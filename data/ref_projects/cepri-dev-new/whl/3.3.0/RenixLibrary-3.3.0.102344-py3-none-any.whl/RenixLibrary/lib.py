import logging
import logging.handlers
import os
import sys
import time

# os.environ['RENIX_SERVER_PATH'] = r'C:\Program Files\Xinertel\Renix3.2.6\server'
sys.path.insert(0, os.path.join(os.environ['RENIX_SERVER_PATH'], 'python_api'))

from .config.param import Config
from .data import *
from .misc import *


def get_logger(Level=logging.INFO, Handle=LogHandle.LOG_FILE, API="log"):
    """
    crate log file and set log level
    :param API:
    :param Level:
    :param Handle:
    :return:
    """
    logger = logging.getLogger(API)
    for i in logger.handlers:
        logger.removeHandler(i)
    logger.setLevel(Level)
    formatter = logging.Formatter("[%(levelname)s] %(asctime)s  %(message)s")

    if Handle.value == 0 or Handle.value == 2:
        if os.name == 'nt':
            path = os.path.join('c:/cllogs', API)
        elif os.name == 'posix':
            path = os.path.join('/var/log/cllogs', API)
        log_file_path = os.path.abspath(os.path.abspath(path) + '/' + time.strftime('%Y%m%d%H%M', time.localtime(time.time())) + '.log ')
        (filepath, filename) = os.path.split(log_file_path)
        if not os.path.exists(filepath):
            os.makedirs(filepath)

        log_file_handler = logging.handlers.RotatingFileHandler(log_file_path,
                                                                maxBytes=10 * 1024 * 1024,
                                                                backupCount=5)
        # log_file_handler.setLevel(log_level)
        log_file_handler.setFormatter(formatter)
        logger.addHandler(log_file_handler)
        logger.info("{} log path: {}".format(API, log_file_path))
        print("{} log path: {}".format(API, log_file_path), flush=True)

    if Handle.value == 1 or Handle.value == 2:
        control_handler = logging.StreamHandler()
        control_handler.setFormatter(formatter)
        logger.addHandler(control_handler)
    return logger


LOGGER = get_logger(Level=logging.INFO, Handle=LogHandle.LOG_FILE, API="RenixLibrary")


def trans_first_letter_to_lower(value):
    if '.' in value:
        result = value.split('.')
        result = [x[0].lower() + x[1:] for x in result]
        result = '.'.join(result)
    else:
        result = value[0].lower() + value[1:]
    return result


def set_attr(ob, k, v): return False if not hasattr(ob, k) else setattr(ob, str(k), v)


def change_param(func_return, args, kwargs):
    if isinstance(func_return, (list, set, tuple)):
        show_func_return = [i.handle if isinstance(i, object) and hasattr(i, "handle") else i for i in func_return]
    elif isinstance(func_return, dict):
        show_func_return = {}
        for k, v in func_return.items():
            if isinstance(v, object) and hasattr(v, "handle"):
                show_func_return.update({k: v.handle})
            else:
                show_func_return.update({k: v})
    elif isinstance(func_return, object) and hasattr(func_return, "handle"):
        show_func_return = func_return.handle
    else:
        show_func_return = func_return

    show_args = (i.handle if isinstance(i, object) and hasattr(i, "handle") else i for i in args)
    if not isinstance(show_args, tuple):
        show_args = tuple(show_args)
    show_kwargs = {}
    for k, v in kwargs.items():
        if isinstance(v, (list, set, tuple)):
            show_v = [i.handle if isinstance(i, object) and hasattr(i, "handle") else i
                      for i in v]
        elif isinstance(v, dict):
            show_v = {}
            for k_1, v_1 in v.items():
                if isinstance(v_1, object) and hasattr(v_1, "handle"):
                    show_v.update({k_1: v_1.handle})
                else:
                    show_v.update({k_1: v_1})
        elif isinstance(v, object) and hasattr(v, "handle"):
            show_v = v.handle
        else:
            show_v = v
        show_kwargs.update({k: show_v})
    return show_func_return, show_args, show_kwargs


def abnormal_check():

    def wrapper(func):
        def decor(*args, **kwargs):
            Config.parse()
            Log = Config.param.log
            Check = Config.param.check
            Show = Config.param.show

            func_return = None
            if Check:
                try:
                    if Show:
                        start = time.perf_counter()
                        func_return = func(*args, **kwargs)
                        LOGGER.info(f'func {func.__name__} execute time: {time.perf_counter() - start:.8f} s')
                    else:
                        func_return = func(*args, **kwargs)
                except Exception as e:
                    if Log:
                        LOGGER.warning('%s : %s', func.__name__, repr(e))
                    func_return = False
                finally:
                    if Log:
                        show_func_return, show_args, show_kwargs = change_param(func_return, args, kwargs)
                        # LOGGER.info('%s : result %s args %s kwargs %s ', func.__name__, func_return, args, kwargs)
                        LOGGER.info('%s : result %s args %s kwargs %s ', func.__name__, show_func_return, show_args,
                                     show_kwargs)
                    return func_return
            else:
                if Show:
                    start = time.perf_counter()
                    func_return = func(*args, **kwargs)
                    LOGGER.info(f'func {func.__name__} execute time: {time.perf_counter() - start:.8f} s')
                else:
                    func_return = func(*args, **kwargs)
                if Log:
                    show_func_return, show_args, show_kwargs = change_param(func_return, args, kwargs)
                    # LOGGER.info('%s : result %s args %s kwargs %s ', func.__name__, func_return, args, kwargs)
                    LOGGER.info('%s : result %s args %s kwargs %s ', func.__name__, show_func_return, show_args,
                                 show_kwargs)
                return func_return

        return decor

    return wrapper


def get_stream_block_stats_query():
    return """SELECT
  coalesce( TX.StreamBlockID, '' ) AS 'StreamBlockID',
  coalesce( TX.PortID, '' ) AS 'TxPortID',
  coalesce( RX.PortID, 'None' ) AS 'RxPortID',
  coalesce( TX.TxStreamFrames, 0 ) AS 'TxStreamFrames',
  coalesce( RX.RxStreamFrames, 0 ) AS 'RxStreamFrames',
  coalesce( TX.TxFrameRate, 0 ) AS 'TxFrameRate',
  CAST ( round( coalesce( RX.RxFrameRate, 0 ), 0 ) AS int ) AS 'RxFrameRate',
  coalesce( TX.TxL1Rate, 0 ) AS 'TxL1Rate',
  coalesce( RX.RxL1Rate, 0 ) AS 'RxL1Rate',
  coalesce( TX.TxUtil, 0.0 ) AS 'TxUtilization',
  coalesce( RX.RxUtil, 0.0 ) AS 'RxUtilization',
  (
      CASE
          WHEN RX.LoadBalance = 1 THEN
              0
          ELSE
              CASE 
                  WHEN (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) - coalesce( RX.RxStreamFrames, 0 )) < 0 
                      THEN RX.RxLossStreamFrames
                  ELSE 
                      (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) - coalesce( RX.RxStreamFrames, 0 ))
              END
      END

  ) AS 'Realtime Loss Frames',
  (
      CASE
          WHEN RX.LoadBalance = 1 THEN
              0
          ELSE
              CASE    
                  WHEN coalesce( TX.TxStreamFrames, 0 ) = 0 THEN 0 
                  ELSE 
                  (
                      CASE        
                          WHEN (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) - coalesce( RX.RxStreamFrames, 0 )) / CAST ( TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) > 100 
                              THEN "100" 
                          WHEN (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) - coalesce( RX.RxStreamFrames, 0 )) / CAST ( TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) < 0.000001 
                          AND  (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) - coalesce( RX.RxStreamFrames, 0 )) / CAST ( TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) > 0 
                              THEN "<0.000001" 
                          WHEN (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) - coalesce( RX.RxStreamFrames, 0 )) / CAST ( TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) < 0
                              THEN CAST (RX.RxLossStreamFrames / CAST ( TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) AS Text)
                          ELSE 
                              CAST ((TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) - coalesce( RX.RxStreamFrames, 0 )) / CAST ( TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount / TX.ChannelCount > 0 THEN RX.RxPortCount / TX.ChannelCount ELSE 1 END ) AS Text) 
                      END 
                  ) 
              END 
      END
  ) AS 'RealtimeLossRate',
  (
      CASE
          WHEN coalesce( TX.TxFrameRate, 0 ) = 0 
              THEN 0
          ELSE 
              round(coalesce( RX.RxLossStreamFrames, 0 ) / CAST ( TX.TxFrameRate AS float ), 6)
      END
  ) AS 'ResumeTime',
  coalesce( RX.RxIpLengthErrorCount, 0 ) AS 'RxIpLengthErrorCount',
  coalesce( RX.RxIpv4ChecksumErrorFrames, 0 ) AS 'RxIpv4ChecksumErrorFrames',
  coalesce( RX.PrbsFillBytes, 0 ) AS 'RXPrbsFillBytes',
  coalesce( RX.DuplicateFrames, 0 ) AS 'RXDuplicateFrames',
  coalesce( RX.InOrderFrames, 0 ) AS 'RXInOrderFrames',
  coalesce( RX.ReOrderFrames, 0 ) AS 'RXReOrderFrames',
  coalesce( RX.PrbsErrorBits, 0 ) AS 'RXPrbsErrorBits',
  coalesce( RX.PrbsErrorFrames, 0 ) AS 'RXPrbsErrorFrames',
  coalesce( RX.RxFcsErrorFrames, 0 ) AS 'RxFcsErrorFrames',
  coalesce( RX.RxFcsErrorFrameRate, 0 ) AS 'RxFcsErrorFrameRate',
  coalesce( RX.TcpChecksumErrorFrames, 0 ) AS 'RXTcpChecksumErrorFrames',
  coalesce( TX.TxTotalBytes, 0 ) AS 'TxTotalBytes',
  coalesce( RX.RxTotalBytes, 0 ) AS 'RxTotalBytes',
  coalesce( RX.RxLateCount, 0 ) AS 'RxLateCount',
  coalesce( RX.RxInSequenceCount, 0 ) AS 'RxInSequenceCount',
  coalesce( RX.RxOutofSequenceCount, 0 ) AS 'RxOutofSequenceCount',
  coalesce( RX.RxMinInterArrivalTime, 0 ) AS 'RxMinInterArrivalTime',
  coalesce( RX.RxMaxInterArrivalTime, 0 ) AS 'RxMaxInterArrivalTime',
  coalesce( RX.RxAvgInterArrivalTime, 0 ) AS 'RxAvgInterArrivalTime',
  coalesce( RX.RxShortTermAvgInterArrivalTime, 0) AS 'RxShortTermAvgInterArrivalTime',
  coalesce( TX.TxByteRate, 0 ) AS 'TxByteRate',
  CAST ( round( coalesce( RX.RxByteRate, 0 ), 0 ) AS int ) AS 'RxByteRate',
  coalesce( TX.TxBitRate, 0 ) AS 'TxBitRate',
  coalesce( RX.RxBitRate, 0 ) AS 'RxBitRate',
  coalesce( RX.MinLatency, 0.0 ) AS 'MinLatency',
  coalesce( RX.MaxLatency, 0.0 ) AS 'MaxLatency',
  coalesce( RX.AvaLatency, 0.0 ) AS 'AvaLatency',
  coalesce( Rx.ShortTermAvgLatency, 0.0) AS 'ShortTermAvgLatency',
  coalesce( RX.MinJitter, 0.0 ) AS 'MinJitter',
  coalesce( RX.MaxJitter, 0.0 ) AS 'MaxJitter',
  coalesce( RX.AvaJitter, 0.0 ) AS 'AvaJitter',
  coalesce( RX.ShortTermAvgJitter, 0.0 ) AS 'ShortTermAvgJitter',
  coalesce( RX.RxPayloadErr, 0 ) AS 'RxPayloadErr',
  coalesce( RX.RxSeqErr, 0 ) AS 'RxSeqErr' 
FROM
  (
  SELECT
    StreamBlockID,
    ChannelCount,
    group_concat( DISTINCT PortID ) PortID,
    sum( TxStreamFrames ) TxStreamFrames,
    sum( TxFrameRate ) TxFrameRate,
    sum( TxL1Rate ) TxL1Rate,
    sum( TxUtil ) TxUtil,
    sum( TxMegaBitRate ) TxMegaBitRate,
    sum( TxByteRate ) TxByteRate,
    sum( TxBitRate ) TxBitRate,
    sum( TxTotalBytes ) TxTotalBytes,
    count( PortID ) TxPortCount 
  FROM
    ( SELECT * FROM StreamBlockTxStats GROUP BY StreamBlockID, PortID ) 
  GROUP BY
    StreamBlockID 
  ) AS TX
  LEFT JOIN (
  SELECT
    StreamBlockID,
    group_concat( DISTINCT PortID ) PortID,
    LoadBalance,
    sum( RxStreamFrames ) RxStreamFrames,
    sum( RxFrameRate ) RxFrameRate,
    sum( RxL1Rate ) RxL1Rate,
    sum( RxUtil ) RxUtil,
    sum( RxLossStreamFrames ) RxLossStreamFrames,
    sum( RxPayloadErr ) RxPayloadErr,
    sum( RxSeqErr ) RxSeqErr,
    sum( RxIpLengthErrorCount ) RxIpLengthErrorCount,
    sum( RxMegaBitRate ) RxMegaBitRate,
    sum( RxByteRate ) RxByteRate,
    sum( RxBitRate ) RxBitRate,
    min( MinLatency ) MinLatency,
    max( MaxLatency ) MaxLatency,
    avg( AvaLatency ) AvaLatency,
    avg( ShortTermAvgLatency ) ShortTermAvgLatency,
    min( MinJitter ) MinJitter,
    max( MaxJitter ) MaxJitter,
    avg( AvaJitter ) AvaJitter,
    avg( ShortTermAvgJitter ) ShortTermAvgJitter,
    sum( RxIpv4ChecksumErrorFrames ) RxIpv4ChecksumErrorFrames,
    sum( PrbsFillBytes ) PrbsFillBytes,
    sum( DuplicateFrames ) DuplicateFrames,
    sum( InOrderFrames ) InOrderFrames,
    sum( ReOrderFrames ) ReOrderFrames,
    sum( PrbsErrorBits ) PrbsErrorBits,
    sum( PrbsErrorFrames ) PrbsErrorFrames,
    sum( RxFcsErrorFrames ) RxFcsErrorFrames,
    sum( RxFcsErrorFrameRate ) RxFcsErrorFrameRate,
    sum( TcpChecksumErrorFrames ) TcpChecksumErrorFrames,
    sum( RxTotalBytes ) RxTotalBytes,
    sum( RxLateCount ) RxLateCount,
    sum( RxInSequenceCount ) RxInSequenceCount,
    sum( RxOutofSequenceCount ) RxOutofSequenceCount,
    min( RxMinInterArrivalTime ) RxMinInterArrivalTime,
    max( RxMaxInterArrivalTime ) RxMaxInterArrivalTime,
    avg( RxAvgInterArrivalTime ) RxAvgInterArrivalTime,
    avg( RxShortTermAvgInterArrivalTime ) RxShortTermAvgInterArrivalTime,
    count( PortID ) RxPortCount 
  FROM
    ( SELECT * FROM StreamBlockRxStats GROUP BY StreamBlockID, PortID ) 
  WHERE
    RxStreamFrames > 0 
  GROUP BY
    StreamBlockID 
  ) AS RX ON TX.StreamBlockID = RX.StreamBlockID 
GROUP BY
  TX.StreamBlockID"""


def get_stream_stats_query():
    return """SELECT 
      coalesce( TX.StreamBlockID, '' ) AS StreamBlockID,
      coalesce( TX.StreamID, '' ) AS StreamID,
      coalesce( TX.PortID, '' ) AS TxPortID,
      coalesce( RX.PortID, '' ) AS RxPortID,
      coalesce(TX.TxStreamFrames , 0 ) AS TxStreamFrames,
      coalesce(RX.RxStreamFrames, 0 ) AS RxStreamFrames,
      coalesce(TX.TxFrameRate, 0 ) AS 'TxFrameRate',
      CAST ( round( coalesce(RX.RxFrameRate, 0 ), 0 ) AS int ) AS 'RxFrameRate',
      coalesce(TX.TxL1Rate, 0 ) AS 'TxL1Rate',
      CAST ( round( coalesce(RX.RxL1Rate, 0 ), 0 ) AS int ) AS 'RxL1Rate',  
      (
          CASE
              WHEN RX.LoadBalance = 1 THEN
                  0
              ELSE
                  CASE
                      WHEN coalesce(TX.TxStreamFrames, 0 ) * ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) - coalesce(RX.RxStreamFrames, 0 ) < 0
                      THEN RX.RxLossStreamFrames
                      ELSE coalesce(TX.TxStreamFrames, 0 ) * ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) - coalesce(RX.RxStreamFrames, 0 )
                  END
          END
      ) AS 'RealtimeLossFrames',
      (
          CASE
              WHEN RX.LoadBalance = 1 THEN
                    0
              ELSE
                  CASE      
                      WHEN coalesce(TX.TxStreamFrames, 0 ) = 0 THEN 0 
                      ELSE 
                      (
                          CASE        
                              WHEN (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) - coalesce(RX.RxStreamFrames, 0 )) / CAST (TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) > 100 
                              THEN "100" 
                              WHEN (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) - coalesce(RX.RxStreamFrames, 0 )) / CAST (TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) < 0.000001 
                              AND  (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) - coalesce(RX.RxStreamFrames, 0 )) / CAST (TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) > 0 
                              THEN "<0.000001" 
                              WHEN (TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) - coalesce(RX.RxStreamFrames, 0 )) / CAST (TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) < 0
                              THEN CAST (RX.RxLossStreamFrames / CAST (TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) AS Text) 
                              ELSE CAST ((TX.TxStreamFrames * ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) - coalesce(RX.RxStreamFrames, 0 )) / CAST (TX.TxStreamFrames AS float ) * 100 / ( CASE WHEN RX.RxPortCount > 0 THEN RX.RxPortCount ELSE 1 END ) AS Text) 
                          END 
                      ) 
                  END 
          END
      ) AS 'RealtimeLossRate',
      (
            CASE
                WHEN coalesce( TX.TxFrameRate, 0 ) = 0 
                    THEN 0
                ELSE 
                    round(coalesce( RX.RxLossStreamFrames, 0 ) / CAST ( TX.TxFrameRate AS float ), 6)
            END
      ) AS 'ResumeTime',
      coalesce(TX.TxUtil, 0.0 ) AS 'TxUtil',
      coalesce(RX.RxUtil, 0.0 ) AS 'RxUtil',
      coalesce(TX.TxByteRate, 0 ) AS TxByteRate,
      CAST ( round( coalesce( RX.RxByteRate, 0 ), 0 ) AS int ) AS RxByteRate,
      CAST ( round( coalesce(TX.TxBitRate, 0 ), 0 ) AS int ) AS 'TxBitRate',
      CAST ( round( coalesce(RX.RxBitRate, 0 ), 0 ) AS int ) AS 'RxBitRate',
      coalesce( RX.PrbsErrorFrames, 0 ) AS 'RxPRBSErrorFrames',
      coalesce( RX.DuplicateFrames, 0 ) AS 'RxDuplicateFrames',
      coalesce( RX.InOrderFrames, 0 ) AS 'RxInOrderFrames',
      coalesce( RX.ReOrderFrames, 0 ) AS 'ReOrderFrames',
      coalesce( TX.TxTotalBytes, 0 ) AS 'TxTotalBytes',
      coalesce( RX.RxTotalBytes, 0 ) AS 'RxTotalBytes',
      coalesce( RX.RxLateCount, 0 ) AS 'RxLateFrames',
      coalesce( RX.RxInSequenceCount, 0 ) AS 'RxInSequenceFrames',
      coalesce( RX.RxOutofSequenceCount, 0 ) AS 'RxOutofSequenceFrames',
      coalesce( RX.RxMinInterArrivalTime, 0 ) AS 'RxMinInterArrivalTime',
      coalesce( RX.RxMaxInterArrivalTime, 0 ) AS 'RxMaxInterArrivalTime',
      coalesce( RX.RxAvgInterArrivalTime, 0 ) AS 'RxAvgInterArrivalTime',
      coalesce( RX.RxShortTermAvgInterArrivalTime, 0 ) AS 'RxShortTermAvgInterArrivalTime',
      coalesce( RX.RxIpv4ChecksumErrorFrames, 0 ) AS 'RxIPv4ChecksumErrorFrames',
      coalesce( RX.PrbsErrorBits, 0 ) AS 'RxPRBSErrorBits',
      coalesce( RX.PrbsFillBytes, 0 ) AS 'RxPRBSFillBytes',
      coalesce( RX.RxFcsErrorFrames, 0 ) AS 'RxFCSErrorFrames',
      coalesce( RX.RxFcsErrorFrameRate, 0 ) AS 'RxFCSErrorFrameRate',
      coalesce( RX.TcpChecksumErrorFrames, 0 ) AS 'RxTCPChecksumErrorFrames', 
      coalesce( RX.RxPayloadErr, 0 ) AS 'RxPayloadErrorFrames', 
      coalesce( RX.RxSeqErr, 0 ) AS 'RxSequenceErrorFrames', 
      coalesce(RX.RxIpLengthErrorCount, 0 ) AS 'RxIPLengthErrorFrames', 
      coalesce(RX.MinLatency, 0.0 ) AS 'MinLatency',
      coalesce(RX.MaxLatency, 0.0 ) AS 'MaxLatency',
      coalesce(RX.AvaLatency, 0.0 ) AS 'AvaLatency',
      coalesce(RX.ShortTermAvgLatency, 0.0 ) AS 'ShortTermAvgLatency',  
      coalesce(RX.MinJitter, 0.0 ) AS 'MinJitter',
      coalesce(RX.MaxJitter, 0.0 ) AS 'MaxJitter',
      coalesce(RX.AvaJitter, 0.0 ) AS 'AvaJitter',
      coalesce(RX.ShortTermAvgJitter, 0.0 ) AS 'ShortTermAvgJitter'
    FROM
    (
        SELECT
            StreamID,
            StreamBlockID,
            group_concat( DISTINCT PortID ) PortID,
            sum( TxStreamFrames ) TxStreamFrames,
            sum( TxFrameRate ) TxFrameRate,
            sum( TxL1Rate ) TxL1Rate,
            sum( TxUtil ) TxUtil,
            sum( TxMegaBitRate ) TxMegaBitRate,
            sum( TxByteRate ) TxByteRate,
            sum( TxBitRate ) TxBitRate,
            sum( TxTotalBytes ) TxTotalBytes,
            count( PortID ) TxPortCount 
        FROM
            ( SELECT * FROM StreamTxStats GROUP BY StreamID, StreamBlockID, PortID ) 
        GROUP BY
            StreamBlockID,
            StreamID 
        ) AS TX
        LEFT JOIN 
        (
        SELECT
            StreamID,
            StreamBlockID,
            group_concat( DISTINCT PortID ) PortID,
            LoadBalance,
            sum( RxStreamFrames ) RxStreamFrames,
            sum( RxFrameRate ) RxFrameRate,
            sum( RxL1Rate ) RxL1Rate,
            sum( RxUtil ) RxUtil,
            sum( RxLossStreamFrames ) RxLossStreamFrames,
            sum( RxPayloadErr ) RxPayloadErr,
            sum( RxSeqErr ) RxSeqErr,
            sum( RxIpLengthErrorCount ) RxIpLengthErrorCount,
            sum( RxMegaBitRate ) RxMegaBitRate,
            sum( RxByteRate ) RxByteRate,
            sum( RxBitRate ) RxBitRate,
            min( MinLatency ) MinLatency,
            max( MaxLatency ) MaxLatency,
            avg( AvaLatency ) AvaLatency,
            avg( ShortTermAvgLatency ) ShortTermAvgLatency,
            min( MinJitter ) MinJitter,
            max( MaxJitter ) MaxJitter,
            avg( AvaJitter ) AvaJitter,
            avg( ShortTermAvgJitter ) ShortTermAvgJitter,
            sum( RxIpv4ChecksumErrorFrames ) RxIpv4ChecksumErrorFrames,
            sum( PrbsFillBytes ) PrbsFillBytes,
            sum( DuplicateFrames ) DuplicateFrames,
            sum( InOrderFrames ) InOrderFrames,
            sum( ReOrderFrames ) ReOrderFrames,
            sum( PrbsErrorBits ) PrbsErrorBits,
            sum( PrbsErrorFrames ) PrbsErrorFrames,
            sum( RxFcsErrorFrames ) RxFcsErrorFrames,
            sum( RxFcsErrorFrameRate ) RxFcsErrorFrameRate,
            sum( TcpChecksumErrorFrames ) TcpChecksumErrorFrames,
            sum( RxTotalBytes ) RxTotalBytes,
            sum( RxLateCount ) RxLateCount,
            sum( RxInSequenceCount ) RxInSequenceCount,
            sum( RxOutofSequenceCount ) RxOutofSequenceCount,
            min( RxMinInterArrivalTime ) RxMinInterArrivalTime,
            max( RxMaxInterArrivalTime ) RxMaxInterArrivalTime,
            avg( RxAvgInterArrivalTime ) RxAvgInterArrivalTime,
            avg( RxShortTermAvgInterArrivalTime ) RxShortTermAvgInterArrivalTime,
            count( PortID ) RxPortCount 
        FROM
            ( SELECT * FROM StreamRxStats GROUP BY StreamID, StreamBlockID, PortID )
        WHERE
            RxStreamFrames > 0 
        GROUP BY
            StreamBlockID,
            StreamID 
    ) AS RX ON TX.StreamBlockID = RX.StreamBlockID AND TX.StreamID = RX.StreamID 
    GROUP BY
        TX.StreamBlockID,
        TX.StreamID"""

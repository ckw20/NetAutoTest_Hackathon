# cython:language_level=3
import os
import sys
import re
import sqlite3
import time
import pandas as pd
import openpyxl

if 'RENIX_SERVER_PATH' in os.environ:
    sys.path.insert(0, os.path.join(os.environ['RENIX_SERVER_PATH'], 'python_api'))

from tabulate import tabulate
from time import strftime
from time import gmtime
from prettytable import PrettyTable
from RenixLibrary.lib import *
from renix_py_api.renix import *
from RenixLibrary.libs.imix import *
from RenixLibrary.rtsm.base import RTSM, Connect_Cl
from renix_py_api.benchmark_test.benchmark_test_api import *
from RenixLibrary.header.modifier import Modifier
from RenixLibrary.libs.multicast import MulticastGroup
from RenixLibrary.protocol.ospfv2 import OspfRouter
from RenixLibrary.protocol.ospfv3 import Ospfv3Router
from RenixLibrary.protocol.bgp import BgpRouter
from RenixLibrary.protocol.isis import IsisRouter
from RenixLibrary.protocol.pim import PimRouter
from RenixLibrary.protocol.mld import Mld
from RenixLibrary.protocol.mld import MldQuerier
from RenixLibrary.protocol.igmp import Igmp
from RenixLibrary.protocol.igmp import IgmpQuerier
from RenixLibrary.protocol.vxlan import Vxlan
from RenixLibrary.protocol.dhcp_client import DhcpClient
from RenixLibrary.protocol.dhcp_server import DhcpServer
from RenixLibrary.protocol.dhcpv6_client import Dhcpv6Client
from RenixLibrary.protocol.dhcpv6_server import Dhcpv6Server
from RenixLibrary.protocol.l2tp import L2tp
from RenixLibrary.protocol.pppoe import PppoeClient
from RenixLibrary.protocol.pppoe import PppoeServer
from RenixLibrary.protocol.rip import RipRouter
from RenixLibrary.protocol.pcep import Pcep
from RenixLibrary.protocol.bfd import BfdRouter
from RenixLibrary.protocol.ldp import Ldp
from RenixLibrary.protocol.lsp_ping import LspPing
from RenixLibrary.protocol.dot1x import Dot1x
from RenixLibrary.protocol.dot3ah import Dot3ah
from RenixLibrary.protocol.dot1ag import Dot1ag
from RenixLibrary.protocol.saa import Saa
from RenixLibrary.protocol.y1731 import Y1731
from RenixLibrary.protocol.lacp import Lacp
from RenixLibrary.protocol.openflow_switch import OpenFlowSwitch
from RenixLibrary.protocol.openflow_controller import OpenFlowController
from RenixLibrary.protocol.ovsdb import Ovsdb
from RenixLibrary.protocol.twamp import Twamp
from RenixLibrary.protocol.ieee8021as import Ieee8021as
from RenixLibrary.config.param import Config
from renix_py_api.benchmark_test.smart_scripter_api import *


class RenixAPI:

    def __init__(self, logLevel=logging.INFO, logHandle=LogHandle.LOG_FILE, **kwargs):
        self.__dateTime = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
        self.__sysEntry = None
        # self.__suitePath = "C:\\TestSuite\\Benchmark\\"
        self.__suitePath = os.path.dirname(
            os.environ.get("RENIX_SERVER_PATH").replace("server", "TestSuite")) + '/Benchmark/'
        if not os.path.exists(self.__suitePath):
            os.makedirs(self.__suitePath)
        self.__logger = None
        self.__logLevel = logLevel
        self.__logHandle = logHandle
        self.__generator = None
        self.__product = None
        self.__tsuID = []
        self.__tsuIDDict = {}
        self.__portIDDict = {}
        self.__manager = []
        self.__chassis = []
        self.__card = []
        self.__hardwarePort = []
        self.__mapPort = {}
        self.__mapHardwarePort = {}
        self.__mode = 'db'
        self.__streamBlockTxStats = None
        self.__streamBlockRxStats = None
        self.__streamBlockStats = None
        self.__streamStats = None
        self.__statictis = False
        self.__statictisData = {}
        self.__subscribe = None
        self.__rtsm = None
        self.__cl_port = None
        self.__cl_instance = None
        self.__rom_manager =None
        self.__license = []
        if 'License' in kwargs:
            self.__license = kwargs['License']
        else:
            self.__license = []

    def __iter__(self):
        self.__generator = 1
        return self

    def __next__(self):
        if self.__generator > 100:
            raise StopIteration
        x = self.__generator
        self.__generator += 1
        return x

    @property
    def handle(self):
        return self.__sysEntry.handle

    @property
    def statictis(self):
        return self.__statictis

    @property
    def logger(self):
        return self.__logger

    @property
    def date_time(self):
        return self.__dateTime

    @property
    def sys_entry(self):
        # self.__sysEntry.get()
        return self.__sysEntry

    @property
    def suite_path(self):
        self.logger.info('get suite_path : %s', self.__suitePath.replace("\\", "/"))
        return self.__suitePath.replace("\\", "/")

    @property
    def manager(self):
        self.__manager = self.sys_entry.get_children('HardwareManager')
        self.logger.info('get manager : %s', self.__manager)
        return self.__manager

    @property
    def chassis(self):
        self.__chassis = [z for y in [x.get_children('HardwareChassis') for x in self.manager] for z in y]
        self.logger.info('get chassis : %s', self.__chassis)
        return self.__chassis

    @property
    def tsu_id(self):
        self.__tsuID = list(range(len(self.chassis)))
        self.logger.info('get TsuId : %s', self.__tsuID)
        return self.__tsuID

    @property
    def tsu_id_dict(self):
        return self.__tsuIDDict

    @property
    def card(self):
        self.__card = [z for y in [x.get_children('HardwareCard') for x in self.chassis] for z in y]
        self.logger.info('get card : %s', self.__card)
        return self.__card

    @property
    def hardware_port(self):
        self.__hardwarePort = [z for y in [x.lower for x in self.card] for z in y]
        self.logger.info('get hardware_port : %s', self.__hardwarePort)
        return self.__hardwarePort

    @property
    def port_id_dict(self):
        return self.__portIDDict

    @property
    def map_port(self):
        return self.__mapPort

    @property
    def map_hardware_port(self):
        return self.__mapHardwarePort

    @property
    def mode(self):
        return self.__mode

    @property
    def product(self):
        return self.__product

    @property
    def cl_port(self):
        return self.__cl_port

    @property
    def cl_instance(self):
        return self.__cl_instance

    @property
    def rom_manager(self):
        return self.__rom_manager

    def init_imix(self):
        return [IMix(Name='Default', Default=True),
                IMix(Name='4-Point', Default=True),
                IMix(Name='IPSEC', Default=True),
                IMix(Name='TCPv4', Default=True)]

    def _reset(self):
        for x in MAP_HANDLE_OBJECT.values():
            del x
        for x in map_name_imix.values():
            del x
        map_stream_header.clear()
        map_stream_imix.clear()
        map_protocol_object.clear()
        MAP_HANDLE_OBJECT.clear()
        MAP_STREAM_MODIFIER_ID.clear()
        map_name_imix.clear()
        self.__tsuID = []
        self.__tsuIDDict = {}
        self.__portIDDict = {}
        self.__manager = []
        self.__chassis = []
        self.__card = []
        self.__hardwarePort = []
        self.__mapPort = {}
        self.__mapHardwarePort = {}
        self.__mode = 'performance'
        self.__streamBlockTxStats = None
        self.__streamBlockRxStats = None
        self.__streamBlockStats = None
        self.__statictis = False
        self.__statictisData = {}
        self.__subscribe = None

    def _wait_state(self, Sessions, AttrName='State', State=None, Interval=1, TimeOut=60):
        Interval = int(Interval)
        TimeOut = int(TimeOut)
        if State is None:
            State = []
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        if not isinstance(State, (list, set, tuple)):
            State = [State]
        State = [str(x).lower() for x in State]
        flag = True
        while flag:
            flag = False
            TimeOut = TimeOut - Interval
            if TimeOut == 0:
                raise TesterException(f'Wait for state({State} erorr)')
            else:
                for Session in Sessions:
                    state = getattr(Session, AttrName, "NotFound")
                    if isinstance(state, Enum):
                        state = state.name
                    if str(state).lower() not in State:
                        logging.info(f'{Session.Name} == {str(state).lower()}')
                        flag = True
                        break
            time.sleep(Interval)
        return True

    def _set_attr(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for k, v in kwargs.items():
            for session in Sessions:
                if hasattr(session, k):
                    setattr(session, str(k), v)
        return True

    def edit_log(self, logLevel, logHandle):
        self.__logLevel = logLevel
        self.__logHandle = logHandle
        return True

    @abnormal_check()
    def reset_tester(self):
        self._reset()
        ResetROMCommand(cl_instance=self.cl_instance).execute()
        # self.cl_instance.rom_init()
        self.__sysEntry = self.cl_instance.get_sys_entry()
        self.sys_entry.ProductType = self.product
        self.init_imix()
        return True

    @staticmethod
    @abnormal_check()
    def clear_log():
        if os.name == 'nt':
            path = os.path.join('c:/cllogs', 'RenixLibrary').replace('\\', '/')
        elif os.name == 'posix':
            path = os.path.join('/var/log/cllogs', 'RenixLibrary').replace('\\', '/')
        if os.path.exists(path):
            os.system(f'rd /s /q \"{path}\"')
            # os.remove(path)
        path = os.path.join(os.getenv('RENIX_SERVER_PATH'), 'RenixLibrary')
        if os.path.exists(path):
            os.system(f'rd /s /q \"{path}\"')
            # os.remove(path)
        return True

    @abnormal_check()
    def shutdown_tester(self):
        try:
            if self.__rtsm is not None:
                self.__rtsm.ShutDown(self.cl_port)
            else:
                CaptureDataListener().stop()
                self.cl_instance.exit()
        except Exception as e:
            print(str(e))
        finally:
            return True

    # abnormal_check()
    def init_tester(self, Product='BIGTAO', Mode='db', Log=True, Rtsm=None, RtsmPort=10001, TimeOut=30,
                    CL=None, CLPort=9001, StartApp=True, **kwargs):
        if Log:
            # self.__logger = get_logger(Level=self.__logLevel, Handle=self.__logHandle, API="RenixLibrary")
            self.__logger = LOGGER
            Show = False
            Check = True
            if 'Show' in kwargs:
                Show = kwargs['Show']
            elif 'Check' in kwargs:
                Check = kwargs['Check']
            Config.save(check=Check, show=Show, log=Log)
        else:
            self.__logger = logging
            Config.save()
        if Rtsm is not None and CL is None:
            self.__rtsm = RTSM(Rtsm, RtsmPort, TimeOut * 1000)
            self.__cl_port = self.__rtsm.Start()
            self.__rtsm.ConnectionCl()
            self.__cl_instance = self.__rtsm.cl_instance
            if StartApp:
                self.__rtsm.StartAPP()
        elif Rtsm is None and CL is not None:
            Connect_Cl(Host=CL, Port=CLPort, TimeOut=TimeOut * 1000)
            self.__cl_instance = get_cl()
        else:
            # initialize(log=Log, log_level=self.__logLevel, log_handle=self.__logHandle)
            self.__cl_instance = initialize(log=False)
        self.__sysEntry = self.cl_instance.get_sys_entry()
        self.__rom_manager = self.cl_instance.rom_manager
        self._reset()
        self.__sysEntry.ProductType = Product
        self.__sysEntry.get()
        self.init_imix()
        self.__mode = Mode.lower()
        self.__product = Product
        return self.__sysEntry

    @abnormal_check()
    def start_app(self):
        return self.__rtsm.StartAPP()

    @abnormal_check()
    def apply(self):
        CommitCommand().execute()
        return True

    @abnormal_check()
    def get(self, element: EnumBase = EnumBase.All):
        result = EnumBase.TRUE.value
        if element == EnumBase.All or EnumBase.TsuId:
            chassisList = self.chassis
            self.__tsuIDDict = {x: chassisList[x] for x in range(len(chassisList))}
            self.logger.info('get : TsuId_dict %s', self.__tsuIDDict)
        if element == EnumBase.All or EnumBase.PortId:
            self.__portIDDict = {}
            for param in self.tsu_id_dict.values():
                hardwarePortList = [z for y in [x.lower for x in param.get_children('HardwareCard')] for z in y]
                for i in range(len(hardwarePortList)):
                    for j in range(len(hardwarePortList) - i - 1):
                        if int(hardwarePortList[j].Location.split('/')[-2]) > int(
                                hardwarePortList[j + 1].Location.split('/')[-2]):
                            hardwarePortList[j], hardwarePortList[j + 1] = hardwarePortList[j + 1], hardwarePortList[j]
                        elif int(hardwarePortList[j].Location.split('/')[-2]) == int(
                                hardwarePortList[j + 1].Location.split('/')[-2]) and int(
                            hardwarePortList[j].Location.split('/')[-1]) > int(
                            hardwarePortList[j + 1].Location.split('/')[-1]):
                            hardwarePortList[j], hardwarePortList[j + 1] = hardwarePortList[j + 1], hardwarePortList[j]
                self.__portIDDict[param] = hardwarePortList
            self.logger.info('get : PortId_dict %s', self.__portIDDict)
        if element == EnumBase.All or EnumBase.MapHardwarePort:
            self.__mapHardwarePort = {}
            for key, value in zip(self.tsu_id_dict.keys(), self.tsu_id_dict.values()):
                for i, port in enumerate(self.port_id_dict[value], start=1):
                    self.__mapHardwarePort[str([key, i])] = port
            self.logger.info('get : map_hardware_port %s', self.__mapHardwarePort)
        if element == EnumBase.All or EnumBase.MapPort:
            self.__mapPort = {}
            for key, value in zip(self.__mapHardwarePort.keys(), self.__mapHardwarePort.values()):
                port_list = value.get_relatives('HardwareLogical', EnumRelationDirection.TARGET, 'Port')
                if port_list:
                    self.__mapPort[key] = port_list[0]
            self.logger.info('get : map_port %s', self.__mapPort)
        return result

    @abnormal_check()
    def get_ports(self):
        """
        Get all ports configured for the current tester

        :return: Port object

        Examples:
        | ${result} | Get Ports |
        """

        return self.sys_entry.get_children('Port')

    @abnormal_check()
    def get_hardware_ports(self, tsuID: int, portID=None):
        """

        :param tsuID:
        :param portID:
        :return:
        """
        chassis = self.tsu_id_dict[tsuID]
        hardwarePortList = self.port_id_dict[chassis]
        if portID is None:
            result = hardwarePortList
        else:
            result = [hardwarePortList[x - 1] for x in portID]
        return result

    @abnormal_check()
    def get_ports_from_hardware(self, hardwarePorts):
        keyList = []
        for k, v in self.map_hardware_port.items():
            keyList.extend(k for h in hardwarePorts if h == v)
        portObjects = [self.map_port[x] for x in keyList]
        self.logger.info('get ports : HardwarePorts %s port_objects %s', hardwarePorts, portObjects)
        return portObjects

    @abnormal_check()
    def get_ports_state(self, hardwarePorts):
        portStates = []
        portObjects = self.get_ports_from_hardware(hardwarePorts)
        ethMedias = [port.get_children('EthFiber')[0] if 'fiber' in port.PortCfgType.name.lower() else
                     port.get_children('EthCopper')[0] for port in portObjects]
        for po, hp, et in zip(portObjects, hardwarePorts, ethMedias):
            states = {"Ipaddr": hp.Location, "Name": po.Name, "Status": po.Online, "Connect_Status": et.LinkStatus.name}
            portStates.append(states)
        self.logger.info('get ports state : HardwarePorts %s ports_states %s', hardwarePorts, portStates)
        return portStates
    @abnormal_check()
    def get_interface_protocol(self, Interface):
        if isinstance(Interface, (set, list, tuple)):
            Interface = Interface[0]
        cmd = GetBoundProtocolCommand(InterfaceHandle=Interface.handle)
        cmd.execute()
        if cmd.ProtocolHandles:
            return [self.rom_manager.get_object(x) for x in cmd.ProtocolHandles]
        else:
            return []


    @abnormal_check()
    def validate_port(self, port: dict):
        """

        :param port:
        :return:
        """
        result = EnumBase.FALSE.value
        tsuID = port['TsuId']
        if tsuID in self.tsu_id_dict.keys():
            # portList = [x for x in range(1, len(self.get_hardware_ports(tsuID=tsuID, portID=None)) + 1)]
            tsuObject = self.tsu_id_dict[tsuID]
            portList = list(self.port_id_dict[tsuObject])
            portList = list(range(1, len(portList) + 1))
            if set(port['PortId']).issubset(set(portList)):
                result = EnumBase.TRUE.value
            else:
                result = EnumBase.PortId.value
        else:
            result = EnumBase.TsuId.value
        return result

    @abnormal_check()
    def connect_chassis(self, Chassis):
        if not isinstance(Chassis, list):
            Chassis = [Chassis]
        connectChassisObject = ConnectChassisCommand(HostnameList=Chassis, cl_instance=self.cl_instance)
        try:
            connectChassisObject.execute()
        except Exception as e:
            if "failed due to product mismatch" not in repr(e):
                raise type(e)(repr(e)) from e
            if self.__sysEntry.ProductType.name == 'BIGTAO':
                self.__sysEntry.ProductType = 1
            else:
                self.__sysEntry.ProductType = 0
            # self.__sysEntry.get()
            connectChassisObject.execute()
        connectList = connectChassisObject.ConnectedList
        if len(connectList) != len(Chassis):
            raise TesterException("Chassis connect failed")
        return [self.rom_manager.get_object(handle, cl=self.cl_instance) for handle in connectList]

    @abnormal_check()
    def reserve_port(self, Locations, Force=False, Debug=False, WaitForStatusUp=True):
        if not isinstance(Locations, (list, set, tuple)):
            Locations = [Locations]
        locations = []
        for x in Locations:
            if "//" in x:
                locations.append(x)
            else:
                locations.append("//" + x)
        result = []
        if Debug:
            for location in locations:
                port = Port(upper=self.sys_entry)
                port.Location = location
                result.append(port)
        else:
            chassisList = list(set([x.split('/')[2] for x in locations]))
            renixConnectObject = ConnectChassisCommand(HostnameList=chassisList, cl_instance=self.cl_instance)
            try:
                renixConnectObject.execute()
            except Exception as e:
                if "failed due to product mismatch" not in repr(e):
                    raise type(e)(repr(e)) from e
                if self.__sysEntry.ProductType.name == 'BIGTAO':
                    self.__sysEntry.ProductType = 1
                else:
                    self.__sysEntry.ProductType = 0
                self.sys_entry.get()
                renixConnectObject.execute()
            # 检查设备license
            for license in [x.lower() for x in self.__license]:
                ClearExpiredLicenseCommand(ChassisList=renixConnectObject.ConnectedList, cl_instance=self.cl_instance).execute()
                licenseDict = {}
                for chassis in renixConnectObject.ConnectedList:
                    licenseDict.update({self.rom_manager.get_object(chassis, cl=self.cl_instance): False})
                    get_lic = GetLicenseFeatureInfoCommand(Chassis=chassis, cl_instance=self.cl_instance)
                    get_lic.execute()
                    for license_handle in get_lic.FeatureInfoList:
                        licObject = self.rom_manager.get_object(license_handle, cl=self.cl_instance)
                        if licObject.FeatureName.lower() == license:
                            licenseDict.update({self.rom_manager.get_object(chassis, cl=self.cl_instance): True})
                license_info = []
                for k, v in licenseDict.items():
                    if not v:
                        license_info.append(k.Hostname)
                if license_info:
                    print(f"Chassis {license_info} does not have {license} license")
                    raise TesterException(f"Chassis {license_info} does not have {license} license")
            if Force:
                ReleasePortCommand(LocationList=locations, ForceRelease=True, cl_instance=self.cl_instance).execute()
                time.sleep(3)
            renixCmdObject = ReservePortCommand(LocationList=locations, WaitForPortStatusUp=WaitForStatusUp, cl_instance=self.cl_instance)
            renixCmdObject.execute()
            onlinePorts = renixCmdObject.OnlinePorts
            if len(onlinePorts) != len(locations):
                result = EnumBase.FALSE.value
            else:
                portObjects = self.sys_entry.get_children('Port')
                result = []
                for x in onlinePorts:
                    result.extend(j for j in portObjects if x == j.handle)
        # CSR-9053
        if not result:
            self._create_capture_event(Ports=result)
        return result

    @abnormal_check()
    def release_port(self, Locations=None, Ports=None, Force=False, Debug=False):
        result = EnumBase.TRUE.value
        if not Debug:
            if Locations is not None:
                locations = []
                for x in Locations:
                    if "//" in x:
                        locations.append(x)
                    else:
                        locations.append("//" + x)
                renixCmdObject = ReleasePortCommand(LocationList=locations, ForceRelease=Force, cl_instance=self.cl_instance)
                renixCmdObject.execute()
            if Ports is not None:
                if not isinstance(Ports, list):
                    Ports = [Ports]
                renixCmdObject = BringPortsOfflineCommand(PortList=[x.handle for x in Ports], cl_instance=self.cl_instance)
                renixCmdObject.execute()
            time.sleep(5)
        return result

    @abnormal_check()
    def load_case(self, Path):
        """
        Load the test instrument configuration file

        Args:

            :param Path: test file path
            :type Path: path string (e.g., "C:/test.xcfg")

        :return: Bool (e.g., True / False)

        Examples:
        | ${result} | load case | Path=='C:/test.xcfg' |
        """

        result = EnumBase.TRUE.value
        LoadTestCaseCommand(TestCase=Path, cl_instance=self.cl_instance).execute()
        self.sys_entry.get()
        # self.sys_entry.get_children('Port')
        map_stream_header.clear()
        map_stream_imix.clear()
        map_protocol_object.clear()
        MAP_HANDLE_OBJECT.clear()
        return result

    @abnormal_check()
    def save_case(self, Path):
        SaveTestCaseCommand(TestCase=Path, cl_instance=self.cl_instance).execute()
        return EnumBase.TRUE.value

    @abnormal_check()
    def relocate_ports(self, Ports, Locations, Force=False, Debug=False):
        result = EnumBase.TRUE.value
        if not isinstance(Ports, list):
            Ports = [Ports]
        if not isinstance(Locations, list):
            Locations = [Locations]
        temp_locations = []
        for p, v in zip(Ports, Locations):
            if "//" not in v:
                v = "//" + v
            setattr(p, "Location", v)
            temp_locations.append(v)
        if not Debug:
            portList = [x.handle for x in Ports]
            chassisList = list(set([x.split('/')[-3] for x in Locations]))
            renixConnectObject = ConnectChassisCommand(HostnameList=chassisList, cl_instance=self.cl_instance)
            try:
                renixConnectObject.execute()
            except Exception as e:
                raise TesterException(str(e))
            if Force:
                ReleasePortCommand(LocationList=temp_locations, ForceRelease=True, cl_instance=self.cl_instance).execute()
                time.sleep(3)
            BringPortsOnlineCommand(PortList=portList, cl_instance=self.cl_instance).execute()
            for p in Ports:
                if p.Online is False:
                    raise ValueError(f"Port:{p.Name} is not online")
        return result

    @abnormal_check()
    def wait_port_state(self, Ports=None, State=None, Interval=1, TimeOut=60):
        if Ports is None:
            Ports = [x for x in self.rom_manager.get_all_objects().values() if isinstance(x, Port)]
        if not isinstance(Ports, (list, set, tuple)):
            Ports = [Ports]
        if State is None:
            State = ['UP']
        if not isinstance(State, (list, set, tuple)):
            State = [State]
        ethMedias = [port.get_children('EthFiber')[0] if 'fiber' in port.PortCfgType.name.lower() else
                     port.get_children('EthCopper')[0] for port in Ports]
        TimeOut = int(TimeOut)
        while TimeOut:
            flag = True
            for media in ethMedias:
                media.get()
                if media.LinkStatus.name.lower() not in [x.lower() for x in State]:
                    flag = False
            if flag:
                break
            else:
                TimeOut -= 1
                time.sleep(int(Interval))
        else:
            self.logger.info(f'wait port state{State} timeout')
            return False
        return True

    @abnormal_check()
    def add_raw_stream(self, Ports, Names=None, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        if not isinstance(Names, list) and Names is not None:
            Names = [Names]
        result = []
        streamList = []
        if Names is not None:
            streamList.extend(StreamTemplate(upper=port, Name=name) for port, name in zip(Ports, Names))
        else:
            streamList.extend(StreamTemplate(upper=port) for port in Ports)
        for stream in streamList:
            for k, v in kwargs.items():
                if hasattr(stream, k):
                    setattr(stream, str(k), v)
            stream.get()
            cmd = ListHeaderNamesCommand(Stream=stream.handle, cl_instance=self.cl_instance)
            cmd.execute()
            headerNames = cmd.HeaderNames
            if headerNames:
                streamHeaderList = []
                headerObject = stream
                for i in headerNames:
                    dictHeader = MAP_HEADER_TRANSFORM[i.split("_")[0].lower()]
                    className = list(dictHeader.keys())[0]
                    headerObject = globals()[className](Upper=headerObject)
                    streamHeaderList.append(headerObject)
                map_stream_header.update({stream: streamHeaderList})
            result.append(stream)
        return result

    @abnormal_check()
    def get_stream_from_handle(self, Handle=None):
        result = EnumBase.FALSE.value
        streamList = [x for y in self.sys_entry.get_children('Port') for x in y.get_children('StreamTemplate')]
        if Handle is None:
            return streamList
        else:
            if isinstance(Handle, list):
                result = [x for x in streamList if x.handle in Handle]
            else:
                for stream in streamList:
                    if Handle == stream.habdle:
                        result = stream
                        break
        return result

    @abnormal_check()
    def add_binding_stream(self, Name=None, **kwargs):
        cmd = CreateBindingStreamCommand(cl_instance=self.cl_instance, **kwargs)
        cmd.execute()
        streamList = cmd.BindingStreams
        result = self.get_stream_from_handle(Handle=streamList)
        if Name is not None:
            name = []
            if Name is not list:
                name.append(Name)
            else:
                name = Name
            if len(name) != len(streamList):
                raise TesterException(type_=EnumErorrTester.ParameterLength)
            for k, v in zip(streamList, name):
                k.Name = v
        for stream in result:
            cmd = ListHeaderNamesCommand(Stream=stream.handle, cl_instance=self.cl_instance)
            cmd.execute()
            headerNames = cmd.HeaderNames
            if headerNames:
                streamHeaderList = []
                headerObject = stream
                for i in headerNames:
                    dictHeader = MAP_HEADER_TRANSFORM[i.split("_")[0].lower()]
                    className = list(dictHeader.keys())[0]
                    headerObject = globals()[className](Upper=headerObject)
                    streamHeaderList.append(headerObject)
                map_stream_header.update({stream: streamHeaderList})
        return result

    @abnormal_check()
    def edit_stream(self, Stream, **kwargs):
        result = EnumBase.TRUE.value
        if not isinstance(Stream, (list, set, tuple)):
            Stream = [Stream]
        if 'RxPorts' in list(kwargs.keys()):
            if not isinstance(kwargs['RxPorts'], (list, set, tuple)):
                rxPorts = [kwargs['RxPorts']]
            else:
                rxPorts = kwargs['RxPorts']
            for x in Stream:
                x.get_parent()
            ports = [x.upper for x in Stream]
            if set(ports).isdisjoint(set(rxPorts)):
                ExcludeTxPort = 'True'
            else:
                ExcludeTxPort = 'False'
            SelectRxPortCommand(StreamList=[x.handle for x in Stream], RxPortList=[x.handle for x in rxPorts],
                                Mode='ONE_TO_MANY', ExcludeTxPort='False', cl_instance=self.cl_instance).execute()
            kwargs.pop('RxPorts')
        for stream in Stream:
            for k, v in kwargs.items():
                if set_attr(stream, k, v) is False:
                    raise TesterException(type_=EnumErorrTester.AttributeError)
            stream.get()
        return result

    @abnormal_check()
    def create_stream_header(self, Stream, HeaderTypes, Index=None):
        if isinstance(Stream, list):
            Stream = Stream[0]
        typeTemp = []
        if not isinstance(HeaderTypes, list) and '.' in HeaderTypes:
            for x in HeaderTypes.split():
                for k, v in MAP_HEADER_TRANSFORM.items():
                    typeTemp.extend(k for vi in v.values() if vi == x)
            HeaderTypes = typeTemp
        if not isinstance(HeaderTypes, list):
            HeaderTypes = [HeaderTypes]
        HeaderTypes = [list(MAP_HEADER_TRANSFORM[x.lower()].values())[0] for x in HeaderTypes]
        if Index is None:
            renixCmd = CreateHeaderCommand(Stream=Stream.handle, HeaderTypes=HeaderTypes, cl_instance=self.cl_instance)
        elif str(Index) == '0':
            renixCmd = InsertHeaderCommand(Stream=Stream.handle, HeaderType=HeaderTypes, cl_instance=self.cl_instance)
        else:
            renixCmd = InsertHeaderCommand(Stream=Stream.handle, HeaderType=HeaderTypes, cl_instance=self.cl_instance, Index=Index)
        renixCmd.execute()
        self.set_stream_header_map(Streams=Stream)
        return map_stream_header[Stream]

    @abnormal_check()
    def get_port_form_stream(self, Streams):
        if not isinstance(Streams, (list, set, tuple)):
            Streams = [Streams]
        for x in Streams:
            x.get_parent()
        Ports = [x.upper for x in Streams]
        result = list(set(Ports))
        result.sort(key=Ports.index)
        return result

    @abnormal_check()
    def edit_port(self, Ports, Type=None, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        # 端口ARP设置
        arp_port_params = {
            'ArpTimeout': 'ArpTimeout',
            'ArpRate': 'Rate',
            'ArpRetryCount': 'RetryCount',
            'ArpSuppressDuplicateGateway': 'SuppressDuplicateGateway',
            'ArpDelayTime': 'DelayTime',
            'ArpUseLinkLocalForNd': 'UseLinkLocalForNd'
        }
        arp_port_configs = []
        for i in Ports:
            arp_port_configs.append(i.get_children('ArpPortConfig')[0])
        params = kwargs.copy()
        for k, v in params.items():
            if k in list(arp_port_params.keys()):
                for i in arp_port_configs:
                    setattr(i, str(arp_port_params[k]), v)
                kwargs.pop(k)
        if 'EnableLink' in kwargs.keys():
            ConfigPortsLinkCommand(PortList=[x.handle for x in Ports], EnableLink=kwargs['EnableLink'], cl_instance=self.cl_instance).execute()
            kwargs.pop('EnableLink')
        portList = [x.handle for x in Ports]
        params = kwargs.copy()
        for k, v in params.items():
            if hasattr(Port, k):
                for i in Ports:
                    setattr(i, str(k), v)
                kwargs.pop(k)
        if kwargs:
            renixCmd = ConfigurePortsCommand(PortList=portList, cl_instance=self.cl_instance, **kwargs)
            renixCmd.execute()
        for port in Ports:
            port.get()
        return True

    @abnormal_check()
    def select_rx_port(self, Streams, RxPorts, Mode=1, ExcludeTxPort=True):
        if not isinstance(Streams, list):
            Streams = [Streams]
        if not isinstance(RxPorts, list):
            RxPorts = [RxPorts]
        streamList = [x.handle for x in Streams]
        rxPortList = [x.handle for x in RxPorts]
        renixCmd = SelectRxPortCommand(StreamList=streamList, RxPortList=rxPortList, Mode=Mode,
                                       ExcludeTxPort=ExcludeTxPort, cl_instance=self.cl_instance)
        renixCmd.execute()
        return EnumBase.TRUE.value

    @abnormal_check()
    def start_stream(self, Type=None, Objects=None):
        if not isinstance(Objects, list):
            Objects = [Objects]
        if Type is None:
            renixCmd = StartAllStreamCommand(cl_instance=self.cl_instance)
        elif Type.lower() == "port":
            streamObjects = [z for y in [x.get_children('StreamTemplate') for x in Objects] for z in y]
            streamList = [x.handle for x in streamObjects]
            renixCmd = StartStreamCommand(StreamList=streamList, cl_instance=self.cl_instance)
        else:
            streamList = [x.handle for x in Objects]
            renixCmd = StartStreamCommand(StreamList=streamList, cl_instance=self.cl_instance)
        renixCmd.execute()
        self.__statictis = True
        return EnumBase.TRUE.value

    @abnormal_check()
    def stop_stream(self, Type=None, Objects=None):
        if not isinstance(Objects, list):
            Objects = [Objects]
        if Type is None:
            renixCmd = StopAllStreamCommand(cl_instance=self.cl_instance)
        elif Type.lower() == "port":
            streamObjects = [z for y in [x.get_children('StreamTemplate') for x in Objects] for z in y]
            streamList = [x.handle for x in streamObjects]
            renixCmd = StopStreamCommand(StreamList=streamList, cl_instance=self.cl_instance)
        else:
            streamList = [x.handle for x in Objects]
            renixCmd = StopStreamCommand(StreamList=streamList, cl_instance=self.cl_instance)
        renixCmd.execute()
        return EnumBase.TRUE.value

    @abnormal_check()
    def wait_stream_state(self, Stream=None, State=['ready'], TimeOut=60):
        if Stream is None:
            Stream = [x for x in self.rom_manager.get_all_objects().values() if isinstance(x, StreamTemplate)]
        if not isinstance(Stream, (list, set, tuple)):
            Stream = [Stream]
        if not isinstance(State, (list, set, tuple)):
            State = [State]
        TimeOut = int(TimeOut)
        while TimeOut:
            flag = True
            for s in Stream:
                s.get('State')
                if s.State.name.lower() not in [x.lower() for x in State]:
                    flag = False
            if flag:
                break
            else:
                TimeOut -= 1
                time.sleep(1)
        else:
            self.logger.info(f'wait stream state{State} timeout')
            return False
        return True

    @abnormal_check()
    def clear_result(self, All: bool = True, Objects=None):
        if All:
            pageResultViewList = [x.handle for x in self.sys_entry.get_children('PageResultView')]
            resultViewList = [x.handle for x in self.sys_entry.get_children('ResultView')]
            renixCmd = ClearResultCommand(ResultViewHandles=pageResultViewList + resultViewList, cl_instance=self.cl_instance)
        else:
            pageResultViewList = [x.handle for x in Objects]
            renixCmd = ClearResultCommand(ResultViewHandles=pageResultViewList, cl_instance=self.cl_instance)
        renixCmd.execute()
        return EnumBase.TRUE.value

    @abnormal_check()
    def del_stream(self, Ports=None, Streams=None):
        if Ports is None and Streams is None:
            streams = [x for x in self.rom_manager.get_all_objects().values() if isinstance(x, StreamTemplate)]
        elif Ports is not None and Streams is None:
            if not isinstance(Ports, (list, set, tuple)):
                Ports = [Ports]
            streams = []
            for port in Ports:
                streams += port.get_children('StreamTemplate')
        elif Ports is None:
            streams = Streams if isinstance(Streams, (list, set, tuple)) else [Streams]
        else:
            return False
        for stream in streams:
            for hander in map_stream_header[stream]:
                del hander
            map_stream_header.pop(stream)
            stream.delete()
        return True

    @abnormal_check()
    def del_port(self, Ports=None):
        if Ports is None:
            ports = [x for x in self.rom_manager.get_all_objects().values() if isinstance(x, Port)]
        else:
            ports = Ports if isinstance(Ports, (list, set, tuple)) else [Ports]
        streams = []
        for port in ports:
            ReleasePortCommand(LocationList=port.Location, ForceRelease=True, cl_instance=self.cl_instance).execute()
            streams += port.get_children('StreamTemplate')
        for stream in streams:
            for hander in map_stream_header[stream]:
                del hander
                map_stream_header.pop(stream)
            if stream in list(map_stream_imix.keys()):
                del map_stream_imix[stream]
                map_stream_imix.pop(stream)
        for port in ports:
            port.delete()
        return True

    @abnormal_check()
    def unsubscribe_result(self):
        resultViews = self.sys_entry.get_children('ResultView')
        resultViews = resultViews + self.sys_entry.get_children('PageResultView')
        resultViewList = [x.handle for x in resultViews]
        if resultViewList:
            UnsubscribeResultCommand(ResultViewHandles=resultViewList, cl_instance=self.cl_instance).execute()
        return True

    @abnormal_check()
    def subscribe_result(self, Types, ResultViewType=1):
        # TODO 适配RTSM
        # resultViews = self.sys_entry.get_children('ResultView')
        # resultViews = resultViews + self.sys_entry.get_children('PageResultView')
        # resultViewList = [x.handle for x in resultViews]
        # if resultViewList:
        #    UnsubscribeResultCommand(ResultViewHandles=resultViewList, cl_instance=self.cl_instance).execute()
        if Types is None:
            self.__subscribe = [
                'PortStats',
                'PortAvgLatencyStats',
                'StreamStats',
                'StreamTxStats',
                'StreamRxStats',
                'StreamBlockStats',
                'StreamBlockTxStats',
                'StreamBlockRxStats',
            ]
        else:
            self.__subscribe = Types
        for key in STATISTIC:
            if self.__subscribe.count(key) != 0:
                if ResultViewType != 1:
                    resultView = ResultView(upper=self.sys_entry, DataClassName=key)
                    ResultQuery(upper=resultView)
                    resultViewHandle = resultView.handle
                else:
                    renixCmd = CreateResultViewCommand(ResultViewType=ResultViewType, DataClassName=key, cl_instance=self.cl_instance)
                    renixCmd.execute()
                    resultViewHandle = renixCmd.ResultViewHandle
                SubscribeResultCommand(ResultViewHandles=resultViewHandle, cl_instance=self.cl_instance).execute()
        for key in ONESHOT_STATISTIC:
            if self.__subscribe.count(key) != 0:
                resultView = ResultView(upper=self.sys_entry, DataClassName=key)
                ResultQuery(upper=resultView)
                SubscribeResultCommand(ResultViewHandles=resultView.handle, cl_instance=self.cl_instance).execute()
        return EnumBase.TRUE.value

    @abnormal_check()
    def get_stream_statistic(self, Stream=None, StreamID=None, StaItems=None, Mode=True):
        if Stream is None:
            streamBlockID = None
        elif isinstance(Stream, (list, set, tuple)):
            streamBlockID = [x.Name for x in Stream]
        else:
            streamBlockID = Stream.Name
        if self.mode.lower() == 'db' and StaItems is None:
            StaItems = [
                'StreamBlockID',
                'StreamID',
                'TxPortID',
                'RxPortID',
                'TxStreamFrames',
                'RxStreamFrames',
                'TxFrameRate',
                'RxFrameRate',
                'TxL1Rate',
                'RxL1Rate',
                'RealtimeLossFrames',
                'RealtimeLossRate',
                'ResumeTime',
                'TxUtil',
                'RxUtil',
                'TxByteRate',
                'RxByteRate',
                'TxBitRate',
                'RxBitRate',
                'RxPRBSErrorFrames',
                'RxDuplicateFrames',
                'RxInOrderFrames',
                'ReOrderFrames',
                'TxTotalBytes',
                'RxTotalBytes',
                'RxLateFrames',
                'RxInSequenceFrames',
                'RxOutofSequenceFrames',
                'RxMinInterArrivalTime',
                'RxMaxInterArrivalTime',
                'RxAvgInterArrivalTime',
                'RxShortTermAvgInterArrivalTime',
                'RxIPv4ChecksumErrorFrames',
                'RxPRBSErrorBits',
                'RxPRBSFillBytes',
                'RxFCSErrorFrames',
                'RxFCSErrorFrameRate',
                'RxTCPChecksumErrorFrames',
                'RxPayloadErrorFrames',
                'RxSequenceErrorFrames',
                'RxIPLengthErrorFrames',
                'MinLatency',
                'MaxLatency',
                'AvaLatency',
                'ShortTermAvgLatency',
                'MinJitter',
                'MaxJitter',
                'AvaJitter',
                'ShortTermAvgJitter',
            ]
        result = self._get_statictis(Statictis="StreamStats",
                                     Idx={'StreamBlockID': streamBlockID, 'StreamID': StreamID},
                                     StaItems=StaItems, Mode=Mode)
        return result

    @abnormal_check()
    def get_result_statistic(self, Stats, Name, Item=None):
        '''
        get statistic of specified result stats.
        :param stats:
            'PortStats'
            'PortAvgLatencyStats'
            'StreamStats'
            'StreamTxStats'
            'StreamRxStats'
            'StreamBlockStats'
            'StreamBlockTxStats'
            'StreamBlockRxStats'
        :param Name:
            PortID for port stats, e.g.'Port_1'
            StreamBlockID for stream block stats, e.g.:'StreamTemplate_1'
            StreamBlockID and StreamID for stream stats, e.g.'[StreamTemplate_1, 1]'
        :param Item:
            the attribute of result object
        :return:
            result.__dict__ when item is None
            or
            result.Item
        '''
        exist_result_views = self.sys_entry.get_children('ResultView')
        result_view = [x for x in exist_result_views if x.DataClassName == Stats][0]
        result_query = result_view.get_children('ResultQuery')[0]
        results = result_query.get_children()
        if Stats.find('Port') >= 0:
            result = [x for x in results if x.PortID == Name][0]
        elif Stats.find('StreamBlock') >= 0:
            result = [x for x in results if x.StreamBlockID == Name][0]
        else:
            stream_blocks = [x for x in results if x.StreamBlockID == Name[0]]
            result = [y for y in stream_blocks if y.StreamID == Name[1]][0]

        return_value = ""
        if Item is None:
            return_value = result.__dict__
        elif hasattr(result, Item):
            return_value = getattr(result, str(Item))
        else:
            print(result.handle, 'not support the attribute:', Item)
            return
        return return_value

    @abnormal_check()
    def get_stream_header(self, Stream):
        if Stream not in map_stream_header:
            cmd = ListHeaderNamesCommand(Stream=Stream.handle, cl_instance=self.cl_instance)
            cmd.execute()
            headerNames = cmd.HeaderNames
            if headerNames:
                streamHeaderList = []
                headerObject = Stream
                for i in headerNames:
                    dictHeader = MAP_HEADER_TRANSFORM[i.split("_")[0].lower()].keys()
                    className = list(dictHeader)[0]
                    headerObject = globals()[className](Upper=headerObject)
                    streamHeaderList.append(headerObject)
                map_stream_header.update({Stream: streamHeaderList})
        return map_stream_header[Stream]

    # ------------------------- GATHER header -------------------------------------
    @abnormal_check()
    def edit_header_ethernet(self, Stream, Level: int = 0, DestMacAdd=None, SourceMacAdd=None, ProtocolType=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ethernetii"]
        header = headerList[Level]
        if DestMacAdd is not None:
            header.destMacAdd = DestMacAdd
            result.update({'DestMacAdd': "destMacAdd"})
        if SourceMacAdd is not None:
            header.sourceMacAdd = SourceMacAdd
            result.update({'SourceMacAdd': "sourceMacAdd"})
        if ProtocolType is not None:
            header.protocolType = ProtocolType
            result.update({'ProtocolType': "protocolType"})
        return result if result else False

    @abnormal_check()
    def edit_header_raw_8023(self, Stream, Level=0, DestMacAdd=None, SourceMacAdd=None, PayloadLength=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "raw"]
        header = headerList[Level]
        if DestMacAdd is not None:
            header.destMacAdd = DestMacAdd
            result.update({'DestMacAdd': "destMacAdd"})
        if SourceMacAdd is not None:
            header.sourceMacAdd = SourceMacAdd
            result.update({'SourceMacAdd': "sourceMacAdd"})
        if PayloadLength is not None:
            header.payloadLength = PayloadLength
            result.update({'PayloadLength': "length"})
        return result if result else False

    @abnormal_check()
    def edit_header_8023(self, Stream, Level=0,
                         DestMacAdd=None,
                         SourceMacAdd=None,
                         PayloadLength=None,
                         Dsap=None,
                         Ssap=None,
                         Control=None,
                         Oui=None,
                         Type=None
                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "8023"]
        header = headerList[Level]
        if DestMacAdd is not None:
            header.destMacAdd = DestMacAdd
            result.update({'DestMacAdd': "destMacAdd"})
        if SourceMacAdd is not None:
            header.sourceMacAdd = SourceMacAdd
            result.update({'SourceMacAdd': "sourceMacAdd"})
        if PayloadLength is not None:
            header.payloadLength = PayloadLength
            result.update({'PayloadLength': "length"})
        if Dsap is not None:
            header.dsap = Dsap
            result.update({'Dsap': "llcHeaderIns.dsap"})
        if Ssap is not None:
            header.ssap = Ssap
            result.update({'Ssap': "llcHeaderIns.ssap"})
        if Control is not None:
            header.control = Control
            result.update({'Control': "llcHeaderIns.control"})
        if Oui is not None:
            header.oui = Oui
            result.update({'Oui': "snapIns.oui"})
        if Type is not None:
            header.type = Type
            result.update({'Type': "snapIns.type"})
        return result if result else False

    @abnormal_check()
    def edit_header_llc(self, Stream, Level=0,
                        Dsap=None,
                        Ssap=None,
                        Control=None,
                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "logiclinkcontrol"]
        header = headerList[Level]
        if Dsap is not None:
            header.dsap = Dsap
            result.update({'Dsap': "dsap"})
        if Ssap is not None:
            header.ssap = Ssap
            result.update({'Ssap': "ssap"})
        if Control is not None:
            header.control = Control
            result.update({'Control': "control"})
        return result if result else False

    @abnormal_check()
    def edit_header_vlan(self, Stream, Level=0, ID=None, Priority=None, CFI=None, Protocol=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "vlan"]
        header = headerList[Level]
        if ID is not None:
            header.id = ID
            result.update({'ID': "id"})
        if Priority is not None:
            header.priority = Priority
            result.update({'Priority': "priority"})
        if CFI is not None:
            header.cfi = CFI
            result.update({'CFI': "cfi"})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': "protocol"})
        return result if result else False

    @abnormal_check()
    def edit_header_ipv4(self, Stream, Level: int = 0,
                         Version=None,
                         HeadLen=None,
                         TotalLength=None,
                         Flags=None,
                         ID=None,
                         Offset=None,
                         TTL=None,
                         Protocol=None,
                         Checksum=None,
                         Source=None,
                         Destination=None,
                         Padding=None,
                         Gateway=None,
                         TosPrecedence=None,
                         TosDelay=None,
                         TosThroughput=None,
                         TosReliability=None,
                         TosMonetaryCost=None,
                         TosReserved=None,
                         DiffserveCodepointPrecedence=None,
                         DiffserveClassSelectorPrecedence=None,
                         DiffserveClassSelectorDrop=None,
                         DiffserveClassSelectorUndefine=None,
                         DiffserveEcn=None,
                         TosByte=None,
                         HeaderOption=None,
                         **kwargs
                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ipv4"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if HeadLen is not None:
            header.headLen = HeadLen
            result.update({'HeadLen': 'headLen'})
        if TotalLength is not None:
            header.totalLength = TotalLength
            result.update({'TotalLength': 'totalLength'})
        if ID is not None:
            header.id = ID
            result.update({'ID': 'id'})
        if Flags is not None:
            header.flags = Flags
            result.update({'Flags': 'flags'})
        if Offset is not None:
            header.offset = Offset
            result.update({'Offset': 'offset'})
        if TTL is not None:
            header.ttl = TTL
            result.update({'TTL': 'ttl'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Source is not None:
            header.source = Source
            result.update({'Source': 'source'})
        if Destination is not None:
            header.destination = Destination
            result.update({'Destination': 'destination'})
        if Padding is not None:
            header.padding = Padding
            result.update({'Padding': 'padding'})
        if Gateway is not None:
            header.gateway = Gateway
            result.update({'Gateway': 'gateway'})
        if TosPrecedence is not None:
            header.tosPrecedence = TosPrecedence
            result.update({'TosPrecedence': 'tos.tos.precedence'})
        if 'Tos' in kwargs:
            header.tos = kwargs['Tos']
            result.update({'Tos': 'tos.tos'})
            kwargs.pop('Tos')
        if TosDelay is not None:
            header.tosDelay = TosDelay
            result.update({'TosDelay': 'tos.tos.delay'})
        if TosThroughput is not None:
            header.tosThroughput = TosThroughput
            result.update({'TosThroughput': 'tos.tos.throughput'})
        if TosReliability is not None:
            header.tosReliability = TosReliability
            result.update({'TosReliability': 'tos.tos.reliability'})
        if TosMonetaryCost is not None:
            header.tosMonetaryCost = TosMonetaryCost
            result.update({'TosMonetaryCost': 'tos.tos.monetaryCost'})
        if TosReserved is not None:
            header.tosReserved = TosReserved
            result.update({'TosReserved': 'tos.tos.reserved'})
        if DiffserveCodepointPrecedence is not None:
            header.diffserveCodepointPrecedence = DiffserveCodepointPrecedence
            result.update({'DiffserveCodepointPrecedence': 'tos.diffServe.dscp.codePoint.precedence'})
        if DiffserveClassSelectorPrecedence is not None:
            header.diffserveClassSelectorPrecedence = DiffserveClassSelectorPrecedence
            result.update({'DiffserveClassSelectorPrecedence': 'tos.diffServe.dscp.classSelector.precedence'})
        if DiffserveClassSelectorDrop is not None:
            header.diffserveClassSelectorDrop = DiffserveClassSelectorDrop
            result.update({'DiffserveClassSelectorDrop': 'tos.diffServe.dscp.classSelector.drop'})
        if DiffserveClassSelectorUndefine is not None:
            header.diffserveClassSelectorUndefine = DiffserveClassSelectorUndefine
            result.update({'DiffserveClassSelectorUndefine': 'tos.diffServe.dscp.classSelector.undefine'})
        if DiffserveEcn is not None:
            header.diffserveEcn = DiffserveEcn
            result.update({'DiffserveEcn': 'tos.diffServe.ecnSetting'})
        if TosByte is not None:
            header.tosByte = TosByte
            result.update({'TosByte': 'tos.tosByte.data'})
        if HeaderOption is not None:
            result.update({'HeaderOption': header.insert_header_option(Types=HeaderOption)})
        return result if result else False

    @abnormal_check()
    def edit_header_ipv4_option(self, Stream, Option, Level=0, Index=0, Header='ipv4', **kwargs):
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == Header]
        header = headerList[Level]
        result = header.edit_header_option(Index=Index, Option=Option, **kwargs)
        return result if result else False

    @abnormal_check()
    def edit_header_ipv6(self, Stream, Level: int = 0,
                         Version=None,
                         TrafficClass=None,
                         FlowLabel=None,
                         PayloadLength=None,
                         NextHeader=None,
                         HopLimit=None,
                         Source=None,
                         Destination=None,
                         Gateway=None):
        Level = int(Level)
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ipv6"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if TrafficClass is not None:
            header.trafficClass = TrafficClass
            result.update({'TrafficClass': 'trafficClass'})
        if FlowLabel is not None:
            header.FlowLabel = FlowLabel
            result.update({'FlowLabel': 'FlowLabel'})
        if PayloadLength is not None:
            header.payloadLength = PayloadLength
            result.update({'PayloadLength': 'payloadLength'})
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if HopLimit is not None:
            header.hopLimit = HopLimit
            result.update({'HopLimit': 'hopLimit'})
        if Source is not None:
            header.source = Source
            result.update({'Source': 'source'})
        if Destination is not None:
            header.destination = Destination
            result.update({'Destination': 'destination'})
        if Gateway is not None:
            header.gateway = Gateway
            result.update({'Gateway': 'gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_tcp(self, Stream, Level: int = 0,
                        SourcePort=None,
                        DestPort=None,
                        SeqNum=None,
                        AckNum=None,
                        DataOffset=None,
                        Reserved=None,
                        Flags=None,
                        WindowSize=None,
                        Checksum=None,
                        UrgentPointer=None,
                        Option=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "tcp"]
        header = headerList[Level]
        if SourcePort is not None:
            header.sourcePort = SourcePort
            result.update({'SourcePort': 'sourcePort'})
        if DestPort is not None:
            header.destPort = DestPort
            result.update({'DestPort': 'destPort'})
        if SeqNum is not None:
            header.seqNum = SeqNum
            result.update({'SeqNum': 'seqNum'})
        if AckNum is not None:
            header.ackNum = AckNum
            result.update({'AckNum': 'ackNum'})
        if DataOffset is not None:
            header.dataOffset = DataOffset
            result.update({'DataOffset': 'dataOffset'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if Flags is not None:
            header.flags = Flags
            result.update({'Flags': 'flags'})
        if WindowSize is not None:
            header.windowSize = WindowSize
            result.update({'WindowSize': 'windowSize'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if UrgentPointer is not None:
            header.urgentPointer = UrgentPointer
            result.update({'UrgentPointer': 'urgentPointer'})
        if Option is not None:
            header.option = Option
            result.update({'Option': 'option'})
        return result if result else False

    @abnormal_check()
    def edit_header_udp(self, Stream, Level: int = 0,
                        SourcePort=None,
                        DestPort=None,
                        Length=None,
                        Checksum=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "udp"]
        header = headerList[Level]
        if SourcePort is not None:
            header.sourcePort = SourcePort
            result.update({'SourcePort': 'sourcePort'})
        if DestPort is not None:
            header.destPort = DestPort
            result.update({'DestPort': 'destPort'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        return result if result else False

    @abnormal_check()
    def edit_header_arp(self, Stream, Level: int = 0,
                        HardwareType=None,
                        ProtocolType=None,
                        HardwareSize=None,
                        ProtocolSize=None,
                        Opcode=None,
                        SendMac=None,
                        SendIpv4=None,
                        TargetMac=None,
                        TargetIpv4=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "arp"]
        header = headerList[Level]
        if HardwareType is not None:
            header.hardwareType = HardwareType
            result.update({'HardwareType': 'hardwareType'})
        if ProtocolType is not None:
            header.protocolType = ProtocolType
            result.update({'ProtocolType': 'protocolType'})
        if HardwareSize is not None:
            header.hardwareSize = HardwareSize
            result.update({'HardwareSize': 'hardwareSize'})
        if ProtocolSize is not None:
            header.protocolSize = ProtocolSize
            result.update({'ProtocolSize': 'protocolSize'})
        if Opcode is not None:
            header.opcode = Opcode
            result.update({'Opcode': 'opcode'})
        if SendMac is not None:
            header.sendMac = SendMac
            result.update({'SendMac': 'sendMac'})
        if SendIpv4 is not None:
            header.sendIpv4 = SendIpv4
            result.update({'SendIpv4': 'sendIpv4'})
        if TargetMac is not None:
            header.targetMac = TargetMac
            result.update({'TargetMac': 'targetMac'})
        if TargetIpv4 is not None:
            header.targetIpv4 = TargetIpv4
            result.update({'TargetIpv4': 'targetIpv4'})
        return result if result else False

    @abnormal_check()
    def edit_header_l2tpv2_data(self, Stream, Level: int = 0,
                                Type=None,
                                UseLength=None,
                                Reserved1=None,
                                UseSequence=None,
                                Reserved2=None,
                                UseOffset=None,
                                UsePriority=None,
                                Reserved3=None,
                                Version=None,
                                LengthOption=None,
                                TunnelId=None,
                                SessionId=None,
                                SeqNum=None,
                                OffsetPadding=None
                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "l2tpv2data"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if UseLength is not None:
            header.useLength = UseLength
            result.update({'UseLength': 'useLength'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if UseSequence is not None:
            header.useSequence = UseSequence
            result.update({'UseSequence': 'useSequence'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        if UseOffset is not None:
            header.useOffset = UseOffset
            result.update({'UseOffset': 'useOffset'})
        if UsePriority is not None:
            header.usePriority = UsePriority
            result.update({'UsePriority': 'usePriority'})
        if Reserved3 is not None:
            header.reserved3 = Reserved3
            result.update({'Reserved3': 'reserved3'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if LengthOption is not None:
            header.lengthOption = LengthOption
            result.update({'LengthOption': 'lengthOption.length_0.value'})
        if TunnelId is not None:
            header.tunnelId = TunnelId
            result.update({'TunnelId': 'tunnelId'})
        if SessionId is not None:
            header.sessionId = SessionId
            result.update({'SessionId': 'sessionId'})
        if SeqNum is not None:
            header.seqNum = SeqNum
            result.update({'SeqNum': 'seqNum'})
        if OffsetPadding is not None:
            header.offsetPadding = OffsetPadding
        return result

    @abnormal_check()
    def edit_header_l2tpv2_data_option(self, Stream, Level=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'l2tpv2data']
        header = headerList[Level]
        result.update(header.editHeaderOptions(**kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_l2tpv2_control(self, Stream, Level: int = 0,
                                   Type=None,
                                   UseLength=None,
                                   Reserved1=None,
                                   UseSequence=None,
                                   Reserved2=None,
                                   UseOffset=None,
                                   UsePriority=None,
                                   Reserved3=None,
                                   Version=None,
                                   Length=None,
                                   TunnelId=None,
                                   SessionId=None,
                                   Ns=None,
                                   Nr=None,
                                   OptionHeaders=None
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "l2tpv2control"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if UseLength is not None:
            header.useLength = UseLength
            result.update({'UseLength': 'useLength'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if UseSequence is not None:
            header.useSequence = UseSequence
            result.update({'UseSequence': 'useSequence'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        if UseOffset is not None:
            header.useOffset = UseOffset
            result.update({'UseOffset': 'useOffset'})
        if UsePriority is not None:
            header.usePriority = UsePriority
            result.update({'UsePriority': 'usePriority'})
        if Reserved3 is not None:
            header.reserved3 = Reserved3
            result.update({'Reserved3': 'reserved3'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if TunnelId is not None:
            header.tunnelId = TunnelId
            result.update({'TunnelId': 'tunnelId'})
        if SessionId is not None:
            header.sessionId = SessionId
            result.update({'SessionId': 'sessionId'})
        if Ns is not None:
            header.ns = Ns
            result.update({'Ns': 'ns'})
        if Nr is not None:
            header.nr = Nr
            result.update({'Nr': 'nr'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_l2tpv2_control_option(self, Stream, Types, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'l2tpv2control']
        header = headerList[Level]
        if Types.lower() == 'generaltlv':
            result.update(header.edit_general_tlv_header(Index=Index, **kwargs))
        elif Types.lower() == 'messagetype':
            result.update(header.edit_message_type_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'resultcode':
            result.update(header.edit_result_code_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'protocolversion':
            result.update(header.edit_protocol_version_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'framingcapabilities':
            result.update(header.edit_framing_capabilities_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'bearercapabilities':
            result.update(header.edit_bearer_capabilities_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'tiebreaker':
            result.update(header.edit_tie_breaker_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'firmwarerevision':
            result.update(header.edit_firmware_revision_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'assignedtunnelid':
            result.update(header.edit_assigned_tunnelid_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'receivewindowsize':
            result.update(header.edit_receive_windowsize_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'assignedsessionid':
            result.update(header.edit_assigned_sessionid_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'response':
            result.update(header.edit_response_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'callserialnumber':
            result.update(header.edit_call_serialnumber_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'minimumbps':
            result.update(header.edit_minimum_bps_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'maximumbps':
            result.update(header.edit_maximum_bpsavpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'bearertype':
            result.update(header.edit_bearer_type_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'framingtype':
            result.update(header.edit_framing_type_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'txconnectspeed':
            result.update(header.edit_tx_connectspeed_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'rxconnectspeed':
            result.update(header.edit_rx_connectspeed_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'physicalchannelid':
            result.update(header.edit_physical_channelid_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'proxyauthentype':
            result.update(header.edit_proxy_authentype_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'proxyauthenid':
            result.update(header.edit_proxy_authenid_avpoption_header(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_l2tpv3_control_over_ip(self, Stream, Level: int = 0,
                                           SessionId=None,
                                           Type=None,
                                           UseLength=None,
                                           Reserved1=None,
                                           UseSequence=None,
                                           Reserved2=None,
                                           Version=None,
                                           ExcludeSessionLength=None,
                                           ControlId=None,
                                           SequenceNumberNs=None,
                                           SequenceNumberNr=None,
                                           OptionHeaders=None
                                           ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "l2tpv3controloverip"]
        header = headerList[Level]
        if SessionId is not None:
            header.sessionId = SessionId
            result.update({'SessionId': 'sessionId'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if UseLength is not None:
            header.useLength = UseLength
            result.update({'UseLength': 'useLength'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if UseSequence is not None:
            header.useSequence = UseSequence
            result.update({'UseSequence': 'useSequence'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if ExcludeSessionLength is not None:
            header.excludeSessionLength = ExcludeSessionLength
            result.update({'ExcludeSessionLength': 'lengthOption.excludeSessionLength_0.value'})
        if ControlId is not None:
            header.controlId = ControlId
            result.update({'ControlId': 'controlId'})
        if SequenceNumberNs is not None:
            header.sequenceNumberNs = SequenceNumberNs
            result.update({'SequenceNumberNs': 'seqNum.sequenceNumber_0.ns'})
        if SequenceNumberNr is not None:
            header.sequenceNumberNr = SequenceNumberNr
            result.update({'SequenceNumberNr': 'seqNum.sequenceNumber_0.nr'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_l2tpv3_control_over_udp(self, Stream, Level: int = 0,
                                            Type=None,
                                            UseLength=None,
                                            Reserved1=None,
                                            UseSequence=None,
                                            Reserved2=None,
                                            Version=None,
                                            Length=None,
                                            ControlId=None,
                                            SequenceNumberNs=None,
                                            SequenceNumberNr=None,
                                            OptionHeaders=None
                                            ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "l2tpv3controloverudp"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if UseLength is not None:
            header.useLength = UseLength
            result.update({'UseLength': 'useLength'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if UseSequence is not None:
            header.useSequence = UseSequence
            result.update({'UseSequence': 'useSequence'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'lengthOption.length_0.value'})
        if ControlId is not None:
            header.controlId = ControlId
            result.update({'ControlId': 'controlId'})
        if SequenceNumberNs is not None:
            header.sequenceNumberNs = SequenceNumberNs
            result.update({'SequenceNumberNs': 'seqNum.sequenceNumber_0.ns'})
        if SequenceNumberNr is not None:
            header.sequenceNumberNr = SequenceNumberNr
            result.update({'SequenceNumberNr': 'seqNum.sequenceNumber_0.nr'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_l2tpv3_control_option(self, Stream, Types, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['l2tpv3controloverudp', 'l2tpv3controloverip']]
        header = headerList[Level]
        if Types.lower() == 'generaltlv':
            result.update(header.edit_general_tlv_header(Index=Index, **kwargs))
        elif Types.lower() == 'messagetype':
            result.update(header.edit_message_type_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'resultcode':
            result.update(header.edit_result_code_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'tiebreaker':
            result.update(header.edit_tie_breaker_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'receivewindowsize':
            result.update(header.edit_receive_windowsize_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'callserialnumber':
            result.update(header.edit_call_serialnumber_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'physicalchannelid':
            result.update(header.edit_physical_channelid_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'circuiterror':
            result.update(header.edit_circuit_error_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'routeid':
            result.update(header.edit_routeid_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'assignedconnection':
            result.update(header.edit_assigned_connection_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'localsessionid':
            result.update(header.edit_local_sessionid_header(Index=Index, **kwargs))
        elif Types.lower() == 'remotesessionid':
            result.update(header.edit_remote_sessionid_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'assignedcookie':
            result.update(header.edit_assigned_cookie_header(Index=Index, **kwargs))
        elif Types.lower() == 'pwtype':
            result.update(header.edit_pw_type_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'l2specificsub':
            result.update(header.edit_l2_specificsub_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'datasequencing':
            result.update(header.edit_data_sequencing_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'txconnectspeed':
            result.update(header.edit_tx_connectspeed_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'rxconnectspeed':
            result.update(header.edit_rx_connectspeed_avpoption_header(Index=Index, **kwargs))
        elif Types.lower() == 'circuitstatus':
            result.update(header.edit_circuit_status_avpoption_header(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_l2tpv3_data_over_ip(self, Stream, Level: int = 0,
                                        SessionId=None,
                                        Cookie4Byte=None,
                                        Cookie8Byte=None,
                                        L2specificsublayer=None,
                                        Atmspecificsublayer=None,
                                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "l2tpv3dataoverip"]
        header = headerList[Level]
        if SessionId is not None:
            header.sessionId = SessionId
            result.update({'SessionId': 'sessionId'})
        if Cookie4Byte is not None:
            header.cookie4Byte = Cookie4Byte
            result.update({'Cookie4Byte': 'cookieData.cookie_0.cookie4Byte.value'})
        if Cookie8Byte is not None:
            header.cookie8Byte = Cookie8Byte
            result.update({'Cookie8Byte': 'cookieData.cookie_0.cookie8Byte.value'})
        if L2specificsublayer is not None:
            header.l2specificsublayer = L2specificsublayer
        if Atmspecificsublayer is not None:
            header.atmspecificsublayer = Atmspecificsublayer
        return result

    @abnormal_check()
    def edit_header_l2tpv3_data_over_udp(self, Stream, Level: int = 0,
                                         Type=None,
                                         Reserved1=None,
                                         Version=None,
                                         Reserved2=None,
                                         SessionId=None,
                                         Cookie4Byte=None,
                                         Cookie8Byte=None,
                                         L2specificsublayer=None,
                                         Atmspecificsublayer=None,
                                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "l2tpv3dataoverudp"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        if SessionId is not None:
            header.sessionId = SessionId
            result.update({'SessionId': 'sessionId'})
        if Cookie4Byte is not None:
            header.cookie4Byte = Cookie4Byte
            result.update({'Cookie4Byte': 'cookieData.cookie_0.cookie4Byte.value'})
        if Cookie8Byte is not None:
            header.cookie8Byte = Cookie8Byte
            result.update({'Cookie8Byte': 'cookieData.cookie_0.cookie8Byte.value'})
        if L2specificsublayer is not None:
            header.l2specificsublayer = L2specificsublayer
        if Atmspecificsublayer is not None:
            header.atmspecificsublayer = Atmspecificsublayer
        return result

    @abnormal_check()
    def edit_header_l2tpv3_data_sublayer(self, Stream, Type, Level=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['l2tpv3dataoverip', 'l2tpv3dataoverudp']]
        header = headerList[Level]
        result.update(header.edit_specific_sublayer(Type=Type, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_dhcpv4_server(self, Stream, Level: int = 0,
                                  MessageType=None,
                                  HardwareType=None,
                                  HaddrLen=None,
                                  Hops=None,
                                  Xid=None,
                                  Elapsed=None,
                                  Bootpflags=None,
                                  ClientAddr=None,
                                  YourAddr=None,
                                  NextServerAddr=None,
                                  RelayAgentAddr=None,
                                  ClientMac=None,
                                  ClientHWPad=None,
                                  ServerHostName=None,
                                  BootFileName=None,
                                  MagicCookie=None,
                                  Padding=None,
                                  OptionHeaders=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "dhcpv4server"]
        header = headerList[Level]
        if MessageType is not None:
            header.messageType = MessageType
            result.update({'MessageType': 'messageType'})
        if HardwareType is not None:
            header.hardwareType = HardwareType
            result.update({'HardwareType': 'hardwareType'})
        if HaddrLen is not None:
            header.haddrLen = HaddrLen
            result.update({'HaddrLen': 'haddrLen'})
        if Hops is not None:
            header.hops = Hops
            result.update({'Hops': 'hops'})
        if Xid is not None:
            header.xid = Xid
            result.update({'Xid': 'xid'})
        if Elapsed is not None:
            header.elapsed = Elapsed
            result.update({'Elapsed': 'elapsed'})
        if Bootpflags is not None:
            header.bootpflags = Bootpflags
            result.update({'Bootpflags': 'bootpflags'})
        if ClientAddr is not None:
            header.clientAddr = ClientAddr
            result.update({'ClientAddr': 'clientAddr'})
        if YourAddr is not None:
            header.yourAddr = YourAddr
            result.update({'YourAddr': 'yourAddr'})
        if NextServerAddr is not None:
            header.nextServerAddr = NextServerAddr
            result.update({'NextServerAddr': 'nextServerAddr'})
        if RelayAgentAddr is not None:
            header.relayAgentAddr = RelayAgentAddr
            result.update({'RelayAgentAddr': 'relayAgentAddr'})
        if ClientMac is not None:
            header.clientMac = ClientMac
            result.update({'ClientMac': 'clientMac'})
        if ClientHWPad is not None:
            header.clientHWPad = ClientHWPad
            result.update({'ClientHWPad': 'clientHWPad'})
        if ServerHostName is not None:
            header.serverHostName = ServerHostName
            result.update({'ServerHostName': 'serverHostName'})
        if BootFileName is not None:
            header.bootFileName = BootFileName
            result.update({'BootFileName': 'bootFileName'})
        if MagicCookie is not None:
            header.magicCookie = MagicCookie
            result.update({'MagicCookie': 'magicCookie'})
        if Padding is not None:
            header.padding = Padding
            result.update({'Padding': 'padding'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_dhcpv4_client(self, Stream, Level: int = 0,
                                  MessageType=None,
                                  HardwareType=None,
                                  HaddrLen=None,
                                  Hops=None,
                                  Xid=None,
                                  Elapsed=None,
                                  Bootpflags=None,
                                  ClientAddr=None,
                                  YourAddr=None,
                                  NextServerAddr=None,
                                  RelayAgentAddr=None,
                                  ClientMac=None,
                                  ClientHWPad=None,
                                  ServerHostName=None,
                                  BootFileName=None,
                                  MagicCookie=None,
                                  Padding=None,
                                  OptionHeaders=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "dhcpv4client"]
        header = headerList[Level]
        if MessageType is not None:
            header.messageType = MessageType
            result.update({'MessageType': 'messageType'})
        if HardwareType is not None:
            header.hardwareType = HardwareType
            result.update({'HardwareType': 'hardwareType'})
        if HaddrLen is not None:
            header.haddrLen = HaddrLen
            result.update({'HaddrLen': 'haddrLen'})
        if Hops is not None:
            header.hops = Hops
            result.update({'Hops': 'hops'})
        if Xid is not None:
            header.xid = Xid
            result.update({'Xid': 'xid'})
        if Elapsed is not None:
            header.elapsed = Elapsed
            result.update({'Elapsed': 'elapsed'})
        if Bootpflags is not None:
            header.bootpflags = Bootpflags
            result.update({'Bootpflags': 'bootpflags'})
        if ClientAddr is not None:
            header.clientAddr = ClientAddr
            result.update({'ClientAddr': 'clientAddr'})
        if YourAddr is not None:
            header.yourAddr = YourAddr
            result.update({'YourAddr': 'yourAddr'})
        if NextServerAddr is not None:
            header.nextServerAddr = NextServerAddr
            result.update({'NextServerAddr': 'nextServerAddr'})
        if RelayAgentAddr is not None:
            header.relayAgentAddr = RelayAgentAddr
            result.update({'RelayAgentAddr': 'relayAgentAddr'})
        if ClientMac is not None:
            header.clientMac = ClientMac
            result.update({'ClientMac': 'clientMac'})
        if ClientHWPad is not None:
            header.clientHWPad = ClientHWPad
            result.update({'ClientHWPad': 'clientHWPad'})
        if ServerHostName is not None:
            header.serverHostName = ServerHostName
            result.update({'ServerHostName': 'serverHostName'})
        if BootFileName is not None:
            header.bootFileName = BootFileName
            result.update({'BootFileName': 'bootFileName'})
        if MagicCookie is not None:
            header.magicCookie = MagicCookie
            result.update({'MagicCookie': 'magicCookie'})
        if Padding is not None:
            header.padding = Padding
            result.update({'Padding': 'padding'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_dhcpv4_option(self, Stream, Types, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['dhcpv4client', 'dhcpv4server']]
        header = headerList[Level]
        if Types.lower() == 'serverid':
            result.update(header.edit_server_id(Index=Index, **kwargs))
        elif Types.lower() == 'message':
            result.update(header.edit_message(Index=Index, **kwargs))
        elif Types.lower() == 'leasetime':
            result.update(header.edit_lease_time(Index=Index, **kwargs))
        elif Types.lower() == 'endofoptions':
            result.update(header.edit_end_of_options(Index=Index, **kwargs))
        elif Types.lower() == 'messagesize':
            result.update(header.edit_message_size(Index=Index, **kwargs))
        elif Types.lower() == 'clientidhw':
            result.update(header.edit_clientid_hw(Index=Index, **kwargs))
        elif Types.lower() == 'clientidnonehw':
            result.update(header.edit_clientid_nonehw(Index=Index, **kwargs))
        elif Types.lower() == 'hostname':
            result.update(header.edit_host_name(Index=Index, **kwargs))
        elif Types.lower() == 'paramreqlist':
            result.update(header.edit_param_req_list(Index=Index, **kwargs))
        elif Types.lower() == 'reqaddr':
            result.update(header.edit_req_addr(Index=Index, **kwargs))
        elif Types.lower() == 'optionoverload':
            result.update(header.edit_option_over_load(Index=Index, **kwargs))
        elif Types.lower() == 'customoption':
            result.update(header.edit_custom_option(Index=Index, **kwargs))
        elif Types.lower() == 'generaltlv':
            result.update(header.edit_general_tlv(Index=Index, **kwargs))
        elif Types.lower() == 'messagetype':
            result.update(header.edit_message_type(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_dhcpv6_client(self, Stream, Level: int = 0,
                                  MessageType=None,
                                  TransId=None,
                                  OptionHeaders=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "dhcpv6client"]
        header = headerList[Level]
        if MessageType is not None:
            header.messageType = MessageType
            result.update({'MessageType': 'messageType'})
        if TransId is not None:
            header.transId = TransId
            result.update({'TransId': 'transId'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_dhcpv6_server(self, Stream, Level: int = 0,
                                  MessageType=None,
                                  TransId=None,
                                  OptionHeaders=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "dhcpv6server"]
        header = headerList[Level]
        if MessageType is not None:
            header.messageType = MessageType
            result.update({'MessageType': 'messageType'})
        if TransId is not None:
            header.transId = TransId
            result.update({'TransId': 'transId'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_dhcpv6_option(self, Stream, Types, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['dhcpv6server', 'dhcpv6client']]
        header = headerList[Level]
        if Types.lower() == 'clientidoption':
            result.update(header.edit_client_id_option(Index=Index, **kwargs))
        elif Types.lower() == 'serveridoption':
            result.update(header.edit_server_id_option(Index=Index, **kwargs))
        elif Types.lower() == 'ianaoption':
            result.update(header.edit_iana_option(Index=Index, **kwargs))
        elif Types.lower() == 'requestoption':
            result.update(header.edit_request_option(Index=Index, **kwargs))
        elif Types.lower() == 'elapsedtimeoption':
            result.update(header.edit_elapsed_time_option(Index=Index, **kwargs))
        elif Types.lower() == 'serverunicastoption':
            result.update(header.edit_server_unicast_option(Index=Index, **kwargs))
        elif Types.lower() == 'statuscodeoption':
            result.update(header.edit_status_code_option(Index=Index, **kwargs))
        elif Types.lower() == 'rapidcommitoption':
            result.update(header.edit_rapid_commit_option(Index=Index, **kwargs))
        elif Types.lower() == 'interfaceidoption':
            result.update(header.edit_interface_id_option(Index=Index, **kwargs))
        elif Types.lower() == 'reconfigureacceptoption':
            result.update(header.edit_reconfigure_accept_option(Index=Index, **kwargs))
        elif Types.lower() == 'iapdoption':
            result.update(header.edit_iapd_option(Index=Index, **kwargs))
        elif Types.lower() == 'customoption':
            result.update(header.edit_custom_option(Index=Index, **kwargs))
        elif Types.lower() == 'generaltlv':
            result.update(header.edit_general_tlv(Index=Index, **kwargs))
        return result if result else False

    def edit_header_dhcpv6_option_ia_address(self, Stream, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['dhcpv6server', 'dhcpv6client']]
        header = headerList[Level]
        result.update(header.edit_ia_address_option(Index=Index, **kwargs))
        return result if result else False

    def edit_header_dhcpv6_option_ia_prefix(self, Stream, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['dhcpv6server', 'dhcpv6client']]
        header = headerList[Level]
        result.update(header.edit_ia_prefix_option(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ppp(self, Stream, Level: int = 0,
                        Addresses=None,
                        Controls=None,
                        Protocol=None,
                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ppp"]
        header = headerList[Level]
        if Addresses is not None:
            header.addresses = Addresses
            result.update({'Addresses': 'addresses.Address_0.value'})
        if Controls is not None:
            header.controls = Controls
            result.update({'Controls': 'controls.Control_0.value'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        return result if result else False

    @abnormal_check()
    def edit_header_pppoe(self, Stream, Level: int = 0,
                          Version=None,
                          Type=None,
                          Code=None,
                          SessionId=None,
                          PayloadLen=None,
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "pppoe"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if SessionId is not None:
            header.sessionId = SessionId
            result.update({'SessionId': 'sessionId'})
        if PayloadLen is not None:
            header.payloadLen = PayloadLen
            result.update({'PayloadLen': 'payloadLen'})
        return result if result else False

    def edit_header_pppoe_discovery(self, Stream, Level: int = 0,
                                    Version=None,
                                    Type=None,
                                    Code=None,
                                    SessionId=None,
                                    PayloadLen=None,
                                    EndOfListTag=None,
                                    ServiceNameTag=None,
                                    AcNameTag=None,
                                    HostUniqTag=None,
                                    AcCookieTag=None,
                                    VendorSpecificTag=None,
                                    RelaySessionIdTag=None,
                                    ServiceNameErrorTag=None,
                                    AcSystemErrorTag=None,
                                    GenericErrorTag=None,
                                    UnknownTag=None
                                    ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "pppoediscovery"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if SessionId is not None:
            header.sessionId = SessionId
            result.update({'SessionId': 'sessionId'})
        if PayloadLen is not None:
            header.payloadLen = PayloadLen
            result.update({'PayloadLen': 'payloadLen'})
        if EndOfListTag is not None:
            header.endOfListTag = EndOfListTag
        if ServiceNameTag is not None:
            header.serviceNameTag = ServiceNameTag
        if AcNameTag is not None:
            header.acNameTag = AcNameTag
        if HostUniqTag is not None:
            header.hostUniqTag = HostUniqTag
        if AcCookieTag is not None:
            header.acCookieTag = AcCookieTag
        if VendorSpecificTag is not None:
            header.vendorSpecificTag = VendorSpecificTag
        if RelaySessionIdTag is not None:
            header.relaySessionIdTag = RelaySessionIdTag
        if ServiceNameErrorTag is not None:
            header.serviceNameErrorTag = ServiceNameErrorTag
        if AcSystemErrorTag is not None:
            header.acSystemErrorTag = AcSystemErrorTag
        if GenericErrorTag is not None:
            header.genericErrorTag = GenericErrorTag
        if UnknownTag is not None:
            header.unknownTag = UnknownTag
        return result

    def edit_header_pppoe_discovery_end_of_list_tag(self, Stream, Level: int = 0,
                                                    TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_end_of_list_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_service_name_tag(self, Stream, Level: int = 0,
                                                     TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_service_name_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_ac_name_tag(self, Stream, Level: int = 0,
                                                TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_ac_name_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_host_uniq_tag(self, Stream, Level: int = 0,
                                                  TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_host_uniq_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_ac_cookie_tag(self, Stream, Level: int = 0,
                                                  TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_ac_cookie_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_vendor_specific_tag(self, Stream, Level: int = 0,
                                                        TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_vendor_specific_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_relay_session_id_tag(self, Stream, Level: int = 0,
                                                         TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_relay_session_id_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_server_name_error_tag(self, Stream, Level: int = 0,
                                                          TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_server_name_error_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_ac_system_error_tag(self, Stream, Level: int = 0,
                                                        TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_ac_system_error_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_generic_error_tag(self, Stream, Level: int = 0,
                                                      TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_generic_error_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    def edit_header_pppoe_discovery_unknown_tag(self, Stream, Level: int = 0,
                                                TagIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pppoediscovery']
        header = headerList[Level]
        result.update(header.config_unknown_tag(TagIndex=TagIndex, **kwargs))
        return result if result else False

    # ------------------------- GATHER header icmpv4-------------------------------------
    @abnormal_check()
    def edit_header_icmp_echorequest(self, Stream, Level: int = 0,
                                     Type=None,
                                     Code=None,
                                     Checksum=None,
                                     Identifier=None,
                                     SequenceNumber=None,
                                     ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv4echorequest"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_maskreply(self, Stream, Level: int = 0,
                                   Type=None,
                                   Code=None,
                                   Checksum=None,
                                   Identifier=None,
                                   SequenceNumber=None,
                                   AddrMask=None
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpmaskreply"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        if AddrMask is not None:
            header.addrMask = AddrMask
            result.update({'AddrMask': 'addrMask'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_maskrequest(self, Stream, Level: int = 0,
                                     Type=None,
                                     Code=None,
                                     Checksum=None,
                                     Identifier=None,
                                     SequenceNumber=None,
                                     AddrMask=None
                                     ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpmaskrequest"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        if AddrMask is not None:
            header.addrMask = AddrMask
            result.update({'AddrMask': 'addrMask'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_destunreach(self, Stream, Level: int = 0,
                                     Type=None,
                                     Code=None,
                                     Checksum=None,
                                     Unused=None,
                                     Data=None,
                                     Ipv4HeaderVersion=None,
                                     Ipv4HeaderHeadLen=None,
                                     Ipv4HeaderTosPrecedence=None,
                                     Ipv4HeaderTosDelay=None,
                                     Ipv4HeaderTosThroughput=None,
                                     Ipv4HeaderTosReliability=None,
                                     Ipv4HeaderTosMonetaryCost=None,
                                     Ipv4HeaderTosReserved=None,
                                     Ipv4HeaderDiffservDscp=None,
                                     Ipv4HeaderDiffserveCodePointPrecedence=None,
                                     Ipv4HeaderDiffserveClassSelectorPrecedence=None,
                                     Ipv4HeaderDiffservDscpDrop=None,
                                     Ipv4HeaderDiffservDscpUndefine=None,
                                     Ipv4HeaderDiffservEcn=None,
                                     Ipv4HeaderTosByte=None,
                                     Ipv4HeaderTotalLength=None,
                                     Ipv4HeaderID=None,
                                     Ipv4HeaderFlags=None,
                                     Ipv4HeaderOffset=None,
                                     Ipv4HeaderTTL=None,
                                     Ipv4HeaderProtocol=None,
                                     Ipv4HeaderChecksum=None,
                                     Ipv4HeaderSource=None,
                                     Ipv4HeaderDestination=None,
                                     Ipv4HeaderHeaderOption=None,
                                     Ipv4HeaderPadding=None,
                                     Ipv4HeaderGateway=None,
                                     ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "destunreach"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.icmpChecksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Unused is not None:
            header.unused = Unused
            result.update({'Unused': 'unused'})
        if Data is not None:
            header.headerData = Data
            result.update({'Data': 'headerData.data'})
        if Ipv4HeaderVersion is not None:
            header.version = Ipv4HeaderVersion
            result.update({'Ipv4HeaderVersion': 'headerData.ipv4Header.version'})
        if Ipv4HeaderHeadLen is not None:
            header.headLen = Ipv4HeaderHeadLen
            result.update({'Ipv4HeaderHeadLen': 'headerData.ipv4Header.headLen'})
        if Ipv4HeaderTosPrecedence is not None:
            header.edit_tos(precedence=Ipv4HeaderTosPrecedence)
            result.update({'Ipv4HeaderTosPrecedence': 'headerData.ipv4Header.tos.tos.precedence'})
        if Ipv4HeaderTosDelay is not None:
            header.edit_tos(delay=Ipv4HeaderTosDelay)
            result.update({'Ipv4HeaderTosDelay': 'headerData.ipv4Header.tos.tos.delay'})
        if Ipv4HeaderTosThroughput is not None:
            header.edit_tos(throughput=Ipv4HeaderTosThroughput)
            result.update({'Ipv4HeaderTosThroughput': 'headerData.ipv4Header.tos.tos.throughput'})
        if Ipv4HeaderTosReliability is not None:
            header.edit_tos(reliability=Ipv4HeaderTosReliability)
            result.update({'Ipv4HeaderTosReliability': 'headerData.ipv4Header.tos.tos.reliability'})
        if Ipv4HeaderTosMonetaryCost is not None:
            header.edit_tos(monetaryCost=Ipv4HeaderTosMonetaryCost)
            result.update({'Ipv4HeaderTosMonetaryCost': 'headerData.ipv4Header.tos.tos.monetaryCost'})
        if Ipv4HeaderTosReserved is not None:
            header.edit_tos(reserved=Ipv4HeaderTosReserved)
            result.update({'Ipv4HeaderTosReserved': 'headerData.ipv4Header.tos.tos.reserved'})
        if Ipv4HeaderDiffservDscp is not None:
            header.edit_diffserv('dscp', Ipv4HeaderDiffservDscp)
            result.update({'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp'})
        if Ipv4HeaderDiffserveCodePointPrecedence is not None:
            header.edit_diffserv('dscp.codePoint.precedence', Ipv4HeaderDiffserveCodePointPrecedence)
            result.update({
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence'})
        if Ipv4HeaderDiffserveClassSelectorPrecedence is not None:
            header.edit_diffserv('dscp.classSelector.precedence', Ipv4HeaderDiffserveClassSelectorPrecedence)
            result.update({
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence'})
        if Ipv4HeaderDiffservDscpDrop is not None:
            header.edit_diffserv('dscp.classSelector.drop', Ipv4HeaderDiffservDscpDrop)
            result.update({'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop'})
        if Ipv4HeaderDiffservDscpUndefine is not None:
            header.edit_diffserv('dscp.classSelector.undefine', Ipv4HeaderDiffservDscpUndefine)
            result.update(
                {'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine'})
        if Ipv4HeaderDiffservEcn is not None:
            header.edit_diffserv('ecnSetting', Ipv4HeaderDiffservEcn)
            result.update({'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting'})
        if Ipv4HeaderTosByte is not None:
            header.edit_tosbyte(value=Ipv4HeaderTosByte)
            result.update({'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'})
        if Ipv4HeaderTotalLength is not None:
            header.totalLength = Ipv4HeaderTotalLength
            result.update({'Ipv4HeaderTotalLength': 'headerData.ipv4Header.totalLength'})
        if Ipv4HeaderID is not None:
            header.id = Ipv4HeaderID
            result.update({'Ipv4HeaderID': 'headerData.ipv4Header.id'})
        if Ipv4HeaderFlags is not None:
            header.flags = Ipv4HeaderFlags
            result.update({'Ipv4HeaderFlags': 'headerData.ipv4Header.flags'})
        if Ipv4HeaderOffset is not None:
            header.offset = Ipv4HeaderOffset
            result.update({'Ipv4HeaderOffset': 'headerData.ipv4Header.offset'})
        if Ipv4HeaderTTL is not None:
            header.ttl = Ipv4HeaderTTL
            result.update({'Ipv4HeaderTTL': 'headerData.ipv4Header.ttl'})
        if Ipv4HeaderProtocol is not None:
            header.protocol = Ipv4HeaderProtocol
            result.update({'Ipv4HeaderProtocol': 'headerData.ipv4Header.protocol'})
        if Ipv4HeaderChecksum is not None:
            header.checksum = Ipv4HeaderChecksum
            result.update({'Ipv4HeaderChecksum': 'headerData.ipv4Header.checksum'})
        if Ipv4HeaderSource is not None:
            header.source = Ipv4HeaderSource
            result.update({'Ipv4HeaderSource': 'headerData.ipv4Header.source'})
        if Ipv4HeaderDestination is not None:
            header.destination = Ipv4HeaderDestination
            result.update({'Ipv4HeaderDestination': 'headerData.ipv4Header.destination'})
        if Ipv4HeaderHeaderOption is not None:
            header.insert_header_option(Types=Ipv4HeaderHeaderOption)
        if Ipv4HeaderPadding is not None:
            header.padding = Ipv4HeaderPadding
            result.update({'Ipv4HeaderPadding': 'headerData.ipv4Header.padding'})
        if Ipv4HeaderGateway is not None:
            header.gateway = Ipv4HeaderGateway
            result.update({'Ipv4HeaderGateway': 'headerData.ipv4Header.gateway'})
        return result

    @abnormal_check()
    def edit_header_icmp_echoreply(self, Stream, Level: int = 0,
                                   Type=None,
                                   Code=None,
                                   Checksum=None,
                                   Identifier=None,
                                   SequenceNumber=None,
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv4echoreply"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_informationreply(self, Stream, Level: int = 0,
                                          Type=None,
                                          Code=None,
                                          Checksum=None,
                                          Identifier=None,
                                          SequenceNumber=None,
                                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "informationreply"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_informationrequest(self, Stream, Level: int = 0,
                                            Type=None,
                                            Code=None,
                                            Checksum=None,
                                            Identifier=None,
                                            SequenceNumber=None,
                                            ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "informationrequest"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_parameterproblem(self, Stream, Level: int = 0,
                                          Type=None,
                                          Code=None,
                                          Checksum=None,
                                          Pointer=None,
                                          Reserve=None,
                                          Data=None,
                                          Ipv4HeaderVersion=None,
                                          Ipv4HeaderHeadLen=None,
                                          Ipv4HeaderTosPrecedence=None,
                                          Ipv4HeaderTosDelay=None,
                                          Ipv4HeaderTosThroughput=None,
                                          Ipv4HeaderTosReliability=None,
                                          Ipv4HeaderTosMonetaryCost=None,
                                          Ipv4HeaderTosReserved=None,
                                          Ipv4HeaderDiffservDscp=None,
                                          Ipv4HeaderDiffserveCodePointPrecedence=None,
                                          Ipv4HeaderDiffserveClassSelectorPrecedence=None,
                                          Ipv4HeaderDiffservDscpDrop=None,
                                          Ipv4HeaderDiffservDscpUndefine=None,
                                          Ipv4HeaderDiffservEcn=None,
                                          Ipv4HeaderTosByte=None,
                                          Ipv4HeaderTotalLength=None,
                                          Ipv4HeaderID=None,
                                          Ipv4HeaderFlags=None,
                                          Ipv4HeaderOffset=None,
                                          Ipv4HeaderTTL=None,
                                          Ipv4HeaderProtocol=None,
                                          Ipv4HeaderChecksum=None,
                                          Ipv4HeaderSource=None,
                                          Ipv4HeaderDestination=None,
                                          Ipv4HeaderHeaderOption=None,
                                          Ipv4HeaderPadding=None,
                                          Ipv4HeaderGateway=None,
                                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv4parameterproblem"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.icmpChecksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Pointer is not None:
            header.pointer = Pointer
            result.update({'Pointer': 'pointer'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if Data is not None:
            header.headerData = Data
            result.update({'Data': 'headerData.data'})
        if Ipv4HeaderVersion is not None:
            header.version = Ipv4HeaderVersion
            result.update({'Ipv4HeaderVersion': 'headerData.ipv4Header.version'})
        if Ipv4HeaderHeadLen is not None:
            header.headLen = Ipv4HeaderHeadLen
            result.update({'Ipv4HeaderHeadLen': 'headerData.ipv4Header.headLen'})
        if Ipv4HeaderTosPrecedence is not None:
            header.edit_tos(precedence=Ipv4HeaderTosPrecedence)
            result.update({'Ipv4HeaderTosPrecedence': 'headerData.ipv4Header.tos.tos.precedence'})
        if Ipv4HeaderTosDelay is not None:
            header.edit_tos(delay=Ipv4HeaderTosDelay)
            result.update({'Ipv4HeaderTosDelay': 'headerData.ipv4Header.tos.tos.delay'})
        if Ipv4HeaderTosThroughput is not None:
            header.edit_tos(throughput=Ipv4HeaderTosThroughput)
            result.update({'Ipv4HeaderTosThroughput': 'headerData.ipv4Header.tos.tos.throughput'})
        if Ipv4HeaderTosReliability is not None:
            header.edit_tos(reliability=Ipv4HeaderTosReliability)
            result.update({'Ipv4HeaderTosReliability': 'headerData.ipv4Header.tos.tos.reliability'})
        if Ipv4HeaderTosMonetaryCost is not None:
            header.edit_tos(monetaryCost=Ipv4HeaderTosMonetaryCost)
            result.update({'Ipv4HeaderTosMonetaryCost': 'headerData.ipv4Header.tos.tos.monetaryCost'})
        if Ipv4HeaderTosReserved is not None:
            header.edit_tos(reserved=Ipv4HeaderTosReserved)
            result.update({'Ipv4HeaderTosReserved': 'headerData.ipv4Header.tos.tos.reserved'})
        if Ipv4HeaderDiffservDscp is not None:
            header.edit_diffserv('dscp', Ipv4HeaderDiffservDscp)
            result.update({'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp'})
        if Ipv4HeaderDiffserveCodePointPrecedence is not None:
            header.edit_diffserv('dscp.codePoint.precedence', Ipv4HeaderDiffserveCodePointPrecedence)
            result.update({
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence'})
        if Ipv4HeaderDiffserveClassSelectorPrecedence is not None:
            header.edit_diffserv('dscp.classSelector.precedence', Ipv4HeaderDiffserveClassSelectorPrecedence)
            result.update({
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence'})
        if Ipv4HeaderDiffservDscpDrop is not None:
            header.edit_diffserv('dscp.classSelector.drop', Ipv4HeaderDiffservDscpDrop)
            result.update({'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop'})
        if Ipv4HeaderDiffservDscpUndefine is not None:
            header.edit_diffserv('dscp.classSelector.undefine', Ipv4HeaderDiffservDscpUndefine)
            result.update(
                {'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine'})
        if Ipv4HeaderDiffservEcn is not None:
            header.edit_diffserv('ecnSetting', Ipv4HeaderDiffservEcn)
            result.update({'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting'})
        if Ipv4HeaderTosByte is not None:
            header.edit_tosbyte(value=Ipv4HeaderTosByte)
            result.update({'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'})
        if Ipv4HeaderTotalLength is not None:
            header.totalLength = Ipv4HeaderTotalLength
            result.update({'Ipv4HeaderTotalLength': 'headerData.ipv4Header.totalLength'})
        if Ipv4HeaderID is not None:
            header.id = Ipv4HeaderID
            result.update({'Ipv4HeaderID': 'headerData.ipv4Header.id'})
        if Ipv4HeaderFlags is not None:
            header.flags = Ipv4HeaderFlags
            result.update({'Ipv4HeaderFlags': 'headerData.ipv4Header.flags'})
        if Ipv4HeaderOffset is not None:
            header.offset = Ipv4HeaderOffset
            result.update({'Ipv4HeaderOffset': 'headerData.ipv4Header.offset'})
        if Ipv4HeaderTTL is not None:
            header.ttl = Ipv4HeaderTTL
            result.update({'Ipv4HeaderTTL': 'headerData.ipv4Header.ttl'})
        if Ipv4HeaderProtocol is not None:
            header.protocol = Ipv4HeaderProtocol
            result.update({'Ipv4HeaderProtocol': 'headerData.ipv4Header.protocol'})
        if Ipv4HeaderChecksum is not None:
            header.checksum = Ipv4HeaderChecksum
            result.update({'Ipv4HeaderChecksum': 'headerData.ipv4Header.checksum'})
        if Ipv4HeaderSource is not None:
            header.source = Ipv4HeaderSource
            result.update({'Ipv4HeaderSource': 'headerData.ipv4Header.source'})
        if Ipv4HeaderDestination is not None:
            header.destination = Ipv4HeaderDestination
            result.update({'Ipv4HeaderDestination': 'headerData.ipv4Header.destination'})
        if Ipv4HeaderHeaderOption is not None:
            header.insert_header_option(Types=Ipv4HeaderHeaderOption)
        if Ipv4HeaderPadding is not None:
            header.padding = Ipv4HeaderPadding
            result.update({'Ipv4HeaderPadding': 'headerData.ipv4Header.padding'})
        if Ipv4HeaderGateway is not None:
            header.gateway = Ipv4HeaderGateway
            result.update({'Ipv4HeaderGateway': 'headerData.ipv4Header.gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_redirect(self, Stream, Level: int = 0,
                                  Type=None,
                                  Code=None,
                                  Checksum=None,
                                  GatewayAddress=None,
                                  Data=None,
                                  Ipv4HeaderVersion=None,
                                  Ipv4HeaderHeadLen=None,
                                  Ipv4HeaderTosPrecedence=None,
                                  Ipv4HeaderTosDelay=None,
                                  Ipv4HeaderTosThroughput=None,
                                  Ipv4HeaderTosReliability=None,
                                  Ipv4HeaderTosMonetaryCost=None,
                                  Ipv4HeaderTosReserved=None,
                                  Ipv4HeaderDiffservDscp=None,
                                  Ipv4HeaderDiffserveCodePointPrecedence=None,
                                  Ipv4HeaderDiffserveClassSelectorPrecedence=None,
                                  Ipv4HeaderDiffservDscpDrop=None,
                                  Ipv4HeaderDiffservDscpUndefine=None,
                                  Ipv4HeaderDiffservEcn=None,
                                  Ipv4HeaderTosByte=None,
                                  Ipv4HeaderTotalLength=None,
                                  Ipv4HeaderID=None,
                                  Ipv4HeaderFlags=None,
                                  Ipv4HeaderOffset=None,
                                  Ipv4HeaderTTL=None,
                                  Ipv4HeaderProtocol=None,
                                  Ipv4HeaderChecksum=None,
                                  Ipv4HeaderSource=None,
                                  Ipv4HeaderDestination=None,
                                  Ipv4HeaderHeaderOption=None,
                                  Ipv4HeaderPadding=None,
                                  Ipv4HeaderGateway=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv4redirect"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.icmpChecksum = Checksum
            result.update({'Checksum': 'checksum'})
        if GatewayAddress is not None:
            header.gatewayAddress = GatewayAddress
            result.update({'GatewayAddress': 'gatewayAddress'})
        if Data is not None:
            header.headerData = Data
            result.update({'Data': 'headerData.data'})
        if Ipv4HeaderVersion is not None:
            header.version = Ipv4HeaderVersion
            result.update({'Ipv4HeaderVersion': 'version'})
        if Ipv4HeaderHeadLen is not None:
            header.headLen = Ipv4HeaderHeadLen
            result.update({'Ipv4HeaderHeadLen': 'headLen'})
        if Ipv4HeaderTosPrecedence is not None:
            header.edit_tos(precedence=Ipv4HeaderTosPrecedence)
            result.update({'Ipv4HeaderTosPrecedence': 'tos.tos.precedence'})
        if Ipv4HeaderTosDelay is not None:
            header.edit_tos(delay=Ipv4HeaderTosDelay)
            result.update({'Ipv4HeaderTosDelay': 'tos.tos.delay'})
        if Ipv4HeaderTosThroughput is not None:
            header.edit_tos(throughput=Ipv4HeaderTosThroughput)
            result.update({'Ipv4HeaderTosThroughput': 'tos.tos.throughput'})
        if Ipv4HeaderTosReliability is not None:
            header.edit_tos(reliability=Ipv4HeaderTosReliability)
            result.update({'Ipv4HeaderTosReliability': 'tos.tos.reliability'})
        if Ipv4HeaderTosMonetaryCost is not None:
            header.edit_tos(monetaryCost=Ipv4HeaderTosMonetaryCost)
            result.update({'Ipv4HeaderTosMonetaryCost': 'tos.tos.monetaryCost'})
        if Ipv4HeaderTosReserved is not None:
            header.edit_tos(reserved=Ipv4HeaderTosReserved)
            result.update({'Ipv4HeaderTosReserved': 'tos.tos.reserved'})
        if Ipv4HeaderDiffservDscp is not None:
            header.edit_diffserv('dscp', Ipv4HeaderDiffservDscp)
            result.update({'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp'})
        if Ipv4HeaderDiffserveCodePointPrecedence is not None:
            header.edit_diffserv('dscp.codePoint.precedence', Ipv4HeaderDiffserveCodePointPrecedence)
            result.update({
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence'})
        if Ipv4HeaderDiffserveClassSelectorPrecedence is not None:
            header.edit_diffserv('dscp.classSelector.precedence', Ipv4HeaderDiffserveClassSelectorPrecedence)
            result.update({
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence'})
        if Ipv4HeaderDiffservDscpDrop is not None:
            header.edit_diffserv('dscp.classSelector.drop', Ipv4HeaderDiffservDscpDrop)
            result.update({'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop'})
        if Ipv4HeaderDiffservDscpUndefine is not None:
            header.edit_diffserv('dscp.classSelector.undefine', Ipv4HeaderDiffservDscpUndefine)
            result.update(
                {'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine'})
        if Ipv4HeaderDiffservEcn is not None:
            header.edit_diffserv('ecnSetting', Ipv4HeaderDiffservEcn)
            result.update({'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting'})
        if Ipv4HeaderTosByte is not None:
            header.edit_tosbyte(value=Ipv4HeaderTosByte)
            result.update({'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'})
        if Ipv4HeaderTotalLength is not None:
            header.totalLength = Ipv4HeaderTotalLength
            result.update({'Ipv4HeaderTotalLength': 'headerData.ipv4Header.totalLength'})
        if Ipv4HeaderID is not None:
            header.id = Ipv4HeaderID
            result.update({'Ipv4HeaderID': 'headerData.ipv4Header.id'})
        if Ipv4HeaderFlags is not None:
            header.flags = Ipv4HeaderFlags
            result.update({'Ipv4HeaderFlags': 'headerData.ipv4Header.flags'})
        if Ipv4HeaderOffset is not None:
            header.offset = Ipv4HeaderOffset
            result.update({'Ipv4HeaderOffset': 'headerData.ipv4Header.offset'})
        if Ipv4HeaderTTL is not None:
            header.ttl = Ipv4HeaderTTL
            result.update({'Ipv4HeaderTTL': 'headerData.ipv4Header.ttl'})
        if Ipv4HeaderProtocol is not None:
            header.protocol = Ipv4HeaderProtocol
            result.update({'Ipv4HeaderProtocol': 'headerData.ipv4Header.protocol'})
        if Ipv4HeaderChecksum is not None:
            header.checksum = Ipv4HeaderChecksum
            result.update({'Ipv4HeaderChecksum': 'headerData.ipv4Header.checksum'})
        if Ipv4HeaderSource is not None:
            header.source = Ipv4HeaderSource
            result.update({'Ipv4HeaderSource': 'headerData.ipv4Header.source'})
        if Ipv4HeaderDestination is not None:
            header.destination = Ipv4HeaderDestination
            result.update({'Ipv4HeaderDestination': 'headerData.ipv4Header.destination'})
        if Ipv4HeaderHeaderOption is not None:
            header.insert_header_option(Types=Ipv4HeaderHeaderOption)
        if Ipv4HeaderPadding is not None:
            header.padding = Ipv4HeaderPadding
            result.update({'Ipv4HeaderPadding': 'headerData.ipv4Header.padding'})
        if Ipv4HeaderGateway is not None:
            header.gateway = Ipv4HeaderGateway
            result.update({'Ipv4HeaderGateway': 'headerData.ipv4Header.gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_sourcequench(self, Stream, Level: int = 0,
                                      Type=None,
                                      Code=None,
                                      Checksum=None,
                                      Reserve=None,
                                      Data=None,
                                      Ipv4HeaderVersion=None,
                                      Ipv4HeaderHeadLen=None,
                                      Ipv4HeaderTosPrecedence=None,
                                      Ipv4HeaderTosDelay=None,
                                      Ipv4HeaderTosThroughput=None,
                                      Ipv4HeaderTosReliability=None,
                                      Ipv4HeaderTosMonetaryCost=None,
                                      Ipv4HeaderTosReserved=None,
                                      Ipv4HeaderDiffservDscp=None,
                                      Ipv4HeaderDiffserveCodePointPrecedence=None,
                                      Ipv4HeaderDiffserveClassSelectorPrecedence=None,
                                      Ipv4HeaderDiffservDscpDrop=None,
                                      Ipv4HeaderDiffservDscpUndefine=None,
                                      Ipv4HeaderDiffservEcn=None,
                                      Ipv4HeaderTosByte=None,
                                      Ipv4HeaderTotalLength=None,
                                      Ipv4HeaderID=None,
                                      Ipv4HeaderFlags=None,
                                      Ipv4HeaderOffset=None,
                                      Ipv4HeaderTTL=None,
                                      Ipv4HeaderProtocol=None,
                                      Ipv4HeaderChecksum=None,
                                      Ipv4HeaderSource=None,
                                      Ipv4HeaderDestination=None,
                                      Ipv4HeaderHeaderOption=None,
                                      Ipv4HeaderPadding=None,
                                      Ipv4HeaderGateway=None,
                                      ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "sourcequench"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.icmpChecksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if Data is not None:
            header.headerData = Data
            result.update({'Data': 'headerData.data'})
        if Ipv4HeaderVersion is not None:
            header.version = Ipv4HeaderVersion
            result.update({'Ipv4HeaderVersion': 'version'})
        if Ipv4HeaderHeadLen is not None:
            header.headLen = Ipv4HeaderHeadLen
            result.update({'Ipv4HeaderHeadLen': 'headLen'})
        if Ipv4HeaderTosPrecedence is not None:
            header.edit_tos(precedence=Ipv4HeaderTosPrecedence)
            result.update({'Ipv4HeaderTosPrecedence': 'tos.tos.precedence'})
        if Ipv4HeaderTosDelay is not None:
            header.edit_tos(delay=Ipv4HeaderTosDelay)
            result.update({'Ipv4HeaderTosDelay': 'tos.tos.delay'})
        if Ipv4HeaderTosThroughput is not None:
            header.edit_tos(throughput=Ipv4HeaderTosThroughput)
            result.update({'Ipv4HeaderTosThroughput': 'tos.tos.throughput'})
        if Ipv4HeaderTosReliability is not None:
            header.edit_tos(reliability=Ipv4HeaderTosReliability)
            result.update({'Ipv4HeaderTosReliability': 'tos.tos.reliability'})
        if Ipv4HeaderTosMonetaryCost is not None:
            header.edit_tos(monetaryCost=Ipv4HeaderTosMonetaryCost)
            result.update({'Ipv4HeaderTosMonetaryCost': 'tos.tos.monetaryCost'})
        if Ipv4HeaderTosReserved is not None:
            header.edit_tos(reserved=Ipv4HeaderTosReserved)
            result.update({'Ipv4HeaderTosReserved': 'tos.tos.reserved'})
        if Ipv4HeaderDiffservDscp is not None:
            header.edit_diffserv('dscp', Ipv4HeaderDiffservDscp)
            result.update({'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp'})
        if Ipv4HeaderDiffserveCodePointPrecedence is not None:
            header.edit_diffserv('dscp.codePoint.precedence', Ipv4HeaderDiffserveCodePointPrecedence)
            result.update({
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence'})
        if Ipv4HeaderDiffserveClassSelectorPrecedence is not None:
            header.edit_diffserv('dscp.classSelector.precedence', Ipv4HeaderDiffserveClassSelectorPrecedence)
            result.update({
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence'})
        if Ipv4HeaderDiffservDscpDrop is not None:
            header.edit_diffserv('dscp.classSelector.drop', Ipv4HeaderDiffservDscpDrop)
            result.update({'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop'})
        if Ipv4HeaderDiffservDscpUndefine is not None:
            header.edit_diffserv('dscp.classSelector.undefine', Ipv4HeaderDiffservDscpUndefine)
            result.update(
                {'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine'})
        if Ipv4HeaderDiffservEcn is not None:
            header.edit_diffserv('ecnSetting', Ipv4HeaderDiffservEcn)
            result.update({'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting'})
        if Ipv4HeaderTosByte is not None:
            header.edit_tosbyte(value=Ipv4HeaderTosByte)
            result.update({'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'})
        if Ipv4HeaderTotalLength is not None:
            header.totalLength = Ipv4HeaderTotalLength
            result.update({'Ipv4HeaderTotalLength': 'headerData.ipv4Header.totalLength'})
        if Ipv4HeaderID is not None:
            header.id = Ipv4HeaderID
            result.update({'Ipv4HeaderID': 'headerData.ipv4Header.id'})
        if Ipv4HeaderFlags is not None:
            header.flags = Ipv4HeaderFlags
            result.update({'Ipv4HeaderFlags': 'headerData.ipv4Header.flags'})
        if Ipv4HeaderOffset is not None:
            header.offset = Ipv4HeaderOffset
            result.update({'Ipv4HeaderOffset': 'headerData.ipv4Header.offset'})
        if Ipv4HeaderTTL is not None:
            header.ttl = Ipv4HeaderTTL
            result.update({'Ipv4HeaderTTL': 'headerData.ipv4Header.ttl'})
        if Ipv4HeaderProtocol is not None:
            header.protocol = Ipv4HeaderProtocol
            result.update({'Ipv4HeaderProtocol': 'headerData.ipv4Header.protocol'})
        if Ipv4HeaderChecksum is not None:
            header.checksum = Ipv4HeaderChecksum
            result.update({'Ipv4HeaderChecksum': 'headerData.ipv4Header.checksum'})
        if Ipv4HeaderSource is not None:
            header.source = Ipv4HeaderSource
            result.update({'Ipv4HeaderSource': 'headerData.ipv4Header.source'})
        if Ipv4HeaderDestination is not None:
            header.destination = Ipv4HeaderDestination
            result.update({'Ipv4HeaderDestination': 'headerData.ipv4Header.destination'})
        if Ipv4HeaderHeaderOption is not None:
            header.insert_header_option(Types=Ipv4HeaderHeaderOption)
        if Ipv4HeaderPadding is not None:
            header.padding = Ipv4HeaderPadding
            result.update({'Ipv4HeaderPadding': 'headerData.ipv4Header.padding'})
        if Ipv4HeaderGateway is not None:
            header.gateway = Ipv4HeaderGateway
            result.update({'Ipv4HeaderGateway': 'headerData.ipv4Header.gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_timeexceeded(self, Stream, Level: int = 0,
                                      Type=None,
                                      Code=None,
                                      Checksum=None,
                                      Reserve=None,
                                      Data=None,
                                      Ipv4HeaderVersion=None,
                                      Ipv4HeaderHeadLen=None,
                                      Ipv4HeaderTosPrecedence=None,
                                      Ipv4HeaderTosDelay=None,
                                      Ipv4HeaderTosThroughput=None,
                                      Ipv4HeaderTosReliability=None,
                                      Ipv4HeaderTosMonetaryCost=None,
                                      Ipv4HeaderTosReserved=None,
                                      Ipv4HeaderDiffservDscp=None,
                                      Ipv4HeaderDiffserveCodePointPrecedence=None,
                                      Ipv4HeaderDiffserveClassSelectorPrecedence=None,
                                      Ipv4HeaderDiffservDscpDrop=None,
                                      Ipv4HeaderDiffservDscpUndefine=None,
                                      Ipv4HeaderDiffservEcn=None,
                                      Ipv4HeaderTosByte=None,
                                      Ipv4HeaderTotalLength=None,
                                      Ipv4HeaderID=None,
                                      Ipv4HeaderFlags=None,
                                      Ipv4HeaderOffset=None,
                                      Ipv4HeaderTTL=None,
                                      Ipv4HeaderProtocol=None,
                                      Ipv4HeaderChecksum=None,
                                      Ipv4HeaderSource=None,
                                      Ipv4HeaderDestination=None,
                                      Ipv4HeaderHeaderOption=None,
                                      Ipv4HeaderPadding=None,
                                      Ipv4HeaderGateway=None,
                                      ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "timeexceeded"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.icmpChecksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if Data is not None:
            header.headerData = Data
            result.update({'Data': 'headerData.data'})
        if Ipv4HeaderVersion is not None:
            header.version = Ipv4HeaderVersion
            result.update({'Ipv4HeaderVersion': 'version'})
        if Ipv4HeaderHeadLen is not None:
            header.headLen = Ipv4HeaderHeadLen
            result.update({'Ipv4HeaderHeadLen': 'headLen'})
        if Ipv4HeaderTosPrecedence is not None:
            header.edit_tos(precedence=Ipv4HeaderTosPrecedence)
            result.update({'Ipv4HeaderTosPrecedence': 'tos.tos.precedence'})
        if Ipv4HeaderTosDelay is not None:
            header.edit_tos(delay=Ipv4HeaderTosDelay)
            result.update({'Ipv4HeaderTosDelay': 'tos.tos.delay'})
        if Ipv4HeaderTosThroughput is not None:
            header.edit_tos(throughput=Ipv4HeaderTosThroughput)
            result.update({'Ipv4HeaderTosThroughput': 'tos.tos.throughput'})
        if Ipv4HeaderTosReliability is not None:
            header.edit_tos(reliability=Ipv4HeaderTosReliability)
            result.update({'Ipv4HeaderTosReliability': 'tos.tos.reliability'})
        if Ipv4HeaderTosMonetaryCost is not None:
            header.edit_tos(monetaryCost=Ipv4HeaderTosMonetaryCost)
            result.update({'Ipv4HeaderTosMonetaryCost': 'tos.tos.monetaryCost'})
        if Ipv4HeaderTosReserved is not None:
            header.edit_tos(reserved=Ipv4HeaderTosReserved)
            result.update({'Ipv4HeaderTosReserved': 'tos.tos.reserved'})
        if Ipv4HeaderDiffservDscp is not None:
            header.edit_diffserv('dscp', Ipv4HeaderDiffservDscp)
            result.update({'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp'})
        if Ipv4HeaderDiffserveCodePointPrecedence is not None:
            header.edit_diffserv('dscp.codePoint.precedence', Ipv4HeaderDiffserveCodePointPrecedence)
            result.update({
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence'})
        if Ipv4HeaderDiffserveClassSelectorPrecedence is not None:
            header.edit_diffserv('dscp.classSelector.precedence', Ipv4HeaderDiffserveClassSelectorPrecedence)
            result.update({
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence'})
        if Ipv4HeaderDiffservDscpDrop is not None:
            header.edit_diffserv('dscp.classSelector.drop', Ipv4HeaderDiffservDscpDrop)
            result.update({'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop'})
        if Ipv4HeaderDiffservDscpUndefine is not None:
            header.edit_diffserv('dscp.classSelector.undefine', Ipv4HeaderDiffservDscpUndefine)
            result.update(
                {'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine'})
        if Ipv4HeaderDiffservEcn is not None:
            header.edit_diffserv('ecnSetting', Ipv4HeaderDiffservEcn)
            result.update({'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting'})
        if Ipv4HeaderTosByte is not None:
            header.edit_tosbyte(value=Ipv4HeaderTosByte)
            result.update({'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'})
        if Ipv4HeaderTotalLength is not None:
            header.totalLength = Ipv4HeaderTotalLength
            result.update({'Ipv4HeaderTotalLength': 'headerData.ipv4Header.totalLength'})
        if Ipv4HeaderID is not None:
            header.id = Ipv4HeaderID
            result.update({'Ipv4HeaderID': 'headerData.ipv4Header.id'})
        if Ipv4HeaderFlags is not None:
            header.flags = Ipv4HeaderFlags
            result.update({'Ipv4HeaderFlags': 'headerData.ipv4Header.flags'})
        if Ipv4HeaderOffset is not None:
            header.offset = Ipv4HeaderOffset
            result.update({'Ipv4HeaderOffset': 'headerData.ipv4Header.offset'})
        if Ipv4HeaderTTL is not None:
            header.ttl = Ipv4HeaderTTL
            result.update({'Ipv4HeaderTTL': 'ttl'})
        if Ipv4HeaderProtocol is not None:
            header.protocol = Ipv4HeaderProtocol
            result.update({'Ipv4HeaderProtocol': 'headerData.ipv4Header.protocol'})
        if Ipv4HeaderChecksum is not None:
            header.checksum = Ipv4HeaderChecksum
            result.update({'Ipv4HeaderChecksum': 'headerData.ipv4Header.checksum'})
        if Ipv4HeaderSource is not None:
            header.source = Ipv4HeaderSource
            result.update({'Ipv4HeaderSource': 'headerData.ipv4Header.source'})
        if Ipv4HeaderDestination is not None:
            header.destination = Ipv4HeaderDestination
            result.update({'Ipv4HeaderDestination': 'headerData.ipv4Header.destination'})
        if Ipv4HeaderHeaderOption is not None:
            header.insert_header_option(Types=Ipv4HeaderHeaderOption)
        if Ipv4HeaderPadding is not None:
            header.padding = Ipv4HeaderPadding
            result.update({'Ipv4HeaderPadding': 'headerData.ipv4Header.padding'})
        if Ipv4HeaderGateway is not None:
            header.gateway = Ipv4HeaderGateway
            result.update({'Ipv4HeaderGateway': 'headerData.ipv4Header.gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_time_stamp_reply(self, Stream, Level: int = 0,
                                          Type=None,
                                          Code=None,
                                          Checksum=None,
                                          Identifier=None,
                                          SequenceNumber=None,
                                          OriginateTimestamp=None,
                                          ReceiveTimestamp=None,
                                          TransmitTimestamp=None
                                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "timestampreply"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        if OriginateTimestamp is not None:
            header.originateTimestamp = OriginateTimestamp
            result.update({'OriginateTimestamp': 'originateTimestamp'})
        if ReceiveTimestamp is not None:
            header.receiveTimestamp = ReceiveTimestamp
            result.update({'ReceiveTimestamp': 'receiveTimestamp'})
        if TransmitTimestamp is not None:
            header.transmitTimestamp = TransmitTimestamp
            result.update({'TransmitTimestamp': 'transmitTimestamp'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmp_time_stamp_request(self, Stream, Level: int = 0,
                                            Type=None,
                                            Code=None,
                                            Checksum=None,
                                            Identifier=None,
                                            SequenceNumber=None,
                                            OriginateTimestamp=None,
                                            ReceiveTimestamp=None,
                                            TransmitTimestamp=None
                                            ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "timestamprequest"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        if OriginateTimestamp is not None:
            header.originateTimestamp = OriginateTimestamp
            result.update({'OriginateTimestamp': 'originateTimestamp'})
        if ReceiveTimestamp is not None:
            header.receiveTimestamp = ReceiveTimestamp
            result.update({'ReceiveTimestamp': 'receiveTimestamp'})
        if TransmitTimestamp is not None:
            header.transmitTimestamp = TransmitTimestamp
            result.update({'TransmitTimestamp': 'transmitTimestamp'})
        return result if result else False

    # ------------------------- GATHER header icmpv6-------------------------------------
    @abnormal_check()
    def edit_header_icmpv6_destinationunreachable(self, Stream, Level: int = 0,
                                                  Type=None,
                                                  Code=None,
                                                  Checksum=None,
                                                  Reserve=None,
                                                  HeaderData=None,
                                                  Version=None,
                                                  TrafficClass=None,
                                                  FlowLabel=None,
                                                  PayloadLength=None,
                                                  NextHeader=None,
                                                  HopLimit=None,
                                                  Source=None,
                                                  Destination=None,
                                                  Gateway=None,
                                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "destinationunreachable"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if HeaderData is not None:
            header.headerData = HeaderData
            result.update({'HeaderData': 'headerData.data'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'headerData.ipv6Header.version'})
        if TrafficClass is not None:
            header.trafficClass = TrafficClass
            result.update({'TrafficClass': 'headerData.ipv6Header.trafficClass'})
        if FlowLabel is not None:
            header.FlowLabel = FlowLabel
            result.update({'FlowLabel': 'headerData.ipv6Header.FlowLabel'})
        if PayloadLength is not None:
            header.payloadLength = PayloadLength
            result.update({'PayloadLength': 'headerData.ipv6Header.payloadLength'})
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'headerData.ipv6Header.nextHeader'})
        if HopLimit is not None:
            header.hopLimit = HopLimit
            result.update({'HopLimit': 'headerData.ipv6Header.hopLimit'})
        if Source is not None:
            header.source = Source
            result.update({'Source': 'headerData.ipv6Header.source'})
        if Destination is not None:
            header.destination = Destination
            result.update({'Destination': 'headerData.ipv6Header.destination'})
        if Gateway is not None:
            header.gateway = Gateway
            result.update({'Gateway': 'headerData.ipv6Header.gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_echoreply(self, Stream, Level: int = 0,
                                     Type=None,
                                     Code=None,
                                     Checksum=None,
                                     Identifier=None,
                                     SequenceNumber=None,
                                     ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv6echoreply"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_echorequest(self, Stream, Level: int = 0,
                                       Type=None,
                                       Code=None,
                                       Checksum=None,
                                       Identifier=None,
                                       SequenceNumber=None,
                                       ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv6echorequest"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Identifier is not None:
            header.identifier = Identifier
            result.update({'Identifier': 'identifier'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_mldv1done(self, Stream, Level: int = 0,
                                     Type=None,
                                     Code=None,
                                     Checksum=None,
                                     MaxRespDelay=None,
                                     Reserved=None,
                                     MulticastAddress=None,
                                     ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "mldv1done"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if MaxRespDelay is not None:
            header.maxRespDelay = MaxRespDelay
            result.update({'MaxRespDelay': 'maxRespDelay'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if MulticastAddress is not None:
            header.multicastAddress = MulticastAddress
            result.update({'MulticastAddress': 'multicastAddress'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_mldv1query(self, Stream, Level: int = 0,
                                      Type=None,
                                      Code=None,
                                      Checksum=None,
                                      MaxRespDelay=None,
                                      Reserved=None,
                                      MulticastAddress=None,
                                      ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "mldv1query"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if MaxRespDelay is not None:
            header.maxRespDelay = MaxRespDelay
            result.update({'MaxRespDelay': 'maxRespDelay'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if MulticastAddress is not None:
            header.multicastAddress = MulticastAddress
            result.update({'MulticastAddress': 'multicastAddress'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_mldv1report(self, Stream, Level: int = 0,
                                       Type=None,
                                       Code=None,
                                       Checksum=None,
                                       MaxRespDelay=None,
                                       Reserved=None,
                                       MulticastAddress=None,
                                       ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "mldv1report"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if MaxRespDelay is not None:
            header.maxRespDelay = MaxRespDelay
            result.update({'MaxRespDelay': 'maxRespDelay'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if MulticastAddress is not None:
            header.multicastAddress = MulticastAddress
            result.update({'MulticastAddress': 'multicastAddress'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_mldv2query(self, Stream, Level: int = 0,
                                      Type=None,
                                      Code=None,
                                      Checksum=None,
                                      MaxRespCode=None,
                                      Reserved=None,
                                      GroupAddress=None,
                                      Resv=None,
                                      Sflag=None,
                                      Qrv=None,
                                      Qqic=None,
                                      NumberOfSources=None,
                                      SourceAddressList=None
                                      ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "mldv2query"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if MaxRespCode is not None:
            header.maxRespCode = MaxRespCode
            result.update({'MaxRespCode': 'maxRespCode'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if GroupAddress is not None:
            header.groupAddress = GroupAddress
            result.update({'GroupAddress': 'groupAddress'})
        if Resv is not None:
            header.resv = Resv
            result.update({'Resv': 'resv'})
        if Sflag is not None:
            header.sFlag = Sflag
            result.update({'Sflag': 'sFlag'})
        if Qrv is not None:
            header.qrv = Qrv
            result.update({'Qrv': 'qrv'})
        if Qqic is not None:
            header.qqic = Qqic
            result.update({'Qqic': 'qqic'})
        if NumberOfSources is not None:
            header.numberOfSources = NumberOfSources
            result.update({'NumberOfSources': 'numberOfSources'})
        if SourceAddressList is not None:
            header.sourceAddressList = SourceAddressList
            for i, addr in enumerate(SourceAddressList):
                result.update({f'SourceAddressList: {addr}': f'sourceAddressList.ipv6AddrContainer_{i}.ipv6Addr'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_mldv2report(self, Stream, Level: int = 0,
                                       Type=None,
                                       Unused=None,
                                       Checksum=None,
                                       Reserved=None,
                                       NumberOfGroupRecords=None
                                       ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "mldv2report"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Unused is not None:
            header.unused = Unused
            result.update({'Unused': 'unused'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved2'})
        if NumberOfGroupRecords is not None:
            header.numberOfGroupRecords = NumberOfGroupRecords
            result.update({'NumberOfGroupRecords': 'numberOfGroupRecords'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_group_records(self, Stream, Level=0, Index=0, Header='mldv2report', **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == Header]
        header = headerList[Level]
        result.update(header.editMldv2GroupRecord(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_packettoobig(self, Stream, Level: int = 0,
                                        Type=None,
                                        Code=None,
                                        Checksum=None,
                                        Mtu=None,
                                        HeaderData=None,
                                        Version=None,
                                        TrafficClass=None,
                                        FlowLabel=None,
                                        PayloadLength=None,
                                        NextHeader=None,
                                        HopLimit=None,
                                        Source=None,
                                        Destination=None,
                                        Gateway=None,
                                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "packettoobig"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Mtu is not None:
            header.mtu = Mtu
            result.update({'Mtu': 'mtu'})
        if HeaderData is not None:
            header.headerData = HeaderData
            result.update({'HeaderData': 'headerData.data'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'headerData.ipv6Header.version'})
        if TrafficClass is not None:
            header.trafficClass = TrafficClass
            result.update({'TrafficClass': 'headerData.ipv6Header.trafficClass'})
        if FlowLabel is not None:
            header.FlowLabel = FlowLabel
            result.update({'FlowLabel': 'headerData.ipv6Header.FlowLabel'})
        if PayloadLength is not None:
            header.payloadLength = PayloadLength
            result.update({'PayloadLength': 'headerData.ipv6Header.payloadLength'})
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'headerData.ipv6Header.nextHeader'})
        if HopLimit is not None:
            header.hopLimit = HopLimit
            result.update({'HopLimit': 'headerData.ipv6Header.hopLimit'})
        if Source is not None:
            header.source = Source
            result.update({'Source': 'headerData.ipv6Header.source'})
        if Destination is not None:
            header.destination = Destination
            result.update({'Destination': 'headerData.ipv6Header.destination'})
        if Gateway is not None:
            header.gateway = Gateway
            result.update({'Gateway': 'headerData.ipv6Header.gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_parameterproblem(self, Stream, Level: int = 0,
                                            Type=None,
                                            Code=None,
                                            Checksum=None,
                                            Pointer=None,
                                            HeaderData=None,
                                            Version=None,
                                            TrafficClass=None,
                                            FlowLabel=None,
                                            PayloadLength=None,
                                            NextHeader=None,
                                            HopLimit=None,
                                            Source=None,
                                            Destination=None,
                                            Gateway=None,
                                            ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv6parameterproblem"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Pointer is not None:
            header.pointer = Pointer
            result.update({'Pointer': 'pointer'})
        if HeaderData is not None:
            header.headerData = HeaderData
            result.update({'HeaderData': 'headerData.data'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'headerData.ipv6Header.version'})
        if TrafficClass is not None:
            header.trafficClass = TrafficClass
            result.update({'TrafficClass': 'headerData.ipv6Header.trafficClass'})
        if FlowLabel is not None:
            header.FlowLabel = FlowLabel
            result.update({'FlowLabel': 'headerData.ipv6Header.FlowLabel'})
        if PayloadLength is not None:
            header.payloadLength = PayloadLength
            result.update({'PayloadLength': 'headerData.ipv6Header.payloadLength'})
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'headerData.ipv6Header.nextHeader'})
        if HopLimit is not None:
            header.hopLimit = HopLimit
            result.update({'HopLimit': 'headerData.ipv6Header.hopLimit'})
        if Source is not None:
            header.source = Source
            result.update({'Source': 'headerData.ipv6Header.source'})
        if Destination is not None:
            header.destination = Destination
            result.update({'Destination': 'headerData.ipv6Header.destination'})
        if Gateway is not None:
            header.gateway = Gateway
            result.update({'Gateway': 'headerData.ipv6Header.gateway'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_timeexceed(self, Stream, Level: int = 0,
                                      Type=None,
                                      Code=None,
                                      Checksum=None,
                                      Reserve=None,
                                      ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "timeexceed"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_routersolicitation(self, Stream, Level: int = 0,
                                              Type=None,
                                              Code=None,
                                              Checksum=None,
                                              Reserve=None,
                                              HeaderOption=None
                                              ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "routersolicit"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if HeaderOption is not None:
            header.insertHeaderOption(HeaderOption)
        return result

    @abnormal_check()
    def edit_header_icmpv6_header_option(self, Stream, Option, Level=0, Index=0, Header='routersolicit', **kwargs):
        # routersolicit routeradvertise icmpv6redirect neighborsolicit neighboradvertise
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == Header]
        header = headerList[Level]
        if Header == 'icmpv6redirect':
            d = header.editLinkLayerOption(Option=Option, Index=Index, **kwargs)
        else:
            d = header.editHeaderOption(Option=Option, Index=Index, **kwargs)
        result.update(d)
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_routeradvertise(self, Stream, Level: int = 0,
                                           Type=None,
                                           Code=None,
                                           Checksum=None,
                                           CurHopLimit=None,
                                           ManagedAddrFlag=None,
                                           OtherConfigFlag=None,
                                           Reserved=None,
                                           RouterLifetime=None,
                                           ReachableTime=None,
                                           RetransTime=None,
                                           HeaderOption=None
                                           ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "routeradvertise"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if CurHopLimit is not None:
            header.curHopLimit = CurHopLimit
            result.update({'CurHopLimit': 'curHopLimit'})
        if ManagedAddrFlag is not None:
            header.managedAddrFlag = ManagedAddrFlag
            result.update({'ManagedAddrFlag': 'managedAddrFlag'})
        if OtherConfigFlag is not None:
            header.otherConfigFlag = OtherConfigFlag
            result.update({'OtherConfigFlag': 'otherConfigFlag'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if RouterLifetime is not None:
            header.routerLifetime = RouterLifetime
            result.update({'RouterLifetime': 'routerLifetime'})
        if ReachableTime is not None:
            header.reachableTime = ReachableTime
            result.update({'ReachableTime': 'reachableTime'})
        if RetransTime is not None:
            header.retransTime = RetransTime
            result.update({'RetransTime': 'retransTime'})
        if HeaderOption is not None:
            header.insertHeaderOption(HeaderOption)
        return result

    @abnormal_check()
    def edit_header_icmpv6_redirect(self, Stream, Level: int = 0,
                                    Type=None,
                                    Code=None,
                                    Checksum=None,
                                    Reserve=None,
                                    TargetAddress=None,
                                    DestAddress=None,
                                    HeaderOption=None,
                                    RedirectedHdrOption=None
                                    ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "icmpv6redirect"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if TargetAddress is not None:
            header.targetAddress = TargetAddress
            result.update({'TargetAddress': 'targetAddress'})
        if DestAddress is not None:
            header.destAddress = DestAddress
            result.update({'DestAddress': 'destAddress'})
        if HeaderOption is not None:
            header.insertLinkLayerOption(HeaderOption)
        if RedirectedHdrOption is not None:
            header.insertRedirectorOption()
        return result

    @abnormal_check()
    def edit_header_icmpv6_redirected_header(self, Stream, Level=0, Index=0, Header='icmpv6redirect', **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == Header]
        header = headerList[Level]
        header.editRedirectorOption(Index=Index, **kwargs)
        return result if result else False

    @abnormal_check()
    def edit_header_icmpv6_neighboradvertise(self, Stream, Level: int = 0,
                                             Type=None,
                                             Code=None,
                                             Checksum=None,
                                             Rflag=None,
                                             Sflag=None,
                                             Oflag=None,
                                             Reserve=None,
                                             TargetAddress=None,
                                             HeaderOption=None,
                                             ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "neighboradvertise"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Rflag is not None:
            header.rFlag = Rflag
            result.update({'Rflag': 'rFlag'})
        if Sflag is not None:
            header.sFlag = Sflag
            result.update({'Sflag': 'sFlag'})
        if Oflag is not None:
            header.oFlag = Oflag
            result.update({'Oflag': 'oFlag'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if TargetAddress is not None:
            header.targetAddress = TargetAddress
            result.update({'TargetAddress': 'targetAddress'})
        if HeaderOption is not None:
            header.insertHeaderOption(HeaderOption)
        return result

    @abnormal_check()
    def edit_header_icmpv6_neighborsolicitation(self, Stream, Level: int = 0,
                                                Type=None,
                                                Code=None,
                                                Checksum=None,
                                                Reserve=None,
                                                TargetAddress=None,
                                                HeaderOption=None,
                                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "neighborsolicit"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Code is not None:
            header.code = Code
            result.update({'Code': 'code'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if TargetAddress is not None:
            header.targetAddress = TargetAddress
            result.update({'TargetAddress': 'targetAddress'})
        if HeaderOption is not None:
            header.insertHeaderOption(HeaderOption)
        return result

    # ------------------------- GATHER header igmpv1-------------------------------------
    @abnormal_check()
    def edit_header_igmpv1_report(self, Stream, Level: int = 0,
                                  Type=None,
                                  Unused=None,
                                  Checksum=None,
                                  GroupAddress=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "igmpv1"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Unused is not None:
            header.unused = Unused
            result.update({'Unused': 'unused'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if GroupAddress is not None:
            header.groupAddress = GroupAddress
            result.update({'GroupAddress': 'groupAddress'})
        return result if result else False

    @abnormal_check()
    def edit_header_igmpv1_query(self, Stream, Level: int = 0,
                                 Type=None,
                                 Unused=None,
                                 Checksum=None,
                                 GroupAddress=None,
                                 ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "igmpv1query"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Unused is not None:
            header.unused = Unused
            result.update({'Unused': 'unused'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if GroupAddress is not None:
            header.groupAddress = GroupAddress
            result.update({'GroupAddress': 'groupAddress'})
        return result if result else False

    # ------------------------- GATHER header igmpv2-------------------------------------
    @abnormal_check()
    def edit_header_igmpv2_report(self, Stream, Level: int = 0,
                                  Type=None,
                                  MaxResponseTime=None,
                                  Checksum=None,
                                  GroupAddress=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "igmpv2"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if MaxResponseTime is not None:
            header.maxResponseTime = MaxResponseTime
            result.update({'MaxResponseTime': 'maxResponseTime'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if GroupAddress is not None:
            header.groupAddress = GroupAddress
            result.update({'GroupAddress': 'groupAddress'})
        return result if result else False

    @abnormal_check()
    def edit_header_igmpv2_query(self, Stream, Level: int = 0,
                                 Type=None,
                                 MaxResponseTime=None,
                                 Checksum=None,
                                 GroupAddress=None,
                                 ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "igmpv2query"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if MaxResponseTime is not None:
            header.maxResponseTime = MaxResponseTime
            result.update({'MaxResponseTime': 'maxResponseTime'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if GroupAddress is not None:
            header.groupAddress = GroupAddress
            result.update({'GroupAddress': 'groupAddress'})
        return result if result else False

    # ------------------------- GATHER header igmpv3-------------------------------------
    @abnormal_check()
    def edit_header_igmpv3_report(self, Stream, Level: int = 0,
                                  Type=None,
                                  Reserved1=None,
                                  Checksum=None,
                                  Reserved2=None,
                                  NumGroupRecords=None
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "igmpv3report"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        if NumGroupRecords is not None:
            header.numGroupRecords = NumGroupRecords
            result.update({'NumGroupRecords': 'numGroupRecords'})
        return result if result else False

    @abnormal_check()
    def edit_header_igmpv3_query(self, Stream, Level: int = 0,
                                 Type=None,
                                 MaxResponseTime=None,
                                 Checksum=None,
                                 GroupAddress=None,
                                 Reserved=None,
                                 SuppressFlag=None,
                                 Qrv=None,
                                 Qqic=None,
                                 NumberOfSources=None,
                                 SourceAddressList=None
                                 ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "igmpv3query"]
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if MaxResponseTime is not None:
            header.maxResponseTime = MaxResponseTime
            result.update({'MaxResponseTime': 'maxResponseTime'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'checksum'})
        if GroupAddress is not None:
            header.groupAddress = GroupAddress
            result.update({'GroupAddress': 'groupAddress'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if SuppressFlag is not None:
            header.suppressFlag = SuppressFlag
            result.update({'SuppressFlag': 'suppressFlag'})
        if Qrv is not None:
            header.qrv = Qrv
            result.update({'Qrv': 'qrv'})
        if Qqic is not None:
            header.qqic = Qqic
            result.update({'Qqic': 'qqic'})
        if NumberOfSources is not None:
            header.numberOfSources = NumberOfSources
            result.update({'NumberOfSources': 'numberOfSources'})
        if SourceAddressList is not None:
            # TBD delete nodes
            for i, addr in enumerate(SourceAddressList):
                header.insertIpv4AddressContainer()
                ret = header.editIpv4AddressContainer(Value=addr, Index=i)
                result.update({f'SourceAddressList: {addr}': ret})
        return result if result else False

    @abnormal_check()
    def edit_header_igmpv3_group_records(self, Stream, Level=0, Index=0, Header='igmpv3report', SourceAddressList=[],
                                         ExceedauxDataList=[], **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == Header]
        header = headerList[Level]
        result.update(header.editGroupRecords(Index=Index, **kwargs))
        # TBD delete nodes
        for i, addr in enumerate(SourceAddressList):
            header.insertIpv4AddressContainer(GroupIndex=Index)
            ret = header.editIpv4AddressContainer(Value=addr, GroupIndex=Index, Index=i)
            result.update({f'SourceAddressList: {addr}': ret})
        # TBD delete nodes
        for j, data in enumerate(ExceedauxDataList):
            header.insertAuxDataContainer(GroupIndex=Index)
            ret = header.editAuxDataContainer(Value=data, GroupIndex=Index, Index=j)
            result.update({f'ExceedauxDataList: {data}': ret})
        return result if result else False

    @abnormal_check()
    def edit_header_custom(self, Stream,
                           Level: int = 0,
                           Index=None,
                           Pattern=None,
                           Checksum=None,
                           ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "custom"]
        header = headerList[Level]
        if Index is None:
            if Pattern is not None:
                result.update({'Pattern': header.insert_option_pattern(Value=Pattern)})
            if str(Checksum).lower() != 'none':
                result.update({'Checksum': header.insert_option_checksum(Value=Checksum)})
        else:
            if Pattern is not None:
                result.update({'Pattern': header.edit_option_pattern(Level=int(Index) + 1, Value=Pattern)})
            if str(Checksum).lower() != 'none':
                result.update({'Checksum': header.insert_option_checksum(Value=Checksum)})
        return result if result else False

    # ------------------------- GATHER header ospfv2-------------------------------------
    @abnormal_check()
    def edit_header_ospfv2_hello(self, Stream, Level: int = 0,
                                 Version=None,
                                 Type=None,
                                 PacketLength=None,
                                 RouterID=None,
                                 AreaID=None,
                                 Checksum=None,
                                 AuthType=None,
                                 AuthValue1=None,
                                 AuthValue2=None,
                                 PacketOptionsReserved7=None,
                                 PacketOptionsReserved6=None,
                                 PacketOptionsDcBit=None,
                                 PacketOptionsEaBit=None,
                                 PacketOptionsNpBit=None,
                                 PacketOptionsMcBit=None,
                                 PacketOptionsEBit=None,
                                 PacketOptionsReserved0=None,
                                 NetworkMask=None,
                                 HelloInterval=None,
                                 RouterPriority=None,
                                 RouterDeadInterval=None,
                                 DesignatedRouter=None,
                                 BackupDesignatedRouter=None,
                                 Neighbors=None
                                 ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ospfv2hello"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'ospfHeader.version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'ospfHeader.type'})
        if PacketLength is not None:
            header.packetLength = PacketLength
            result.update({'PacketLength': 'ospfHeader.packetLength'})
        if RouterID is not None:
            header.routerID = RouterID
            result.update({'RouterID': 'ospfHeader.routerID'})
        if AreaID is not None:
            header.areaID = AreaID
            result.update({'AreaID': 'ospfHeader.areaID'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'ospfHeader.checksum'})
        if AuthType is not None:
            header.authType = AuthType
        if AuthValue1 is not None:
            header.authValue1 = AuthValue1
            result.update({'AuthValue1': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue1'})
        if AuthValue2 is not None:
            header.authValue2 = AuthValue2
            result.update({'AuthValue2': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue2'})
        if PacketOptionsReserved7 is not None:
            header.optionsReserved7 = PacketOptionsReserved7
            result.update({'PacketOptionsReserved7': f'{header._Ospfv2OptionHeader__optionType}.reserved7'})
        if PacketOptionsReserved6 is not None:
            header.optionsReserved6 = PacketOptionsReserved6
            result.update({'PacketOptionsReserved6': f'{header._Ospfv2OptionHeader__optionType}.reserved6'})
        if PacketOptionsDcBit is not None:
            header.optionsDcBit = PacketOptionsDcBit
            result.update({'PacketOptionsDcBit': f'{header._Ospfv2OptionHeader__optionType}.dcBit'})
        if PacketOptionsEaBit is not None:
            header.optionsEaBit = PacketOptionsEaBit
            result.update({'PacketOptionsEaBit': f'{header._Ospfv2OptionHeader__optionType}.eaBit'})
        if PacketOptionsNpBit is not None:
            header.optionsNpBit = PacketOptionsNpBit
            result.update({'PacketOptionsNpBit': f'{header._Ospfv2OptionHeader__optionType}.npBit'})
        if PacketOptionsMcBit is not None:
            header.optionsMcBit = PacketOptionsMcBit
            result.update({'PacketOptionsMcBit': f'{header._Ospfv2OptionHeader__optionType}.mcBit'})
        if PacketOptionsEBit is not None:
            header.optionsEBit = PacketOptionsEBit
            result.update({'PacketOptionsEBit': f'{header._Ospfv2OptionHeader__optionType}.eBit'})
        if PacketOptionsReserved0 is not None:
            header.optionsReserved0 = PacketOptionsReserved0
            result.update({'PacketOptionsReserved0': f'{header._Ospfv2OptionHeader__optionType}.reserved0'})
        if NetworkMask is not None:
            header.networkMask = NetworkMask
            result.update({'NetworkMask': 'networkMask'})
        if HelloInterval is not None:
            header.helloInterval = HelloInterval
            result.update({'HelloInterval': 'helloInterval'})
        if RouterPriority is not None:
            header.routerPriority = RouterPriority
            result.update({'RouterPriority': 'routerPriority'})
        if RouterDeadInterval is not None:
            header.routerDeadInterval = RouterDeadInterval
            result.update({'RouterDeadInterval': 'routerDeadInterval'})
        if DesignatedRouter is not None:
            header.designatedRouter = DesignatedRouter
            result.update({'DesignatedRouter': 'designatedRouter'})
        if BackupDesignatedRouter is not None:
            header.backupDesignatedRouter = BackupDesignatedRouter
            result.update({'BackupDesignatedRouter': 'backupDesignatedRouter'})
        if Neighbors is not None:
            result.update(header.insert_neighbors(Value=Neighbors))
        return result

    @abnormal_check()
    def edit_header_ospfv2_unknown(self, Stream, Level: int = 0,
                                   Version=None,
                                   Type=None,
                                   PacketLength=None,
                                   RouterID=None,
                                   AreaID=None,
                                   Checksum=None,
                                   AuthType=None,
                                   AuthValue1=None,
                                   AuthValue2=None,
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ospfv2unknown"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'ospfHeader.version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'ospfHeader.type'})
        if PacketLength is not None:
            header.packetLength = PacketLength
            result.update({'PacketLength': 'ospfHeader.packetLength'})
        if RouterID is not None:
            header.routerID = RouterID
            result.update({'RouterID': 'ospfHeader.routerID'})
        if AreaID is not None:
            header.areaID = AreaID
            result.update({'AreaID': 'ospfHeader.areaID'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'ospfHeader.checksum'})
        if AuthType is not None:
            header.authType = AuthType
        if AuthValue1 is not None:
            header.authValue1 = AuthValue1
            result.update({'AuthValue1': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue1'})
        if AuthValue2 is not None:
            header.authValue2 = AuthValue2
            result.update({'AuthValue2': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue2'})
        return result

    @abnormal_check()
    def edit_header_ospfv2_request(self, Stream, Level: int = 0,
                                   Version=None,
                                   Type=None,
                                   PacketLength=None,
                                   RouterID=None,
                                   AreaID=None,
                                   Checksum=None,
                                   AuthType=None,
                                   AuthValue1=None,
                                   AuthValue2=None,
                                   LsaHeaderCount=None,
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ospfv2linkstaterequest"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'ospfHeader.version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'ospfHeader.type'})
        if PacketLength is not None:
            header.packetLength = PacketLength
            result.update({'PacketLength': 'ospfHeader.packetLength'})
        if RouterID is not None:
            header.routerID = RouterID
            result.update({'RouterID': 'ospfHeader.routerID'})
        if AreaID is not None:
            header.areaID = AreaID
            result.update({'AreaID': 'ospfHeader.areaID'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'ospfHeader.checksum'})
        if AuthType is not None:
            header.authType = AuthType
        if AuthValue1 is not None:
            header.authValue1 = AuthValue1
            result.update({'AuthValue1': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue1'})
        if AuthValue2 is not None:
            header.authValue2 = AuthValue2
            result.update({'AuthValue2': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue2'})
        if LsaHeaderCount is not None:
            header.insert_lsa_header(Value=LsaHeaderCount)
        return result

    @abnormal_check()
    def edit_header_ospfv2_dd(self, Stream, Level: int = 0,
                              Version=None,
                              Type=None,
                              PacketLength=None,
                              RouterID=None,
                              AreaID=None,
                              Checksum=None,
                              AuthType=None,
                              AuthValue1=None,
                              AuthValue2=None,
                              PacketOptionsReserved7=None,
                              PacketOptionsReserved6=None,
                              PacketOptionsDcBit=None,
                              PacketOptionsEaBit=None,
                              PacketOptionsNpBit=None,
                              PacketOptionsMcBit=None,
                              PacketOptionsEBit=None,
                              PacketOptionsReserved0=None,
                              InterfaceMtu=None,
                              SequenceNumber=None,
                              DdOptionsReserved7=None,
                              DdOptionsReserved6=None,
                              DdOptionsReserved5=None,
                              DdOptionsReserved4=None,
                              DdOptionsReserved3=None,
                              DdOptionsIBit=None,
                              DdOptionsMBit=None,
                              DdOptionsMsBit=None,
                              LsaHeaderCount=None
                              ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ospfv2databasedescription"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'ospfHeader.version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'ospfHeader.type'})
        if PacketLength is not None:
            header.packetLength = PacketLength
            result.update({'PacketLength': 'ospfHeader.packetLength'})
        if RouterID is not None:
            header.routerID = RouterID
            result.update({'RouterID': 'ospfHeader.routerID'})
        if AreaID is not None:
            header.areaID = AreaID
            result.update({'AreaID': 'ospfHeader.areaID'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'ospfHeader.checksum'})
        if AuthType is not None:
            header.authType = AuthType
        if AuthValue1 is not None:
            header.authValue1 = AuthValue1
            result.update({'AuthValue1': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue1'})
        if AuthValue2 is not None:
            header.authValue2 = AuthValue2
            result.update({'AuthValue2': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue2'})
        if PacketOptionsReserved7 is not None:
            header.optionsReserved7 = PacketOptionsReserved7
            result.update({'PacketOptionsReserved7': f'{header._Ospfv2OptionHeader__optionType}.reserved7'})
        if PacketOptionsReserved6 is not None:
            header.optionsReserved6 = PacketOptionsReserved6
            result.update({'PacketOptionsReserved6': f'{header._Ospfv2OptionHeader__optionType}.reserved6'})
        if PacketOptionsDcBit is not None:
            header.optionsDcBit = PacketOptionsDcBit
            result.update({'PacketOptionsDcBit': f'{header._Ospfv2OptionHeader__optionType}.dcBit'})
        if PacketOptionsEaBit is not None:
            header.optionsEaBit = PacketOptionsEaBit
            result.update({'PacketOptionsEaBit': f'{header._Ospfv2OptionHeader__optionType}.eaBit'})
        if PacketOptionsNpBit is not None:
            header.optionsNpBit = PacketOptionsNpBit
            result.update({'PacketOptionsNpBit': f'{header._Ospfv2OptionHeader__optionType}.npBit'})
        if PacketOptionsMcBit is not None:
            header.optionsMcBit = PacketOptionsMcBit
            result.update({'PacketOptionsMcBit': f'{header._Ospfv2OptionHeader__optionType}.mcBit'})
        if PacketOptionsEBit is not None:
            header.optionsEBit = PacketOptionsEBit
            result.update({'PacketOptionsEBit': f'{header._Ospfv2OptionHeader__optionType}.eBit'})
        if PacketOptionsReserved0 is not None:
            header.optionsReserved0 = PacketOptionsReserved0
            result.update({'PacketOptionsReserved0': f'{header._Ospfv2OptionHeader__optionType}.reserved0'})
        if InterfaceMtu is not None:
            header.interfaceMtu = InterfaceMtu
            result.update({'InterfaceMtu': 'interfaceMtu'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        if DdOptionsReserved7 is not None:
            header.ddOptionsReserved7 = DdOptionsReserved7
            result.update({'DdOptionsReserved7': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.reserved7'})
        if DdOptionsReserved6 is not None:
            header.ddOptionsReserved6 = DdOptionsReserved6
            result.update({'DdOptionsReserved6': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.reserved6'})
        if DdOptionsReserved5 is not None:
            header.ddOptionsReserved5 = DdOptionsReserved5
            result.update({'DdOptionsReserved5': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.reserved5'})
        if DdOptionsReserved4 is not None:
            header.ddOptionsReserved4 = DdOptionsReserved4
            result.update({'DdOptionsReserved4': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.reserved4'})
        if DdOptionsReserved3 is not None:
            header.ddOptionsReserved3 = DdOptionsReserved3
            result.update({'DdOptionsReserved3': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.reserved3'})
        if DdOptionsIBit is not None:
            header.ddOptionsIBit = DdOptionsIBit
            result.update({'DdOptionsIBit': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.iBit'})
        if DdOptionsMBit is not None:
            header.ddOptionsMBit = DdOptionsMBit
            result.update({'DdOptionsMBit': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.mBit'})
        if DdOptionsMsBit is not None:
            header.ddOptionsMsBit = DdOptionsMsBit
            result.update({'DdOptionsMsBit': f'{header._Ospfv2DatabaseDescriptionHeader__ddOptions}.msBit'})
        if LsaHeaderCount is not None:
            header.insert_lsa_header(Value=LsaHeaderCount)
        return result

    @abnormal_check()
    def edit_header_ospfv2_ack(self, Stream, Level: int = 0,
                               Version=None,
                               Type=None,
                               PacketLength=None,
                               RouterID=None,
                               AreaID=None,
                               Checksum=None,
                               AuthType=None,
                               AuthValue1=None,
                               AuthValue2=None,
                               PacketOptionsReserved7=None,
                               PacketOptionsReserved6=None,
                               PacketOptionsDcBit=None,
                               PacketOptionsEaBit=None,
                               PacketOptionsNpBit=None,
                               PacketOptionsMcBit=None,
                               PacketOptionsEBit=None,
                               PacketOptionsReserved0=None,
                               LsaHeaderCount=None
                               ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ospfv2linkstateacknowledge"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'ospfHeader.version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'ospfHeader.type'})
        if PacketLength is not None:
            header.packetLength = PacketLength
            result.update({'PacketLength': 'ospfHeader.packetLength'})
        if RouterID is not None:
            header.routerID = RouterID
            result.update({'RouterID': 'ospfHeader.routerID'})
        if AreaID is not None:
            header.areaID = AreaID
            result.update({'AreaID': 'ospfHeader.areaID'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'ospfHeader.checksum'})
        if AuthType is not None:
            header.authType = AuthType
        if AuthValue1 is not None:
            header.authValue1 = AuthValue1
            result.update({'AuthValue1': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue1'})
        if AuthValue2 is not None:
            header.authValue2 = AuthValue2
            result.update({'AuthValue2': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue2'})
        if PacketOptionsReserved7 is not None:
            header.optionsReserved7 = PacketOptionsReserved7
            result.update({'PacketOptionsReserved7': f'{header._Ospfv2OptionHeader__optionType}.reserved7'})
        if PacketOptionsReserved6 is not None:
            header.optionsReserved6 = PacketOptionsReserved6
            result.update({'PacketOptionsReserved6': f'{header._Ospfv2OptionHeader__optionType}.reserved6'})
        if PacketOptionsDcBit is not None:
            header.optionsDcBit = PacketOptionsDcBit
            result.update({'PacketOptionsDcBit': f'{header._Ospfv2OptionHeader__optionType}.dcBit'})
        if PacketOptionsEaBit is not None:
            header.optionsEaBit = PacketOptionsEaBit
            result.update({'PacketOptionsEaBit': f'{header._Ospfv2OptionHeader__optionType}.eaBit'})
        if PacketOptionsNpBit is not None:
            header.optionsNpBit = PacketOptionsNpBit
            result.update({'PacketOptionsNpBit': f'{header._Ospfv2OptionHeader__optionType}.npBit'})
        if PacketOptionsMcBit is not None:
            header.optionsMcBit = PacketOptionsMcBit
            result.update({'PacketOptionsMcBit': f'{header._Ospfv2OptionHeader__optionType}.mcBit'})
        if PacketOptionsEBit is not None:
            header.optionsEBit = PacketOptionsEBit
            result.update({'PacketOptionsEBit': f'{header._Ospfv2OptionHeader__optionType}.eBit'})
        if PacketOptionsReserved0 is not None:
            header.optionsReserved0 = PacketOptionsReserved0
            result.update({'PacketOptionsReserved0': f'{header._Ospfv2OptionHeader__optionType}.reserved0'})
        if LsaHeaderCount is not None:
            header.insert_lsa_header(Value=LsaHeaderCount)
        return result

    @abnormal_check()
    def edit_header_ospfv2_lsa(self, Stream, HeaderType, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == HeaderType.lower()]
        header = headerList[Level]
        result.update(header.edit_lsa_header(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ospfv2_update(self, Stream, Level: int = 0,
                                  Version=None,
                                  Type=None,
                                  PacketLength=None,
                                  RouterID=None,
                                  AreaID=None,
                                  Checksum=None,
                                  AuthType=None,
                                  AuthValue1=None,
                                  AuthValue2=None,
                                  NumberOfLsas=None,
                                  LsaHeaders=None
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ospfv2linkstateupdate"]
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'ospfHeader.version'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'ospfHeader.type'})
        if PacketLength is not None:
            header.packetLength = PacketLength
            result.update({'PacketLength': 'ospfHeader.packetLength'})
        if RouterID is not None:
            header.routerID = RouterID
            result.update({'RouterID': 'ospfHeader.routerID'})
        if AreaID is not None:
            header.areaID = AreaID
            result.update({'AreaID': 'ospfHeader.areaID'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'ospfHeader.checksum'})
        if AuthType is not None:
            header.authType = AuthType
        if AuthValue1 is not None:
            header.authValue1 = AuthValue1
            result.update({'AuthValue1': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue1'})
        if AuthValue2 is not None:
            header.authValue2 = AuthValue2
            result.update({'AuthValue2': f'ospfHeader.authSelect.{header._Ospfv2Header__authSelect}.authValue2'})
        if NumberOfLsas is not None:
            header.numberOfLsas = NumberOfLsas
            result.update({'NumberOfLsas': 'numberOfLsas'})
        if LsaHeaders is not None:
            header.insert_lsa_header(Value=LsaHeaders)
        return result

    @abnormal_check()
    def edit_header_ospfv2_update_lsa(self, Stream, Type, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ospfv2linkstateupdate']
        header = headerList[Level]
        if Type.lower() == 'router':
            ret = header.edit_route_lsa_header(Index=Index, **kwargs)
        elif Type.lower() == 'network':
            ret = header.edit_network_lsa_header(Index=Index, **kwargs)
        elif Type.lower() == 'summary':
            ret = header.edit_summary_lsa_header(Index=Index, **kwargs)
        elif Type.lower() == 'summaryasbr':
            ret = header.edit_summary_asbr_lsa_header(Index=Index, **kwargs)
        elif Type.lower() == 'asexternal':
            ret = header.edit_external_lsa_header(Index=Index, **kwargs)
        result.update(ret)
        return result

    @abnormal_check()
    def edit_header_ospfv2_update_routelsalink(self, Stream, Level=0, LsaIndex=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ospfv2linkstateupdate']
        header = headerList[Level]
        result.update(header.edit_route_lsa_link(LsaIndex=LsaIndex, Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ospfv2_update_routelinktosmetric(self, Stream, Level=0, LsaIndex=0, MetricIndex=0, Index=0,
                                                     **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ospfv2linkstateupdate']
        header = headerList[Level]
        result.update(
            header.edit_route_lsa_tos_metric(LsaIndex=LsaIndex, MetricIndex=MetricIndex, Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ospfv2_update_networkattachedroute(self, Stream, Level=0, LsaIndex=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ospfv2linkstateupdate']
        header = headerList[Level]
        result.update(header.edit_network_lsa_attachedrouters(LsaIndex=LsaIndex, Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ospfv2_update_tosmetric(self, Stream, Type, Level=0, LsaIndex=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ospfv2linkstateupdate']
        header = headerList[Level]
        result.update(header.edit_lsa_tosmetric(Type=Type, LsaIndex=LsaIndex, Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_mpls(self, Stream, Level: int = 0,
                         Label=None,
                         Exp=None,
                         Bottom=None,
                         TTL=None,
                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "mpls"]
        header = headerList[Level]
        if Label is not None:
            header.label = Label
            result.update({'Label': 'label'})
        if Exp is not None:
            header.exp = Exp
            result.update({'Exp': 'exp'})
        if Bottom is not None:
            header.bottom = Bottom
            result.update({'Bottom': 'bottom'})
        if TTL is not None:
            header.ttl = TTL
            result.update({'TTL': 'ttl'})
        return result if result else False

    @abnormal_check()
    def edit_header_gre(self, Stream, Level: int = 0,
                        ChecksumPresent=None,
                        Routing=None,
                        KeyPresent=None,
                        SequenceNumberPresent=None,
                        Reserved=None,
                        Version=None,
                        Protocol=None,
                        EnableKeepAlive=None,
                        KeepAlivePeriod=None,
                        KeepAliveRetries=None,
                        Checksum=None,
                        ChecksumReserved=None,
                        Key=None,
                        SequenceNumber=None,
                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "gre"]
        header = headerList[Level]
        if ChecksumPresent is not None:
            header.checksumPresent = ChecksumPresent
            result.update({'ChecksumPresent': 'checksumPresent'})
        if Routing is not None:
            header.routing = Routing
            result.update({'Routing': 'routing'})
        if KeyPresent is not None:
            header.keyPresent = KeyPresent
            result.update({'KeyPresent': 'keyPresent'})
        if SequenceNumberPresent is not None:
            header.sequenceNumberPresent = SequenceNumberPresent
            result.update({'SequenceNumberPresent': 'sequenceNumberPresent'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        if EnableKeepAlive is not None:
            header.enableKeepAlive = EnableKeepAlive
            result.update({'EnableKeepAlive': 'enableKeepAlive'})
        if KeepAlivePeriod is not None:
            header.keepAlivePeriod = KeepAlivePeriod
            result.update({'KeepAlivePeriod': 'keepAlivePeriod'})
        if KeepAliveRetries is not None:
            header.keepAliveRetries = KeepAliveRetries
            result.update({'KeepAliveRetries': 'keepAliveRetries'})
        if Checksum is not None:
            header.insert_gre_checksum(checksum=Checksum)
            result.update({'Checksum': 'checksum.GreChecksum_0.checksum'})
        if ChecksumReserved is not None:
            header.insert_gre_checksum(reserved=ChecksumReserved)
            result.update({'ChecksumReserved': 'checksum.GreChecksum_0.reserved'})
        if Key is not None:
            header.insert_gre_key(key=Key)
            result.update({'Key': 'Key.GreKey_0.key'})
        if SequenceNumber is not None:
            header.insert_gre_sequenceNumber(sequenceNumber=SequenceNumber)
            result.update({'SequenceNumber': 'sequenceNumber.GreSequenceNumber_0.sequenceNumber'})
        return result if result else False

    @abnormal_check()
    def edit_header_isis_csnp(self, Stream, Level: int = 0,
                              InterRoutingProtocolDiscriminator=None,
                              LengthIndicator=None,
                              VersionIdExtend=None,
                              IdLength=None,
                              Reserved1=None,
                              PDUType=None,
                              Version=None,
                              Reserved2=None,
                              MaxAreaAddress=None,
                              PDULength=None,
                              LspId=None,
                              StartLspId=None,
                              EndLspId=None,
                              CsnpDataTlvOptionHeader=None,
                              ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ["l1csnpheader", 'l2csnpheader']]
        header = headerList[Level]
        if header.header_type == 'l1csnpheader':
            field = 'l1csnpCommonHeader'
        else:
            field = 'l2csnpCommonHeader'
        if InterRoutingProtocolDiscriminator is not None:
            header.InterRoutingProtocolDiscriminator = InterRoutingProtocolDiscriminator
            result.update({'InterRoutingProtocolDiscriminator': f'{field}.InterRoutingProtocolDiscriminator'})
        if LengthIndicator is not None:
            header.lengthIndicator = LengthIndicator
            result.update({'LengthIndicator': f'{field}.lengthIndicator'})
        if VersionIdExtend is not None:
            header.versionIdExtend = VersionIdExtend
            result.update({'VersionIdExtend': f'{field}.versionIdExtend'})
        if IdLength is not None:
            header.idLength = IdLength
            result.update({'IdLength': f'{field}.idLength'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': f'{field}.reserved1'})
        if PDUType is not None:
            header.pDUType = PDUType
            result.update({'PDUType': f'{field}.pDUType'})
        if Version is not None:
            header.version = Version
            result.update({'Version': f'{field}.version'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': f'{field}.reserved2'})
        if MaxAreaAddress is not None:
            header.maxAreaAddress = MaxAreaAddress
            result.update({'MaxAreaAddress': f'{field}.maxAreaAddress'})
        if PDULength is not None:
            header.pDULength = PDULength
            result.update({'PDULength': 'CsnpDataHeader.pDULength'})
        if LspId is not None:
            header.lspId = LspId
            result.update({'LspId': 'CsnpDataHeader.lspId'})
        if StartLspId is not None:
            header.startLspId = StartLspId
            result.update({'StartLspId': 'CsnpDataHeader.startLspId'})
        if EndLspId is not None:
            header.endLspId = EndLspId
            result.update({'EndLspId': 'CsnpDataHeader.endLspId'})
        if CsnpDataTlvOptionHeader is not None:
            header.CsnpDataTlvOptionHeader = CsnpDataTlvOptionHeader
        return result

    @abnormal_check()
    def edit_header_isis_tlv_header(self, Stream, Option, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['l1csnpheader', 'isisl1helloheader', 'l1lspheader',
                                                                 'l1psnpheader', 'l2csnpheader', 'isisl2helloheader',
                                                                 'l2lspheader', 'l2psnpheader', 'p2phelloheader']]
        header = headerList[Level]
        result.update(header.editTlvHeader(Option=Option, Index=Index, **kwargs))
        return result

    @abnormal_check()
    def edit_header_isis_lsp_entry(self, Stream, Level=0, TlvIndex=0, LspIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if
                      x.header_type in ['l1csnpheader', 'l1psnpheader', 'l2csnpheader', 'l2psnpheader']]
        header = headerList[Level]
        result.update(header.editLspEntry(TlvIndex=TlvIndex, LspIndex=LspIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_isis_l1l2_hello(self, Stream, Level: int = 0,
                                    InterRoutingProtocolDiscriminator=None,
                                    LengthIndicator=None,
                                    VersionIdExtend=None,
                                    IdLength=None,
                                    CommonReserved1=None,
                                    PDUType=None,
                                    Version=None,
                                    CommonReserved2=None,
                                    MaxAreaAddress=None,
                                    FixedReserve1=None,
                                    CircuitType=None,
                                    SenderSystemID=None,
                                    HolderTimer=None,
                                    PDULength=None,
                                    FixedReserve2=None,
                                    Priority=None,
                                    DesignatedSystemID=None,
                                    IsIsTlv=None,
                                    ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ["isisl1helloheader", 'isisl2helloheader']]
        header = headerList[Level]
        if header.header_type == 'isisl1helloheader':
            field = ['l1CommonHeader', 'l1HelloMsg']
        else:
            field = ['l2HelloCommonHeader', 'l2HelloMsg']
        if InterRoutingProtocolDiscriminator is not None:
            header.InterRoutingProtocolDiscriminator = InterRoutingProtocolDiscriminator
            result.update({'InterRoutingProtocolDiscriminator': f'{field[0]}.InterRoutingProtocolDiscriminator'})
        if LengthIndicator is not None:
            header.lengthIndicator = LengthIndicator
            result.update({'LengthIndicator': f'{field[0]}.lengthIndicator'})
        if VersionIdExtend is not None:
            header.versionIdExtend = VersionIdExtend
            result.update({'VersionIdExtend': f'{field[0]}.versionIdExtend'})
        if IdLength is not None:
            header.idLength = IdLength
            result.update({'IdLength': f'{field[0]}.idLength'})
        if CommonReserved1 is not None:
            header.commonReserved1 = CommonReserved1
            result.update({'CommonReserved1': f'{field[0]}.reserved1'})
        if PDUType is not None:
            header.pDUType = PDUType
            result.update({'PDUType': f'{field[0]}.pDUType'})
        if Version is not None:
            header.version = Version
            result.update({'Version': f'{field[0]}.version'})
        if CommonReserved2 is not None:
            header.commonReserved2 = CommonReserved2
            result.update({'CommonReserved2': f'{field[0]}.reserved2'})
        if MaxAreaAddress is not None:
            header.maxAreaAddress = MaxAreaAddress
            result.update({'MaxAreaAddress': f'{field[0]}.maxAreaAddress'})
        if FixedReserve1 is not None:
            header.fixedReserve1 = FixedReserve1
            result.update({'FixedReserve1': f'{field[1]}.reserved1'})
        if CircuitType is not None:
            header.circuitType = CircuitType
            result.update({'CircuitType': f'{field[1]}.circuitType'})
        if SenderSystemID is not None:
            header.senderSystemID = SenderSystemID
            result.update({'SenderSystemID': f'{field[1]}.senderSystemID'})
        if HolderTimer is not None:
            header.holderTimer = HolderTimer
            result.update({'HolderTimer': f'{field[1]}.holderTimer'})
        if PDULength is not None:
            header.pDULength = PDULength
            result.update({'PDULength': f'{field[1]}.pDULength'})
        if FixedReserve2 is not None:
            header.fixedReserve2 = FixedReserve2
            result.update({'FixedReserve2': f'{field[1]}.reserved2'})
        if Priority is not None:
            header.priority = Priority
            result.update({'Priority': f'{field[1]}.priority'})
        if DesignatedSystemID is not None:
            header.designatedSystemID = DesignatedSystemID
            result.update({'DesignatedSystemID': f'{field[1]}.designatedSystemID'})
        if IsIsTlv is not None:
            header.isIsTlv = IsIsTlv
        return result

    @abnormal_check()
    def edit_header_isis_area_address_entry(self, Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if
                      x.header_type in ['isisl1helloheader', 'l1lspheader', 'isisl2helloheader',
                                        'l2lspheader', 'p2phelloheader']]
        header = headerList[Level]
        result.update(header.editAddressEntry(TlvIndex=TlvIndex, EntryIndex=EntryIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_isis_nlpid_entry(self, Stream, Level=0, TlvIndex=0, NlpidIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if
                      x.header_type in ['isisl1helloheader', 'l1lspheader', 'isisl2helloheader',
                                        'l2lspheader', 'p2phelloheader']]
        header = headerList[Level]
        result.update(header.editProtocolsSupported(TlvIndex=TlvIndex, NlpidIndex=NlpidIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_isis_lsp(self, Stream, Level: int = 0,
                             InterRoutingProtocolDiscriminator=None,
                             LengthIndicator=None,
                             VersionIdExtend=None,
                             IdLength=None,
                             Reserved1=None,
                             PDUType=None,
                             Version=None,
                             Reserved2=None,
                             MaxAreaAddress=None,
                             PDULength=None,
                             RemainTime=None,
                             LspId=None,
                             SeqcenceNum=None,
                             Checksum=None,
                             PartitionRepair=None,
                             Attchment=None,
                             OverloadBit=None,
                             TypeOfIntermediateSystem=None,
                             LspisIsTlvOptionSet=None
                             ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ["l1lspheader", 'l2lspheader']]
        header = headerList[Level]
        if header.header_type == 'l1lspheader':
            field = 'l1LspCommonHeader'
        else:
            field = 'l2LspCommonHeader'
        if InterRoutingProtocolDiscriminator is not None:
            header.InterRoutingProtocolDiscriminator = InterRoutingProtocolDiscriminator
            result.update({'InterRoutingProtocolDiscriminator': f'{field}.InterRoutingProtocolDiscriminator'})
        if LengthIndicator is not None:
            header.lengthIndicator = LengthIndicator
            result.update({'LengthIndicator': f'{field}.lengthIndicator'})
        if VersionIdExtend is not None:
            header.versionIdExtend = VersionIdExtend
            result.update({'VersionIdExtend': f'{field}.versionIdExtend'})
        if IdLength is not None:
            header.idLength = IdLength
            result.update({'IdLength': f'{field}.idLength'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': f'{field}.reserved1'})
        if PDUType is not None:
            header.pDUType = PDUType
            result.update({'PDUType': f'{field}.pDUType'})
        if Version is not None:
            header.version = Version
            result.update({'Version': f'{field}.version'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': f'{field}.reserved2'})
        if MaxAreaAddress is not None:
            header.maxAreaAddress = MaxAreaAddress
            result.update({'MaxAreaAddress': f'{field}.maxAreaAddress'})
        if PDULength is not None:
            header.pDULength = PDULength
            result.update({'PDULength': 'LspDataUnitHeader.pDULength'})
        if RemainTime is not None:
            header.remainTime = RemainTime
            result.update({'RemainTime': 'LspDataUnitHeader.remainTime'})
        if LspId is not None:
            header.lspId = LspId
            result.update({'LspId': 'LspDataUnitHeader.lspId'})
        if SeqcenceNum is not None:
            header.seqcenceNum = SeqcenceNum
            result.update({'SeqcenceNum': 'LspDataUnitHeader.seqcenceNum'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'LspDataUnitHeader.checksum'})
        if PartitionRepair is not None:
            header.partitionRepair = PartitionRepair
            result.update({'PartitionRepair': 'LspDataUnitHeader.partitionRepair'})
        if Attchment is not None:
            header.attchment = Attchment
            result.update({'Attchment': 'LspDataUnitHeader.attchment'})
        if OverloadBit is not None:
            header.OverloadBit = OverloadBit
            result.update({'OverloadBit': 'LspDataUnitHeader.OverloadBit'})
        if TypeOfIntermediateSystem is not None:
            header.TypeOfIntermediateSystem = TypeOfIntermediateSystem
            result.update({'TypeOfIntermediateSystem': 'LspDataUnitHeader.TypeOfIntermediateSystem'})
        if LspisIsTlvOptionSet is not None:
            header.LspisIsTlvOptionSet = LspisIsTlvOptionSet
        return result

    @abnormal_check()
    def edit_header_isis_metric_entry(self, Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['l1lspheader', 'l2lspheader']]
        header = headerList[Level]
        result.update(header.editMetricEntry(TlvIndex=TlvIndex, EntryIndex=EntryIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_isis_sub_tlv(self, Stream, SubTlv, Level=0, TlvIndex=0, SubTlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['l1lspheader', 'l2lspheader']]
        header = headerList[Level]
        result.update(header.editSubTlv(SubTlv=SubTlv, TlvIndex=TlvIndex, SubTlvIndex=SubTlvIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_isis_internal_metric_entry(self, Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['l1lspheader', 'l2lspheader']]
        header = headerList[Level]
        result.update(header.editInternalMetricEntry(TlvIndex=TlvIndex, EntryIndex=EntryIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_isis_external_metric_entry(self, Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ['l1lspheader', 'l2lspheader']]
        header = headerList[Level]
        result.update(header.editExternalMetricEntry(TlvIndex=TlvIndex, EntryIndex=EntryIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_isis_psnp(self, Stream, Level: int = 0,
                              InterRoutingProtocolDiscriminator=None,
                              LengthIndicator=None,
                              VersionIdExtend=None,
                              IdLength=None,
                              Reserved1=None,
                              PDUType=None,
                              Version=None,
                              Reserved2=None,
                              MaxAreaAddress=None,
                              PDULength=None,
                              SourceId=None,
                              Reserved=None,
                              CsnpDataTlvOptionHeader=None
                              ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type in ["l1psnpheader", 'l2psnpheader']]
        header = headerList[Level]
        if header.header_type == 'l1psnpheader':
            field = 'l1psnpCommonHeader'
        else:
            field = 'l2psnpCommonHeader'
        if InterRoutingProtocolDiscriminator is not None:
            header.InterRoutingProtocolDiscriminator = InterRoutingProtocolDiscriminator
            result.update({'InterRoutingProtocolDiscriminator': f'{field}.InterRoutingProtocolDiscriminator'})
        if LengthIndicator is not None:
            header.lengthIndicator = LengthIndicator
            result.update({'LengthIndicator': f'{field}.lengthIndicator'})
        if VersionIdExtend is not None:
            header.versionIdExtend = VersionIdExtend
            result.update({'VersionIdExtend': f'{field}.versionIdExtend'})
        if IdLength is not None:
            header.idLength = IdLength
            result.update({'IdLength': f'{field}.idLength'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': f'{field}.reserved1'})
        if PDUType is not None:
            header.pDUType = PDUType
            result.update({'PDUType': f'{field}.pDUType'})
        if Version is not None:
            header.version = Version
            result.update({'Version': f'{field}.version'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': f'{field}.reserved2'})
        if MaxAreaAddress is not None:
            header.maxAreaAddress = MaxAreaAddress
            result.update({'MaxAreaAddress': f'{field}.maxAreaAddress'})
        if PDULength is not None:
            header.pDULength = PDULength
            result.update({'PDULength': 'psnpDataHeader.pDULength'})
        if SourceId is not None:
            header.sourceId = SourceId
            result.update({'SourceId': 'psnpDataHeader.sourceId'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'psnpDataHeader.reserved'})
        if CsnpDataTlvOptionHeader is not None:
            header.CsnpDataTlvOptionHeader = CsnpDataTlvOptionHeader
        return result

    @abnormal_check()
    def edit_header_isis_p2p_hello(self, Stream, Level: int = 0,
                                   InterRoutingProtocolDiscriminator=None,
                                   LengthIndicator=None,
                                   VersionIdExtend=None,
                                   IdLength=None,
                                   CommonReserved1=None,
                                   PDUType=None,
                                   Version=None,
                                   CommonReserved2=None,
                                   MaxAreaAddress=None,
                                   FixedReserve1=None,
                                   CircuitType=None,
                                   SenderSystemID=None,
                                   HolderTimer=None,
                                   PDULength=None,
                                   LocalCircuitId=None,
                                   IsIsTlv=None,
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'p2phelloheader']
        header = headerList[Level]
        if InterRoutingProtocolDiscriminator is not None:
            header.InterRoutingProtocolDiscriminator = InterRoutingProtocolDiscriminator
            result.update(
                {'InterRoutingProtocolDiscriminator': 'p2pHelloCommonHeader.InterRoutingProtocolDiscriminator'})
        if LengthIndicator is not None:
            header.lengthIndicator = LengthIndicator
            result.update({'LengthIndicator': 'p2pHelloCommonHeader.lengthIndicator'})
        if VersionIdExtend is not None:
            header.versionIdExtend = VersionIdExtend
            result.update({'VersionIdExtend': 'p2pHelloCommonHeader.versionIdExtend'})
        if IdLength is not None:
            header.idLength = IdLength
            result.update({'IdLength': 'p2pHelloCommonHeader.idLength'})
        if CommonReserved1 is not None:
            header.commonReserved1 = CommonReserved1
            result.update({'CommonReserved1': 'p2pHelloCommonHeader.reserved1'})
        if PDUType is not None:
            header.pDUType = PDUType
            result.update({'PDUType': 'p2pHelloCommonHeader.pDUType'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'p2pHelloCommonHeader.version'})
        if CommonReserved2 is not None:
            header.commonReserved2 = CommonReserved2
            result.update({'CommonReserved2': 'p2pHelloCommonHeader.reserved2'})
        if MaxAreaAddress is not None:
            header.maxAreaAddress = MaxAreaAddress
            result.update({'MaxAreaAddress': 'p2pHelloCommonHeader.maxAreaAddress'})
        if FixedReserve1 is not None:
            header.fixedReserve1 = FixedReserve1
            result.update({'FixedReserve1': 'p2pHelloMsg.reserved1'})
        if CircuitType is not None:
            header.circuitType = CircuitType
            result.update({'CircuitType': 'p2pHelloMsg.circuitType'})
        if SenderSystemID is not None:
            header.senderSystemID = SenderSystemID
            result.update({'SenderSystemID': 'p2pHelloMsg.senderSystemID'})
        if HolderTimer is not None:
            header.holderTimer = HolderTimer
            result.update({'HolderTimer': 'p2pHelloMsg.holderTimer'})
        if PDULength is not None:
            header.pDULength = PDULength
            result.update({'PDULength': 'p2pHelloMsg.pDULength'})
        if LocalCircuitId is not None:
            header.localCircuitId = LocalCircuitId
            result.update({'LocalCircuitId': 'p2pHelloMsg.localCircuitId'})
        if IsIsTlv is not None:
            header.isIsTlv = IsIsTlv
        return result

    # ------------------------- GTpv1 header -------------------------------------

    @abnormal_check()
    def edit_header_gtpv1(self, Stream, Level: int = 0,
                          Version=None,
                          Pt=None,
                          Reserved=None,
                          Nexthead=None,
                          SequenceNumber=None,
                          PduNumberPresent=None,
                          MessageType=None,
                          Length=None,
                          Teid=None,
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'gtpv1']
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Pt is not None:
            header.pt = Pt
            result.update({'Pt': 'pt'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if Nexthead is not None:
            header.nexthead = Nexthead
            result.update({'Nexthead': 'nexthead'})
        if SequenceNumber is not None:
            header.sequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'sequenceNumber'})
        if PduNumberPresent is not None:
            header.pduNumberPresent = PduNumberPresent
            result.update({'PduNumberPresent': 'pduNumberPresent'})
        if MessageType is not None:
            header.messageType = MessageType
            result.update({'MessageType': 'messageType'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Teid is not None:
            header.teid = Teid
            result.update({'Teid': 'teid'})
        return result if result else False

    @abnormal_check()
    def edit_header_gtpv1_optional(self, Stream, Level: int = 0,
                                   Sequence=None,
                                   NPDUNumber=None,
                                   NextHeaderType=None,
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'gtpv1opt']
        header = headerList[Level]
        if Sequence is not None:
            header.sequence = Sequence
            result.update({'Sequence': 'sequence'})
        if NPDUNumber is not None:
            header.nPDUNumber = NPDUNumber
            result.update({'NPDUNumber': 'nPDUNumber'})
        if NextHeaderType is not None:
            header.nextHeaderType = NextHeaderType
            result.update({'NextHeaderType': 'nextHeaderType'})
        return result if result else False

    @abnormal_check()
    def edit_header_gtpv1_extension(self, Stream, Level: int = 0,
                                    Length=None,
                                    BytePattern=None,
                                    NextHeaderType=None,
                                    ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'gtpv1exthdr']
        header = headerList[Level]
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if BytePattern is not None:
            header.bytePattern = BytePattern
            result.update({'BytePattern': 'bytePattern'})
        if NextHeaderType is not None:
            header.nextHeaderType = NextHeaderType
            result.update({'NextHeaderType': 'nextHeaderType'})
        return result if result else False

    @abnormal_check()
    def edit_header_gtpv1_optional_extension(self, Stream, Level: int = 0,
                                             Sequence=None,
                                             NPDUNumber=None,
                                             NextHeaderType1=None,
                                             Length=None,
                                             BytePattern=None,
                                             NextHeaderType2=None,
                                             ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'gtpv1ext']
        header = headerList[Level]
        if Sequence is not None:
            header.sequence = Sequence
            result.update({'Sequence': 'sequence'})
        if NPDUNumber is not None:
            header.nPDUNumber = NPDUNumber
            result.update({'NPDUNumber': 'nPDUNumber'})
        if NextHeaderType1 is not None:
            header.nextHeaderType1 = NextHeaderType1
            result.update({'NextHeaderType1': 'nextHeaderType'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if BytePattern is not None:
            header.bytePattern = BytePattern
            result.update({'BytePattern': 'bytePattern'})
        if NextHeaderType2 is not None:
            header.nextHeaderType2 = NextHeaderType2
            result.update({'NextHeaderType2': 'nextHeaderType'})
        return result if result else False

    @abnormal_check()
    def edit_header_ipv6_fragment(self, Stream, Level: int = 0,
                                  NextHeader=None,
                                  Reserved1=None,
                                  FragOffset=None,
                                  Reserved2=None,
                                  Mflag=None,
                                  Ident=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6fragmentheader']
        header = headerList[Level]
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if FragOffset is not None:
            header.fragOffset = FragOffset
            result.update({'FragOffset': 'fragOffset'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        if Mflag is not None:
            header.m_flag = Mflag
            result.update({'Mflag': 'm_flag'})
        if Ident is not None:
            header.ident = Ident
            result.update({'Ident': 'ident'})
        return result if result else False

    @abnormal_check()
    def edit_header_ipv6_routing(self, Stream, Level: int = 0,
                                 NextHeader=None,
                                 Length=None,
                                 RoutingType=None,
                                 SegLeft=None,
                                 Reserved=None,
                                 Nodes=None,
                                 ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6routingheader']
        header = headerList[Level]
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if RoutingType is not None:
            header.routingType = RoutingType
            result.update({'RoutingType': 'routingType'})
        if SegLeft is not None:
            header.segLeft = SegLeft
            result.update({'SegLeft': 'segLeft'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if Nodes is not None:
            if not isinstance(Nodes, list):
                Nodes = [Nodes]
            header.nodes = Nodes
            for i, v in enumerate(Nodes):
                result.update({f'Nodes_{v}': f'node.Ipv6Address_{i}.value'})
        return result if result else False

    @abnormal_check()
    def edit_header_ipv6_authentication(self, Stream, Level: int = 0,
                                        NextHeader=None,
                                        Length=None,
                                        Reserved=None,
                                        Spi=None,
                                        SeqNum=None,
                                        AuthData=None,
                                        Pad=None,
                                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6authenticationheader']
        header = headerList[Level]
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if Spi is not None:
            header.spi = Spi
            result.update({'Spi': 'spi'})
        if SeqNum is not None:
            header.seqNum = SeqNum
            result.update({'SeqNum': 'seqNum'})
        if AuthData is not None:
            header.authData = AuthData
            result.update({'AuthData': 'authData'})
        if Pad is not None:
            header.pad = Pad
            result.update({'Pad': 'pad'})
        return result if result else False

    @abnormal_check()
    def edit_header_ipv6_destination(self, Stream, Level: int = 0,
                                     NextHeader=None,
                                     Length=None,
                                     Pad=None,
                                     OptionHeaders=None,
                                     ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6destinationheader']
        header = headerList[Level]
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Pad is not None:
            header.pad = Pad
            result.update({'Pad': 'pad'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result

    @abnormal_check()
    def edit_header_ipv6_destination_option(self, Stream, Option, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6destinationheader']
        header = headerList[Level]
        if Option.lower() == 'pad1':
            result.update(header.edit_pad1_option(Index=Index, **kwargs))
        elif Option.lower() == 'padn':
            result.update(header.edit_padN_option(Index=Index, **kwargs))
        elif Option.lower() == 'generaltlv':
            result.update(header.edit_custom_option(Index=Index, **kwargs))
        elif Option.lower() == 'bierv6':
            result.update(header.edit_bier(Index=Index, **kwargs))
        return result

    @abnormal_check()
    def edit_header_ipv6_destination_bier_bit_string(self, Stream, Level=0, BierIndex=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6destinationheader']
        header = headerList[Level]
        result.update(header.edit_bier_bit_string(BierIndex=BierIndex, Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ipv6_encapsulation(self, Stream, Level: int = 0,
                                       Spi=None,
                                       SeqNum=None,
                                       PayloadData=None,
                                       PadData=None,
                                       Length=None,
                                       NextHeader=None,
                                       AuthData=None,
                                       Pad=None
                                       ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6encapsulationheader']
        header = headerList[Level]
        if Spi is not None:
            header.spi = Spi
            result.update({'Spi': 'spi'})
        if SeqNum is not None:
            header.seqNum = SeqNum
            result.update({'SeqNum': 'seqNum'})
        if PayloadData is not None:
            header.payloadData = PayloadData
            result.update({'PayloadData': 'payloadData'})
        if PadData is not None:
            header.padData = PadData
            result.update({'PadData': 'padData'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if AuthData is not None:
            header.authData = AuthData
            result.update({'AuthData': 'authData'})
        if Pad is not None:
            header.pad = Pad
            result.update({'Pad': 'pad'})
        return result

    @abnormal_check()
    def edit_header_ipv6_hopbyhop(self, Stream, Level: int = 0,
                                  NextHeader=None,
                                  Length=None,
                                  Pad=None,
                                  OptionHeaders=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6hopbyhopheader']
        header = headerList[Level]
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Pad is not None:
            header.pad = Pad
            result.update({'Pad': 'pad'})
        if OptionHeaders is not None:
            result.update({'OptionHeaders': header.insert_option_header(Value=OptionHeaders)})
        return result if result else False

    @abnormal_check()
    def edit_header_ipv6_hopbyhop_option(self, Stream, Option, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6hopbyhopheader']
        header = headerList[Level]
        if Option.lower() == 'pad1':
            result.update(header.edit_pad1_option(Index=Index, **kwargs))
        elif Option.lower() == 'padn':
            result.update(header.edit_padN_option(Index=Index, **kwargs))
        elif Option.lower() == 'routeralert':
            result.update(header.edit_router_alert_option(Index=Index, **kwargs))
        elif Option.lower() == 'jumbo':
            result.update(header.edit_jumbo_payload_option(Index=Index, **kwargs))
        elif Option.lower() == 'generaltlv':
            result.update(header.edit_custom_option(Index=Index, **kwargs))
        return result

    @abnormal_check()
    def edit_header_ipv6_sr(self, Stream, Level: int = 0,
                            NextHeader=None,
                            Length=None,
                            RoutingType=None,
                            SegLeft=None,
                            LastEntry=None,
                            SRHeaderFlag=None,
                            Tag=None,
                            SRHOption=None,
                            ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6srheader']
        header = headerList[Level]
        if NextHeader is not None:
            header.nextHeader = NextHeader
            result.update({'NextHeader': 'nextHeader'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if RoutingType is not None:
            header.routingType = RoutingType
            result.update({'RoutingType': 'routingType'})
        if SegLeft is not None:
            header.segLeft = SegLeft
            result.update({'SegLeft': 'segLeft'})
        if LastEntry is not None:
            header.lastEntry = LastEntry
            result.update({'LastEntry': 'lastEntry'})
        if SRHeaderFlag is not None:
            header.sRHeaderFlag = SRHeaderFlag
            result.update({'SRHeaderFlag': 'sRHeaderFlag.unusedFlags'})
        if Tag is not None:
            header.tag = Tag
            result.update({'Tag': 'tag'})
        if SRHOption is not None:
            header.sRHOption = SRHOption
        return result

    @abnormal_check()
    def edit_header_ipv6_sr_option(self, Stream, Option, Level=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ipv6srheader']
        header = headerList[Level]
        if Option.lower() == 'srsegment':
            result.update(header.edit_segment(Index=Index, **kwargs))
        elif Option.lower() == 'sringressnodetlv':
            result.update(header.edit_ingress_node_tlv(Index=Index, **kwargs))
        elif Option.lower() == 'sregressnodetlv':
            result.update(header.edit_egress_node_tlv(Index=Index, **kwargs))
        elif Option.lower() == 'sropaquecontainertlv':
            result.update(header.edit_opaque_container_tlv(Index=Index, **kwargs))
        elif Option.lower() == 'srhmactlv':
            result.update(header.edit_srh_mac_tlv(Index=Index, **kwargs))
        elif Option.lower() == 'srpadding1tlv':
            result.update(header.edit_sr_padding1_tlv(Index=Index, **kwargs))
        elif Option.lower() == 'srpaddingtlv':
            result.update(header.edit_sr_padding_tlv(Index=Index, **kwargs))
        elif Option.lower() == 'generaltlv':
            result.update(header.edit_custom_option(Index=Index, **kwargs))
        return result

    # ------------------------- 802.1ah header -------------------------------------

    @abnormal_check()
    def edit_header_8021ah_CustomerStagEthernet(self, Stream, Level: int = 0,
                                                EtherType=None,
                                                VlanType=None,
                                                VlanPCP=None,
                                                Dei=None,
                                                Vid=None,
                                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'stag']
        header = headerList[Level]
        if EtherType is not None:
            header.etherType = EtherType
            result.update({'EtherType': 'etherType'})
        if VlanType is not None:
            header.vlanType = VlanType
            result.update({'VlanType': 'tag.sTagOption_0.sTag.vlanType'})
        if VlanPCP is not None:
            header.vlanPCP = VlanPCP
            result.update({'VlanPCP': 'tag.sTagOption_0.sTag.vlanPCP'})
        if Dei is not None:
            header.dei = Dei
            result.update({'Dei': 'tag.sTagOption_0.sTag.dei'})
        if Vid is not None:
            header.vid = Vid
            result.update({'Vid': 'tag.sTagOption_0.sTag.vid'})
        return result if result else False

    @abnormal_check()
    def edit_header_8021ah_EncapsulatedCustomerEthernetII(self, Stream, Level: int = 0,
                                                          EtherType=None,
                                                          ServiceTag=None,
                                                          CustomerTag=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'encapethernetii']
        header = headerList[Level]
        if EtherType is not None:
            header.etherType = EtherType
            result.update({'EtherType': 'etherType'})
        if ServiceTag is not None:
            header.insert_service_tag()
        if CustomerTag is not None:
            header.insert_customer_tag()
        return result

    @abnormal_check()
    def edit_header_8021ah_EncapsulatedCustomerEthernetII_serviceTag(self, Stream, Level: int = 0,
                                                                     VlanType=None,
                                                                     VlanPCP=None,
                                                                     Dei=None,
                                                                     Vid=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'encapethernetii']
        header = headerList[Level]
        if VlanType is not None:
            result.update(header.config_service_tag(vlanType=VlanType))
        if VlanPCP is not None:
            result.update(header.config_service_tag(vlanPCP=VlanPCP))
        if Dei is not None:
            result.update(header.config_service_tag(dei=Dei))
        if Vid is not None:
            result.update(header.config_service_tag(vid=Vid))
        return result if result else False

    @abnormal_check()
    def edit_header_8021ah_EncapsulatedCustomerEthernetII_customerTag(self, Stream, Level: int = 0,
                                                                      Type=None,
                                                                      Pcp=None,
                                                                      Cfi=None,
                                                                      Id=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'encapethernetii']
        header = headerList[Level]
        if Type is not None:
            result.update(header.config_customer_tag(type=Type))
        if Pcp is not None:
            result.update(header.config_customer_tag(pcp=Pcp))
        if Cfi is not None:
            result.update(header.config_customer_tag(cfi=Cfi))
        if Id is not None:
            result.update(header.config_customer_tag(id=Id))
        return result if result else False

    @abnormal_check()
    def edit_header_8021ah_EncapsulatedBackboneEthernet(self, Stream, Level: int = 0,
                                                        EtherType=None,
                                                        VlanType=None,
                                                        VlanPCP=None,
                                                        Dei=None,
                                                        Vid=None,
                                                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'encapbackboneeth']
        header = headerList[Level]
        if EtherType is not None:
            header.etherType = EtherType
            result.update({'EtherType': 'etherType'})
        if VlanType is not None:
            header.vlanType = VlanType
            result.update({'VlanType': 'bVLANTag.tagOption_0.btag.vlanType'})
        if VlanPCP is not None:
            header.vlanPCP = VlanPCP
            result.update({'VlanPCP': 'bVLANTag.tagOption_0.btag.vlanPCP'})
        if Dei is not None:
            header.dei = Dei
            result.update({'Dei': 'bVLANTag.tagOption_0.btag.dei'})
        if Vid is not None:
            header.vid = Vid
            result.update({'Vid': 'bVLANTag.tagOption_0.btag.vid'})
        return result if result else False

    @abnormal_check()
    def edit_header_8021ah_iTag(self, Stream, Level: int = 0,
                                Pcp=None,
                                Drop=None,
                                Uca=None,
                                Res1=None,
                                Res2=None,
                                ServiceId=None,
                                EncapCusDstAddr=None,
                                SourceMacAdd=None,
                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'itag']
        header = headerList[Level]
        if Pcp is not None:
            header.pcp = Pcp
            result.update({'Pcp': 'pcp'})
        if Drop is not None:
            header.drop = Drop
            result.update({'Drop': 'drop'})
        if Uca is not None:
            header.uca = Uca
            result.update({'Uca': 'uca'})
        if Res1 is not None:
            header.res1 = Res1
            result.update({'Res1': 'res1'})
        if Res2 is not None:
            header.res2 = Res2
            result.update({'Res2': 'res2'})
        if ServiceId is not None:
            header.serviceId = ServiceId
            result.update({'ServiceId': 'serviceId'})
        if EncapCusDstAddr is not None:
            header.encapCusDstAddr = EncapCusDstAddr
            result.update({'EncapCusDstAddr': 'encapCusDstAddr'})
        if SourceMacAdd is not None:
            header.sourceMacAdd = SourceMacAdd
            result.update({'SourceMacAdd': 'sourceMacAdd'})
        return result if result else False

    @abnormal_check()
    def edit_header_8021ah_MacInMac(self, Stream, Level: int = 0,
                                    DestMacAdd=None,
                                    SourceMacAdd=None,
                                    EtherType=None,
                                    VlanType=None,
                                    VlanPCP=None,
                                    Dei=None,
                                    Vid=None,
                                    ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'mac-in-mac']
        header = headerList[Level]
        if DestMacAdd is not None:
            header.destMacAdd = DestMacAdd
            result.update({'DestMacAdd': 'destMacAdd'})
        if SourceMacAdd is not None:
            header.sourceMacAdd = SourceMacAdd
            result.update({'SourceMacAdd': 'sourceMacAdd'})
        if EtherType is not None:
            header.etherType = EtherType
            result.update({'EtherType': 'etherType'})
        if VlanType is not None:
            header.vlanType = VlanType
            result.update({'VlanType': 'bVLANTag.tagOption_0.btag.vlanType'})
        if VlanPCP is not None:
            header.vlanPCP = VlanPCP
            result.update({'VlanPCP': 'bVLANTag.tagOption_0.btag.vlanPCP'})
        if Dei is not None:
            header.dei = Dei
            result.update({'Dei': 'bVLANTag.tagOption_0.btag.dei'})
        if Vid is not None:
            header.vid = Vid
            result.update({'Vid': 'bVLANTag.tagOption_0.btag.vid'})
        return result if result else False

    @abnormal_check()
    def edit_header_8021ah_EncapsulatedCustomerEthernet(self, Stream, Level: int = 0,
                                                        EtherType=None,
                                                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'encapcustomereth']
        header = headerList[Level]
        if EtherType is not None:
            header.etherType = EtherType
            result.update({'EtherType': 'etherType'})
        return result if result else False

    # ------------------------- ancp header -------------------------------------

    @abnormal_check()
    def edit_header_ancp(self, Stream, Level: int = 0,
                         Identifier=None,
                         Length=None,
                         Version=None,
                         MessageType=None,
                         ResultField=None,
                         ResultCode=None,
                         PartitionId=None,
                         TransactionId=None,
                         Ignore=None,
                         SubMessageNumber=None,
                         Length2=None,
                         Unused=None,
                         Function=None,
                         XFunction=None,
                         Unused2=None,
                         ExtensionFlag=None,
                         MessageType2=None,
                         Reserved=None,
                         NumberOfTlvs=None,
                         ExtensionBlockLength=None,
                         AccessLineIdentifyingTlvs=None,
                         TestingRelatedTlvs=None,
                         StatusInfoTlvs=None
                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'portmanagement']
        header = headerList[Level]
        if Identifier is not None:
            header.id = Identifier
            result.update({'Identifier': 'tcpipEncapHeaderField.id'})
        if Length is not None:
            header.len = Length
            result.update({'Length': 'tcpipEncapHeaderField.len'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'ancpPortManagementMsgHeader.version'})
        if MessageType is not None:
            header.messageType1 = MessageType
            result.update({'MessageType': 'ancpPortManagementMsgHeader.messageType1'})
        if ResultField is not None:
            header.resultField = ResultField
            result.update({'ResultField': 'ancpPortManagementMsgHeader.resultField'})
        if ResultCode is not None:
            header.resultCode = ResultCode
            result.update({'ResultCode': 'ancpPortManagementMsgHeader.resultCode'})
        if PartitionId is not None:
            header.partitionID = PartitionId
            result.update({'PartitionId': 'ancpPortManagementMsgHeader.partitionID'})
        if TransactionId is not None:
            header.transactionID = TransactionId
            result.update({'TransactionId': 'ancpPortManagementMsgHeader.transactionID'})
        if Ignore is not None:
            header.ignore = Ignore
            result.update({'Ignore': 'ancpPortManagementMsgHeader.ignore'})
        if SubMessageNumber is not None:
            header.subMessageNum = SubMessageNumber
            result.update({'SubMessageNumber': 'ancpPortManagementMsgHeader.subMessageNum'})
        if Length2 is not None:
            header.len_ = Length2
            result.update({'Length2': 'ancpPortManagementMsgHeader.len'})
        if Unused is not None:
            header.unused = Unused
            result.update({'Unused': 'ancpPortManagementMsgHeader.unused'})
        if Function is not None:
            header.function = Function
            result.update({'Function': 'ancpPortManagementMsgHeader.function'})
        if XFunction is not None:
            header.xFunction = XFunction
            result.update({'XFunction': 'ancpPortManagementMsgHeader.xFunction'})
        if Unused2 is not None:
            header.unused2 = Unused2
            result.update({'Unused2': 'ancpPortManagementMsgHeader.unused2'})
        if ExtensionFlag is not None:
            header.extensionFlag = ExtensionFlag
            result.update({'ExtensionFlag': 'ancpPortManagementMsgHeader.extensionFlag'})
        if MessageType2 is not None:
            header.messageType2 = MessageType2
            result.update({'MessageType2': 'ancpPortManagementMsgHeader.messageType2'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'ancpPortManagementMsgHeader.reserved'})
        if NumberOfTlvs is not None:
            header.numberOfTLV = NumberOfTlvs
            result.update({'NumberOfTlvs': 'ancpPortManagementMsgHeader.numberOfTLV'})
        if ExtensionBlockLength is not None:
            header.extBlockLength = ExtensionBlockLength
            result.update({'ExtensionBlockLength': 'ancpPortManagementMsgHeader.extBlockLength'})
        if AccessLineIdentifyingTlvs is not None:
            header.accLineIdentifyingTLVs = AccessLineIdentifyingTlvs
        if TestingRelatedTlvs is not None:
            header.testRelatedTLVs = TestingRelatedTlvs
        if StatusInfoTlvs is not None:
            header.statusInfoTLVs = StatusInfoTlvs
        return result

    @abnormal_check()
    def edit_header_ancp_access_line_identifying_tlv(self, Stream, Level: int = 0,
                                                     TlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'portmanagement']
        header = headerList[Level]
        result.update(header.config_access_loop_circuit_id_tlv(TlvIndex=TlvIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ancp_testing_related_tlv(self, Stream, Level: int = 0,
                                             TlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'portmanagement']
        header = headerList[Level]
        result.update(header.config_testing_related_tlv(TlvIndex=TlvIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_ancp_status_info_tlv(self, Stream, Level: int = 0,
                                         TlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'portmanagement']
        header = headerList[Level]
        result.update(header.config_status_info_tlv(TlvIndex=TlvIndex, **kwargs))
        return result

    @abnormal_check()
    def edit_header_ancp_status_info_tlv_optional_sub_tlv(self, Stream, Level: int = 0,
                                                          TlvIndex=0, SubTlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'portmanagement']
        header = headerList[Level]
        result.update(
            header.config_status_info_tlv_optional_sub_tlv(TlvIndex=TlvIndex, SubTlvIndex=SubTlvIndex, **kwargs))
        return result if result else False

    # ------------------------- bier header -------------------------------------

    @abnormal_check()
    def edit_header_bier(self, Stream, Level: int = 0,
                         BiftId=None,
                         TrafficClass=None,
                         SBit=None,
                         Ttl=None,
                         Nibble=None,
                         BierVer=None,
                         Bsl=None,
                         Entropy=None,
                         Oam=None,
                         Rsv=None,
                         Dscp=None,
                         Protocol=None,
                         BfirId=None,
                         BierbitString=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'bier']
        header = headerList[Level]
        if BiftId is not None:
            header.biftId = BiftId
            result.update({'BiftId': 'biftId'})
        if TrafficClass is not None:
            header.trafficClass = TrafficClass
            result.update({'TrafficClass': 'trafficClass'})
        if SBit is not None:
            header.sBit = SBit
            result.update({'SBit': 'sBit'})
        if Ttl is not None:
            header.ttl = Ttl
            result.update({'Ttl': 'ttl'})
        if Nibble is not None:
            header.nibble = Nibble
            result.update({'Nibble': 'nibble'})
        if BierVer is not None:
            header.bierVer = BierVer
            result.update({'BierVer': 'bierVer'})
        if Bsl is not None:
            header.bsl = Bsl
            result.update({'Bsl': 'bsl'})
        if Entropy is not None:
            header.entropy = Entropy
            result.update({'Entropy': 'entropy'})
        if Oam is not None:
            header.oam = Oam
            result.update({'Oam': 'oam'})
        if Rsv is not None:
            header.rsv = Rsv
            result.update({'Rsv': 'rsv'})
        if Dscp is not None:
            header.dscp = Dscp
            result.update({'Dscp': 'dscp'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        if BfirId is not None:
            header.bfirId = BfirId
            result.update({'BfirId': 'bfirId'})
        if BierbitString is not None:
            header.bierbitString = BierbitString
        return result

    @abnormal_check()
    def edit_header_bier_bit_string(self, Stream, Level: int = 0,
                                    Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'bier']
        header = headerList[Level]
        result.update(header.config_bit_string(Index=Index, **kwargs))
        return result if result else False

    # ------------------------- eoam header -------------------------------------

    @abnormal_check()
    def edit_header_eoam(self, Stream, Level: int = 0,
                         MDlevel=None,
                         Version=None,
                         OpCode=None,
                         RDIbit=None,
                         Reserved=None,
                         CCMIntervalField=None,
                         FirstTLVOffset=None,
                         SequenceNumber=None,
                         MAEPI=None,
                         MDNF=None,
                         MDNL=None,
                         MDN=None,
                         SMAF=None,
                         SMAL=None,
                         SMAN=None,
                         Padding=None,
                         ITUTY1731=None,
                         Tlvs=None
                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        if MDlevel is not None:
            header.MDlevel = MDlevel
            result.update({'MDlevel': 'cfmHeader.MDlevel'})
        if Version is not None:
            header.Version = Version
            result.update({'Version': 'cfmHeader.Version'})
        if OpCode is not None:
            header.OpCode = OpCode
            result.update({'OpCode': 'OpCode'})
        if RDIbit is not None:
            header.RDIbit = RDIbit
            result.update({'RDIbit': 'RDIbit'})
        if Reserved is not None:
            header.Reserved = Reserved
            result.update({'Reserved': 'Reserved'})
        if CCMIntervalField is not None:
            header.CCMIntervalField = CCMIntervalField
            result.update({'CCMIntervalField': 'CCMIntervalField'})
        if FirstTLVOffset is not None:
            header.FirstTLVOffset = FirstTLVOffset
            result.update({'FirstTLVOffset': 'FirstTLVOffset'})
        if SequenceNumber is not None:
            header.SequenceNumber = SequenceNumber
            result.update({'SequenceNumber': 'SequenceNumber'})
        if MAEPI is not None:
            header.MAEPI = MAEPI
            result.update({'MAEPI': 'MAEPI'})
        if MDNF is not None:
            header.MDNF = MDNF
            result.update({'MDNF': 'MAID.MDNF'})
        if MDNL is not None:
            header.MDNL = MDNL
            result.update({'MDNL': 'MAID.theMDNL.MDNLength_0.MDNL'})
        if MDN is not None:
            header.MDN = MDN
            result.update({'MDN': 'MAID.theMDN.MaintenanceDomainName_0.MDN'})
        if SMAF is not None:
            header.SMAF = SMAF
            result.update({'SMAF': 'MAID.SMAF'})
        if SMAL is not None:
            header.SMAL = SMAL
            result.update({'SMAL': 'MAID.SMAL'})
        if SMAN is not None:
            header.SMAN = SMAN
            result.update({'SMAN': 'MAID.SMAN'})
        if Padding is not None:
            header.pad = Padding
            result.update({'Padding': 'MAID.thePad.Padding_0.pad'})
        if ITUTY1731 is not None:
            header.ITUTY1731 = ITUTY1731
            result.update({'ITUTY1731': 'ITU-TY1731'})
        if Tlvs is not None:
            header.Tlvs = Tlvs
        return result

    @abnormal_check()
    def edit_header_eoam_sender_id_tlv(self, Stream, Level: int = 0,
                                       Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        result.update(header.config_sender_id_tlv(Index=Index, **kwargs))
        return result

    @abnormal_check()
    def edit_header_eoam_sender_id_tlv_chassis_id(self, Stream, Type, Level: int = 0,
                                                  TlvIndex=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        result.update(header.config_sender_id_tlv_chassis_id(
            TlvIndex=TlvIndex, Index=Index, Type=Type, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_eoam_sender_id_tlv_management_address_domain(self, Stream, Type, Level: int = 0,
                                                                 TlvIndex=0, Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        result.update(header.config_sender_id_tlv_management_address_domain(
            TlvIndex=TlvIndex, Index=Index, Type=Type, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_eoam_port_status_tlv(self, Stream, Level: int = 0,
                                         Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        result.update(header.config_port_status_tlv(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_eoam_interface_status_tlv(self, Stream, Level: int = 0,
                                              Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        result.update(header.config_interface_status_tlv(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_eoam_organization_specific_tlv(self, Stream, Level: int = 0,
                                                   Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        result.update(header.config_organization_specific_tlv(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_eoam_end_tlv(self, Stream, Level: int = 0,
                                 Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ccm']
        header = headerList[Level]
        result.update(header.config_end_tlv(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_hdlc(self, Stream, Level: int = 0,
                         Address=None,
                         Value=None,
                         Protocol=None
                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'chdlc']
        header = headerList[Level]
        if Address is not None:
            header.address = Address
            result.update({'Address': 'address'})
        if Value is not None:
            header.value = Value
            result.update({'Value': 'value'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        return result if result else False

    @abnormal_check()
    def edit_header_control_word(self, Stream, Level: int = 0,
                                 Reserved=None,
                                 Flags=None,
                                 Fragment=None,
                                 Length=None,
                                 Sn=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'cw']
        header = headerList[Level]
        if Reserved is not None:
            header.rsvd = Reserved
            result.update({'Reserved': 'rsvd'})
        if Flags is not None:
            header.flags = Flags
            result.update({'Flags': 'flags'})
        if Fragment is not None:
            header.frg = Fragment
            result.update({'Fragment': 'frg'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Sn is not None:
            header.sn = Sn
            result.update({'Sn': 'sn'})
        return result if result else False

    @abnormal_check()
    def edit_header_els_flogi(self, Stream, Level: int = 0,
                              CommandCode=None,
                              FcPhVersion=None,
                              BtobCredit=None,
                              CommonFeatures=None,
                              Bbscn=None,
                              BtobDataFieldSize=None,
                              Reserved=None,
                              PortName=None,
                              NodeName=None,
                              Class1serviceOptions=None,
                              Class1InitatorControl=None,
                              Class1recipientControl=None,
                              Class1reserved1=None,
                              Class1totalConcurrentSeq=None,
                              Class1Nx_Porte2eCredit=None,
                              Class1reserved2=None,
                              Class1openSeqPerExchange=None,
                              Class1reserved3=None,
                              Class2serviceOptions=None,
                              Class2InitatorControl=None,
                              Class2recipientControl=None,
                              Class2reserved1=None,
                              Class2totalConcurrentSeq=None,
                              Class2Nx_Porte2eCredit=None,
                              Class2reserved2=None,
                              Class2openSeqPerExchange=None,
                              Class2reserved3=None,
                              Class3serviceOptions=None,
                              Class3InitatorControl=None,
                              Class3recipientControl=None,
                              Class3reserved1=None,
                              Class3totalConcurrentSeq=None,
                              Class3Nx_Porte2eCredit=None,
                              Class3reserved2=None,
                              Class3openSeqPerExchange=None,
                              Class3reserved3=None,
                              Obsolete=None,
                              VendorVersionLevel=None
                              ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'elsflogi']
        header = headerList[Level]
        if CommandCode is not None:
            header.commandCode = CommandCode
            result.update({'CommandCode': 'commandCode'})
        if FcPhVersion is not None:
            header.fcPhVersion = FcPhVersion
            result.update({'FcPhVersion': 'commonSvcPara.fcPhVersion'})
        if BtobCredit is not None:
            header.btobCredit = BtobCredit
            result.update({'BtobCredit': 'commonSvcPara.btobCredit'})
        if CommonFeatures is not None:
            header.commonFeatures = CommonFeatures
            result.update({'CommonFeatures': 'commonSvcPara.commonFeatures'})
        if Bbscn is not None:
            header.bbscn = Bbscn
            result.update({'Bbscn': 'commonSvcPara.bbscn'})
        if BtobDataFieldSize is not None:
            header.btobDataFieldSize = BtobDataFieldSize
            result.update({'BtobDataFieldSize': 'commonSvcPara.btobDataFieldSize'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'commonSvcPara.reserved'})
        if PortName is not None:
            header.portName = PortName
            result.update({'PortName': 'portName'})
        if NodeName is not None:
            header.nodeName = NodeName
            result.update({'NodeName': 'nodeName'})
        if Class1serviceOptions is not None:
            header.class1serviceOptions = Class1serviceOptions
            result.update({'Class1serviceOptions': 'class1SvcPara.serviceOptions'})
        if Class1InitatorControl is not None:
            header.class1InitatorControl = Class1InitatorControl
            result.update({'Class1InitatorControl': 'class1SvcPara.InitatorControl'})
        if Class1recipientControl is not None:
            header.class1recipientControl = Class1recipientControl
            result.update({'Class1recipientControl': 'class1SvcPara.recipientControl'})
        if Class1reserved1 is not None:
            header.class1reserved1 = Class1reserved1
            result.update({'Class1reserved1': 'class1SvcPara.reserved1'})
        if Class1totalConcurrentSeq is not None:
            header.class1totalConcurrentSeq = Class1totalConcurrentSeq
            result.update({'Class1totalConcurrentSeq': 'class1SvcPara.totalConcurrentSeq'})
        if Class1Nx_Porte2eCredit is not None:
            header.class1Nx_Porte2eCredit = Class1Nx_Porte2eCredit
            result.update({'Class1Nx_Porte2eCredit': 'class1SvcPara.Nx_Porte2eCredit'})
        if Class1reserved2 is not None:
            header.class1reserved2 = Class1reserved2
            result.update({'Class1reserved2': 'class1SvcPara.reserved2'})
        if Class1openSeqPerExchange is not None:
            header.class1openSeqPerExchange = Class1openSeqPerExchange
            result.update({'Class1openSeqPerExchange': 'class1SvcPara.openSeqPerExchange'})
        if Class1reserved3 is not None:
            header.class1reserved3 = Class1reserved3
            result.update({'Class1reserved3': 'class1SvcPara.reserved3'})
        if Class2serviceOptions is not None:
            header.class2serviceOptions = Class2serviceOptions
            result.update({'Class2serviceOptions': 'class2SvcPara.serviceOptions'})
        if Class2InitatorControl is not None:
            header.class2InitatorControl = Class2InitatorControl
            result.update({'Class2InitatorControl': 'class2SvcPara.InitatorControl'})
        if Class2recipientControl is not None:
            header.class2recipientControl = Class2recipientControl
            result.update({'Class2recipientControl': 'class2SvcPara.recipientControl'})
        if Class2reserved1 is not None:
            header.class2reserved1 = Class2reserved1
            result.update({'Class2reserved1': 'class2SvcPara.reserved1'})
        if Class2totalConcurrentSeq is not None:
            header.class2totalConcurrentSeq = Class2totalConcurrentSeq
            result.update({'Class2totalConcurrentSeq': 'class2SvcPara.totalConcurrentSeq'})
        if Class2Nx_Porte2eCredit is not None:
            header.class2Nx_Porte2eCredit = Class2Nx_Porte2eCredit
            result.update({'Class2Nx_Porte2eCredit': 'class2SvcPara.Nx_Porte2eCredit'})
        if Class2reserved2 is not None:
            header.class2reserved2 = Class2reserved2
            result.update({'Class2reserved2': 'class2SvcPara.reserved2'})
        if Class2openSeqPerExchange is not None:
            header.class2openSeqPerExchange = Class2openSeqPerExchange
            result.update({'Class2openSeqPerExchange': 'class2SvcPara.openSeqPerExchange'})
        if Class2reserved3 is not None:
            header.class2reserved3 = Class2reserved3
            result.update({'Class2reserved3': 'class2SvcPara.reserved3'})
        if Class3serviceOptions is not None:
            header.class3serviceOptions = Class3serviceOptions
            result.update({'Class3serviceOptions': 'class3SvcPara.serviceOptions'})
        if Class3InitatorControl is not None:
            header.class3InitatorControl = Class3InitatorControl
            result.update({'Class3InitatorControl': 'class3SvcPara.InitatorControl'})
        if Class3recipientControl is not None:
            header.class3recipientControl = Class3recipientControl
            result.update({'Class3recipientControl': 'class3SvcPara.recipientControl'})
        if Class3reserved1 is not None:
            header.class3reserved1 = Class3reserved1
            result.update({'Class3reserved1': 'class3SvcPara.reserved1'})
        if Class3totalConcurrentSeq is not None:
            header.class3totalConcurrentSeq = Class3totalConcurrentSeq
            result.update({'Class3totalConcurrentSeq': 'class3SvcPara.totalConcurrentSeq'})
        if Class3Nx_Porte2eCredit is not None:
            header.class3Nx_Porte2eCredit = Class3Nx_Porte2eCredit
            result.update({'Class3Nx_Porte2eCredit': 'class3SvcPara.Nx_Porte2eCredit'})
        if Class3reserved2 is not None:
            header.class3reserved2 = Class3reserved2
            result.update({'Class3reserved2': 'class3SvcPara.reserved2'})
        if Class3openSeqPerExchange is not None:
            header.class3openSeqPerExchange = Class3openSeqPerExchange
            result.update({'Class3openSeqPerExchange': 'class3SvcPara.openSeqPerExchange'})
        if Class3reserved3 is not None:
            header.class3reserved3 = Class3reserved3
            result.update({'Class3reserved3': 'class3SvcPara.reserved3'})
        if Obsolete is not None:
            header.obsolete = Obsolete
            result.update({'Obsolete': 'obsolete'})
        if VendorVersionLevel is not None:
            header.vendorVersionLevel = VendorVersionLevel
            result.update({'VendorVersionLevel': 'vendorVersionLevel'})
        return result if result else False

    @abnormal_check()
    def edit_header_goose(self, Stream, Level: int = 0,
                          Appid=None,
                          Length=None,
                          Reserve=None,
                          Reserve1=None,
                          Apdu=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'goose']
        header = headerList[Level]
        if Appid is not None:
            header.appid = Appid
            result.update({'Appid': 'appid'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Reserve is not None:
            header.reserve = Reserve
            result.update({'Reserve': 'reserve'})
        if Reserve1 is not None:
            header.reserve1 = Reserve1
            result.update({'Reserve1': 'reserve1'})
        if Apdu is not None:
            header.apdu = Apdu
            result.update({'Apdu': 'apdu'})
        return result if result else False

    @abnormal_check()
    def edit_header_mstp_config(self, Stream, Level: int = 0,
                                ProtocolIdentifier=None,
                                ProtocolVersionIdentifier=None,
                                BPDUType=None,
                                TopologyChangeAck=None,
                                Agreement=None,
                                Forwarding=None,
                                Learning=None,
                                PortRole=None,
                                Proposal=None,
                                TopologyChange=None,
                                RootBridgePriority=None,
                                RootSystemIdExtension=None,
                                RootBridgeSystemID=None,
                                RootPathCost=None,
                                BridgePriority=None,
                                BridgeSystemIdExtension=None,
                                BridgeSystemID=None,
                                PortIdentifier=None,
                                MessageAge=None,
                                MaxAge=None,
                                HelloTime=None,
                                ForwardDelay=None,
                                Version1Length=None,
                                Version3Length=None,
                                ConfigId=None,
                                ConfigName=None,
                                ConfigRevision=None,
                                ConfigDigest=None,
                                CistRootPathCost=None,
                                CistBridgePriority=None,
                                CistSystemIdExtension=None,
                                CistBridgeSystemID=None,
                                CistRemainingHops=None,
                                MstInstances=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'cfg']
        header = headerList[Level]
        if ProtocolIdentifier is not None:
            header.protocolIdentifier = ProtocolIdentifier
            result.update({'ProtocolIdentifier': 'protocolIdentifier'})
        if ProtocolVersionIdentifier is not None:
            header.protocolVersionIdentifier = ProtocolVersionIdentifier
            result.update({'ProtocolVersionIdentifier': 'protocolVersionIdentifier'})
        if BPDUType is not None:
            header.BPDUType = BPDUType
            result.update({'BPDUType': 'BPDUType'})
        if TopologyChangeAck is not None:
            header.topologyChangeAck = TopologyChangeAck
            result.update({'TopologyChangeAck': 'BPDUFlags.topologyChangeAck'})
        if Agreement is not None:
            header.agreement = Agreement
            result.update({'Agreement': 'BPDUFlags.agreement'})
        if Forwarding is not None:
            header.forwarding = Forwarding
            result.update({'Forwarding': 'BPDUFlags.forwarding'})
        if Learning is not None:
            header.learning = Learning
            result.update({'Learning': 'BPDUFlags.learning'})
        if PortRole is not None:
            header.portRole = PortRole
            result.update({'PortRole': 'BPDUFlags.portRole'})
        if Proposal is not None:
            header.proposal = Proposal
            result.update({'Proposal': 'BPDUFlags.proposal'})
        if TopologyChange is not None:
            header.topologyChange = TopologyChange
            result.update({'TopologyChange': 'BPDUFlags.topologyChange'})
        if RootBridgePriority is not None:
            header.rootBridgePriority = RootBridgePriority
            result.update({'RootBridgePriority': 'rootIdentifier.rootBridgePriority'})
        if RootSystemIdExtension is not None:
            header.rootSystemIdExtension = RootSystemIdExtension
            result.update({'RootSystemIdExtension': 'rootIdentifier.systemIdExtension'})
        if RootBridgeSystemID is not None:
            header.rootBridgeSystemID = RootBridgeSystemID
            result.update({'RootBridgeSystemID': 'rootIdentifier.rootBridgeSystemID'})
        if RootPathCost is not None:
            header.rootPathCost = RootPathCost
            result.update({'RootPathCost': 'rootPathCost'})
        if BridgePriority is not None:
            header.bridgePriority = BridgePriority
            result.update({'BridgePriority': 'bridgeIdentifier.bridgePriority'})
        if BridgeSystemIdExtension is not None:
            header.bridgeSystemIdExtension = BridgeSystemIdExtension
            result.update({'BridgeSystemIdExtension': 'bridgeIdentifier.systemIdExtension'})
        if BridgeSystemID is not None:
            header.bridgeSystemID = BridgeSystemID
            result.update({'BridgeSystemID': 'bridgeIdentifier.bridgeSystemID'})
        if PortIdentifier is not None:
            header.portIdentifier = PortIdentifier
            result.update({'PortIdentifier': 'portIdentifier'})
        if MessageAge is not None:
            header.messageAge = MessageAge
            result.update({'MessageAge': 'messageAge'})
        if MaxAge is not None:
            header.maxAge = MaxAge
            result.update({'MaxAge': 'maxAge'})
        if HelloTime is not None:
            header.helloTime = HelloTime
            result.update({'HelloTime': 'helloTime'})
        if ForwardDelay is not None:
            header.forwardDelay = ForwardDelay
            result.update({'ForwardDelay': 'forwardDelay'})
        if Version1Length is not None:
            header.version1Length = Version1Length
            result.update({'Version1Length': 'version1Length'})
        if Version3Length is not None:
            header.version3Length = Version3Length
            result.update({'Version3Length': 'version3Length'})
        if ConfigId is not None:
            header.configId = ConfigId
            result.update({'ConfigId': 'mstExtension.configId'})
        if ConfigName is not None:
            header.configName = ConfigName
            result.update({'ConfigName': 'mstExtension.configName'})
        if ConfigRevision is not None:
            header.configRevision = ConfigRevision
            result.update({'ConfigRevision': 'mstExtension.configRevision'})
        if ConfigDigest is not None:
            header.configDigest = ConfigDigest
            result.update({'ConfigDigest': 'mstExtension.configDigest'})
        if CistRootPathCost is not None:
            header.cistRootPathCost = CistRootPathCost
            result.update({'CistRootPathCost': 'mstExtension.cistRootPathCost'})
        if CistBridgePriority is not None:
            header.cistBridgePriority = CistBridgePriority
            result.update({'CistBridgePriority': 'mstExtension.cistBridgeIdentifier.bridgePriority'})
        if CistSystemIdExtension is not None:
            header.cistSystemIdExtension = CistSystemIdExtension
            result.update({'CistSystemIdExtension': 'mstExtension.cistBridgeIdentifier.systemIdExtension'})
        if CistBridgeSystemID is not None:
            header.cistBridgeSystemID = CistBridgeSystemID
            result.update({'CistBridgeSystemID': 'mstExtension.cistBridgeIdentifier.bridgeSystemID'})
        if CistRemainingHops is not None:
            header.cistRemainingHops = CistRemainingHops
            result.update({'CistRemainingHops': 'mstExtension.cistRemainingHops'})
        if MstInstances is not None:
            header.mstInstances = MstInstances
        return result

    @abnormal_check()
    def edit_header_mstp_config_mst_instance(self, Stream, Level: int = 0,
                                             Index=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'cfg']
        header = headerList[Level]
        result.update(header.config_mst_instance(Index=Index, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_pause(self, Stream, Level: int = 0,
                          PauseCode=None,
                          PauseTime=None):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pause']
        header = headerList[Level]
        if PauseCode is not None:
            header.pauseCode = PauseCode
            result.update({'PauseCode': 'pauseCode'})
        if PauseTime is not None:
            header.pauseTime = PauseTime
            result.update({'PauseTime': 'pauseTime'})
        return result if result else False

    @abnormal_check()
    def edit_header_pfc(self, Stream, Level: int = 0,
                        OpCode=None,
                        MsOctet=None,
                        P7=None,
                        P6=None,
                        P5=None,
                        P4=None,
                        P3=None,
                        P2=None,
                        P1=None,
                        P0=None,
                        Time0=None,
                        Time1=None,
                        Time2=None,
                        Time3=None,
                        Time4=None,
                        Time5=None,
                        Time6=None,
                        Time7=None,
                        ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'pfc']
        header = headerList[Level]
        if OpCode is not None:
            header.opCode = OpCode
            result.update({'OpCode': 'opCode'})
        if MsOctet is not None:
            header.msOctet = MsOctet
            result.update({'MsOctet': 'priorityEnableVector.msOctet'})
        if P7 is not None:
            header.p7 = P7
            result.update({'P7': 'priorityEnableVector.p7'})
        if P6 is not None:
            header.p6 = P6
            result.update({'P6': 'priorityEnableVector.p6'})
        if P5 is not None:
            header.p5 = P5
            result.update({'P5': 'priorityEnableVector.p5'})
        if P4 is not None:
            header.p4 = P4
            result.update({'P4': 'priorityEnableVector.p4'})
        if P3 is not None:
            header.p3 = P3
            result.update({'P3': 'priorityEnableVector.p3'})
        if P2 is not None:
            header.p2 = P2
            result.update({'P2': 'priorityEnableVector.p2'})
        if P1 is not None:
            header.p1 = P1
            result.update({'P1': 'priorityEnableVector.p1'})
        if P0 is not None:
            header.p0 = P0
            result.update({'P0': 'priorityEnableVector.p0'})
        if Time0 is not None:
            header.time0 = Time0
            result.update({'Time0': 'time0'})
        if Time1 is not None:
            header.time1 = Time1
            result.update({'Time1': 'time1'})
        if Time2 is not None:
            header.time2 = Time2
            result.update({'Time2': 'time2'})
        if Time3 is not None:
            header.time3 = Time3
            result.update({'Time3': 'time3'})
        if Time4 is not None:
            header.time4 = Time4
            result.update({'Time4': 'time4'})
        if Time5 is not None:
            header.time5 = Time5
            result.update({'Time5': 'time5'})
        if Time6 is not None:
            header.time6 = Time6
            result.update({'Time6': 'time6'})
        if Time7 is not None:
            header.time7 = Time7
            result.update({'Time7': 'time7'})
        return result if result else False

    @abnormal_check()
    def edit_header_vntag(self, Stream, Level: int = 0,
                          Ver=None,
                          Res=None,
                          Dir=None,
                          Pointer=None,
                          DstVif=None,
                          SrcVif=None,
                          Looped=None,
                          Protocol=None,
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'vntag']
        header = headerList[Level]
        if Ver is not None:
            header.ver = Ver
            result.update({'Ver': 'ver'})
        if Res is not None:
            header.res = Res
            result.update({'Res': 'res'})
        if Dir is not None:
            header.dir = Dir
            result.update({'Dir': 'dir'})
        if Pointer is not None:
            header.pointer = Pointer
            result.update({'Pointer': 'pointer'})
        if DstVif is not None:
            header.dstVif = DstVif
            result.update({'DstVif': 'dstVif'})
        if SrcVif is not None:
            header.srcVif = SrcVif
            result.update({'SrcVif': 'srcVif'})
        if Looped is not None:
            header.looped = Looped
            result.update({'Looped': 'looped'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        return result if result else False

    @abnormal_check()
    def edit_header_fibre_channel(self, Stream, Level: int = 0,
                                  Rctl=None,
                                  DestAddr=None,
                                  Csctl=None,
                                  SourceAddr=None,
                                  Type=None,
                                  FrameControl=None,
                                  SeqID=None,
                                  DataField=None,
                                  SeqCount=None,
                                  OriginatorExchangeID=None,
                                  ResponseExchangeID=None,
                                  ParaRelativeOffset=None,
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'fc']
        header = headerList[Level]
        if Rctl is not None:
            header.rctl = Rctl
            result.update({'Rctl': 'rctl'})
        if DestAddr is not None:
            header.destAddr = DestAddr
            result.update({'DestAddr': 'destAddr'})
        if Csctl is not None:
            header.csctl = Csctl
            result.update({'Csctl': 'csctl'})
        if SourceAddr is not None:
            header.sourceAddr = SourceAddr
            result.update({'SourceAddr': 'sourceAddr'})
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if FrameControl is not None:
            header.frameControl = FrameControl
            result.update({'FrameControl': 'frameControl'})
        if SeqID is not None:
            header.seqID = SeqID
            result.update({'SeqID': 'seqID'})
        if DataField is not None:
            header.dataField = DataField
            result.update({'DataField': 'dataField'})
        if SeqCount is not None:
            header.seqCount = SeqCount
            result.update({'SeqCount': 'seqCount'})
        if OriginatorExchangeID is not None:
            header.originatorExchangeID = OriginatorExchangeID
            result.update({'OriginatorExchangeID': 'originatorExchangeID'})
        if ResponseExchangeID is not None:
            header.responseExchangeID = ResponseExchangeID
            result.update({'ResponseExchangeID': 'responseExchangeID'})
        if ParaRelativeOffset is not None:
            header.paraRelativeOffset = ParaRelativeOffset
            result.update({'ParaRelativeOffset': 'paraRelativeOffset'})
        return result if result else False

    @abnormal_check()
    def edit_header_vxlan(self, Stream, Level: int = 0,
                          Flags=None,
                          Reserved1=None,
                          Vni=None,
                          Reserved2=None,
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'vxlan']
        header = headerList[Level]
        if Flags is not None:
            header.flags = Flags
            result.update({'Flags': 'flags'})
        if Reserved1 is not None:
            header.reserved1 = Reserved1
            result.update({'Reserved1': 'reserved1'})
        if Vni is not None:
            header.VNI = Vni
            result.update({'Vni': 'VNI'})
        if Reserved2 is not None:
            header.reserved2 = Reserved2
            result.update({'Reserved2': 'reserved2'})
        return result if result else False

    @abnormal_check()
    def edit_header_lldp_chassisId(self, Stream, Level: int = 0,
                                   Type=None,
                                   Length=None,
                                   ChassisIdSubType=None,
                                   IanaAddressFamily=None,
                                   ChassisId=None
                                   ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'chassisidtlv']
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if ChassisIdSubType is not None:
            header.chassisIdSubType = ChassisIdSubType
            result.update({'ChassisIdSubType': 'chassisId.networkAddress4.chassisIdSubType'})
        if IanaAddressFamily is not None:
            header.ianaAddressFamily = IanaAddressFamily
            result.update({'IanaAddressFamily': 'chassisId.networkAddress4.ianaAddressFamily'})
        if ChassisId is not None:
            header.chassisId = ChassisId
            result.update({'ChassisId': 'chassisId.networkAddress4.chassisId'})
        return result if result else False

    @abnormal_check()
    def edit_header_lldp_portId(self, Stream, Level: int = 0,
                                Type=None,
                                Length=None,
                                PortIdSubType=None,
                                PortId=None
                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'portidtlv']
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if PortIdSubType is not None:
            header.portIdSubType = PortIdSubType
            result.update({'PortIdSubType': 'portId.macAddr.portIdSubType'})
        if PortId is not None:
            header.portId = PortId
            result.update({'PortId': 'portId.macAddr.portId'})
        return result if result else False

    @abnormal_check()
    def edit_header_lldp_ttl(self, Stream, Level: int = 0,
                             Type=None,
                             Length=None,
                             Ttl=None
                             ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'ttltlv']
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        if Ttl is not None:
            header.ttl = Ttl
            result.update({'Ttl': 'ttl'})
        return result if result else False

    @abnormal_check()
    def edit_header_lldp_end(self, Stream, Level: int = 0,
                             Type=None,
                             Length=None
                             ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'endtlv']
        header = headerList[Level]
        if Type is not None:
            header.type = Type
            result.update({'Type': 'type'})
        if Length is not None:
            header.length = Length
            result.update({'Length': 'length'})
        return result if result else False

    @abnormal_check()
    def edit_header_hsr_tag(self, Stream, Level: int = 0,
                            PathId=None,
                            LsduSize=None,
                            SeqNum=None,
                            Protocol=None
                            ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'hsrtag']
        header = headerList[Level]
        if PathId is not None:
            header.pathid = PathId
            result.update({'PathId': 'pathid'})
        if LsduSize is not None:
            header.lsdusize = LsduSize
            result.update({'LsduSize': 'lsdusize'})
        if SeqNum is not None:
            header.seqnum = SeqNum
            result.update({'SeqNum': 'seqnum'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        return result if result else False

    @abnormal_check()
    def edit_header_prp_tag(self, Stream, Level: int = 0,
                            SequenceNumber=None,
                            LanId=None,
                            LsduSize=None,
                            PrpSuffix=None,
                            ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'prptag']
        header = headerList[Level]
        if SequenceNumber is not None:
            header.seqnum = SequenceNumber
            result.update({'SequenceNumber': 'seqnum'})
        if LanId is not None:
            header.lanid = LanId
            result.update({'LanId': 'lanid'})
        if LsduSize is not None:
            header.lsdusize = LsduSize
            result.update({'LsduSize': 'lsdusize'})
        if PrpSuffix is not None:
            header.prpsuffix = PrpSuffix
            result.update({'PrpSuffix': 'prpsuffix'})
        return result if result else False

    @abnormal_check()
    def edit_header_r_tag(self, Stream, Level: int = 0,
                          Reserved=None,
                          SeqNum=None,
                          Protocol=None
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'rtag']
        header = headerList[Level]
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if SeqNum is not None:
            header.seqnum = SeqNum
            result.update({'SeqNum': 'seqnum'})
        if Protocol is not None:
            header.protocol = Protocol
            result.update({'Protocol': 'protocol'})
        return result if result else False

    @abnormal_check()
    def edit_header_sctp(self, Stream, Level: int = 0,
                         SourcePort=None,
                         DestPort=None,
                         VerTag=None,
                         Checksum=None,
                         ChunkList=None
                         ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        if SourcePort is not None:
            header.sourcePort = SourcePort
            result.update({'SourcePort': 'header.sourcePort'})
        if DestPort is not None:
            header.destPort = DestPort
            result.update({'DestPort': 'header.destPort'})
        if VerTag is not None:
            header.verTag = VerTag
            result.update({'VerTag': 'header.verTag'})
        if Checksum is not None:
            header.checksum = Checksum
            result.update({'Checksum': 'header.checksum'})
        if ChunkList is not None:
            header.chunkList = ChunkList
        return result

    @abnormal_check()
    def edit_header_sctp_chunk(self, Stream, ChunkType, Level: int = 0,
                               ChunkIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        header.insert_chunk_type(Index=ChunkIndex, Type=ChunkType)
        if ChunkType == 'DataChunk':
            result.update(header.edit_data_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'InitChunk':
            result.update(header.edit_init_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'InitAckChunk':
            result.update(header.edit_init_ack_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'SAckChunk':
            result.update(header.edit_sack_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'HeartbeatChunk':
            result.update(header.edit_heartbeat_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'HeartbeatAckChunk':
            result.update(header.edit_heartbeat_ack_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'AbortChunk':
            result.update(header.edit_abort_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'ShutdownChunk':
            result.update(header.edit_shutdown_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'ShutdownAckChunk':
            result.update(header.edit_shutdown_ack_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'ErrorChunk':
            result.update(header.edit_error_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'CookieEchoChunk':
            result.update(header.edit_cookie_echo_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'CookieAckChunk':
            result.update(header.edit_cookie_ack_chunk(Index=ChunkIndex, **kwargs))
        elif ChunkType == 'ShutdownCompleteChunk':
            result.update(header.edit_shutdown_complete_chunk(Index=ChunkIndex, **kwargs))
        return result

    @abnormal_check()
    def edit_header_sctp_init_optional_parameters_tlv(self, Stream, ChunkType, Level: int = 0,
                                                      ChunkIndex=0, TlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        result.update(header.edit_init_optional_parameters_tlv(ChunkType=ChunkType,
                                                               ChunkIndex=ChunkIndex,
                                                               TlvIndex=TlvIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_sctp_sack_chunk_gap_ack_block(self, Stream, Level: int = 0,
                                                  ChunkIndex=0, BlockIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        result.update(header.edit_sack_chunk_gap_ack_block(ChunkIndex=ChunkIndex, BlockIndex=BlockIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_sctp_sack_chunk_duplicate_tsn(self, Stream, Level: int = 0,
                                                  ChunkIndex=0, TsnIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        result.update(header.edit_sack_chunk_duplicate_tsn(ChunkIndex=ChunkIndex, TsnIndex=TsnIndex, **kwargs))
        return result if result else False

    @abnormal_check()
    def edit_header_sctp_chunk_error_cause(self, Stream, ChunkType, CauseType, Level: int = 0,
                                                       ChunkIndex=0, CauseIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        result.update(header.edit_abort_error_chunk_error_cause(ChunkType=ChunkType,
                                                                CauseType=CauseType,
                                                                ChunkIndex=ChunkIndex,
                                                                CauseIndex=CauseIndex, **kwargs))
        return result

    @abnormal_check()
    def edit_header_sctp_chunk_error_cause_missing_parameter_type(self, Stream, ChunkType, Level: int = 0,
                                                                  ChunkIndex=0, CauseIndex=0, TypeIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        result.update(header.edit_abort_error_chunk_error_cause_missing_parameter_type(ChunkType=ChunkType,
                                                                                       ChunkIndex=ChunkIndex,
                                                                                       CauseIndex=CauseIndex,
                                                                                       TypeIndex=TypeIndex, **kwargs))
        return result

    @abnormal_check()
    def edit_header_sctp_chunk_error_cause_unrecognized_parameter_tlv(self, Stream, ChunkType, Level: int = 0,
                                                                                  ChunkIndex=0, CauseIndex=0, TlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        result.update(header.edit_abort_error_chunk_error_cause_unrecognized_parameter_tlv(ChunkType=ChunkType,
                                                                                           ChunkIndex=ChunkIndex,
                                                                                           CauseIndex=CauseIndex,
                                                                                           TlvIndex=TlvIndex, **kwargs))
        return result

    @abnormal_check()
    def edit_header_sctp_chunk_error_cause_new_address_tlv(self, Stream, ChunkType, CauseType, Level: int = 0,
                                                           ChunkIndex=0, CauseIndex=0, TlvIndex=0, **kwargs):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'sctp']
        header = headerList[Level]
        result.update(header.edit_error_cause_new_address_tlv(ChunkType=ChunkType,
                                                              ChunkIndex=ChunkIndex,
                                                              CauseType=CauseType,
                                                              CauseIndex=CauseIndex,
                                                              TlvIndex=TlvIndex, **kwargs))
        return result

    @abnormal_check()
    def edit_header_trill(self, Stream, Level: int = 0,
                          Version=None,
                          Reserved=None,
                          MultiDestination=None,
                          OptionLength=None,
                          HopCount=None,
                          EgressRBridge=None,
                          IngressBridge=None,
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == 'trill']
        header = headerList[Level]
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        if MultiDestination is not None:
            header.multiDestination = MultiDestination
            result.update({'MultiDestination': 'multiDestination'})
        if OptionLength is not None:
            header.optionLength = OptionLength
            result.update({'OptionLength': 'optionLength'})
        if HopCount is not None:
            header.hopCount = HopCount
            result.update({'HopCount': 'hopCount'})
        if EgressRBridge is not None:
            header.egressRBridge = EgressRBridge
            result.update({'EgressRBridge': 'egressRBridge'})
        if IngressBridge is not None:
            header.ingressBridge = IngressBridge
            result.update({'IngressBridge': 'ingressBridge'})
        return result if result else False


    # ------------------------- GATHER header modifier-------------------------------------
    @abnormal_check()
    def edit_modifier(self, Stream, Attribute,
                      Level=0,
                      Index=None,
                      HeaderType=None,
                      Type=None,
                      Start=None,
                      Count=None,
                      Step=None,
                      Range=None,
                      Seed=None,
                      StreamType=None,
                      Offset=None,
                      Repeat=None,
                      Mask=None,
                      List=None, ):
        if isinstance(Stream, (set, tuple, list)):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        if HeaderType is None:
            header = headerList[Level]
        else:
            headerList = [x for x in headerList if x.header_type == str(HeaderType).lower()]
            header = headerList[Level]
        if Attribute.split('.')[0] not in STREAM_HEADER_FIELD:
            Attribute = Attribute[:1].lower() + Attribute[1:]
        modifier = Modifier(Header=header, Attribute=Attribute, Mode="merge", Index=Index)
        # modifier = Modifier(Header=header, Attribute=trans_first_letter_to_lower(Attribute), Mode="merge")
        if Type is not None:
            modifier.Type = Type
        if Start is not None:
            modifier.Start = Start
        if Count is not None:
            modifier.Count = Count
        if Step is not None:
            modifier.Step = Step
        if Range is not None:
            modifier.Range = Range
        if Seed is not None:
            modifier.Seed = Seed
        if StreamType is not None:
            modifier.StreamType = StreamType
        if Offset is not None:
            modifier.Offset = Offset
        if Mask is not None:
            modifier.Mask = Mask
        if Repeat is not None:
            modifier.Repeat = Repeat
        if List is not None:
            modifier.List = List
        modifier.apply()
        return {'Stream': Stream, 'Header': modifier.Header.name, 'Attribute': modifier.Attribute, 'Index': modifier.Index}

    @abnormal_check()
    def edit_modifier_link(self, Stream, Link, LinkModifierType='MODIFIER_ID', BindingModifier=False):
        if isinstance(Stream, (set, tuple, list)):
            Stream = Stream[0]
        params = []
        if not isinstance(Link[0], (set, list, tuple)):
            param = "{}.{}.XetModifier:{}".format(Link[0]['Header'], Link[0]['Attribute'], Link[0]['Index']) + '='
            for i in Link[1:]:
                param = param + '{},'.format(i['Index'])
            params.append(param[:-1])
        else:
            for li in Link:
                param = "{}.{}.XetModifier:{}".format(li[0]['Header'], li[0]['Attribute'], li[0]['Index']) + '='
                for i in li[1:]:
                    param = param + '{},'.format(i['Index'])
                params.append(param[:-1])
        update_link_modifier_cmd = UpdateLinkModifierCommand(Stream=Stream.handle,
                                                                  Parameter=params,
                                                                  LinkModifierType=LinkModifierType, BindingModifier=BindingModifier)

        update_link_modifier_cmd.execute()
        return True

    @abnormal_check()
    def create_interface(self, Port, Layers=None, Tops=None, **kwargs):
        # Parameter type check
        flag = False
        if Layers is None:
            flag = True
            Layers = ["eth", "ipv4"]
        if not isinstance(Layers, (list, set, tuple)):
            Layers = [Layers]
        if isinstance(Port, list):
            interfaces = [Interface(upper=x, **kwargs) for x in Port]
            handles = [x.handle for x in interfaces]
        else:
            interfaces = Interface(upper=Port, **kwargs)
            handles = interfaces.handle
        Layers = [x.lower() for x in Layers]
        if Tops is None and len(Layers) <= 2:
            BuildInterfaceCommand(InterfaceList=handles, NetworkLayers=Layers, cl_instance=self.cl_instance).execute()
        elif Tops is None and len(Layers) > 2:
            BuildInterfaceCommand(InterfaceList=handles, NetworkLayers=Layers[0], TopLayers=Layers[1:], cl_instance=self.cl_instance).execute()
        else:
            if flag:
                Layers = None
            self.edit_interface_stack(Interfaces=interfaces, Layers=Layers, Tops=Tops)
        return interfaces

    @abnormal_check()
    def edit_interface_stack(self, Interfaces, Layers=None, Tops=None):
        if not isinstance(Interfaces, (list, set, tuple)):
            Interfaces = [Interfaces]
        if Layers is None:
            Layers = ["eth"]
        else:
            if not isinstance(Layers, (list, set, tuple)):
                Layers = [Layers]
        if Tops is None:
            Tops = ''
        Layers = [x.lower() for x in Layers]
        if 'l2tp' in Layers:
            TopLayers = ''
            if Tops != '' and not isinstance(Tops, (list, set, tuple)):
                tempTops = [Tops.lower()]
            elif isinstance(Tops, (list, set, tuple)):
                tempTops = [i.lower() for i in Tops]
            else:
                tempTops = Tops
            NetworkLayers = Layers[:Layers.index('l2tp')] + tempTops + Layers[Layers.index('l2tp'):]
        else:
            NetworkLayers = Layers
            if Tops != '' and not isinstance(Tops, (list, set, tuple)):
                TopLayers = [Tops.lower()]
            elif isinstance(Tops, (list, set, tuple)):
                TopLayers = [i.lower() for i in Tops]
            else:
                TopLayers = Tops
        ReplaceInterfaceStackCommand(InterfaceList=[x.handle for x in Interfaces], NetworkLayers=NetworkLayers,
                                     TopLayers=TopLayers, cl_instance=self.cl_instance).execute()
        result = {}
        for interface in Interfaces:
            lower_list = interface.get_relatives('lower')
            for i in lower_list:
                if isinstance(i, NetworkLayer):
                    a = i.get_relatives("lowerlayer", direction=EnumRelationDirection.TARGET)
                    if not a:
                        firstlayer = i
                        break
            interface_layer = [firstlayer]
            while True:
                layer = firstlayer.get_relatives("lowerlayer", direction=EnumRelationDirection.SOURCE)
                if layer:
                    interface_layer.append(layer[0])
                    firstlayer = layer[0]
                else:
                    break
            result.update({interface: interface_layer})
        return result if result else False

    @abnormal_check()
    def edit_interface(self, Interface, Layer=None, Level=None, **kwargs):
        result = EnumBase.TRUE.value
        if not isinstance(Interface, (set, list, tuple)):
            Interface = [Interface]
        for interface in Interface:
            layers = None
            # Parameter type check
            if Layer is not None:
                if type(Layer) is not str:
                    raise ValueError("Layer type error")
            if Layer is not None:
                layers = interface.get_children(Layer)
            for k, v in kwargs.items():
                if Layer is None:
                    if hasattr(interface, k):
                        setattr(interface, str(k), v)
                else:
                    if Level:
                        if hasattr(layers[int(Level)], k):
                            setattr(layers[int(Level)], str(k), v)
                    else:
                        for layer in layers:
                            if hasattr(layer, k):
                                setattr(layer, str(k), v)
        return result

    @abnormal_check()
    def add_stream(self,
                   Type="raw",
                   Ports=None,
                   Names=None,
                   FilePath=None,
                   IncludeCrc=True,
                   SrcPoints=None,
                   DstPoints=None,
                   SrcInterface=None,
                   DstInterface=None,
                   Bidirection=None,
                   Direction=None,
                   Layer=None,
                   TrafficMeshMode=None,
                   EndpointMapping=None,
                   AutoCreateTunnel=False,
                   StreamOnly=None,
                   **kwargs):
        if Type.lower() == "binding":
            if Layer is not None:
                if Layer.lower() == "ethernetii" or Layer.lower() == "eth":
                    layer = "EthIILayer"
                    TopLayerType = 0
                elif Layer.lower() == "vlan":
                    layer = "VlanLayer"
                    TopLayerType = 3
                elif Layer.lower() == "gre":
                    layer = "GreIpv4Layer"
                    TopLayerType = 4
                elif Layer.lower() == "ipv6":
                    layer = "Ipv6Layer"
                    TopLayerType = 2
                else:
                    layer = "Ipv4Layer"
                    TopLayerType = 1
            else:
                layer = "Ipv4Layer"
                TopLayerType = None
            if SrcPoints is None:
                if not isinstance(SrcInterface, list):
                    srcEndpoint = [SrcInterface.get_children(layer)[0]]
                else:
                    srcEndpoint = [x.get_children(layer)[0] for x in SrcInterface]
            else:
                if not isinstance(SrcPoints, list):
                    srcEndpoint = [SrcPoints]
                else:
                    srcEndpoint = SrcPoints
            if DstPoints is None:
                if not isinstance(DstInterface, list):
                    dstEndpoint = [DstInterface.get_children(layer)[0]]
                else:
                    dstEndpoint = [x.get_children(layer)[0] for x in DstInterface]
            else:
                if not isinstance(DstPoints, list):
                    dstEndpoint = [DstPoints]
                else:
                    dstEndpoint = DstPoints
            stream = self.add_binding_stream(SrcEndpointHandles=[x.handle for x in srcEndpoint],
                                             DstEndpointHandles=[x.handle for x in dstEndpoint],
                                             Bidirection=Bidirection, Direction=Direction, TopLayerType=TopLayerType,
                                             TrafficMeshMode=TrafficMeshMode, EndpointMapping=EndpointMapping,
                                             AutoCreateTunnel=AutoCreateTunnel)
        elif Type.lower() == "pcap":
            if isinstance(Ports, (list, set, tuple)):
                ports = Ports
            else:
                ports = [Ports]
            create_stream_from_pcap_cmd = CreateStreamFromPcapCommand(PortList=[x.handle for x in ports],
                                                                      FilePath=FilePath,
                                                                      IncludeCrc=IncludeCrc,
                                                                      cl_instance=self.cl_instance
                                                                      )
            create_stream_from_pcap_cmd.execute()
            stream = [self.rom_manager.get_object(x, cl=self.cl_instance) for x in create_stream_from_pcap_cmd.PcapStreams]
        else:
            stream = self.add_raw_stream(Ports=Ports)
        if isinstance(stream, list) and len(stream) != 1:
            num = 1
            for x in stream:
                if Names is not None: self.edit_stream(Stream=x, Name=f'{Names}_{num}')
                self.edit_stream(Stream=x, **kwargs)
                num += 1
        else:
            if Names is not None: self.edit_stream(Stream=stream, Name=Names)
            self.edit_stream(Stream=stream, **kwargs)
        if StreamOnly is not None:
            if isinstance(stream, (list, set, tuple)):
                for x in stream:
                    x.StreamOnly = StreamOnly
            else:
                stream.StreamOnly = StreamOnly
        return stream

    @abnormal_check()
    def edit_port_load_profile(self, Ports, **kwargs):
        result = EnumBase.TRUE.value
        if not isinstance(Ports, (list, set, tuple)):
            Ports = [Ports]
        for port in Ports:
            tem = kwargs.copy()
            kwarg = kwargs.copy()
            streamPortConfig = port.get_children('StreamPortConfig')[0]
            if "TransmitMode" in kwarg.keys():
                if kwarg["TransmitMode"] == "ONSTREAM" and self.sys_entry.ProductType.value != 0:
                    raise TesterException("Only product type BigTao support ONSTREAM")
                streamPortConfig.TransmitMode = kwarg["TransmitMode"]
                tem.pop("TransmitMode")
            kwarg = tem.copy()
            if "InterFrameGapUnit" in kwarg.keys() or "InterFrameGap" in kwarg.keys() or "BurstSize" in kwarg.keys():
                if "BurstSize" in kwarg.keys():
                    streamPortConfig.BurstSize = kwarg["BurstSize"]
                    tem.pop("BurstSize")
                kwarg = tem.copy()
                if streamPortConfig.BurstSize == 1:
                    if "InterFrameGapUnit" in kwarg.keys() or "InterFrameGap" in kwarg.keys():
                        raise TesterException("BurstSize should not be 1 when edit InterFrameGapUnit or InterFrameGap")
                if "InterFrameGapUnit" in kwarg.keys():
                    streamPortConfig.InterFrameGapUnit = kwarg["InterFrameGapUnit"]
                    tem.pop("InterFrameGapUnit")
            kwarg = tem.copy()
            for k, v in kwarg.items():
                if hasattr(streamPortConfig, k):
                    setattr(streamPortConfig, str(k), v)
                    tem.pop(k)
            kwarg = tem.copy()
            if 'PORT_BASE' in str(streamPortConfig.LoadProfileType):
                interFrameGapProfile = streamPortConfig.get_children('InterFrameGapProfile')
                if interFrameGapProfile:
                    interFrameGapProfile = interFrameGapProfile[0]
                else:
                    interFrameGapProfile = InterFrameGapProfile(upper=streamPortConfig)
                if "Unit" in kwarg.keys():
                    interFrameGapProfile.Unit = kwarg["Unit"]
                    tem.pop("Unit")
                if "Rate" in kwarg.keys():
                    interFrameGapProfile.Rate = kwarg["Rate"]
                    tem.pop("Rate")
            kwarg = tem.copy()
            if 'STREAM_BASE' in str(streamPortConfig.LoadProfileType):
                if "LoadMode" in kwarg.keys() and self.sys_entry.ProductType.value != 0:
                    raise TesterException("Only product type BigTao support ONSTREAM to set LoadMode")
                streamLoadProfile = streamPortConfig.get_children('StreamLoadProfile')[0]
                if "LoadMode" in kwarg.keys():
                    setattr(streamLoadProfile, "Unit", kwarg["LoadMode"])
                    tem.pop("LoadMode")
            transmitMode = streamPortConfig.TransmitMode
            if 'BURST' in str(transmitMode):
                burstTransConfig = streamPortConfig.get_children('BurstTransmitConfig')[0]
                kwarg = tem.copy()
                for k, v in kwarg.items():
                    if hasattr(burstTransConfig, k):
                        setattr(burstTransConfig, str(k), v)
                        tem.pop(k)
            elif 'TIME' in str(transmitMode):
                timeTransConfig = streamPortConfig.get_children('TimeTransmitConfig')[0]
                kwarg = tem.copy()
                for k, v in kwarg.items():
                    if hasattr(timeTransConfig, k):
                        setattr(timeTransConfig, str(k), v)
                        tem.pop(k)
            elif 'STEP' in str(transmitMode):
                stepTransConfig = streamPortConfig.get_children('StepTransmitConfig')[0]
                kwarg = tem.copy()
                for k, v in kwarg.items():
                    if hasattr(stepTransConfig, k):
                        setattr(stepTransConfig, str(k), v)
                        tem.pop(k)
            if bool(tem):
                raise TesterException("Parameter {} setting failed".format(str(tem.keys())))
        return result

    @abnormal_check()
    def edit_stream_load_profile(self, Streams, **kwargs):
        result = EnumBase.TRUE.value
        if not isinstance(Streams, list):
            Streams = [Streams]
        for stream in Streams:
            tem = kwargs.copy()
            kwarg = kwargs.copy()
            stream.get_parent()
            port = stream.upper
            streamPortConfig = port.get_children('StreamPortConfig')[0]
            if "PORT_BASE" in str(streamPortConfig.LoadProfileType):
                if self.sys_entry.ProductType.value != 0:
                    raise TesterException("{} port load profile should not be PORT_BASE".format(stream.Name))
                else:
                    if "ONSTREAM" not in str(streamPortConfig.TransmitMode):
                        raise TesterException(
                            "{} port load profile should not be PORT_BASE and transmit mode should not be ONSTREAM at the same time".format(
                                stream.Name))
            if "PORT_BASE" not in str(streamPortConfig.LoadProfileType):
                streamTemplateLoadProfile = stream.get_children('StreamTemplateLoadProfile')[0]
                if "Unit" in kwarg.keys():
                    streamTemplateLoadProfile.Unit = kwarg["Unit"]
                    tem.pop("Unit")
                kwarg = tem.copy()
                for k, v in kwarg.items():
                    if hasattr(streamTemplateLoadProfile, k):
                        setattr(streamTemplateLoadProfile, str(k), v)
                        tem.pop(k)
            if "ONSTREAM" in str(streamPortConfig.TransmitMode):
                streamTransConfig = stream.get_children('StreamTransmitConfig')[0]
                if "Unit" in kwarg.keys():
                    streamTransConfig.Unit = kwarg["Unit"]
                    tem.pop("Unit")
                kwarg = tem.copy()
                for k, v in kwarg.items():
                    if hasattr(streamTransConfig, k):
                        setattr(streamTransConfig, str(k), v)
                        tem.pop(k)
            if bool(tem):
                raise TesterException("Parameter {} setting failed".format(str(tem.keys())))
        return result

    @abnormal_check()
    def load_profile(self, BaseOn='port', Objects=None, LoadMode=None, **kwargs):
        """
        config load profile.

        :param BaseOn:
            'port'
            'stream'
        :param Objects:
            port object when base on port.
            stream object when base on stream.
        :param LoadMode:
            load mode for base on stream
            'FRAME_PER_SEC'
            'BYTE_PER_SEC'
        :param kwargs:
            (StreamPortConfig:)
            TransmitMode='CONTINUOUS'
            GenerateError='NO_ERROR'
            IgnoreLinkState='NO'
            TimeStampPosTx='TIMESTAMP_HEAD'
            TimeStampPosRx='TIMESTAMP_HEAD'
            LatencyCompensationTx=0
            LatencyCompensationRx=0
            LatencyCompensationOn=True
            InterFrameGap=12.0(daryu)
            BurstSize=1(daryu)
            InterFrameGapUnit='BYTES'(daryu)
            (InterFrameGapProfile:)
            Rate=10
            Unit=PERCENT
            (StreamTemplateLoadProfile:)
            Rate=10
            Unit=PERCENT
            (BurstTransmitConfig:)
            FramePerBurst=1
            BurstCount=1
            BurstGap=1
            BurstGapUnit='SEC'
            (StepTransmitConfig:)
            Frames=1
            (TimeTransmitConfig:)
            Seconds=100
            (StreamTransmitConfig:)
            StreamTransmitMode=CONTINUOUS
            FramePerBurst=1
            BurstCount=1
            BurstGap=1
            BurstGapUnit='SEC'

        :return:
            True
            False
        """
        result = EnumBase.TRUE.value
        # def la(kw, ob k): kw, ob, k, v: setattr(ob, str(k), v) if hasattr(ob, k) else kw.pop(k)
        if not isinstance(Objects, list):
            Objects = [Objects]
        for object in Objects:
            if BaseOn == 'port':
                port = object
                stream_port_config = port.get_children('StreamPortConfig')[0]
                inter_frame_gap_profile = stream_port_config.get_children('InterFrameGapProfile')[0]
            elif BaseOn == 'stream':
                port = object.get_parent()
                stream_port_config = port.get_children('StreamPortConfig')[0]
                stream_port_config.edit(LoadProfileType='STREAM_BASE')
                stream_template_load_profile = object.get_children('StreamTemplateLoadProfile')[0]
                if LoadMode is not None:
                    stream_load_profile = stream_port_config.get_children('StreamLoadProfile')[0]
                    stream_load_profile.edit(Unit=LoadMode)
            else:
                print('Not support the load profile mode now:', BaseOn)
                return
                # later...
            tmp = kwargs.copy()
            for k, v in kwargs.items():
                if hasattr(stream_port_config, k):
                    setattr(stream_port_config, str(k), v)
                    tmp.pop(k)
                elif BaseOn == 'port' and hasattr(inter_frame_gap_profile, k):
                    setattr(inter_frame_gap_profile, str(k), v)
                    tmp.pop(k)
                elif BaseOn == 'stream' and hasattr(stream_template_load_profile, k):
                    setattr(stream_template_load_profile, str(k), v)
                    tmp.pop(k)

            if stream_port_config.get():
                transmit_mode = stream_port_config.TransmitMode
                if 'BURST' in str(transmit_mode):
                    burst_trans_config = stream_port_config.get_children('BurstTransmitConfig')[0]
                    for k, v in tmp.items():
                        if hasattr(burst_trans_config, k):
                            setattr(burst_trans_config, str(k), v)
                elif 'TIME' in str(transmit_mode):
                    step_trans_config = stream_port_config.get_children('TimeTransmitConfig')[0]
                    for k, v in tmp.items():
                        if hasattr(step_trans_config, k):
                            setattr(step_trans_config, str(k), v)
                elif 'STEP' in str(transmit_mode):
                    time_trans_config = stream_port_config.get_children('StepTransmitConfig')[0]
                    for k, v in tmp.items():
                        if hasattr(time_trans_config, k):
                            setattr(time_trans_config, str(k), v)
                elif 'ONSTREAM' in str(transmit_mode):
                    if BaseOn == 'port':
                        streams = port.get_children('StreamTemplate')
                        for stream in streams:
                            stream_trans_config = StreamTransmitConfig(upper=stream)
                            for k, v in tmp.items():
                                if hasattr(stream_trans_config, k):
                                    setattr(stream_trans_config, str(k), v)
                    elif BaseOn == 'stream':
                        stream_trans_config = StreamTransmitConfig(upper=object)
                        for k, v in tmp.items():
                            if hasattr(stream_trans_config, k):
                                setattr(stream_trans_config, str(k), v)
                else:
                    # CONTINUOUS
                    pass

        return result

    @abnormal_check()
    def create_imix(self, Name, Seed=None):
        return IMix(Name=Name, Seed=Seed)

    @abnormal_check()
    def get_imix_from_name(self, Name):
        return map_name_imix[Name]

    @abnormal_check()
    def add_imix_distribution_frame(self, IMix, Type="fixed", Length=None, Min=None, Max=None, Weight=None):
        return IMix.add_frame_length(Type=Type, Length=Length, Min=Min, Max=Max, Weight=Weight)

    @abnormal_check()
    def del_imix_distribution_frame(self, IMix, Index: int = None):
        return IMix.del_frame_length(Index=Index)

    @abnormal_check()
    def bind_stream_imix(self, Stream, IMix):
        if isinstance(Stream, (list, set, tuple)):
            Stream = Stream[0]
        result = EnumBase.TRUE.value
        if Stream.FrameLengthType is not EnumFrameLengthType.IMIX:
            Stream.FrameLengthType = 5
        # streamImixTemplate = Stream.get_relatives('ImixTemplate', EnumRelationDirection.TARGET, 'StreamImixTemplate')[0]
        # set_relatives(self, relation_name, relation_obj, direction=EnumRelationDirection.TARGET)
        if isinstance(IMix, StreamImixTemplate):
            Stream.set_relatives('ImixTemplate', IMix, EnumRelationDirection.TARGET)
        else:
            Stream.set_relatives('ImixTemplate', IMix.template, EnumRelationDirection.TARGET)
            map_stream_imix.update({Stream: IMix})
        return result

    @abnormal_check()
    def get_port_statistic(self, Port, StaItems=None, Mode=True, ResultView=False):
        if isinstance(Port, (list, set, tuple)) and len(Port) > 1:
            portHandle = [x.handle for x in Port]
        elif Port is None:
            portHandle = None
        else:
            if isinstance(Port, (list, set, tuple)):
                Port = Port[0]
            portHandle = Port.handle
        result = self._get_statictis(Statictis="PortStats",
                                     Idx={'PortHandle': portHandle},
                                     StaItems=StaItems, Mode=Mode, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_port_latency_statistic(self, Port=None, StaItems=None, Mode=True):
        if isinstance(Port, (list, set, tuple)) and len(Port) > 1:
            portName = [x.Name for x in Port]
        elif Port is None:
            portName = None
        else:
            if isinstance(Port, (list, set, tuple)):
                Port = Port[0]
            portName = Port.Name
        result = self._get_statictis(Statictis="PortAvgLatencyStats",
                                     Idx={'PortID': portName},
                                     StaItems=StaItems, Mode=Mode)
        return result

    @abnormal_check()
    def get_streamblock_statistic(self, Stream, StaItems, Mode=True, ResultView=False):
        if isinstance(Stream, (list, set, tuple)) and len(Stream) > 1:
            streamBlockID = [x.Name for x in Stream]
        elif Stream is None:
            streamBlockID = None
        else:
            if isinstance(Stream, (list, set, tuple)):
                Stream = Stream[0]
            streamBlockID = Stream.Name
        result = self._get_statictis(Statictis="StreamBlockStats",
                                     Idx={'StreamBlockID': streamBlockID},
                                     StaItems=StaItems, Mode=Mode, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_l2tpsession_statistic(self, Session, NodeIndexInBlock, StaItems=None, ResultViewType=1):
        if isinstance(Session, list):
            Session = Session[0]
        if StaItems is None:
            # renixCmd = ListROMPropertiesCommand(ROMName='L2tpSessionStatistic', cl_instance=self.cl_instance)
            # renixCmd.execute()
            # StaItems = renixCmd.Properties
            StaItems = L2TPSESSIONSTATISTIC.keys()
        result = None
        if self.mode == 'db':
            if self.__statictis:
                self.__statictis = False
                self._get_statictis_from_database()
            mapNameID = [Session.Name, str(NodeIndexInBlock)]
            for x in self.__statictisData['L2tpSessionStatistic']:
                if mapNameID == [x[L2TPSESSIONSTATISTIC['L2tpBlockId']],
                                 str(x[L2TPSESSIONSTATISTIC['NodeIndexInBlock']])]:
                    result = {y: x[L2TPSESSIONSTATISTIC[y]] for y in StaItems}
                    # self.logger.info(StaItems)
                    break
        else:
            if ResultViewType == 1:
                resultViews = self.sys_entry.get_children('pageResultView')
                resultViews = [x for x in resultViews if x.DataClassName == 'L2tpSessionStatistic']
                mapNameID = [Session.Name, str(NodeIndexInBlock)]
                for view in resultViews:
                    if result is not None:
                        break
                    if view.RecordCount % view.RecordPerPage == 0:
                        record_count = int(view.RecordCount / view.RecordPerPage)
                    else:
                        record_count = int(view.RecordCount / view.RecordPerPage) + 1
                    for i in range(record_count):
                        if result is not None:
                            break
                        else:
                            if i != 0:
                                GotoResultPageCommand(ResultViewHandle=view.handle, PageNumber=i + 1, cl_instance=self.cl_instance).execute()
                                time.sleep(3)
                            view.get()
                            resultQuerys = view.get_children()
                            for query in resultQuerys:
                                query.get()
                                if result is not None:
                                    break
                                else:
                                    resultStreamStats = query.get_children('L2tpSessionStatistic')
                                    if resultStreamStats is not None:
                                        for x in resultStreamStats:
                                            x.get()
                                            if mapNameID == [x.L2tpBlockId, str(x.NodeIndexInBlock)]:
                                                result = {y: getattr(x, y) for y in StaItems}
                                                break
            else:
                resultViews = self.sys_entry.get_children('ResultView')
                resultViews = [x for x in resultViews if x.DataClassName == 'L2tpSessionStatistic']
                mapNameID = [Session.Name, str(NodeIndexInBlock)]
                for view in resultViews:
                    if result is not None:
                        break
                    view.get()
                    resultQuerys = view.get_children()
                    for query in resultQuerys:
                        query.get()
                        if result is not None:
                            break
                        else:
                            resultStreamStats = query.get_children('L2tpSessionStatistic')
                            if resultStreamStats is not None:
                                for x in resultStreamStats:
                                    x.get()
                                    if mapNameID == [x.L2tpBlockId, str(x.NodeIndexInBlock)]:
                                        result = {y: getattr(x, y) for y in StaItems}
                                        break
        if result is None:
            result = EnumBase.FALSE.value
        return result

    @abnormal_check()
    def get_l2tpblock_statistic(self, Session, StaItems=None, ResultViewType=1):
        if isinstance(Session, list):
            Session = Session[0]
        if StaItems is None:
            renixCmd = ListROMPropertiesCommand(ROMName='L2tpBlockStatistic', cl_instance=self.cl_instance)
            renixCmd.execute()
            StaItems = renixCmd.Properties
        result = None
        if self.mode == '123456789':
            if self.__statictis:
                self.__statictis = False
                self._get_statictis_from_database()
            mapNameID = [Session.Name]
            for x in self.__statictisData['L2tpSessionStatistic']:
                if mapNameID == [x[L2TPSESSIONSTATISTIC['L2tpBlockId']]]:
                    result = {y: x[L2TPSESSIONSTATISTIC[y]] for y in StaItems}
                    # self.logger.info(StaItems)
                    break
        else:
            if ResultViewType == 1:
                resultViews = self.sys_entry.get_children('pageResultView')
                resultViews = [x for x in resultViews if x.DataClassName == 'L2tpBlockStatistic']
                mapNameID = [Session.Name]
                for view in resultViews:
                    if result is not None:
                        break
                    if view.RecordCount % view.RecordPerPage == 0:
                        record_count = int(view.RecordCount / view.RecordPerPage)
                    else:
                        record_count = int(view.RecordCount / view.RecordPerPage) + 1
                    for i in range(record_count):
                        if result is not None:
                            break
                        else:
                            if i != 0:
                                GotoResultPageCommand(ResultViewHandle=view.handle, PageNumber=i + 1, cl_instance=self.cl_instance).execute()
                                time.sleep(3)
                            view.get()
                            resultQuerys = view.get_children()
                            for query in resultQuerys:
                                query.get()
                                if result is not None:
                                    break
                                else:
                                    resultStreamStats = query.get_children('L2tpBlockStatistic')
                                    if resultStreamStats is not None:
                                        for x in resultStreamStats:
                                            x.get()
                                            if mapNameID == [x.L2tpBlockId]:
                                                result = {y: getattr(x, y) for y in StaItems}
                                                break
            else:
                resultViews = self.sys_entry.get_children('ResultView')
                resultViews = [x for x in resultViews if x.DataClassName == 'L2tpBlockStatistic']
                mapNameID = [Session.Name]
                for view in resultViews:
                    if result is not None:
                        break
                    view.get()
                    resultQuerys = view.get_children()
                    for query in resultQuerys:
                        query.get()
                        if result is not None:
                            break
                        else:
                            resultStreamStats = query.get_children('L2tpBlockStatistic')
                            if resultStreamStats is not None:
                                for x in resultStreamStats:
                                    x.get()
                                    if mapNameID == [x.L2tpBlockId]:
                                        result = {y: getattr(x, y) for y in StaItems}
                                        break
        if result is None:
            result = EnumBase.FALSE.value
        return result

    @abnormal_check()
    def get_streamblock_tx_statistic(self, Stream=None, Port=None, StaItems=None, Mode=True):
        if Stream is None:
            streamBlockID = None
        elif isinstance(Stream, (list, set, tuple)):
            streamBlockID = [x.Name for x in Stream]
        else:
            streamBlockID = Stream.Name
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.handle for x in Port]
        else:
            portID = Port.handle
        result = self._get_statictis(Statictis="StreamBlockTxStats",
                                     Idx={'StreamBlockID': streamBlockID, 'PortID': portID},
                                     StaItems=StaItems, Mode=Mode)
        return result

    @abnormal_check()
    def get_streamblock_rx_statistic(self, Stream=None, Port=None, StaItems=None, Mode=True):
        if Stream is None:
            streamBlockID = None
        elif isinstance(Stream, (list, set, tuple)):
            streamBlockID = [x.Name for x in Stream]
        else:
            streamBlockID = Stream.Name
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.handle for x in Port]
        else:
            portID = Port.handle
        result = self._get_statictis(Statictis="StreamBlockRxStats",
                                     Idx={'StreamBlockID': streamBlockID, 'PortID': portID},
                                     StaItems=StaItems, Mode=Mode)
        return result

    @abnormal_check()
    def get_stream_tx_statistic(self, Stream=None, Port=None, StreamID=None, StaItems=None, Mode=True):
        if Stream is None:
            streamBlockID = None
        elif isinstance(Stream, (list, set, tuple)):
            streamBlockID = [x.Name for x in Stream]
        else:
            streamBlockID = Stream.Name
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.handle for x in Port]
        else:
            portID = Port.handle
        result = self._get_statictis(Statictis="StreamTxStats",
                                     Idx={'StreamBlockID': streamBlockID, 'StreamID': StreamID, 'PortID': portID},
                                     StaItems=StaItems, Mode=Mode)
        return result

    @abnormal_check()
    def get_stream_rx_statistic(self, Stream=None, Port=None, StreamID=None, StaItems=None, Mode=True):
        if Stream is None:
            streamBlockID = None
        elif isinstance(Stream, (list, set, tuple)):
            streamBlockID = [x.Name for x in Stream]
        else:
            streamBlockID = Stream.Name
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.handle for x in Port]
        else:
            portID = Port.handle
        result = self._get_statictis(Statictis="StreamRxStats",
                                     Idx={'StreamBlockID': streamBlockID, 'StreamID': StreamID, 'PortID': portID},
                                     StaItems=StaItems, Mode=Mode)
        return result

    @abnormal_check()
    def start_l2_learning(self, Type=None, Ports=None, Streams=None, WaitLearningDone=True, WaitTime=30):
        result = EnumBase.TRUE.value
        if not isinstance(Ports, list) and Ports is not None:
            Ports = [Ports]
        if not isinstance(Streams, list) and Streams is not None:
            Streams = [Streams]
        if Ports is not None and Streams is None:
            streamHandles = []
            for p in Ports:
                streamHandles = streamHandles + [x.handle for x in p.get_children('StreamTemplate')]
        elif Ports is None and Streams is not None:
            streamHandles = [x.handle for x in Streams]
        elif Ports is None and Streams is None:
            streamHandles = [x.handle for y in self.sys_entry.get_children('Port') for x in
                             y.get_children('StreamTemplate')]
        else:
            raise TesterException("Can not use Port and Stream at the same time")
        if Type is None:
            renixCmd = StartL2LearningCommand(StreamHandles=streamHandles, WaitLearningDone=WaitLearningDone,
                                              WaitTime=WaitTime, cl_instance=self.cl_instance)
        else:
            renixCmd = StartL2RxLearningCommand(StreamHandles=streamHandles, cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def stop_l2_learning(self, Ports=None, Streams=None):
        result = EnumBase.TRUE.value
        if not isinstance(Ports, list) and Ports is not None:
            Ports = [Ports]
        if not isinstance(Streams, list) and Streams is not None:
            Streams = [Streams]
        if Ports is not None and Streams is None:
            stream = []
            for p in Ports:
                stream = stream + p.get_children('StreamTemplate')
            renixCmd = StopL2LearningCommand(StreamHandles=[x.handle for x in stream], cl_instance=self.cl_instance)
            renixCmd.execute()
        elif Ports is None and Streams is not None:
            renixCmd = StopL2LearningCommand(StreamHandles=[x.handle for x in Streams], cl_instance=self.cl_instance)
            renixCmd.execute()
        elif Ports is None and Streams is None:
            streamHandles = [x.handle for y in self.sys_entry.get_children('Port') for x in
                             y.get_children('StreamTemplate')]
            renixCmd = StopL2LearningCommand(StreamHandles=streamHandles, cl_instance=self.cl_instance)
            renixCmd.execute()
        else:
            raise TesterException("Can not use Port and Stream at the same time")
        return result

    @abnormal_check()
    def start_l3_learning(self, Ports=None, Streams=None):
        result = EnumBase.TRUE.value
        if not isinstance(Ports, list) and Ports is not None:
            Ports = [Ports]
        if not isinstance(Streams, list) and Streams is not None:
            Streams = [Streams]
        if Ports is not None and Streams is None:
            streamHandles = []
            for p in Ports:
                streamHandles = streamHandles + [x.handle for x in p.get_children('StreamTemplate')]
        elif Ports is None and Streams is not None:
            streamHandles = [x.handle for x in Streams]
        elif Ports is None and Streams is None:
            renixCmd = StartAllStreamArpCommand(cl_instance=self.cl_instance)
            renixCmd.execute()
            return result
        else:
            raise TesterException("Can not use Port and Stream at the same time")
        renixCmd = StartStreamArpCommand(StreamHandles=streamHandles, cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def stop_l3_learning(self, Ports=None, Streams=None):
        result = EnumBase.TRUE.value
        if not isinstance(Ports, list) and Ports is not None:
            Ports = [Ports]
        if not isinstance(Streams, list) and Streams is not None:
            Streams = [Streams]
        if Ports is not None and Streams is None:
            stream = []
            for p in Ports:
                stream = stream + p.get_children('StreamTemplate')
            renixCmd = StopStreamArpCommand(StreamHandles=[x.handle for x in stream], cl_instance=self.cl_instance)
            renixCmd.execute()
        elif Ports is None and Streams is not None:
            renixCmd = StopStreamArpCommand(StreamHandles=[x.handle for x in Streams], cl_instance=self.cl_instance)
            renixCmd.execute()
        elif Ports is None and Streams is None:
            renixCmd = StopAllStreamArpCommand(cl_instance=self.cl_instance)
            renixCmd.execute()
        else:
            raise TesterException("Can not use Port and Stream at the same time")
        return result

    @abnormal_check()
    def start_protocol(self, Ports=None, Protocols=None, Objects=None):
        result = EnumBase.TRUE.value
        if Objects is not None:
            if Ports is not None or Protocols is not None:
                raise TesterException("Port and Protocol should be None when Object is not None")
            else:
                if not isinstance(Objects, list) and Objects is not None:
                    Objects = [Objects]
                renixCmd = StartProtocolCommand(ProtocolList=[x.handle for x in Objects], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if not isinstance(Protocols, list) and Protocols is not None:
                Protocols = [Protocols]
            if Ports is None and Protocols is None:
                renixCmd = StartAllProtocolCommand(cl_instance=self.cl_instance)
            else:
                protocolHandles = []
                if Ports is not None and Protocols is None:
                    for p in Ports:
                        for pr in [list(x.keys())[0] for x in PROTOCOL_MAP.values()]:
                            protocolHandles = protocolHandles + p.get_children(pr)
                elif Ports is not None and Protocols is not None:
                    for p in Ports:
                        for pr in [list(PROTOCOL_MAP[x.lower()].keys())[0] for x in Protocols]:
                            protocolHandles = protocolHandles + p.get_children(pr)
                renixCmd = StartProtocolCommand(ProtocolList=[x.handle for x in protocolHandles], cl_instance=self.cl_instance)
        renixCmd.execute()
        self.__statictis = True
        return result

    @abnormal_check()
    def stop_protocol(self, Ports=None, Protocols=None, Objects=None):
        result = EnumBase.TRUE.value
        if Objects is not None:
            if Ports is not None or Protocols is not None:
                raise TesterException("Port and Protocol should be None when Object is not None")
            else:
                if not isinstance(Objects, list) and Objects is not None:
                    Objects = [Objects]
                renixCmd = StopProtocolCommand(ProtocolList=[x.handle for x in Objects], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if not isinstance(Protocols, list) and Protocols is not None:
                Protocols = [Protocols]
            if Ports is None and Protocols is None:
                renixCmd = StopAllProtocolCommand(cl_instance=self.cl_instance)
            else:
                protocolHandles = []
                if Ports is not None and Protocols is None:
                    for p in Ports:
                        for pr in [list(x.keys())[0] for x in PROTOCOL_MAP.values()]:
                            protocolHandles = protocolHandles + p.get_children(pr)
                elif Ports is not None and Protocols is not None:
                    for p in Ports:
                        for pr in [list(PROTOCOL_MAP[x.lower()].keys())[0] for x in Protocols]:
                            protocolHandles = protocolHandles + p.get_children(pr)
                renixCmd = StopProtocolCommand(ProtocolList=list(set([x.handle for x in protocolHandles])), cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def simple_filter_template_pattern(self, Ports, Layers, Pattern, **kwargs):
        """
        config simple filter template pattern

        :param Ports:
            port object list
        :param Layers:
            "Ethernet.ethernetII IPv4.ipv4"
        :param Pattern:
            "ethernetII_1.sourceMacAdd=00:01:01:a0:00:01"
        :param kwargs:
            AutoDelete=True
        :return:
            True
            False
        """
        result = EnumBase.TRUE.value
        for port in Ports:
            filterStatsConfig = port.get_children('FilterStatsConfig')[0]
            streamFilterSimplePattern = StreamFilterSimplePattern(upper=filterStatsConfig)
            editSimpleFilterTemplatePatternCommand = EditSimpleFilterTemplatePatternCommand(
                cl_instance = self.cl_instance,
                FilterPatternHandle=streamFilterSimplePattern.handle,
                HeaderTypes=Layers, HeaderParameters=Pattern)
            editSimpleFilterTemplatePatternCommand.execute(cl_instance=self.cl_instance)
        return result

    @abnormal_check()
    def capture_config(self, Ports, **kwargs):
        """
        config capture mode / cache capability and other related parameter.
        :param Ports:
            port object list
        :param kwargs:
            CaptureMode=ALL
            CacheCapacity=Cache_Max
            BufferFullAction=STOP
            StartingFrameIndex=1
            AttemptDownloadPacketCount=0
            FcsError=False
            Ipv4ChecksumError=False
            PayloadError=False
            EnableRealtimeCapture=False
            MaxRealtimeCaptureFrameCount=100
            SliceMode=Disable
            SliceByteSize=128

        :return:
        """
        result = EnumBase.TRUE.value
        for port in Ports:
            captureConfig = port.get_children('CaptureConfig')[0]
            for k, v in kwargs:
                if hasattr(captureConfig, k):
                    setattr(captureConfig, str(k), v)
        return result

    @abnormal_check()
    def capture_byte_pattern(self, Ports, **kwargs):
        """
        create byte pattern capture

        :param Ports:
            port object list
        :param kwargs:
            CustomCapturePatternOperator='AND'
            CustomCapturePatternNot=False
            UseFrameLength=False
            Data='0x0'
            MaxData='0xff'
            Mask='0xff'
            Offset=0
            MinFrameLength=64
            MaxFrameLength=16383

        :return:
            True
            False
        """
        result = EnumBase.TRUE.value
        for port in Ports:
            captureConfig = port.get_children('CaptureConfig')[0]
            captureByteFilter = captureConfig.get_children('CaptureBytePattern')[0]
            if captureByteFilter == "":
                captureByteFilter = CaptureByteFilter(upper=captureConfig)
            for k, v in kwargs:
                if hasattr(captureByteFilter, k):
                    setattr(captureByteFilter, str(k), v)
        return result

    @abnormal_check()
    def capture_pdu_pattern(self, Ports, **kwargs):
        """
        create pdu pattern capture

        :param Ports:
            port object list
        :param kwargs:
            CustomCapturePatternOperator='AND'
            CustomCapturePatternNot=False
            Value="00:00:02:02:01:02"
            MaxValue="00:00:02:02:01:02"
            Mask="FF:FF:FF:FF:FF:FF"
            TemplateString="00:00:02:02:01:02"
        :return:
            True
            False
        """
        result = EnumBase.TRUE.value

        if not isinstance(Ports, list):
            Ports = [Ports]

        for port in Ports:

            captureConfig = port.get_children('CaptureConfig')[0]

            capturePduFilters = captureConfig.get_children('CapturePduFilter')
            if capturePduFilters:
                capturePduFilter = capturePduFilters[0]
            else:
                capturePduFilter = CapturePduFilter(upper=captureConfig)

            capturePduPatterns = capturePduFilter.get_children('CapturePduPattern')
            if capturePduPatterns:
                capturePduPattern = capturePduPatterns[0]
            else:
                capturePduPattern = CapturePduPattern(upper=capturePduFilter)

            for k, v in kwargs:
                if hasattr(capturePduPattern, k):
                    setattr(capturePduPattern, str(k), v)

        return result

    @abnormal_check()
    def capture_event(self, Ports, **kwargs):
        """
        config capture event

        :param Ports:
            port object list
        :param kwargs:
            LogicRelation='AND'
            PatternMatch='INCLUDE'
            FcsError='IGNORE'
            PrbsError='IGNORE'
            Ipv4ChecksumError='IGNORE'
            TcpChecksumError='IGNORE'
            UdpChecksumError='IGNORE'
            IgmpChecksumError='IGNORE'
            IcmpChecksumError='IGNORE'
            SequenceError='IGNORE'
            UndersizedFrame='IGNORE'
            OversizedFrame='IGNORE'
            JumboFrame='IGNORE'
            FrameLength='IGNORE'
            FrameLengthValue=0
            SignaturePresent='IGNORE'
            StreamIdMatch='IGNORE'
            StreamId=0
            Ipv4Packets='IGNORE'
            TcpPackets='IGNORE'
            UdpPackets='IGNORE'
            Ipv6Packets='IGNORE'
            IgmpPackets='IGNORE'
            PayloadError='IGNORE'
        :return:
            True
            False
        """
        result = EnumBase.TRUE.value
        for port in Ports:
            captureConfig = port.get_children('CaptureConfig')[0]
            captureEvent = CaptureEvent(upper=captureConfig)
            for k, v in kwargs:
                if hasattr(captureEvent, k):
                    setattr(captureEvent, str(k), v)
        return result

    def _create_capture_event(self, Ports, **kwargs):
        for port in Ports:
            captureConfig = port.get_children('CaptureConfig')[0]
            captureEvent = captureConfig.get_children('CaptureEvent')
            if not captureEvent:
                captureEvent = CaptureEvent(upper=captureConfig)
                for k, v in kwargs:
                    if hasattr(captureEvent, k):
                        setattr(captureEvent, str(k), v)
        return True

    @abnormal_check()
    def start_capture(self, Ports=None, Objects=None):
        result = EnumBase.TRUE.value
        if Objects is not None:
            if Ports is not None:
                raise TesterException("Port and Protocol should be None when Object is not None")
            else:
                if not isinstance(Objects, list) and Objects is not None:
                    Objects = [Objects]
                renixCmd = StartCaptureCommand(CaptureConfigs=[x.handle for x in Objects], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if Ports is None:
                renixCmd = StartAllCaptureCommand(cl_instance=self.cl_instance)
            else:
                captureConfigs = []
                for p in Ports:
                    captureConfigs = captureConfigs + p.get_children("CaptureConfig")
                renixCmd = StartCaptureCommand(CaptureConfigs=[x.handle for x in captureConfigs], cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def stop_capture(self, Ports=None, Objects=None):
        result = EnumBase.TRUE.value
        if Objects is not None:
            if Ports is not None:
                raise TesterException("Port and Protocol should be None when Object is not None")
            else:
                if not isinstance(Objects, list) and Objects is not None:
                    Objects = [Objects]
                renixCmd = StopCaptureCommand(CaptureConfigs=[x.handle for x in Objects], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if Ports is None:
                renixCmd = StopAllCaptureCommand(cl_instance=self.cl_instance)
            else:
                captureConfigs = []
                for p in Ports:
                    captureConfigs = captureConfigs + p.get_children("CaptureConfig")
                renixCmd = StopCaptureCommand(CaptureConfigs=[x.handle for x in captureConfigs], cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def edit_capture(self, Ports, **kwargs):
        if not isinstance(Ports, (list, set, tuple)):
            Ports = [Ports]
        captures = [x.get_children('CaptureConfig')[0] for x in Ports]
        for capture in captures:
            capture.edit(**kwargs)
        return True

    @abnormal_check()
    def create_capture_byte_pattern(self, Port, **kwargs):
        if isinstance(Port, (list, set, tuple)):
            Port = Port[0]
        capture = Port.get_children('CaptureConfig')[0]
        filter = capture.get_children('CapturePduFilter')
        if filter:
            capturePduFilter = filter[0]
        else:
            capturePduFilter = CapturePduFilter(upper=capture)
        pattern = CaptureBytePattern(upper=capturePduFilter, **kwargs)
        return pattern.handle

    @abnormal_check()
    def create_capture_pdu_pattern(self, Port, HeaderTypes, **kwargs):
        if isinstance(Port, (list, set, tuple)):
            Port = Port[0]
        capture = Port.get_children('CaptureConfig')[0]
        filter = capture.get_children('CapturePduFilter')
        if filter:
            capturePduFilter = filter[0]
        else:
            capturePduFilter = CapturePduFilter(upper=capture)
        pattern = CapturePduPattern(upper=capturePduFilter)
        if 'TemplateString' in list(kwargs.keys()):
            pattern.edit(TemplateString=kwargs['TemplateString'])
            kwargs.pop('TemplateString')
        if not isinstance(HeaderTypes, list):
            HeaderTypes = [HeaderTypes]
        headerTypes = [list(MAP_HEADER_TRANSFORM[x.lower()].values())[0] for x in HeaderTypes]
        param = {}
        if 'Value' in list(kwargs.keys()):
            param.update({'Value': kwargs.pop('Value')})
        if 'MaxValue' in list(kwargs.keys()):
            param.update({'MaxValue': kwargs.pop('MaxValue')})
        if 'Mask' in list(kwargs.keys()):
            param.update({'Mask': kwargs.pop('Mask')})
        if 'Offset' in list(kwargs.keys()):
            param.update({'Offset': kwargs.pop('Offset')})
        if 'Level' in list(kwargs.keys()):
            levelHeaderTypes = [x.split('.')[-1] for x in headerTypes]
            tempList = levelHeaderTypes[:int(kwargs['Level'])]
            index = tempList.count(levelHeaderTypes[int(kwargs['Level'])])
            fieldName = levelHeaderTypes[int(kwargs['Level'])] + f'_{index + 1}.' + str(kwargs["Attribute"])
            kwargs.pop('Level')
            kwargs.pop('Attribute')
        else:
            fieldName = trans_first_letter_to_lower(kwargs['FieldName'])
            kwargs.pop('FieldName')
        UpdateCapturePduPatternCommand(PduPatternHandle=pattern.handle,
                                       HeaderTypes=headerTypes,
                                       FieldName=fieldName, cl_instance=self.cl_instance, **param).execute()
        if kwargs:
            pattern.edit(**kwargs)
        return pattern.handle

    @abnormal_check()
    def edit_capture_pattern(self, Pattern, **kwargs):
        if isinstance(Pattern, (list, set, tuple)):
            Pattern = Pattern[0]
        patternObject = self.rom_manager.get_object(Pattern, cl=self.cl_instance)
        if 'TemplateString' in list(kwargs.keys()):
            patternObject.edit(TemplateString=kwargs['TemplateString'])
            kwargs.pop('TemplateString')
        if isinstance(patternObject, CapturePduPattern) and {'HeaderTypes'}.issubset(kwargs.keys()):
            param = {}
            if 'Value' in list(kwargs.keys()):
                param.update({'Value': kwargs.pop('Value')})
            if 'MaxValue' in list(kwargs.keys()):
                param.update({'MaxValue': kwargs.pop('MaxValue')})
            if 'Mask' in list(kwargs.keys()):
                param.update({'Mask': kwargs.pop('Mask')})
            if 'Offset' in list(kwargs.keys()):
                param.update({'Offset': kwargs.pop('Offset')})
            if 'Level' in list(kwargs.keys()):
                headerTypes = [list(MAP_HEADER_TRANSFORM[x.lower()].values())[0] for x in kwargs['HeaderTypes']]
                levelHeaderTypes = [x.split('.')[-1] for x in headerTypes]
                tempList = levelHeaderTypes[:int(kwargs['Level'])]
                index = tempList.count(levelHeaderTypes[int(kwargs['Level'])])
                fieldName = levelHeaderTypes[int(kwargs['Level'])] + f'_{index + 1}.' + str(kwargs["Attribute"])
                kwargs.pop('Level')
                kwargs.pop('Attribute')
            else:
                fieldName = trans_first_letter_to_lower(kwargs['FieldName'])
                kwargs.pop('FieldName')
            UpdateCapturePduPatternCommand(PduPatternHandle=patternObject.handle,
                                           HeaderTypes=kwargs['HeaderTypes'],
                                           FieldName=fieldName, cl_instance=self.cl_instance, **param).execute()
            kwargs.pop('HeaderTypes')
        if kwargs:
            patternObject.edit(**kwargs)
        return True

    @abnormal_check()
    def edit_capture_filter(self, Port, Expression):
        if isinstance(Port, (list, set, tuple)):
            Port = Port[0]
        capture = Port.get_children('CaptureConfig')[0]
        filter = capture.get_children('CapturePduFilter')
        if filter:
            capturePduFilter = filter[0]
        else:
            capturePduFilter = CapturePduFilter(upper=capture)
        capturePduFilter.edit(LogicExpression=Expression)
        return True

    @abnormal_check()
    def edit_capture_event(self, Port, EventType='QUALIFY', **kwargs):
        """
        edit capture event

        :param Port:
            port object
        :param EventType:
            QUALIFY
            START
            STOP
        :param kwargs:
            LogicRelation='AND'
            PatternMatch='INCLUDE'
            FcsError='IGNORE'
            PrbsError='IGNORE'
            Ipv4ChecksumError='IGNORE'
            TcpChecksumError='IGNORE'
            UdpChecksumError='IGNORE'
            IgmpChecksumError='IGNORE'
            IcmpChecksumError='IGNORE'
            SequenceError='IGNORE'
            UndersizedFrame='IGNORE'
            OversizedFrame='IGNORE'
            JumboFrame='IGNORE'
            FrameLength='IGNORE'
            FrameLengthValue=0
            SignaturePresent='IGNORE'
            StreamIdMatch='IGNORE'
            StreamId=0
            Ipv4Packets='IGNORE'
            TcpPackets='IGNORE'
            UdpPackets='IGNORE'
            Ipv6Packets='IGNORE'
            IgmpPackets='IGNORE'
            PayloadError='IGNORE'
        :return:
            True
            False
        """
        if isinstance(Port, (list, set, tuple)):
            Port = Port[0]
        capture = Port.get_children('CaptureConfig')[0]
        event = capture.get_children('CaptureEvent')
        if len(event) != 3:
            for i in range(3 - len(event)):
                CaptureEvent(upper=capture)
        event = capture.get_children('CaptureEvent')
        for e in event:
            if e.EventType.name.lower() == EventType.lower():
                captureEvent = e
                break
        captureEvent.edit(**kwargs)
        return True

    @abnormal_check()
    def get_capture_info(self, Port, Items=None):
        """
        get capture infomation

        :param Port:
            port object
        :param Items:
            CaptureState
            ElapsedTime
            CapturedPacketCount
            BufferFull
            DownloadedPacketCount
            CurrentDataFile
        :return: dict
        """
        if isinstance(Port, (list, set, tuple)):
            Port = Port[0]
        if Items is None:
            Items = [
                'CaptureState',
                'ElapsedTime',
                'CapturedPacketCount',
                'BufferFull',
                'DownloadedPacketCount',
                'CurrentDataFile']
        else:
            if not isinstance(Items, (list, set, tuple)):
                Items = [Items]
        capture = Port.get_children('CaptureConfig')[0]
        result = {i: getattr(capture, i) for i in Items if hasattr(capture, i)}
        return {k: (v.name if isinstance(v, enum.Enum) else v) for k, v in result.items()}

    @abnormal_check()
    def get_capture_data(self, Port, Index=1):
        if isinstance(Port, (list, set, tuple)):
            Port = Port[0]
        capture = Port.get_children('CaptureConfig')[0]
        renix_cmd = GetCaptureDataByIndexCommand(CaptureConfig=capture.handle, Index=Index, show_return_value=True)
        renix_cmd.execute()
        result = {
            'Timestamp': renix_cmd.Timestamp,
            'Length': renix_cmd.Length,
            'Data': renix_cmd.Data

        }
        return result

    @abnormal_check()
    def abort_download_capture_packets(self, Ports, **kwargs):
        """
        abort download capture packets

        :param Ports:
            port object list
        :param kwargs:
            AutoDelete=True
        :return:
        """
        result = EnumBase.TRUE.value
        for port in Ports:
            captureConfig = port.get_children('CaptureConfig')[0]
            abort_download_data_cmd = AbortDownloadDataCommand(CaptureConfigs=captureConfig.handle, cl_instance=self.cl_instance, **kwargs)
            abort_download_data_cmd.execute()
        return result

    @abnormal_check()
    def get_capture_packets_by_index(self, Port, Index, **kwargs):
        """
        get capture packets by index

        :param Ports:
            port object
        :param Index:
            index of packet to get
        :param kwargs:
            AutoDelete=True
        :return:
        """
        captureConfig = Port.get_children('CaptureConfig')[0]
        get_cap_data_by_index_cmd = GetCaptureDataByIndexCommand(CaptureConfig=captureConfig.handle, Index=Index, cl_instance=self.cl_instance,
                                                                 **kwargs)
        get_cap_data_by_index_cmd.execute()
        return get_cap_data_by_index_cmd.Data

    def port_directory(self, Port):
        """
        to return the directory where the captured packets file of port saved in.
        :param Port:
            port object.
        :return:
            "10_0_5_6_1_15"
        """
        location = Port.Location
        locationList = [x for x in location.split('/') if x != ""]
        result = locationList[0].replace('.', '_') + '_' + locationList[1] + '_' + locationList[2]
        return result

    @abnormal_check()
    def get_sessions(self, Ports=None, Protocols=None):
        if Protocols is None:
            protocol = [list(x.keys())[0] for x in PROTOCOL_MAP.values()]
        else:
            if not isinstance(Protocols, list):
                protocol = PROTOCOL_MAP[Protocols.lower()].keys()
            else:
                protocol = [list(PROTOCOL_MAP[x.lower()].keys())[0] for x in Protocols]
        if Ports is None:
            portList = self.sys_entry.get_children('Port')
            result = []
            for p in protocol:
                result.extend([x for y in portList for x in y.get_children(p)])
        else:
            if not isinstance(Ports, list):
                Ports = [Ports]
            result = []
            for p in protocol:
                result.extend([x for y in Ports for x in y.get_children(p)])
        objectResult = []
        for r in result:
            if r.handle in map_protocol_object.keys():
                objectResult.append(map_protocol_object[r.handle])
            else:
                for v in PROTOCOL_MAP.values():
                    if list(v.keys())[0] == r.__class__.__name__:
                        r.get_parent()
                        objectClass = globals()[list(v.values())[0]](Upper=r.upper, Session=r)
                        objectResult.append(objectClass)
                        map_protocol_object.update({objectClass.handle: objectClass})
                        break
        return objectResult

    @abnormal_check()
    def get_sessions_from_type(self, Type):
        if Type in PROTOCOL_MAP:
            Type = list(PROTOCOL_MAP[Type].keys())[0]
        return [x for x in self.rom_manager.get_all_objects().values() if isinstance(x,  globals().get(Type))]

    @abnormal_check()
    def get_vxlan_statistic(self, Session=None, StaItems=None, Mode=True):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="VxlanBindingStats",
                                     Idx={'VtepId': sessionID},
                                     StaItems=StaItems, Mode=Mode)
        return result
        # Stat = None
        # if StaItems is None:
        #     renixCmd = ListROMPropertiesCommand(ROMName='VxlanBindingStats', cl_instance=self.cl_instance)
        #     renixCmd.execute()
        #     StaItems = renixCmd.Properties
        # # resultViews = self.sys_entry.get_children('PageResultView')
        # resultViews = self.sys_entry.get_children('ResultView')
        # resultViews = [x for x in resultViews if x.DataClassName == 'VxlanBindingStats']
        # mapNameID = [Session.Name]
        # for view in resultViews:
        #     if view.RecordCount % view.RecordPerPage == 0:
        #         record_count = int(view.RecordCount / view.RecordPerPage)
        #     else:
        #         record_count = int(view.RecordCount / view.RecordPerPage) + 1
        #     for i in range(record_count):
        #         if i != 0:
        #             GotoResultPageCommand(ResultViewHandle=view.handle, PageNumber=i + 1, cl_instance=self.cl_instance).execute()
        #             time.sleep(3)
        #         view.get()
        #         resultQuerys = view.get_children()
        #         for query in resultQuerys:
        #             resultStats = query.get_children('VxlanBindingStats')
        #             if resultStats is not None:
        #                 for x in resultStats:
        #                     if mapNameID == [x.VtepId]:
        #                         Stat = x
        #                         break
        # if Stat is not None:
        #     result = {x: getattr(Stat, x) for x in StaItems}
        # else:
        #     result = EnumBase.FALSE.value
        # return result

    @abnormal_check()
    def download_packages(self, Port, FileDir, FileName, MaxCount=0, TimeOut=30, AppendPortHandle=True):
        if AppendPortHandle:
            FileDir = os.path.join(FileDir, Port.handle)
        if not os.path.exists(FileDir):
            os.makedirs(FileDir)
        captureConfig = Port.get_children('CaptureConfig')[0]
        renixCmd = DownloadCaptureDataCommand(CaptureConfigs=captureConfig.handle, FileDir=FileDir, FileName=FileName, cl_instance=self.cl_instance,
                                              MaxDownloadDataCount=MaxCount)
        renixCmd.execute()
        flag = True
        for x in range(1, TimeOut):
            if captureConfig.CaptureState == EnumCaptureState.IDLE:
                flag = False
                break
            time.sleep(1)
        time.sleep(3)
        if flag:
            raise TesterException("{} download packages failure".format(Port))
        else:
            path = captureConfig.CurrentDataFile
            return os.path.normpath(path)

    @abnormal_check()
    def del_objects(self, Objects):
        if not isinstance(Objects, list):
            Objects = [Objects]
        for Object in Objects:
            Object.delete()
        return EnumBase.TRUE.value

    # ------------------------- GATHER TestSuite -------------------------------------
    @abnormal_check()
    def create_benchmark(self, Type='rfc2544', Items=None):
        wizard, items = Wizard.create_benchmark(Type=Type, Items=Items)
        return wizard, items

    @abnormal_check()
    def run_benchmark(self, Mode=0, Timer=1800, Analyzer=False, Block=True):
        # result = EnumBase.FALSE.value
        # for smart scripter, may not exist result files.
        result = []
        timer = int(Timer)
        brnchmark = self.sys_entry.get_children('SmartScripter')[0]
        testSuiteOption = self.sys_entry.get_children('TestSuiteOption')[0]
        dateTime = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
        path = os.path.join(self.suite_path, dateTime)
        testSuiteOption.ResultPath = path
        brnchmark.AutoOpenAnalyzer = Analyzer
        StartSmartScripterCommand(Mode=Mode, cl_instance=self.cl_instance).execute()
        if not Block:
            return True
        while True:
            state = brnchmark.State.name
            elapsed_time = brnchmark.ElapsedTime
            command_name = brnchmark.CurrentCommandName
            self.logger.info(f'{state}: {command_name} {elapsed_time}, remaining {strftime("%H:%M:%S", gmtime(timer))} timeout')
            print(f'{state}: {command_name} {elapsed_time}, remaining {strftime("%H:%M:%S", gmtime(timer))} timeout', flush=True)

            if state == EnumSmartScripterState.IDLE.name:
                break
            if timer <= 0:
                self.logger.warning('Test still running after timer expired')
                break
            time.sleep(5)
            timer -= 5
        verdict = brnchmark.Verdict
        if verdict is EnumSmartScripterVerdict.FAILED:
            raise TesterException(brnchmark.Reason)
        fileDict = {}
        for root, dirs, files in os.walk(path, topdown=True):
            fileDict = {name: os.path.join(root, name) for name in files}
        for x in fileDict:
            if re.search(r'(.+((_\d+)(-\d+)+)+).db', x) is not None:
                result.append(fileDict[x].replace("\\", "/"))
        return result

    @abnormal_check()
    def wait_benchmark_completed(self, Timer=1800):
        result = []
        timer = int(Timer)
        brnchmark = self.sys_entry.get_children('SmartScripter')[0]
        testSuiteOption = self.sys_entry.get_children('TestSuiteOption')[0]
        dateTime = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
        path = os.path.join(self.suite_path, dateTime)
        testSuiteOption.ResultPath = path
        while True:
            state = brnchmark.State.name
            elapsed_time = brnchmark.ElapsedTime
            command_name = brnchmark.CurrentCommandName
            self.logger.info(f'{state}: {command_name} {elapsed_time}, remaining {strftime("%H:%M:%S", gmtime(timer))} timeout')
            print(f'{state}: {command_name} {elapsed_time}, remaining {strftime("%H:%M:%S", gmtime(timer))} timeout', flush=True)

            if state == EnumSmartScripterState.IDLE.name:
                break
            if timer <= 0:
                self.logger.warning('Test still running after timer expired')
                break
            time.sleep(5)
            timer -= 5
        verdict = brnchmark.Verdict
        if verdict is EnumSmartScripterVerdict.FAILED:
            raise TesterException(brnchmark.Reason)
        fileDict = {}
        for root, dirs, files in os.walk(path, topdown=True):
            fileDict.update({name: os.path.join(root, name) for name in files})
        for x in fileDict:
            if re.search(r'(.+((_\d+)(-\d+)+)+).db', x) is not None:
                result.append(fileDict[x].replace("\\", "/"))
        return result if result else False

    @abnormal_check()
    def pause_benchmark(self):
        PauseSmartScripterCommand(cl_instance=self.cl_instance).execute()
        return True

    @abnormal_check()
    def stop_benchmark(self):
        StopSmartScripterCommand(cl_instance=self.cl_instance).execute()
        return True

    @abnormal_check()
    def get_benchmark_result(self, DB, Type: str, ReturnType='dict', *args, **kwargs):
        if isinstance(DB, (set, list, tuple)):
            DB = DB[0]
        with sqlite3.connect(DB) as conn:
            type = Type.lower()
            if type in EnumBenchmarkDbTable._member_names_:
                sqlTable = EnumBenchmarkDbTable[type].value
                sql = f"""SELECT * FROM {sqlTable}"""
                df = pd.read_sql_query(sql, conn)
            if ReturnType.lower() == 'dict':
                result = df.to_dict('records')
            else:
                result = df
            return result

    @abnormal_check()
    def get_benchmark_result_(self, DB, Type: str, Item: str, FrameSize=None, Mbps=None, All=False):
        if isinstance(DB, (set, list, tuple)):
            DB = DB[0]
        conn = sqlite3.connect(DB)
        cursor = conn.cursor()
        benchmarkResult = []
        if Type.lower() == EnumBenchmarkType.Asymmetric.value.lower():
            sqlTable = "AsymmetricThroughputResult"
            if FrameSize is None:
                if Item.lower() == 'throughput':
                    sql = f"""SELECT * FROM {sqlTable}"""
                    cursor.execute(sql)
                    sqlResultTupleList = cursor.fetchall()
                    for sqlResultTuple in sqlResultTupleList:
                        sqlStream = {"ProfileName": sqlResultTuple[2], "FrameSize": sqlResultTuple[1],
                                     "Percent": sqlResultTuple[15], "Mbps": sqlResultTuple[14],
                                     "Rate": sqlResultTuple[13]}
                        if Mbps is None:
                            sqlStream["Mbps"] = sqlStream["FrameSize"] * sqlStream["Rate"] * 8 / 1000000
                        benchmarkResult.append(sqlStream)
            elif Item.lower() == 'throughput':
                for frame in FrameSize:
                    # Downstream Throughput
                    sql = f"""SELECT * FROM {sqlTable}""" + """ WHERE ProfileName == 'Downstream' AND TestResult == 'Passed' AND FrameSize == """ + str(
                        frame)

                    cursor.execute(sql)
                    sqlResultTuple = cursor.fetchall()[-1]
                    sqlDownStream = {"ProfileName": sqlResultTuple[2], "FrameSize": sqlResultTuple[1],
                                     "Percent": sqlResultTuple[15], "Mbps": sqlResultTuple[14],
                                     "Rate": sqlResultTuple[13]}
                    # Upstream Throughput
                    sql = f"""SELECT * FROM {sqlTable}""" + """ WHERE ProfileName == 'Upstream' AND TestResult == 'Passed' AND FrameSize == """ + str(
                        frame)

                    cursor.execute(sql)
                    sqlResultTuple = cursor.fetchall()[-1]
                    sqlUpStream = {"ProfileName": sqlResultTuple[2], "FrameSize": sqlResultTuple[1],
                                   "Percent": sqlResultTuple[15], "Mbps": sqlResultTuple[14],
                                   "Rate": sqlResultTuple[13]}
                    if Mbps is None:
                        sqlDownStream["Mbps"] = sqlDownStream["FrameSize"] * sqlDownStream["Rate"] * 8 / 1000000

                        sqlUpStream["Mbps"] = sqlDownStream["FrameSize"] * sqlUpStream["Rate"] * 8 / 1000000

                    benchmarkResult.extend((sqlDownStream, sqlUpStream))
        if Type.lower() == EnumBenchmarkType.RFC2544.value.lower():
            sqlTable = "Rfc2544PerLoadResult" if All else "Rfc2544PerFrameSizeResult"
            if Item.lower() == 'throughput' or Item.lower() == 'latency':
                sql = f"""SELECT * FROM {sqlTable}"""
                cursor.execute(sql)
                sqlResultTupleList = cursor.fetchall()
                for sqlResultTuple in sqlResultTupleList:
                    sqlStream = {"TestNum": sqlResultTuple[1],
                                 "FrameSize": sqlResultTuple[3],
                                 "Percent": sqlResultTuple[15],
                                 "Mbps": sqlResultTuple[14],
                                 "Rate": sqlResultTuple[13],
                                 "FrameLoss": sqlResultTuple[18],
                                 "FrameLossPercent": sqlResultTuple[19],
                                 "MaxLatency": sqlResultTuple[21],
                                 "MinLatency": sqlResultTuple[23],
                                 "AvgLatency": sqlResultTuple[22],
                                 "LatencyType": sqlResultTuple[28],
                                 }
                    benchmarkResult.append(sqlStream)
        if Type.lower() == EnumBenchmarkType.RFC2889.value.lower():
            sqlTable = "Rfc2889SummaryResult"
            sql = f"""SELECT * FROM {sqlTable}"""
            cursor.execute(sql)
            sqlResultTupleList = cursor.fetchall()
            if Item.lower() == 'addresscachingcapacity' or Item.lower() == 'addresslearningrate':
                for sqlResultTuple in sqlResultTupleList:
                    sqlStream = {"TrialNo": sqlResultTuple[1], "FrameSize": sqlResultTuple[2],
                                 "TxFraneCount": sqlResultTuple[13], "RxFraneCount": sqlResultTuple[14],
                                 "NumberOfAddress": sqlResultTuple[17], "LearningRate(fps)": sqlResultTuple[18]}
                    benchmarkResult.append(sqlStream)
        if Type.lower() == EnumBenchmarkType.RFC3918.value.lower():
            sqlTable = "Rfc3918PerIterationResult"
            if Item.lower() == 'joinleavelatency':
                sql = f"""SELECT * FROM {sqlTable}"""
                cursor.execute(sql)
                sqlResultTupleList = cursor.fetchall()
                for sqlResultTuple in sqlResultTupleList:
                    result = {"TestNum": sqlResultTuple[1],
                              "TrialNumber": sqlResultTuple[2],
                              "MulticastEgressPorts": sqlResultTuple[3],
                              "MulticastGroups": sqlResultTuple[4],
                              "McRxGroups": sqlResultTuple[5],
                              "FrameSize": sqlResultTuple[6],
                              "MinFrameSize": sqlResultTuple[7],
                              "MaxFrameSize": sqlResultTuple[8],
                              "IntendedLoad": sqlResultTuple[9],
                              "OfferedLoadFps": sqlResultTuple[10],
                              "OfferedLoadMbps": sqlResultTuple[11],
                              "OfferedLoadPercent": sqlResultTuple[12],
                              "TxFrameCount": sqlResultTuple[13],
                              "RxFrameCount": sqlResultTuple[14],
                              "ExpectedRxFrameCount": sqlResultTuple[15],
                              "FrameLossCount": sqlResultTuple[16],
                              "FrameLossPercent": sqlResultTuple[17],
                              "FloodedFrames": sqlResultTuple[19],
                              "MaxJoinLatency": sqlResultTuple[20],
                              "AvgJoinLatency": sqlResultTuple[21],
                              "MinJoinLatency": sqlResultTuple[22],
                              "MaxLeaveLatency": sqlResultTuple[23],
                              "AvgLeaveLatency": sqlResultTuple[24],
                              "MinLeaveLatency": sqlResultTuple[25],
                              "FailedJoins": sqlResultTuple[26],
                              "DuplicatedJoins": sqlResultTuple[27],
                              }
                    benchmarkResult.append(result)
        conn.close()
        return benchmarkResult

    @abnormal_check()
    def format_benchmark_result(self, Result):
        if isinstance(Result, pd.DataFrame):
            return tabulate(Result, headers='keys', tablefmt='psql')
        if type(Result) is not list:
            raise TesterException("Result is not list")
        putsTable = PrettyTable()
        putsTable.field_names = Result[0].keys()
        for x in Result:
            putsTable.add_row(x.values())
        result = putsTable
        self.logger.info('\n{}\n'.format(result))
        return result

    @abnormal_check()
    def export_benchmark_result(self, Result, Path: str, Sheet: str):
        result = EnumBase.TRUE.value
        if os.path.exists("C:/CMCC/Report.xlsx"):
            excel = openpyxl.load_workbook("C:/CMCC/Report.xlsx")
        else:
            excel = openpyxl.Workbook()
        if Sheet in excel.sheetnames:
            sheet = excel[Sheet]
        else:
            sheet = excel.create_sheet(Sheet)
        row = 1
        for column in Result[0].keys():
            sheet.cell(1, row, column)
            row += 1
        iColumn = 0
        for x in Result:
            iRow = 1
            iColumn += 1
            for column in Result[iColumn - 1].values():
                sheet.cell(iColumn, iRow, column)
                iRow += 1
        if not os.path.exists(Path):
            os.makedirs(Path)
        excel.save("C:/CMCC/Report.xlsx")
        excel.save(os.path.join(Path, "Report.xlsx"))
        return result

    @abnormal_check()
    def expand_benchmark(self, Config):
        return Config.expand_benchmark()

    @abnormal_check()
    def relate_benchmark_ports(self, Config, Ports):
        return Config.relate_ports(Ports=Ports)

    @abnormal_check()
    def create_benchmark_streams(self, Config,
                                 Items,
                                 Type,
                                 SrcPoints,
                                 DstPoints,
                                 Bidirectional=False,
                                 Mode='1v1',
                                 Mapping='roundrobin',
                                 Monitors=()
                                 ):
        return Config.create_streams(Items=Items,
                                     Type=Type,
                                     SrcPoints=SrcPoints,
                                     DstPoints=DstPoints,
                                     Bidirectional=Bidirectional,
                                     Mode=Mode,
                                     Mapping=Mapping,
                                     Monitors=Monitors)

    @abnormal_check()
    def edit_benchmark_learning(self, Configs, Frequency, EnableLearning=True,
                                LearningRate=1000, LearningRepeat=5, DelayBefore=2,
                                EnableArp=False, ArpRate=1000, ArpRepeat=5):
        if not isinstance(Configs, list):
            Configs = [Configs]
        for config in Configs:
            config.edit_address_learning(Frequency=Frequency, EnableLearning=EnableLearning,
                                         LearningRate=LearningRate, LearningRepeat=LearningRepeat,
                                         DelayBefore=DelayBefore,
                                         EnableArp=EnableArp, ArpRate=ArpRate, ArpRepeat=ArpRepeat)
        return True

    @abnormal_check()
    def edit_benchmark_latency(self, Configs, Type='FIFO', DelayBefore=2, DelayAfter=10):
        if not isinstance(Configs, list):
            Configs = [Configs]
        for config in Configs:
            config.edit_latency(Type=Type, DelayBefore=DelayBefore, DelayAfter=DelayAfter)
        return True

    @abnormal_check()
    def edit_benchmark_path(self, Configs, Path):
        if not isinstance(Configs, list):
            Configs = [Configs]
        for config in Configs:
            config.edit_result_path(Path=Path)
        return True

    @abnormal_check()
    def edit_benchmark_result_file_name(self, Config, EnableCustomResult=False, ResultFileName=None, AddTimeStamp=True):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        Config.edit_result_file_name(EnableCustomResult=EnableCustomResult, ResultFileName=ResultFileName,
                                     AddTimeStamp=AddTimeStamp)
        return True

    @abnormal_check()
    def edit_benchmark_duration(self, Config, Trial=1, Mode='second', Count=100):
        if isinstance(Config, list):
            Config = Config[0]
        return Config.edit_duration(Trial=Trial, Mode=Mode, Count=Count)

    @abnormal_check()
    def edit_benchmark_frame(self, Config,
                             Type='custom',
                             Length=128,
                             Min=128,
                             Max=256,
                             Start=128,
                             End=256,
                             Step=128,
                             Custom=None,
                             ImixTemplates=(),
                             ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.edit_frame(Type=Type,
                                 Length=Length,
                                 Min=Min,
                                 Max=Max,
                                 Start=Start,
                                 End=End,
                                 Step=Step,
                                 Custom=Custom,
                                 ImixTemplates=ImixTemplates)

    @abnormal_check()
    def edit_benchmark_search(self, Config,
                              Mode='binary',
                              Lower=1,
                              Upper=100,
                              Init=10,
                              Step=10,
                              Resolution=1,
                              Ratio=50,
                              Acceptance=0,
                              Ignore=False,
                              EnableLatency=False,
                              Maxlatency=30
                              ):
        if isinstance(Config, list):
            Config = Config[0]
        return Config.edit_search(Mode=Mode,
                                  Lower=Lower,
                                  Upper=Upper,
                                  Init=Init,
                                  Step=Step,
                                  Resolution=Resolution,
                                  Ratio=Ratio,
                                  Acceptance=Acceptance,
                                  Ignore=Ignore,
                                  EnableLatency=EnableLatency,
                                  Maxlatency=Maxlatency)

    @abnormal_check()
    def benchmark_stream_use_exist(self, Config, Streams):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.use_stream_exist(Streams=Streams)

    @abnormal_check()
    def edit_benchmark_burst_count_loop(self, Config, Mode='step', Start=1, End=1, Step=1, Custom=(1, 2)):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.edit_burst_count_loop(Mode=Mode, Start=Start, End=End, Step=Step, Custom=Custom)

    @abnormal_check()
    def edit_benchmark_transport_layer(self, Configs, HeaderType=None, EnableRandomPort=True, SrcPortBase=7,
                                       SrcPortStep=1,
                                       SrcPortCount=0, DstPortBase=7, DstPortStep=1, DstPortCount=0):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        for config in Configs:
            config.edit_transport_layer(HeaderType=HeaderType, EnableRandomPort=EnableRandomPort,
                                        SrcPortBase=SrcPortBase,
                                        SrcPortStep=SrcPortStep, SrcPortCount=SrcPortCount, DstPortBase=DstPortBase,
                                        DstPortStep=DstPortStep,
                                        DstPortCount=DstPortCount)
        return True

    @abnormal_check()
    def edit_benchmark_address_learning_capacity(self, Config,
                                                 MinAddressCount=1,
                                                 MaxAddressCount=65536,
                                                 InitAddressCount=20480,
                                                 Resolution=2,
                                                 AgingTime=15,
                                                 LearningRate=10000,
                                                 ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.edit_address_learning_capacity(
            MinAddressCount=MinAddressCount,
            MaxAddressCount=MaxAddressCount,
            InitAddressCount=InitAddressCount,
            Resolution=Resolution,
            AgingTime=AgingTime,
            LearningRate=LearningRate,
        )

    @abnormal_check()
    def edit_benchmark_address_learning_rate(self, Config,
                                             MinRateCount=1488,
                                             MaxRateCount=1488,
                                             InitRateCount=1488,
                                             Resolution=2,
                                             AgingTime=15,
                                             AddressCount=1000,
                                             ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.edit_address_learning_rate(
            MinRateCount=MinRateCount,
            MaxRateCount=MaxRateCount,
            InitRateCount=InitRateCount,
            Resolution=Resolution,
            AgingTime=AgingTime,
            AddressCount=AddressCount,
        )

    @abnormal_check()
    def edit_benchmark_traffic_load_loop(self, Config,
                                         LoadUnit='percent',
                                         LoadMode='custom',
                                         FixedLoad=10,
                                         LoadMin=10,
                                         LoadMax=50,
                                         LoadStart=10,
                                         LoadEnd=50,
                                         LoadStep=10,
                                         LoadCustom=(10, 20, 50),
                                         ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.edit_traffic_load_loop(
            LoadUnit=LoadUnit,
            LoadMode=LoadMode,
            FixedLoad=FixedLoad,
            LoadMin=LoadMin,
            LoadMax=LoadMax,
            LoadStart=LoadStart,
            LoadEnd=LoadEnd,
            LoadStep=LoadStep,
            LoadCustom=LoadCustom,
        )

    @abnormal_check()
    def edit_benchmark_backtoback_binary_search(self, Config,
                                                MinDuration=0.000064,
                                                MinFrameCount=1,
                                                DurationResolution=0.0001,
                                                FrameCountResolution=100,
                                                AcceptFrameLoss=0
                                                ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.edit_duration_parameters(MinDuration=MinDuration,
                                               MinFrameCount=MinFrameCount,
                                               DurationResolution=DurationResolution,
                                               FrameCountResolution=FrameCountResolution,
                                               AcceptFrameLoss=AcceptFrameLoss
                                               )

    @abnormal_check()
    def edit_benchmark_errored_frame_filtering(self, Config,
                                               CrcTested=True,
                                               CrcFrameLength=64,
                                               UndersizedTested=True,
                                               UndersizedFrameLength=60,
                                               OversizedTested=True,
                                               OversizedFrameLength=1519,
                                               MaxLegalFrameLength=1518,
                                               BurstSize=1,
                                               ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        return Config.edit_errored_frame_filtering(
            CrcTested=CrcTested,
            CrcFrameLength=CrcFrameLength,
            UndersizedTested=UndersizedTested,
            UndersizedFrameLength=UndersizedFrameLength,
            OversizedTested=OversizedTested,
            OversizedFrameLength=OversizedFrameLength,
            MaxLegalFrameLength=MaxLegalFrameLength,
            BurstSize=BurstSize,
        )

    @abnormal_check()
    def edit_benchmark_multicast_base_parameters(self,
                                                 Configs,
                                                 Version='igmpv2',
                                                 Ipv4GroupAddressStart='225.0.0.1',
                                                 Ipv4GroupAddressStep='0.1.0.0',
                                                 Ipv4PrefixLength=32,
                                                 Ipv6GroupAddressStart='ff1e::1',
                                                 Ipv6GroupAddressStep='0:0:0:1::',
                                                 Ipv6PrefixLength=128,
                                                 GroupIncrement=1,
                                                 JoinGroupDelay=15,
                                                 LeaveGroupDelay=15,
                                                 JoinLeaveSendRate=1000,
                                                 GroupDistributeMode='even',
                                                 ):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        for config in Configs:
            config.edit_multicast_base_parameters(Version=Version,
                                                  Ipv4GroupAddressStart=Ipv4GroupAddressStart,
                                                  Ipv4GroupAddressStep=Ipv4GroupAddressStep,
                                                  Ipv4PrefixLength=Ipv4PrefixLength,
                                                  Ipv6GroupAddressStart=Ipv6GroupAddressStart,
                                                  Ipv6GroupAddressStep=Ipv6GroupAddressStep,
                                                  Ipv6PrefixLength=Ipv6PrefixLength,
                                                  GroupIncrement=GroupIncrement,
                                                  JoinGroupDelay=JoinGroupDelay,
                                                  LeaveGroupDelay=LeaveGroupDelay,
                                                  JoinLeaveSendRate=JoinLeaveSendRate,
                                                  GroupDistributeMode=GroupDistributeMode,
                                                  )
        return True

    @abnormal_check()
    def edit_benchmark_multicast_stream_tos(self, Configs, Tos=0, FlowLabel=0, TTL=7, Priority=0):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        for config in Configs:
            config.edit_multicast_stream_tos(Tos=Tos, FlowLabel=FlowLabel, TTL=TTL, Priority=Priority)
        return True

    @abnormal_check()
    def edit_benchmark_multicast_other(self, Configs, StopTestWhenFailed=True, VerifyFreq='topo_changed',
                                       DurationMode='second', TimeDurationCount=1, BurstDurationCount=100,
                                       TxFrameRate=1000):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        for config in Configs:
            config.edit_multicast_other(StopTestWhenFailed=StopTestWhenFailed, VerifyFreq=VerifyFreq,
                                        DurationMode=DurationMode, TimeDurationCount=TimeDurationCount,
                                        BurstDurationCount=BurstDurationCount, TxFrameRate=TxFrameRate)
        return True

    @abnormal_check()
    def edit_benchmark_multicast_traffic_ratio_loop(self,
                                                    Config,
                                                    LoopMode='step',
                                                    FixedRatio=10,
                                                    MinRatio=10,
                                                    MaxRatio=50,
                                                    StartRatio=10,
                                                    EndRatio=50,
                                                    StepRatio=10,
                                                    CustomRatio=(10, 20, 100),
                                                    ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        Config.edit_multicast_traffic_ratio_loop(LoopMode=LoopMode,
                                                 FixedRatio=FixedRatio,
                                                 MinRatio=MinRatio,
                                                 MaxRatio=MaxRatio,
                                                 StartRatio=StartRatio,
                                                 EndRatio=EndRatio,
                                                 StepRatio=StepRatio,
                                                 CustomRatio=CustomRatio)
        return EnumBase.TRUE.value

    @abnormal_check()
    def edit_benchmark_multicast_group_count_loop(self,
                                                  Config,
                                                  LoopMode='step',
                                                  FixedGroup=10,
                                                  MinGroup=10,
                                                  MaxGroup=50,
                                                  StartGroup=10,
                                                  EndGroup=50,
                                                  StepGroup=10,
                                                  CustomGroup=(10, 20, 100),
                                                  ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        Config.edit_multicast_group_count_loop(LoopMode=LoopMode,
                                               FixedGroup=FixedGroup,
                                               MinGroup=MinGroup,
                                               MaxGroup=MaxGroup,
                                               StartGroup=StartGroup,
                                               EndGroup=EndGroup,
                                               StepGroup=StepGroup,
                                               CustomGroup=CustomGroup)
        return True

    @abnormal_check()
    def edit_benchmark_multicast_mixed_throughput_unicast_streams(self, Config, Streams):
        if isinstance(Config, list):
            Config = Config[0]
        return Config.edit_mixed_throughput_unicast_streams(UnicastStreamHandles=[x.handle for x in Streams])

    @abnormal_check()
    def edit_benchmark_multicast_join_leave_delay(self, Config,
                                                  DelayBetweenJoinAndStartStream=10,
                                                  DelayBetweenJoinAndLeave=10,
                                                  ):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        Config.edit_multicast_join_leave_delay(DelayBetweenJoinAndStartStream=DelayBetweenJoinAndStartStream,
                                               DelayBetweenJoinAndLeave=DelayBetweenJoinAndLeave)
        return True

    # ------------------------- GATHER mpls -------------------------------------
    @abnormal_check()
    def create_mpls_wizard(self, Type, **kwargs):
        if Type.lower() == 'mpls_ip_vpn':
            return MplsIpVpn(**kwargs)
        elif Type.lower() == 'mpls_6vpe':
            return Mpls6VPe(**kwargs)
        elif Type.lower() == 'bgp_vpls':
            return BgpVpls(**kwargs)
        elif Type.lower() == 'ldp_vpls':
            return LdpVpls(**kwargs)
        elif Type.lower() == 'pwe':
            return Pwe()
        else:
            return False

    @abnormal_check()
    def expand_mpls_wizard(self, Wizard):
        return Wizard.expand()

    @abnormal_check()
    def edit_mpls_provider_port(self, Wizard, Port, **kwargs):
        return Wizard.edit_provider_port(Port=Port, **kwargs)

    @abnormal_check()
    def edit_mpls_customer_port(self, Wizard, Port, **kwargs):
        return Wizard.edit_customer_port(Port=Port, **kwargs)

    @abnormal_check()
    def edit_mpls_provider_router_basic_parameters(self, Wizard, **kwargs):
        return Wizard.edit_provider_router_basic_parameters(**kwargs)

    @abnormal_check()
    def edit_mpls_provider_router_ldp(self, Wizard, **kwargs):
        return Wizard.edit_provider_router_mpls_ldp(**kwargs)

    @abnormal_check()
    def edit_mpls_provider_router_ospf(self, Wizard, **kwargs):
        return Wizard.edit_provider_router_igp_ospf(**kwargs)

    @abnormal_check()
    def edit_mpls_provider_router_isis(self, Wizard, **kwargs):
        return Wizard.edit_provider_router_igp_isis(**kwargs)

    @abnormal_check()
    def edit_mpls_provider_router_rip(self, Wizard, **kwargs):
        return Wizard.edit_provider_router_igp_rip(**kwargs)

    @abnormal_check()
    def edit_mpls_provider_route_reflector(self, Wizard, **kwargs):
        return Wizard.edit_provider_route_reflector(**kwargs)

    @abnormal_check()
    def edit_traffic_parameters(self, Wizard, **kwargs):
        return Wizard.edit_traffic_parameters(**kwargs)

    @abnormal_check()
    def edit_lsp_ping(self, Wizard, **kwargs):
        return Wizard.edit_lsp_ping(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpn_parameters(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_customer_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpn_customer_parameters(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_provider_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpn_provider_parameters(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_as_number(self, Wizard, **kwargs):
        return Wizard.edit_vpn_as_number(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_ipv4_route_customer_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpn_ipv4_route_customer_parameters(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_ipv4_route_provider_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpn_ipv4_route_provider_parameters(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_ipv6_route_customer_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpn_ipv6_route_customer_parameters(**kwargs)

    @abnormal_check()
    def edit_mpls_vpn_ipv6_route_provider_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpn_ipv6_route_provider_parameters(**kwargs)

    # -------------------------MPLS VPLS-------------------------------
    @abnormal_check()
    def edit_mpls_host(self, Wizard, **kwargs):
        return Wizard.edit_host(**kwargs)

    @abnormal_check()
    def edit_mpls_fec128(self, Wizard, **kwargs):
        return Wizard.edit_fec128(**kwargs)

    @abnormal_check()
    def edit_mpls_fec129(self, Wizard, **kwargs):
        return Wizard.edit_fec129(**kwargs)

    # -------------------------MPLS BGP VPLS-------------------------------
    @abnormal_check()
    def edit_bgp_vpls(self, Wizard, **kwargs):
        return Wizard.edit_bgp_vpls(**kwargs)

    # -------------------------MPLS LDP VPLS-------------------------------
    @abnormal_check()
    def edit_mpls_vpls_basic_parameters(self, Wizard, **kwargs):
        return Wizard.edit_vpls_basic_parameters(**kwargs)

    # -------------------------MPLS PWE-------------------------------
    @abnormal_check()
    def edit_mpls_pwe_basic_parameters(self, Wizard, **kwargs):
        return Wizard.edit_pwe_basic_parameters(**kwargs)

    # ---------------------------------------------------------------------
    @abnormal_check()
    def get_gateway_mac(self, Interface, Version=None):
        address_ipv4 = []
        address_ipv6 = []
        if not isinstance(Interface, (set, list, tuple)):
            Interface = [Interface]
        for i in Interface:
            Ipv4Layers = i.get_children('Ipv4Layer')
            if Ipv4Layers is not []:
                for layer in Ipv4Layers:
                    address_ipv4 = address_ipv4 + layer.ResolvedMacList
            Ipv6Layers = i.get_children('Ipv6Layer')
            if Ipv6Layers is not []:
                for layer in Ipv6Layers:
                    address_ipv6 = address_ipv6 + layer.ResolvedMacList
        if Version is None:
            return address_ipv4 + address_ipv6
        elif Version.lower() == 'ipv4':
            return address_ipv4
        else:
            return address_ipv6

    @abnormal_check()
    def get_interfaces(self, Ports=None, Types=None):
        if Ports is None:
            portList = self.sys_entry.get_children('Port')
            interface = []
            for p in portList:
                interface = interface + [x for x in p.get_children('Interface')]
        else:
            if not isinstance(Ports, (list, set, tuple)):
                Ports = [Ports]
            interface = []
            for p in Ports:
                interface = interface + [x for x in p.get_children('Interface')]
        if Types is not None:
            if not isinstance(Types, (list, set, tuple)):
                Types = [Types]
            result = []
            for t in Types:
                if t.lower() == 'eth':
                    result = result + [x for x in interface if x.get_children('EthIILayer') and x not in result]
                elif t.lower() == 'ipv4':
                    result = result + [x for x in interface if x.get_children('Ipv4Layer') and x not in result]
                elif t.lower() == 'ipv6':
                    result = result + [x for x in interface if x.get_children('Ipv6Layer') and x not in result]
                elif t.lower() == 'vlan':
                    result = result + [x for x in interface if x.get_children('VlanLayer') and x not in result]
                elif t.lower() == 'pppoe':
                    result = result + [x for x in interface if x.get_children('PppoeLayer') and x not in result]
                elif t.lower() == 'l2tp':
                    result = result + [x for x in interface if x.get_children('L2tpLayer') and x not in result]
                elif t.lower() == 'gre':
                    result = result + [x for x in interface if x.get_children('GreIpv4Layer') and x not in result]
        else:
            result = interface
        return result

    @abnormal_check()
    def get_layer_from_interfaces(self, Interfaces, Layer='ipv4'):
        if Layer.lower() == "eth":
            layer = "EthIILayer"
        elif Layer.lower() == "ipv6":
            layer = "Ipv6Layer"
        elif Layer.lower() == "vlan":
            layer = "VLANLayer"
        elif Layer.lower() == "pppoe":
            layer = "PppoeLayer"
        elif Layer.lower() == "l2tp":
            layer = "L2tpLayer"
        elif Layer.lower() == "gre":
            layer = "GreIpv4Layer"
        else:
            layer = "Ipv4Layer"
        if not isinstance(Interfaces, list):
            Interfaces = [Interfaces]
        result = []
        for interface in Interfaces:
            result = result + interface.get_children(layer)
        return result

    @abnormal_check()
    def get_streams(self, Ports=None):
        if Ports is None:
            portList = self.sys_entry.get_children('Port')
            result = []
            for p in portList:
                result = result + [x for x in p.get_children('StreamTemplate')]
        else:
            if not isinstance(Ports, list):
                Ports = [Ports]
            result = []
            for p in Ports:
                result = result + [x for x in p.get_children('StreamTemplate')]
        self.set_stream_header_map(Streams=result)
        return result

    @abnormal_check()
    def get_configs(self, Configs=None, KeyType='handle', Upper=None):
        if Configs is None:
            result = self.rom_manager.get_all_objects().values()
        else:
            if not isinstance(Configs, (list, set, tuple)):
                Configs = [Configs]
            result = []
            for config in Configs:
                result = result + [x for x in self.rom_manager.get_all_objects().values() if
                                   x.handle.split('_')[0].lower() == config.lower()]
        if not result:
            return False
        resultDict = {}
        if KeyType.lower() == 'handle':
            tempDict = {x.handle: x for x in result}
        else:
            tempDict = {x.Name: x for x in result}
        if Upper is not None:
            for k, v in tempDict.items():
                if self.check_upper_exist(Config=v, Upper=Upper):
                    resultDict.update({k: v})
        else:
            resultDict = tempDict
        return resultDict

    def check_upper_exist(self, Config, Upper):
        if isinstance(Config, (list, set, tuple)):
            Config = Config[0]
        if isinstance(Upper, (list, set, tuple)):
            Upper = Upper[0]
        # Config.get_parent()
        if Config.upper == Upper:
            return True
        elif isinstance(Config.upper, SysEntry):
            return False
        else:
            if self.check_upper_exist(Config=Config.upper, Upper=Upper):
                return True

    @abnormal_check()
    def start_arp(self, Ports=None, Interfaces=None):
        result = EnumBase.TRUE.value
        if Interfaces is not None:
            if Ports is not None:
                raise TesterException("Port should be None when Object is not None")
            else:
                if not isinstance(Interfaces, list) and Interfaces is not None:
                    Interfaces = [Interfaces]
                renixCmd = StartArpCommand(InterfaceConfigs=[x.handle for x in Interfaces], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if Ports is None:
                renixCmd = StartAllArpCommand(cl_instance=self.cl_instance)
            else:
                InterfaceConfigs = []
                for p in Ports:
                    InterfaceConfigs = InterfaceConfigs + p.get_children("Interface")
                renixCmd = StartArpCommand(InterfaceConfigs=[x.handle for x in InterfaceConfigs], cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def stop_arp(self, Ports=None, Interfaces=None):
        result = EnumBase.TRUE.value
        if Interfaces is not None:
            if Ports is not None:
                raise TesterException("Port should be None when Object is not None")
            else:
                if not isinstance(Interfaces, list) and Interfaces is not None:
                    Interfaces = [Interfaces]
                renixCmd = StopArpCommand(InterfaceConfigs=[x.handle for x in Interfaces], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if Ports is None:
                renixCmd = StopAllArpCommand(cl_instance=self.cl_instance)
            else:
                InterfaceConfigs = []
                for p in Ports:
                    InterfaceConfigs = InterfaceConfigs + p.get_children("Interface")
                renixCmd = StopArpCommand(InterfaceConfigs=[x.handle for x in InterfaceConfigs], cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def start_stream_arp(self, Ports=None, Stream=None):
        result = EnumBase.TRUE.value
        if Stream is not None:
            if Ports is not None:
                raise TesterException("Port should be None when Object is not None")
            else:
                if not isinstance(Stream, list) and Stream is not None:
                    Stream = [Stream]
                renixCmd = StartStreamArpCommand(StreamHandles=[x.handle for x in Stream], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if Ports is None:
                renixCmd = StartAllStreamArpCommand(cl_instance=self.cl_instance)
            else:
                StreamHandles = []
                for p in Ports:
                    StreamHandles = StreamHandles + p.get_children("Stream")
                renixCmd = StartStreamArpCommand(StreamHandles=[x.handle for x in StreamHandles], cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def stop_stream_arp(self, Ports=None, Stream=None):
        result = EnumBase.TRUE.value
        if Stream is not None:
            if Ports is not None:
                raise TesterException("Port should be None when Object is not None")
            else:
                if not isinstance(Stream, list) and Stream is not None:
                    Stream = [Stream]
                renixCmd = StopStreamArpCommand(StreamHandles=[x.handle for x in Stream], cl_instance=self.cl_instance)
        else:
            if not isinstance(Ports, list) and Ports is not None:
                Ports = [Ports]
            if Ports is None:
                renixCmd = StopAllStreamArpCommand(cl_instance=self.cl_instance)
            else:
                StreamHandles = []
                for p in Ports:
                    StreamHandles = StreamHandles + p.get_children("Stream")
                renixCmd = StopAllStreamArpCommand(StreamHandles=[x.handle for x in StreamHandles], cl_instance=self.cl_instance)
        renixCmd.execute()
        return result

    @abnormal_check()
    def select_interface(self, Session, Interface):
        if not isinstance(Session, list):
            Session = [Session]
        if not isinstance(Interface, list):
            Interface = [Interface]
        SelectInterfaceCommand(ProtocolList=[x.handle for x in Session],
                               InterfaceList=[x.handle for x in Interface], cl_instance=self.cl_instance).execute()
        return True

    # ------------------------- GATHER dhcpv4 -------------------------------------
    @abnormal_check()
    def create_dhcp_client(self, Port, **kwargs):
        session = DhcpClient(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_dhcp_client(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def dhcp_bind(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.bind()
        return True

    @abnormal_check()
    def dhcp_abort(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.abort()
        return True

    @abnormal_check()
    def dhcp_rebind(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.rebind()
        return True

    @abnormal_check()
    def dhcp_reboot(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.reboot()
        return True

    @abnormal_check()
    def dhcp_release(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.release()
        return True

    @abnormal_check()
    def dhcp_renew(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.renew()
        return True

    @abnormal_check()
    def create_dhcp_client_custom_option(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        result = []
        for s in Session:
            result.append(s.create_option(**kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_dhcp_server(self, Port, **kwargs):
        session = DhcpServer(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_dhcp_server(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def create_dhcp_server_address_pool(self, Sessions, **kwargs):
        if not isinstance(Sessions, list):
            Sessions = [Sessions]
        result = []
        for Session in Sessions:
            result.append(Session.create_pool(**kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_dhcp_server_custom_option(self, Session, Upper, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        if not isinstance(Upper, (list, set, tuple)):
            Upper = [Upper]
        result = []
        for s in Session:
            for u in Upper:
                result.append(s.create_option(Upper=u, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def wait_dhcp_client_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
            if State is None:
                State = 'BOUND'
            return self._wait_state(Sessions=Sessions, AttrName='State', State=State, Interval=Interval,
                                    TimeOut=TimeOut)

    @abnormal_check()
    def wait_dhcp_server_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
            if State is None:
                State = 'UP'
            return self._wait_state(Sessions=Sessions, AttrName='State', State=State, Interval=Interval,
                                    TimeOut=TimeOut)

    @abnormal_check()
    def get_dhcp_port_statistic(self, Port=None, StaItems=None, Mode=True):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.handle for x in Port]
        else:
            portID = Port.handle
        result = self._get_statictis(Statictis="Dhcpv4PortStats",
                                     Idx={'PortHandle': portID},
                                     StaItems=StaItems, Mode=Mode)
        return result

    @abnormal_check()
    def get_dhcp_client_statistic(self, Session=None, Id=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv4ClientStats",
                                     Idx={'ClientHandle': sessionID,
                                          'SessionIndex': Id},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dhcp_client_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv4ClientBlockStats",
                                     Idx={'ClientHandle': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dhcp_server_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv4ServerStats",
                                     Idx={'ServerHandle': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dhcp_server_lease_statistic(self, Session=None, ClientId=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv4LeaseStats",
                                     Idx={'ServerHandle': sessionID,
                                          'ClientId': ClientId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def edit_dhcp_client_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, (list, set, tuple)):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children("Dhcpv4PortConfig")[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def edit_dhcp_server_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, (list, set, tuple)):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children("Dhcpv4ServerPortConfig")[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def dhcp_force_renew(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.renew()
        return True

    @abnormal_check()
    def dhcp_abort_server(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.abort()
        return True

    # ------------------------- GATHER dhcpv6 client-------------------------------------
    @abnormal_check()
    def create_dhcpv6_client(self, Port, **kwargs):
        session = Dhcpv6Client(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def dhcpv6_client_custom_options(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        configs = []
        for Session in Sessions:
            config = Session.custom_options(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def dhcpv6_client_bind(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.bind()
        return True

    @abnormal_check()
    def dhcpv6_client_release(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.release()
        return True

    @abnormal_check()
    def dhcpv6_client_renew(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.renew()
        return True

    @abnormal_check()
    def dhcpv6_client_rebind(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.rebind()
        return True

    @abnormal_check()
    def dhcpv6_client_confirm(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.confirm()
        return True

    @abnormal_check()
    def dhcpv6_client_abort(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.abort()
        return True

    @abnormal_check()
    def dhcpv6_client_info_request(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.info_request()
        return True

    @abnormal_check()
    def dhcpv6_client_lease_query(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.lease_query(**kwargs)
        return True

    @abnormal_check()
    def dhcpv6_client_bulk_lease_query(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.bulk_lease_query(**kwargs)
        return True

    @abnormal_check()
    def dhcpv6_client_active_lease_query(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.active_lease_query()
        return True

    @abnormal_check()
    def dhcpv6_client_start_tls(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_tls()
        return True

    @abnormal_check()
    def edit_dhcpv6_client_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('Dhcpv6PortRateConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def wait_dhcpv6_client_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def wait_dhcpv6_pd_client_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_pd_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def get_dhcpv6_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.handle for x in Port]
        else:
            portID = Port.handle
        result = self._get_statictis(Statictis="Dhcpv6PortStatistics",
                                     Idx={'Dhcpv6PortId': portID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dhcpv6_client_statistic(self, Session=None, Id=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv6ClientStatistics",
                                     Idx={'Dhcpv6ClientId': sessionID,
                                          'SessionIndex': Id},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dhcpv6_client_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv6ClientBlockStatistics",
                                     Idx={'Dhcpv6ClientBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dhcpv6_pd_client_statistic(self, Session=None, Id=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv6PdClientStatistics",
                                     Idx={'Dhcpv6PdClientId': sessionID,
                                          'SessionIndex': Id},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER dhcpv6 server-------------------------------------
    @abnormal_check()
    def create_dhcpv6_server(self, Port, **kwargs):
        session = Dhcpv6Server(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def dhcpv6_server_custom_options(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        configs = []
        for Session in Sessions:
            config = Session.custom_options(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    def dhcpv6_server_address_pool(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        configs = []
        for Session in Sessions:
            config = Session.address_pool(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    def dhcpv6_server_prefix_pool(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        configs = []
        for Session in Sessions:
            config = Session.prefix_pool(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    def dhcpv6_server_start(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_server()
        return True

    def dhcpv6_server_stop(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_server()
        return True

    def dhcpv6_server_reconfigure_renew(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.renew()
        return True

    def dhcpv6_server_reconfigure_rebind(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.rebind()
        return True

    def dhcpv6_server_abort(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.abort()
        return True

    @abnormal_check()
    def wait_dhcpv6_server_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def get_dhcpv6_server_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dhcpv6ServerStatistics",
                                     Idx={'Dhcpv6ServerId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dhcpv6_server_lease_statistic(self, Session=None, Pool=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        if Pool is None:
            poolID = None
        elif isinstance(Pool, (list, set, tuple)):
            poolID = [x.Name for x in Pool]
        else:
            poolID = Pool.Name
        result = self._get_statictis(Statictis="Dhcpv6LeaseStatistics",
                                     Idx={'Dhcpv6ServerId': sessionID,
                                          'Dhcpv6LeaseId': poolID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER ospfv2 -------------------------------------
    @abnormal_check()
    def create_ospf(self, Port, **kwargs):
        session = OspfRouter(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_ospf(self, Session, **kwargs):
        return self._set_attr(Sessions=Session, **kwargs)

    @abnormal_check()
    def create_ospf_router_lsa(self, Session, **kwargs):
        config = Session.create_router_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_router_lsa_link(self, RouterLsa, **kwargs):
        config = OspfRouter.create_router_ls_link(RouterLsa=RouterLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_network_lsa(self, Session, **kwargs):
        config = Session.create_network_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_network_atch_router(self, NetworkLsa, **kwargs):
        config = OspfRouter.create_network_atch_router(NetworkLsa=NetworkLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_summary_lsa(self, Session, **kwargs):
        config = Session.create_summary_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_asbr_summary_lsa(self, Session, **kwargs):
        config = Session.create_asbr_summary_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_external_lsa(self, Session, **kwargs):
        config = Session.create_external_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_te_lsa(self, Session, **kwargs):
        config = Session.create_te_lsa(**kwargs)
        return config

    @abnormal_check()
    def edit_ospf_te_lsa_link(self, TeLsa, **kwargs):
        config = OspfRouter.edit_te_lsa_link(Lsa=TeLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_opaque_router_info_lsa(self, Session, **kwargs):
        config = Session.create_opaque_router_info_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_sr_algorithm_tlv(self, OpaqueRouterInfoLsa, **kwargs):
        config = OspfRouter.create_sr_algorithm_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_sr_sid_label_range_tlv(self, OpaqueRouterInfoLsa, **kwargs):
        config = OspfRouter.create_sr_sid_label_range_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_sr_srms_preference_tlv(self, OpaqueRouterInfoLsa, **kwargs):
        config = OspfRouter.create_sr_srms_preference_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_router_info_capability_tlv(self, OpaqueRouterInfoLsa, **kwargs):
        config = OspfRouter.create_router_info_capability_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_sr_fad_tlv(self, Session, OpaqueRouterInfoLsa, **kwargs):
        config = Session.create_sr_fad_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_sr_node_msd_tlv(self, Session, OpaqueRouterInfoLsa, **kwargs):
        config = Session.create_sr_node_msd_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_opaque_extended_prefix_lsa(self, Session, **kwargs):
        config = Session.create_opaque_extended_prefix_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_ext_prefix_range_tlv(self, Session, OpaqueExtendedPrefixLsa, **kwargs):
        config = Session.create_ext_prefix_range_tlv(OpaqueExtendedPrefixLsa=OpaqueExtendedPrefixLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_ext_prefix_tlv(self, Session, OpaqueExtendedPrefixLsa, **kwargs):
        config = Session.create_ext_prefix_tlv(OpaqueExtendedPrefixLsa=OpaqueExtendedPrefixLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_sid_label_binding_sub_tlv(self, Session, Tlv, **kwargs):
        config = Session.create_sid_label_binding_sub_tlv(Tlv=Tlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_prefix_sid_sub_tlv(self, Session, Tlv, **kwargs):
        config = Session.create_prefix_sid_sub_tlv(Tlv=Tlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_sr_fapm_sub_tlv(self, Tlv, **kwargs):
        config = OspfRouter.create_sr_fapm_sub_tlv(Tlv=Tlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_bier_sub_tlv(self, Tlv, **kwargs):
        config = OspfRouter.create_bier_sub_tlv(Tlv=Tlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_bier_mpls_encap_sub_tlv(self, Tlv, **kwargs):
        config = OspfRouter.create_bier_mpls_encap_sub_tlv(Tlv=Tlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_opaque_extended_link_lsa(self, Session, **kwargs):
        config = Session.create_opaque_extended_link_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospf_extended_link_tlv(self, OpaqueExtendedLinkLsa, **kwargs):
        config = OspfRouter.create_extended_link_tlv(OpaqueExtendedLinkLsa=OpaqueExtendedLinkLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_adj_sid_sub_tlv(self, Session, ExtendedLinkTlv, **kwargs):
        config = Session.create_adj_sid_sub_tlv(ExtendedLinkTlv=ExtendedLinkTlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_lan_adj_sid_sub_tlv(self, Session, ExtendedLinkTlv, **kwargs):
        config = Session.create_lan_adj_sid_sub_tlv(ExtendedLinkTlv=ExtendedLinkTlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_sr_link_msd_sub_tlv(self, Session, ExtendedLinkTlv, **kwargs):
        config = Session.create_sr_link_msd_sub_tlv(ExtendedLinkTlv=ExtendedLinkTlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospf_custom_sub_tlv(self, SrLinkMsdSubTlv, **kwargs):
        config = OspfRouter.create_custom_sub_tlv(SrLinkMsdSubTlv=SrLinkMsdSubTlv, **kwargs)
        return config

    @abnormal_check()
    def advertise_ospf_lsa(self, Sessions=None, Type=None, Lsa=None):
        if Lsa is None:
            if not isinstance(Sessions, (list, set, tuple)):
                Sessions = [Sessions]
            for Session in Sessions:
                Session.advertise(Type=Type)
        else:
            if not isinstance(Lsa, list):
                Lsa = [Lsa]
            Ospfv2AdvertiseCommand(Ospfv2LsaConfigs=[x.handle for x in Lsa], cl_instance=self.cl_instance).execute()
        return True

    @abnormal_check()
    def withdraw_ospf_lsa(self, Sessions=None, Type=None, Lsa=None):
        if Lsa is None:
            if not isinstance(Sessions, (list, set, tuple)):
                Sessions = [Sessions]
            for Session in Sessions:
                Session.withdraw(Type=Type)
        else:
            if not isinstance(Lsa, list):
                Lsa = [Lsa]
            Ospfv2WithdrawCommand(Ospfv2LsaConfigs=[x.handle for x in Lsa], cl_instance=self.cl_instance).execute()
        return True

    @abnormal_check()
    def wait_ospf_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['DR', 'BACKUP', 'DROTHER']
        return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def wait_ospf_adjacency_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'FULL'
        return self._wait_state(Sessions=Sessions, AttrName='AdjacencyStatus', State=State, Interval=Interval,
                                TimeOut=TimeOut)

    @abnormal_check()
    def establish_ospf(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.establish()
        return True

    @abnormal_check()
    def grace_restart_ospf(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.grace_restart()
        return True

    @abnormal_check()
    def get_ospf_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Ospfv2SessionResultPropertySet", Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def edit_ospf_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('Ospfv2PortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    # ------------------------- GATHER ospfv3 -------------------------------------
    @abnormal_check()
    def create_ospfv3(self, Port, **kwargs):
        session = Ospfv3Router(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_ospfv3(self, Session, **kwargs):
        return self._set_attr(Sessions=Session, **kwargs)

    @abnormal_check()
    def create_ospfv3_router_lsa(self, Session, **kwargs):
        config = Session.create_router_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_router_lsa_link(self, RouterLsa, **kwargs):
        config = Ospfv3Router.create_router_ls_link(RouterLsa=RouterLsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_endx_sid_sub_tlv(self, Session, RouterLsaLink, **kwargs):
        config = Session.create_srv6_endx_sid_sub_tlv(RouterLsaLink=RouterLsaLink, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_lan_endx_sid_sub_tlv(self, Session, RouterLsaLink, **kwargs):
        config = Session.create_srv6_lan_endx_sid_sub_tlv(RouterLsaLink=RouterLsaLink, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_link_msd_sub_tlv(self, Session, RouterLsaLink, **kwargs):
        config = Session.create_srv6_link_msd_sub_tlv(RouterLsaLink=RouterLsaLink, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_endx_sid_structure_sub_tlv(self, SubTlv, **kwargs):
        config = Ospfv3Router.create_endx_sid_structure_sub_tlv(SubTlv=SubTlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_lan_endx_sid_structure_sub_tlv(self, SubTlv, **kwargs):
        config = Ospfv3Router.create_lan_endx_sid_structure_sub_tlv(SubTlv=SubTlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_network_lsa(self, Session, **kwargs):
        config = Session.create_network_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_network_atch_router(self, Lsa, **kwargs):
        config = Ospfv3Router.create_network_atch_router(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_intra_area_prefix_lsa(self, Session, **kwargs):
        config = Session.create_intra_area_prefix_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_inter_area_prefix_lsa(self, Session, **kwargs):
        config = Session.create_inter_area_prefix_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_sr_fapm_sub_tlv(self, Lsa, **kwargs):
        config = Ospfv3Router.create_sr_fapm_sub_tlv(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_bier_sub_tlv(self, Lsa, **kwargs):
        config = Ospfv3Router.create_bier_sub_tlv(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_bier_mpls_encap_sub_tlv(self, SubTlv, **kwargs):
        config = Ospfv3Router.create_bier_mpls_encap_sub_tlv(SubTlv=SubTlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_inter_area_router_lsa(self, Session, **kwargs):
        config = Session.create_inter_area_router_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_as_external_lsa(self, Session, **kwargs):
        config = Session.create_as_external_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_nssa_external_lsa(self, Session, **kwargs):
        config = Session.create_nssa_external_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_link_lsa(self, Session, **kwargs):
        config = Session.create_link_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_opaque_router_info_lsa(self, Session, **kwargs):
        config = Session.create_opaque_router_info_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_sr_algorithm_tlv(self, Lsa, **kwargs):
        config = Ospfv3Router.create_sr_algorithm_tlv(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_sr_fad_tlv(self, Session, Lsa, **kwargs):
        config = Session.create_sr_fad_tlv(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_capabilities_tlv(self, Session, Lsa, **kwargs):
        config = Session.create_srv6_capabilities_tlv(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_node_msd_tlv(self, Session, Lsa, **kwargs):
        config = Session.create_srv6_node_msd_tlv(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_location_lsa(self, Session, **kwargs):
        config = Session.create_srv6_location_lsa(**kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_location_tlv(self, Session, Lsa, **kwargs):
        config = Session.create_srv6_location_tlv(Lsa=Lsa, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_end_sid_sub_tlv(self, Tlv, **kwargs):
        config = Ospfv3Router.create_srv6_end_sid_sub_tlv(Tlv=Tlv, **kwargs)
        return config

    @abnormal_check()
    def create_ospfv3_srv6_sid_structure_sub_tlv(self, SubTlv, **kwargs):
        config = Ospfv3Router.create_srv6_sid_structure_sub_tlv(SubTlv=SubTlv, **kwargs)
        return config

    @abnormal_check()
    def get_ospf_router_from_lsa(self, Lsa):
        if not isinstance(Lsa, list):
            Lsa = [Lsa]
        result = [x.get_relatives('GenerateLsa', direction=EnumRelationDirection.SOURCE)[0] for x in Lsa]
        return result

    @abnormal_check()
    def advertise_ospfv3_lsa(self, Sessions, Type=None, Lsa=None):
        if Lsa is None:
            if not isinstance(Sessions, (list, set, tuple)):
                Sessions = [Sessions]
            for Session in Sessions:
                Session.advertise(Type=Type)
        else:
            if not isinstance(Lsa, list):
                Lsa = [Lsa]
            Ospfv3AdvertiseCommand(Ospfv2LsaConfigs=[x.handle for x in Lsa], cl_instance=self.cl_instance).execute()
        return True

    @abnormal_check()
    def withdraw_ospfv3_lsa(self, Sessions, Type=None, Lsa=None):
        if Lsa is None:
            if not isinstance(Sessions, (list, set, tuple)):
                Sessions = [Sessions]
            for Session in Sessions:
                Session.withdraw(Type=Type)
        else:
            if not isinstance(Lsa, list):
                Lsa = [Lsa]
            Ospfv3WithdrawCommand(Ospfv2LsaConfigs=[x.handle for x in Lsa], cl_instance=self.cl_instance).execute()
        return True

    @abnormal_check()
    def establish_ospfv3(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.establish()
        return True

    @abnormal_check()
    def grace_restart_ospfv3(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.grace_restart()
        return True

    @abnormal_check()
    def get_ospfv3_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Ospfv3SessionResultPropertySet", Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def edit_ospfv3_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('Ospfv3PortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    # ------------------------- GATHER bgp -------------------------------------
    @abnormal_check()
    def create_bgp(self, Port, **kwargs):
        session = BgpRouter(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_bgp(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def create_bgp_ipv4_route_pool(self, Session, **kwargs):
        return Session.create_ipv4_route_pool(**kwargs)

    @abnormal_check()
    def create_bgp_ipv6_route_pool(self, Session, **kwargs):
        return Session.create_ipv6_route_pool(**kwargs)

    @abnormal_check()
    def create_bgp_capability(self, Session, **kwargs):
        return Session.create_capability(**kwargs)

    @abnormal_check()
    def create_bgp_evpn_route_ad(self, Session, **kwargs):
        return Session.create_evpn_route_ad(**kwargs)

    @abnormal_check()
    def get_bgp_router_from_route_pool(self, Configs, Type='ipv4'):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        if Type.lower() == 'ipv4':
            result = [x.get_relatives('GenerateIpv4Route', direction=EnumRelationDirection.SOURCE, )[0] for x in Configs]
        else:
            result = [x.get_relatives('GenerateIpv6Route', direction=EnumRelationDirection.SOURCE)[0] for x in Configs]
        return result

    @abnormal_check()
    def advertise_bgp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        cmd = BgpAdvertiseRoutesCommand(BgpSessionBlockHandles=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def withdraw_bgp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        cmd = BgpWithdrawnRoutesCommand(BgpSessionBlockHandles=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def advertise_bgp_route(self, Routes):
        BgpRouter.advertise_route(Routes=Routes)
        return True

    @abnormal_check()
    def withdraw_bgp_route(self, Routes):
        BgpRouter.withdraw_route(Routes=Routes)
        return True

    @abnormal_check()
    def establish_bgp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.establish()
        return True

    @abnormal_check()
    def connect_bgp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.connect()
        return True

    @abnormal_check()
    def disconnect_bgp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.disconnect()
        return True

    @abnormal_check()
    def wait_bgp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if isinstance(Sessions, (list, set, tuple)):
            session = Sessions[0]
        else:
            session = Sessions
        if isinstance(session, BgpProtocolConfig):
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, AttrName='BgpProtocolState', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def wait_bgp_router_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        Interval = int(Interval)
        TimeOut = int(TimeOut)
        if State is None:
            State = 'ESTABLISHED'
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        if not isinstance(State, (list, set, tuple)):
            State = [State]
        flag = True
        while flag:
            flag = False
            TimeOut = TimeOut - Interval
            if TimeOut == 0:
                raise TesterException(f'Wait for state({State} erorr)')
            else:
                for Session in Sessions:
                    version = Session.IpVersion
                    if isinstance(version, Enum):
                        version = version.name
                    if 'ipv4' in version.lower():
                        if hasattr(Session, 'Ipv4RouterState'):
                            state = getattr(Session, 'Ipv4RouterState', "NotFound")
                        else:
                            state = getattr(Session, 'BgpV4RouterState', "NotFound").name
                        if state not in State:
                            flag = True
                            break
                    elif 'ipv6' in version.lower():
                        if hasattr(Session, 'Ipv6RouterState'):
                            state = getattr(Session, 'Ipv6RouterState', "NotFound")
                        else:
                            state = getattr(Session, 'BgpV6RouterState', "NotFound").name
                        if state not in State:
                            flag = True
                            break
                    else:
                        if hasattr(Session, 'Ipv4RouterState'):
                            state = getattr(Session, 'Ipv4RouterState', "NotFound")
                        else:
                            state = getattr(Session, 'BgpV4RouterState', "NotFound").name
                        if state not in State:
                            flag = True
                            break
                        elif 'ipv6' in version.lower():
                            if hasattr(Session, 'Ipv6RouterState'):
                                state = getattr(Session, 'Ipv6RouterState', "NotFound")
                            else:
                                state = getattr(Session, 'BgpV6RouterState', "NotFound").name
                            if state not in State:
                                flag = True
                                break
            time.sleep(Interval)
        return True

    @abnormal_check()
    def wait_bgp_ipv4_router_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if isinstance(Sessions, (list, set, tuple)):
            session = Sessions[0]
        else:
            session = Sessions
        if isinstance(session, BgpProtocolConfig):
            if State is None:
                State = 'ESTABLISHED'
            return self._wait_state(Sessions=Sessions, AttrName='BgpV4RouterState', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'ESTABLISHED'
            return self._wait_state(Sessions=Sessions, AttrName='Ipv4RouterState', State=State, Interval=Interval,
                                    TimeOut=TimeOut)

    @abnormal_check()
    def wait_bgp_ipv6_router_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if isinstance(Sessions, (list, set, tuple)):
            session = Sessions[0]
        else:
            session = Sessions
        if isinstance(session, BgpProtocolConfig):
            if State is None:
                State = 'ESTABLISHED'
            return self._wait_state(Sessions=Sessions, AttrName='BgpV6RouterState', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'ESTABLISHED'
            return self._wait_state(Sessions=Sessions, AttrName='Ipv6RouterState', State=State, Interval=Interval,
                                    TimeOut=TimeOut)

    @abnormal_check()
    def internet_route_generator(self,
                                 PortNumber,
                                 Ipv4RouteNumber=300000,
                                 Ipv6RouteNumber=100000,
                                 Ipv4StartMask=23,
                                 Ipv6StartMask=32,
                                 Ipv4StartRoute="60.0.0.0",
                                 Ipv6StartRoute="60::"):
        Ipv4RouteNumber = int(Ipv4RouteNumber)
        Ipv6RouteNumber = int(Ipv6RouteNumber)
        Ipv4StartMask = int(Ipv4StartMask)
        Ipv6StartMask = int(Ipv6StartMask)
        ipv4routeperport = int(Ipv4RouteNumber / PortNumber)
        ipv6routeperport = int(Ipv6RouteNumber / PortNumber)
        ipv4mask = list()
        for i in range(Ipv4StartMask, 33):
            ipv4mask.append(i)
        ipv4routeblocknumber = len(ipv4mask)
        avagnumber = int(ipv4routeperport / ipv4routeblocknumber)
        ipv4routecount = list()
        for i in range(ipv4routeblocknumber):
            ipv4routecount.append(avagnumber)

        def ipv4_to_int(ipv4):
            ipv4 = [int(x) for x in ipv4.split(".")]
            ipv4_int = (ipv4[0] << 24) + (ipv4[1] << 16) + (ipv4[2] << 8) + ipv4[3]
            # print(bin(ipv4_int))
            return ipv4_int

        def int_to_ipv4(ip_int):
            ipv4 = []
            for x in (24, 16, 8, 0):
                ipv4.append(str(ip_int >> x & 0xFF))
                # print(ipv4)
            return ".".join(ipv4)

        ipv4routepool = list()
        for y in range(PortNumber):
            if y == 0:
                Ipv4StartRoute = Ipv4StartRoute
            else:
                Ipv4StartRoute = ipv4routepool[y - 1][-1]
                var = ipv4_to_int(Ipv4StartRoute) + (2 ** (32 - ipv4mask[-1])) * ipv4routecount[-1]
                var = int_to_ipv4(var)
                Ipv4StartRoute = var
            ip_pool = list()
            ip_pool.append(Ipv4StartRoute)
            for x in range(1, len(ipv4mask)):
                ip_address = ipv4_to_int(ip_pool[x - 1]) + (2 ** (32 - ipv4mask[x - 1])) * ipv4routecount[x - 1]
                ip_address = int_to_ipv4(ip_address)
                ip_pool.append(ip_address)
            ipv4routepool.append(ip_pool)
        result = list()
        result.append(ipv4routepool)
        result.append(ipv4mask)
        result.append(ipv4routecount)
        ipv6mask = list()
        for i in range(Ipv6StartMask, int(Ipv6StartMask) + 10):
            ipv6mask.append(i)
        ipv6routeblocknumber = len(ipv6mask)
        avagnumber = int(ipv6routeperport / ipv6routeblocknumber)
        ipv6routecount = list()
        for i in range(ipv6routeblocknumber):
            ipv6routecount.append(avagnumber)

        def ipseg2str(ipseglist):
            ipstr = ''
            for ipseg in ipseglist:
                if len(ipseg) == 1:
                    ipseg = '000' + ipseg
                elif len(ipseg) == 2:
                    ipseg = '00' + ipseg
                elif len(ipseg) == 3:
                    ipseg = '0' + ipseg
                elif len(ipseg) == 4:
                    ipseg = ipseg
                else:
                    return ""
                ipstr += ipseg
            return ipstr

        # 不带0压缩的ipv6转换为十进制，如2001:DB8:0:23:8:800:200C:417A
        def noCompressipv62dec(ipv6):
            iplist = ipv6.split(":")
            if iplist:
                ipstr = ipseg2str(iplist)
                # print(ipstr)
                return int(ipstr, 16)
            else:
                return ""

        # 带0压缩的ipv6转换为十进制，如FF01::1001
        def compressipv62dec(ipv6):
            compressList = ipv6.split("::")
            # print("compressList:" + str(compressList))
            ipstr = ""
            part1 = []
            part2 = []
            if len(compressList) == 2:
                part1 = compressList[0].split(":") if compressList[0] else []
                part2 = compressList[1].split(":") if compressList[1] else []
            if part1 or part2:
                ipstr += ipseg2str(part1)
                for i in range(8 - len(part1) - len(part2)):
                    ipstr += '0000'
                ipstr += ipseg2str(part2)
                # print("ipstr:" + ipstr)
                return int(ipstr, 16)
            else:
                return ""

        # 将ipv6中段中的0压缩，如005e压缩为5e
        def subZero(ipseg):
            index = 0
            for i in range(len(ipseg)):
                if ipseg[i] == '0':
                    index += 1
                else:
                    break
            if index > 2:
                return ipseg[index:] if ipseg[index:] else '0'
            else:
                return ipseg

        # 将十进制数转换为ipv6
        def dec2ipv6(dec):
            if checkdec(dec) and int(dec) <= 340282366920938463463374607431768211455:
                hexstr = (hex(int(dec)))[2:]
                hexstrlen = len(hexstr)
                while hexstrlen < 32:
                    hexstr = '0' + hexstr
                    hexstrlen += 1
                result = subZero(hexstr[0:4]) + ":" + subZero(hexstr[4:8]) + ":" + subZero(
                    hexstr[8:12]) + ":" + subZero(
                    hexstr[12:16]) + ":" + subZero(hexstr[16:20]) + ":" + subZero(hexstr[20:24]) + ":" + subZero(
                    hexstr[24:28]) + ":" + subZero(hexstr[28:])
                # print("result:" + result)
                return result
            else:
                return ""

        # 十进制地址检查
        def checkdec(dec):
            matchobj = re.match(r'(0[dD])?[0-9]+$', dec)
            if matchobj:
                return True
            else:
                return False

        # 将IPv6地址压缩为::模式
        def ipv6compress(ipv6):
            address = ":".join('' if i == '0000' else i.lstrip('0') for i in ipv6.split(':'))
            result = (re.sub(r'(:)\1+', r'\1\1', address).lower())
            if '::' not in result:
                a = list()
                for i in result.split(':'):
                    a.append(i)
                if a[-1] == '':
                    result += ':'
                    return result
                else:
                    return result
            else:
                return result

        ipv6routepool = list()
        for y in range(PortNumber):
            if y == 0:
                Ipv6StartRoute = Ipv6StartRoute
            else:
                Ipv6StartRoute = ipv6routepool[y - 1][-1]
                varv6 = compressipv62dec(Ipv6StartRoute) + (2 ** (128 - ipv6mask[-1])) * ipv6routecount[-1]
                varv6 = dec2ipv6(str(varv6))
                varv6 = ipv6compress(varv6)
                Ipv6StartRoute = varv6
            ipv6_pool = list()
            ipv6_pool.append(Ipv6StartRoute)
            for x in range(1, len(ipv6mask)):
                if '::' in ipv6_pool[x - 1]:
                    ipv6_address = compressipv62dec(ipv6_pool[x - 1]) + (2 ** (128 - ipv6mask[x - 1])) * ipv6routecount[
                        x - 1]
                else:
                    ipv6_address = noCompressipv62dec(ipv6_pool[x - 1]) + (2 ** (128 - ipv6mask[x - 1])) * \
                                   ipv6routecount[x - 1]
                ipv6_address = dec2ipv6(str(ipv6_address))
                ipv6_address = ipv6compress(ipv6_address)
                if ipv6_address[-1] == ':' and ipv6_address[-2] != ':':
                    ipv6_address = ipv6_address + '0'
                ipv6_pool.append(ipv6_address)
            ipv6routepool.append(ipv6_pool)
        result.append(ipv6routepool)
        result.append(ipv6mask)
        result.append(ipv6routecount)
        return result

    @abnormal_check()
    def create_bgp_random_route(self,
                                PortNumber,
                                Type=None,
                                Ipv4RouteNumber=300000,
                                Ipv6RouteNumber=100000,
                                Ipv4StartMask=23,
                                Ipv6StartMask=32,
                                Ipv4StartRoute="60.0.0.0",
                                Ipv6StartRoute="60::",
                                **kwargs
                                ):
        Routes = self.internet_route_generator(PortNumber=PortNumber,
                                               Ipv4RouteNumber=Ipv4RouteNumber,
                                               Ipv6RouteNumber=Ipv6RouteNumber,
                                               Ipv4StartMask=Ipv4StartMask,
                                               Ipv6StartMask=Ipv6StartMask,
                                               Ipv4StartRoute=Ipv4StartRoute,
                                               Ipv6StartRoute=Ipv6StartRoute)
        if Type is not None and Type.lower() == 'ipv4':
            ipv4Routes = Routes[:len(Routes) // 2]
        elif Type is not None and Type.lower() == 'ipv6':
            ipv6Routes = Routes[len(Routes) // 2:]
        else:
            ipv4Routes = Routes[:len(Routes) // 2]
            ipv6Routes = Routes[len(Routes) // 2:]
        bgpProtocolConfig = [x for x in self.rom_manager.get_all_objects().values() if isinstance(x, BgpProtocolConfig)]
        bgpRoutepoolConfig = []
        if 'ipv4Routes' in locals().keys():
            bgpProtocolConfigv4 = [x for x in bgpProtocolConfig if
                                   x.IpVersion.name == 'IPV4' or x.IpVersion.name == 'BOTH']
            bgpProtocolConfigv4 = bgpProtocolConfigv4[:len(ipv4Routes[0])]
            bgpIpv4RoutepoolConfig = [x for x in self.rom_manager.get_all_objects().values() if
                                      isinstance(x, BgpIpv4RoutepoolConfig)]
            if bgpIpv4RoutepoolConfig:
                for x in bgpIpv4RoutepoolConfig:
                    x.delete()
            firstRouteList = ipv4Routes[0]
            maskList = ipv4Routes[1]
            countList = ipv4Routes[2]
            num = 0
            for bgpSession in bgpProtocolConfigv4:
                num_1 = 0
                firstRoute = firstRouteList[num]
                for route in firstRoute:
                    bgpRoutepoolConfig.append(
                        BgpIpv4RoutepoolConfig(upper=bgpSession, FirstRoute=route, RouteCount=countList[num_1],
                                               PrefixLength=maskList[num_1], **kwargs))
                    num_1 += 1
                num += 1
        if 'ipv6Routes' in locals().keys():
            bgpProtocolConfigv6 = [x for x in bgpProtocolConfig if
                                   x.IpVersion.name == 'IPV6' or x.IpVersion.name == 'BOTH']
            bgpProtocolConfigv6 = bgpProtocolConfigv6[:len(ipv6Routes[0])]
            bgpIpv6RoutepoolConfig = [x for x in self.rom_manager.get_all_objects().values() if
                                      isinstance(x, BgpIpv6RoutepoolConfig)]
            if bgpIpv6RoutepoolConfig:
                for x in bgpIpv6RoutepoolConfig:
                    x.delete()
            firstRouteList = ipv6Routes[0]
            maskList = ipv6Routes[1]
            countList = ipv6Routes[2]
            num = 0
            for bgpSession in bgpProtocolConfigv6:
                num_1 = 0
                firstRoute = firstRouteList[num]
                for route in firstRoute:
                    bgpRoutepoolConfig.append(
                        BgpIpv6RoutepoolConfig(upper=bgpSession, FirstIpv6Route=route, RouteCount=countList[num_1],
                                               PrefixLength=maskList[num_1], **kwargs))
                    num_1 += 1
                num += 1
        if not bgpRoutepoolConfig:
            bgpRoutepoolConfig = EnumBase.FALSE.value
        return bgpRoutepoolConfig

    @abnormal_check()
    def create_bgp_route_pool_custom_path_attribute(self, RoutePool, **kwargs):
        if not isinstance(RoutePool, (list, set, tuple)):
            RoutePool = [RoutePool]
        configs = []
        for i in RoutePool:
            config = BgpRouter.create_route_pool_custom_path_attribute(RoutePool=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_evpn_mac_ip_routes(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_evpn_mac_ip_routes(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_evpn_inclusive_multicast_routes(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_evpn_inclusive_multicast_routes(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_evpn_ethernet_segment_routes(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_evpn_ethernet_segment_routes(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_evpn_ip_prefix_routes(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_evpn_ip_prefix_routes(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_ipv4_vpls(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_ipv4_vpls(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_ipv6_vpls(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_ipv6_vpls(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_ipv4_flow_specs(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_ipv4_flow_specs(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_flow_specs_actions(self, FlowSpec, **kwargs):
        if not isinstance(FlowSpec, (list, set, tuple)):
            FlowSpec = [FlowSpec]
        configs = []
        for i in FlowSpec:
            config = BgpRouter.create_flow_specs_actions(FlowSpec=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_flow_spec_conponent_type(self, FlowSpec, Types, **kwargs):
        if not isinstance(Types, (list, set, tuple)):
            Types = [Types]
        configs = []
        for Type in Types:
            config = BgpRouter.create_flow_spec_conponent_type(FlowSpec=FlowSpec, Type=Type, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_flow_spec_custom_path_attribute(self, FlowSpec, **kwargs):
        if not isinstance(FlowSpec, (list, set, tuple)):
            FlowSpec = [FlowSpec]
        configs = []
        for i in FlowSpec:
            config = BgpRouter.create_flow_spec_custom_path_attribute(FlowSpec=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_ipv6_flow_spec(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_ipv6_flow_spec(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_ipv6_flow_spec_action(self, FlowSpec, **kwargs):
        if not isinstance(FlowSpec, (list, set, tuple)):
            FlowSpec = [FlowSpec]
        configs = []
        for i in FlowSpec:
            config = BgpRouter.create_ipv6_flow_spec_action(FlowSpec=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_sr_te_policy(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_sr_te_policy(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_sr_te_policy_Segement_list(self, Session, SrTePolicy, **kwargs):
        if not isinstance(SrTePolicy, (list, set, tuple)):
            SrTePolicy = [SrTePolicy]
        configs = []
        for i in SrTePolicy:
            config = Session.create_sr_te_policy_Segement_list(SrTePolicy=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_segement_sub_tlv(self, Session, SegementList, Types, **kwargs):
        if not isinstance(Types, (list, set, tuple)):
            Types = [Types]
        configs = []
        for Type in Types:
            config = Session.create_segement_sub_tlv(SegementList=SegementList, Type=Type, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_link_states(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        configs = []
        for i in Session:
            config = i.create_link_states(**kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_link_states_link(self, Session, LinkState, **kwargs):
        if not isinstance(LinkState, (list, set, tuple)):
            LinkState = [LinkState]
        configs = []
        for i in LinkState:
            config = Session.create_link_states_link(LinkState=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_link_states_prefix(self, Session, LinkState, **kwargs):
        if not isinstance(LinkState, (list, set, tuple)):
            LinkState = [LinkState]
        configs = []
        for i in LinkState:
            config = Session.create_link_states_prefix(LinkState=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_link_states_prefix_sr_range_sub_tlv(self, Session, LinkStatePrefix, **kwargs):
        if not isinstance(LinkStatePrefix, (list, set, tuple)):
            LinkStatePrefix = [LinkStatePrefix]
        configs = []
        for i in LinkStatePrefix:
            config = Session.create_link_states_prefix_sr_range_sub_tlv(LinkStatePrefix=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_bgp_link_states_srv6_sid(self, Session, LinkState, **kwargs):
        if not isinstance(LinkState, (list, set, tuple)):
            LinkState = [LinkState]
        configs = []
        for i in LinkState:
            config = Session.create_link_states_srv6_sid(LinkState=i, **kwargs)
            configs.append(config)
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def graceful_restart_bgp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.graceful_restart()
        return True

    @abnormal_check()
    def refresh_bgp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.refresh()
        return True

    @abnormal_check()
    def get_bgp_evpn_routes_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="EvpnRoutesStatistic",
                                     Idx={'BgpSessionBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bgp_link_state_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="BgpLinkStateStatistic",
                                     Idx={'BgpSessionBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bgp_session_statistic(self, Session=None, Id=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="BgpSessionStatistic",
                                     Idx={'BgpSessionBlockId': sessionID, 'BgpPeerId': int(Id)},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bgp_session_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="BgpSessionBlockStatistic",
                                     Idx={'BgpSessionBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def edit_bgp_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('BgpPortRateConfig')[0]
            if 'BgpSrVersion' in kwargs.keys():
                v = kwargs['BgpSrVersion']
                if not isinstance(v, (list, set, tuple)):
                    v = [v]
                tmp = [EnumBgpSrVersion[i].value for i in v]
                setattr(config, 'BgpSrVersion', int(sum(tmp)))
                kwargs.pop('BgpSrVersion')
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def sent_bgp_data(self, Session, Data):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        if isinstance(Session, BgpProtocolConfig):
            send_cmd = BgpSendDataCommand(BgpSessionBlockHandle=Session.handle, BgpHexDataString=Data)
            send_cmd.execute()
        else:
            Session.sent_data(Data)
        return True

    # ------------------------- GATHER isis -------------------------------------
    @abnormal_check()
    def create_isis(self, Port, **kwargs):
        session = IsisRouter(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_isis(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def edit_isis_global_options(self, **kwargs):
        option = self.sys_entry.get_children('IsisGlobalTypeOption')[0]
        option.edit(**kwargs)
        return True

    @abnormal_check()
    def edit_isis_per_pdu(self, Session, Index, **kwargs):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        Session.edit_per_pdu_authentication(Index=Index, **kwargs)
        return True

    @abnormal_check()
    def get_isis_per_pdu(self, Session, Index):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        return Session.get_per_pdu_authentication(Index=Index)

    @abnormal_check()
    def edit_isis_mt_params(self, Session, Index, MtId=None, MtFlags=None):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        Session.edit_mt_params(Index=Index, MtId=MtId, MtFlags=MtFlags)
        return True

    @abnormal_check()
    def get_isis_mt_params(self, Session, Index):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        return Session.get_mt_params(Index=Index)

    @abnormal_check()
    def create_isis_lsp(self, Session, **kwargs):
        return Session.create_lsp(**kwargs)

    @abnormal_check()
    def create_isis_ipv4_tlv(self, Lsp, **kwargs):
        return IsisRouter.create_ipv4_tlv(Lsp=Lsp, **kwargs)

    @abnormal_check()
    def create_isis_ipv6_tlv(self, Lsp, **kwargs):
        return IsisRouter.create_ipv6_tlv(Lsp=Lsp, **kwargs)

    @abnormal_check()
    def get_isis_router_from_tlv(self, Configs):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        result = [x.get_relatives('GenerateLsp', direction=EnumRelationDirection.SOURCE)[0] for x in Configs]
        return result

    @abnormal_check()
    def wait_isis_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if isinstance(Sessions, (list, set, tuple)):
            session = Sessions[0]
        else:
            session = Sessions
        if isinstance(session, IsisProtocolConfig):
            if State is None:
                State = 'UP'
            return self._wait_state(Sessions=Sessions, AttrName='RouterState', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'UP'
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def wait_isis_three_way_p2p_adj_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        return self._wait_state(Sessions=Sessions, AttrName='ThreeWayP2pAdjState', State=State, Interval=Interval,
                                TimeOut=TimeOut)

    @abnormal_check()
    def wait_isis_l1_broadcast_adj_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['DISOTHER', 'DIS']
        return self._wait_state(Sessions=Sessions, AttrName='L1BroadcastAdjState', State=State, Interval=Interval,
                                TimeOut=TimeOut)

    @abnormal_check()
    def wait_isis_l2_broadcast_adj_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['DISOTHER', 'DIS']
        return self._wait_state(Sessions=Sessions, AttrName='L2BroadcastAdjState', State=State, Interval=Interval,
                                TimeOut=TimeOut)

    @abnormal_check()
    def create_isis_neighbor_tlv(self, Lsp, **kwargs):
        return IsisRouter.create_neighbor_tlv(Lsp=Lsp, **kwargs)

    @abnormal_check()
    def create_isis_neighbor_te_config(self, Neighbor, **kwargs):
        return IsisRouter.create_neighbor_te_config(Neighbor=Neighbor, **kwargs)

    @abnormal_check()
    def create_isis_neighbor_sr_adj_sid_sub_tlv(self, Session, Neighbor, **kwargs):
        return Session.create_neighbor_sr_adj_sid_sub_tlv(Neighbor=Neighbor, **kwargs)

    @abnormal_check()
    def create_isis_neighbor_sr_lan_adj_sid_sub_tlv(self, Session, Neighbor, **kwargs):
        return Session.create_neighbor_sr_lan_adj_sid_sub_tlv(Neighbor=Neighbor, **kwargs)

    @abnormal_check()
    def create_isis_neighbor_srv6_endx_sid_sub_tlv(self, Session, Neighbor, **kwargs):
        return Session.create_neighbor_srv6_endx_sid_sub_tlv(Neighbor=Neighbor, **kwargs)

    @abnormal_check()
    def create_isis_neighbor_srv6_lan_endx_sid_sub_tlv(self, Session, Neighbor, **kwargs):
        return Session.create_neighbor_srv6_lan_endx_sid_sub_tlv(Neighbor=Neighbor, **kwargs)

    @abnormal_check()
    def create_isis_neighbor_sr_link_msd_sub_tlv(self, Session, Neighbor, **kwargs):
        return Session.create_neighbor_sr_link_msd_sub_tlv(Neighbor=Neighbor, **kwargs)

    @abnormal_check()
    def create_isis_neighbor_custom_sub_tlv(self, SubTlv, **kwargs):
        return IsisRouter.create_custom_sub_tlv(SubTlv=SubTlv, **kwargs)

    @abnormal_check()
    def create_isis_tlv_prefix_sid_sub_tlv(self, Session, Tlv, **kwargs):
        return Session.create_tlv_prefix_sid_sub_tlv(Tlv=Tlv, **kwargs)

    @abnormal_check()
    def create_isis_tlv_flex_algorithm_prefix_metric_sub_tlv(self, Tlv, **kwargs):
        return IsisRouter.create_tlv_flex_algorithm_prefix_metric_sub_tlv(Tlv=Tlv, **kwargs)

    @abnormal_check()
    def create_isis_tlv_bier_sub_tlv(self, Tlv, **kwargs):
        return IsisRouter.create_tlv_bier_sub_tlv(Tlv=Tlv, **kwargs)

    @abnormal_check()
    def create_isis_tlv_bier_Mpls_sub_sub_tlv(self, Bier, **kwargs):
        return IsisRouter.create_tlv_bier_Mpls_sub_sub_tlv(Bier=Bier, **kwargs)

    @abnormal_check()
    def create_isis_tlv_bierv6_sub_sub_tlv(self, Bier, **kwargs):
        return IsisRouter.create_tlv_bier_Mpls_sub_sub_tlv(Bier=Bier, **kwargs)

    @abnormal_check()
    def create_isis_tlv_end_bier_sub_tlv(self, Bier, **kwargs):
        return IsisRouter.create_tlv_end_bier_sub_tlv(Bier=Bier, **kwargs)

    @abnormal_check()
    def create_isis_tlv_bierv6_bift_id_sub_tlv(self, Bier, **kwargs):
        return IsisRouter.create_tlv_bierv6_bift_id_sub_tlv(Bier=Bier, **kwargs)

    @abnormal_check()
    def create_isis_capability_tlv(self, Session, Lsp, **kwargs):
        return Session.create_capability_tlv(Lsp=Lsp, **kwargs)

    @abnormal_check()
    def create_isis_capability_sr_capability_sub_tlv(self, Session, Capability, **kwargs):
        return Session.create_capability_sr_capability_sub_tlv(Capability=Capability, **kwargs)

    @abnormal_check()
    def create_isis_capability_sr_algorithm_sub_tlv(self, Capability, **kwargs):
        return IsisRouter.create_capability_sr_algorithm_sub_tlv(Capability=Capability, **kwargs)

    @abnormal_check()
    def create_isis_capability_srv6_capability_sub_tlv(self, Session, Capability, **kwargs):
        return Session.create_capability_srv6_capability_sub_tlv(Capability=Capability, **kwargs)

    @abnormal_check()
    def create_isis_capability_sr_node_msd_sub_tlv(self, Session, Capability, **kwargs):
        return Session.create_capability_sr_node_msd_sub_tlv(Capability=Capability, **kwargs)

    @abnormal_check()
    def create_isis_capability_sr_fad_sub_tlv(self, Session, Capability, **kwargs):
        return Session.create_capability_sr_fad_sub_tlv(Capability=Capability, **kwargs)

    @abnormal_check()
    def create_isis_capability_srms_preference_sub_tlv(self, Capability, **kwargs):
        return IsisRouter.create_capability_srms_preference_sub_tlv(Capability=Capability, **kwargs)

    @abnormal_check()
    def create_isis_sr_binding_tlv(self, Session, Lsp, **kwargs):
        return Session.create_sr_binding_tlv(Lsp=Lsp, **kwargs)

    @abnormal_check()
    def create_isis_binding_sr_sid_sub_tlv(self, Binding, **kwargs):
        return IsisRouter.create_binding_sr_sid_sub_tlv(Binding=Binding, **kwargs)

    @abnormal_check()
    def create_isis_srv6_location_tlv(self, Session, Lsp, **kwargs):
        return Session.create_srv6_location_tlv(Lsp=Lsp, **kwargs)

    @abnormal_check()
    def create_isis_srv6_end_sid_sub_tlv(self, Session, Location, **kwargs):
        return Session.create_srv6_end_sid_sub_tlv(Location=Location, **kwargs)

    @abnormal_check()
    def advertise_isis(self, Lsps, **kwargs):
        return IsisRouter.advertise(Lsps=Lsps, **kwargs)

    @abnormal_check()
    def withdraw_isis(self, Lsps, **kwargs):
        return IsisRouter.withdraw(Lsps=Lsps, **kwargs)

    @abnormal_check()
    def graceful_restart_isis(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.graceful_restart()
        return True

    @abnormal_check()
    def get_isis_session_stats(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="IsisSessionStats",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_isis_tlv_stats(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="IsisTlvStats",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def edit_isis_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('IsisPortRateConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    # ------------------------- GATHER pim -------------------------------------
    @abnormal_check()
    def create_pim(self, Port, **kwargs):
        session = PimRouter(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_pim(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def create_pim_group(self, Session, **kwargs):
        config = Session.create_group(**kwargs)
        return config

    @abnormal_check()
    def create_pim_ipv6_group(self, Session, **kwargs):
        config = Session.create_ipv6_group(**kwargs)
        return config

    @abnormal_check()
    def create_pim_register_group(self, Session, **kwargs):
        config = Session.create_register_group(**kwargs)
        return config

    @abnormal_check()
    def create_pim_ipv6_register_group(self, Session, **kwargs):
        config = Session.create_ipv6_register_group(**kwargs)
        return config

    @abnormal_check()
    def create_pim_rp_map(self, Session, **kwargs):
        config = Session.create_rp_map(**kwargs)
        return config

    @abnormal_check()
    def create_pim_ipv6_rp_map(self, Session, **kwargs):
        config = Session.create_ipv6_rp_map(**kwargs)
        return config

    @abnormal_check()
    def wait_pim_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        if State is None:
            State = ['NEIGHBOR']
        return self._wait_state(Sessions=Sessions, AttrName='state', State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def pim_start_boot_strap(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_boot_strap()
        return True

    @abnormal_check()
    def pim_stop_boot_strap(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_boot_strap()
        return True

    @abnormal_check()
    def pim_change_gen_id(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.change_gen_id()
        return True

    @abnormal_check()
    def pim_join_group(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.join_group()
        return True

    @abnormal_check()
    def pim_leave_group(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.leave_group()
        return True

    @abnormal_check()
    def pim_start_register(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_register()
        return True

    @abnormal_check()
    def pim_stop_register(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_register()
        return True

    @abnormal_check()
    def edit_pim_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('PimPortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def get_pim_session_stats(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="PimSessionStats",
                                     Idx={'SessionID': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pim_group_stats(self, Session=None, Group=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        if Group is None:
            groupID = None
        elif isinstance(Group, (list, set, tuple)):
            groupID = [x.Name for x in Group]
        else:
            groupID = Group.Name
        result = self._get_statictis(Statictis="PimGroupStats",
                                     Idx={'GroupID': groupID,
                                          'SessionID': sessionID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER igmp -------------------------------------
    @abnormal_check()
    def create_igmp(self, Port, **kwargs):
        session = Igmp(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_igmp(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def edit_igmp_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('IgmpPortRateConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def select_source_interface(self, Session, Memberships, Interface):
        return Session.select_source_interface(Memberships=Memberships, Interface=Interface)

    @abnormal_check()
    def wait_igmp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['MEMBER']
        if not isinstance(Sessions, (set, list, tuple)):
            Sessions = [Sessions]
        if isinstance(Sessions[0], IgmpProtocolConfig):
            return self._wait_state(Sessions=Sessions, AttrName='IgmpHostState', State=State, Interval=Interval, TimeOut=TimeOut)
        else:
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def igmp_send_report(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.send_report()
        return True

    @abnormal_check()
    def igmp_send_leave(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.send_leave()
        return True

    @abnormal_check()
    def igmp_resend_report(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resend_report()
        return True

    @abnormal_check()
    def get_igmp_host_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="IgmpHostResults", Idx={'IgmpHostBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_igmp_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="IgmpPortAggregatedResults", Idx={'IgmpPortId': portID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER igmp querier -------------------------------------
    @abnormal_check()
    def create_igmp_querier(self, Port, **kwargs):
        session = IgmpQuerier(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_igmp_querier(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def apply_igmp_querier(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.apply()
        return True

    @abnormal_check()
    def wait_igmp_querier_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['UP']
        return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def get_igmp_querier_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="IgmpQuerierResults", Idx={'QuerierId': sessionID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER mld -------------------------------------
    @abnormal_check()
    def create_mld(self, Port, **kwargs):
        session = Mld(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_mld(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def edit_mld_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('MldPortRateConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_multicast_group(self, Version="ipv4", **kwargs):
        return MulticastGroup(Version=Version, cl_instance=self.cl_instance, **kwargs)

    @abnormal_check()
    def create_memberships(self, Session, **kwargs):
        return Session.create_memberships(**kwargs)

    @abnormal_check()
    def binding_multicast_group(self, Session, Memberships, MulticastGroup):
        return Session.binding_multicast_group(Memberships=Memberships, MulticastGroup=MulticastGroup)

    @abnormal_check()
    def wait_mld_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['MEMBER']
        if not isinstance(Sessions, (set, list, tuple)):
            Sessions = [Sessions]
        if isinstance(Sessions[0], MldProtocolConfig):
            return self._wait_state(Sessions=Sessions, AttrName='MldHostState', State=State, Interval=Interval, TimeOut=TimeOut)
        else:
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def mld_send_report(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.send_report()
        return True

    @abnormal_check()
    def mld_send_leave(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.send_leave()
        return True

    @abnormal_check()
    def mld_resend_report(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resend_report()
        return True

    @abnormal_check()
    def get_mld_host_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="MldHostResults", Idx={'MldHostBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_mld_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="MldPortAggregatedResults", Idx={'MldPortId': portID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER mld querier -------------------------------------
    @abnormal_check()
    def create_mld_querier(self, Port, **kwargs):
        session = MldQuerier(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_mld_querier(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def apply_mld_querier(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.apply()
        return True

    @abnormal_check()
    def wait_mld_querier_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['UP']
        return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def get_mld_querier_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="MldQuerierResults", Idx={'QuerierId': sessionID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER vxlan -------------------------------------
    @abnormal_check()
    def create_vxlan(self, Port, **kwargs):
        session = Vxlan(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_vxlan(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def create_vxlan_segment(self, **kwargs):
        return Vxlan.create_segment(**kwargs)

    @abnormal_check()
    def binding_vxlan_multicast_group(self, Segments, MulticastGroups):
        if not isinstance(Segments, list):
            Segments = [Segments]
        if not isinstance(MulticastGroups, list):
            MulticastGroups = [MulticastGroups]
        return Vxlan.binding_multicast_group(Segments=Segments, MulticastGroups=MulticastGroups)

    @abnormal_check()
    def binding_vxlan_vm(self, Segments, Interfaces):
        if not isinstance(Segments, list):
            Segments = [Segments]
        if not isinstance(Interfaces, list):
            Interfaces = [Interfaces]
        return Vxlan.binding_vm(Segments=Segments, Interfaces=Interfaces)

    @abnormal_check()
    def binding_vxlan_vtep(self, Vteps, Interfaces):
        if not isinstance(Vteps, list):
            Vteps = [Vteps]
        if not isinstance(Interfaces, list):
            Interfaces = [Interfaces]
        return Vxlan.binding_vtep(Vteps=Vteps, Interfaces=Interfaces)

    @abnormal_check()
    def start_vxlan_ping(self, Interfaces, **kwargs):
        if not isinstance(Interfaces, list):
            Interfaces = [Interfaces]
        return Vxlan.start_ping(Interfaces=Interfaces, **kwargs)

    @abnormal_check()
    def stop_vxlan_ping(self, Interfaces, **kwargs):
        if not isinstance(Interfaces, list):
            Interfaces = [Interfaces]
        return Vxlan.stop_ping(Interfaces=Interfaces, **kwargs)

    @abnormal_check()
    def get_vxlan_vm_property(self, Interface):
        if isinstance(Interface, list):
            Interface = Interface[0]
        result = Interface.get_children("VxlanVmProperty")[0]
        return result

    @abnormal_check()
    def wait_vxlan_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def get_vxlan_vm_point(self, Vxlan):
        interface = Vxlan.session.get_relatives('VmRelation', direction=EnumRelationDirection.TARGET)[0]
        result = interface.get_children('Ipv4Layer')[0]
        return result

    # ------------------------- GATHER l2tp -------------------------------------
    @abnormal_check()
    def create_l2tp(self, Port, **kwargs):
        session = L2tp(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_l2tp(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def connect_l2tp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.connect()
        return True

    @abnormal_check()
    def disconnect_l2tp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.disconnect()
        return True

    @abnormal_check()
    def abort_l2tp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.abort()
        return True

    @abnormal_check()
    def wait_l2tp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def edit_l2tp_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('L2tpProtocolConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def get_l2tp_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="L2tpPortStatistic",
                                     Idx={'PortName': portID},
                                     StaItems=StaItems)
        return result

    def get_l2tp_session_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="L2tpBlockStatistic",
                                     Idx={'L2tpBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    def get_l2tp_session_statistic(self, Session=None, NodeIndexInBlock=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="L2tpSessionStatistic",
                                     Idx={'L2tpBlockId': sessionID,
                                          'NodeIndexInBlock': NodeIndexInBlock},
                                     StaItems=StaItems)
        return result

    def get_l2tp_tunnel_statistic(self, Session=None, NodeIndexInBlock=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="L2tpTunnelStatistic",
                                     Idx={'L2tpBlockId': sessionID,
                                          'NodeIndexInBlock': NodeIndexInBlock},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER pppoe -------------------------------------
    @abnormal_check()
    def create_pppoe(self, Port, EmulationMode='CLIENT', **kwargs):
        if EmulationMode.lower() == 'server':
            session = PppoeServer(Upper=Port, **kwargs)
        else:
            session = PppoeClent(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_pppoe(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def connect_pppoe(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.connect()
        return True

    @abnormal_check()
    def disconnect_pppoe(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.disconnect()
        return True

    @abnormal_check()
    def abort_pppoe(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.abort()
        return True

    @abnormal_check()
    def create_pppoe_custom_option(self, Session, **kwargs):
        if not isinstance(Session, (list, set, tuple)):
            Session = [Session]
        result = [x.create_custom_option(**kwargs) for x in Session]
        if len(result) == 1:
            return result[0]
        else:
            return result

    @abnormal_check()
    def wait_pppoe_ipcp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_ipcp_state(State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def wait_pppoe_ipv6cp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_ipv6cp_state(State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def get_pppoe_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="PppoePortStatistic", Idx={'PortHandle': portID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pppoe_server_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="PppoeServerBlockStatistic", Idx={'PppoeServerBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pppoe_server_statistic(self, Session=None, Index=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="PppoeServerStatistic",
                                     Idx={'PppoeServerBlockId': sessionID, 'PppoeServerId': Index},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pppoe_client_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="PppoeClientBlockStatistic", Idx={'PppoeClientBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pppoe_client_statistic(self, Session=None, Index=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="PppoeClientStatistic",
                                     Idx={'PppoeClientBlockId': sessionID, 'PppoeClientId': Index},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER rip -------------------------------------
    @abnormal_check()
    def create_rip(self, Port, **kwargs):
        session = RipRouter(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_rip(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def create_rip_ipv4_route(self, Session, **kwargs):
        return Session.create_ipv4_route(**kwargs)

    @abnormal_check()
    def create_rip_ipv6_route(self, Session, **kwargs):
        return Session.create_ipv6_route(**kwargs)

    @abnormal_check()
    def advertise_rip(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.advertise()
        return True

    @abnormal_check()
    def withdraw_rip(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.withdraw()
        return True

    @abnormal_check()
    def suspend_rip(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.suspend()
        return True

    @abnormal_check()
    def resume_rip(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resume()
        return True

    @abnormal_check()
    def wait_rip_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def get_rip_session_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="RipSessionBlockStats",
                                     Idx={'SessionBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_rip_session_statistic(self, Session=None, SessionId=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="RipSessionStats",
                                     Idx={'SessionBlockId': sessionID, 'SessionId': SessionId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_rip_router_from_route(self, Route):
        if not isinstance(Route, list):
            Route = [Route]
        result = [x.get_relatives('GenerateRipRoute', direction=EnumRelationDirection.SOURCE)[0] for x in Route]
        return result

    @abnormal_check()
    def edit_rip_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('RipPortRateConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    # ------------------------- GATHER bfd -------------------------------------
    @abnormal_check()
    def create_bfd(self, Port, **kwargs):
        session = BfdRouter(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_bfd(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def create_bfd_ipv4_session(self, Session, **kwargs):
        return Session.create_ipv4_session(**kwargs)

    @abnormal_check()
    def create_bfd_ipv6_session(self, Session, **kwargs):
        return Session.create_ipv6_session(**kwargs)

    @abnormal_check()
    def bfd_admin_down(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.admin_down()
        return True

    @abnormal_check()
    def bfd_admin_up(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.admin_up()
        return True

    @abnormal_check()
    def bfd_enable_demand_mode(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.enable_demand_mode()
        return True

    @abnormal_check()
    def bfd_disable_Demand_mode(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.disable_demand_mode()
        return True

    @abnormal_check()
    def bfd_initiate_poll(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.initiate_poll()
        return True

    @abnormal_check()
    def bfd_resume_pdus(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resume_pdus()
        return True

    @abnormal_check()
    def bfd_set_diagnostic_state(self, Sessions, State):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.set_diagnostic_state(State=State)
        return True

    @abnormal_check()
    def bfd_stop_pdus(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_pdus()
        return True

    @abnormal_check()
    def wait_bfd_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def get_bfd_session_result(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="BfdSessionResult",
                                     Idx={'SessionID': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bfd_ipv4_session_result(self, Session=None, SessionId=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="BfdIpv4SessionResult",
                                     Idx={'Ipv4SessionID': sessionID, 'SessionIndex': SessionId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bfd_ipv6_session_result(self, Session=None, SessionId=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="BfdIpv6SessionResult",
                                     Idx={'Ipv6SessionID': sessionID, 'SessionIndex': SessionId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bfd_isis_session_result(self, BfdSession=None, IsisSession=None, SessionId=1, StaItems=None):
        if BfdSession is None:
            bfdID = None
        elif isinstance(BfdSession, (list, set, tuple)):
            bfdID = [x.Name for x in BfdSession]
        else:
            bfdID = BfdSession.Name
        if IsisSession is None:
            isisID = None
        elif isinstance(IsisSession, (list, set, tuple)):
            isisID = [x.Name for x in IsisSession]
        else:
            isisID = IsisSession.Name
        result = self._get_statictis(Statictis="IsisBfdSessionResult",
                                     Idx={'SessionID': bfdID, 'IpSessionID': isisID,
                                          'SessionIndex': SessionId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bfd_isis_ipv6_session_result(self, BfdSession=None, IsisSession=None, SessionId=1, StaItems=None):
        if BfdSession is None:
            bfdID = None
        elif isinstance(BfdSession, (list, set, tuple)):
            bfdID = [x.Name for x in BfdSession]
        else:
            bfdID = BfdSession.Name
        if IsisSession is None:
            isisID = None
        elif isinstance(IsisSession, (list, set, tuple)):
            isisID = [x.Name for x in IsisSession]
        else:
            isisID = IsisSession.Name
        result = self._get_statictis(Statictis="IsisBfdIpv6SessionResult",
                                     Idx={'SessionID': bfdID, 'IpSessionID': isisID,
                                          'SessionIndex': SessionId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bfd_ospfv2_session_result(self, BfdSession=None, Ospfv2Session=None, SessionId=1, StaItems=None):
        if BfdSession is None:
            bfdID = None
        elif isinstance(BfdSession, (list, set, tuple)):
            bfdID = [x.Name for x in BfdSession]
        else:
            bfdID = BfdSession.Name
        if Ospfv2Session is None:
            ospfID = None
        elif isinstance(Ospfv2Session, (list, set, tuple)):
            ospfID = [x.Name for x in Ospfv2Session]
        else:
            ospfID = Ospfv2Session.Name
        result = self._get_statictis(Statictis="Ospfv2BfdSessionResult",
                                     Idx={'SessionID': bfdID, 'Ipv4SessionID': ospfID,
                                          'SessionIndex': SessionId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_bfd_ospfv3_session_result(self, BfdSession=None, Ospfv3Session=None, SessionId=1, StaItems=None):
        if BfdSession is None:
            bfdID = None
        elif isinstance(BfdSession, (list, set, tuple)):
            bfdID = [x.Name for x in BfdSession]
        else:
            bfdID = BfdSession.Name
        if Ospfv3Session is None:
            ospfID = None
        elif isinstance(Ospfv3Session, (list, set, tuple)):
            ospfID = [x.Name for x in Ospfv3Session]
        else:
            ospfID = Ospfv3Session.Name
        result = self._get_statictis(Statictis="Ospfv3BfdSessionResult",
                                     Idx={'SessionID': bfdID, 'Ipv6SessionID': ospfID,
                                          'SessionIndex': SessionId},
                                     StaItems=StaItems)
        return result

    # -------------------------------------------------------------------
    @abnormal_check()
    def edit_configs(self, Configs, **kwargs):
        if not isinstance(Configs, list):
            Configs = [Configs]
        for k, v in kwargs.items():
            for config in Configs:
                if hasattr(config, k):
                    setattr(config, str(k), v)
        return True

    @abnormal_check()
    def get_config_children(self, Configs, Children):
        if not isinstance(Configs, list):
            Configs = [Configs]
        result = []
        for Config in Configs:
            result = result + Config.get_children(Children)
        return result

    @abnormal_check()
    def del_benchmark(self):
        clear_smart_scripter_commands()

    @abnormal_check()
    def ipv4_ping(self, Interface, IpAddr, PacketCount=5):

        '''
        从IPv4接口上ping一个IP地址,如果成功则返回字符串Success,如果不成功则返回其他，具体参见下面返回值说明

        参数描述：

            Interface：仪表的接口对象
            IpAddr：需要ping的目的ip地址，类型为字符串
            PacketCount：需要发送的ping包的个数，类型为整数, 可选参数，默认为5

        返回值：类型为字符串

            NotStart: 由于测试仪器问题，ping并没有真正的开始
            NotEnd：ping开始之后不能自动结束
            Success：ping成功了100收到响应报文
            Failed：ping失败了一个响应报文也没有收到
            PartialSuccess：ping部分成功收到了至少一个响应报文
            Unexpected：其他无法预知的情况

        '''

        pingConfig = self.sys_entry.get_children('Ipv4PingConfig')[0]
        pingAction = StartIpv4PingCommand(InterfaceHandle=Interface.handle,
                                          FrameCount=PacketCount, cl_instance=self.cl_instance,
                                          CustomIP=IpAddr)
        pingAction.execute()

        try:
            waitAction = WaitConditionCommand(WaitTime=5,
                                              ObjectHandles=pingConfig.handle,
                                              PropertyName="State",
                                              WaitOperator="EQUAL", cl_instance=self.cl_instance,
                                              ExpectValue=1)
            waitAction.execute()
        except Exception as e:
            print("Ping has not started in 5 seconds")
            print(e)
            return "NotStart"

        print("Ping has started.")

        try:
            waitAction = WaitConditionCommand(WaitTime=PacketCount * 5,
                                              ObjectHandles=pingConfig.handle,
                                              PropertyName="State",
                                              WaitOperator="EQUAL", cl_instance=self.cl_instance,
                                              ExpectValue=0)
            waitAction.execute()
        except Exception as e:
            print(f"Ping has not ended in {PacketCount * 2} seconds.")
            print(e)
            return "NotEnd"
        print("Ping has ended.")

        pingConfig = self.sys_entry.get_children('Ipv4PingConfig')[0]
        print("Ping result:")
        print(pingConfig.PingStatus)
        matchObj = re.search(r"Received Packets:\s*(\d+)\s*", pingConfig.PingStatus)
        if matchObj:
            recieveNumber = int(matchObj.group(1)) == PacketCount
            if recieveNumber:
                return True
            elif recieveNumber == 0:
                return False
            else:
                return "PartialSuccess"

        return "Unexpected"

    def ipv6_ping(self, Interface, IpAddr, PacketCount=5):

        '''
        从IPv6接口上ping一个IPv6地址,如果成功则返回字符串Success,如果不成功则返回其他，具体参见下面返回值说明

        参数描述：

            Interface：仪表的接口对象
            IpAddr：需要ping的目的ipv6地址，类型为字符串
            PacketCount：需要发送的ping包的个数，类型为整数, 可选参数，默认为5

        返回值：类型为字符串

            NotStart: 由于测试仪器问题，ping并没有真正的开始
            NotEnd：ping开始之后不能自动结束
            Success：ping成功的收到所有请求的响应报文
            Failed：ping失败了，一个响应报文也没有收到
            PartialSuccess：ping部分成功，收到了至少一个响应报文
            Unexpected：其他无法预知的情况

        '''

        pingConfig = self.sys_entry.get_children('Ipv6PingConfig')[0]
        pingAction = StartIpv6PingCommand(InterfaceHandle=Interface.handle,
                                          FrameCount=PacketCount, cl_instance=self.cl_instance,
                                          CustomIP=IpAddr)
        pingAction.execute()

        try:
            waitAction = WaitConditionCommand(WaitTime=5,
                                              ObjectHandles=pingConfig.handle,
                                              PropertyName="State",
                                              WaitOperator="EQUAL", cl_instance=self.cl_instance,
                                              ExpectValue=1)
            waitAction.execute()
        except Exception as e:
            print("Ping has not started in 5 seconds")
            print(e)
            return "NotStart"

        print("Ping has started.")

        try:
            waitAction = WaitConditionCommand(WaitTime=PacketCount * 5,
                                              ObjectHandles=pingConfig.handle,
                                              PropertyName="State",
                                              WaitOperator="EQUAL", cl_instance=self.cl_instance,
                                              ExpectValue=0)
            waitAction.execute()
        except Exception as e:
            print(f"Ping has not ended in {PacketCount * 2} seconds.")
            print(e)
            return "NotEnd"
        print("Ping has ended.")

        pingConfig = self.sys_entry.get_children('Ipv6PingConfig')[0]
        print("Ping result:")
        print(pingConfig.PingStatus)
        matchObj = re.search(r"Received Packets:\s*(\d+)\s*", pingConfig.PingStatus)
        if matchObj:
            recieveNumber = int(matchObj.group(1)) == PacketCount
            if recieveNumber:
                return True
            elif recieveNumber == 0:
                return False
            else:
                return "PartialSuccess"

        return "Unexpected"

    @abnormal_check()
    def ipv4_ping_stop(self, Interface):
        pingAction = StopIpv4PingCommand(InterfaceHandle=Interface.handle, cl_instance=self.cl_instance)
        pingAction.execute()
        return True

    @abnormal_check()
    def ipv6_ping_stop(self, Interface):
        pingAction = StopIpv6PingCommand(InterfaceHandle=Interface.handle, cl_instance=self.cl_instance)
        pingAction.execute()
        return True

    def wait_rom_property_changed(self, RomInstance, Property="State", ExpectedValue=1,
                                  Timeout=30, Operation="EQUAL"):
        '''
        Wait the specified Property of RomInstance to change into ExpectedValue, if the sate does not
        change in sepcified time, it will return string "Timeout", else if will return string "Changed".

        Parameters:
        RomInstance   -  Used to specify ROM object.
        Property      -  String type, Used to specify the property of ROM object. Default value is State.
        ExpectedValue -  Used to specify the what vlaue should the property should be changed into.
        Timeout       -  Used to specify when will timeout if the property does not changed.
        '''
        try:
            waitAction = WaitConditionCommand(Timeout,
                                              ObjectHandles=RomInstance.handle,
                                              PropertyName=Property,
                                              WaitOperator=Operation, cl_instance=self.cl_instance,
                                              ExpectValue=ExpectedValue)
            waitAction.execute()
        except Exception as e:
            print(RomInstance.__dict__)
            print(f"{Property} of ROM instance has not changed in {Timeout} seconds.")
            print(e)
            return "Timeout"

        print(f"{Property} of ROM instance has changed into {ExpectedValue}.")
        return "Changed"

    def get_tester_property(self, RomClassName, AttrName, Obj=None, Index=""):
        '''
        Get the value of specified property named AttrName in obj or its descendants.

        Parameter:

        Obj           - Renix object.
        RomClassName  - Renix object model class name, for example, Interface, Ipv4Layer, it should be a string.
        AttrName      - Attribute name of Renix object, it should be a string.
        Index         - There may be multiple renix objects in the Obj system, it will specify which one.
                        The index is start from 1. If not specified, it will get the first one.

        return value:

        If not found, return NotFound, else the vlaue for the specified property.
        '''

        # If the Obj is not specified, use the root ROM Object SysEntry as the search scope.
        if not Obj:
            Obj = self.sys_entry

        # Check if the Obj is a specified Renix Object, if yes, get the specified property and return.

        if Index:
            exp = r"^" + RomClassName + "_" + str(Index) + "$"
        else:
            exp = r"^" + RomClassName + r"_\d+$"

        if re.match(exp, Obj.handle):
            value = getattr(Obj, AttrName, "NotFound")
            return value

        # If the Obj is not a specified Renix Object, get its children object.

        children = Obj.get_children()
        if not children:
            return "NotFound"

        # If any obj in children is the specified Renix Object, get the property.

        for obj in children:
            value = self.get_tester_property(
                RomClassName, AttrName, obj, Index)
            if value != "NotFound":
                return value

        # If could not find in chirdren, return NotFound
        return "NotFound"

    @abnormal_check()
    def get_tester_object(self, RomClassName, Obj=None, Index=""):
        '''
        Get specified object of RomClassName class in the Obj or its descendants.
        If Index is specified, it will find the obj with specified index.
        If not, it will find the first obj in the Obj or its descendants.

        Parameters:

        Obj      - Renix object.

        RomClassName  - Renix object model class name, for example, Interface, Ipv4Layer, it should be a string.

        Index - There may be multiple renix objects of the specified class in the Obj system,
                   it will specify which one. The index is start from 1. If not specified, it will
                   get the first one.

        Return value:

        Return found object if found or None.
        '''

        # If the Obj is not specified, use the root ROM Object SysEntry as the search scope.
        if not Obj:
            Obj = self.sys_entry

        # Check if the Obj is a Renix Object of specified class, if yes, return the Obj.
        if Index:
            exp = r"^" + RomClassName + "_" + str(Index) + "$"
        else:
            exp = r"^" + RomClassName + r"_\d+$"
        if re.match(exp, Obj.handle):
            return Obj

        # If the Obj is not a Renix Object of specified class, get its children objects.
        children = Obj.get_children()

        # If no child, return.
        if not children:
            return None

        # Search in children.
        for childObj in children:
            foundObj = self.get_tester_object(RomClassName, childObj, Index)
            if foundObj:
                return foundObj

        # If could not find in chirdren, return None
        return None

    @abnormal_check()
    def get_object_by(self, HandleOrName, Obj=None, By="HANDLE"):
        '''
        Get specified object by handle or name in the Obj or its descendants.

        Parameters:

        HandleOrName - The Object's handle or name.

        Obj          - Renix object.

        By           - Handle or name, valid value are string HANDLE and string NAME.

        Return value:

        Return found object if found or None if not found.
        '''

        # If the Obj is not specified, use the root ROM Object SysEntry as the search scope.
        if not Obj:
            Obj = self.sys_entry

        # Check if the Obj is the specified object, if yes, return the Obj.
        if By == "HANDLE":
            if Obj.handle == HandleOrName:
                return Obj
        else:
            if Obj.Name == HandleOrName:
                return Obj

        # If the Obj is not the specified object, get its children objects.
        children = Obj.get_children()

        # If no child, return.
        if not children:
            return None

        # Search in children.
        for childObj in children:
            print(childObj)
            foundObj = self.get_object_by(HandleOrName, childObj, By)
            if foundObj:
                return foundObj

        # If could not find in chirdren, return None
        return None

    def download_packets(self, CapConfObj, Dir, Name, Timeout=30, MaxCount=0):
        '''
        Download captured packets via capture configuration object.

        Parameters:

        CapConfObj - Packet capture object.
        Dir        - Which dir to save the packets.
        Name       - Packets file name.

        Return:

        packets file path if success, if error, it will return "Error".
        '''

        if CapConfObj.CapturedPacketCount == 0:
            print("The count of captured packets is 0.")
            return "Error"

        download_cap_data_cmd = DownloadCaptureDataCommand(
            CaptureConfigs=CapConfObj.handle, FileDir=Dir, FileName=Name, MaxDownloadDataCount=MaxCount, cl_instance=self.cl_instance)
        download_cap_data_cmd.execute()

        if self.wait_rom_property_changed(CapConfObj, "CaptureState", 3, 5) == "Changed":
            print("Download is started.")
        else:
            if CapConfObj.DownloadedPacketCount == 0:
                print("Download has not started.")
                return "Error"

        if self.wait_rom_property_changed(CapConfObj, "CaptureState", 1, Timeout) == "Changed":
            print("Download is finished.")
        else:
            print("Download timeout.")
            return "Error"

        return CapConfObj.CurrentDataFile

    @abnormal_check()
    def create_protocol_session(self, ProtocolClassName, Interface, **kwargs):
        '''
        Create any L2&3 protocol renix object except LACP.

        Parameters:

        ProtocolClassName - Any L2&3 protocol renix object except LACP.

        Interface         - Specify the interface on which the protocl work on.

        kwargs            - Any protocol property of protocol configiration
                            object except the upper property, because the upper
                            is always specified as the port which the interface
                            is belongs to.

        Return Value:

        The protocol renix object created is returned. If any exception happens,
        it will return None.
        '''
        try:
            objClass = globals()[ProtocolClassName]
            Interface.get_parent()
            obj = objClass(upper=Interface.upper, **kwargs)
        except Exception as e:
            print(e)
            return None

        SelectInterfaceCommand(ProtocolList=[obj.handle],
                               InterfaceList=[Interface.handle], cl_instance=self.cl_instance).execute()

        return obj

    @abnormal_check()
    def get_port_speed(self, Ports):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            renixObject = port.get_relatives('SelectMedia', EnumRelationDirection.TARGET)[0]
            result.append(LINESPEED[renixObject.LineSpeed.value])
        return result

    # ------------------------- GATHER statictis -------------------------------------
    @abnormal_check()
    def _get_statictis_from_database(self):
        path = os.path.join(self.suite_path, self.date_time) + '_testresult.db'
        cmd = SaveResultCommand(FileName=path, cl_instance=self.cl_instance, SaveAllResults=False)
        cmd.execute()
        time.sleep(10)
        conn = sqlite3.connect(path)
        for key in DB_STATISTIC:
            if self.__subscribe.count(key) != 0:
                if key == 'StreamBlockStats':
                    sql = get_stream_block_stats_query()
                    self.__statictisData[key] = pd.read_sql_query(sql, conn)
                elif key == 'StreamStats':
                    sql = get_stream_stats_query()
                    self.__statictisData[key] = pd.read_sql_query(sql, conn)
                else:
                    self.__statictisData[key] = pd.read_sql_query(f"SELECT * FROM {key}", conn)
        conn.close()
        return True

    @abnormal_check()
    def _get_statictis_from_resultview(self, Statictis):
        renixCmd = ListROMPropertiesCommand(ROMName=Statictis, cl_instance=self.cl_instance)
        renixCmd.execute()
        StaItems = renixCmd.Properties
        resultViews = self.sys_entry.get_children('ResultView')
        resultViews = [x for x in resultViews if x.DataClassName == Statictis]
        resultViews = [x for x in resultViews if not hasattr(x, 'CurrentPage')]
        if not resultViews:
            raise TesterException(f'ResultViews DataClassName({Statictis}) is None')
        result = None
        for view in resultViews:
            if view.DataClassName in ONESHOT_STATISTIC:
                RefreshResultCommand(ResultViewHandle=view.handle, cl_instance=self.cl_instance).execute()
                time.sleep(3)
            view.get()
            resultQuerys = view.get_children()
            if not resultQuerys:
                raise TesterException(f'resultQuerys DataClassName({Statictis}) is None')
            for query in resultQuerys:
                query.get()
                resultStats = query.get_children(Statictis)
                if not resultViews:
                    raise TesterException(f'resultStats DataClassName({Statictis}) is None')
                tempDataFrame = {}
                for i in StaItems:
                    temp = []
                    for y in resultStats:
                        temp.append(getattr(y, i))
                    tempDataFrame.update({i: temp})
                tempDataFrame = pd.DataFrame(tempDataFrame)
                if result is None:
                    result = tempDataFrame
                else:
                    result = pd.concat([result, tempDataFrame])
            result.reset_index(drop=True, inplace=True)
            return result

    @abnormal_check()
    def _get_statictis_from_pageresultview(self, Statictis='StreamBlockStats'):
        renixCmd = ListROMPropertiesCommand(ROMName=Statictis, cl_instance=self.cl_instance)
        renixCmd.execute()
        StaItems = renixCmd.Properties
        resultViews = self.sys_entry.get_children('pageResultView')
        resultViews = [x for x in resultViews if x.DataClassName == Statictis]
        if not resultViews:
            raise TesterException(f'PageResultViews DataClassName({Statictis}) is None')
        result = None
        for view in resultViews:
            if view.CurrentPage != 1:
                GotoResultPageCommand(ResultViewHandle=view.handle, PageNumber=1, cl_instance=self.cl_instance).execute()
                time.sleep(3)
            if view.RecordCount % view.RecordPerPage == 0:
                record_count = int(view.RecordCount / view.RecordPerPage)
            else:
                record_count = int(view.RecordCount / view.RecordPerPage) + 1
            for i in range(record_count):
                if i != 0:
                    GotoResultPageCommand(ResultViewHandle=view.handle, PageNumber=i + 1, cl_instance=self.cl_instance).execute()
                    time.sleep(3)
                view.get()
                resultQuerys = view.get_children()
                if not resultQuerys:
                    raise TesterException(f'pageResultQuerys DataClassName({Statictis}) is None')
                for query in resultQuerys:
                    query.get()
                    resultStats = query.get_children(Statictis)
                    if not resultViews:
                        raise TesterException(f'pageResultStats DataClassName({Statictis}) is None')
                    tempDataFrame = {}
                    for i in StaItems:
                        temp = []
                        for y in resultStats:
                            # self.logger.info(y.__dict__)
                            temp.append(getattr(y, i))
                        tempDataFrame.update({i: temp})
                    tempDataFrame = pd.DataFrame(tempDataFrame)
                    if result is None:
                        result = tempDataFrame
                    else:
                        result = pd.concat([result, tempDataFrame])
        self.logger.debug('\n' + tabulate(result, headers='keys', tablefmt='psql') + '\n')
        if result is None:
            raise TesterException(f'result DataClassName({Statictis}) is None')
        result.reset_index(drop=True, inplace=True)
        return result

    @abnormal_check()
    def _get_statictis_by_performance(self):
        temp = True
        for key in STATISTIC:
            if self.__subscribe.count(key) != 0:
                if key in DB_STATISTIC and self.mode == 'db':
                    if temp:
                        self._get_statictis_from_database()
                        temp = False
                else:
                    self.__statictisData[key] = self._get_statictis_from_pageresultview(Statictis=key)
        for key in ONESHOT_STATISTIC:
            if self.__subscribe.count(key) != 0:
                self.__statictisData[key] = self._get_statictis_from_resultview(Statictis=key)
        return True

    @abnormal_check()
    def reset_statistic(self):
        self.__statictisData.clear()
        return True

    @abnormal_check()
    def _get_statictis(self, Statictis, Idx, StaItems=None, Mode=True, ResultView=False):
        if isinstance(Statictis, (list, set, tuple)):
            Statictis = Statictis[0]
        if StaItems is None:
            renixCmd = ListROMPropertiesCommand(ROMName=Statictis, cl_instance=self.cl_instance)
            renixCmd.execute()
            StaItems = renixCmd.Properties
        else:
            if isinstance(Idx, dict):
                if isinstance(StaItems, str):
                    StaItems = [StaItems]
                flag = set(Idx.keys()).difference(set(StaItems))
                if flag:
                    StaItems = list(flag) + StaItems
        result = None
        if not ResultView:
            if self.mode == 'normal':
                resultViews = self.sys_entry.get_children('pageResultView')
                resultViews = [x for x in resultViews if x.DataClassName == StaItems]
                mapIdx = [str(v) for v in Idx.values()]
                for view in resultViews:
                    if result is not None:
                        break
                    if view.RecordCount % view.RecordPerPage == 0:
                        record_count = int(view.RecordCount / view.RecordPerPage)
                    else:
                        record_count = int(view.RecordCount / view.RecordPerPage) + 1
                    for i in range(record_count):
                        if result is not None:
                            break
                        else:
                            if i != 0:
                                GotoResultPageCommand(ResultViewHandle=view.handle, PageNumber=i + 1, cl_instance=self.cl_instance).execute()
                                time.sleep(3)
                            view.get()
                            resultQuerys = view.get_children()
                            for query in resultQuerys:
                                query.get()
                                if result is not None:
                                    break
                                else:
                                    resultStreamStats = query.get_children(StaItems)
                                    if resultStreamStats is not None:
                                        for x in resultStreamStats:
                                            x.get()
                                            if mapIdx == [str(x[k]) for k in Idx.keys()]:
                                                result = {y: getattr(x, y) for y in StaItems}
                                                break
            else:
                if Mode:
                    if Statictis in ['PortStats', 'PortAvgLatencyStats', 'StreamStats', 'StreamTxStats', 'StreamRxStats',
                                     'StreamBlockStats', 'StreamBlockTxStats', 'StreamBlockRxStats']:
                        # streamTemplates = [x for x in self.rom_manager.get_all_objects().values() if isinstance(x, StreamTemplate)]
                        streamTemplates = self.get_stream_from_handle()
                        streams = []
                        if streamTemplates:
                            for x in streamTemplates:
                                try:
                                    if x.State.name == 'RUNNING':
                                        streams.append(x)
                                except Exception as e:
                                    pass
                        if streams:
                            self._get_statictis_by_performance()
                        else:
                            if self.statictis:
                                self._get_statictis_by_performance()
                                self.__statictis = False
                        self._get_statictis_by_performance()
                    else:
                        self._get_statictis_by_performance()

                else:
                    if Statictis not in list(self.__statictisData.keys()):
                        self._get_statictis_by_performance()
                df = self.__statictisData[Statictis]
        else:
            df = self._get_statictis_from_resultview(Statictis)
        self.logger.info('\n' + tabulate(df, headers='keys', tablefmt='psql') + '\n')
        if list(Idx.values())[0] is not None:
            for k, v in Idx.items():
                if v is not None:
                    if isinstance(v, (list, set, tuple)):
                        df = df[(df[k].isin(v))]
                    else:
                        df = df[(df[k] == v)]
        result = df[StaItems]
        if len(df) == 1:
            result = result.to_dict('records')[0]
        if result is None:
            result = False
        return result

    @abnormal_check()
    def save_result(self, Path, FileName):
        if not os.path.exists(Path):
            os.makedirs(Path)
        path = os.path.join(Path, FileName) + '.db'
        cmd = SaveResultCommand(FileName=path, cl_instance=self.cl_instance, SaveAllResults=False)
        cmd.execute()
        return path

    @abnormal_check()
    def set_stream_header_map(self, Streams):
        if not isinstance(Streams, (list, set, tuple)):
            Streams = [Streams]
        for stream in Streams:
            renixCmd = ListHeaderNamesCommand(Stream=stream.handle, cl_instance=self.cl_instance)
            renixCmd.execute()
            headerNames = renixCmd.HeaderNames
            if headerNames:
                objectTypes = [list(MAP_HEADER_TRANSFORM[x.lower().split('_')[0]].keys())[0] for x in headerNames if
                               x.lower().split('_')[0] in list(MAP_HEADER_TRANSFORM.keys())]
                streamHeaderList = []
                headerObject = stream
                for className in objectTypes:
                    headerObject = globals()[className](Upper=headerObject)
                    streamHeaderList.append(headerObject)
                map_stream_header.update({stream: streamHeaderList})
        return map_stream_header

    @abnormal_check()
    def set_protocol_object_map(self, Protocols):
        if not isinstance(Protocols, (list, set, tuple)):
            Protocols = [Protocols]
        for protocol in Protocols:
            map_protocol_object.update({protocol.handle: protocol})
        return map_protocol_object

    @abnormal_check()
    def edit_overall_setting(self, **kwargs):
        StreamGlobalConfig = {'PortSendMode', 'MeshCreationMode'}
        L2LearningConfig = {'Rate', 'RepeatCount', 'DelayTime', 'RxLearningEncapsulation'}
        ArpOption = {'EnableAutoArp', 'StopOnArpFail', 'AutoArpWaitTime'}
        Y1731Option = {'TestModeType', 'LmmTxFCfOffset', 'LmrRxFCfOffset', 'LmrRxFCfStart', 'LmrRxFCfStep',
                       'LmrTxFCbOffset', 'LmrTxFCbStep', 'DmTimeUnit'}
        param = set(kwargs.keys())
        objectList = ['StreamGlobalConfig', 'L2LearningConfig', 'ArpOption', 'Y1731Option']
        paramList = [StreamGlobalConfig, L2LearningConfig, ArpOption, Y1731Option]
        for o, p in zip(objectList, paramList):
            var = param.intersection(p)
            if var:
                object = self.sys_entry.get_children(o)[0]
                for v in var:
                    varParam = {v: kwargs[v] if not isinstance(kwargs[v], Enum) else kwargs[v].value}
                    object.edit(**varParam)
                    kwargs.pop(v)
        return True

    @abnormal_check()
    def create_peclsp_for_srte(self, Excel, Session, TunnelCount=16000, PcelspCount=4000,
                               SymbolicNameIdentification='Tunnel'):
        data = pd.DataFrame(pd.read_excel(Excel))
        tunnelperpeer = int(TunnelCount / 250)
        counter = PcelspCount
        for x in range(250):
            for y in range(tunnelperpeer):
                PceLsp = PceLspConfig(upper=Session)
                SymbolicName = SymbolicNameIdentification + str(x * tunnelperpeer + (y + 1))
                PceLsp.edit(SymbolicName=SymbolicName)
                SourceIP = data.loc[x][1]
                PceLsp.edit(SourceIpv4Address=SourceIP)
                DestIP = data.loc[x][2]
                PceLsp.edit(DestinationIpv4Address=DestIP)
                PcepSrEroObject = PcepSrEroObjectConfig(upper=PceLsp)
                PcepSrEroSubObject = PcepSrEroSubObjectConfig(upper=PcepSrEroObject)
                PcepSrEroSubObject.edit(NaiType=3)
                PcepSrEroSubObject.edit(FFlag=True)
                Adjsid = int(data.loc[x][3])
                PcepSrEroSubObject.edit(SidLabel=Adjsid)
                PcepSrEroSubObject = PcepSrEroSubObjectConfig(upper=PcepSrEroObject)
                PcepSrEroSubObject.edit(NaiType=0)
                PcepSrEroSubObject.edit(FFlag=True)
                Nodesid = int(data.loc[x][4])
                PcepSrEroSubObject.edit(SidLabel=Nodesid)
                counter -= 1
                if counter == 0:
                    break
            if counter == 0:
                break
        return True

    @abnormal_check()
    def create_bgp_ipv4_flowspec_performance(self, Session, MaxRouteCount, SourcePrefix, DestPrefix):
        DestiPrefixCount = len(DestPrefix)
        HalfDestiPrefixCount = int(DestiPrefixCount / 2)
        SourcePrefixCount = len(SourcePrefix)
        HalfSourcePrefixCount = int(SourcePrefixCount / 2)
        Tpye1Count = int(MaxRouteCount / DestiPrefixCount / 5 / HalfSourcePrefixCount)
        SourcePrefix1 = SourcePrefix[:HalfSourcePrefixCount]
        SourcePrefix2 = SourcePrefix[HalfSourcePrefixCount:]
        DestPrefix1 = DestPrefix[:HalfDestiPrefixCount]
        DestPrefix2 = DestPrefix[HalfDestiPrefixCount:]
        DSCPValue = [8, 16, 24, 40, 56]
        for Ipaddress in DestPrefix2:
            for value in DSCPValue:
                BGP_IPv4_FlowSpec = BgpIpv4FlowSpecConfig(upper=Session)
                BGP_IPv4_FlowSpec.edit(ComponentType=1027)
                Type1 = BGP_IPv4_FlowSpec.get_children('BgpIpv4FlowSpecType1Component')[0]
                Type1.edit(IpValue=Ipaddress, PrefixLength=16, Count=Tpye1Count, Step=1)
                Type2 = BGP_IPv4_FlowSpec.get_children('BgpIpv4FlowSpecType2Component')[0]
                Type2.edit(IpValue=SourcePrefix1[0], PrefixLength=24, Count=HalfSourcePrefixCount, Step=1)
                Type11 = BgpIpv4FlowSpecType11Component(upper=BGP_IPv4_FlowSpec)
                Type11.edit(EqualBit=True, DSCPValue=value)
                BGP_IPv4_FlowSpec_action = BGP_IPv4_FlowSpec.get_children('BgpIpv4FlowSpecAction')[0]
                if value == 8:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x38)
                elif value == 16:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x18)
                elif value == 24:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x10)
                elif value == 40:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x8)
                elif value == 56:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x28)
                else:
                    None
        for Ipaddress in DestPrefix1:
            for value in DSCPValue:
                BGP_IPv4_FlowSpec = BgpIpv4FlowSpecConfig(upper=Session)
                BGP_IPv4_FlowSpec.edit(ComponentType=1027)
                Type1 = BGP_IPv4_FlowSpec.get_children('BgpIpv4FlowSpecType1Component')[0]
                Type1.edit(IpValue=Ipaddress, PrefixLength=16, Count=Tpye1Count, Step=1)
                Type2 = BGP_IPv4_FlowSpec.get_children('BgpIpv4FlowSpecType2Component')[0]
                Type2.edit(IpValue=SourcePrefix2[0], PrefixLength=24, Count=HalfSourcePrefixCount, Step=1)
                Type11 = BgpIpv4FlowSpecType11Component(upper=BGP_IPv4_FlowSpec)
                Type11.edit(EqualBit=True, DSCPValue=value)
                BGP_IPv4_FlowSpec_action = BGP_IPv4_FlowSpec.get_children('BgpIpv4FlowSpecAction')[0]
                if value == 8:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x38)
                elif value == 16:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x18)
                elif value == 24:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x10)
                elif value == 40:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x8)
                elif value == 56:
                    BGP_IPv4_FlowSpec_action.edit(EnableTrafficMarking=True, DSCPValue=0x28)
                else:
                    None
        return True

    # ------------------------- GATHER ldp -------------------------------------
    @abnormal_check()
    def create_ldp(self, Port, **kwargs):
        session = Ldp(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_ldp(self, Session, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Session, k):
                setattr(Session, str(k), v)
        return True

    @abnormal_check()
    def create_ldp_ipv4_egress(self, Session, **kwargs):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        return Session.create_ipv4_egress(**kwargs)

    @abnormal_check()
    def create_ldp_ipv4_ingress(self, Session, **kwargs):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        return Session.create_ipv4_ingress(**kwargs)

    @abnormal_check()
    def create_ldp_fec_128(self, Session, **kwargs):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        return Session.create_fec_128(**kwargs)

    @abnormal_check()
    def create_ldp_fec_129(self, Session, **kwargs):
        if isinstance(Session, (list, set, tuple)):
            Session = Session[0]
        return Session.create_fec_129(**kwargs)

    @abnormal_check()
    def get_ldp_point_from_lsp(self, Configs):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        result = [x.get_relatives('GenerateLdpLsp', direction=EnumRelationDirection.SOURCE)[0] for x in Configs]
        return result

    @abnormal_check()
    def wait_ldp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if isinstance(Sessions, (list, set, tuple)):
            session = Sessions[0]
        else:
            session = Sessions
        if State is None:
            State = 'OPERATIONAL'
        return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def establish_ldp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.establish()
        return True

    @abnormal_check()
    def stop_ldp_hello(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_hello()
        return True

    @abnormal_check()
    def stop_ldp_keepalive(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_keepalive()
        return True

    @abnormal_check()
    def resume_ldp_hello(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resume_hello()
        return True

    @abnormal_check()
    def resume_ldp_keepalive(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resume_keepalive()
        return True

    @abnormal_check()
    def restart_ldp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.restart()
        return True

    @abnormal_check()
    def request_ldp_label(self, Configs):
        if not isinstance(Configs, list):
            Configs = [Configs]
        Ldp.request_label(Configs=Configs)
        return True

    @abnormal_check()
    def abort_request_ldp_label(self, Configs):
        if not isinstance(Configs, list):
            Configs = [Configs]
        Ldp.abort_request_label(Configs=Configs)
        return True

    @abnormal_check()
    def withdraw_ldb_label(self, Configs):
        if not isinstance(Configs, list):
            Configs = [Configs]
        Ldp.withdraw_lsp(Configs=Configs)
        return True

    @abnormal_check()
    def advertise_ldp_label(self, Configs):
        if not isinstance(Configs, list):
            Configs = [Configs]
        Ldp.advertise_lsp(Configs=Configs)
        return True

    @abnormal_check()
    def start_ldp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_ldp()
        return True

    @abnormal_check()
    def stop_ldp(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_ldp()
        return True

    @abnormal_check()
    def get_ldp_session_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="LdpSessionStatistic", Idx={'LdpSessionId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_ldp_lsp_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="LdpLspStatistic", Idx={'LdpSessionId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def edit_ldp_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('LdpPortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    # ------------------------- GATHER pcep -------------------------------------
    @abnormal_check()
    def create_pcep(self, Port, **kwargs):
        session = Pcep(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_pcep(self, Sessions, **kwargs):
        for k, v in kwargs.items():
            if hasattr(Sessions, k):
                setattr(Sessions, str(k), v)
        return True

    @abnormal_check()
    def create_pcc_lsp(self, Sessions, **kwargs):
        result = []
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            result.append(Session.create_pcc_lsp(**kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_pce_lsp(self, Sessions, **kwargs):
        result = []
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            result.append(Session.create_pce_lsp(**kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_pcc_lsp_info_object(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcc_lsp_info(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_pce_lsp_info_object(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pce_lsp_info(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_auto_delegation_parameters_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_auto_delegation_parameters_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_auto_request_parameters_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_auto_request_parameters_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_auto_sync_parameters_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_auto_sync_parameters_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_auto_initiate_parameters_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_auto_initiate_parameters_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_auto_reply_parameters_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_auto_reply_parameters_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_auto_update_parameters_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_auto_update_parameters_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_auto_tx_parameters_config(self, PcepAutoParametersConfigs, **kwargs):
        result = []
        if not isinstance(PcepAutoParametersConfigs, (list, set, tuple)):
            PcepAutoParametersConfigs = [PcepAutoParametersConfigs]
        for PcepAutoParametersConfig in PcepAutoParametersConfigs:
            result.extend(
                Pcep.pcep_auto_tx_parameters_config(PcepAutoParametersConfig=PcepAutoParametersConfig, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_bw_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_bw_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_end_point_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_endpoint_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_lspa_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_lspa_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_metric_list_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_metric_list_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_metric_object_config(self, PcepMetricLists, **kwargs):
        result = []
        if not isinstance(PcepMetricLists, (list, set, tuple)):
            PcepMetricLists = [PcepMetricLists]
        for PcepMetricList in PcepMetricLists:
            result.append(Pcep.pcep_metric_object_config(PcepLspMetricList=PcepMetricList, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_no_path_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_no_path_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_rp_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_rp_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_sr_ero_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_sr_ero_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_sr_ero_sub_object_config(self, PcepSrEroObjects, **kwargs):
        result = []
        if not isinstance(PcepSrEroObjects, (list, set, tuple)):
            PcepSrEroObjects = [PcepSrEroObjects]
        for PcepSrEroObject in PcepSrEroObjects:
            result.append(Pcep.pcep_sr_ero_sub_object_config(PcepSrEroObject=PcepSrEroObject, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_srp_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.extend(Pcep.pcep_srp_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_sr_rro_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_sr_rro_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_sr_rro_sub_object_config(self, PcepSrRroObjects, **kwargs):
        result = []
        if not isinstance(PcepSrRroObjects, (list, set, tuple)):
            PcepSrRroObjects = [PcepSrRroObjects]
        for PcepSrRroObject in PcepSrRroObjects:
            result.append(Pcep.pcep_sr_rro_sub_object_config(PcepSrRroObject=PcepSrRroObject, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_srv6_ero_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_srv6_ero_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_srv6_ero_sub_object_config(self, PcepSrv6EroObjects, **kwargs):
        result = []
        if not isinstance(PcepSrv6EroObjects, (list, set, tuple)):
            PcepSrv6EroObjects = [PcepSrv6EroObjects]
        for PcepSrv6EroObject in PcepSrv6EroObjects:
            result.append(Pcep.pcep_srv6_ero_sub_object_config(PcepSrv6EroObject=PcepSrv6EroObject, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_srv6_rro_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_srv6_rro_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_srv6_rro_sub_object_config(self, PcepSrv6RroObjects, **kwargs):
        result = []
        if not isinstance(PcepSrv6RroObjects, (list, set, tuple)):
            PcepSrv6RroObjects = [PcepSrv6RroObjects]
        for PcepSrv6RroObject in PcepSrv6RroObjects:
            result.append(Pcep.pcep_srv6_rro_sub_object_config(PcepSrv6RroObject=PcepSrv6RroObject, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_xro_object_config(self, PcepLsps, **kwargs):
        result = []
        if not isinstance(PcepLsps, (list, set, tuple)):
            PcepLsps = [PcepLsps]
        for PcepLsp in PcepLsps:
            result.append(Pcep.pcep_xro_object_config(PcepLsp=PcepLsp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def pcep_xro_sub_object_config(self, PcepXroObjects, **kwargs):
        result = []
        if not isinstance(PcepXroObjects, (list, set, tuple)):
            PcepXroObjects = [PcepXroObjects]
        for PcepXroObject in PcepXroObjects:
            result.append(Pcep.pcep_xro_sub_object_config(PcepXroObject=PcepXroObject, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def wait_pcep_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def pcep_establish(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.pcep_establish()
        return True

    @abnormal_check()
    def pcep_resume_keep_alive(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.pcep_resume_keep_alive()
        return True

    @abnormal_check()
    def pcep_stop_keep_alive(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.pcep_stop_keep_alive()
        return True

    @abnormal_check()
    def pcc_delegate_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_delegate_lsp(lsps=Session.PccLsp)
            else:
                Session.pcc_delegate_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pcc_initial_sync(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_initial_sync(lsps=Session.PccLsp)
            else:
                Session.pcc_initial_sync(lsps=Lsps)
        return True

    @abnormal_check()
    def pcc_end_sync(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_end_sync(lsps=Session.PccLsp)
            else:
                Session.pcc_end_sync(lsps=Lsps)
        return True

    @abnormal_check()
    def pcc_synchronize_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_synchronize_lsp(lsps=Session.PccLsp)
            else:
                Session.pcc_synchronize_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pcc_report_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_report_lsp(lsps=Session.PccLsp)
            else:
                Session.pcc_report_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pcc_request_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_request_lsp(lsps=Session.PccLsp)
            else:
                Session.pcc_request_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pcc_remove_delegated_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_remove_delegated_lsp(lsps=Session.PccLsp)
            else:
                Session.pcc_remove_delegated_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pcc_revoke_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pcc_revoke_lsp(lsps=Session.PccLsp)
            else:
                Session.pcc_revoke_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pce_initiate_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pce_initiate_lsp(lsps=Session.PceLsp)
            else:
                Session.pce_initiate_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pce_remove_initiated_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pce_remove_initiated_lsp(lsps=Session.PceLsp)
            else:
                Session.pce_remove_initiated_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pce_return_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pce_return_lsp(lsps=Session.PceLsp)
            else:
                Session.pce_return_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def pce_update_lsp(self, Sessions, Lsps=None):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            if Lsps is None:
                Session.pce_update_lsp(lsps=Session.PceLsp)
            else:
                Session.pce_update_lsp(lsps=Lsps)
        return True

    @abnormal_check()
    def get_pcep_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="PcepPortStatistic",
                                     Idx={'PortHandle': portID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pcep_session_statistic(self, Session=None, SessionId=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="PcepSessionStatistic",
                                     Idx={'SessionHandle': sessionID, 'SessionIndex': SessionId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pcep_session_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="PcepSessionBlockStatistic",
                                     Idx={'SessionBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pcep_lsp_statistic(self, Session=None, SessionId=1, Lsp=None, LspId=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        if Lsp is None:
            lspID = None
        elif isinstance(Lsp, (list, set, tuple)):
            lspID = [x.Name for x in Lsp]
        else:
            lspID = Lsp.Name
        result = self._get_statictis(Statictis="PcepLspStatistic",
                                     Idx={'SessionId': sessionID, 'SessionIndex': SessionId,
                                          'LspIdentify': lspID, 'LspIndex': LspId},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_pcep_lsp_block_statistic(self, Session=None, SessionId=1, Lsp=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        if Lsp is None:
            lspID = None
        elif isinstance(Lsp, (list, set, tuple)):
            lspID = [x.Name for x in Lsp]
        else:
            lspID = Lsp.Name
        result = self._get_statictis(Statictis="PcepLspBlockStatistic",
                                     Idx={'SessionId': sessionID, 'SessionIndex': SessionId,
                                          'LspIdentify': lspID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def edit_pcep_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('PcepPortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_lsp_ping(self, Port, **kwargs):
        session = LspPing(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def create_lsp_ping_echo_request(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        result = []
        for Session in Sessions:
            result.append(Session.echo_request(**kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_lsp_ping_fec_ldp_ipv4(self, EchoRequests, **kwargs):
        if not isinstance(EchoRequests, (list, tuple, set)):
            EchoRequests = [EchoRequests]
        result = []
        for EchoRequest in EchoRequests:
            result.append(LspPing.fec_ldp_ipv4(EchoRequest=EchoRequest, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_lsp_ping_fec_vpn_ipv4(self, EchoRequests, **kwargs):
        if not isinstance(EchoRequests, (list, tuple, set)):
            EchoRequests = [EchoRequests]
        result = []
        for EchoRequest in EchoRequests:
            result.append(LspPing.fec_vpn_ipv4(EchoRequest=EchoRequest, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_lsp_ping_fec_segment_routing(self, EchoRequests, **kwargs):
        if not isinstance(EchoRequests, (list, tuple, set)):
            EchoRequests = [EchoRequests]
        result = []
        for EchoRequest in EchoRequests:
            result.append(LspPing.fec_segment_routing(EchoRequest=EchoRequest, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_lsp_ping_fec_sr_prefix(self, Srs, **kwargs):
        if not isinstance(Srs, (list, tuple, set)):
            Srs = [Srs]
        result = []
        for Sr in Srs:
            result.append(LspPing.fec_sr_prefix(Sr=Sr, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_lsp_ping_fec_sr_adjacency(self, Srs, **kwargs):
        if not isinstance(Srs, (list, tuple, set)):
            Srs = [Srs]
        result = []
        for Sr in Srs:
            result.append(LspPing.fec_sr_adjacency(Sr=Sr, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def edit_lsp_ping_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('LspPingPortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def start_lsp_ping(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_lsp_ping()
        return True

    @abnormal_check()
    def stop_lsp_ping(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_lsp_ping()
        return True

    @abnormal_check()
    def pause_lsp_ping(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.pause_lsp_ping()
        return True

    @abnormal_check()
    def resume_lsp_ping(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resume_lsp_ping()
        return True

    @abnormal_check()
    def pause_lsp_trace(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.pause_lsp_trace()
        return True

    @abnormal_check()
    def resume_lsp_trace(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resume_lsp_trace()
        return True

    @abnormal_check()
    def wait_lsp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_lsp_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def wait_lsp_ping_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_lsp_ping_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def wait_lsp_trace_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_lsp_trace_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def get_lsp_ping_session_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="LspPingSessionStats",
                                     Idx={'SessionID': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_lsp_ping_echo_request_statistic(self, Session=None, EchoRequest=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        if EchoRequest is None:
            echoRequestID = None
        elif isinstance(EchoRequest, (list, set, tuple)):
            echoRequestID = [x.Name for x in EchoRequest]
        else:
            echoRequestID = EchoRequest.Name
        result = self._get_statictis(Statictis="LspPingEchoRequestStats",
                                     Idx={'SessionID': sessionID, 'GroupID': echoRequestID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_lsp_trace_echo_request_statistic(self, Session=None, EchoRequest=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        if EchoRequest is None:
            echoRequestID = None
        elif isinstance(EchoRequest, (list, set, tuple)):
            echoRequestID = [x.Name for x in EchoRequest]
        else:
            echoRequestID = EchoRequest.Name
        result = self._get_statictis(Statictis="LspTraceEchoRequestStats",
                                     Idx={'SessionID': sessionID, 'GroupID': echoRequestID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER dot1x -------------------------------------
    @abnormal_check()
    def create_dot1x(self, Port, **kwargs):
        session = Dot1x(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_dot1x_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('Dot1xPortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def dot1x_upload_certificate(self, Sessions, Folder):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.upload_certificate(folder=Folder)
        return True

    @abnormal_check()
    def dot1x_delete_certificate(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.delete_certificate()
        return True

    @abnormal_check()
    def abort_dot1x(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.abort()
        return True

    @abnormal_check()
    def wait_dot1x_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def get_dot1x_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dot1xBlockStatistics",
                                     Idx={'Dot1xBlockHandle': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dot1x_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="Dot1xPortStatistics",
                                     Idx={'PortHandle': portID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_dot1x_statistic(self, Session=None, Index=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dot1xStatistics",
                                     Idx={'Dot1xBlockHandle': sessionID, 'SessionIndex': Index},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER dot3ah -------------------------------------
    @abnormal_check()
    def create_dot3ah(self, Port, **kwargs):
        session = Dot3ah(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_dot3ah_event_notification(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.edit_event_notification(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def edit_dot3ah_info_pdu(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.edit_info_pdu(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def edit_dot3ah_org_spec(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.edit_org_spec(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_dot3ah_org_spec_tlv(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.create_org_spec_tlv(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_dot3ah_var_req(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.create_var_req(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_dot3ah_var_resp(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.create_var_resp(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def start_event_notification_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStartEventNotificationCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def start_link_trace_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStartLinkTraceCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def start_loopback_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStartLoopBackCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def start_org_spec_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStartOrgSpecCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def start_var_req_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStartVarReqCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def stop_event_notification_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStopEventNotificationCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def stop_link_trace_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStopLinkTraceCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def stop_loopback_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStopLoopBackCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def stop_org_spec_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStopOrgSpecCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def stop_var_req_dot3ah(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot3ahStopVarReqCommand(Dot3ahConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def wait_dot3ah_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        if isinstance(Sessions[0], Dot3ahProtocolConfig):
            if State is None:
                State = 'RESERVED'
            return self._wait_state(Sessions=Sessions, AttrName='State', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'RESERVED'
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def get_dot3ah_error_event_stats(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dot3ahErrorEventStats",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_dot3ah_session_statistic(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dot3ahSessionStatistic",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    # ------------------------- GATHER dot1ag -------------------------------------
    @abnormal_check()
    def create_dot1ag(self, Port, **kwargs):
        session = Dot1ag(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_dot1ag_link_trace(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.edit_link_trace(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def edit_dot1ag_loopback(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.edit_loopback(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_dot1ag_ma(self, **kwargs):
        return Dot1ag.create_ma(**kwargs)

    @abnormal_check()
    def create_dot1ag_mp(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.create_mp(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_dot1ag_org_specific_tlv(self, Session, **kwargs):
        if not isinstance(Session, (set, list, tuple)):
            Session = [Session]
        configs = []
        for x in Session:
            configs.append(x.create_org_specific_tlv(**kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def create_dot1ag_custom_mp(self, **kwargs):
        return Dot1ag.create_custom_mp(**kwargs)

    @abnormal_check()
    def create_dot1ag_expected_mp(self, Ma, **kwargs):
        if not isinstance(Ma, (list, tuple, set)):
            Ma = [Ma]
        configs = []
        for Ma in Ma:
            configs.append(Dot1ag.create_expected_mp(Ma=Ma, **kwargs))
        return configs[0] if len(configs) == 1 else configs

    @abnormal_check()
    def start_cc_dot1ag(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot1agStartCCCommand(Dot1agConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def start_link_trace_dot1ag(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot1agStartLinkTraceCommand(Dot1agConfigs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_loopback_dot1ag(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot1agStartLoopBackCommand(Dot1agConfigs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_cc_dot1ag(self, Sessions):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot1agStopCCCommand(Dot1agConfigs=[i.handle for i in Sessions])
        cmd.execute()
        return True

    @abnormal_check()
    def stop_link_trace_dot1ag(self, Sessions, MpObjects):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot1agStopLinkTraceCommand([i.handle for i in Sessions], MpHandleList=[x.handle for x in MpObjects])
        cmd.execute()
        return True

    @abnormal_check()
    def stop_loopback_dot1ag(self, Sessions, MpObjects):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        cmd = Dot1agStopLoopBackCommand(Dot1agConfigs=[i.handle for i in Sessions], MpHandleList=[x.handle for x in MpObjects])
        cmd.execute()
        return True

    @abnormal_check()
    def wait_dot1ag_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        if isinstance(Sessions[0], Dot1agProtocolConfig):
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, AttrName='State', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def get_dot1ag_mp_stats(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Dot1agMpStats",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    # ------------------------- GATHER Saa -------------------------------------
    @abnormal_check()
    def create_saa(self, Port, **kwargs):
        session = Saa(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def wait_saa_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def edit_saa_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('SaaPortRateConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def get_saa_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="SaaPortStatistics",
                                     Idx={'SaaPortId': portID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_saa_session_block_statistic(self, Session=None, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="SaaSessionBlockStatistics",
                                     Idx={'SaaSessionBlockId': sessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_saa_session_statistic(self, Session=None, Index=1, StaItems=None):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="SaaSessionStatistics",
                                     Idx={'SaaSessionBlockId': sessionID, 'SessionIndex': Index},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER y1731 -------------------------------------
    @abnormal_check()
    def create_y1731(self, Port, **kwargs):
        session = Y1731(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def wait_y1731_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        if isinstance(Sessions[0], Y1731ProtocolConfig):
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, AttrName='State', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def edit_y1731_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = port.get_children('Y1731PortConfig')[0]
            if kwargs:
                config.edit(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def edit_y1731_global_option(self, **kwargs):
        config = self.__sysEntry.get_children('Y1731Option')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_y1731_meg(self, **kwargs):
        config = Y1731.create_meg(**kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_y1731_mp(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        result = []
        for Session in Sessions:
            result.append(Session.create_mp(**kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def edit_y1731_mp(self, Mps, **kwargs):
        if not isinstance(Mps, list):
            Mps = [Mps]
        for mp in Mps:
            Y1731.edit_mp(Mp=mp, **kwargs)
        return True

    @abnormal_check()
    def create_y1731_expected_mep(self, Megs, **kwargs):
        if not isinstance(Megs, (list, set, tuple)):
            Megs = [Megs]
        result = []
        for meg in Megs:
            result.append(Y1731.create_expected_mep(Meg=meg, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_y1731_data_tlv(self, Mps, **kwargs):
        if not isinstance(Mps, (list, set, tuple)):
            Mps = [Mps]
        result = []
        for mp in Mps:
            result.append(Y1731.create_data_tlv(Mp=mp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_y1731_ltm_egress_identifier_tlv(self, Mps, **kwargs):
        if not isinstance(Mps, (list, set, tuple)):
            Mps = [Mps]
        result = []
        for mp in Mps:
            result.append(Y1731.create_ltm_egress_identifier_tlv(Mp=mp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_y1731_ltr_egress_identifier_tlv(self, Mps, **kwargs):
        if not isinstance(Mps, (list, set, tuple)):
            Mps = [Mps]
        result = []
        for mp in Mps:
            result.append(Y1731.create_ltr_egress_identifier_tlv(Mp=mp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_y1731_organization_specific_tlv(self, Mps, **kwargs):
        if not isinstance(Mps, (list, set, tuple)):
            Mps = [Mps]
        result = []
        for mp in Mps:
            result.append(Y1731.create_organization_specific_tlv(Mp=mp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def create_y1731_reply_ingress_tlv(self, Mps, **kwargs):
        if not isinstance(Mps, (list, set, tuple)):
            Mps = [Mps]
        result = []
        for mp in Mps:
            result.append(Y1731.create_reply_ingress_tlv(Mp=mp, **kwargs))
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def start_y1731_1dm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731Start1DmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_y1731_ais(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StartAisCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_y1731_ccm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StartCcmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_y1731_dmm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StartDmmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_y1731_lbm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StartLbmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_y1731_lck(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StartLckCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_y1731_lmm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StartLmmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def start_y1731_ltm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StartLtmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_1dm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731Stop1DmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_ais(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StopAisCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_ccm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StopCcmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_dmm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StopDmmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_lbm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StopLbmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_lck(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StopLckCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_lmm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StopLmmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def stop_y1731_ltm(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, tuple, set)):
            Sessions = [Sessions]
        if 'MepHandles' in kwargs:
            mep_handles = kwargs['MepHandles']
            if not isinstance(mep_handles, (list, tuple, set)):
                mep_handles = [Sessions]
            if isinstance(mep_handles[0], Y1731MpConfig):
                meps = [i.handle for i in mep_handles]
                kwargs.update({'MepHandles': meps})
        cmd = Y1731StopLtmCommand(Y1731Configs=[i.handle for i in Sessions], **kwargs)
        cmd.execute()
        return True

    @abnormal_check()
    def get_y1731_port_statistic(self, Port=None, StaItems=None, ResultView=False):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="Y1731PortStats",
                                     Idx={'PortHandle': portID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_y1731_meg_statistic(self, Meg=None, Port=None, StaItems=None, ResultView=False):
        if Meg is None:
            megID = None
        elif isinstance(Meg, (list, set, tuple)):
            megID = [x.Name for x in Meg]
        else:
            megID = Meg.Name
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="Y1731MegStats",
                                     Idx={'MegHandle': megID, 'PortHandle': portID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_y1731_mp_statistic(self, Mp=None, StaItems=None, ResultView=False):
        if Mp is None:
            mpID = None
        elif isinstance(Mp, (list, set, tuple)):
            mpID = [x.Name for x in Mp]
        else:
            mpID = Mp.Name
        result = self._get_statictis(Statictis="Y1731MpStats",
                                     Idx={'MpHandle': mpID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    # ------------------------- GATHER lacp -------------------------------------

    @abnormal_check()
    def create_lacp(self, Ports):
        session = Lacp(Ports=Ports)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def lacp_add_members(self, Lacp_, Ports):
        return Lacp_.add_members(Ports=Ports)

    @abnormal_check()
    def edit_lacp_aggregation_group(self, Lacp_, **kwargs):
        return Lacp_.edit_aggregation_group(**kwargs)

    @abnormal_check()
    def lacp_delete_members(self, Lacp_, Ports):
        return Lacp_.delete_members(Ports=Ports)

    @abnormal_check()
    def edit_lacp_members_port_config(self, Ports, **kwargs):
        return Lacp.edit_members_port_config(Ports, **kwargs)

    @abnormal_check()
    def pause_send_lacp_pdus(self, Ports):
        return Lacp.pause_send_lacp_pdus(Ports=Ports)

    @abnormal_check()
    def resume_send_lacp_pdus(self, Ports):
        return Lacp.resume_send_lacp_pdus(Ports=Ports)

    @abnormal_check()
    def send_in_sync_pdus(self, Ports):
        return Lacp.send_in_sync_pdus(Ports=Ports)

    @abnormal_check()
    def send_out_of_sync_pdus(self, Ports):
        return Lacp.send_out_of_sync_pdus(Ports=Ports)

    @abnormal_check()
    def start_lacp_port(self, Ports):
        return Lacp.start_lacp_port(Ports=Ports)

    @abnormal_check()
    def stop_lacp_port(self, Ports):
        return Lacp.stop_lacp_port(Ports=Ports)

    @abnormal_check()
    def get_lacp_port_statistic(self, Port=None, StaItems=None):
        if Port is None:
            portID = None
        elif isinstance(Port, (list, set, tuple)):
            portID = [x.Name for x in Port]
        else:
            portID = Port.Name
        result = self._get_statictis(Statictis="LacpPortStats",
                                     Idx={'PortHandle': portID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_lag_port_statistic(self, Lacp_=None, StaItems=None):
        if Lacp_ is None:
            lacpID = None
        elif isinstance(Lacp_, (list, set, tuple)):
            lacpID = [x.session.Name for x in Lacp_]
        else:
            lacpID = Lacp_.session.Name
        result = self._get_statictis(Statictis="LagPortStats",
                                     Idx={'LagPortHandle': lacpID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER openflow -------------------------------------

    @abnormal_check()
    def create_openflow_switch(self, Port, **kwargs):
        session = OpenFlowSwitch(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def wait_openflow_switch_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def edit_controller_desc(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        results = []
        for Session in Sessions:
            results.append(Session.edit_controller_config(**kwargs))
        return results[0] if len(results) == 1 else results

    @abnormal_check()
    def edit_switch_desc(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        results = []
        for Session in Sessions:
            results.append(Session.edit_switch_config(**kwargs))
        return results[0] if len(results) == 1 else results

    @abnormal_check()
    def openflow_start_vswitch(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_vswitch()
        return True

    @abnormal_check()
    def openflow_stop_vswitch(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_vswitch()
        return True

    @abnormal_check()
    def create_openflow_controller(self, Port, **kwargs):
        session = OpenFlowController(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def wait_openflow_controller_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def create_openflow_action_list(self, **kwargs):
        config = OfpActionListConfig(upper=self.cl_instance.get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_action(self, ActionList, **kwargs):
        config = OfpActionConfig(upper=ActionList)
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_command_list(self, **kwargs):
        config = OfpCommandListConfig(upper=self.cl_instance.get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_command(self, CommandList, **kwargs):
        config = OfpControllerCommandConfig(upper=CommandList)
        for k, v in kwargs.items():
            if k == 'FlowEntry':
                config.set_relatives('OfpGetFlowEntry', v, EnumRelationDirection.TARGET)
            elif k == 'GroupTable':
                config.set_relatives('OfpGetGroupTable', v, EnumRelationDirection.TARGET)
            elif k == 'MeterTable':
                config.set_relatives('OfpGetMeterTable', v, EnumRelationDirection.TARGET)
            elif k == 'ActionList':
                config.set_relatives('OfpGetActionList', v, EnumRelationDirection.TARGET)
            else:
                setattr(config, k, v)
        return config

    @abnormal_check()
    def create_openflow_flow_table(self, **kwargs):
        config = OfpFlowTableConfig(upper=self.cl_instance.get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_flow_entry(self, FlowTable, **kwargs):
        config = OfpFlowEntryConfig(upper=FlowTable)
        for k, v in kwargs.items():
            if k == 'ActionList':
                config.set_relatives('OfpGetActionList', v, EnumRelationDirection.TARGET)
            elif k == 'StreamTemplate':
                config.set_relatives('BoundStreamTemplate', v, EnumRelationDirection.TARGET)
            elif k == 'StreamChannel':
                config.set_relatives('BoundStreamChannel', v, EnumRelationDirection.TARGET)
            elif k == 'Flags':
                value = [EnumOfpFlowFlags[i].value for i in v]
                value = int(sum(value))
                setattr(config, k, value)
            else:
                setattr(config, k, v)
        return config

    @abnormal_check()
    def create_openflow_instruction(self, FlowEntry, **kwargs):
        config = OfpInstructionConfig(upper=FlowEntry)
        for k, v in kwargs.items():
            if k == 'ActionList':
                config.set_relatives('OfpGetActionList', v, EnumRelationDirection.TARGET)
            else:
                setattr(config, k, v)
        return config

    @abnormal_check()
    def create_openflow_match_field(self, FlowEntry, **kwargs):
        config = OfpMatchFieldConfig(upper=FlowEntry)
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_group_table(self, **kwargs):
        config = OfpGroupTableConfig(upper=self.cl_instance.get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_action_bucket(self, GroupTable, **kwargs):
        config = GroupTable.get_children('OfpActionBucketConfig')[0]
        for k, v in kwargs.items():
            if k == 'ActionList':
                config.set_relatives('OfpGetActionList', v, EnumRelationDirection.TARGET)
            else:
                setattr(config, k, v)
        return config

    @abnormal_check()
    def create_openflow_meter_table(self, **kwargs):
        config = OfpMeterTableConfig(upper=self.cl_instance.get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_meter_band(self, MeterTable, **kwargs):
        config = MeterTable.get_children('OfpMeterBandConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_queue(self, **kwargs):
        config = OfpQueueConfig(upper=self.cl_instance.get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def create_openflow_queue_property(self, Queue, **kwargs):
        config = OfpQueuePropertyConfig(upper=Queue)
        if kwargs:
            config.edit(**kwargs)
        return config

    @abnormal_check()
    def get_openflow_controller_statistic(self, Controller=None, StaItems=None):
        if Controller is None:
            controllerID = None
        elif isinstance(Controller, (list, set, tuple)):
            controllerID = [x.Name for x in Controller]
        else:
            controllerID = Controller.Name
        result = self._get_statictis(Statictis="OfpControllerStats",
                                     Idx={'Handle': controllerID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_openflow_switch_statistic(self, Switch=None, StaItems=None):
        if Switch is None:
            switchID = None
        elif isinstance(Switch, (list, set, tuple)):
            switchID = [x.Name for x in Switch]
        else:
            switchID = Switch.Name
        result = self._get_statictis(Statictis="OfpSwitchDescStats",
                                     Idx={'Handle': switchID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER ovsdb -------------------------------------

    @abnormal_check()
    def create_ovsdb(self, Port, **kwargs):
        session = Ovsdb(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def wait_ovsdb_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_session_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def edit_ovsdb_port_config(self, Ports, **kwargs):
        if not isinstance(Ports, list):
            Ports = [Ports]
        result = []
        for port in Ports:
            config = Ovsdb.edit_port_config(Port=port, **kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def edit_ovsdb_table(self, **kwargs):
        return Ovsdb.edit_ovsdb_table(**kwargs)

    @abnormal_check()
    def edit_ovsdb_export(self, **kwargs):
        return Ovsdb.edit_ovsdb_export(**kwargs)

    @abnormal_check()
    def ovsdb_upload_ca_certificate(self, Ports, LocalPath, Files):
        return Ovsdb.upload_ca_certificate(Ports=Ports,
                                           LocalPath=LocalPath,
                                           Files=Files)

    @abnormal_check()
    def ovsdb_upload_certificate(self, Ports, LocalPath, Files):
        return Ovsdb.upload_certificate(Ports=Ports,
                                        LocalPath=LocalPath,
                                        Files=Files)

    @abnormal_check()
    def ovsdb_upload_private_key(self, Ports, LocalPath, Files):
        return Ovsdb.upload_private_key(Ports=Ports,
                                        LocalPath=LocalPath,
                                        Files=Files)

    @abnormal_check()
    def ovsdb_refresh_files(self, Ports):
        return Ovsdb.refresh_files(Ports=Ports)

    @abnormal_check()
    def ovsdb_delete_certificate(self, Ports, Files):
        return Ovsdb.delete_certificate(Ports=Ports,
                                        Files=Files)

    @abnormal_check()
    def ovsdb_start_refresh_table(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_refresh_table()
        return True

    @abnormal_check()
    def ovsdb_stop_refresh_table(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_refresh_table()
        return True

    @abnormal_check()
    def ovsdb_query_db(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.query_db(**kwargs)
        return True

    @abnormal_check()
    def ovsdb_query_db_oneshot(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.query_db_oneshot(**kwargs)
        return True

    @abnormal_check()
    def ovsdb_query_db_period(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.query_db_period(**kwargs)
        return True

    @abnormal_check()
    def ovsdb_stop_query_db_period(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_query_db_period(**kwargs)
        return True

    @abnormal_check()
    def ovsdb_export_contents(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.export_contents()
        return True

    @abnormal_check()
    def get_ovsdb_statistic(self, Sessions=None, StaItems=None):
        if Sessions is None:
            SessionID = None
        elif isinstance(Sessions, (list, set, tuple)):
            SessionID = [x.Name for x in Sessions]
        else:
            SessionID = Sessions.Name
        result = self._get_statictis(Statictis="OvsdbResults",
                                     Idx={'OvsdbHandle': SessionID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER twamp -------------------------------------

    @abnormal_check()
    def create_twamp(self, Port, **kwargs):
        session = Twamp(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def wait_twamp_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.wait_twamp_state(State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def edit_twamp_test_session(self, Twamps, **kwargs):
        if not isinstance(Twamps, list):
            Twamps = [Twamps]
        result = []
        for twamp in Twamps:
            config = twamp.edit_test_session(**kwargs)
            result.append(config)
        return result[0] if len(result) == 1 else result

    @abnormal_check()
    def wait_twamp_session_state(self, TestSessions, State=None, Interval=1, TimeOut=60):
        self._wait_state(Sessions=TestSessions, State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @abnormal_check()
    def twamp_start(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_twamp()
        return True

    @abnormal_check()
    def twamp_stop(self, Sessions):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_twamp()
        return True

    @abnormal_check()
    def twamp_start_session(self, Sessions, TestSessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.start_session(TestSessions=TestSessions, **kwargs)
        return True

    @abnormal_check()
    def twamp_stop_session(self, Sessions, TestSessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.stop_session(TestSessions=TestSessions, **kwargs)
        return True

    @abnormal_check()
    def twamp_request_session(self, Sessions, TestSessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.request_session(TestSessions=TestSessions, **kwargs)
        return True

    @abnormal_check()
    def twamp_pause_session(self, Sessions, TestSessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.pause_session(TestSessions=TestSessions, **kwargs)
        return True

    @abnormal_check()
    def twamp_resume_session(self, Sessions, TestSessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        for Session in Sessions:
            Session.resume_session(TestSessions=TestSessions, **kwargs)
        return True

    @abnormal_check()
    def get_twamp_client_statistic(self, Sessions=None, StaItems=None):
        if Sessions is None:
            SessionID = None
        elif isinstance(Sessions, (list, set, tuple)):
            SessionID = [x.Name for x in Sessions]
        else:
            SessionID = Sessions.Name
        result = self._get_statictis(Statictis="TwampClientStats",
                                     Idx={'SessionHandle': SessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_twamp_server_statistic(self, Sessions=None, StaItems=None):
        if Sessions is None:
            SessionID = None
        elif isinstance(Sessions, (list, set, tuple)):
            SessionID = [x.Name for x in Sessions]
        else:
            SessionID = Sessions.Name
        result = self._get_statictis(Statictis="TwampServerStats",
                                     Idx={'SessionHandle': SessionID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_twamp_port_client_statistic(self, Ports=None, StaItems=None):
        if Ports is None:
            PortID = None
        elif isinstance(Ports, (list, set, tuple)):
            PortID = [x.Name for x in Ports]
        else:
            PortID = Ports.Name
        result = self._get_statictis(Statictis="TwampPortClientStats",
                                     Idx={'PortHandle': PortID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_twamp_port_server_statistic(self, Ports=None, StaItems=None):
        if Ports is None:
            PortID = None
        elif isinstance(Ports, (list, set, tuple)):
            PortID = [x.Name for x in Ports]
        else:
            PortID = Ports.Name
        result = self._get_statictis(Statictis="TwampPortServerStats",
                                     Idx={'PortHandle': PortID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_twamp_test_session_statistic(self, Twamps=None, StaItems=None):
        if Twamps is None:
            TwampID = None
        elif isinstance(Twamps, (list, set, tuple)):
            TwampID = [x.Name for x in Twamps]
        else:
            TwampID = Twamps.Name
        result = self._get_statictis(Statictis="TwampTestSessionStats",
                                     Idx={'SessionHandle': TwampID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_twamp_port_test_session_statistic(self, Ports=None, StaItems=None):
        if Ports is None:
            PortID = None
        elif isinstance(Ports, (list, set, tuple)):
            PortID = [x.Name for x in Ports]
        else:
            PortID = Ports.Name
        result = self._get_statictis(Statictis="TwampPortTestSessionStats",
                                     Idx={'PortHandle': PortID},
                                     StaItems=StaItems)
        return result

    @abnormal_check()
    def get_twamp_state_statistic(self, Ports=None, StaItems=None):
        if Ports is None:
            PortID = None
        elif isinstance(Ports, (list, set, tuple)):
            PortID = [x.Name for x in Ports]
        else:
            PortID = Ports.Name
        result = self._get_statictis(Statictis="TwampStateStats",
                                     Idx={'PortHandle': PortID},
                                     StaItems=StaItems)
        return result

    # ------------------------- GATHER bgp route wizard -------------------------------------

    @abnormal_check()
    def create_bgp_route_wizard(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        return BgpRouteWizard(Sessions=Sessions, **kwargs)

    @abnormal_check()
    def config_bgp_route_wizard_ipv4(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            result = wizard.config_ipv4_route(**kwargs)
            configs.append(result)
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_bgp_route_wizard_ipv6(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            result = wizard.config_ipv6_route(**kwargs)
            configs.append(result)
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_bgp_route_wizard_igp_topo(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            result = wizard.config_igp_topo(**kwargs)
            configs.append(result)
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_bgp_route_wizard_igp(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            result = wizard.config_igp(**kwargs)
            configs.append(result)
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_bgp_route_wizard_igp_te_option(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            config = wizard.config_link_state_route_te(**kwargs)
            configs.append(config)
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def expand_bgp_route_wizard(self, Wizards):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        for wizard in Wizards:
            wizard.expand()
        return True

    # ------------------------- GATHER isis lsp wizard -------------------------------------

    @abnormal_check()
    def create_isis_lsp_wizard(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        return IsisLspWizard(Sessions=Sessions, **kwargs)

    @abnormal_check()
    def config_isis_lsp_wizard_network_topo(self, Wizards, Type, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_network_topo(Type=Type, **kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_isis(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_isis(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_isis_te(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_isis_te(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_isis_sr(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_isis_sr(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_isis_srv6(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_isis_srv6(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_isis_flex_algo(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_isis_flex_algorithm(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_ipv4_internal_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ipv4_internal_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_ipv4_external_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ipv4_external_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_ipv6_internal_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ipv6_internal_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_isis_lsp_wizard_ipv6_external_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ipv6_external_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def expand_isis_lsp_wizard(self, Wizards):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        for wizard in Wizards:
            wizard.expand()
        return True

    # ------------------------- GATHER ospfv2 lsa wizard -------------------------------------

    @abnormal_check()
    def create_ospfv2_lsa_wizard(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        return Ospfv2LsaWizard(Sessions=Sessions, **kwargs)

    @abnormal_check()
    def config_ospfv2_lsa_wizard_ospfv2_topo(self, Wizards, Type, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv2_topo(Type=Type, **kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv2_lsa_wizard_ospfv2(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv2(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv2_lsa_wizard_ospfv2_te_option(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv2_te_option(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv2_lsa_wizard_ospfv2_sr(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv2_sr(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv2_lsa_wizard_ospfv2_stub_network(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv2_stub_network(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv2_lsa_wizard_ospfv2_summary_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv2_summary_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv2_lsa_wizard_ospfv2_external_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv2_external_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def expand_ospfv2_lsa_wizard(self, Wizards):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        for wizard in Wizards:
            wizard.expand()
        return True

    # ------------------------- GATHER ospfv3 lsa wizard -------------------------------------

    @abnormal_check()
    def create_ospfv3_lsa_wizard(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        return Ospfv3LsaWizard(Sessions=Sessions, **kwargs)

    @abnormal_check()
    def config_ospfv3_lsa_wizard_ospfv3_topo(self, Wizards, Type, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv3_topo(Type=Type, **kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv3_lsa_wizard_ospfv3(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv3(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv3_lsa_wizard_ospfv3_intra_area_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv3_intra_area_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv3_lsa_wizard_ospfv3_inter_area_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv3_inter_area_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_ospfv3_lsa_wizard_ospfv3_external_route(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ospfv3_external_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def expand_ospfv3_lsa_wizard(self, Wizards):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        for wizard in Wizards:
            wizard.expand()
        return True

    # ------------------------- GATHER rip route wizard -------------------------------------

    @abnormal_check()
    def create_rip_route_wizard(self, Sessions, **kwargs):
        if not isinstance(Sessions, (list, set, tuple)):
            Sessions = [Sessions]
        return RipRouteWizard(Sessions=Sessions, **kwargs)

    @abnormal_check()
    def config_rip_route_wizard_ipv4(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ipv4_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def config_rip_route_wizard_ipv6(self, Wizards, **kwargs):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        configs = []
        for wizard in Wizards:
            configs.append(wizard.config_ipv6_route(**kwargs))
        return configs if len(configs) > 1 else configs[0]

    @abnormal_check()
    def expand_rip_route_wizard(self, Wizards):
        if not isinstance(Wizards, (list, set, tuple)):
            Wizards = [Wizards]
        for wizard in Wizards:
            wizard.expand()
        return True

    # ------------------------- GATHER smart scripter -------------------------------------

    @abnormal_check()
    def smart_scripter_global_group(self):
        return get_smart_scripter_global_group()

    @abnormal_check()
    def smart_scripter_command(self, ParentGroup, Command, Rename, **kwargs):
        cmd = create_smart_scripter_command(parent_group=ParentGroup,
                                            command_class_name=Command,
                                            command_name=Rename)
        cmd.edit(**kwargs)
        # for k,v in kwargs.items():
        #     if hasattr(cmd, k):
        #         setattr(cmd, k, v)
        return cmd

    @abnormal_check()
    def smart_scripter_control_condition(self, ControlCommand, ControlConditionName, ConditionResult='PASS', **kwargs):
        condition = create_condition_command(ControlConditionName)
        condition.edit(**kwargs)
        ControlCommand.set_relatives('CommandCondition', condition)
        if ControlConditionName in ['IfCommand', 'ElseIfCommand', 'WhileCommand']:
            ControlCommand.edit(ExpectCondition=f'EnumExpectCondition.{ConditionResult}')
        return condition


    # ------------------------- GATHER ieee802.1as -------------------------------------
    @abnormal_check()
    def create_ieee8021as(self, Port, **kwargs):
        session = Ieee8021as(Upper=Port, **kwargs)
        self.set_protocol_object_map(Protocols=session)
        return session

    @abnormal_check()
    def edit_ieee8021as(self, Session, **kwargs):
        return self._set_attr(Sessions=Session, **kwargs)

    @abnormal_check()
    def wait_ieee8021as_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if isinstance(Sessions, (list, set, tuple)):
            session = Sessions[0]
        else:
            session = Sessions
        if isinstance(session, Ieee8021asProtocolConfig):
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, AttrName='SessionState', State=State, Interval=Interval,
                                    TimeOut=TimeOut)
        else:
            if State is None:
                State = 'RUNNING'
            return self._wait_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)

    @abnormal_check()
    def wait_ieee8021as_clock_state(self, Sessions, State=None, Interval=1, TimeOut=60):
        if isinstance(Sessions, (list, set, tuple)):
            session = Sessions[0]
        else:
            session = Sessions
        if State is None:
            State = State = ['MASTER', 'SLAVE']
        return self._wait_state(Sessions=Sessions, AttrName='ClockState', State=State, Interval=Interval,
                                TimeOut=TimeOut)

    @abnormal_check()
    def get_ieee8021as_clock_statistic(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Ieee8021asClockStatistic",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_ieee8021as_clock_sync_statistic(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Ieee8021asClockSyncStatistic",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_ieee8021as_message_rate_statistic(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Ieee8021asMessageRateStatistic",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_ieee8021as_parent_clock_info_statistic(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Ieee8021asParentClockInfoStatistic",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_ieee8021as_state_summary_statistic(self, Port=None, StaItems=None, ResultView=False):
        if Port is None:
            PortID = None
        elif isinstance(Port, (list, set, tuple)):
            PortID = [x.Name for x in Port]
        else:
            PortID = Port.Name
        result = self._get_statictis(Statictis="Ieee8021asStateSummaryStatistic",
                                     Idx={'PortHandle': PortID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result

    @abnormal_check()
    def get_ieee8021as_time_properties_statistic(self, Session=None, StaItems=None, ResultView=False):
        if Session is None:
            sessionID = None
        elif isinstance(Session, (list, set, tuple)):
            sessionID = [x.Name for x in Session]
        else:
            sessionID = Session.Name
        result = self._get_statictis(Statictis="Ieee8021asTimePropertiesStatistic",
                                     Idx={'SessionHandle': sessionID},
                                     StaItems=StaItems, ResultView=ResultView)
        return result
    # ------------------------- GATHER tsn -------------------------------------
    @abnormal_check()
    def create_tsn_wizard(self, Type, **kwargs):
        if Type.lower() == 'avb':
            return TsnAvbWizard(**kwargs)
        elif Type.lower() == 'qcr':
            return TsnQcrWizard(**kwargs)
        elif Type.lower() == 'frame_pre_emption':
            return BgpVpls(**kwargs)
        elif Type.lower() == 'cb':
            return Pwe()
        else:
            return False


    @abnormal_check()
    def config_tsn_avb_qav(self, Wizards, **kwargs):
        result = True
        try:
            if not isinstance(Wizards, (list, set, tuple)):
                Wizards = [Wizards]
            for i in Wizards:
                i.config_qav(**kwargs)
        except Exception as e:
            str(e)
            result = False
        finally:
            return result

    @abnormal_check()
    def config_tsn_avb_gptp(self, Wizards, **kwargs):
        result = True
        try:
            if not isinstance(Wizards, (list, set, tuple)):
                Wizards = [Wizards]
            for i in Wizards:
                i.config_gptp(**kwargs)
        except Exception as e:
            str(e)
            result = False
        finally:
            return result

    @abnormal_check()
    def config_tsn_avb_non_stream(self, Wizards, **kwargs):
        result = True
        try:
            if not isinstance(Wizards, (list, set, tuple)):
                Wizards = [Wizards]
            for i in Wizards:
                i.config_non_stream(**kwargs)
        except Exception as e:
            str(e)
            result = False
        finally:
            return result

    @abnormal_check()
    def create_tsn_qcr_stream(self, Wizard, TalkerPort=None,
                          ListenerPortList=None, Priority=None, LoadUnit=None, Load=None, FrameLengthType=None,
                          FixedFrameSize=None, MinFrameSize=None, MaxFrameSize=None, StepFrameSize=None, **kwargs):
        if isinstance(Wizard, (list, set, tuple)):
            Wizard = Wizard[0]
        result = Wizard.create_qcr_stream(TalkerPort=TalkerPort,
                  ListenerPortList=ListenerPortList, Priority=Priority, LoadUnit=LoadUnit, Load=Load, FrameLengthType=FrameLengthType,
                  FixedFrameSize=FixedFrameSize, MinFrameSize=MinFrameSize, MaxFrameSize=MaxFrameSize, StepFrameSize=StepFrameSize, **kwargs)
        return result


    @abnormal_check()
    def config_tsn_qcr_stream_identification_function(self, Configs=None,
                                                  StreamIdentificationFunction=None, SourceMacAddress=None,
                                                  DestinationMacAddress=None, VlanId=None, AddUdpHeader=None,
                                                  SourcePort=None, DestinationPort=None, AddIpHeader=None,
                                                  SourceIpAddress=None, DestinationIpAddress=None, IpDscp=None,
                                                  IpNextProtocol=None, **kwargs):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        for i in Configs:
            TsnQcrWizard.config_stream_identification_function(Config=i,
                                              StreamIdentificationFunction=StreamIdentificationFunction, SourceMacAddress=SourceMacAddress,
                                              DestinationMacAddress=DestinationMacAddress, VlanId=VlanId, AddUdpHeader=AddUdpHeader,
                                              SourcePort=SourcePort, DestinationPort=DestinationPort, AddIpHeader=AddIpHeader,
                                              SourceIpAddress=SourceIpAddress, DestinationIpAddress=DestinationIpAddress, IpDscp=IpDscp,
                                              IpNextProtocol=IpNextProtocol, **kwargs)
        return True


    @abnormal_check()
    def expand_wizard(self, Wizard):
        return Wizard.expand()

    # ------------------------- GATHER header ripng-------------------------------------
    @abnormal_check()
    def edit_header_ripng(self, Stream, Level: int = 0,
                                  Command=None,
                                  Version=None,
                                  Reserved=None
                                  ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripng"]
        header = headerList[Level]
        if Command is not None:
            header.command = Command
            result.update({'Command': 'command'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        return result if result else False


    @abnormal_check()
    def insert_ripng_entries(self, Stream, Level=0, Count=1):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripng"]
        header = headerList[Level]
        return header.insertEntries(int(Count))

    @abnormal_check()
    def edit_header_ripng_entry(self, Stream, Level: int = 0, Index=0,
                                Ipaddr=None,
                                RouteTag=None,
                                PrefixLen=None,
                                Metric=None
                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripng"]
        header = headerList[Level]
        params = {}
        if Ipaddr is not None:
            params.update({'ipaddr': Ipaddr})
        if RouteTag is not None:
            params.update({'routeTag': RouteTag})
        if PrefixLen is not None:
            params.update({'prefixLen': PrefixLen})
        if Metric is not None:
            params.update({'metric': Metric})
        return header.editRipngEntries(Index=Index, **params)


    # ------------------------- GATHER header ripv1-------------------------------------
    @abnormal_check()
    def edit_header_ripv1(self, Stream, Level: int = 0,
                          Command=None,
                          Version=None,
                          Reserved=None
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripv1"]
        header = headerList[Level]
        if Command is not None:
            header.command = Command
            result.update({'Command': 'command'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        return result if result else False


    @abnormal_check()
    def insert_ripv1_entries(self, Stream, Level=0, Count=1):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripv1"]
        header = headerList[Level]
        return header.insertEntries(int(Count))


    @abnormal_check()
    def edit_header_ripv1_entry(self, Stream, Level: int = 0, Index=0,
                                Afi=None,
                                Reserved=None,
                                Reserved1=None,
                                Reserved2=None,
                                Ipaddr=None,
                                Metric=None
                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripv1"]
        header = headerList[Level]
        params = {}
        if Ipaddr is not None:
            params.update({'ipaddr': Ipaddr})
        if Afi is not None:
            params.update({'afi': Afi})
        if Reserved is not None:
            params.update({'reserved': Reserved})
        if Reserved1 is not None:
            params.update({'reserved1': Reserved1})
        if Reserved2 is not None:
            params.update({'reserved2': Reserved2})
        if Metric is not None:
            params.update({'metric': Metric})
        return header.editRipngEntries(Index=Index, **params)

    # ------------------------- GATHER header ripv2-------------------------------------
    @abnormal_check()
    def edit_header_ripv2(self, Stream, Level: int = 0,
                          Command=None,
                          Version=None,
                          Reserved=None
                          ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripv2"]
        header = headerList[Level]
        if Command is not None:
            header.command = Command
            result.update({'Command': 'command'})
        if Version is not None:
            header.version = Version
            result.update({'Version': 'version'})
        if Reserved is not None:
            header.reserved = Reserved
            result.update({'Reserved': 'reserved'})
        return result if result else False


    @abnormal_check()
    def insert_ripv2_entries(self, Stream, Level=0, Count=1):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripv2"]
        header = headerList[Level]
        return header.insertEntries(int(Count))


    @abnormal_check()
    def edit_header_ripv2_entry(self, Stream, Level: int = 0, Index=0,
                                Afi=None,
                                RouteTag=None,
                                SubnetMask=None,
                                NextHop=None,
                                Ipaddr=None,
                                Metric=None
                                ):
        result = {}
        if isinstance(Stream, list):
            Stream = Stream[0]
        headerList = self.get_stream_header(Stream=Stream)
        headerList = [x for x in headerList if x.header_type == "ripv2"]
        header = headerList[Level]
        params = {}
        if Ipaddr is not None:
            params.update({'ipaddr': Ipaddr})
        if Afi is not None:
            params.update({'afi': Afi})
        if RouteTag is not None:
            params.update({'routeTag': RouteTag})
        if SubnetMask is not None:
            params.update({'subnetMask': SubnetMask})
        if NextHop is not None:
            params.update({'nextHop': NextHop})
        if Metric is not None:
            params.update({'metric': Metric})
        return header.editRipngEntries(Index=Index, **params)

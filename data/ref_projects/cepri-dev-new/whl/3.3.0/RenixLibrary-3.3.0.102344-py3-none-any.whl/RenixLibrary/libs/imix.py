import logging

from RenixLibrary.data import TesterException, MAP_HANDLE_OBJECT
from renix_py_api.api_gen import StreamImixTemplate, StreamImixFrameLengthDistribution
from renix_py_api.renix_common_api import get_sys_entry

# {ImixTemplateName: imixObject}
map_name_imix = {}


class IMix:

    def __init__(self, Name, Seed=None, Default=False):
        sys_entry = get_sys_entry()
        self.__config = sys_entry.get_children('StreamImixConfig')[0]
        self.__name = Name
        self.__default = Default
        if Seed is None:
            self.__seed = 10900842
        else:
            self.__seed = Seed
        self.__distribution = []
        self.__streamImixFrameLengthDistribution = []
        if Default:
            streamImixTemplateList = self.__config.get_children('StreamImixTemplate')
            streamImixTemplatedict = {x.ImixName: x for x in streamImixTemplateList}
            if Name in list(streamImixTemplatedict.keys()):
                self.__template = streamImixTemplatedict[Name]
            else:
                raise TesterException(f"IMix name({Name}) do not exist")
        else:
            self.__first = True
            if Name in list(map_name_imix.keys()):
                raise TesterException(f"IMix name({Name}) has exist in {list(map_name_imix.keys())}")
            self.__template = StreamImixTemplate(upper=self.__config, ImixName=Name)
        self.__handle = self.__template.handle
        map_name_imix.update({Name: self})
        logging.info(f'map_name_imix update {Name}: {self}')
        MAP_HANDLE_OBJECT.update({self.__handle: self})

    @property
    def upper(self):
        return self.__template.upper

    @property
    def lower(self):
        return self.__template.lower

    @property
    def config(self):
        return self.__config

    @property
    def default(self):
        return self.__default

    @property
    def template(self):
        return self.__template

    @property
    def Name(self):
        return self.__name

    @Name.setter
    def Name(self, Value):
        self.__name = Value

    @property
    def Seed(self):
        return self.__seed

    @Seed.setter
    def Seed(self, Value):
        self.__seed = Value

    @property
    def Distribution(self):
        return self.__distribution

    @property
    def StreamImixFrameLengthDistribution(self):
        return self.__streamImixFrameLengthDistribution

    def init_template(self):
        self.__streamImixFrameLengthDistribution = self.__template.get_children('StreamImixFrameLengthDistribution')
        for x in self.__streamImixFrameLengthDistribution:
            if x.RandomLength:
                self.__distribution.append(
                    {"Type": 'random', "Length": None, "Min": x.MinLength, "Max": x.MaxLength, "Weight": x.Weight})
            else:
                self.__distribution.append(
                    {"Type": 'fixed', "Length": x.FixedLength, "Min": None, "Max": None, "Weight": x.Weight})

    def add_frame_length(self, Type="fixed", Length=None, Min=None, Max=None, Weight=None):
        if Type.lower() == "fixed":
            if Min is not None or Max is not None:
                raise ValueError("Min and Max should be None when Type is fixed")
            else:
                self.__distribution.append({"Type": Type, "Length": Length, "Min": Min, "Max": Max, "Weight": Weight})
                if self.__first:
                    self.__streamImixFrameLengthDistribution = self.__template.get_children(
                        'StreamImixFrameLengthDistribution')
                    self.__first = False
                else:
                    self.__streamImixFrameLengthDistribution.append(
                        StreamImixFrameLengthDistribution(upper=self.template))
                self.__streamImixFrameLengthDistribution[-1].edit(RandomLength=False, FixedLength=Length, Weight=Weight)
        else:
            if Length is not None:
                raise ValueError("Length should be None when Type is random")
            else:
                self.__distribution.append({"Type": Type, "Length": Length, "Min": Min, "Max": Max, "Weight": Weight})
                if self.__first:
                    self.__streamImixFrameLengthDistribution = self.__template.get_children(
                        'StreamImixFrameLengthDistribution')
                    self.__first = False
                else:
                    self.__streamImixFrameLengthDistribution.append(
                        StreamImixFrameLengthDistribution(upper=self.template))
                MaxLength = self.__streamImixFrameLengthDistribution[-1].MaxLength
                MinLength = self.__streamImixFrameLengthDistribution[-1].MinLength
                if int(MaxLength) < int(Min):
                    self.__streamImixFrameLengthDistribution[-1].edit(RandomLength=True, MaxLength=Max)
                if int(MinLength) > int(Max):
                    self.__streamImixFrameLengthDistribution[-1].edit(RandomLength=True, MinLength=Min)
                self.__streamImixFrameLengthDistribution[-1].edit(RandomLength=True, MaxLength=Max, MinLength=Min,
                                                                  Weight=Weight)
        return True

    def del_frame_length(self, Index: int = None):
        if Index is None:
            self.__distribution.clear()
            for x in self.__streamImixFrameLengthDistribution:
                x.delete()
            self.__streamImixFrameLengthDistribution = []
            return True
        else:
            imixFrameLengthDistribution = self.__streamImixFrameLengthDistribution.pop(Index - 1)
            imixFrameLengthDistribution.delete()
            return self.__distribution.pop(Index - 1)

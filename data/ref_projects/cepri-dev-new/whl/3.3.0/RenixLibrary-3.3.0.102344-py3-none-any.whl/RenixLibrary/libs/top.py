from renix_py_api.renix import *


class Top:

    def __init__(self, ClassName, Upper):
        self.__owner_upper = Upper
        self.__object = self._create_object(ClassName=ClassName, Upper=Upper)
        self.__handle = self.__object.handle

    @property
    def upper(self):
        return self.__object.upper

    @property
    def lower(self):
        return self.__object.lower

    @property
    def handle(self):
        return self.__handle

    @property
    def object(self):
        return self.__object

    def delete(self):
        self.__object.delete()
        del self

    def edit(self, **kwargs):
        self.__object.edit(**kwargs)
        return True

    def get_children(self, **kwargs):
        return self.__object.get_children(**kwargs)

    def get_parent(self, **kwargs):
        return self.__object.get_parent(**kwargs)

    def get_relatives(self, **kwargs):
        return self.__object.get_relatives(**kwargs)

    def set_relatives(self, **kwargs):
        return self.__object.set_relatives(**kwargs)

    @staticmethod
    def _create_object(ClassName, Upper):
        objClass = globals()[ClassName](upper=Upper)
        return objClass

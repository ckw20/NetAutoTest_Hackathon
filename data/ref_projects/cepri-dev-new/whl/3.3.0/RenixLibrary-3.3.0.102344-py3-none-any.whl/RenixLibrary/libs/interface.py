# from .top import *
from RenixLibrary.data import TesterException
from RenixAPI.RenixLibrary.libs.top import *
from RenixAPI.RenixLibrary.unittest.data import *


class Interface(Top):

    def __init__(self, Upper, Layers=None):
        super().__init__(ClassName='Interface', Upper=Upper)
        if Layers is not None:
            ReplaceInterfaceStackCommand(InterfaceList=self.handle, NetworkLayers=Layers[0],
                                         TopLayers=Layers[1:]).execute()
            self.__Layers = Layers
        else:
            ReplaceInterfaceStackCommand(InterfaceList=self.handle, NetworkLayers=['eth'],
                                         TopLayers='ipv4').execute()
            self.__Layers = ['eth', 'ipv4']

    @property
    def ETH(self):
        layer = self.object.get_children('EthIILayer')
        if len(layer) == 0:
            raise TesterException("This interface does not has ethernetII layer")
        elif len(layer) == 1:
            return layer[0]
        else:
            return layer

    @property
    def Vlan(self):
        layer = self.object.get_children('VlanLayer')
        if len(layer) == 0:
            raise TesterException("This interface does not has vlan layer")
        elif len(layer) == 1:
            return layer[0]
        else:
            return layer

    @property
    def IPv4(self):
        layer = self.object.get_children('Ipv4Layer')
        if len(layer) == 0:
            raise TesterException("This interface does not has ipv4 layer")
        elif len(layer) == 1:
            return layer[0]
        else:
            return layer

    @property
    def IPv6(self):
        layer = self.object.get_children('Ipv6Layer')
        if len(layer) == 0:
            raise TesterException("This interface does not has ipv6 layer")
        elif len(layer) == 1:
            return layer[0]
        else:
            return layer

    @property
    def Layer(self):
        return self.object.get_children()[1:]

    @property
    def Layers(self):
        return self.__Layers

    @Layers.setter
    def Layers(self, Value):
        ReplaceInterfaceStackCommand(InterfaceList=self.handle, NetworkLayers=['eth'],
                                     TopLayers=Value).execute()
        self.__Layers = Value

    @property
    def EnableLearning(self):
        return self.object.EnableLearningGatewayMac

    @EnableLearning.setter
    def EnableLearning(self, Value):
        self.object.EnableLearning = Value
        self.object.get()

    @property
    def Count(self):
        return self.object.Count

    @Count.setter
    def Count(self, Value):
        self.object.Count = Value
        self.object.get()

    @property
    def EnableInterfaceCount(self):
        return self.object.EnableInterfaceCount

    @EnableInterfaceCount.setter
    def EnableInterfaceCount(self, Value):
        self.object.EnableInterfaceCount = Value
        self.object.get()

    @property
    def RouterIdMode(self):
        return self.object.RouterIdMode

    @RouterIdMode.setter
    def RouterIdMode(self, Value):
        self.object.RouterIdMode = Value
        self.object.get()

    @property
    def RouterId(self):
        return self.object.RouterId

    @RouterId.setter
    def RouterId(self, Value):
        self.object.RouterId = Value
        self.object.get()

    @property
    def RouterIdStep(self):
        return self.object.RouterIdStep

    @RouterIdStep.setter
    def RouterIdStep(self, Value):
        self.object.RouterIdStep = Value
        self.object.get()

    @property
    def RouterIdList(self):
        return self.object.RouterIdList

    @RouterIdList.setter
    def RouterIdList(self, Value):
        self.object.RouterIdList = Value
        self.object.get()

    @property
    def IPv6RouterId(self):
        return self.object.Ipv6RouterId

    @IPv6RouterId.setter
    def IPv6RouterId(self, Value):
        self.object.Ipv6RouterId = Value
        self.object.get()

    @property
    def IPv6RouterIdStep(self):
        return self.object.Ipv6RouterIdStep

    @IPv6RouterIdStep.setter
    def IPv6RouterIdStep(self, Value):
        self.object.Ipv6RouterIdStep = Value
        self.object.get()

    @property
    def IPv6RouterIdList(self):
        return self.object.Ipv6RouterIdList

    @IPv6RouterIdList.setter
    def IPv6RouterIdList(self, Value):
        self.object.Ipv6RouterIdList = Value
        self.object.get()

    @property
    def EnableVlansAssociation(self):
        return self.object.EnableVlansAssociation

    @EnableVlansAssociation.setter
    def EnableVlansAssociation(self, Value):
        self.object.EnableVlansAssociation = Value
        self.object.get()

    def get_gateway_mac(self, Type=None):
        if Type is None:
            if {'ipv4', 'ipv6'}.issubset(self.Layers):
                layer = self.IPv4 + self.IPv6
            elif {'ipv4'}.issubset(self.Layers):
                layer = self.IPv4
            elif {'ipv6'}.issubset(self.Layers):
                layer = self.IPv6
            else:
                raise TesterException("This interface does not get gateway mac")
        else:
            if {'ipv4', 'ipv6'}.issubset(Type):
                layer = self.IPv4 + self.IPv6
            elif {'ipv4'}.issubset(Type):
                layer = self.IPv4
            elif {'ipv6'}.issubset(Type):
                layer = self.IPv6
            else:
                raise TesterException("This interface does not get gateway mac")
        result = []
        if isinstance(layer, list):
            for x in layer:
                result = result + x.ResolvedMacList
        else:
            result = result + layer.ResolvedMacList
        return result


if __name__ == '__main__':
    initialize()
    sys_entry = get_sys_entry()
    sys_entry.ProductType = PRODUCT
    port1 = Port(upper=sys_entry, Location=LOCAATION[0])
    port2 = Port(upper=sys_entry, Location=LOCAATION[1])
    bring_port_online_cmd = BringPortsOnlineCommand(PortList=[port1.handle, port2.handle])
    bring_port_online_cmd.execute()
    interface1 = Interface(Upper=port1)
    interface2 = Interface(Upper=port1, Layers=['eth', 'vlan', 'vlan', 'ipv4', 'ipv6'])
    ipv4 = interface1.IPv4
    print(ipv4.__dict__)
    print(interface2.Layers)
    print(interface2.Layer)
    vlans_2 = interface2.Vlan
    print(vlans_2[0].VlanId)
    vlans_2[1].VlanId = 101
    print(vlans_2[1].VlanId)
    pass

from renix_py_api.renix import *


class MulticastGroup:

    def __init__(self, Version="ipv4", **kwargs):
        self.__sys_entry = get_sys_entry()
        if Version.lower() == "ipv4":
            self.__multicast = Ipv4MulticastGroup(upper=self.__sys_entry)
            self.__version = "ipv4"
        else:
            self.__multicast = Ipv6MulticastGroup(upper=self.__sys_entry)
            self.__version = "ipv6"
        params = kwargs.copy()
        for k, v in kwargs.items():
            if hasattr(self, k):
                params.pop(k)
                setattr(self, str(k), v)
        for k, v in params.items():
            if hasattr(self.__multicast, k):
                setattr(self.__multicast, str(k), v)

    @property
    def multicast(self):
        return self.__multicast

    @property
    def handle(self):
        return self.multicast.handle

    @property
    def Count(self):
        return self.multicast.Count

    @Count.setter
    def Count(self, Value):
        self.multicast.Count = Value
        self.multicast.get()

    @property
    def Mode(self):
        return self.multicast.AddressMode

    @Mode.setter
    def Mode(self, Value):
        self.multicast.AddressMode = Value
        self.multicast.get()

    @property
    def Start(self):
        return self.multicast.StartIpAddress

    @Start.setter
    def Start(self, Value):
        self.multicast.StartIpAddress = Value
        self.multicast.get()

    @property
    def Number(self):
        return self.multicast.NumberOfGroups

    @Number.setter
    def Number(self, Value):
        self.multicast.NumberOfGroups = Value
        self.multicast.get()

    @property
    def Increment(self):
        return self.multicast.Increment

    @Increment.setter
    def Increment(self, Value):
        self.multicast.Increment = Value
        self.multicast.get()

    @property
    def Prefix(self):
        return self.multicast.PrefixLength

    @Prefix.setter
    def Prefix(self, Value):
        self.multicast.PrefixLength = Value
        self.multicast.get()

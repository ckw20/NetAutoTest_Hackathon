import configparser
import os
import datetime

TEMP_CONFIG_TIME = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S-%f')
CONFIG_FILE = os.path.abspath(os.path.join(os.path.split(os.path.abspath(__file__))[0], 'param.cfg'))
renix_lib_path = os.path.join(os.getenv('RENIX_SERVER_PATH'), 'RenixLibrary')
if not os.path.exists(renix_lib_path):
    os.makedirs(renix_lib_path)
TEMP_CONFIG_FILE = os.path.join(os.getenv('RENIX_SERVER_PATH'), 'RenixLibrary', f'param_{TEMP_CONFIG_TIME}.cfg')


# print(TEMP_CONFIG_FILE)

class ParamCfg:
    pass


class Config:
    param = ParamCfg()

    @classmethod
    def parse(cls):
        conf = configparser.ConfigParser()
        if not os.path.exists(TEMP_CONFIG_FILE):
            cfgfile = open(TEMP_CONFIG_FILE, 'w')
            conf.add_section("param")
            conf.set("param", "check", '1')
            conf.set("param", "show", '1')
            conf.set("param", "log", '1')
            conf.write(cfgfile)
            cfgfile.close()
            cls.param.check = True
            cls.param.show = True
            cls.param.log = True
        else:
            conf.read(TEMP_CONFIG_FILE)
            # print(os.path.abspath('param.cfg'))
            if int(conf.get('param', 'check')):
                cls.param.check = True
            else:
                cls.param.check = False
            if int(conf.get('param', 'show')):
                cls.param.show = True
            else:
                cls.param.show = False
            if int(conf.get('param', 'log')):
                cls.param.log = True
            else:
                cls.param.log = False
        del conf

    @classmethod
    def save(cls, check=True, show=False, log=False):
        conf = configparser.ConfigParser()
        cfgfile = open(TEMP_CONFIG_FILE, 'w')
        conf.add_section("param")
        if check:
            conf.set("param", "check", '1')
        else:
            conf.set("param", "check", '0')
        if show:
            conf.set("param", "show", '1')
        else:
            conf.set("param", "show", '0')
        if log:
            conf.set("param", "log", '1')
        else:
            conf.set("param", "log", '0')
        conf.write(cfgfile)
        cfgfile.close()
        del conf

# Config.save()
# Config.parse()
# print(Config.param.check)
# print(Config.param.show)
# print(Config.param.log)

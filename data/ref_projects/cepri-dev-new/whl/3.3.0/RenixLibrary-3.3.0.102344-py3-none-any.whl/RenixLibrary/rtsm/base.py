import os
import signal

from renix_py_api.api_gen import StartupClCommand, ShutdownClCommand, SyncPasswordToRtsmCommand, GetConnectedClCommand, \
    CheckPlCountCommand, SetChiefUserCommand
from renix_py_api.renix import start_renix
from renix_py_api.renix_common_api import RenixApiManager, get_sys_entry, get_cl, set_cl


class RTSM:

    def __init__(self, Host='127.0.0.1', Port=10001, TimeOut=30000):
        self.host = Host
        self.port = Port
        self.pl = None
        self.timeout = TimeOut
        self.cl = []
        self.connection = False
        self.connection_cl = False
        self.cl_port = None
        self.cl_instance = RenixApiManager()
        set_cl(self.cl_instance)

    def Login(self):
        # 连接RTSM
        if not self.connection:
            self.cl_instance.connection_init(host=self.host, port=self.port, timeout=self.timeout)
            self.connection = True
            print(f'RTSM {self.host}:{self.port} login succeeded')
        else:
            raise Exception('RTSM has logined')

    def Logout(self):
        # 断开RTSM连接
        if self.connection:
            self.cl_instance.close_connection()
            self.connection = False
            print(f'RTSM {self.host}:{self.port} logout succeeded')
        else:
            raise Exception('RTSM do not login')

    def Start(self):
        # 启动cl
        if not self.connection:
            self.Login()
        startClCommand = StartupClCommand(cl_instance=self.cl_instance)
        startClCommand.execute()
        self.cl.append(startClCommand.ClListenPort)
        # 将密码同步给rtsm服务
        SyncPasswordToRtsmCommand(Password="xinertel", ClListenPort=startClCommand.ClListenPort, cl_instance=self.cl_instance).execute()
        clCount = GetConnectedClCommand(cl_instance=self.cl_instance)
        clCount.execute()
        self.cl_port = startClCommand.ClListenPort
        print(f'listen cl port: {str(self.cl_port)}')
        if not self.connection:
            self.Logout()
        return startClCommand.ClListenPort

    def ShutDown(self, Port=None):
        if self.pl is not None:
            os.kill(self.pl.pid, signal.SIGTERM)
        # 关闭cl
        if not self.connection:
            self.Login()
        if Port is None:
            for i in self.cl:
                ShutdownClCommand(i, cl_instance=self.cl_instance).execute()
                print(f'Shutdown cl port: {i}')
        else:
            ShutdownClCommand(Port, cl_instance=self.cl_instance).execute()
            print(f'Shutdown cl port: {Port}')
        if not self.connection:
            self.Logout()

    def StartAPP(self, Port=None):
        self.pl = start_renix(self.host, self.cl_port, "xinertel")
        return  self.pl
        # CheckPlCountCommand(ClListenPort=self.cl_port, cl_instance=self.cl_instance).execute()

    def ConnectionCl(self):
        # 连接CL
        if self.connection:
            self.Logout()
        self.cl_instance.connection_init(host=self.host, port=self.cl[-1], timeout=self.timeout)
        self.cl_instance.rom_init()
        # 获取管理员权限
        SetChiefUserCommand(Password="xinertel", cl_instance=self.cl_instance).execute()
        self.cl_port = self.cl[-1]
        self.connection_cl = True
        print(f'Connection cl port: {self.cl_port} succeeded')
        return self.cl_instance.get_sys_entry()

    def DisconnectionCl(self):
        # 连接CL
        if self.connection_cl:
            self.cl_instance.close_connection()
            self.connection_cl = False
            print(f'disconnection cl port: {self.cl_port} succeeded')
        else:
            raise Exception('CL do not connected')


def Connect_Cl(Host='127.0.0.1', Port=9001, TimeOut=30000):
    cl_instance = get_cl()
    cl_instance.connection_init(host=Host, port=Port, timeout=TimeOut)
    cl_instance.rom_init()
    # 获取管理员权限
    SetChiefUserCommand(Password="xinertel").execute()
    return cl_instance.get_sys_entry()


def Disconnection_Cl():
    cl_instance = get_cl()
    cl_instance.close_connection()
    return True


def Close_Cl(Port=9001):
    ShutdownClCommand(Port).execute()


if __name__ == '__main__':
    def case_01():
        rtsm = RTSM(Host='10.0.11.192')
        rtsm.Login()
        cl_port = rtsm.Start()
        rtsm.Logout()
        entry = rtsm.ConnectionCl()
        print(entry.__dict__)
        rtsm.DisconnectionCl()
        rtsm.ShutDown(cl_port)

    def case_02():
        rtsm = RTSM(Host='10.0.11.192')
        cl_port = rtsm.Start()
        entry = rtsm.ConnectionCl()
        print(entry.__dict__)
        rtsm.DisconnectionCl()
        rtsm.ShutDown(cl_port)


    case_01()
    case_02()

import enum
from RenixLibrary.misc import *
from RenixLibrary.header.header_base import HeaderBase
from RenixLibrary.header.ethernet import EthernetHeader
from RenixLibrary.header.raw_802_3 import Raw8023Header
from RenixLibrary.header.vlan import VlanHeader
from RenixLibrary.header.vxlan import VxlanHeader
from RenixLibrary.header.arp import ArpHeader
from RenixLibrary.header.ipv4 import Ipv4Header
from RenixLibrary.header.ipv6 import Ipv6Header
from RenixLibrary.header.tcp import TcpHeader
from RenixLibrary.header.udp import UdpHeader
from RenixLibrary.header.l2tpv2_data import l2tpv2DataHeader
from RenixLibrary.header.l2tpv2_control import l2tpv2ControlHeader
from RenixLibrary.header.l2tpv3_controloverip import l2tpv3ControlOverIpHeader
from RenixLibrary.header.l2tpv3_controloverudp import l2tpv3ControlOverUdpHeader
from RenixLibrary.header.l2tpv3_dataoverip import l2tpv3DataOverIpHeader
from RenixLibrary.header.l2tpv3_dataoverudp import l2tpv3DataOverUdpHeader
from RenixLibrary.header.dhcpv4_server import dhcpv4ServerHeader
from RenixLibrary.header.dhcpv4_client import dhcpv4ClientHeader
from RenixLibrary.header.dhcpv6_client import dhcpv6ClientHeader
from RenixLibrary.header.dhcpv6_server import dhcpv6ServerHeader
from RenixLibrary.header.ppp import PppHeader
from RenixLibrary.header.pppoe import PppoeHeader
from RenixLibrary.header.pppoe_discovery import PppoeDiscoveryHeader
from RenixLibrary.header.icmpv4_echorequest import Icmpv4EchoRequestHeader
from RenixLibrary.header.icmpv4_addressmaskreply import Icmpv4AddressMaskReplyHeader
from RenixLibrary.header.icmpv4_addressmaskrequest import Icmpv4AddressMaskRequestHeader
from RenixLibrary.header.icmpv4_destunreach import Icmpv4DestUnreachHeader
from RenixLibrary.header.icmpv4_echoreply import Icmpv4EchoReplyHeader
from RenixLibrary.header.icmpv4_informationreply import Icmpv4InformationReplyHeader
from RenixLibrary.header.icmpv4_informationrequest import Icmpv4InformationRequestHeader
from RenixLibrary.header.icmpv4_parameterproblem import Icmpv4ParameterProblemHeader
from RenixLibrary.header.icmpv4_redirect import Icmpv4RedirectHeader
from RenixLibrary.header.icmpv4_sourcequench import Icmpv4SourceQuenchHeader
from RenixLibrary.header.icmpv4_timeexceeded import Icmpv4TimeExceededHeader
from RenixLibrary.header.icmpv4_timestampreply import Icmpv4TimeStampReplyHeader
from RenixLibrary.header.icmpv4_timestamprequest import Icmpv4TimeStampRequestHeader
from RenixLibrary.header.icmpv6_destinationunreachable import Icmpv6DestinationUnreachableHeader
from RenixLibrary.header.icmpv6_echoreply import Icmpv6EchoReplyHeader
from RenixLibrary.header.icmpv6_echorequest import Icmpv6EchoRequestHeader
from RenixLibrary.header.icmpv6_mldv1done import Icmpv6Mldv1DoneHeader
from RenixLibrary.header.icmpv6_mldv1query import Icmpv6Mldv1QueryHeader
from RenixLibrary.header.icmpv6_mldv1report import Icmpv6Mldv1ReportHeader
from RenixLibrary.header.icmpv6_mldv2query import Icmpv6Mldv2QueryHeader
from RenixLibrary.header.icmpv6_mldv2report import Icmpv6Mldv2ReportHeader
from RenixLibrary.header.icmpv6_packettoobig import Icmpv6PacketTooBigHeader
from RenixLibrary.header.icmpv6_parameterproblem import Icmpv6ParameterProblemHeader
from RenixLibrary.header.icmpv6_timeexceed import Icmpv6TimeExceedHeader
from RenixLibrary.header.icmpv6_routersolicitation import Icmpv6RouterSolicitationHeader
from RenixLibrary.header.icmpv6_routeradvertise import Icmpv6RouterAdvertiseHeader
from RenixLibrary.header.icmpv6_redirect import Icmpv6RedirectHeader
from RenixLibrary.header.icmpv6_neighboradvertise import Icmpv6NeighborAdvertiseHeader
from RenixLibrary.header.icmpv6_neighborsolicitation import Icmpv6NeighborSolicitationHeader
from RenixLibrary.header.igmpv1_report import Igmpv1ReportHeader
from RenixLibrary.header.igmpv1_query import Igmpv1QueryHeader
from RenixLibrary.header.igmpv2_report import Igmpv2ReportHeader
from RenixLibrary.header.igmpv2_query import Igmpv2QueryHeader
from RenixLibrary.header.igmpv3_report import Igmpv3ReportHeader
from RenixLibrary.header.igmpv3_query import Igmpv3QueryHeader
from RenixLibrary.header.custom import CustomHeader
from RenixLibrary.header.ospfv2_hello import Ospfv2HelloHeader
from RenixLibrary.header.ospfv2_dd import Ospfv2DatabaseDescriptionHeader
from RenixLibrary.header.ospfv2_ack import Ospfv2LinkStateAcknowledgeHeader
from RenixLibrary.header.ospfv2_unknown import Ospfv2UnknownHeader
from RenixLibrary.header.ospfv2_request import Ospfv2LinkStateRequestHeader
from RenixLibrary.header.ospfv2_update import Ospfv2LinkStateUpdateHeader
from RenixLibrary.header.gre import GreHeader
from RenixLibrary.header.gtpv1 import Gtpv1Header
from RenixLibrary.header.gtpv1_extension import Gtpv1ExtensionHeader
from RenixLibrary.header.gtpv1_optional import Gtpv1OptionalHeader
from RenixLibrary.header.gtpv1_optional_extension import Gtpv1OptionalExtensionHeader
from RenixLibrary.header.mpls import MplsHeader
from RenixLibrary.header.isis_l1csnp import IsisL1CsnpHeader
from RenixLibrary.header.isis_l1hello import IsisL1HelloHeader
from RenixLibrary.header.isis_l1lsp import IsisL1LspHeader
from RenixLibrary.header.isis_l1psnp import IsisL1PsnpHeader
from RenixLibrary.header.isis_l2csnp import IsisL2CsnpHeader
from RenixLibrary.header.isis_l2hello import IsisL2HelloHeader
from RenixLibrary.header.isis_l2lsp import IsisL2LspHeader
from RenixLibrary.header.isis_l2psnp import IsisL2PsnpHeader
from RenixLibrary.header.isis_p2phello import IsisP2pHelloHeader
from RenixLibrary.wizard.mpls.mpls_ip_vpn import MplsIpVpn
from RenixLibrary.wizard.mpls.mpls_6_vpe import Mpls6VPe
from RenixLibrary.wizard.mpls.mpls_bgp_vpls import BgpVpls
from RenixLibrary.wizard.mpls.mpls_ldp_vpls import LdpVpls
from RenixLibrary.wizard.mpls.mpls_pwe import Pwe
from RenixLibrary.wizard.test_suite.benchmark import *
from RenixLibrary.header.ipv6_fragment import Ipv6FragmentHeader
from RenixLibrary.header.ipv6_routing import Ipv6RoutingHeader
from RenixLibrary.header.ipv6_authentication import Ipv6AuthenticationHeader
from RenixLibrary.header.ipv6_destination import Ipv6DestinationHeader
from RenixLibrary.header.ipv6_encapsulation import Ipv6EncapsulationHeader
from RenixLibrary.header.ipv6_hopbyhop import Ipv6HopByHopHeader
from RenixLibrary.header.ipv6_sr import Ipv6SrHeader
from RenixLibrary.header.ripng import RipngHeader
from RenixLibrary.header.ripv1 import Ripv1Header
from RenixLibrary.header.ripv2 import Ripv2Header
from RenixLibrary.wizard.bgp_route.bgp_route_wizard import BgpRouteWizard
from RenixLibrary.wizard.isis_lsp.isis_lsp_wizard import IsisLspWizard
from RenixLibrary.wizard.ospf_lsa.ospfv2_lsa_wizard import Ospfv2LsaWizard
from RenixLibrary.wizard.ospf_lsa.ospfv3_lsa_wizard import Ospfv3LsaWizard
from RenixLibrary.wizard.rip_route.rip_route_wizard import RipRouteWizard
from RenixLibrary.wizard.tsn.tsn_avb import TsnAvbWizard
from RenixLibrary.wizard.tsn.tsn_qcr import TsnQcrWizard
from RenixLibrary.header.dot1ah_customerstagethernet import CustomerSTagEthernetHeader
from RenixLibrary.header.dot1ah_encapsulatedcustomerethernetii import EncapsulatedCustomerEthernetIIHeader
from RenixLibrary.header.dot1ah_encapsulatedbackboneethernet import EncapsulatedBackboneEthernetHeader
from RenixLibrary.header.dot1ah_itag import iTagHeader
from RenixLibrary.header.dot1ah_macinmac import MacInMacHeader
from RenixLibrary.header.dot1ah_encapsulatedcustomerethernet import EncapsulatedCustomerEthernetHeader
from RenixLibrary.header.ancp import ANCPPortManagementHeader
from RenixLibrary.header.bier import BierHeader
from RenixLibrary.header.eoam import EoamHeader
from RenixLibrary.header.hdlc import HdlcHeader
from RenixLibrary.header.control_word import ControlWordHeader
from RenixLibrary.header.fcoe import FcoeHeader
from RenixLibrary.header.dot3 import Dot3Header
from RenixLibrary.header.goose import GooseHeader
from RenixLibrary.header.llc import LlcHeader
from RenixLibrary.header.mstp_config import MstpConfigHeader
from RenixLibrary.header.pause import PauseHeader
from RenixLibrary.header.pfc import PfcHeader
from RenixLibrary.header.vn_tag import VntagHeader
from RenixLibrary.header.fibre_channel import FibreChannelHeader
from RenixLibrary.header.lldp_chassisid import LldpChassisIdHeader
from RenixLibrary.header.lldp_portid import LldpPortIdHeader
from RenixLibrary.header.lldp_ttltlv import LldpTtlHeader
from RenixLibrary.header.lldp_endtlv import LldpEndHeader
from RenixLibrary.header.hsr import HsrTagHeader
# TODO CSR-11843 PRP在3.3.0上暂不支持
# from RenixLibrary.header.prp import PrpTagHeader
from RenixLibrary.header.rtag import RTagHeader
from RenixLibrary.header.sctp import SctpHeader
from RenixLibrary.header.trill import TrillHeader

# {streamObject: streamHeaderList}
map_stream_header = {}
# {streamObject: imixObject}
map_stream_imix = {}
# {handle: object}
map_protocol_object = {}
# {handle: object}
MAP_HANDLE_OBJECT = {}
# {
#   'StreamTemplate_1': {
#       'index number': 2
#       'ipv4_1.source.XetModifier': [0, 1]
#       'ipv4_1.destination.XetModifier': [2]
#   }
#   'StreamTemplate_2': {
#       'index number': 3
#       'ipv4_1.source.XetModifier': [0, 1]
#       'ipv4_1.destination.XetModifier': [2, 3]
#   }
# }
MAP_STREAM_MODIFIER_ID = {}


MAP_HEADER_TRANSFORM = {
    "ethernetii": {'EthernetHeader': 'Ethernet.ethernetII'},
    "raw": {'Raw8023Header': 'Ethernet.raw'},
    "vlan": {'VlanHeader': 'VLAN.vlan'},
    "vxlan": {'VxlanHeader': 'VXLAN.vxlan'},
    "arp": {'ArpHeader': 'ARP.arp'},
    "gre": {'GreHeader': 'GRE.gre'},
    "ipv4": {'Ipv4Header': 'IPv4.ipv4'},
    "ipv6": {'Ipv6Header': 'IPv6.ipv6'},
    "tcp": {'TcpHeader': 'TCP.tcp'},
    "udp": {'UdpHeader': 'UDP.udp'},
    "l2tpv2data": {'l2tpv2DataHeader': 'L2TPv2.l2tpv2Data'},
    "l2tpv2control": {'l2tpv2ControlHeader': 'L2TPv2.l2tpv2Control'},
    "l2tpv3controloverip": {'l2tpv3ControlOverIpHeader': 'L2TPv3.l2tpv3ControlOverIp'},
    "l2tpv3controloverudp": {'l2tpv3ControlOverUdpHeader': 'L2TPv3.l2tpv3ControlOverUdp'},
    "l2tpv3dataoverip": {'l2tpv3DataOverIpHeader': 'L2TPv3.l2tpv3DataOverIp'},
    "l2tpv3dataoverudp": {'l2tpv3DataOverUdpHeader': 'L2TPv3.l2tpv3DataOverUdp'},
    "dhcpv4server": {'dhcpv4ServerHeader': 'DHCPv4.dhcpv4Server'},
    "dhcpv4client": {'dhcpv4ClientHeader': 'DHCPv4.dhcpv4Client'},
    "dhcpv6client": {'dhcpv6ClientHeader': 'DHCPv6.dhcpv6Client'},
    "dhcpv6server": {'dhcpv6ServerHeader': 'DHCPv6.dhcpv6Server'},
    "ppp": {'PppHeader': 'PPP.ppp'},
    "pppoe": {'PppoeHeader': 'PPPoE.pppoe'},
    "pppoediscovery": {'PppoeDiscoveryHeader': 'PPPoE.pppoeDiscovery'},
    "icmpv4echorequest": {'Icmpv4EchoRequestHeader': 'ICMPv4.icmpv4EchoRequest'},
    'destunreach': {'Icmpv4DestUnreachHeader': 'ICMPv4.destUnreach'},
    'icmpv4echoreply': {'Icmpv4EchoReplyHeader': 'ICMPv4.icmpv4EchoReply'},
    'informationreply': {'Icmpv4InformationReplyHeader': 'ICMPv4.informationReply'},
    'informationrequest': {'Icmpv4InformationRequestHeader': 'ICMPv4.informationRequest'},
    'icmpv4parameterproblem': {'Icmpv4ParameterProblemHeader': 'ICMPv4.icmpv4ParameterProblem'},
    'icmpv4redirect': {'Icmpv4RedirectHeader': 'ICMPv4.icmpv4Redirect'},
    'sourcequench': {'Icmpv4SourceQuenchHeader': 'ICMPv4.sourceQuench'},
    'timeexceeded': {'Icmpv4TimeExceededHeader': 'ICMPv4.timeExceeded'},
    'timestampreply': {'Icmpv4TimeStampReplyHeader': 'ICMPv4.timestampReply'},
    'timestamprequest': {'Icmpv4TimeStampRequestHeader': 'ICMPv4.timestampRequest'},
    'icmpmaskrequest': {'Icmpv4AddressMaskRequestHeader': 'ICMPv4.icmpMaskRequest'},
    'icmpmaskreply': {'Icmpv4AddressMaskReplyHeader': 'ICMPv4.icmpMaskReply'},
    'destinationunreachable': {'Icmpv6DestinationUnreachableHeader': 'ICMPv6.destinationUnreachable'},
    'icmpv6echoreply': {'Icmpv6EchoReplyHeader': 'ICMPv6.icmpv6EchoReply'},
    'icmpv6echorequest': {'Icmpv6EchoRequestHeader': 'ICMPv6.icmpv6EchoRequest'},
    'packettoobig': {'Icmpv6PacketTooBigHeader': 'ICMPv6.packetTooBig'},
    'icmpv6parameterproblem': {'Icmpv6ParameterProblemHeader': 'ICMPv6.icmpv6ParameterProblem'},
    'timeexceed': {'Icmpv6TimeExceedHeader': 'ICMPv6.timeExceed'},
    'routersolicit': {'Icmpv6RouterSolicitationHeader': 'ICMPv6.routerSolicit'},
    'routeradvertise': {'Icmpv6RouterAdvertiseHeader': 'ICMPv6.routerAdvertise'},
    'icmpv6redirect': {'Icmpv6RedirectHeader': 'ICMPv6.icmpv6Redirect'},
    'neighborsolicit': {'Icmpv6NeighborSolicitationHeader': 'ICMPv6.neighborSolicit'},
    'neighboradvertise': {'Icmpv6NeighborAdvertiseHeader': 'ICMPv6.neighborAdvertise'},
    'mldv1query': {'Icmpv6Mldv1QueryHeader': 'ICMPv6.mldv1Query'},
    'mldv1report': {'Icmpv6Mldv1ReportHeader': 'ICMPv6.mldv1Report'},
    'mldv1done': {'Icmpv6Mldv1DoneHeader': 'ICMPv6.mldv1Done'},
    'mldv2query': {'Icmpv6Mldv2QueryHeader': 'ICMPv6.mldv2Query'},
    'mldv2report': {'Icmpv6Mldv2ReportHeader': 'ICMPv6.mldv2Report'},
    "igmpv1": {'Igmpv1ReportHeader': 'IGMP.igmpv1'},
    "igmpv1query": {'Igmpv1QueryHeader': 'IGMP.igmpv1Query'},
    "igmpv2": {'Igmpv2ReportHeader': 'IGMP.igmpv2'},
    "igmpv2query": {'Igmpv2QueryHeader': 'IGMP.igmpv2Query'},
    "igmpv3report": {'Igmpv3ReportHeader': 'IGMP.igmpv3Report'},
    "igmpv3query": {'Igmpv3QueryHeader': 'IGMP.igmpv3Query'},
    "custom": {'CustomHeader': 'Custom.custom'},
    "ospfv2linkstateupdate": {'Ospfv2LinkStateUpdateHeader': 'OSPFv2.ospfv2LinkStateUpdate'},
    "ospfv2linkstaterequest": {'Ospfv2LinkStateRequestHeader': 'OSPFv2.ospfv2LinkStateRequest'},
    "ospfv2databasedescription": {'Ospfv2DatabaseDescriptionHeader': 'OSPFv2.ospfv2DatabaseDescription'},
    "ospfv2linkstateacknowledge": {'Ospfv2LinkStateAcknowledgeHeader': 'OSPFv2.ospfv2LinkStateAcknowledge'},
    "ospfv2unknown": {'Ospfv2UnknownHeader': 'OSPFv2.ospfv2Unknown'},
    "ospfv2hello": {'Ospfv2HelloHeader': 'OSPFv2.ospfv2Hello'},
    "mpls": {'MplsHeader': 'MPLS.mpls'},
    'l1csnpheader': {'IsisL1CsnpHeader': 'IsIs.l1csnpHeader'},
    'isisl1helloheader': {'IsisL1HelloHeader': 'IsIs.IsIsl1HelloHeader'},
    'l1lspheader': {'IsisL1LspHeader': 'IsIs.l1lspHeader'},
    'l1psnpheader': {'IsisL1PsnpHeader': 'IsIs.l1psnpHeader'},
    'l2csnpheader': {'IsisL2CsnpHeader': 'IsIs.l2csnpHeader'},
    'isisl2helloheader': {'IsisL2HelloHeader': 'IsIs.IsIsl2HelloHeader'},
    'l2lspheader': {'IsisL2LspHeader': 'IsIs.l2lspHeader'},
    'l2psnpheader': {'IsisL2PsnpHeader': 'IsIs.l2psnpHeader'},
    'p2phelloheader': {'IsisP2pHelloHeader': 'IsIs.p2pHelloHeader'},
    'gtpv1': {'Gtpv1Header': 'GTPv1.gtpv1'},
    'gtpv1opt': {'Gtpv1OptionalHeader': 'GTPv1.gtpv1Opt'},
    'gtpv1exthdr': {'Gtpv1ExtensionHeader': 'GTPv1Ext.gtpv1ExtHdr'},
    'gtpv1ext': {'Gtpv1OptionalExtensionHeader': 'GTPv1Ext.gtpv1Ext'},
    'ipv6fragmentheader': {'Ipv6FragmentHeader': 'IPv6.ipv6FragmentHeader'},
    'ipv6routingheader': {'Ipv6RoutingHeader': 'IPv6.ipv6RoutingHeader'},
    'ipv6authenticationheader': {'Ipv6AuthenticationHeader': 'IPv6.ipv6AuthenticationHeader'},
    'ipv6destinationheader': {'Ipv6DestinationHeader': 'IPv6.ipv6DestinationHeader'},
    'ipv6encapsulationheader': {'Ipv6EncapsulationHeader': 'IPv6.ipv6EncapsulationHeader'},
    'ipv6hopbyhopheader': {'Ipv6HopByHopHeader': 'IPv6.ipv6HopByHopHeader'},
    'ipv6srheader': {'Ipv6SrHeader': 'IPv6.ipv6SrHeader'},
    'stag': {'CustomerSTagEthernetHeader': 'STagged.sTag'},
    'encapethernetii': {'EncapsulatedCustomerEthernetIIHeader': 'MacInMacEthernetII.encapEthernetII'},
    'encapbackboneeth': {'EncapsulatedBackboneEthernetHeader': 'EncapBackboneEth.encapBackboneEth'},
    'itag': {'iTagHeader': 'iTag.itag'},
    'mac-in-mac': {'MacInMacHeader': 'MacInMac.mac-in-mac'},
    'encapcustomereth': {'EncapsulatedCustomerEthernetHeader': 'EncapCustomerEth.encapCustomerEth'},
    'portmanagement': {'ANCPPortManagementHeader': 'ANCP.portManagement'},
    'bier': {'BierHeader': 'BIER.bier'},
    'ccm': {'EoamHeader': 'Serviceoam.CCM'},
    'chdlc': {'HdlcHeader': 'CHDLC.chdlc'},
    'cw': {'ControlWordHeader': 'ControlWord.cw'},
    'elsflogi': {'FcoeHeader': 'FCoE.elsFLOGI'},
    '8023': {'Dot3Header': 'Ethernet.8023'},
    'goose': {'GooseHeader': 'Goose.goose'},
    'logiclinkcontrol': {'LlcHeader': 'Ethernet.logicLinkControl'},
    'cfg': {'MstpConfigHeader': 'MSTP.cfg'},
    'pause': {'PauseHeader': 'Pause.pause'},
    'pfc': {'PfcHeader': 'PFC.pfc'},
    'vntag': {'VntagHeader': 'VNTag.vnTag'},
    'fc': {'FibreChannelHeader': 'FCoE.fc'},
    'chassisidtlv': {'LldpChassisIdHeader': 'LLDP.chassisIdTlv'},
    'portidtlv': {'LldpPortIdHeader': 'LLDP.portIdTlv'},
    'ttltlv': {'LldpTtlHeader': 'LLDP.ttlTlv'},
    'endtlv': {'LldpEndHeader': 'LLDP.endTlv'},
    'hsrtag': {'HsrTagHeader': 'HSRTag.hsrtag'},
    'prptag': {'PrpTagHeader': 'PRPTag.prptag'},
    'rtag': {'RTagHeader': 'RTag.rtag'},
    'sctp': {'SctpHeader': 'Sctp.sctp'},
    'trill': {'TrillHeader': 'Trill.trill'},
    'ripng': {'RipngHeader': 'RIP.ripng'},
    'ripv1': {'Ripv1Header': 'RIP.ripv1'},
    'ripv2': {'Ripv2Header': 'RIP.ripv2'},
}

PROTOCOL_MAP = {
    "bgp": {'BgpProtocolConfig': 'BgpRouter'},
    "bfd": {'BfdProtocolConfig': 'BfdRouter'},
    "isis": {'IsisProtocolConfig': 'IsisRouter'},
    "ospfv2": {'Ospfv2ProtocolConfig': 'OspfRouter'},
    "ospfv3": {'Ospfv3ProtocolConfig': 'Ospfv3Router'},
    "pim": {'PimProtocolConfig': 'PimRouter'},
    "rip": {'RipProtocolConfig': 'RipRouter'},
    "dot1x": {'Dot1xProtocolConfig': 'Dot1x'},
    "dot1ag": {'Dot1agProtocolConfig': 'Dot1ag'},
    "dot3ah": {'Dot3ahProtocolConfig': 'Dot3ah'},
    "dhcpv4server": {'Dhcpv4ServerConfig': 'DhcpServer'},
    "dhcpv4": {'Dhcpv4ClientConfig': 'DhcpClient'},
    "dhcpv6server": {'Dhcpv6ServerConfig': 'Dhcpv6Server'},
    "dhcpv6": {'Dhcpv6ClientConfig': 'Dhcpv6Client'},
    "vxlan": {'VxlanProtocolConfig': 'Vxlan'},
    "saa": {'SaaProtocolConfig': 'Saa'},
    "igmp": {'IgmpProtocolConfig': 'Igmp'},
    "igmpquery": {'IgmpQuerierProtocolConfig': 'IgmpQuery'},
    "mld": {'MldProtocolConfig': 'Mld'},
    "mldquery": {'MldQuerierProtocolConfig': 'MldQuery'},
    "l2tp": {'L2tpProtocolConfig': 'L2tp'},
    "pppoeclient": {'PppoeClientConfig': 'PppoeClient'},
    "pppoeserver": {'PppoeServerConfig': 'PppoeServer'},
    "ldp": {'LdpProtocolConfig': 'Ldp'},
    "lspping": {'LspPingConfig': 'Lspping'},
    "pcep": {'PcepProtocolConfig': 'Pcep'},
}

LINESPEED = {
    0: None,
    256: 0.01,
    512: 0.1,
    1024: 1,
    16384: 2.5,
    131072: 5,
    2048: 10,
    32768: 25,
    4096: 40,
    8192: 100,
    262144: 200,
    524288: 400,
}


class LogHandle(enum.Enum):
    LOG_FILE = 0
    LOG_CONSOLE = 1
    LOG_FILE_AND_CONSOLE = 2


class EnumBase(enum.Enum):
    TRUE = True
    FALSE = False
    NONE = None
    All = "All"
    TsuId = 2
    PortId = 3
    MapHardwarePort = 4
    MapPort = 5


class EnumConfigCommand(enum.Enum):
    StreamPortConfig = "StreamPortConfig"
    ConfigurePortsCommand = "ConfigurePortsCommand"


class EnumErorrTester(enum.Enum):
    EditConfigVauleError = "Edit Config Vaule Error"
    StatisticsFind = "Successfully find statistics"
    ParameterLength = "Parameter length error"
    AttributeError = "Attribute does not exist"


class EnumSetLevel(enum.Enum):
    All = 0
    Port = 1
    Stream = 2


class EnumBenchmarkType(enum.Enum):
    RFC2544 = "RFC2544"
    Asymmetric = "Asymmetric"
    RFC2889 = "RFC2889"
    RFC3918 = "RFC3918"


class EnumBenchmarkItem(enum.Enum):
    Throughput = "Throughput"
    FrameLoss = "FrameLoss"
    Latency = "Latency"
    AddressCachingCapacity = "AddressCachingCapacity"


class EnumBenchmarkDbTable(enum.Enum):
    rfc2544 = "Rfc2544PerLoadResult"
    asymmetric = "AsymmetricThroughputResult"
    rfc2889 = "Rfc2889SummaryResult"
    rfc3918 = "Rfc3918PerIterationResult"


class EnumStaType(enum.Enum):
    All = 0
    Port = "PortStats"
    Stream = "StreamStats"
    StreamTx = "StreamTxStats"
    StreamRx = "StreamRxStats"
    StreamBlock = "StreamBlockStats"
    StreamBlockTx = "StreamBlockTxStats"
    StreamBlockRx = "StreamBlockRxStats"


class TesterException(Exception):
    def __init__(self, type_=EnumErorrTester.EditConfigVauleError):
        self.__type = type_
        if str(type_) is EnumErorrTester:
            self.__msg = type_.value
        else:
            self.__msg = type_

    @property
    def type(self):
        return self.__type

    @property
    def msg(self):
        return self.__msg

    def __str__(self):
        return self.msg


BigTao220 = {i + 1: "{}/{}".format(int(i / 16) + 1, i % 16 + 1) for i in range(0, 32)}

BigTao6200 = {i + 1: "{}/{}".format(int(i / 16) + 1, i % 16 + 1) for i in range(0, 96)}

DarYu3000 = {i + 1: "{}/{}".format(int(i / 16) + 1, i % 16 + 1) for i in range(0, 48)}

DarYu12000 = {i + 1: "{}/{}".format(int(i / 16) + 1, i % 16 + 1) for i in range(0, 192)}

STREAMBLOCKSTAT = {
    'StreamBlockID': 0,
    'TxPortID': 1,
    'RxPortID': 2,
    'TxStreamFrames': 3,
    'RxStreamFrames': 4,
    'TxFrameRate': 5,
    'RxFrameRate': 6,
    'TxL1Rate': 7,
    'RxL1Rate': 8,
    'TxUtil': 9,
    'RxUtil': 10,
    'RxLossStreamFrames': 11,
    'RealtimeLossRate': 12,
    'ResumeTime': 13,
    'RxIpv4ChecksumErrorFrames': 14,
    'PrbsFillBytes': 15,
    'DuplicateFrames': 16,
    'InOrderFrames': 17,
    'ReOrderFrames': 18,
    'PrbsErrorBits': 19,
    'PrbsErrorFrames': 20,
    'RxFcsErrorFrames': 21,
    'RxFcsErrorFrameRate': 22,
    'TcpChecksumErrorFrames': 23,
    'TxTotalBytes': 24,
    'RxTotalBytes': 25,
    'RxLateCount': 26,
    'RxInSequenceCount': 27,
    'RxOutofSequenceCount': 28,
    'RxMinInterArrivalTime': 29,
    'RxMaxInterArrivalTime': 30,
    'RxAvgInterArrivalTime': 31,
    'RxShortTermAvgInterArrivalTime': 32,
    'TxByteRate': 33,
    'RxByteRate': 34,
    'TxBitRate': 35,
    'RxBitRate': 36,
    'MinLatency': 37,
    'MaxLatency': 38,
    'AvaLatency': 39,
    'ShortTermAvgLatency': 40,
    'MinJitter': 41,
    'MaxJitter': 42,
    'AvaJitter': 43,
    'ShortTermAvgJitter': 44,
}

L2TPSESSIONSTATISTIC = {
    'L2tpBlockId': 4,
    'NodeIndexInBlock': 5,
    'LocalTunnelId': 6,
    'RemoteTunnelId': 7,
    'LocalSessionId': 8,
    'RemoteSessionId': 9,
    'SessionState': 10,
    'LocalTunnelIpAddress': 11,
    'RemoteTunnelIpAddress': 12,
    'LocalTunnelIpv6Address': 13,
    'RemoteTunnelIpv6Address': 14,
    'TxIcrq': 15,
    'RxIcrq': 16,
    'TxIcrp': 17,
    'RxIcrp': 18,
    'TxIccn': 19,
    'RxIccn': 20,
    'TxCdn': 21,
    'RxCdn': 22,
    'ResultCode': 23,
    'ErrorCode': 24,
    'ErrorMessage': 25,
}

STATISTIC = [
    # Stream
    'PortStats',
    'PortAvgLatencyStats',
    'StreamStats',
    'StreamTxStats',
    'StreamRxStats',
    'StreamBlockStats',
    'StreamBlockTxStats',
    'StreamBlockRxStats',
    # Routings
    # BFD
    'BfdIpv4SessionResult',
    'BfdIpv6SessionResult',
    'BfdSessionResult',
    'IsisBfdSessionResult',
    'IsisBfdIpv6SessionResult',
    'Ospfv2BfdSessionResult',
    'Ospfv3BfdSessionResult',
    # BGP
    'EvpnRoutesStatistic',
    'BgpLinkStateStatistic',
    'BgpSessionStatistic',
    'BgpSessionBlockStatistic',
    # IS-IS
    'IsisSessionStats',
    'IsisTlvStats',
    # OSPFv2
    'Ospfv2SessionResultPropertySet',
    # OSPFv3
    'Ospfv3SessionResultPropertySet',
    # PIM
    'PimSessionStats',
    'PimGroupStats',
    # RIP
    'RipSessionBlockStats',
    'RipSessionStats',
    # Access
    # IGMP
    'IgmpHostResults',
    'IgmpPortAggregatedResults',
    # IGMP Querier
    'IgmpQuerierResults',
    # MLD
    'MldHostResults',
    'MldPortAggregatedResults',
    # MLD Querier
    'MldQuerierResults',
    # PPPoE
    'PppoePortStatistic',
    'PppoeServerBlockStatistic',
    'PppoeServerStatistic',
    'PppoeClientBlockStatistic',
    'PppoeClientStatistic',
    # DHCPv4
    'Dhcpv4ServerStats',
    'Dhcpv4ClientBlockStats',
    'Dhcpv4ClientStats',
    'Dhcpv4PortStats',
    # DHCPv6
    'Dhcpv6PortStatistics',
    'Dhcpv6ServerStatistics',
    'Dhcpv6ClientStatistics',
    'Dhcpv6ClientBlockStatistics',
    'Dhcpv6PdClientStatistics',
    # L2tp
    'L2tpPortStatistic',
    'L2tpBlockStatistic',
    'L2tpSessionStatistic',
    'L2tpTunnelStatistic',
    # 802.1x
    'Dot1xBlockStatistics',
    'Dot1xPortStatistics',
    'Dot1xStatistics',
    # 802.3ah
    'Dot3ahSessionStatistic',
    # MPLS
    # LDP
    'LdpSessionStatistic',
    'LdpLspStatistic',
    # PCEP
    'PcepLspStatistic',
    'PcepLspBlockStatistic',
    'PcepPortStatistic',
    'PcepSessionStatistic',
    'PcepSessionBlockStatistic',
    # LspPing
    'LspPingSessionStats',
    'LspPingEchoRequestStats',
    'LspTraceEchoRequestStats',
    # Vxlan
    'VxlanBindingStats',
    # saa
    'SaaPortStatistics',
    'SaaSessionBlockStatistics',
    'SaaSessionStatistics',
    # Y1371
    'Y1731MegStats',
    'Y1731MpStats',
    'Y1731PortStats',
    # Lacp
    'LacpPortStats',
    'LagPortStats',
    # openflow
    'OfpControllerStats',
    'OfpSwitchDescStats',
    # ovsdb
    'OvsdbResults',
    # twamp
    'TwampClientStats',
    'TwampServerStats',
    'TwampPortClientStats',
    'TwampPortServerStats',
    'TwampTestSessionStats',
    'TwampPortTestSessionStats',
    'TwampStateStats',
    # IEEE802.1AS
    'Ieee8021asClockStatistic',
    'Ieee8021asClockSyncStatistic',
    'Ieee8021asMessageRateStatistic',
    'Ieee8021asParentClockInfoStatistic',
    'Ieee8021asStateSummaryStatistic',
    'Ieee8021asTimePropertiesStatistic'
]

DB_STATISTIC = [
    'PortStats',
    'PortAvgLatencyStats',
    'StreamTxStats',
    'StreamRxStats',
    'StreamStats',
    'StreamBlockTxStats',
    'StreamBlockRxStats',
    'StreamBlockStats',
]

ONESHOT_STATISTIC = [
    # DHCPv4
    'Dhcpv4LeaseStats',
    # DHCPv6
    'Dhcpv6LeaseStatistics',
    # MPLS
    # LDP
    'LdpLspStatistic',
    # 802.3ah
    'Dot3ahErrorEventStats',
    # 802.1ag
    'Dot1agMpStats',
]

# in edit_modifier, will not lower case the attribute.
STREAM_HEADER_FIELD = [
    'CsnpDataHeader',
    'LspDataUnitHeader',
    'FlowLabel',
    'OpCode',
    'RDIbit',
    'Reserved',
    'CCMIntervalField',
    'FirstTLVOffset',
    'SequenceNumber',
    'MAEPI',
    'MAID',
    'ITU-TY1731',
    'InitatorControl',
    'Nx_Porte2eCredit',
    'BPDUType',
    'BPDUFlags',
    'VNI'
]

import re


def is_ipv4(ip_str):
    """

    :param ip_str: IPv4 address string
    :return:
    """
    ipList = ip_str.split('.')
    if ip_str.count('.') != 3:
        return False
    else:
        flag = True
        for num in ipList:
            try:
                ip_num = int(num)
                if ip_num >= 0 and ip_num <= 255 != 0:
                    pass
                else:
                    flag = False
            except ValueError:
                flag = False
        return flag


def is_mac(Address):
    preg = re.compile('^([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}$')
    ret = preg.match(Address)
    if ret is None:
        return False
    else:
        return True


def check_mac():
    def wrapper(func):
        def decor(*args, **kwargs):
            Address = kwargs['Address']
            flag = is_mac(Address)
            if not flag:
                raise ValueError('Address is not mac')
            func_return = func(*args, **kwargs)
            return func_return

        return decor

    return wrapper


class Mac:

    def __init__(self):
        pass

    @staticmethod
    def is_mac(Address):
        preg = re.compile('^([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}$')
        ret = preg.match(Address)
        if ret is None:
            return False
        else:
            return True

    @staticmethod
    def mac_to_int(Address):
        flag = is_mac(Address)
        if not flag:
            raise ValueError('Address is not mac')
        Address = Address.replace(":", "")
        return int(Address, 16)

    @staticmethod
    def int_to_mac(Number):
        # mac地址每段都是2位 不足位数补0 例如：f:23:54 => 0f:23:54
        if len(hex(Number)) % 2 != 0:
            hexStr = '0{0:X}'.format(Number)
        else:
            hexStr = '{0:X}'.format(Number)
        i = 0
        ret = ""
        while i <= len(hexStr) - 2:
            if ret == "":
                ret = hexStr[i:(i + 2)]
            else:
                ret = "".join([ret, ":", hexStr[i:(i + 2)]])
            i = i + 2
        return ret

    @classmethod
    def get_next_mac(cls, Address, n):
        flag = is_mac(Address)
        if not flag:
            raise ValueError('Address is not mac')
        return cls.int_to_mac(cls.mac_to_int(Address) + n)

    @classmethod
    def back_old_mac(cls, Address, n):
        flag = is_mac(Address)
        if not flag:
            raise ValueError('Address is not mac')
        return cls.int_to_mac(cls.mac_to_int(Address) - n)

    @classmethod
    def calc_mac_num(cls, Start, End):
        flag = is_mac(Start)
        if not flag:
            raise ValueError('Start is not mac')
        flag = is_mac(End)
        if not flag:
            raise ValueError('End is not mac')
        mac_start = str(Start).upper()
        mac_end = str(End).upper()
        ret = cls.mac_to_int(mac_end) - cls.mac_to_int(mac_start) + 1
        if ret < 0:
            ret = 0
        return ret

    @classmethod
    def calc_mac_modifier(cls, Start, Step, Count):
        flag = is_mac(Start)
        if not flag:
            raise ValueError('Start is not mac')
        flag = is_mac(Step)
        if not flag:
            raise ValueError('End is not mac')
        mac_start = str(Start).upper()
        mac_step = str(Step).upper()
        ret = cls.mac_to_int(mac_start) + cls.mac_to_int(mac_step) * Count
        return cls.int_to_mac(ret)

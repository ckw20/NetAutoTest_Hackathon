from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class Ospfv3Router(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Ospfv3ProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.RouterState.name

    @property
    def AdjacencyStatus(self):
        return self.session.AdjacencyStatus.name

    @property
    def lsa(self):
        return self.router_lsa + self.network_lsa + self.intra_area_prefix_lsa + self.inter_area_prefix_lsa + \
               self.inter_area_router_lsa + self.as_external_lsa + self.link_lsa + self.nssa_external_lsa + \
               self.opaque_router_info_lsa + self.srv6_locator_lsa

    @property
    def router_lsa(self):
        return self.session.get_children('Ospfv3RouterLsaConfig')

    @property
    def network_lsa(self):
        return self.session.get_children('Ospfv3NetworkLsaConfig')

    @property
    def intra_area_prefix_lsa(self):
        return self.session.get_children('Ospfv3IntraAreaPrefixLsaConfig')

    @property
    def inter_area_prefix_lsa(self):
        return self.session.get_children('Ospfv3InterAreaPrefixLsaConfig')

    @property
    def inter_area_router_lsa(self):
        return self.session.get_children('Ospfv3InterAreaRouterLsaConfig')

    @property
    def as_external_lsa(self):
        return self.session.get_children('Ospfv3AsExternalLsaConfig')

    @property
    def nssa_external_lsa(self):
        return self.session.get_children('Ospfv3NssaExternalLsaConfig')

    @property
    def link_lsa(self):
        return self.session.get_children('Ospfv3LinkLsaConfig')

    @property
    def opaque_router_info_lsa(self):
        return self.session.get_children('Ospfv3OpaqueRouterInfoLsaConfig')

    @property
    def srv6_locator_lsa(self):
        return self.session.get_children('Ospfv3Srv6LocatorLsaConfig')

    def count(self, *args):
        result = {}
        for k in args:
            result.update({k: getattr(self.session, str(k))})
        return result

    @property
    def Enable(self):
        return self.session.EnableOspfv3

    @Enable.setter
    def Enable(self, Value):
        self.session.EnableOspfv3 = Value
        self.session.get()

    @property
    def InstanceId(self):
        return self.session.InstanceId

    @InstanceId.setter
    def InstanceId(self, Value):
        self.session.InstanceId = Value
        self.session.get()

    @property
    def AreaId(self):
        return self.session.AreaId

    @AreaId.setter
    def AreaId(self, Value):
        self.session.AreaId = Value
        self.session.get()

    @property
    def EnableExtendedLsa(self):
        return self.session.EnableExtendedLsa

    @EnableExtendedLsa.setter
    def EnableExtendedLsa(self, Value):
        self.session.EnableExtendedLsa = Value
        self.session.get()

    @property
    def ExtendedLsaMode(self):
        return self.session.ExtendedLsaMode.name

    @ExtendedLsaMode.setter
    def ExtendedLsaMode(self, Value):
        self.session.ExtendedLsaMode = Value
        self.session.get()

    @property
    def AreaExtendedLsaMode(self):
        return self.session.AreaExtendedLsaMode.name

    @AreaExtendedLsaMode.setter
    def AreaExtendedLsaMode(self, Value):
        self.session.AreaExtendedLsaMode = Value
        self.session.get()

    @property
    def EnableBfd(self):
        return self.session.EnableBfd

    @EnableBfd.setter
    def EnableBfd(self, Value):
        self.session.EnableBfd = Value
        self.session.get()

    @property
    def NetworkType(self):
        return self.session.NetworkType.name

    @NetworkType.setter
    def NetworkType(self, Value):
        self.session.NetworkType = Value
        self.session.get()

    @property
    def Priority(self):
        return self.session.Priority

    @Priority.setter
    def Priority(self, Value):
        self.session.Priority = Value
        self.session.get()

    @property
    def InterfaceId(self):
        return self.session.InterfaceId

    @InterfaceId.setter
    def InterfaceId(self, Value):
        self.session.InterfaceId = Value
        self.session.get()

    @property
    def Cost(self):
        return self.session.InterfaceCost

    @Cost.setter
    def Cost(self, Value):
        self.session.InterfaceCost = Value
        self.session.get()

    @property
    def Options(self):
        return self.get_options(Options=self.session.Options)

    @Options.setter
    def Options(self, Value):
        Value = self.transform_options(OptionsEum=EnumOspfv3OptionBit, Value=Value)
        self.session.Options = Value
        self.session.get()

    @property
    def EnableOspfv3Mtu(self):
        return self.session.EnableOspfv3Mtu

    @EnableOspfv3Mtu.setter
    def EnableOspfv3Mtu(self, Value):
        self.session.EnableOspfv3Mtu = Value
        self.session.get()

    @property
    def EnableGracefulRestart(self):
        return self.session.EnableGracefulRestart

    @EnableGracefulRestart.setter
    def EnableGracefulRestart(self, Value):
        self.session.EnableGracefulRestart = Value
        self.session.get()

    @property
    def GracefulRestartReason(self):
        return self.session.GracefulRestartReason.name

    @GracefulRestartReason.setter
    def GracefulRestartReason(self, Value):
        self.session.GracefulRestartReason = Value
        self.session.get()

    @property
    def EnableViewRoutes(self):
        return self.session.EnableViewRoutes

    @EnableViewRoutes.setter
    def EnableViewRoutes(self, Value):
        self.session.EnableViewRoutes = Value
        self.session.get()

    @property
    def HelloInterval(self):
        return self.session.HelloInterval

    @HelloInterval.setter
    def HelloInterval(self, Value):
        self.session.HelloInterval = Value
        self.session.get()

    @property
    def RouterDeadInterval(self):
        return self.session.RouterDeadInterval

    @RouterDeadInterval.setter
    def RouterDeadInterval(self, Value):
        self.session.RouterDeadInterval = Value
        self.session.get()

    @property
    def LsaRetransInterval(self):
        return self.session.LsaRetransInterval

    @LsaRetransInterval.setter
    def LsaRetransInterval(self, Value):
        self.session.LsaRetransInterval = Value
        self.session.get()

    @property
    def LsaRefreshTime(self):
        return self.session.LsaRefreshTime

    @LsaRefreshTime.setter
    def LsaRefreshTime(self, Value):
        self.session.LsaRefreshTime = Value
        self.session.get()

    @classmethod
    def edit_lsa(cls, Lsa, **kwargs):
        Lsa.edit(**kwargs)
        return True

    def create_router_lsa(self, **kwargs):
        config = Ospfv3RouterLsaConfig(upper=self.session)
        if 'RouterType' in kwargs.keys():
            Value = kwargs['RouterType']
            kwargs.pop('RouterType')
            Value = self.transform_options(OptionsEum=EnumOspfv3RouterType, Value=Value)
            config.edit(RouterType=Value)
        if 'Options' in kwargs.keys():
            Value = kwargs['Options']
            kwargs.pop('Options')
            Value = self.transform_options(OptionsEum=EnumOspfv3OptionBit, Value=Value)
            config.edit(Options=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_router_ls_link(cls, RouterLsa, **kwargs):
        config = Ospfv3RouterLsaLinksConfig(upper=RouterLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_endx_sid_sub_tlv(self, RouterLsaLink, **kwargs):
        config = Ospfv3Srv6EndXSidSubTlvConfig(upper=RouterLsaLink)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv3Srv6EndXFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_lan_endx_sid_sub_tlv(self, RouterLsaLink, **kwargs):
        config = Ospfv3Srv6LanEndXSidSubTlvConfig(upper=RouterLsaLink)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv3Srv6EndXFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_link_msd_sub_tlv(self, RouterLsaLink, **kwargs):
        config = Ospfv3Srv6MsdSubTlvConfig(upper=RouterLsaLink)
        kwargs = self.edit_options_of_kwargs(config=config, para='Msds', enum_=EnumOspfv3MSDType, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_endx_sid_structure_sub_tlv(SubTlv, **kwargs):
        config = Ospfv3Srv6SidStructureSubTlvConfig(upper=SubTlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_lan_endx_sid_structure_sub_tlv(SubTlv, **kwargs):
        config = Ospfv3Srv6SidStructureSubTlvConfig(upper=SubTlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_network_lsa(self, **kwargs):
        config = Ospfv3NetworkLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='Options', enum_=EnumOspfv3OptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_network_atch_router(Lsa, **kwargs):
        config = Ospfv3NetworkAtchRouterConfig(upper=Lsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_intra_area_prefix_lsa(self, **kwargs):
        config = Ospfv3IntraAreaPrefixLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedLsaTlvs', enum_=EnumOspfv3IntraAreaPrefixExtendedLsa, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='PrefixOptions', enum_=EnumOspfv3PrefixOptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_inter_area_prefix_lsa(self, **kwargs):
        config = Ospfv3InterAreaPrefixLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedLsaTlvs', enum_=EnumOspfv3InterAreaPrefixExtendedLsa, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='PrefixOptions', enum_=EnumOspfv3PrefixOptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_sr_fapm_sub_tlv(Lsa, **kwargs):
        config = Ospfv3SrFapmSubTlvConfig(upper=Lsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_bier_sub_tlv(Lsa, **kwargs):
        config = Ospfv3BierSubTlvConfig(upper=Lsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_bier_mpls_encap_sub_tlv(SubTlv, **kwargs):
        config = Ospfv3BierMplsEncapSubTlvConfig(upper=SubTlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_inter_area_router_lsa(self, **kwargs):
        config = Ospfv3InterAreaRouterLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='Options', enum_=EnumOspfv3OptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_as_external_lsa(self, **kwargs):
        config = Ospfv3AsExternalLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedLsaTlvs', enum_=EnumOspfv3ExternalExtendedLsaTlv, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedLsaSubTlvs', enum_=EnumOspfv3ExternalExtendedLsaSubTlv, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='PrefixOptions', enum_=EnumOspfv3PrefixOptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_nssa_external_lsa(self, **kwargs):
        config = Ospfv3NssaExternalLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedLsaTlvs', enum_=EnumOspfv3ExternalExtendedLsaTlv, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedLsaSubTlvs', enum_=EnumOspfv3ExternalExtendedLsaSubTlv, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='PrefixOptions', enum_=EnumOspfv3PrefixOptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_link_lsa(self, **kwargs):
        config = Ospfv3LinkLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedLsaTlvs', enum_=EnumOspfv3LinkExtendedLsa, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='PrefixOptions', enum_=EnumOspfv3PrefixOptionBit, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='Options', enum_=EnumOspfv3OptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_opaque_router_info_lsa(self, **kwargs):
        config = Ospfv3OpaqueRouterInfoLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='TlvsFlag', enum_=EnumOspfv3CapabilitiesTlv, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='InformationalCapabilities', enum_=EnumOspfRouterInfoCapabilities, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='FunctionalCapabilities', enum_=EnumOspfRouterFuncCapabilities, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_sr_algorithm_tlv(Lsa, **kwargs):
        config = Ospfv3SrAlgorithmTlvConfig(upper=Lsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sr_fad_tlv(self, Lsa, **kwargs):
        config = Ospfv3SrFadTlvConfig(upper=Lsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='FlexAlgorithmSubTlvs', enum_=EnumOspfv3FlexAlgoSubTlv, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_capabilities_tlv(self, Lsa, **kwargs):
        config = Ospfv3Srv6CapabilitiesTlvConfig(upper=Lsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv3Srv6CapabilitiesFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_node_msd_tlv(self, Lsa, **kwargs):
        config = Ospfv3Srv6MsdSubTlvConfig(upper=Lsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='Msds', enum_=EnumOspfv3MSDType, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_location_lsa(self, **kwargs):
        config = Ospfv3Srv6LocatorLsaConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_location_tlv(self, Lsa, **kwargs):
        config = Ospfv3Srv6LocatorTlvConfig(upper=Lsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv3LocatorFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_srv6_end_sid_sub_tlv(Tlv, **kwargs):
        config = Ospfv3Srv6EndSidSubTlvConfig(upper=Tlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_srv6_sid_structure_sub_tlv(SubTlv, **kwargs):
        config = Ospfv3Srv6SidStructureSubTlvConfig(upper=SubTlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    def advertise(self, Type=None, Lsa=None):
        Ospfv3LsaConfigs = []
        if Type is None:
            if Lsa:
                if not isinstance(Lsa, (list, set, tuple)):
                    Lsa = [Lsa]
                Ospfv3LsaConfigs = [x.handle for x in Lsa]
            else:
                Ospfv3LsaConfigs = [x.handle for x in self.lsa]
        elif Type.lower() == "router":
            Ospfv3LsaConfigs = [x.handle for x in self.router_lsa]
        elif Type.lower() == "network":
            Ospfv3LsaConfigs = [x.handle for x in self.network_lsa]
        elif Type.lower() == "interareaprefix":
            Ospfv3LsaConfigs = [x.handle for x in self.inter_area_prefix_lsa]
        elif Type.lower() == "interarearouter":
            Ospfv3LsaConfigs = [x.handle for x in self.inter_area_router_lsa]
        elif Type.lower() == "asexternal":
            Ospfv3LsaConfigs = [x.handle for x in self.as_external_lsa]
        elif Type.lower() == "nssaexternal":
            Ospfv3LsaConfigs = [x.handle for x in self.nssa_external_lsa]
        elif Type.lower() == "link":
            Ospfv3LsaConfigs = [x.handle for x in self.link_lsa]
        elif Type.lower() == "intraareaprefix":
            Ospfv3LsaConfigs = [x.handle for x in self.intra_area_prefix_lsa]
        elif Type.lower() == "opaquerouterinfo":
            Ospfv3LsaConfigs = [x.handle for x in self.opaque_router_info_lsa]
        elif Type.lower() == "srv6locator":
            Ospfv3LsaConfigs = [x.handle for x in self.srv6_locator_lsa]
        cmd = Ospfv3AdvertiseCommand(Ospfv3LsaConfigs=Ospfv3LsaConfigs)
        cmd.execute()
        return True

    def withdraw(self, Type=None, Lsa=None):
        Ospfv3LsaConfigs = []
        if Type is None:
            if Lsa:
                if not isinstance(Lsa, (list, set, tuple)):
                    Lsa = [Lsa]
                Ospfv3LsaConfigs = [x.handle for x in Lsa]
            else:
                Ospfv3LsaConfigs = [x.handle for x in self.lsa]
        elif Type.lower() == "router":
            Ospfv3LsaConfigs = [x.handle for x in self.router_lsa]
        elif Type.lower() == "network":
            Ospfv3LsaConfigs = [x.handle for x in self.network_lsa]
        elif Type.lower() == "interareaprefix":
            Ospfv3LsaConfigs = [x.handle for x in self.inter_area_prefix_lsa]
        elif Type.lower() == "interarearouter":
            Ospfv3LsaConfigs = [x.handle for x in self.inter_area_router_lsa]
        elif Type.lower() == "asexternal":
            Ospfv3LsaConfigs = [x.handle for x in self.as_external_lsa]
        elif Type.lower() == "nssaexternal":
            Ospfv3LsaConfigs = [x.handle for x in self.nssa_external_lsa]
        elif Type.lower() == "link":
            Ospfv3LsaConfigs = [x.handle for x in self.link_lsa]
        elif Type.lower() == "intraareaprefix":
            Ospfv3LsaConfigs = [x.handle for x in self.intra_area_prefix_lsa]
        elif Type.lower() == "opaquerouterinfo":
            Ospfv3LsaConfigs = [x.handle for x in self.opaque_router_info_lsa]
        elif Type.lower() == "srv6locator":
            Ospfv3LsaConfigs = [x.handle for x in self.srv6_locator_lsa]
        cmd = Ospfv3WithdrawCommand(Ospfv3LsaConfigs=Ospfv3LsaConfigs)
        cmd.execute()
        return True

    def establish(self):
        cmd = Ospfv3EstablishCommand(Ospfv3Configs=self.handle)
        cmd.execute()
        return True

    def grace_restart(self):
        cmd = Ospfv3GraceRestartCommand(Ospfv3Configs=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['DR', 'BACKUP', 'DROTHER']
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_adjacency_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'FULL'
        self.wait_state(StateName='AdjacencyStatus', State=State, Interval=Interval, TimeOut=TimeOut)
        return True


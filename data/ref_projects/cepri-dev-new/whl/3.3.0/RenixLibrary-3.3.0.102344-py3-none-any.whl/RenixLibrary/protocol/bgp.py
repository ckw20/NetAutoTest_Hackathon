from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class BgpRouter(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='BgpProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.BgpProtocolState.name

    @property
    def Ipv4RouterState(self):
        return self.session.BgpV4RouterState.name

    @property
    def Ipv6RouterState(self):
        return self.session.BgpV6RouterState.name

    @property
    def IpVersion(self):
        return self.session.IpVersion.name

    @IpVersion.setter
    def IpVersion(self, Value):
        self.session.IpVersion = Value
        self.session.get()

    @property
    def BgpInitiator(self):
        return self.session.BgpInitiator

    @BgpInitiator.setter
    def BgpInitiator(self, Value):
        self.session.BgpInitiator = Value
        self.session.get()

    @property
    def AsNumber(self):
        return self.session.AsNumber

    @AsNumber.setter
    def AsNumber(self, Value):
        self.session.AsNumber = Value
        self.session.get()

    @property
    def AsNumberStep(self):
        return self.session.AsNumberStep

    @AsNumberStep.setter
    def AsNumberStep(self, Value):
        self.session.AsNumberStep = Value
        self.session.get()

    @property
    def Enable4ByteAs(self):
        return self.session.Enable4ByteAs

    @Enable4ByteAs.setter
    def Enable4ByteAs(self, Value):
        self.session.Enable4ByteAs = Value
        self.session.get()

    @property
    def AsNumber4Byte(self):
        return self.session.AsNumber4Byte

    @AsNumber4Byte.setter
    def AsNumber4Byte(self, Value):
        self.session.AsNumber4Byte = Value
        self.session.get()

    @property
    def AsNumber4ByteStep(self):
        return self.session.AsNumber4ByteStep

    @AsNumber4ByteStep.setter
    def AsNumber4ByteStep(self, Value):
        self.session.AsNumber4ByteStep = Value
        self.session.get()

    @property
    def DutAsNumber(self):
        return self.session.DutAsNumber

    @DutAsNumber.setter
    def DutAsNumber(self, Value):
        self.session.DutAsNumber = Value
        self.session.get()

    @property
    def DutAsNumberStep(self):
        return self.session.DutAsNumberStep

    @DutAsNumberStep.setter
    def DutAsNumberStep(self, Value):
        self.session.DutAsNumberStep = Value
        self.session.get()

    @property
    def Enable4ByteDutAs(self):
        return self.session.Enable4ByteDutAs

    @Enable4ByteDutAs.setter
    def Enable4ByteDutAs(self, Value):
        self.session.Enable4ByteDutAs = Value
        self.session.get()

    @property
    def Dut4ByteAsNumber(self):
        return self.session.Dut4ByteAsNumber

    @Dut4ByteAsNumber.setter
    def Dut4ByteAsNumber(self, Value):
        self.session.Dut4ByteAsNumber = Value
        self.session.get()

    @property
    def Dut4ByteAsNumberStep(self):
        return self.session.Dut4ByteAsNumberStep

    @Dut4ByteAsNumberStep.setter
    def Dut4ByteAsNumberStep(self, Value):
        self.session.Dut4ByteAsNumberStep = Value
        self.session.get()

    @property
    def BgpType(self):
        return self.session.BgpType.name

    @BgpType.setter
    def BgpType(self, Value):
        self.session.BgpType = Value
        self.session.get()

    @property
    def UseGatewayAsDutIp(self):
        return self.session.UseGatewayAsDutIp

    @UseGatewayAsDutIp.setter
    def UseGatewayAsDutIp(self, Value):
        self.session.UseGatewayAsDutIp = Value
        self.session.get()

    @property
    def BgpSessionIpAddressType(self):
        return self.session.BgpSessionIpAddressType.name

    @BgpSessionIpAddressType.setter
    def BgpSessionIpAddressType(self, Value):
        self.session.BgpSessionIpAddressType = Value
        self.session.get()

    @property
    def DutIpv4Address(self):
        return self.session.DutIpv4Address

    @DutIpv4Address.setter
    def DutIpv4Address(self, Value):
        self.session.DutIpv4Address = Value
        self.session.get()

    @property
    def DutIpv4AddressStep(self):
        return self.session.DutIpv4AddressStep

    @DutIpv4AddressStep.setter
    def DutIpv4AddressStep(self, Value):
        self.session.DutIpv4AddressStep = Value
        self.session.get()

    @property
    def DutIpv6Address(self):
        return self.session.DutIpv6Address

    @DutIpv6Address.setter
    def DutIpv6Address(self, Value):
        self.session.DutIpv6Address = Value
        self.session.get()

    @property
    def DutIpv6AddressStep(self):
        return self.session.DutIpv6AddressStep

    @DutIpv6AddressStep.setter
    def DutIpv6AddressStep(self, Value):
        self.session.DutIpv6AddressStep = Value
        self.session.get()

    @property
    def HoldTime(self):
        return self.session.HoldTime

    @HoldTime.setter
    def HoldTime(self, Value):
        self.session.HoldTime = Value
        self.session.get()

    @property
    def KeepaliveTime(self):
        return self.session.KeepaliveTime

    @KeepaliveTime.setter
    def KeepaliveTime(self, Value):
        self.session.KeepaliveTime = Value
        self.session.get()

    @property
    def ConnectRetryCount(self):
        return self.session.ConnectRetryCount

    @ConnectRetryCount.setter
    def ConnectRetryCount(self, Value):
        self.session.ConnectRetryCount = Value
        self.session.get()

    @property
    def ConnectRetryInterval(self):
        return self.session.ConnectRetryInterval

    @ConnectRetryInterval.setter
    def ConnectRetryInterval(self, Value):
        self.session.ConnectRetryInterval = Value
        self.session.get()

    @property
    def MaxRoutesPerUpdateMessage(self):
        return self.session.MaxRoutesPerUpdateMessage

    @MaxRoutesPerUpdateMessage.setter
    def MaxRoutesPerUpdateMessage(self, Value):
        self.session.MaxRoutesPerUpdateMessage = Value
        self.session.get()

    @property
    def RouteRefreshMode(self):
        return self.session.RouteRefreshMode

    @RouteRefreshMode.setter
    def RouteRefreshMode(self, Value):
        self.session.RouteRefreshMode = Value
        self.session.get()

    @property
    def EnableGracefulRestart(self):
        return self.session.EnableGracefulRestart

    @EnableGracefulRestart.setter
    def EnableGracefulRestart(self, Value):
        self.session.EnableGracefulRestart = Value
        self.session.get()

    @property
    def RestartTime(self):
        return self.session.RestartTime

    @RestartTime.setter
    def RestartTime(self, Value):
        self.session.RestartTime = Value
        self.session.get()

    @property
    def EnableViewRoutes(self):
        return self.session.EnableViewRoutes

    @EnableViewRoutes.setter
    def EnableViewRoutes(self, Value):
        self.session.EnableViewRoutes = Value
        self.session.get()

    @property
    def Authentication(self):
        return self.session.Authentication.name

    @Authentication.setter
    def Authentication(self, Value):
        self.session.Authentication = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def EnableBfd(self):
        return self.session.EnableBfd

    @EnableBfd.setter
    def EnableBfd(self, Value):
        self.session.EnableBfd = Value
        self.session.get()

    @property
    def EnableSr(self):
        return self.session.EnableSr

    @EnableSr.setter
    def EnableSr(self, Value):
        self.session.EnableSr = Value
        self.session.get()

    @property
    def MiniLabel(self):
        return self.session.MiniLabel

    @MiniLabel.setter
    def MiniLabel(self, Value):
        self.session.MiniLabel = Value
        self.session.get()

    @property
    def EnableExMsg(self):
        return self.session.EnableExMsg

    @EnableExMsg.setter
    def EnableExMsg(self, Value):
        self.session.EnableExMsg = Value
        self.session.get()

    @property
    def EnableCustomize(self):
        return self.session.EnableCustomize

    @EnableCustomize.setter
    def EnableCustomize(self, Value):
        self.session.EnableCustomize = Value
        self.session.get()

    @property
    def AfiSubAfi(self):
        return self.session.AfiSubAfi

    @AfiSubAfi.setter
    def AfiSubAfi(self, Value):
        self.session.AfiSubAfi = Value
        self.session.get()

    @property
    def EnableParseRxUpdateMsg(self):
        return self.session.EnableParseRxUpdateMsg

    @EnableParseRxUpdateMsg.setter
    def EnableParseRxUpdateMsg(self, Value):
        self.session.EnableParseRxUpdateMsg = Value
        self.session.get()

    @property
    def BgpIpv4Routepool(self):
        return self.session.get_children('BgpIpv4RoutepoolConfig')

    def advertise(self):
        cmd = BgpAdvertiseRoutesCommand(BgpSessionBlockHandles=self.handle)
        cmd.execute()
        return True

    def withdraw(self):
        cmd = BgpWithdrawnRoutesCommand(BgpSessionBlockHandles=self.handle)
        cmd.execute()
        return True

    @classmethod
    def advertise_route(cls, Routes):
        if not isinstance(Routes, (list, set, tuple)):
            Routes = [Routes]
        cmd = AdvertiseBgpRouteBlockCommand(BgpRouteBlockHandles=[x.handle for x in Routes])
        cmd.execute()
        return True

    @classmethod
    def withdraw_route(cls, Routes):
        if not isinstance(Routes, (list, set, tuple)):
            Routes = [Routes]
        cmd = WithdrawBgpRouteBlockCommand(BgpRouteBlockHandles=[x.handle for x in Routes])
        cmd.execute()
        return True

    def establish(self):
        cmd = EstablishBgpCommand(BgpSessionBlockHandles=self.handle)
        cmd.execute()
        return True

    def connect(self):
        cmd = ConnectBgpCommand(BgpSessionBlockHandles=self.handle)
        cmd.execute()
        return True

    def disconnect(self):
        cmd = DisconnectBgpCommand(BgpSessionBlockHandles=self.handle)
        cmd.execute()
        return True

    def graceful_restart(self):
        cmd = BgpGracefulRestartCommand(BgpSessionBlockHandles=self.handle)
        cmd.execute()
        return True

    def refresh(self):
        cmd = BgpRefreshCommand(BgpSessionBlockHandles=self.handle)
        cmd.execute()
        return True

    def bgp_action(self):
        return self.protocol_action(self, 'BgpSessionBlockHandles')

    def establish_bak(self):
        action = self.bgp_action()
        action('EstablishBgpCommand')

    def create_ipv4_route_pool(self, **kwargs):
        config = BgpIpv4RoutepoolConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='EncodeSrTlvs', enum_=EnumBgpSrTlvFlags, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='EncodedSrv6ServiceDataSubTlvs',
                                             enum_=EnumBgpSrv6ServiceDataSubTlvType, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv6_route_pool(self, **kwargs):
        config = BgpIpv6RoutepoolConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='EncodeSrTlvs', enum_=EnumBgpSrv6TlvFlags, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='EncodedSrv6ServiceDataSubTlvs',
                                             enum_=EnumBgpSrv6ServiceDataSubTlvType, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'RUNNING'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_ipv4_router_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'ESTABLISHED'
        self.wait_state(StateName='Ipv4RouterState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_ipv6_router_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'ESTABLISHED'
        self.wait_state(StateName='Ipv6RouterState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def create_capability(self, **kwargs):
        config = BgpCapabilityConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_evpn_route_ad(self, **kwargs):
        config = EvpnRouteAdConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_route_pool_custom_path_attribute(cls, RoutePool, **kwargs):
        params = kwargs.copy()
        config = BgpPathAttributeConfig(upper=RoutePool)
        if 'AttributeValue' in params.keys():
            Value = kwargs['AttributeValue']
            params.pop('AttributeValue')
            Value = cls.transform_attribute(AttributeValue=Value)
            config.edit(AttributeValue=Value)
        if params:
            config.edit(**params)
        return config

    def create_evpn_mac_ip_routes(self, **kwargs):
        config = EvpnRouteMacIpConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_evpn_inclusive_multicast_routes(self, **kwargs):
        config = EvpnRouteInclusiveMulticastConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_evpn_ethernet_segment_routes(self, **kwargs):
        config = EvpnRouteEthernetSegmentConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_evpn_ip_prefix_routes(self, **kwargs):
        config = EvpnRouteIpPrefixConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv4_vpls(self, **kwargs):
        config = BgpIpv4VplsConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv6_vpls(self, **kwargs):
        config = BgpIpv6VplsConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ad_vpls(self, **kwargs):
        config = BgpAdVplsConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv4_flow_specs(self, **kwargs):
        config = BgpIpv4FlowSpecConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='ComponentType', enum_=BgpRouteComponentType, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_flow_specs_actions(cls, FlowSpec, **kwargs):
        if isinstance(FlowSpec, BgpIpv4FlowSpecConfig):
            config = FlowSpec.get_children('BgpIpv4FlowSpecAction')[0]
        elif isinstance(FlowSpec, BgpIpv6FlowSpecConfig):
            config = FlowSpec.get_children('BgpIpv6FlowSpecAction')[0]
        else:
            return False
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_flow_spec_conponent_type(cls, FlowSpec, Type=1, **kwargs):
        if isinstance(FlowSpec, BgpIpv4FlowSpecConfig):
            ip_type = 'Ipv4'
        else:
            ip_type = 'Ipv6'
        Type = int(Type)
        if Type in [1, 2]:
            config = FlowSpec.get_children('Bgp{}FlowSpecType{}Component'.format(ip_type, Type))[0]
        elif Type in range(3, 13):
            config = eval(f'Bgp{ip_type}FlowSpecType{Type}Component(upper=FlowSpec)')
        else:
            return False
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_flow_spec_custom_path_attribute(cls, FlowSpec, **kwargs):
        params = kwargs.copy()
        config = BgpFlowSpecPathAttributeConfig(upper=FlowSpec)
        if 'AttributeValue' in params.keys():
            Value = kwargs['AttributeValue']
            params.pop('AttributeValue')
            Value = cls.transform_attribute(AttributeValue=Value)
            config.edit(AttributeValue=Value)
        if params:
            config.edit(**params)
        return config

    def create_ipv6_flow_spec(self, **kwargs):
        config = BgpIpv6FlowSpecConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='FlowSpecActionType', enum_=Ipv6FlowSpecActionType,
                                             **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='ComponentType', enum_=BgpRouteComponentType, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_ipv6_flow_spec_action(cls, FlowSpec, **kwargs):
        config = FlowSpec.get_children('BgpIpv6FlowSpecAction')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sr_te_policy(self, **kwargs):
        config = BgpSrTePolicyConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='SrTePolicySubTlv', enum_=EnumBgpSrTeSubTlv, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='ColorFlags', enum_=EnumBgpSrTeColorFlag, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='BsidFlags', enum_=EnumBgpSrTeBsidFlag, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sr_te_policy_Segement_list(self, SrTePolicy, **kwargs):
        config = BgpSrTePolicySegmentList(upper=SrTePolicy)
        kwargs = self.edit_options_of_kwargs(config=config, para='SubTlvs', enum_=EnumBgpSrTeSegmentListSubTlv,
                                             **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_segement_sub_tlv(self, SegementList, Type='A', **kwargs):
        config = eval(f'BgpSegmentSubTlvType{Type}(upper=SegementList)')
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumBgpSegmentFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_link_states(self, **kwargs):
        ls = BgpLsNodeConfig(upper=self.session)
        ls_attr = ['Origin', 'AsPath', 'AsPathType', 'NextHop', 'IPv6NextHop', 'EnableLinkLocalNextHop',
                   'LinkLocalNextHop', 'LocalPreference', 'Community', 'ExtendedCommunity', 'ProtocolID',
                   'IdentifierType', 'Identifier']
        ls_descriptor = ls.get_children('BgpLsLocalNodeDescriptorConfig')[0]
        ls_descriptor_attr = ['EnableNodeNLRI', 'LocalNodeDescriptorFlag', 'AsNumber', 'BgpLsIdentifier',
                              'OspfAreaId', 'IGPRouterIdType', 'IsisNonPseud', 'IsisPseud', 'OspfNonPseud',
                              'OspfPseud', 'BgpRouterId', 'MemberAsn']
        # add new attribute for class BgpLsNodeConfig
        for descriptor in ls_descriptor_attr:
            value = getattr(ls_descriptor, descriptor)
            setattr(ls, descriptor, value)
        ls_attribute = ls.get_children('BgpLsLocalNodeAttributeConfig')[0]
        ls_attribute_attr = ['LocalNodeAttributeFlag', 'MultiTopoId', 'NodeFlagBitIsis', 'NodeFlagBitOspfv2',
                             'NodeFlagBitOspfv3', 'NodeName', 'IsisAreaId', 'LocalIpv4RouterIds', 'LocalIpv6RouterIds',
                             'SidLabelType', 'SrCapabilitiesFlags', 'SrCapabilities', 'SrAlgorithm', 'SrLocalBlock',
                             'SrmsPref', 'Srv6CapabilitiesFlags', 'Srv6MsdFlags', 'Srv6MsdMaxSegmentLeft',
                             'Srv6MsdMaxEndPop',
                             'Srv6MsdMaxInsert', 'Srv6MsdMaxEncap', 'Srv6MsdMaxEndD']
        # add new attribute for class BgpLsNodeConfig
        for attribute in ls_attribute_attr:
            value = getattr(ls_attribute, attribute)
            setattr(ls, attribute, value)
        # dispose for enum attrs
        kwargs = self.edit_options_of_kwargs(config=ls_attribute, para='LocalNodeAttributeFlag',
                                             enum_=EnumNodeAttributeFlag, **kwargs)
        value = getattr(ls_attribute, 'LocalNodeAttributeFlag')
        setattr(ls, 'LocalNodeAttributeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=ls_attribute, para='NodeFlagBitIsis', enum_=EnumIsisNodeFlagBits,
                                             **kwargs)
        value = getattr(ls_attribute, 'NodeFlagBitIsis')
        setattr(ls, 'NodeFlagBitIsis', value)

        kwargs = self.edit_options_of_kwargs(config=ls_attribute, para='NodeFlagBitOspfv2',
                                             enum_=EnumOspfv2NodeFlagBits, **kwargs)
        value = getattr(ls_attribute, 'NodeFlagBitOspfv2')
        setattr(ls, 'NodeFlagBitOspfv2', value)

        kwargs = self.edit_options_of_kwargs(config=ls_attribute, para='NodeFlagBitOspfv3',
                                             enum_=EnumOspfv3NodeFlagBits, **kwargs)
        value = getattr(ls_attribute, 'NodeFlagBitOspfv3')
        setattr(ls, 'NodeFlagBitOspfv3', value)

        kwargs = self.edit_options_of_kwargs(config=ls_attribute, para='SrCapabilitiesFlags', enum_=EnumSrCapabilities,
                                             **kwargs)
        value = getattr(ls_attribute, 'SrCapabilitiesFlags')
        setattr(ls, 'SrCapabilitiesFlags', value)

        kwargs = self.edit_options_of_kwargs(config=ls_attribute, para='Srv6CapabilitiesFlags',
                                             enum_=EnumSrv6CapabilityFlag, **kwargs)
        value = getattr(ls_attribute, 'Srv6CapabilitiesFlags')
        setattr(ls, 'Srv6CapabilitiesFlags', value)

        kwargs = self.edit_options_of_kwargs(config=ls_attribute, para='Srv6MsdFlags', enum_=EnumSrv6MsdType, **kwargs)
        value = getattr(ls_attribute, 'Srv6MsdFlags')
        setattr(ls, 'Srv6MsdFlags', value)

        kwargs = self.edit_options_of_kwargs(config=ls_descriptor, para='LocalNodeDescriptorFlag',
                                             enum_=EnumNodeDescriptorFlag, **kwargs)
        value = getattr(ls_descriptor, 'LocalNodeDescriptorFlag')
        setattr(ls, 'LocalNodeDescriptorFlag', value)

        for k, v in kwargs.items():
            if k in ls_attr:
                setattr(ls, k, v)
            elif k in ls_descriptor_attr:
                setattr(ls_descriptor, k, v)
                setattr(ls, k, v)
            elif k in ls_attribute_attr:
                setattr(ls_attribute, k, v)
                setattr(ls, k, v)
        return ls

    def create_link_states_link(self, LinkState, **kwargs):
        # add new attribute for class BgpLsLinkConfig
        link = BgpLsLinkConfig(upper=LinkState)
        link_attr = ['LinkLocalRemoteIdFlag', 'LinkLocalId', 'LinkRemoteId']
        remote_node_descriptor = link.get_children('BgpLsRemoteNodeDescriptorConfig')[0]
        remote_node_descriptor_attr = ['RemoteNodeDescriptorFlag', 'AsNumber', 'BgpLsIdentifier', 'OspfAreaId',
                                       'IGPRouterIdType', 'IsisNonPseud', 'IsisPseud', 'OspfNonPseud', 'OspfPseud',
                                       'BgpRouterId', 'MemberAsn']
        for i in remote_node_descriptor_attr:
            value = getattr(remote_node_descriptor, i)
            setattr(link, i, value)
        link_descriptor = link.get_children('BgpLsLinkDescriptorConfig')[0]
        link_descriptor_attr = ['LinkDescriptorFlag', 'Ipv4InterfaceAddr', 'Ipv4NeighborAddr', 'Ipv6InterfaceAddr',
                                'Ipv6NeighborAddr', 'MultiTopologyId']
        for i in link_descriptor_attr:
            value = getattr(link_descriptor, i)
            setattr(link, i, value)
        link_attribute = link.get_children('BgpLsLinkAttributeConfig')[0]
        link_attribute_attr = ['LinkAttributeFlag', 'LocalIpv4RouterIds', 'RemoteIpv4RouterIds', 'LocalIpv6RouterIds',
                               'RemoteIpv6RouterIds', 'IgpMetricType', 'IgpMetricValue', 'LinkProteType',
                               'ShareRiskGroup',
                               'OspfAdjSidFlag', 'IsisAdjSidFlag', 'AdjSidWeight', 'AdjSidLabel', 'OspfNeighborId',
                               'IsisSystemId',
                               'PeerNodeFlag', 'PeerNodeWeight', 'PeerNodeSidLabel', 'PeerAdjFlag', 'PeerAdjWeight',
                               'PeerAdjSidLabel', 'PeerSetFlag', 'PeerSetWeight', 'PeerSetSidLabel', 'Srv6MsdFlags',
                               'Srv6MsdMaxSegmentLeft', 'Srv6MsdMaxEndPop', 'Srv6MsdMaxInsert', 'Srv6MsdMaxEncap',
                               'Srv6MsdMaxEndD', 'Srv6EndXSidEndpointBehavior', 'Srv6EndXSidFlag',
                               'Srv6EndXSidAlgorithm',
                               'Srv6EndXSidWeight', 'Srv6EndXSidSid', 'Srv6LanEndXSidSystemId',
                               'Srv6LanEndXSidRouterId']
        for i in link_attribute_attr:
            value = getattr(link_attribute, i)
            setattr(link, i, value)
        te_link = link_attribute.get_children('BgpLsTeLinkConfig')[0]
        te_link_attr = ['EnableInterfaceIp', 'InterfaceIp', 'EnableNeighborIp', 'NeighborIp', 'EnableInterfaceIpv6',
                        'InterfaceIpv6', 'EnableNeighborIpv6', 'NeighborIpv6', 'EnableGroup', 'Group',
                        'EnableUniLinkLoss',
                        'LinkLoss', 'LinkLossAflag', 'EnableUniDelay', 'UniDelay', 'UniAflag', 'EnableUniMinMaxDelay',
                        'UniMinMaxAflag', 'UniMinDelay', 'UniMaxDelay', 'EnableUniDelayVariation', 'UniVarDelay',
                        'EnableUniResidual',
                        'UniResBandwidth', 'EnableUniAva', 'UniAvaBandwidth', 'EnableUniUtilized', 'UniUtilized',
                        'EnableMaximum',
                        'Maximum', 'EnableReservable', 'Reservable', 'EnableUnreserved', 'UnreservedBandwidth0',
                        'UnreservedBandwidth1',
                        'UnreservedBandwidth2', 'UnreservedBandwidth3', 'UnreservedBandwidth4', 'UnreservedBandwidth5',
                        'UnreservedBandwidth6',
                        'UnreservedBandwidth7', 'EnableTeDefaultMetric', 'TeDefaultValue']
        for i in te_link_attr:
            value = getattr(te_link, i)
            setattr(link, i, value)

        kwargs = self.edit_options_of_kwargs(config=remote_node_descriptor, para='RemoteNodeDescriptorFlag',
                                             enum_=EnumNodeDescriptorFlag, **kwargs)
        value = getattr(remote_node_descriptor, 'RemoteNodeDescriptorFlag')
        setattr(link, 'RemoteNodeDescriptorFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_descriptor, para='LinkDescriptorFlag',
                                             enum_=EnumLinkDescriptorFlag, **kwargs)
        value = getattr(link_descriptor, 'LinkDescriptorFlag')
        setattr(link, 'LinkDescriptorFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='LinkAttributeFlag',
                                             enum_=EnumLinkAttributeFlag, **kwargs)
        value = getattr(link_attribute, 'LinkAttributeFlag')
        setattr(link, 'LinkAttributeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='LinkProteType', enum_=EnumLinkProtectionType,
                                             **kwargs)
        value = getattr(link_attribute, 'LinkProteType')
        setattr(link, 'LinkProteType', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='OspfAdjSidFlag', enum_=EnumOspfAdjSidFlag,
                                             **kwargs)
        value = getattr(link_attribute, 'OspfAdjSidFlag')
        setattr(link, 'OspfAdjSidFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='IsisAdjSidFlag', enum_=EnumIsisAdjSidFlag,
                                             **kwargs)
        value = getattr(link_attribute, 'IsisAdjSidFlag')
        setattr(link, 'IsisAdjSidFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='PeerNodeFlag', enum_=EnumPeerFlag, **kwargs)
        value = getattr(link_attribute, 'PeerNodeFlag')
        setattr(link, 'PeerNodeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='PeerAdjFlag', enum_=EnumPeerFlag, **kwargs)
        value = getattr(link_attribute, 'PeerAdjFlag')
        setattr(link, 'PeerAdjFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='PeerSetFlag', enum_=EnumPeerFlag, **kwargs)
        value = getattr(link_attribute, 'PeerSetFlag')
        setattr(link, 'PeerSetFlag', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='Srv6MsdFlags', enum_=EnumSrv6MsdType,
                                             **kwargs)
        value = getattr(link_attribute, 'Srv6MsdFlags')
        setattr(link, 'Srv6MsdFlags', value)

        kwargs = self.edit_options_of_kwargs(config=link_attribute, para='Srv6EndXSidFlag', enum_=EnumSrv6SidFlag,
                                             **kwargs)
        value = getattr(link_attribute, 'Srv6EndXSidFlag')
        setattr(link, 'Srv6EndXSidFlag', value)

        for k, v in kwargs.items():
            if k in link_attr:
                setattr(link, k, v)
            elif k in remote_node_descriptor_attr:
                setattr(remote_node_descriptor, k, v)
                setattr(link, k, v)
            elif k in link_descriptor_attr:
                setattr(link_descriptor, k, v)
                setattr(link, k, v)
            elif k in link_attribute_attr:
                setattr(link_attribute, k, v)
                setattr(link, k, v)
            elif k in te_link_attr:
                setattr(te_link, k, v)
                setattr(link, k, v)
        return link

    def create_link_states_prefix(self, LinkState, **kwargs):
        # add new attribute for class BgpLsPrefixConfig
        prefix = BgpLsPrefixConfig(upper=LinkState)
        prefix_descriptor = prefix.get_children('BgpLsPrefixDescriptorConfig')[0]
        prefix_descriptor_attr = ['PrefixDescriptorFlag', 'OspfRouteType', 'PrefixCount', 'PrefixType', 'Ipv4Prefix',
                                  'EndIpv4Prefix', 'Ipv4PrefixLength', 'Ipv4PrefixStep', 'Ipv6Prefix', 'EndIpv6Prefix',
                                  'Ipv6PrefixLength', 'Ipv6PrefixStep', 'MultiTopologyId']
        for i in prefix_descriptor_attr:
            value = getattr(prefix_descriptor, i)
            setattr(prefix, i, value)
        prefix_attribute = prefix.get_children('BgpLsPrefixAttributeConfig')[0]
        prefix_attribute_attr = ['PrefixAttributeFlag', 'IgpFlag', 'PrefixMetric', 'OspfForwardtype',
                                 'Ospfv2ForwardAddr',
                                 'Ospfv3ForwardAddr', 'OspfSrPrefixFlag', 'IsisSrPrefixFlag', 'Algorithm',
                                 'SidLabelIndex',
                                 'Ospfv2SrPrefixAttributeFlag', 'Ospfv3SrPrefixAttributeFlag',
                                 'IsisSrPrefixAttributeFlag',
                                 'SrSourceIpv4Id', 'SrSourceIpv6Id', 'Ospfv2SrRangeFlag', 'IsisSrRangeFlag',
                                 'SrRangeSubTlv',
                                 'Srv6LocatorFlag', 'Srv6LocatorAlgorithm', 'Srv6LocatorMetric']
        for i in prefix_attribute_attr:
            value = getattr(prefix_attribute, i)
            setattr(prefix, i, value)

        kwargs = self.edit_options_of_kwargs(config=prefix_descriptor, para='PrefixDescriptorFlag',
                                             enum_=EnumPrefixDescriptorFlag, **kwargs)
        value = getattr(prefix_descriptor, 'PrefixDescriptorFlag')
        setattr(prefix, 'PrefixDescriptorFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='PrefixAttributeFlag',
                                             enum_=EnumPrefixAttributeFlag, **kwargs)
        value = getattr(prefix_attribute, 'PrefixAttributeFlag')
        setattr(prefix, 'PrefixAttributeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='IgpFlag', enum_=EnumIGPFlag, **kwargs)
        value = getattr(prefix_attribute, 'IgpFlag')
        setattr(prefix, 'IgpFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='OspfSrPrefixFlag',
                                             enum_=EnumOspfSrPrefixSidFlag, **kwargs)
        value = getattr(prefix_attribute, 'OspfSrPrefixFlag')
        setattr(prefix, 'OspfSrPrefixFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='IsisSrPrefixFlag',
                                             enum_=EnumIsisSrPrefixSidFlag, **kwargs)
        value = getattr(prefix_attribute, 'IsisSrPrefixFlag')
        setattr(prefix, 'IsisSrPrefixFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='Ospfv2SrPrefixAttributeFlag',
                                             enum_=EnumOspfv2SrPrefixAttributeFlag, **kwargs)
        value = getattr(prefix_attribute, 'Ospfv2SrPrefixAttributeFlag')
        setattr(prefix, 'Ospfv2SrPrefixAttributeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='Ospfv3SrPrefixAttributeFlag',
                                             enum_=EnumOspfv3SrPrefixAttributeFlag, **kwargs)
        value = getattr(prefix_attribute, 'Ospfv3SrPrefixAttributeFlag')
        setattr(prefix, 'Ospfv3SrPrefixAttributeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='IsisSrPrefixAttributeFlag',
                                             enum_=EnumIsisSrPrefixAttributeFlag, **kwargs)
        value = getattr(prefix_attribute, 'IsisSrPrefixAttributeFlag')
        setattr(prefix, 'IsisSrPrefixAttributeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='Ospfv2SrRangeFlag',
                                             enum_=EnumOspfv2SrRangeFlag, **kwargs)
        value = getattr(prefix_attribute, 'Ospfv2SrRangeFlag')
        setattr(prefix, 'Ospfv2SrRangeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='IsisSrRangeFlag', enum_=EnumIsisSrRangeFlag,
                                             **kwargs)
        value = getattr(prefix_attribute, 'IsisSrRangeFlag')
        setattr(prefix, 'IsisSrRangeFlag', value)

        kwargs = self.edit_options_of_kwargs(config=prefix_attribute, para='Srv6LocatorFlag', enum_=EnumSrv6LocatorFlag,
                                             **kwargs)
        value = getattr(prefix_attribute, 'Srv6LocatorFlag')
        setattr(prefix, 'Srv6LocatorFlag', value)

        for k, v in kwargs.items():
            if k in prefix_descriptor_attr:
                setattr(prefix_descriptor, k, v)
                setattr(prefix, k, v)
            elif k in prefix_attribute_attr:
                setattr(prefix_attribute, k, v)
                setattr(prefix, k, v)
        return prefix

    def create_link_states_prefix_sr_range_sub_tlv(self, LinkStatePrefix, **kwargs):
        link_state_prefix_attr = LinkStatePrefix.get_children('BgpLsPrefixAttributeConfig')[0]
        config = BgpLsSrRangeSubTlvConfig(upper=link_state_prefix_attr)
        kwargs = self.edit_options_of_kwargs(config=config, para='OspfSrPrefixSidFlag', enum_=EnumOspfSrPrefixSidFlag,
                                             **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='IsisSrPrefixSidFlag', enum_=EnumIsisSrPrefixSidFlag,
                                             **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_link_states_srv6_sid(self, LinkState, **kwargs):
        config = BgpLsSrv6SidConfig(upper=LinkState)
        kwargs = self.edit_options_of_kwargs(config=config, para='Srv6AttributeFlag', enum_=EnumSrv6AttributeFlag,
                                             **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='Srv6EndpointBehaviorFlag',
                                             enum_=EnumSrv6EndpointBehaviorFlag,
                                             **kwargs)
        kwargs = self.edit_options_of_kwargs(config=config, para='Srv6BgpPeerNodeSidFlag', enum_=EnumSrv6SidFlag,
                                             **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def sent_data(self, Data):
        send_cmd = BgpSendDataCommand(BgpSessionBlockHandle=self.handle, BgpHexDataString=Data)
        send_cmd.execute()
        return True


if __name__ == '__main__':
    initialize()
    sys_entry = get_sys_entry()
    sys_entry.ProductType = 1
    port1 = Port(upper=sys_entry, Location=LOCAATION[0])
    port2 = Port(upper=sys_entry, Location=LOCAATION[1])
    # bring_port_online_cmd = BringPortsOnlineCommand(PortList=[port1.handle, port2.handle])
    # bring_port_online_cmd.execute()
    interface1 = Interface(upper=port1)
    interface2 = Interface(upper=port2)
    build_ipv41 = BuildInterfaceCommand(InterfaceList=interface1.handle, NetworkLayers=['eth', 'ipv4'])
    build_ipv41.execute()
    build_ipv42 = BuildInterfaceCommand(InterfaceList=interface2.handle, NetworkLayers=['eth', 'ipv4'])
    build_ipv42.execute()
    bfp_1 = BgpRouter(Upper=port1)
    bfp_2 = BgpRouter(Upper=port2)
    bfp_1.establish_bak()
    bfp_2.establish_bak()

    bfp_1.interface = interface1
    bfp_2.interface = interface2
    bfp_1.create_ipv4_route_pool()
    bfp_2.create_ipv4_route_pool()
    ipv4_route_pool_1 = bfp_1.BgpIpv4Routepool
    ipv4_route_pool_2 = bfp_2.BgpIpv4Routepool
    ipv4_route_pool_1[0].FirstRoute = "192.168.1.2"
    ipv4_route_pool_2[0].FirstRoute = "192.168.2.2"
    SaveTestCaseCommand(TestCase="D:/bgp.xcfg").execute()
    print(bfp_1.__dict__)
    print(bfp_2.__dict__)
    pass

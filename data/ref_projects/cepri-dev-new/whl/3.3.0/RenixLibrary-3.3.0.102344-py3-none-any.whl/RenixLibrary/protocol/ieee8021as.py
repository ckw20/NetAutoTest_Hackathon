from .protocol import *


class Ieee8021as(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Ieee8021asProtocolConfig', Upper=Upper, Session=Session)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.SessionState.name

    @property
    def ClockState(self):
        return self.session.ClockState.name

    @property
    def PortNumber(self):
        return self.session.PortNumber

    @PortNumber.setter
    def PortNumber(self, Value):
        self.session.PortNumber = Value
        self.session.get()

    @property
    def Profile(self):
        return self.session.TransmitType.name

    @Profile.setter
    def Profile(self, Value):
        self.session.Profile = Value
        self.session.get()

    @property
    def DomainNumber(self):
        return self.session.DomainNumber

    @DomainNumber.setter
    def DomainNumber(self, Value):
        self.session.DomainNumber = Value
        self.session.get()

    @property
    def SlaveOnly(self):
        return self.session.SlaveOnly

    @SlaveOnly.setter
    def SlaveOnly(self, Value):
        self.session.SlaveOnly = Value
        self.session.get()

    @property
    def StepMode(self):
        return self.session.StepMode

    @StepMode.setter
    def StepMode(self, Value):
        self.session.StepMode = Value
        self.session.get()

    @property
    def Priority1(self):
        return self.session.Priority1

    @Priority1.setter
    def Priority1(self, Value):
        self.session.Priority1 = Value
        self.session.get()

    @property
    def Priority2(self):
        return self.session.Priority2

    @Priority2.setter
    def Priority2(self, Value):
        self.session.Priority2 = Value
        self.session.get()

    @property
    def TimeSource(self):
        return self.session.TimeSource

    @TimeSource.setter
    def TimeSource(self, Value):
        self.session.TimeSource = Value
        self.session.get()

    @property
    def ClockAccuracy(self):
        return self.session.ClockAccuracy

    @ClockAccuracy.setter
    def ClockAccuracy(self, Value):
        self.session.ClockAccuracy = Value
        self.session.get()

    @property
    def ClockClass(self):
        return self.session.ClockClass

    @ClockClass.setter
    def ClockClass(self, Value):
        self.session.ClockClass = Value
        self.session.get()

    @property
    def properties(self):
        return self.session.TransmitType.name

    @properties.setter
    def properties(self, Value):
        self.session.properties = Value
        self.session.get()

    @property
    def UTCOffset(self):
        return self.session.UTCOffset

    @UTCOffset.setter
    def UTCOffset(self, Value):
        self.session.UTCOffset = Value
        self.session.get()

    @property
    def TimeTraceble(self):
        return self.session.TimeTraceble

    @TimeTraceble.setter
    def TimeTraceble(self, Value):
        self.session.TimeTraceble = Value
        self.session.get()

    @property
    def FrequencyTraceble(self):
        return self.session.FrequencyTraceble

    @FrequencyTraceble.setter
    def FrequencyTraceble(self, Value):
        self.session.FrequencyTraceble = Value
        self.session.get()

    @property
    def NeighborPropagationDelayThresholdOneStep(self):
        return self.session.NeighborPropagationDelayThresholdOneStep

    @NeighborPropagationDelayThresholdOneStep.setter
    def NeighborPropagationDelayThresholdOneStep(self, Value):
        self.session.NeighborPropagationDelayThresholdOneStep = Value
        self.session.get()

    @property
    def NeighborPropagationDelayThresholdTwoStep(self):
        return self.session.NeighborPropagationDelayThresholdTwoStep

    @NeighborPropagationDelayThresholdTwoStep.setter
    def NeighborPropagationDelayThresholdTwoStep(self, Value):
        self.session.NeighborPropagationDelayThresholdTwoStep = Value
        self.session.get()

    @property
    def AnnounceReceiptTimeout(self):
        return self.session.AnnounceReceiptTimeout

    @AnnounceReceiptTimeout.setter
    def AnnounceReceiptTimeout(self, Value):
        self.session.AnnounceReceiptTimeout = Value
        self.session.get()

    @property
    def LogAnnounceInterval(self):
        return self.session.LogAnnounceInterval

    @LogAnnounceInterval.setter
    def LogAnnounceInterval(self, Value):
        self.session.LogAnnounceInterval = Value
        self.session.get()

    @property
    def LogSyncInterval(self):
        return self.session.LogSyncInterval

    @LogSyncInterval.setter
    def LogSyncInterval(self, Value):
        self.session.LogSyncInterval = Value
        self.session.get()

    @property
    def LogPdelayReqInterval(self):
        return self.session.TransmitType.name

    @LogPdelayReqInterval.setter
    def LogPdelayReqInterval(self, Value):
        self.session.LogPdelayReqInterval = Value
        self.session.get()

    @property
    def EnableMsgIntervalReqTlv(self):
        return self.session.EnableMsgIntervalReqTlv

    @EnableMsgIntervalReqTlv.setter
    def EnableMsgIntervalReqTlv(self, Value):
        self.session.EnableMsgIntervalReqTlv = Value
        self.session.get()

    @property
    def LogMsgIntervalReqTlvInterval(self):
        return self.session.LogMsgIntervalReqTlvInterval

    @LogMsgIntervalReqTlvInterval.setter
    def LogMsgIntervalReqTlvInterval(self, Value):
        self.session.LogMsgIntervalReqTlvInterval = Value
        self.session.get()

    @property
    def PeerLogPdelayReqInterval(self):
        return self.session.PeerLogPdelayReqInterval

    @PeerLogPdelayReqInterval.setter
    def PeerLogPdelayReqInterval(self, Value):
        self.session.PeerLogPdelayReqInterval = Value
        self.session.get()

    @property
    def PeerLogSyncInterval(self):
        return self.session.PeerLogSyncInterval

    @PeerLogSyncInterval.setter
    def PeerLogSyncInterval(self, Value):
        self.session.PeerLogSyncInterval = Value
        self.session.get()

    @property
    def PeerLogGptpCapableTlvInterval(self):
        return self.session.PeerLogGptpCapableTlvInterval

    @PeerLogGptpCapableTlvInterval.setter
    def PeerLogGptpCapableTlvInterval(self, Value):
        self.session.PeerLogGptpCapableTlvInterval = Value
        self.session.get()

    @property
    def EnableGptpCapableTlv(self):
        return self.session.EnableGptpCapableTlv

    @EnableGptpCapableTlv.setter
    def EnableGptpCapableTlv(self, Value):
        self.session.EnableGptpCapableTlv = Value
        self.session.get()

    @property
    def LogGptpCapableTlvInterval(self):
        return self.session.LogGptpCapableTlvInterval

    @LogGptpCapableTlvInterval.setter
    def LogGptpCapableTlvInterval(self, Value):
        self.session.LogGptpCapableTlvInterval = Value
        self.session.get()

    @property
    def EnableGptpCapableMsgIntervalReqTlv(self):
        return self.session.EnableGptpCapableMsgIntervalReqTlv

    @EnableGptpCapableMsgIntervalReqTlv.setter
    def EnableGptpCapableMsgIntervalReqTlv(self, Value):
        self.session.EnableGptpCapableMsgIntervalReqTlv = Value
        self.session.get()

    @property
    def PdelayReqCorrectionField(self):
        return self.session.TransmitType.name

    @PdelayReqCorrectionField.setter
    def PdelayReqCorrectionField(self, Value):
        self.session.PdelayReqCorrectionField = Value
        self.session.get()

    @property
    def CummulativeScaledRateOffset(self):
        return self.session.CummulativeScaledRateOffset

    @CummulativeScaledRateOffset.setter
    def CummulativeScaledRateOffset(self, Value):
        self.session.CummulativeScaledRateOffset = Value
        self.session.get()

    @property
    def OffsetScaledLogVariance(self):
        return self.session.OffsetScaledLogVariance

    @OffsetScaledLogVariance.setter
    def OffsetScaledLogVariance(self, Value):
        self.session.OffsetScaledLogVariance = Value
        self.session.get()

    @property
    def StepsRemoved(self):
        return self.session.StepsRemoved

    @StepsRemoved.setter
    def StepsRemoved(self, Value):
        self.session.StepsRemoved = Value
        self.session.get()

    @property
    def FollowupCorrectionField(self):
        return self.session.FollowupCorrectionField

    @FollowupCorrectionField.setter
    def FollowupCorrectionField(self, Value):
        self.session.FollowupCorrectionField = Value
        self.session.get()

    @property
    def PdelayReqCorrectionField(self):
        return self.session.PdelayReqCorrectionField

    @PdelayReqCorrectionField.setter
    def PdelayReqCorrectionField(self, Value):
        self.session.PdelayReqCorrectionField = Value
        self.session.get()

    @property
    def PdelayRspCorrectionField(self):
        return self.session.PdelayRspCorrectionField

    @PdelayRspCorrectionField.setter
    def PdelayRspCorrectionField(self, Value):
        self.session.PdelayRspCorrectionField = Value
        self.session.get()

    @property
    def PdelayRspFollowupCorrectionField(self):
        return self.session.PdelayRspFollowupCorrectionField

    @PdelayRspFollowupCorrectionField.setter
    def PdelayRspFollowupCorrectionField(self, Value):
        self.session.PdelayRspFollowupCorrectionField = Value
        self.session.get()

    @property
    def FollowupCorrectionField(self):
        return self.session.FollowupCorrectionField

    @FollowupCorrectionField.setter
    def FollowupCorrectionField(self, Value):
        self.session.FollowupCorrectionField = Value
        self.session.get()

    @property
    def PdelayReqCorrectionField(self):
        return self.session.PdelayReqCorrectionField

    @PdelayReqCorrectionField.setter
    def PdelayReqCorrectionField(self, Value):
        self.session.PdelayReqCorrectionField = Value
        self.session.get()

    @property
    def PdelayRspCorrectionField(self):
        return self.session.PdelayRspCorrectionField

    @PdelayRspCorrectionField.setter
    def PdelayRspCorrectionField(self, Value):
        self.session.PdelayRspCorrectionField = Value
        self.session.get()

    @property
    def PdelayRspFollowupCorrectionField(self):
        return self.session.PdelayRspFollowupCorrectionField

    @PdelayRspFollowupCorrectionField.setter
    def PdelayRspFollowupCorrectionField(self, Value):
        self.session.PdelayRspFollowupCorrectionField = Value
        self.session.get()

    def start(self):
        cmd = StartProtocolCommand(ProtocolList=self.handle)
        cmd.execute()
        return True

    def stop(self):
        cmd = StopProtocolCommand(ProtocolList=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'RUNNING'
        self.wait_state(StateName='SessionState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_clock_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['MASTER', 'SLAVE']
        self.wait_state(StateName='ClockState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True


from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class Vxlan(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='VxlanProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def state(self):
        return self.session.VtepState

    @property
    def version(self):
        return self.session.Version

    @property
    def AssociatedVmCount(self):
        return self.session.AssociatedVmCount

    @property
    def AssociatedSegments(self):
        return self.session.AssociatedSegments

    @property
    def AutoUdpSourcePort(self):
        return self.session.AutoUdpSourcePort

    @AutoUdpSourcePort.setter
    def AutoUdpSourcePort(self, Value):
        self.session.AutoUdpSourcePort = Value
        self.session.get()

    @property
    def UdpSourcePort(self):
        return self.session.UdpSourcePort

    @UdpSourcePort.setter
    def UdpSourcePort(self, Value):
        self.session.UdpSourcePort = Value
        self.session.get()

    @property
    def EnableUdpChecksum(self):
        return self.session.EnableUdpChecksum

    @EnableUdpChecksum.setter
    def EnableUdpChecksum(self, Value):
        self.session.EnableUdpChecksum = Value
        self.session.get()

    @property
    def EvpnLearning(self):
        return self.session.EvpnLearning

    @EvpnLearning.setter
    def EvpnLearning(self, Value):
        self.session.EvpnLearning = Value
        self.session.get()

    @property
    def OvsdbLearning(self):
        return self.session.OvsdbLearning

    @OvsdbLearning.setter
    def OvsdbLearning(self, Value):
        self.session.OvsdbLearning = Value
        self.session.get()

    @property
    def MulticastType(self):
        return self.session.MulticastType

    @MulticastType.setter
    def MulticastType(self, Value):
        self.session.MulticastType = Value
        self.session.get()

    @property
    def VtepTunnelIp(self):
        return self.session.VtepTunnelIp

    @VtepTunnelIp.setter
    def VtepTunnelIp(self, Value):
        self.session.VtepTunnelIp = Value
        self.session.get()

    @property
    def EnableIrb(self):
        return self.session.EnableIrb

    @EnableIrb.setter
    def EnableIrb(self, Value):
        self.session.EnableIrb = Value
        self.session.get()

    @property
    def RPAddress(self):
        return self.session.RPAddress

    @RPAddress.setter
    def RPAddress(self, Value):
        self.session.RPAddress = Value
        self.session.get()

    @property
    def RPIpv6Address(self):
        return self.session.RPIpv6Address

    @RPIpv6Address.setter
    def RPIpv6Address(self, Value):
        self.session.RPIpv6Address = Value
        self.session.get()

    @property
    def IrbMode(self):
        return self.session.IrbMode

    @IrbMode.setter
    def IrbMode(self, Value):
        self.session.IrbMode = Value
        self.session.get()

    @classmethod
    def create_segment(cls, **kwargs):
        config = VxlanSegmentConfig(upper=get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @property
    def SegmentConfig(self):
        return get_sys_entry().get_children('VxlanSegmentConfig')

    @classmethod
    def binding_multicast_group(cls, Segments, MulticastGroups):
        cmd = VxlanSelectMulticastGroupCommand(VxlanSegmentHandle=[x.handle for x in Segments],
                                               VxlanMulticastGroupHandle=[x.handle for x in MulticastGroups])
        cmd.execute()
        return True

    @classmethod
    def binding_vm(cls, Segments, Interfaces):
        cmd = VxlanSelectVmCommand(VxlanSegmentHandles=[x.handle for x in Segments],
                                   VxlanVmHandles=[x.handle for x in Interfaces])
        cmd.execute()
        return True

    @classmethod
    def binding_vtep(cls, Vteps, Interfaces):
        cmd = VxlanSelectVtepCommand(VxlanVtepHandle=[x.handle for x in Vteps], VxlanVmHandle=[x.handle for x in Interfaces])
        cmd.execute()
        return True

    @classmethod
    def start_ping(cls, Interfaces, **kwargs):
        cmd = VxlanStartPingCommand(InterfaceHandles=[x.handle for x in Interfaces], **kwargs)
        cmd.execute()
        return True

    @classmethod
    def stop_ping(cls, Interfaces, **kwargs):
        cmd = VxlanStopPingCommand(InterfaceHandles=[x.handle for x in Interfaces], **kwargs)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'STARTED'
        self.wait_state(StateName='state', State=State, Interval=Interval, TimeOut=TimeOut)
        return True


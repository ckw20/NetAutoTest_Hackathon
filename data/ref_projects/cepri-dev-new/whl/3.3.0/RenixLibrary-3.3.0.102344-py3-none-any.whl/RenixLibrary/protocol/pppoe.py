import time

from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class Pppoe(Protocol):

    def __init__(self, Upper, Config, Session=None, **kwargs):
        super().__init__(ClassName=Config, Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def IpcpState(self):
        return self.session.IpcpState.name

    @property
    def Ipv6cpState(self):
        return self.session.Ipv6cpState.name

    @property
    def IpVersion(self):
        return self.session.IpVersion.name

    @property
    def PppSessionCount(self):
        return self.session.PppSessionCount

    @property
    def EmulationMode(self):
        return self.session.EmulationMode

    @EmulationMode.setter
    def EmulationMode(self, Value):
        self.session.EmulationMode = Value
        self.session.get()

    @property
    def AuthenticationType(self):
        return self.session.AuthenticationType.name

    @AuthenticationType.setter
    def AuthenticationType(self, Value):
        self.session.AuthenticationType = Value
        self.session.get()

    @property
    def Username(self):
        return self.session.Username

    @Username.setter
    def Username(self, Value):
        self.session.Username = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def ServiceName(self):
        return self.session.ServiceName

    @ServiceName.setter
    def ServiceName(self, Value):
        self.session.ServiceName = Value
        self.session.get()

    @property
    def EnableMaxPayloadTag(self):
        return self.session.EnableMaxPayloadTag

    @EnableMaxPayloadTag.setter
    def EnableMaxPayloadTag(self, Value):
        self.session.EnableMaxPayloadTag = Value
        self.session.get()

    @property
    def MaxPayloadBytes(self):
        return self.session.MaxPayloadBytes

    @MaxPayloadBytes.setter
    def MaxPayloadBytes(self, Value):
        self.session.MaxPayloadBytes = Value
        self.session.get()

    @property
    def LcpConfigReqTimeout(self):
        return self.session.LcpConfigReqTimeout

    @LcpConfigReqTimeout.setter
    def LcpConfigReqTimeout(self, Value):
        self.session.LcpConfigReqTimeout = Value
        self.session.get()

    @property
    def LcpConfigReqMaxAttempts(self):
        return self.session.LcpConfigReqMaxAttempts

    @LcpConfigReqMaxAttempts.setter
    def LcpConfigReqMaxAttempts(self, Value):
        self.session.LcpConfigReqMaxAttempts = Value
        self.session.get()

    @property
    def LcpTermReqTimeout(self):
        return self.session.LcpTermReqTimeout

    @LcpTermReqTimeout.setter
    def LcpTermReqTimeout(self, Value):
        self.session.LcpTermReqTimeout = Value
        self.session.get()

    @property
    def LcpTermReqMaxAttempts(self):
        return self.session.LcpTermReqMaxAttempts

    @LcpTermReqMaxAttempts.setter
    def LcpTermReqMaxAttempts(self, Value):
        self.session.LcpTermReqMaxAttempts = Value
        self.session.get()

    @property
    def NcpConfigReqTimeout(self):
        return self.session.NcpConfigReqTimeout

    @NcpConfigReqTimeout.setter
    def NcpConfigReqTimeout(self, Value):
        self.session.NcpConfigReqTimeout = Value
        self.session.get()

    @property
    def NcpConfigReqMaxAttempts(self):
        return self.session.NcpConfigReqMaxAttempts

    @NcpConfigReqMaxAttempts.setter
    def NcpConfigReqMaxAttempts(self, Value):
        self.session.NcpConfigReqMaxAttempts = Value
        self.session.get()

    @property
    def LcpNcpMaxNak(self):
        return self.session.LcpNcpMaxNak

    @LcpNcpMaxNak.setter
    def LcpNcpMaxNak(self, Value):
        self.session.LcpNcpMaxNak = Value
        self.session.get()

    @property
    def EnableMruNegotiation(self):
        return self.session.EnableMruNegotiation

    @EnableMruNegotiation.setter
    def EnableMruNegotiation(self, Value):
        self.session.EnableMruNegotiation = Value
        self.session.get()

    @property
    def MruSize(self):
        return self.session.MruSize

    @MruSize.setter
    def MruSize(self, Value):
        self.session.MruSize = Value
        self.session.get()

    @property
    def EnableEchoRequest(self):
        return self.session.EnableEchoRequest

    @EnableEchoRequest.setter
    def EnableEchoRequest(self, Value):
        self.session.EnableEchoRequest = Value
        self.session.get()

    @property
    def EchoRequestInterval(self):
        return self.session.EchoRequestInterval

    @EchoRequestInterval.setter
    def EchoRequestInterval(self, Value):
        self.session.EchoRequestInterval = Value
        self.session.get()

    @property
    def EchoRequestMaxAttempts(self):
        return self.session.EchoRequestMaxAttempts

    @EchoRequestMaxAttempts.setter
    def EchoRequestMaxAttempts(self, Value):
        self.session.EchoRequestMaxAttempts = Value
        self.session.get()

    @property
    def EnableMagicNumber(self):
        return self.session.EnableMagicNumber

    @EnableMagicNumber.setter
    def EnableMagicNumber(self, Value):
        self.session.EnableMagicNumber = Value
        self.session.get()

    def connect(self):
        cmd = PppoeConnectCommand(PppoeBlockHandles=self.handle)
        cmd.execute()
        return True

    def disconnect(self):
        cmd = PppoeDisconnectCommand (PppoeBlockHandles=self.handle)
        cmd.execute()
        return True

    def abort(self):
        cmd = PppoeAbortCommand(PppoeBlockHandles=self.handle)
        cmd.execute()
        return True

    def create_custom_option(self, **kwargs):
        renixObject = PppoeCustomOption(upper=self.session)
        for k, v in kwargs.items():
            if hasattr(renixObject, k):
                setattr(renixObject, str(k), v)
        return renixObject

    def wait_ipcp_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'CONNECTED'
        self.wait_state(StateName='IpcpState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_ipv6cp_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'CONNECTED'
        self.wait_state(StateName='Ipv6cpState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True


class PppoeClient(Pppoe):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(Config='PppoeClientConfig', Upper=Upper, Session=Session,  **kwargs)

    @property
    def PadiTimeout(self):
        return self.session.PadiTimeout

    @PadiTimeout.setter
    def PadiTimeout(self, Value):
        self.session.PadiTimeout = Value
        self.session.get()

    @property
    def PadiMaxAttempts(self):
        return self.session.PadiMaxAttempts

    @PadiMaxAttempts.setter
    def PadiMaxAttempts(self, Value):
        self.session.PadiMaxAttempts = Value
        self.session.get()

    @property
    def PadrTimeout(self):
        return self.session.PadrTimeout

    @PadrTimeout.setter
    def PadrTimeout(self, Value):
        self.session.PadrTimeout = Value
        self.session.get()

    @property
    def PadrMaxAttempts(self):
        return self.session.PadrMaxAttempts

    @PadrMaxAttempts.setter
    def PadrMaxAttempts(self, Value):
        self.session.PadrMaxAttempts = Value
        self.session.get()

    @property
    def EnableRelayAgent(self):
        return self.session.EnableRelayAgent

    @EnableRelayAgent.setter
    def EnableRelayAgent(self, Value):
        self.session.EnableRelayAgent = Value
        self.session.get()

    @property
    def RelayAgentDestMac(self):
        return self.session.RelayAgentDestMac

    @RelayAgentDestMac.setter
    def RelayAgentDestMac(self, Value):
        self.session.RelayAgentDestMac = Value
        self.session.get()

    @property
    def RelayAgentDestMacStep(self):
        return self.session.RelayAgentDestMacStep

    @RelayAgentDestMacStep.setter
    def RelayAgentDestMacStep(self, Value):
        self.session.RelayAgentDestMacStep = Value
        self.session.get()

    @property
    def UseRelayAgentPadi(self):
        return self.session.UseRelayAgentPadi

    @UseRelayAgentPadi.setter
    def UseRelayAgentPadi(self, Value):
        self.session.UseRelayAgentPadi = Value
        self.session.get()

    @property
    def UseRelayAgentPadr(self):
        return self.session.UseRelayAgentPadr

    @UseRelayAgentPadr.setter
    def UseRelayAgentPadr(self, Value):
        self.session.UseRelayAgentPadr = Value
        self.session.get()

    @property
    def RelayAgentType(self):
        return self.session.RelayAgentType.name
    @RelayAgentType.setter
    def RelayAgentType(self, Value):
        self.session.RelayAgentType = Value
        self.session.get()

    @property
    def RelaySessionId(self):
        return self.session.RelaySessionId

    @RelaySessionId.setter
    def RelaySessionId(self, Value):
        self.session.RelaySessionId = Value
        self.session.get()

    @property
    def CircuitId(self):
        return self.session.CircuitId

    @CircuitId.setter
    def CircuitId(self, Value):
        self.session.CircuitId = Value
        self.session.get()

    @property
    def RemoteId(self):
        return self.session.RemoteId

    @RemoteId.setter
    def RemoteId(self, Value):
        self.session.RemoteId = Value
        self.session.get()

    @property
    def ChapChalReqTimeout(self):
        return self.session.ChapChalReqTimeout

    @ChapChalReqTimeout.setter
    def ChapChalReqTimeout(self, Value):
        self.session.ChapChalReqTimeout = Value
        self.session.get()

    @property
    def ChapAckTimeout(self):
        return self.session.ChapAckTimeout

    @ChapAckTimeout.setter
    def ChapAckTimeout(self, Value):
        self.session.ChapAckTimeout = Value
        self.session.get()

    @property
    def ChapMaxReplyAttempts(self):
        return self.session.ChapMaxReplyAttempts

    @ChapMaxReplyAttempts.setter
    def ChapMaxReplyAttempts(self, Value):
        self.session.ChapMaxReplyAttempts = Value
        self.session.get()

    @property
    def PapReqTimeout(self):
        return self.session.PapReqTimeout

    @PapReqTimeout.setter
    def PapReqTimeout(self, Value):
        self.session.PapReqTimeout = Value
        self.session.get()

    @property
    def PapReqMaxAttempts(self):
        return self.session.PapReqMaxAttempts

    @PapReqMaxAttempts.setter
    def PapReqMaxAttempts(self, Value):
        self.session.PapReqMaxAttempts = Value
        self.session.get()

    @property
    def EnableAutoRetry(self):
        return self.session.EnableAutoRetry

    @EnableAutoRetry.setter
    def EnableAutoRetry(self, Value):
        self.session.EnableAutoRetry = Value
        self.session.get()

    @property
    def AutoRetryCount(self):
        return self.session.AutoRetryCount

    @AutoRetryCount.setter
    def AutoRetryCount(self, Value):
        self.session.AutoRetryCount = Value
        self.session.get()

    @property
    def LcpDelay(self):
        return self.session.LcpDelay

    @LcpDelay.setter
    def LcpDelay(self, Value):
        self.session.LcpDelay = Value
        self.session.get()

    @property
    def EnableAutoFillIpv6(self):
        return self.session.EnableAutoFillIpv6

    @EnableAutoFillIpv6.setter
    def EnableAutoFillIpv6(self, Value):
        self.session.EnableAutoFillIpv6 = Value
        self.session.get()


class PppoeServer(Pppoe):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(Config='PppoeServerConfig', Upper=Upper, Session=Session,  **kwargs)

    @property
    def AcName(self):
        return self.session.AcName

    @AcName.setter
    def AcName(self, Value):
        self.session.AcName = Value
        self.session.get()

    @property
    def ChapReplyTimeout(self):
        return self.session.ChapReplyTimeout

    @ChapReplyTimeout.setter
    def ChapReplyTimeout(self, Value):
        self.session.ChapReplyTimeout = Value
        self.session.get()

    @property
    def ChapMaxChalAttempts(self):
        return self.session.ChapMaxChalAttempts

    @ChapMaxChalAttempts.setter
    def ChapMaxChalAttempts(self, Value):
        self.session.ChapMaxChalAttempts = Value
        self.session.get()

    @property
    def PapPeerReqTimeout(self):
        return self.session.PapPeerReqTimeout

    @PapPeerReqTimeout.setter
    def PapPeerReqTimeout(self, Value):
        self.session.PapPeerReqTimeout = Value
        self.session.get()

    @property
    def Ipv4Start(self):
        return self.session.Ipv4Start

    @Ipv4Start.setter
    def Ipv4Start(self, Value):
        self.session.Ipv4Start = Value
        self.session.get()

    @property
    def Ipv4Step(self):
        return self.session.Ipv4Step

    @Ipv4Step.setter
    def Ipv4Step(self, Value):
        self.session.Ipv4Step = Value
        self.session.get()

    @property
    def Ipv4Count(self):
        return self.session.Ipv4Count

    @Ipv4Count.setter
    def Ipv4Count(self, Value):
        self.session.Ipv4Count = Value
        self.session.get()

    @property
    def Ipv6InterfaceId(self):
        return self.session.Ipv6InterfaceId

    @Ipv6InterfaceId.setter
    def Ipv6InterfaceId(self, Value):
        self.session.Ipv6InterfaceId = Value
        self.session.get()

    @property
    def Ipv6InterfaceIdStep(self):
        return self.session.Ipv6InterfaceIdStep

    @Ipv6InterfaceIdStep.setter
    def Ipv6InterfaceIdStep(self, Value):
        self.session.Ipv6InterfaceIdStep = Value
        self.session.get()

    @property
    def Ipv6PrefixStart(self):
        return self.session.Ipv6PrefixStart

    @Ipv6PrefixStart.setter
    def Ipv6PrefixStart(self, Value):
        self.session.Ipv6PrefixStart = Value
        self.session.get()

    @property
    def Ipv6PrefixStep(self):
        return self.session.Ipv6PrefixStep

    @Ipv6PrefixStep.setter
    def Ipv6PrefixStep(self, Value):
        self.session.Ipv6PrefixStep = Value
        self.session.get()

    @property
    def Ipv6Count(self):
        return self.session.Ipv6Count

    @Ipv6Count.setter
    def Ipv6Count(self, Value):
        self.session.Ipv6Count = Value
        self.session.get()

    @property
    def EnableForceConnectMode(self):
        return self.session.EnableForceConnectMode

    @EnableForceConnectMode.setter
    def EnableForceConnectMode(self, Value):
        self.session.EnableForceConnectMode = Value
        self.session.get()

    @property
    def UnconnectedSessionThreshold(self):
        return self.session.UnconnectedSessionThreshold

    @UnconnectedSessionThreshold.setter
    def UnconnectedSessionThreshold(self, Value):
        self.session.UnconnectedSessionThreshold = Value
        self.session.get()

    @property
    def MAndOFlag(self):
        return self.session.MAndOFlag.name

    @MAndOFlag.setter
    def MAndOFlag(self, Value):
        self.session.MAndOFlag = Value
        self.session.get()

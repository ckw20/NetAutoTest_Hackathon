from .protocol import *


class LspPing(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='LspPingConfig', Upper=Upper, Session=Session)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def PingState(self):
        return self.session.PingState.name

    @property
    def TraceState(self):
        return self.session.TraceState.name

    def echo_request(self, **kwargs):
        config = LspPingEchoRequestConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='OperationMode', enum_=EnumOperationMode, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def fec_ldp_ipv4(EchoRequest, **kwargs):
        config = LspPingFecLdpIpv4PrefixConfig(upper=EchoRequest)
        EchoRequest.set_relatives('InnerLabel', config, EnumRelationDirection.TARGET)
        EchoRequest.edit(InnerLabel=EnumFECLabel.LDPIPv4)
        config.edit(OperationMode=EnumFECLabel.LDPIPv4)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def fec_vpn_ipv4(EchoRequest, **kwargs):
        config = LspPingFecVPNIpv4PrefixConfig(upper=EchoRequest)
        EchoRequest.set_relatives('InnerLabel', config, EnumRelationDirection.TARGET)
        EchoRequest.edit(InnerLabel=EnumFECLabel.VPNIPv4)
        config.edit(OperationMode=EnumFECLabel.VPNIPv4)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def fec_segment_routing(EchoRequest, **kwargs):
        config = LspPingFecSrConfig(upper=EchoRequest)
        EchoRequest.set_relatives('InnerLabel', config, EnumRelationDirection.TARGET)
        EchoRequest.edit(InnerLabel=EnumFECLabel.SEGMENT_ROUTING)
        config.edit(OperationMode=EnumFECLabel.SEGMENT_ROUTING)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def fec_sr_prefix(Sr, **kwargs):
        config = LspPingFecSrDetailConfig(upper=Sr)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def fec_sr_adjacency(Sr, **kwargs):
        config = LspPingFecSrDetailConfig(upper=Sr)
        config.edit(SrFecType='ADJACENCY')
        if kwargs:
            config.edit(**kwargs)
        return config

    def start_lsp_ping(self):
        LspPingStartCommand(LspPingSessionHandles=self.session.handle).execute()
        return True

    def stop_lsp_ping(self):
        LspPingStopCommand(LspPingSessionHandles=self.session.handle).execute()
        return True

    def pause_lsp_ping(self):
        LspPingPauseCommand(LspPingSessionHandles=self.session.handle).execute()
        return True

    def resume_lsp_ping(self):
        LspPingResumeCommand(LspPingSessionHandles=self.session.handle).execute()
        return True

    def pause_lsp_trace(self):
        LspTracePauseCommand(LspTraceSessionHandles=self.session.handle).execute()
        return True

    def resume_lsp_trace(self):
        LspTraceResumeCommand(LspTraceSessionHandles=self.session.handle).execute()
        return True

    def wait_lsp_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_lsp_ping_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'PAUSE_SEND'
        self.wait_state(StateName='PingState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_lsp_trace_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'PAUSE_SEND'
        self.wait_state(StateName='TraceState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

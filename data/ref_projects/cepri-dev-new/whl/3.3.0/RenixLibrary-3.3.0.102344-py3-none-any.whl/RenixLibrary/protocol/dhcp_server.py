from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *
# from RenixAPI.RenixLibrary.data import LOCAATION


class DhcpServer(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Dhcpv4ServerConfig', Upper=Upper)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def LeaseTime(self):
        return self.session.LeaseTime

    @LeaseTime.setter
    def LeaseTime(self, Value):
        self.session.LeaseTime = Value
        self.session.get()

    @property
    def RenewTime(self):
        return self.session.RenewTime

    @RenewTime.setter
    def RenewTime(self, Value):
        self.session.RenewTime = Value
        self.session.get()

    @property
    def RebindTime(self):
        return self.session.RebindTime

    @RebindTime.setter
    def RebindTime(self, Value):
        self.session.RebindTime = Value
        self.session.get()

    @property
    def MinLeaseTime(self):
        return self.session.MinLeaseTime

    @MinLeaseTime.setter
    def MinLeaseTime(self, Value):
        self.session.MinLeaseTime = Value
        self.session.get()

    @property
    def DeclineReserveTime(self):
        return self.session.DeclineReserveTime

    @DeclineReserveTime.setter
    def DeclineReserveTime(self, Value):
        self.session.DeclineReserveTime = Value
        self.session.get()

    @property
    def OfferReserveTime(self):
        return self.session.OfferReserveTime

    @OfferReserveTime.setter
    def OfferReserveTime(self, Value):
        self.session.OfferReserveTime = Value
        self.session.get()

    @property
    def ServerHostName(self):
        return self.session.ServerHostName

    @ServerHostName.setter
    def ServerHostName(self, Value):
        self.session.ServerHostName = Value
        self.session.get()

    @property
    def DuplicateAddressDetection(self):
        return self.session.DuplicateAddressDetection

    @DuplicateAddressDetection.setter
    def DuplicateAddressDetection(self, Value):
        self.session.DuplicateAddressDetection = Value
        self.session.get()

    @property
    def DuplicateAddressDetectionTimeout(self):
        return self.session.DuplicateAddressDetectionTimeout

    @DuplicateAddressDetectionTimeout.setter
    def DuplicateAddressDetectionTimeout(self, Value):
        self.session.DuplicateAddressDetectionTimeout = Value
        self.session.get()

    def abort(self):
        cmd = Dhcpv4AbortServerCommand(Dhcpv4Servers=self.handle)
        cmd.execute()
        return True

    def renew(self):
        cmd = Dhcpv4ForceRenewCommand(Dhcpv4Servers=self.handle)
        cmd.execute()
        return True

    def create_pool(self, **kwargs):
        result = Dhcpv4AddressPool(upper=self.session)
        result.edit(**kwargs)
        return result

    def create_option(self, Upper, **kwargs):
        if isinstance(Upper, DhcpServer):
            result = Dhcpv4ServerOption(upper=Upper.session)
        else:
            result = Dhcpv4ServerOption(upper=Upper)
        kwargs = self.edit_options_of_kwargs(config=result, para='MessageType',
                                             enum_=EnumDhcpv4ServerMessageType, **kwargs)
        if kwargs:
            result.edit(**kwargs)
        return result

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True



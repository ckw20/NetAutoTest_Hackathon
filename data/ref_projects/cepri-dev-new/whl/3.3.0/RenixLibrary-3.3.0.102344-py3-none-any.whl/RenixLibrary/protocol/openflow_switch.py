from .protocol import *


class OpenFlowSwitch(Protocol):

    def __init__(self, Upper, **kwargs):
        super().__init__(ClassName='OfpSwitchConfig', Upper=Upper)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def TcpPort(self):
        return self.session.TcpPort

    @TcpPort.setter
    def TcpPort(self, Value):
        self.session.TcpPort = Value
        self.session.get()

    @property
    def ConnectionType(self):
        return self.session.ConnectionType.name

    @ConnectionType.setter
    def ConnectionType(self, Value):
        self.session.ConnectionType = Value
        self.session.get()

    @property
    def EnableEchoRequest(self):
        return self.session.EnableEchoRequest

    @EnableEchoRequest.setter
    def EnableEchoRequest(self, Value):
        self.session.EnableEchoRequest = Value
        self.session.get()

    @property
    def EchoRequestInterval(self):
        return self.session.EchoRequestInterval

    @EchoRequestInterval.setter
    def EchoRequestInterval(self, Value):
        self.session.EchoRequestInterval = Value
        self.session.get()

    @property
    def OpenFlowVersion(self):
        return self.session.OpenFlowVersion

    @OpenFlowVersion.setter
    def OpenFlowVersion(self, Value):
        self.session.OpenFlowVersion = Value
        self.session.get()

    @property
    def DPID(self):
        return self.session.DPID

    @DPID.setter
    def DPID(self, Value):
        self.session.DPID = Value
        self.session.get()

    @property
    def MaxBufferedPackets(self):
        return self.session.MaxBufferedPackets

    @MaxBufferedPackets.setter
    def MaxBufferedPackets(self, Value):
        self.session.MaxBufferedPackets = Value
        self.session.get()

    @property
    def MaxTableCount(self):
        return self.session.MaxTableCount

    @MaxTableCount.setter
    def MaxTableCount(self, Value):
        self.session.MaxTableCount = Value
        self.session.get()

    @property
    def Capabilities(self):
        return self.session.Capabilities

    @Capabilities.setter
    def Capabilities(self, Value):
        self.session.Capabilities = Value
        self.session.get()

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'RUNING'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def start_vswitch(self):
        StartVSwitchCommand(VSwitchConfigs=self.session.handle).execute()
        return True

    def stop_vswitch(self):
        StopVSwitchCommand(VSwitchConfigs=self.session.handle).execute()
        return True

    def edit_switch_config(self, **kwargs):
        config = OfpSwitchDescConfig(upper=self.session)
        for k, v in kwargs.items():
            if k == 'CommandList':
                config.set_relatives('OfpGetCommandList', v, EnumRelationDirection.TARGET)
            elif k == 'FlowTable':
                config.set_relatives('OfpGetFlowTable', v, EnumRelationDirection.TARGET)
            else:
                setattr(config, k, v)
        return config

    def edit_controller_config(self, **kwargs):
        config = OfpControllerDescConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

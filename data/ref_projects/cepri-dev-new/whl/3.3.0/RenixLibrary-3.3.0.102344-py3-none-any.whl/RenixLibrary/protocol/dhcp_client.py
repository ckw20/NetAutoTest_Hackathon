from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *
# from RenixAPI.RenixLibrary.data import LOCAATION


class DhcpClient(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Dhcpv4ClientConfig', Upper=Upper)
        self.__HostInterface = ''
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def Mode(self):
        return self.session.Mode.name

    @Mode.setter
    def Mode(self, Value):
        self.session.Mode = Value
        self.session.get()

    @property
    def HostName(self):
        return self.session.HostName

    @HostName.setter
    def HostName(self, Value):
        self.session.HostName = Value
        self.session.get()

    @property
    def ParameterRequests(self):
        return self.get_options(Options=self.session.ParameterRequestList)

    @ParameterRequests.setter
    def ParameterRequests(self, Value):
        trans_value = self.transform_options(OptionsEum=EnumRequestParameter, Value=Value)
        self.session.ParameterRequestList = trans_value
        self.session.get()

    @property
    def EnableRouterOption(self):
        return self.session.EnableRouterOption

    @EnableRouterOption.setter
    def EnableRouterOption(self, Value):
        self.session.EnableRouterOption = Value
        self.session.get()

    @property
    def VendorClassIdentifier(self):
        return self.session.VendorClassIdentifier

    @VendorClassIdentifier.setter
    def VendorClassIdentifier(self, Value):
        self.session.VendorClassIdentifier = Value
        self.session.get()

    @property
    def BroadcastFlag(self):
        return self.session.BroadcastFlag.name

    @BroadcastFlag.setter
    def BroadcastFlag(self, Value):
        self.session.BroadcastFlag = Value
        self.session.get()

    @property
    def RelayAgentIp(self):
        return self.session.RelayAgentIp

    @RelayAgentIp.setter
    def RelayAgentIp(self, Value):
        self.session.RelayAgentIp = Value
        self.session.get()

    @property
    def ServerIp(self):
        return self.session.ServerIp

    @ServerIp.setter
    def ServerIp(self, Value):
        self.session.ServerIp = Value
        self.session.get()

    @property
    def EnableRelayAgentCircuitID(self):
        return self.session.EnableRelayAgentCircuitID

    @EnableRelayAgentCircuitID.setter
    def EnableRelayAgentCircuitID(self, Value):
        self.session.EnableRelayAgentCircuitID = Value
        self.session.get()

    @property
    def RelayAgentCircuitID(self):
        return self.session.RelayAgentCircuitID

    @RelayAgentCircuitID.setter
    def RelayAgentCircuitID(self, Value):
        self.session.RelayAgentCircuitID = Value
        self.session.get()

    @property
    def EnableRelayAgentRemoteID(self):
        return self.session.EnableRelayAgentRemoteID

    @EnableRelayAgentRemoteID.setter
    def EnableRelayAgentRemoteID(self, Value):
        self.session.EnableRelayAgentRemoteID = Value
        self.session.get()

    @property
    def RelayAgentRemoteID(self):
        return self.session.RelayAgentRemoteID

    @RelayAgentRemoteID.setter
    def RelayAgentRemoteID(self, Value):
        self.session.RelayAgentRemoteID = Value
        self.session.get()

    @property
    def EnableSyncAddressToInterface(self):
        return self.session.EnableSyncAddressToInterface

    @EnableSyncAddressToInterface.setter
    def EnableSyncAddressToInterface(self, Value):
        self.session.EnableSyncAddressToInterface = Value
        self.session.get()

    # fake attribute of Dhcpv6ClientConfig
    @property
    def HostInterface(self):
        return self.__HostInterface

    @HostInterface.setter
    def HostInterface(self, Interface):
        Dhcpv4SelectHostInterfaceCommand(Dhcpv4Clients=self.session.handle, InterfaceHandles=Interface.handle).execute()
        self.__HostInterface = Interface

    def bind(self):
        cmd = Dhcpv4BindCommand(Dhcpv4Clients=self.handle)
        cmd.execute()
        return True

    def abort(self):
        cmd = Dhcpv4AbortClientCommand(Dhcpv4Clients=self.handle)
        cmd.execute()
        return True

    def rebind(self):
        cmd = Dhcpv4RebindCommand(Dhcpv4Clients=self.handle)
        cmd.execute()
        return True

    def reboot(self):
        cmd = Dhcpv4RebootCommand(Dhcpv4Clients=self.handle)
        cmd.execute()
        return True

    def release(self):
        cmd = Dhcpv4ReleaseCommand(Dhcpv4Clients=self.handle)
        cmd.execute()
        return True

    def renew(self):
        cmd = Dhcpv4RenewCommand(Dhcpv4Clients=self.handle)
        cmd.execute()
        return True

    def create_option(self, **kwargs):
        result = Dhcpv4ClientOption(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=result, para='MessageType',
                                             enum_=EnumDhcpv4ClientMessageType, **kwargs)
        if kwargs:
            result.edit(**kwargs)
        return result

    def edit_option(self, index, **kwargs):
        result = self.session.get_children('Dhcpv4ClientOption')[index]
        result.edit(**kwargs)
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'BOUND'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True



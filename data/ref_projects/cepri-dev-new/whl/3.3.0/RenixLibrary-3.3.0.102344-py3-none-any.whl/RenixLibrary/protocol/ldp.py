from .protocol import *


class Ldp(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='LdpProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def Version(self):
        return self.session.LdpVersion.name

    @property
    def LabelSpaceId(self):
        return self.session.LabelSpaceId

    @property
    def Ipv4EgressLspCount(self):
        return self.session.Ipv4EgressLspCount

    @property
    def Ipv4IngressLspCount(self):
        return self.session.Ipv4IngressLspCount

    @property
    def Fec128LspCount(self):
        return self.session.Fec128LspCount

    @property
    def Fec129LspCount(self):
        return self.session.Fec129LspCount

    @property
    def HelloType(self):
        return self.session.HelloType.name

    @HelloType.setter
    def HelloType(self, Value):
        self.session.HelloType = Value
        self.session.get()

    @property
    def HelloAddressType(self):
        return self.session.HelloAddressType.name

    @HelloAddressType.setter
    def HelloAddressType(self, Value):
        self.session.HelloAddressType = Value
        self.session.get()

    @property
    def LabelAdvertType(self):
        return self.session.LabelAdvertType.name

    @LabelAdvertType.setter
    def LabelAdvertType(self, Value):
        self.session.LabelAdvertType = Value
        self.session.get()

    @property
    def TransportMode(self):
        return self.session.TransportMode.name

    @TransportMode.setter
    def TransportMode(self, Value):
        self.session.TransportMode = Value
        self.session.get()

    @property
    def DutIpv4Address(self):
        return self.session.DutIpv4Address

    @DutIpv4Address.setter
    def DutIpv4Address(self, Value):
        self.session.DutIpv4Address = Value
        self.session.get()

    @property
    def DirectHelloInterval(self):
        return self.session.DirectHelloInterval

    @DirectHelloInterval.setter
    def DirectHelloInterval(self, Value):
        self.session.DirectHelloInterval = Value
        self.session.get()

    @property
    def TargetedHelloInterval(self):
        return self.session.TargetedHelloInterval

    @TargetedHelloInterval.setter
    def TargetedHelloInterval(self, Value):
        self.session.TargetedHelloInterval = Value
        self.session.get()

    @property
    def KeepAliveInterval(self):
        return self.session.KeepAliveInterval

    @KeepAliveInterval.setter
    def KeepAliveInterval(self, Value):
        self.session.KeepAliveInterval = Value
        self.session.get()

    @property
    def LabelReqRetryCount(self):
        return self.session.LabelReqRetryCount

    @LabelReqRetryCount.setter
    def LabelReqRetryCount(self, Value):
        self.session.LabelReqRetryCount = Value
        self.session.get()

    @property
    def LabelReqRetryInterval(self):
        return self.session.LabelReqRetryInterval

    @LabelReqRetryInterval.setter
    def LabelReqRetryInterval(self, Value):
        self.session.LabelReqRetryInterval = Value
        self.session.get()

    @property
    def Authentication(self):
        return self.session.Authentication.name

    @Authentication.setter
    def Authentication(self, Value):
        self.session.Authentication = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def EgressLabel(self):
        return self.session.EgressLabel.name

    @EgressLabel.setter
    def EgressLabel(self, Value):
        self.session.EgressLabel = Value
        self.session.get()

    @property
    def MinLabel(self):
        return self.session.MinLabel

    @MinLabel.setter
    def MinLabel(self, Value):
        self.session.MinLabel = Value
        self.session.get()

    @property
    def EnableLspResult(self):
        return self.session.EnableLspResult

    @EnableLspResult.setter
    def EnableLspResult(self, Value):
        self.session.EnableLspResult = Value
        self.session.get()

    @property
    def EnablePseudowireLspResult(self):
        return self.session.EnablePseudowireLspResult

    @EnablePseudowireLspResult.setter
    def EnablePseudowireLspResult(self, Value):
        self.session.EnablePseudowireLspResult = Value
        self.session.get()

    @property
    def LspBindMode(self):
        return self.session.LspBindMode.name

    @LspBindMode.setter
    def LspBindMode(self, Value):
        self.session.LspBindMode = Value
        self.session.get()

    @property
    def VcLspBindMode(self):
        return self.session.VcLspBindMode.name

    @VcLspBindMode.setter
    def VcLspBindMode(self, Value):
        self.session.VcLspBindMode = Value
        self.session.get()

    @property
    def GeneralizedLspBindMode(self):
        return self.session.GeneralizedLspBindMode.name

    @GeneralizedLspBindMode.setter
    def GeneralizedLspBindMode(self, Value):
        self.session.GeneralizedLspBindMode = Value
        self.session.get()

    def create_ipv4_egress(self, **kwargs):
        config = LdpIpv4EgressLspConfig(upper=self.session, **kwargs)
        return config

    def create_ipv4_ingress(self, **kwargs):
        config = LdpIpv4IngressLspConfig(upper=self.session, **kwargs)
        return config

    def create_fec_128(self, **kwargs):
        config = LdpFec128LspConfig(upper=self.session)
        if 'PwStatusCode' in kwargs.keys():
            Value = kwargs['PwStatusCode']
            kwargs.pop('PwStatusCode')
            Value = self.transform_options(OptionsEum=EnumPwStatusCode, Value=Value)
            config.edit(PwStatusCode=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_fec_129(self, **kwargs):
        config = LdpFec129LspConfig(upper=self.session)
        if 'PwStatusCode' in kwargs.keys():
            Value = kwargs['PwStatusCode']
            kwargs.pop('PwStatusCode')
            Value = self.transform_options(OptionsEum=EnumPwStatusCode, Value=Value)
            config.edit(PwStatusCode=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'OPERATIONAL'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def establish(self):
        cmd = LdpEstablishCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

    def stop_hello(self):
        cmd = LdpStopHellosCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

    def stop_keepalive(self):
        cmd = LdpStopKeepaliveCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

    def resume_hello(self):
        cmd = LdpResumeHellosCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

    def resume_keepalive(self):
        cmd = LdpResumeKeepaliveCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

    def restart(self):
        cmd = LdpRestartCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

    @staticmethod
    def request_label(Configs):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        cmd = LdpRequestLabelCommand(LdpLspConfigs=[x.handle for x in Configs])
        cmd.execute()
        return True

    @staticmethod
    def abort_request_label(Configs):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        cmd = LdpAbortRequestCommand(LdpLspConfigs=[x.handle for x in Configs])
        cmd.execute()
        return True

    @staticmethod
    def withdraw_lsp(Configs):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        cmd = LdpWithdrawLspsCommand(LdpLspConfigs=[x.handle for x in Configs])
        cmd.execute()
        return True

    @staticmethod
    def advertise_lsp(Configs):
        if not isinstance(Configs, (list, set, tuple)):
            Configs = [Configs]
        cmd = LdpReAdvertiseLspCommand(LdpLspConfigs=[x.handle for x in Configs])
        cmd.execute()
        return True

    def start_ldp(self):
        cmd = LdpStartCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

    def stop_ldp(self):
        cmd = LdpStopCommand(LdpSessionHandles=self.handle)
        cmd.execute()
        return True

from .protocol import *


class Ovsdb(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='OvsdbProtocolConfig', Upper=Upper, Session=Session)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def OvsdbState(self):
        return self.session.OvsdbState.name

    @property
    def OvsdbControllerIpList(self):
        return self.session.OvsdbControllerIpList

    @OvsdbControllerIpList.setter
    def OvsdbControllerIpList(self, Value):
        self.session.OvsdbControllerIpList = Value
        self.session.get()

    @property
    def OvsdbContents(self):
        return self.session.OvsdbContents

    @OvsdbContents.setter
    def OvsdbContents(self, Value):
        self.session.OvsdbContents = Value
        self.session.get()

    @staticmethod
    def edit_ovsdb_table(**kwargs):
        config = get_sys_entry().get_children('OvsdbTableContentsConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def edit_ovsdb_export(**kwargs):
        config = get_sys_entry().get_children('OvsdbExportContentsConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def upload_ca_certificate(Ports, LocalPath, Files):
        if not isinstance(Ports, list):
            Ports = [Ports]
        if not isinstance(Files, list):
            Files = [Files]
        UploadCaCertificateCommand(PortHandles=[i.handle for i in Ports],
                                   LocalPath=LocalPath,
                                   Files=Files).execute()
        return True

    @staticmethod
    def upload_certificate(Ports, LocalPath, Files):
        if not isinstance(Ports, list):
            Ports = [Ports]
        if not isinstance(Files, list):
            Files = [Files]
        UploadCertificateCommand(PortHandles=[i.handle for i in Ports],
                                 LocalPath=LocalPath,
                                 Files=Files).execute()
        return True

    @staticmethod
    def upload_private_key(Ports, LocalPath, Files):
        if not isinstance(Ports, list):
            Ports = [Ports]
        if not isinstance(Files, list):
            Files = [Files]
        UploadPrivateKeyCommand(PortHandles=[i.handle for i in Ports],
                                LocalPath=LocalPath,
                                Files=Files).execute()
        return True

    @staticmethod
    def refresh_files(Ports):
        if not isinstance(Ports, list):
            Ports = [Ports]
        RefreshFilesCommand(PortHandles=[i.handle for i in Ports]).execute()
        return True

    @staticmethod
    def delete_certificate(Ports, Files):
        if not isinstance(Ports, list):
            Ports = [Ports]
        if not isinstance(Files, list):
            Files = [Files]
        DeleteCertsCommand(PortHandles=[i.handle for i in Ports],
                           Files=Files).execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'STARTED'
        self.wait_state(StateName='OvsdbState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @staticmethod
    def edit_port_config(Port, **kwargs):
        config = Port.get_children('OvsdbPortConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def start_refresh_table(self):
        OvsdbStartRefreshTableCommand(OvsdbHandle=[self.handle]).execute()
        return True

    def stop_refresh_table(self):
        OvsdbStopRefreshTableCommand(OvsdbHandle=[self.handle]).execute()
        return True

    def query_db(self, **kwargs):
        OvsdbQueryDbCommand(**kwargs).execute()
        return True

    def query_db_oneshot(self, **kwargs):
        OvsdbQueryDbOneShotCommand(**kwargs).execute()
        return True

    def query_db_period(self, **kwargs):
        OvsdbQueryDbPeriodCommand(**kwargs).execute()
        return True

    def stop_query_db_period(self, **kwargs):
        OvsdbStopQueryDbPeriodCommand(**kwargs).execute()
        return True

    def export_contents(self):
        OvsdbExportContentsCommand(OvsdbHandle=[self.handle]).execute()
        return True




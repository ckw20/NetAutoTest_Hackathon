from .protocol import *


class Twamp(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='TwampProtocolConfig', Upper=Upper, Session=Session)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def ActiveClient(self):
        return self.session.ActiveClient

    @ActiveClient.setter
    def ActiveClient(self, Value):
        self.session.ActiveClient = Value
        self.session.get()

    @property
    def ActiveServer(self):
        return self.session.ActiveServer

    @ActiveServer.setter
    def ActiveServer(self, Value):
        self.session.ActiveServer = Value
        self.session.get()

    @property
    def State(self):
        return self.session.State.name

    @property
    def IpLayerVersion(self):
        return self.session.IpLayerVersion.name

    @IpLayerVersion.setter
    def IpLayerVersion(self, Value):
        self.session.IpLayerVersion = Value
        self.session.get()

    @property
    def EnableLight(self):
        return self.session.EnableLight

    @EnableLight.setter
    def EnableLight(self, Value):
        self.session.EnableLight = Value
        self.session.get()

    @property
    def Ipv6AddressType(self):
        return self.session.Ipv6AddressType.name

    @Ipv6AddressType.setter
    def Ipv6AddressType(self, Value):
        self.session.Ipv6AddressType = Value
        self.session.get()

    @property
    def ScalabilityMode(self):
        return self.session.ScalabilityMode.name

    @ScalabilityMode.setter
    def ScalabilityMode(self, Value):
        self.session.ScalabilityMode = Value
        self.session.get()

    @property
    def PeerIpv4Address(self):
        return self.session.PeerIpv4Address

    @PeerIpv4Address.setter
    def PeerIpv4Address(self, Value):
        self.session.PeerIpv4Address = Value
        self.session.get()

    @property
    def PeerIpv6Address(self):
        return self.session.PeerIpv6Address

    @PeerIpv6Address.setter
    def PeerIpv6Address(self, Value):
        self.session.PeerIpv6Address = Value
        self.session.get()

    @property
    def ConnectionRetryInterval(self):
        return self.session.ConnectionRetryInterval

    @ConnectionRetryInterval.setter
    def ConnectionRetryInterval(self, Value):
        self.session.ConnectionRetryInterval = Value
        self.session.get()

    @property
    def ConnectionRetryCount(self):
        return self.session.ConnectionRetryCount

    @ConnectionRetryCount.setter
    def ConnectionRetryCount(self, Value):
        self.session.ConnectionRetryCount = Value
        self.session.get()

    @property
    def WillingToParticipate(self):
        return self.session.WillingToParticipate

    @WillingToParticipate.setter
    def WillingToParticipate(self, Value):
        self.session.WillingToParticipate = Value
        self.session.get()

    @property
    def Mode(self):
        return self.get_options(self.session.Mode)

    @Mode.setter
    def Mode(self, Value):
        value = self.transform_options(EnumSecurityMode, Value)
        self.session.Mode = value
        self.session.get()

    @property
    def LocalUdpPorts(self):
        return self.session.LocalUdpPorts

    @LocalUdpPorts.setter
    def LocalUdpPorts(self, Value):
        self.session.LocalUdpPorts = Value
        self.session.get()

    @property
    def ServWaitTime(self):
        return self.session.ServWaitTime

    @ServWaitTime.setter
    def ServWaitTime(self, Value):
        self.session.ServWaitTime = Value
        self.session.get()

    @property
    def RefWaitTime(self):
        return self.session.RefWaitTime

    @RefWaitTime.setter
    def RefWaitTime(self, Value):
        self.session.RefWaitTime = Value
        self.session.get()

    def wait_twamp_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'ESTABLISHED'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def edit_test_session(self, **kwargs):
        config = TwampTestSessionConfig(upper=self.session, **kwargs)
        return config

    def start_twamp(self):
        StartTwampCommand(TwampConfigs=self.session.handle).execute()
        return True

    def stop_twamp(self):
        StopTwampCommand(TwampConfigs=self.session.handle).execute()
        return True

    def start_session(self, TestSessions, **kwargs):
        TwampStartSessionCommand(TwampConfigs=[self.session.handle],
                                 SessionHandles=[i.handle for i in TestSessions], **kwargs).execute()
        return True

    def stop_session(self, TestSessions, **kwargs):
        TwampStopSessionCommand(TwampConfigs=self.session.handle,
                                SessionHandles=[i.handle for i in TestSessions], **kwargs).execute()
        return True

    def request_session(self, TestSessions, **kwargs):
        TwampRequestSessionCommand(TwampConfigs=self.session.handle,
                                   SessionHandles=[i.handle for i in TestSessions], **kwargs).execute()
        return True

    def pause_session(self, TestSessions, **kwargs):
        TwampPauseSessionCommand(TwampConfigs=self.session.handle,
                                 SessionHandles=[i.handle for i in TestSessions], **kwargs).execute()
        return True

    def resume_session(self, TestSessions, **kwargs):
        TwampResumeSessionCommand(TwampConfigs=self.session.handle,
                                  SessionHandles=[i.handle for i in TestSessions], **kwargs).execute()
        return True

import time

from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class PimRouter(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='PimProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def state(self):
        return self.session.State

    @property
    def DrAddr(self):
        return self.session.DrAddr

    @property
    def DrIpv6Addr(self):
        return self.session.DrIpv6Addr

    @property
    def BsrState(self):
        return self.session.BsrState

    @property
    def RegisterState(self):
        return self.session.RegisterState

    @property
    def SessionMode(self):
        return self.session.SessionMode

    @SessionMode.setter
    def SessionMode(self, Value):
        self.session.SessionMode = Value
        self.session.get()

    @property
    def IpVersion(self):
        return self.session.IpVersion

    @IpVersion.setter
    def IpVersion(self, Value):
        self.session.IpVersion = Value
        self.session.get()

    @property
    def DrPriority(self):
        return self.session.DrPriority

    @DrPriority.setter
    def DrPriority(self, Value):
        self.session.DrPriority = Value
        self.session.get()

    @property
    def GenIdMode(self):
        return self.session.GenIdMode

    @GenIdMode.setter
    def GenIdMode(self, Value):
        self.session.GenIdMode = Value
        self.session.get()

    @property
    def RegisterEnable(self):
        return self.session.RegisterEnable

    @RegisterEnable.setter
    def RegisterEnable(self, Value):
        self.session.RegisterEnable = Value
        self.session.get()

    @property
    def BsrEnable(self):
        return self.session.BsrEnable

    @BsrEnable.setter
    def BsrEnable(self, Value):
        self.session.BsrEnable = Value
        self.session.get()

    @property
    def BsrPriority(self):
        return self.session.BsrPriority

    @BsrPriority.setter
    def BsrPriority(self, Value):
        self.session.BsrPriority = Value
        self.session.get()

    @property
    def BsrInterval(self):
        return self.session.BsrInterval

    @BsrInterval.setter
    def BsrInterval(self, Value):
        self.session.BsrInterval = Value
        self.session.get()

    @property
    def HelloInterval(self):
        return self.session.HelloInterval

    @HelloInterval.setter
    def HelloInterval(self, Value):
        self.session.HelloInterval = Value
        self.session.get()

    @property
    def HelloHoldTime(self):
        return self.session.HelloHoldTime

    @HelloHoldTime.setter
    def HelloHoldTime(self, Value):
        self.session.HelloHoldTime = Value
        self.session.get()

    @property
    def JoinPruneInterval(self):
        return self.session.JoinPruneInterval

    @JoinPruneInterval.setter
    def JoinPruneInterval(self, Value):
        self.session.JoinPruneInterval = Value
        self.session.get()

    @property
    def JoinPruneHoldTime(self):
        return self.session.JoinPruneHoldTime

    @JoinPruneHoldTime.setter
    def JoinPruneHoldTime(self, Value):
        self.session.JoinPruneHoldTime = Value
        self.session.get()

    @property
    def EnableNeighborIpv6Addr(self):
        return self.session.EnableNeighborIpv6Addr

    @EnableNeighborIpv6Addr.setter
    def EnableNeighborIpv6Addr(self, Value):
        self.session.EnableNeighborIpv6Addr = Value
        self.session.get()

    @property
    def NeighborIpv6Addr(self):
        return self.session.NeighborIpv6Addr

    @NeighborIpv6Addr.setter
    def NeighborIpv6Addr(self, Value):
        self.session.NeighborIpv6Addr = Value
        self.session.get()

    def start_boot_strap(self):
        cmd = PimStartBootStrapCommand(PimConfigs=self.handle)
        cmd.execute()
        return True

    def stop_boot_strap(self):
        cmd = PimStopBootStrapCommand(PimConfigs=self.handle)
        cmd.execute()
        return True

    def change_gen_id(self):
        cmd = PimChangeGenIDCommand(PimConfigs=self.handle)
        cmd.execute()
        return True

    def join_group(self):
        cmd = PimJoinGroupCommand(PimConfigs=self.handle)
        cmd.execute()
        return True

    def leave_group(self):
        cmd = PimLeaveGroupCommand(PimConfigs=self.handle)
        cmd.execute()
        return True

    def start_register(self):
        cmd = PimStartRegisterCommand(PimConfigs=self.handle)
        cmd.execute()
        return True

    def stop_register(self):
        cmd = PimStopRegisterCommand(PimConfigs=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'NEIGHBOR'
        self.wait_state(StateName='state', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def create_group(self, **kwargs):
        config = PimGroupConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv6_group(self, **kwargs):
        config = PimIpv6GroupConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_register_group(self, **kwargs):
        config = PimRegisterGroupConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv6_register_group(self, **kwargs):
        config = PimIpv6RegisterGroupConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_rp_map(self, **kwargs):
        config = PimRpMapConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv6_rp_map(self, **kwargs):
        config = PimIpv6RpMapConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config


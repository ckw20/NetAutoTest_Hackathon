from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *

class RipRouter(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='RipProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def ProtocolState(self):
        return self.session.ProtocolState.name

    @property
    def Version(self):
        return self.session.Version.name

    @Version.setter
    def Version(self, Value):
        self.session.Version = Value
        self.session.get()

    @property
    def UpdateType(self):
        return self.session.UpdateType.name

    @UpdateType.setter
    def UpdateType(self, Value):
        self.session.UpdateType = Value
        self.session.get()

    @property
    def DutIpv4Address(self):
        return self.session.DutIpv4Address

    @DutIpv4Address.setter
    def DutIpv4Address(self, Value):
        self.session.DutIpv4Address = Value
        self.session.get()

    @property
    def DutIpv6Address(self):
        return self.session.DutIpv6Address

    @DutIpv6Address.setter
    def DutIpv6Address(self, Value):
        self.session.DutIpv6Address = Value
        self.session.get()

    @property
    def AuthMethod(self):
        return self.session.AuthMethod.name

    @AuthMethod.setter
    def AuthMethod(self, Value):
        self.session.AuthMethod = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def Md5KeyId(self):
        return self.session.Md5KeyId

    @Md5KeyId.setter
    def Md5KeyId(self, Value):
        self.session.Md5KeyId = Value
        self.session.get()

    @property
    def UpdateInterval(self):
        return self.session.UpdateInterval

    @UpdateInterval.setter
    def UpdateInterval(self, Value):
        self.session.UpdateInterval = Value
        self.session.get()

    @property
    def UpdateJitter(self):
        return self.session.UpdateJitter

    @UpdateJitter.setter
    def UpdateJitter(self, Value):
        self.session.UpdateJitter = Value
        self.session.get()

    @property
    def MaxRoutePerUpdate(self):
        return self.session.MaxRoutePerUpdate

    @MaxRoutePerUpdate.setter
    def MaxRoutePerUpdate(self, Value):
        self.session.MaxRoutePerUpdate = Value
        self.session.get()

    @property
    def SplitHorizon(self):
        return self.session.SplitHorizon

    @SplitHorizon.setter
    def SplitHorizon(self, Value):
        self.session.SplitHorizon = Value
        self.session.get()

    @property
    def EnableViewRoutes(self):
        return self.session.EnableViewRoutes

    @EnableViewRoutes.setter
    def EnableViewRoutes(self, Value):
        self.session.EnableViewRoutes = Value
        self.session.get()

    @property
    def EnableIpAddrValidation(self):
        return self.session.EnableIpAddrValidation

    @EnableIpAddrValidation.setter
    def EnableIpAddrValidation(self, Value):
        self.session.EnableIpAddrValidation = Value
        self.session.get()

    @property
    def Ipv4RouteCount(self):
        return self.session.Ipv4RouteCount

    @property
    def Ipv6RouteCount(self):
        return self.session.Ipv6RouteCount

    def create_ipv4_route(self, **kwargs):
        config = RipIpv4RouteConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv6_route(self, **kwargs):
        config = RipIpv6RouteConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    @property
    def RipIpv4Route(self):
        return self.session.get_children('RipIpv4RouteConfig')

    @property
    def RipIpv6Route(self):
        return self.session.get_children('RipIpv6RouteConfig')

    def advertise(self):
        cmd = RipAdvertiseCommand(RipConfigs=self.handle)
        cmd.execute()
        return True

    def withdraw(self):
        cmd = RipWithdrawCommand(RipConfigs=self.handle)
        cmd.execute()
        return True

    def suspend(self):
        cmd = RipSuspendCommand(RipConfigs=self.handle)
        cmd.execute()
        return True

    def resume(self):
        cmd = RipResumeCommand(RipConfigs=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'OPEN'
        self.wait_state(StateName='ProtocolState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True




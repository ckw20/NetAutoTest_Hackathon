import time

from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class Saa(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='SaaProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def Mode(self):
        return self.session.Mode.name

    @Mode.setter
    def Mode(self, Value):
        self.session.Mode = Value
        self.session.get()

    @property
    def State(self):
        return self.session.State.name

    @property
    def Flags(self):
        return self.get_options(Options=self.session.Flags)

    @Flags.setter
    def Flags(self, Value):
        Value = self.transform_options(OptionsEum=EnumSaaRAFlags, Value=Value)
        self.session.Flags = Value
        self.session.get()

    @property
    def RouterLifetime(self):
        return self.session.RouterLifetime

    @RouterLifetime.setter
    def RouterLifetime(self, Value):
        self.session.RouterLifetime = Value
        self.session.get()

    @property
    def EnableDAD(self):
        return self.session.EnableDAD

    @EnableDAD.setter
    def EnableDAD(self, Value):
        self.session.EnableDAD = Value
        self.session.get()

    @property
    def DADTransmitCount(self):
        return self.session.DADTransmitCount

    @DADTransmitCount.setter
    def DADTransmitCount(self, Value):
        self.session.DADTransmitCount = Value
        self.session.get()

    @property
    def DADRetransmitDelay(self):
        return self.session.DADRetransmitDelay

    @DADRetransmitDelay.setter
    def DADRetransmitDelay(self, Value):
        self.session.DADRetransmitDelay = Value
        self.session.get()

    @property
    def RouterSolicitationRetries(self):
        return self.session.RouterSolicitationRetries

    @RouterSolicitationRetries.setter
    def RouterSolicitationRetries(self, Value):
        self.session.RouterSolicitationRetries = Value
        self.session.get()

    @property
    def RouterSolicitationRetransmitDelay(self):
        return self.session.RouterSolicitationRetransmitDelay

    @RouterSolicitationRetransmitDelay.setter
    def RouterSolicitationRetransmitDelay(self, Value):
        self.session.RouterSolicitationRetransmitDelay = Value
        self.session.get()

    @property
    def EnableEui64LinkLocal(self):
        return self.session.EnableEui64LinkLocal

    @EnableEui64LinkLocal.setter
    def EnableEui64LinkLocal(self, Value):
        self.session.EnableEui64LinkLocal = Value
        self.session.get()

    @property
    def EnableSendRA(self):
        return self.session.EnableSendRA

    @EnableSendRA.setter
    def EnableSendRA(self, Value):
        self.session.EnableSendRA = Value
        self.session.get()

    @property
    def MaxInterval(self):
        return self.session.MaxInterval

    @MaxInterval.setter
    def MaxInterval(self, Value):
        self.session.MaxInterval = Value
        self.session.get()

    @property
    def MinInterval(self):
        return self.session.MinInterval

    @MinInterval.setter
    def MinInterval(self, Value):
        self.session.MinInterval = Value
        self.session.get()

    @property
    def Ipv6EnableGatewayLearn(self):
        return self.session.Ipv6EnableGatewayLearn

    @Ipv6EnableGatewayLearn.setter
    def Ipv6EnableGatewayLearn(self, Value):
        self.session.Ipv6EnableGatewayLearn = Value
        self.session.get()

    @property
    def DefaultNoAdvertise(self):
        return self.session.DefaultNoAdvertise

    @DefaultNoAdvertise.setter
    def DefaultNoAdvertise(self, Value):
        self.session.DefaultNoAdvertise = Value
        self.session.get()

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'IDLE'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

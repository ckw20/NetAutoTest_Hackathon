from .protocol import *


class Dot3ah(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Dot3ahProtocolConfig', Upper=Upper, Session=Session)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def MaxPduSize(self):
        return self.session.MaxPduSize

    @MaxPduSize.setter
    def MaxPduSize(self, Value):
        self.session.MaxPduSize = Value
        self.session.get()

    @property
    def TransmitType(self):
        return self.session.TransmitType.name

    @TransmitType.setter
    def TransmitType(self, Value):
        self.session.TransmitType = Value
        self.session.get()

    @property
    def LoopBackRespTime(self):
        return self.session.LoopBackRespTime

    @LoopBackRespTime.setter
    def LoopBackRespTime(self, Value):
        self.session.LoopBackRespTime = Value
        self.session.get()

    @property
    def EnableLinkFault(self):
        return self.session.EnableLinkFault

    @EnableLinkFault.setter
    def EnableLinkFault(self, Value):
        self.session.EnableLinkFault = Value
        self.session.get()

    @property
    def EnableDyingGasp(self):
        return self.session.EnableDyingGasp

    @EnableDyingGasp.setter
    def EnableDyingGasp(self, Value):
        self.session.EnableDyingGasp = Value
        self.session.get()

    @property
    def EnableCriticalEvent(self):
        return self.session.EnableCriticalEvent

    @EnableCriticalEvent.setter
    def EnableCriticalEvent(self, Value):
        self.session.EnableCriticalEvent = Value
        self.session.get()

    @property
    def EnableLoopBackResp(self):
        return self.session.EnableLoopBackResp

    @EnableLoopBackResp.setter
    def EnableLoopBackResp(self, Value):
        self.session.EnableLoopBackResp = Value
        self.session.get()

    @property
    def EnableVarResp(self):
        return self.session.EnableVarResp

    @EnableVarResp.setter
    def EnableVarResp(self, Value):
        self.session.EnableVarResp = Value
        self.session.get()

    @property
    def VarReqPeriod(self):
        return self.session.VarReqPeriod

    @VarReqPeriod.setter
    def VarReqPeriod(self, Value):
        self.session.VarReqPeriod = Value
        self.session.get()

    def edit_event_notification(self, **kwargs):
        config = self.session.get_children('Dot3ahEventNotificationConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def edit_info_pdu(self, **kwargs):
        config = self.session.get_children('Dot3ahInfoPduConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def edit_org_spec(self, **kwargs):
        config = self.session.get_children('Dot3ahOrgSpecConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_org_spec_tlv(self, **kwargs):
        config = Dot3ahOrgSpecTlvConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_var_req(self, **kwargs):
        config = Dot3ahVarReqConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_var_resp(self, **kwargs):
        config = Dot3ahVarRespConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def start_event_notification(self):
        cmd = Dot3ahStartEventNotificationCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def start_link_trace(self):
        cmd = Dot3ahStartLinkTraceCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def start_loopback(self):
        cmd = Dot3ahStartLoopBackCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def start_org_spec(self):
        cmd = Dot3ahStartOrgSpecCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def start_var_req(self):
        cmd = Dot3ahStartVarReqCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def stop_event_notification(self):
        cmd = Dot3ahStopEventNotificationCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def stop_link_trace(self):
        cmd = Dot3ahStopLinkTraceCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def stop_loopback(self):
        cmd = Dot3ahStopLoopBackCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def stop_org_spec(self):
        cmd = Dot3ahStopOrgSpecCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def stop_var_req(self):
        cmd = Dot3ahStopVarReqCommand(Dot3ahConfigs=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'Completed'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

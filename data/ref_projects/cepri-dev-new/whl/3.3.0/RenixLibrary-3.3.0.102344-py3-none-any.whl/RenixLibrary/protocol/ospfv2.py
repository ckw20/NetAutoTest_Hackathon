import time

from .protocol import *
# from RenixAPI.RenixLibrary.protocol.protocol import *


class OspfRouter(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Ospfv2ProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def Enable(self):
        return self.session.EnableOspfv2

    @Enable.setter
    def Enable(self, Value):
        self.session.EnableOspfv2 = Value
        self.session.get()

    @property
    def State(self):
        return self.session.RouterState.name

    @property
    def AdjacencyStatus(self):
        return self.session.AdjacencyStatus.name

    @property
    def lsa(self):
        return self.router_lsa + self.network_lsa + self.summary_lsa + self.asbr_summary_lsa + self.external_lsa + \
               self.te_lsa + self.opaque_route_info_lsa + self.opaque_extended_prefix_lsa + self.opaque_extended_link_lsa

    @property
    def router_lsa(self):
        return self.session.get_children('Ospfv2RouterLsaConfig')

    @property
    def network_lsa(self):
        return self.session.get_children('Ospfv2NetworkLsaConfig')

    @property
    def summary_lsa(self):
        return self.session.get_children('Ospfv2SummaryLsaConfig')

    @property
    def asbr_summary_lsa(self):
        return self.session.get_children('Ospfv2AsbrSummaryLsaConfig')

    @property
    def external_lsa(self):
        return self.session.get_children('Ospfv2ExternalLsaConfig')

    @property
    def te_lsa(self):
        return self.session.get_children('Ospfv2TeLsaConfig')

    @property
    def opaque_route_info_lsa(self):
        return self.session.get_children('Ospfv2OpaqueRouterInfoLsaConfig')

    @property
    def opaque_extended_prefix_lsa(self):
        return self.session.get_children('Ospfv2OpaqueSrExtPrefixLsaConfig')

    @property
    def opaque_extended_link_lsa(self):
        return self.session.get_children('Ospfv2OpaqueSrExtLinkLsaConfig')

    def count(self, *args):
        result = {}
        for k in args:
            result.update({k: getattr(self.session, str(k))})
        return result

    @property
    def AreaId(self):
        return self.session.AreaId

    @AreaId.setter
    def AreaId(self, Value):
        self.session.AreaId = Value
        self.session.get()

    @property
    def EnableBfd(self):
        return self.session.EnableBfd

    @EnableBfd.setter
    def EnableBfd(self, Value):
        self.session.EnableBfd = Value
        self.session.get()

    @property
    def NetworkType(self):
        return self.session.NetworkType.name

    @NetworkType.setter
    def NetworkType(self, Value):
        self.session.NetworkType = Value
        self.session.get()

    @property
    def Priority(self):
        return self.session.Priority

    @Priority.setter
    def Priority(self, Value):
        self.session.Priority = Value
        self.session.get()

    @property
    def Cost(self):
        return self.session.InterfaceCost

    @Cost.setter
    def Cost(self, Value):
        self.session.InterfaceCost = Value
        self.session.get()

    @property
    def AuthenticationType(self):
        return self.session.AuthenticationType.name

    @AuthenticationType.setter
    def AuthenticationType(self, Value):
        self.session.AuthenticationType = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def Md5KeyId(self):
        return self.session.Md5KeyId

    @Md5KeyId.setter
    def Md5KeyId(self, Value):
        self.session.Md5KeyId = Value
        self.session.get()

    @property
    def Options(self):
        return self.get_options(Options=self.session.Options)

    @Options.setter
    def Options(self, Value):
        Value = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Value)
        self.session.Options = Value
        self.session.get()

    @property
    def EnableOspfv2Mtu(self):
        return self.session.EnableOspfv2Mtu

    @EnableOspfv2Mtu.setter
    def EnableOspfv2Mtu(self, Value):
        self.session.EnableOspfv2Mtu = Value
        self.session.get()

    @property
    def EnableGracefulRestart(self):
        return self.session.EnableGracefulRestart

    @EnableGracefulRestart.setter
    def EnableGracefulRestart(self, Value):
        self.session.EnableGracefulRestart = Value
        self.session.get()

    @property
    def GracefulRestartReason(self):
        return self.session.GracefulRestartReason.name

    @GracefulRestartReason.setter
    def GracefulRestartReason(self, Value):
        self.session.GracefulRestartReason = Value
        self.session.get()

    @property
    def EnableViewRoutes(self):
        return self.session.EnableViewRoutes

    @EnableViewRoutes.setter
    def EnableViewRoutes(self, Value):
        self.session.EnableViewRoutes = Value
        self.session.get()

    @property
    def HelloInterval(self):
        return self.session.HelloInterval

    @HelloInterval.setter
    def HelloInterval(self, Value):
        self.session.HelloInterval = Value
        self.session.get()

    @property
    def RouterDeadInterval(self):
        return self.session.RouterDeadInterval

    @RouterDeadInterval.setter
    def RouterDeadInterval(self, Value):
        self.session.RouterDeadInterval = Value
        self.session.get()

    @property
    def LsaRetransInterval(self):
        return self.session.LsaRetransInterval

    @LsaRetransInterval.setter
    def LsaRetransInterval(self, Value):
        self.session.LsaRetransInterval = Value
        self.session.get()

    @property
    def LsaRefreshTime(self):
        return self.session.LsaRefreshTime

    @LsaRefreshTime.setter
    def LsaRefreshTime(self, Value):
        self.session.LsaRefreshTime = Value
        self.session.get()

    @property
    def EnableSrManagement(self):
        return self.session.EnableSrManagement

    @EnableSrManagement.setter
    def EnableSrManagement(self, Value):
        self.session.EnableSrManagement = Value
        self.session.get()

    @classmethod
    def edit_lsa(cls, Lsa, **kwargs):
        Lsa.edit(**kwargs)
        return True

    def create_router_lsa(self, **kwargs):
        config = Ospfv2RouterLsaConfig(upper=self.session)
        if 'RouterType' in kwargs.keys():
            Value = kwargs['RouterType']
            kwargs.pop('RouterType')
            Value = self.transform_options(OptionsEum=EnumOspfv2RouterType, Value=Value)
            config.edit(RouterType=Value)
        if 'Options' in kwargs.keys():
            Value = kwargs['Options']
            kwargs.pop('Options')
            Value = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Value)
            config.edit(Options=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_router_ls_link(cls, RouterLsa, **kwargs):
        config = Ospfv2RouterLsaLinksConfig(upper=RouterLsa)
        if 'LinkType' in kwargs.keys():
            Value = kwargs['LinkType']
            kwargs.pop('LinkType')
            Value = cls.transform_options(OptionsEum=EnumRouterLsaLinkType, Value=Value)
            config.edit(LinkType=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_network_lsa(self, **kwargs):
        config = Ospfv2NetworkLsaConfig(upper=self.session)
        if 'Options' in kwargs.keys():
            Value = kwargs['Options']
            kwargs.pop('Options')
            Value = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Value)
            config.edit(Options=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_network_atch_router(NetworkLsa, **kwargs):
        config = Ospfv2NetworkAtchRouterConfig(upper=NetworkLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_summary_lsa(self, **kwargs):
        config = Ospfv2SummaryLsaConfig(upper=self.session)
        if 'Options' in kwargs.keys():
            Value = kwargs['Options']
            kwargs.pop('Options')
            Value = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Value)
            config.edit(Options=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_asbr_summary_lsa(self, **kwargs):
        config = Ospfv2AsbrSummaryLsaConfig(upper=self.session)
        if 'MetricType' in kwargs.keys():
            Value = kwargs['MetricType']
            kwargs.pop('MetricType')
            Value = self.transform_options(OptionsEum=EnumExtLsaLsMetricType, Value=Value)
            config.edit(MetricType=Value)
        if 'Options' in kwargs.keys():
            Value = kwargs['Options']
            kwargs.pop('Options')
            Value = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Value)
            config.edit(Options=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_external_lsa(self, **kwargs):
        config = Ospfv2ExternalLsaConfig(upper=self.session)
        if 'LsType' in kwargs.keys():
            Value = kwargs['LsType']
            kwargs.pop('LsType')
            Value = self.transform_options(OptionsEum=EnumExtLsaLsType, Value=Value)
            config.edit(LsType=Value)
        if 'MetricType' in kwargs.keys():
            Value = kwargs['MetricType']
            kwargs.pop('MetricType')
            Value = self.transform_options(OptionsEum=EnumExtLsaLsMetricType, Value=Value)
            config.edit(MetricType=Value)
        if 'Options' in kwargs.keys():
            Value = kwargs['Options']
            kwargs.pop('Options')
            Value = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Value)
            config.edit(Options=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_te_lsa(self, **kwargs):
        config = Ospfv2TeLsaConfig(upper=self.session)
        if 'Options' in kwargs.keys():
            Value = kwargs['Options']
            kwargs.pop('Options')
            Value = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Value)
            config.edit(Options=Value)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def edit_te_lsa_link(Lsa, **kwargs):
        if isinstance(Lsa, (list, set, tuple)):
            Lsa = Lsa[0]
        config = Lsa.get_children('Ospfv2TeLinkConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_opaque_router_info_lsa(self, **kwargs):
        config = Ospfv2OpaqueRouterInfoLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='Options', enum_=EnumOspfv2OptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_sr_algorithm_tlv(OpaqueRouterInfoLsa, **kwargs):
        config = Ospfv2SrAlgorithmTlvConfig(upper=OpaqueRouterInfoLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_sr_sid_label_range_tlv(OpaqueRouterInfoLsa, **kwargs):
        config = Ospfv2SidLabelRangeTlvConfig(upper=OpaqueRouterInfoLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_sr_srms_preference_tlv(OpaqueRouterInfoLsa, **kwargs):
        config = Ospfv2SrmsPreferenceTlvConfig(upper=OpaqueRouterInfoLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_router_info_capability_tlv(OpaqueRouterInfoLsa, **kwargs):
        config = Ospfv2RouterInfoCapabilityTlvConfig(upper=OpaqueRouterInfoLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_sr_local_block_tlv(OpaqueRouterInfoLsa, **kwargs):
        config = Ospfv2SrLocalBlockTlvConfig(upper=OpaqueRouterInfoLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sr_fad_tlv(self, OpaqueRouterInfoLsa, **kwargs):
        config = Ospfv2FlexAlgoDefinitionTlvConfig(upper=OpaqueRouterInfoLsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='FlexAlgoSubTlv', enum_=EnumOspfv2FlexAlgoSubTlvType, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sr_node_msd_tlv(self, OpaqueRouterInfoLsa, **kwargs):
        config = Ospfv2SrNodeMsdTlvConfig(upper=OpaqueRouterInfoLsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv2SrMsdFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_opaque_extended_prefix_lsa(self, **kwargs):
        config = Ospfv2OpaqueSrExtPrefixLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='Options', enum_=EnumOspfv2OptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ext_prefix_range_tlv(self, OpaqueExtendedPrefixLsa, **kwargs):
        config = Ospfv2ExtPrefixRangeTlvConfig(upper=OpaqueExtendedPrefixLsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedPrefixFlags', enum_=EnumOspfv2ExtendedPrefixRangeFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ext_prefix_tlv(self, OpaqueExtendedPrefixLsa, **kwargs):
        config = Ospfv2ExtPrefixTlvConfig(upper=OpaqueExtendedPrefixLsa)
        kwargs = self.edit_options_of_kwargs(config=config, para='ExtendedPrefixFlags', enum_=EnumOspfv2ExtendedPrefixFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sid_label_binding_sub_tlv(self, Tlv, **kwargs):
        config = Ospfv2SidLabelBindingSubTlvConfig(upper=Tlv)
        kwargs = self.edit_options_of_kwargs(config=config, para='SidLabelBindingTlvFlags', enum_=EnumSidLabelBindingFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_prefix_sid_sub_tlv(self, Tlv, **kwargs):
        config = Ospfv2PrefixSidSubTlvConfig(upper=Tlv)
        kwargs = self.edit_options_of_kwargs(config=config, para='PrefixSidTlvFlags', enum_=EnumOpsfv2PrefixSidTlvFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_sr_fapm_sub_tlv(Tlv, **kwargs):
        config = Ospfv2SrFapmSubTlvConfig(upper=Tlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_bier_sub_tlv(Tlv, **kwargs):
        config = Ospfv2BierSubTlvConfig(upper=Tlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_bier_mpls_encap_sub_tlv(Tlv, **kwargs):
        config = Ospfv2BierMplsEncapSubTlvConfig(upper=Tlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_opaque_extended_link_lsa(self, **kwargs):
        config = Ospfv2OpaqueSrExtLinkLsaConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='Options', enum_=EnumOspfv2OptionBit, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_extended_link_tlv(OpaqueExtendedLinkLsa, **kwargs):
        config = Ospfv2ExtendedLinkTlvConfig(upper=OpaqueExtendedLinkLsa)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_adj_sid_sub_tlv(self, ExtendedLinkTlv, **kwargs):
        config = Ospfv2AdjSidSubTlvConfig(upper=ExtendedLinkTlv)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv2ExtendedFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_lan_adj_sid_sub_tlv(self, ExtendedLinkTlv, **kwargs):
        config = Ospfv2LanSidSubTlvConfig(upper=ExtendedLinkTlv)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv2ExtendedFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sr_link_msd_sub_tlv(self, ExtendedLinkTlv, **kwargs):
        config = Ospfv2SrLinkMsdSubTlvConfig(upper=ExtendedLinkTlv)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumOspfv2SrMsdFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_custom_sub_tlv(SrLinkMsdSubTlv, **kwargs):
        config = Ospfv2CustomMsdSubTlvConfig(upper=SrLinkMsdSubTlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    def advertise(self, Type=None, Lsa=None):
        ospfv2LsaConfigs = []
        if Type is None:
            if Lsa:
                if not isinstance(Lsa, (list, set, tuple)):
                    Lsa = [Lsa]
                ospfv2LsaConfigs = [x.handle for x in Lsa]
            else:
                ospfv2LsaConfigs = [x.handle for x in self.lsa]
        elif Type.lower() == "router":
            ospfv2LsaConfigs = [x.handle for x in self.router_lsa]
        elif Type.lower() == "network":
            ospfv2LsaConfigs = [x.handle for x in self.network_lsa]
        elif Type.lower() == "summary":
            ospfv2LsaConfigs = [x.handle for x in self.summary_lsa]
        elif Type.lower() == "asbrsummary":
            ospfv2LsaConfigs = [x.handle for x in self.asbr_summary_lsa]
        elif Type.lower() == "external":
            ospfv2LsaConfigs = [x.handle for x in self.external_lsa]
        elif Type.lower() == "te":
            ospfv2LsaConfigs = [x.handle for x in self.te_lsa]
        elif Type.lower() == "opaquerouterinfo":
            ospfv2LsaConfigs = [x.handle for x in self.opaque_route_info_lsa]
        elif Type.lower() == "opaqueextendedprefix":
            ospfv2LsaConfigs = [x.handle for x in self.opaque_extended_prefix_lsa]
        elif Type.lower() == "opaqueextendedlink":
            ospfv2LsaConfigs = [x.handle for x in self.opaque_extended_link_lsa]
        cmd = Ospfv2AdvertiseCommand(Ospfv2LsaConfigs=ospfv2LsaConfigs)
        cmd.execute()
        return True

    def withdraw(self, Type=None, Lsa=None):
        ospfv2LsaConfigs = []
        if Type is None:
            if Lsa:
                if not isinstance(Lsa, (list, set, tuple)):
                    Lsa = [Lsa]
                ospfv2LsaConfigs = [x.handle for x in Lsa]
            else:
                ospfv2LsaConfigs = [x.handle for x in self.lsa]
        elif Type.lower() == "router":
            ospfv2LsaConfigs = [x.handle for x in self.router_lsa]
        elif Type.lower() == "network":
            ospfv2LsaConfigs = [x.handle for x in self.network_lsa]
        elif Type.lower() == "summary":
            ospfv2LsaConfigs = [x.handle for x in self.summary_lsa]
        elif Type.lower() == "asbrsummary":
            ospfv2LsaConfigs = [x.handle for x in self.asbr_summary_lsa]
        elif Type.lower() == "external":
            ospfv2LsaConfigs = [x.handle for x in self.external_lsa]
        elif Type.lower() == "te":
            ospfv2LsaConfigs = [x.handle for x in self.te_lsa]
        elif Type.lower() == "opaquerouterinfo":
            ospfv2LsaConfigs = [x.handle for x in self.opaque_route_info_lsa]
        elif Type.lower() == "opaqueextendedprefix":
            ospfv2LsaConfigs = [x.handle for x in self.opaque_extended_prefix_lsa]
        elif Type.lower() == "opaqueextendedlink":
            ospfv2LsaConfigs = [x.handle for x in self.opaque_extended_link_lsa]
        cmd = Ospfv2WithdrawCommand(Ospfv2LsaConfigs=ospfv2LsaConfigs)
        cmd.execute()
        return True

    def establish(self):
        cmd = Ospfv2EstablishCommand(Ospfv2Configs=self.handle)
        cmd.execute()
        return True

    def grace_restart(self):
        cmd = Ospfv2GraceRestartCommand(Ospfv2Configs=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['DR', 'BACKUP', 'DROTHER']
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_adjacency_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'FULL'
        self.wait_state(StateName='AdjacencyStatus', State=State, Interval=Interval, TimeOut=TimeOut)
        return True


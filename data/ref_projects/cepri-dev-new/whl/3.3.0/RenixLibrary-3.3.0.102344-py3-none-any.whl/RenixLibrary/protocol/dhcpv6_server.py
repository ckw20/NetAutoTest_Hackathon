from .protocol import *

class Dhcpv6Server(Protocol):

    def __init__(self, Upper, **kwargs):
        super(Dhcpv6Server, self).__init__(ClassName='Dhcpv6ServerConfig', Upper=Upper)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def EmulationMode(self):
        return self.session.EmulationMode.name

    @EmulationMode.setter
    def EmulationMode(self, value):
        self.session.EmulationMode = value
        self.session.get()

    @property
    def State(self):
        return self.session.ServerState.name

    @property
    def RenewalTimer(self):
        return self.session.RenewalTimer

    @RenewalTimer.setter
    def RenewalTimer(self, value):
        self.session.RenewalTimer = value
        self.session.get()

    @property
    def RebindingTimer(self):
        return self.session.RebindingTimer

    @RebindingTimer.setter
    def RebindingTimer(self, value):
        self.session.RebindingTimer = value
        self.session.get()

    @property
    def DnsList(self):
        return self.session.DnsList

    @DnsList.setter
    def DnsList(self, value):
        self.session.DnsList = value
        self.session.get()

    @property
    def EnableDelayedAuth(self):
        return self.session.EnableDelayedAuth

    @EnableDelayedAuth.setter
    def EnableDelayedAuth(self, value):
        self.session.EnableDelayedAuth = value
        self.session.get()

    @property
    def DhcpRealm(self):
        return self.session.DhcpRealm

    @DhcpRealm.setter
    def DhcpRealm(self, value):
        self.session.DhcpRealm = value
        self.session.get()

    @property
    def AuthenticationKeyId(self):
        return self.session.AuthenticationKeyId

    @AuthenticationKeyId.setter
    def AuthenticationKeyId(self, value):
        self.session.AuthenticationKeyId = value
        self.session.get()

    @property
    def AuthenticationKey(self):
        return self.session.AuthenticationKey

    @AuthenticationKey.setter
    def AuthenticationKey(self, value):
        self.session.AuthenticationKey = value
        self.session.get()

    @property
    def AuthenticationKeyType(self):
        return self.session.AuthenticationKeyType.name

    @AuthenticationKeyType.setter
    def AuthenticationKeyType(self, value):
        self.session.AuthenticationKeyType = value
        self.session.get()

    @property
    def EnabledReconfigureKey(self):
        return self.session.EnabledReconfigureKey

    @EnabledReconfigureKey.setter
    def EnabledReconfigureKey(self, value):
        self.session.EnabledReconfigureKey = value
        self.session.get()

    @property
    def ReconfigureKey(self):
        return self.session.ReconfigureKey

    @ReconfigureKey.setter
    def ReconfigureKey(self, value):
        self.session.ReconfigureKey = value
        self.session.get()

    @property
    def ReconfigureKeyType(self):
        return self.session.ReconfigureKeyType.name

    @ReconfigureKeyType.setter
    def ReconfigureKeyType(self, value):
        self.session.ReconfigureKeyType = value
        self.session.get()

    @property
    def EnabledDhcpv6Only(self):
        return self.session.EnabledDhcpv6Only

    @EnabledDhcpv6Only.setter
    def EnabledDhcpv6Only(self, value):
        self.session.EnabledDhcpv6Only = value
        self.session.get()

    @property
    def EnabledTcp(self):
        return self.session.EnabledTcp

    @EnabledTcp.setter
    def EnabledTcp(self, value):
        self.session.EnabledTcp = value
        self.session.get()

    @property
    def TcpPort(self):
        return self.session.TcpPort

    @TcpPort.setter
    def TcpPort(self, value):
        self.session.TcpPort = value
        self.session.get()

    @property
    def LeaseQueryStatusCode(self):
        return self.session.LeaseQueryStatusCode.name

    @LeaseQueryStatusCode.setter
    def LeaseQueryStatusCode(self, value):
        self.session.LeaseQueryStatusCode = value
        self.session.get()

    @property
    def BulkLeaseQueryStatusCode(self):
        return self.session.BulkLeaseQueryStatusCode.name

    @BulkLeaseQueryStatusCode.setter
    def BulkLeaseQueryStatusCode(self, value):
        self.session.BulkLeaseQueryStatusCode = value
        self.session.get()

    @property
    def ActiveLeaseQueryStatusCode(self):
        return self.session.ActiveLeaseQueryStatusCode.name

    @ActiveLeaseQueryStatusCode.setter
    def ActiveLeaseQueryStatusCode(self, value):
        self.session.ActiveLeaseQueryStatusCode = value
        self.session.get()

    @property
    def StartTlsStatusCode(self):
        return self.session.StartTlsStatusCode.name

    @StartTlsStatusCode.setter
    def StartTlsStatusCode(self, value):
        self.session.StartTlsStatusCode = value
        self.session.get()

    def abort(self):
        cmd = Dhcpv6ServerAbortCommand(Dhcpv6Servers=self.handle)
        cmd.execute()
        return True

    def rebind(self):
        cmd = Dhcpv6ServerRebindCommand(Dhcpv6Servers=self.handle)
        cmd.execute()
        return True

    def renew(self):
        cmd = Dhcpv6ServerRenewCommand(Dhcpv6Servers=self.handle)
        cmd.execute()
        return True

    def start_server(self):
        cmd = Dhcpv6StartServerCommand(Dhcpv6Servers=self.handle)
        cmd.execute()
        return True

    def stop_server(self):
        cmd = Dhcpv6StopServerCommand(Dhcpv6Servers=self.handle)
        cmd.execute()
        return True

    def address_pool(self, **kwargs):
        config = self.session.get_children('Dhcpv6AddressPoolsConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def prefix_pool(self, **kwargs):
        config = self.session.get_children('Dhcpv6PrefixPoolsConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def custom_options(self, **kwargs):
        config = Dhcpv6ServerCustomOptionsConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='IncludeMsg', enum_=EnumDhcpv6ServerIncludeMsg, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True



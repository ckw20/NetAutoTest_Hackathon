from .protocol import *


class Y1731(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Y1731ProtocolConfig', Upper=Upper, Session=Session)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def NextHop(self):
        return self.session.NextHop

    @NextHop.setter
    def NextHop(self, Value):
        self.session.NextHop = Value
        self.session.get()

    @staticmethod
    def create_meg(**kwargs):
        config = Y1731MegConfig(upper=get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_mp(self, **kwargs):
        config = Y1731MpConfig(upper=self.session)
        self.edit_mp(config, **kwargs)
        return config

    @staticmethod
    def edit_mp(Mp, **kwargs):
        for k, v in kwargs.items():
            if k == 'Meg':
                Mp.set_relatives('SelectMeg', v, EnumRelationDirection.TARGET)
            else:
                setattr(Mp, k, v)
        return True

    @classmethod
    def create_expected_mep(cls, Meg, **kwargs):
        config = Y1731ExpectedMep(upper=Meg)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_data_tlv(cls, Mp, **kwargs):
        config = Y1731DataTlv(upper=Mp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_ltm_egress_identifier_tlv(cls, Mp, **kwargs):
        config = Y1731LtmEgressIdentifierTlv(upper=Mp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_ltr_egress_identifier_tlv(cls, Mp, **kwargs):
        config = Y1731LtrEgressIdentifierTlv(upper=Mp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_organization_specific_tlv(cls, Mp, **kwargs):
        config = Y1731OrgSpecificTlv(upper=Mp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_reply_ingress_tlv(cls, Mp, **kwargs):
        config = Y1731ReplyIngressTlv(upper=Mp)
        if kwargs:
            config.edit(**kwargs)
        return config

    def transform_action_kwargs(self, **kwargs):
        for k,v in kwargs.items():
            if k == 'MepHandles':
                kwargs.pop(k)
                mep = v.handle
                kwargs.update({k: mep})
                break
        return kwargs

    def start_1dm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731Start1DmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_ais(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StartAisCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_ccm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StartCcmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_dmm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StartDmmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_lbm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StartLbmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_lck(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StartLckCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_lmm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StartLmmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_ltm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StartLtmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_1dm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731Stop1DmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_ais(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StopAisCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_ccm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StopCcmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_dmm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StopDmmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_lbm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StopLbmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_lck(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StopLckCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_lmm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StopLmmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_ltm(self, **kwargs):
        kwargs = self.transform_action_kwargs(**kwargs)
        cmd = Y1731StopLtmCommand(Y1731Configs=self.handle, **kwargs)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'RUNNING'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True


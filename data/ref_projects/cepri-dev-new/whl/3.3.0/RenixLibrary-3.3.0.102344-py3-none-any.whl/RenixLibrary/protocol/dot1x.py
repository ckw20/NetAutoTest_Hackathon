from .protocol import *


class Dot1x(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Dot1xProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def AuthMode(self):
        return self.session.AuthMode.name

    @AuthMode.setter
    def AuthMode(self, Value):
        self.session.AuthMode = Value
        self.session.get()

    @property
    def Identity(self):
        return self.session.Identity

    @Identity.setter
    def Identity(self, Value):
        self.session.Identity = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def UseAuthenticatorMac(self):
        return self.session.UseAuthenticatorMac

    @UseAuthenticatorMac.setter
    def UseAuthenticatorMac(self, Value):
        self.session.UseAuthenticatorMac = Value
        self.session.get()

    @property
    def AuthenticatorMac(self):
        return self.session.AuthenticatorMac

    @AuthenticatorMac.setter
    def AuthenticatorMac(self, Value):
        self.session.AuthenticatorMac = Value
        self.session.get()

    @property
    def RetryCount(self):
        return self.session.RetryCount

    @RetryCount.setter
    def RetryCount(self, Value):
        self.session.RetryCount = Value
        self.session.get()

    @property
    def RetryTimeout(self):
        return self.session.RetryTimeout

    @RetryTimeout.setter
    def RetryTimeout(self, Value):
        self.session.RetryTimeout = Value
        self.session.get()

    @property
    def RetransmitCount(self):
        return self.session.RetransmitCount

    @RetransmitCount.setter
    def RetransmitCount(self, Value):
        self.session.RetransmitCount = Value
        self.session.get()

    @property
    def RetransmitTimeout(self):
        return self.session.RetransmitTimeout

    @RetransmitTimeout.setter
    def RetransmitTimeout(self, Value):
        self.session.RetransmitTimeout = Value
        self.session.get()

    @property
    def SupplicantCertificateName(self):
        return self.session.SupplicantCertificateName

    @SupplicantCertificateName.setter
    def SupplicantCertificateName(self, Value):
        self.session.SupplicantCertificateName = Value
        self.session.get()

    @property
    def CertificatePassword(self):
        return self.session.CertificatePassword

    @CertificatePassword.setter
    def CertificatePassword(self, Value):
        self.session.CertificatePassword = Value
        self.session.get()

    @property
    def DuplicateUserInfoToInner(self):
        return self.session.DuplicateUserInfoToInner

    @DuplicateUserInfoToInner.setter
    def DuplicateUserInfoToInner(self, Value):
        self.session.DuplicateUserInfoToInner = Value
        self.session.get()

    @property
    def InnerIdentity(self):
        return self.session.InnerIdentity

    @InnerIdentity.setter
    def InnerIdentity(self, Value):
        self.session.InnerIdentity = Value
        self.session.get()

    @property
    def InnerPassword(self):
        return self.session.InnerPassword

    @InnerPassword.setter
    def InnerPassword(self, Value):
        self.session.InnerPassword = Value
        self.session.get()

    @property
    def InnerTunnelAuthMode(self):
        return self.session.InnerTunnelAuthMode.name

    @InnerTunnelAuthMode.setter
    def InnerTunnelAuthMode(self, Value):
        self.session.InnerTunnelAuthMode = Value
        self.session.get()

    @property
    def EnableClientCertificate(self):
        return self.session.EnableClientCertificate

    @EnableClientCertificate.setter
    def EnableClientCertificate(self, Value):
        self.session.EnableClientCertificate = Value
        self.session.get()

    def upload_certificate(self, folder):
        cmd = Dot1xUploadCertificateCommand(PortHandles=self.upper.handle, Certificates=folder)
        cmd.execute()
        return True

    def delete_certificate(self):
        cmd = Dot1xDeleteCertificateCommand(PortHandles=self.upper.handle)
        cmd.execute()
        return True

    def abort(self):
        cmd = Dot1xAbortCommand(Dot1xConfigs=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'AUTHENTICATED'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

import time

from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class Pcep(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='PcepProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    @property
    def Role(self):
        return self.session.Role.name

    @Role.setter
    def Role(self, Value):
        self.session.Role = Value
        self.session.get()

    @property
    def IpVersion(self):
        return self.session.IpVersion.name

    @IpVersion.setter
    def IpVersion(self, Value):
        self.session.IpVersion = Value
        self.session.get()

    @property
    def UseGatewayAsDutIp(self):
        return self.session.UseGatewayAsDutIp

    @UseGatewayAsDutIp.setter
    def UseGatewayAsDutIp(self, Value):
        self.session.UseGatewayAsDutIp = Value
        self.session.get()

    @property
    def SessionIpAddress(self):
        return self.session.SessionIpAddress.name

    @SessionIpAddress.setter
    def SessionIpAddress(self, Value):
        self.session.SessionIpAddress = Value
        self.session.get()

    @property
    def PeerIpv4Address(self):
        return self.session.PeerIpv4Address

    @PeerIpv4Address.setter
    def PeerIpv4Address(self, Value):
        self.session.PeerIpv4Address = Value
        self.session.get()

    @property
    def PeerIpv4AddressStep(self):
        return self.session.PeerIpv4AddressStep

    @PeerIpv4AddressStep.setter
    def PeerIpv4AddressStep(self, Value):
        self.session.PeerIpv4AddressStep = Value
        self.session.get()

    @property
    def PeerIpv6Address(self):
        return self.session.PeerIpv6Address

    @PeerIpv6Address.setter
    def PeerIpv6Address(self, Value):
        self.session.PeerIpv6Address = Value
        self.session.get()

    @property
    def PeerIpv6AddressStep(self):
        return self.session.PeerIpv6AddressStep

    @PeerIpv6AddressStep.setter
    def PeerIpv6AddressStep(self, Value):
        self.session.PeerIpv6AddressStep = Value
        self.session.get()

    @property
    def SessionInitiator(self):
        return self.session.SessionInitiator

    @SessionInitiator.setter
    def SessionInitiator(self, Value):
        self.session.SessionInitiator = Value
        self.session.get()

    @property
    def Negotiation(self):
        return self.session.Negotiation

    @Negotiation.setter
    def Negotiation(self, Value):
        self.session.Negotiation = Value
        self.session.get()

    @property
    def KeepAlive(self):
        return self.session.KeepAlive

    @KeepAlive.setter
    def KeepAlive(self, Value):
        self.session.KeepAlive = Value
        self.session.get()

    @property
    def MinKeepAlive(self):
        return self.session.MinKeepAlive

    @MinKeepAlive.setter
    def MinKeepAlive(self, Value):
        self.session.MinKeepAlive = Value
        self.session.get()

    @property
    def MaxKeepAlive(self):
        return self.session.MaxKeepAlive

    @MaxKeepAlive.setter
    def MaxKeepAlive(self, Value):
        self.session.MaxKeepAlive = Value
        self.session.get()

    @property
    def Dead(self):
        return self.session.Dead

    @Dead.setter
    def Dead(self, Value):
        self.session.Dead = Value
        self.session.get()

    @property
    def MinDeadAlive(self):
        return self.session.MinDeadAlive

    @MinDeadAlive.setter
    def MinDeadAlive(self, Value):
        self.session.MinDeadAlive = Value
        self.session.get()

    @property
    def MaxDeadAlive(self):
        return self.session.MaxDeadAlive

    @MaxDeadAlive.setter
    def MaxDeadAlive(self, Value):
        self.session.MaxDeadAlive = Value
        self.session.get()

    @property
    def EnableStatefulCapability(self):
        return self.session.EnableStatefulCapability

    @EnableStatefulCapability.setter
    def EnableStatefulCapability(self, Value):
        self.session.EnableStatefulCapability = Value
        self.session.get()

    @property
    def StatefulCapability(self):
        return self.get_options(Options=self.session.StatefulCapability)

    @StatefulCapability.setter
    def StatefulCapability(self, Value):
        Value = self.transform_options(OptionsEum=EnumPCEStatefulCapability, Value=Value)
        self.session.StatefulCapability = Value
        self.session.get()

    @property
    def EnableSegmentRoutingCapability(self):
        return self.get_options(Options=self.session.EnableSegmentRoutingCapability)

    @EnableSegmentRoutingCapability.setter
    def EnableSegmentRoutingCapability(self, Value):
        Value = self.transform_options(OptionsEum=EnumPcepStatefulCapability, Value=Value)
        self.session.EnableSegmentRoutingCapability = Value
        self.session.get()

    @property
    def PathSetupTypeList(self):
        return self.session.PathSetupTypeList

    @PathSetupTypeList.setter
    def PathSetupTypeList(self, Value):
        self.session.PathSetupTypeList = Value
        self.session.get()

    @property
    def SrCapabilityFlags(self):
        return self.get_options(Options=self.session.SrCapabilityFlags)

    @SrCapabilityFlags.setter
    def SrCapabilityFlags(self, Value):
        Value = self.transform_options(OptionsEum=EnumPcepSrCapabilityFlags, Value=Value)
        self.session.SrCapabilityFlags = Value
        self.session.get()

    @property
    def Srv6CapabilityFlags(self):
        return self.get_options(Options=self.session.Srv6CapabilityFlags)

    @Srv6CapabilityFlags.setter
    def Srv6CapabilityFlags(self, Value):
        Value = self.transform_options(OptionsEum=EnumPcepSrv6CapabilityFlags, Value=Value)
        self.session.Srv6CapabilityFlags = Value
        self.session.get()

    @property
    def MSDs(self):
        return self.get_options(Options=self.session.MSDs)

    @MSDs.setter
    def MSDs(self, Value):
        Value = self.transform_options(OptionsEum=EnumPcepMSDType, Value=Value)
        self.session.MSDs = Value
        self.session.get()

    @property
    def MaximumSidDepth(self):
        return self.session.MaximumSidDepth

    @MaximumSidDepth.setter
    def MaximumSidDepth(self, Value):
        self.session.MaximumSidDepth = Value
        self.session.get()

    @property
    def MaxSegmentsLeft(self):
        return self.session.MaxSegmentsLeft

    @MaxSegmentsLeft.setter
    def MaxSegmentsLeft(self, Value):
        self.session.MaxSegmentsLeft = Value
        self.session.get()

    @property
    def MaxEndPop(self):
        return self.session.MaxEndPop

    @MaxEndPop.setter
    def MaxEndPop(self, Value):
        self.session.MaxEndPop = Value
        self.session.get()

    @property
    def MaxHencaps(self):
        return self.session.MaxHencaps

    @MaxHencaps.setter
    def MaxHencaps(self, Value):
        self.session.MaxHencaps = Value
        self.session.get()

    @property
    def MaxEndD(self):
        return self.session.MaxEndD

    @MaxEndD.setter
    def MaxEndD(self, Value):
        self.session.MaxEndD = Value
        self.session.get()

    @property
    def EnableDbVersionTlv(self):
        return self.session.EnableDbVersionTlv

    @EnableDbVersionTlv.setter
    def EnableDbVersionTlv(self, Value):
        self.session.EnableDbVersionTlv = Value
        self.session.get()

    @property
    def LspStateDbVersion(self):
        return self.session.LspStateDbVersion

    @LspStateDbVersion.setter
    def LspStateDbVersion(self, Value):
        self.session.LspStateDbVersion = Value
        self.session.get()

    def create_pcc_lsp(self, **kwargs):
        config = PccLspConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_pce_lsp(self, **kwargs):
        config = PceLspConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    @property
    def PccLsp(self):
        return self.session.get_children('PccLspConfig')

    @property
    def PceLsp(self):
        return self.session.get_children('PceLspConfig')

    @classmethod
    def pcc_lsp_info(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PccLspInfoObjectConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pce_lsp_info(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PceLspInfoObjectConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_auto_delegation_parameters_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepAutoDelegationParametersConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_auto_request_parameters_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepAutoRequestParametersConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_auto_sync_parameters_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepAutoSyncParametersConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_auto_initiate_parameters_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepAutoInitiateParametersConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_auto_reply_parameters_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepAutoReplyParametersConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_auto_update_parameters_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepAutoUpdateParametersConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_auto_tx_parameters_config(cls, PcepAutoParametersConfig, **kwargs):
        config = PcepAutoParametersConfig.get_children('PcepAutoTxParametersConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_bw_object_config(cls, PcepLsp, **kwargs):
        config = PcepBwObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_endpoint_object_config(cls, PcepLsp, **kwargs):
        config = PcepEndPointObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_lspa_object_config(cls, PcepLsp, **kwargs):
        config = PcepLspaObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_metric_list_config(cls, PcepLsp, **kwargs):
        config = PcepMetricListConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_metric_object_config(cls, PcepLspMetricList, **kwargs):
        config = PcepMetricObjectConfig(upper=PcepLspMetricList)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_rp_object_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepRpObjectConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_no_path_object_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepNoPathObjectConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_sr_ero_object_config(cls, PcepLsp, **kwargs):
        config = PcepSrEroObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_sr_ero_sub_object_config(cls, PcepSrEroObject, **kwargs):
        config = PcepSrEroSubObjectConfig(upper=PcepSrEroObject)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_sr_rro_object_config(cls, PcepLsp, **kwargs):
        config = PcepSrRroObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_sr_rro_sub_object_config(cls, PcepSrRroObject, **kwargs):
        config = PcepSrRroSubObjectConfig(upper=PcepSrRroObject)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_srp_object_config(cls, PcepLsp, **kwargs):
        config = PcepLsp.get_children('PcepSrpObjectConfig')
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_srv6_ero_object_config(cls, PcepLsp, **kwargs):
        config = PcepSrv6EroObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_srv6_ero_sub_object_config(cls, PcepSrv6EroObject, **kwargs):
        config = PcepSrv6EroSubObjectConfig(upper=PcepSrv6EroObject)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_srv6_rro_object_config(cls, PcepLsp, **kwargs):
        config = PcepSrv6RroObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_srv6_rro_sub_object_config(cls, PcepSrv6RroObject, **kwargs):
        config = PcepSrv6RroSubObjectConfig(upper=PcepSrv6RroObject)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_xro_object_config(cls, PcepLsp, **kwargs):
        config = PcepXroObjectConfig(upper=PcepLsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def pcep_xro_sub_object_config(cls, PcepXroObject, **kwargs):
        config = PcepXroSubObjectConfig(upper=PcepXroObject)
        if kwargs:
            config.edit(**kwargs)
        return config

    def pcc_delegate_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccDelegateLspCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcc_initial_sync(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccInitialSyncCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcc_end_sync(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccEndSyncCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcc_synchronize_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccSynchronizeLspCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcc_report_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccReportLspCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcc_request_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccRequestLspCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcc_remove_delegated_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccRemoveDelegatedLspCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcc_revoke_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PccRevokeLspCommand(PccLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pce_initiate_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PceInitiateLspCommand(PceLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pce_remove_initiated_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PceRemoveInitiatedLspCommand(PceLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pce_return_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PceReturnLspCommand(PceLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pce_update_lsp(self, lsps):
        if not isinstance(lsps, list):
            lsps = [lsps]
        for lsp in lsps:
            cmd = PceUpdateLspCommand(PceLspConfigs=lsp.handle)
            cmd.execute()
        return True

    def pcep_establish(self):
        cmd = PcepEstablishCommand(PcepSessionHandles=self.handle)
        cmd.execute()
        return True

    def pcep_resume_keep_alive(self):
        cmd = PcepResumeKeepaliveCommand(PcepSessionHandles=self.handle)
        cmd.execute()
        return True

    def pcep_stop_keep_alive(self):
        cmd = PcepStopKeepaliveCommand(PcepSessionHandles=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

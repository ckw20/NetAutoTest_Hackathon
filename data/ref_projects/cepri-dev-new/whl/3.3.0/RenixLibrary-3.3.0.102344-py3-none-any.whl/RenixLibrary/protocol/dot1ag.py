from .protocol import *


class Dot1ag(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='Dot1agProtocolConfig', Upper=Upper, Session=Session)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.State.name

    def edit_link_trace(self, **kwargs):
        config = self.session.get_children('Dot1agLinkTraceConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def edit_loopback(self, **kwargs):
        config = self.session.get_children('Dot1agLoopBackConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_ma(**kwargs):
        config = Dot1agMaConfig(upper=get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_mp(self, **kwargs):
        config = Dot1agMpConfig(upper=self.session)
        if kwargs:
            if 'SelectMa' in list(kwargs.keys()):
                config.set_relatives('SelectMa', kwargs['SelectMa'], EnumRelationDirection.TARGET)
                kwargs.pop('SelectMa')
            config.edit(**kwargs)
        return config

    def create_org_specific_tlv(self, **kwargs):
        config = Dot1agOrgSpecificTlv(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_custom_mp(cls, **kwargs):
        config = Dot1agCustomMpConfig(upper=get_sys_entry())
        if kwargs:
            config.edit(**kwargs)
        return config

    @staticmethod
    def create_expected_mp(Ma, **kwargs):
        config = Dot1agExpectedMpConfig(upper=Ma)
        if kwargs:
            config.edit(**kwargs)
        return config

    def start_cc(self):
        cmd = Dot1agStartCCCommand(Dot1agConfigs=self.handle)
        cmd.execute()
        return True

    def start_link_trace(self, **kwargs):
        cmd = Dot1agStartLinkTraceCommand(Dot1agConfigs=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_loopback(self, **kwargs):
        cmd = Dot1agStartLoopBackCommand(Dot1agConfigs=self.handle, **kwargs)
        cmd.execute()
        return True

    def stop_cc(self):
        cmd = Dot1agStopCCCommand(Dot1agConfigs=self.handle)
        cmd.execute()
        return True

    def stop_link_trace(self, Mps):
        # cmd = Dot1agStopLinkTraceCommand(Dot1agConfigs=self.handle, MpHandleList=' '.join([x.handle for x in Mps]))
        cmd = Dot1agStopLinkTraceCommand(Dot1agConfigs=self.handle, MpHandleList=[x.handle for x in Mps])
        cmd.execute()
        return True

    def stop_loopback(self, Mps):
        cmd = Dot1agStopLoopBackCommand(Dot1agConfigs=self.handle, MpHandleList=[x.handle for x in Mps])
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'RUNNING'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

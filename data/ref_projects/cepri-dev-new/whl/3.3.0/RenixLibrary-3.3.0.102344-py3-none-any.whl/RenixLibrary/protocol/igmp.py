from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class Igmp(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='IgmpProtocolConfig', Upper=Upper, Session=Session)
        params = kwargs.copy()
        for k, v in kwargs.items():
            if hasattr(self, k):
                params.pop(k)
                setattr(self, str(k), v)
        for k, v in params.items():
            if hasattr(self.session, k):
                setattr(self.session, str(k), v)

    @property
    def State(self):
        return self.session.IgmpHostState.name

    @property
    def GroupCount(self):
        return self.session.IgmpGroupCount

    @property
    def SourceCount(self):
        return self.session.IgmpSourceCount

    @property
    def Version(self):
        return self.session.IgmpMulticastVersion

    @Version.setter
    def Version(self, Value):
        self.session.IgmpMulticastVersion = Value
        self.session.get()

    @property
    def PackReports(self):
        return self.session.IgmpPackReports

    @PackReports.setter
    def PackReports(self, Value):
        self.session.IgmpPackReports = Value
        self.session.get()

    @property
    def InitialJoin(self):
        return self.session.IgmpForceSingleInitialJoin

    @InitialJoin.setter
    def InitialJoin(self, Value):
        self.session.IgmpForceSingleInitialJoin = Value
        self.session.get()

    @property
    def RobustJoin(self):
        return self.session.IgmpForceRobustJoin

    @RobustJoin.setter
    def RobustJoin(self, Value):
        self.session.IgmpForceRobustJoin = Value
        self.session.get()

    @property
    def RobustnessVariable(self):
        return self.session.IgmpRobustnessVariable

    @RobustnessVariable.setter
    def RobustnessVariable(self, Value):
        self.session.IgmpRobustnessVariable = Value
        self.session.get()

    @property
    def UnsolicitedReportInterval(self):
        return self.session.IgmpUnsolicitedReportInterval

    @UnsolicitedReportInterval.setter
    def UnsolicitedReportInterval(self, Value):
        self.session.IgmpUnsolicitedReportInterval = Value
        self.session.get()

    @property
    def ForceLeave(self):
        return self.session.IgmpForceLeave

    @ForceLeave.setter
    def ForceLeave(self, Value):
        self.session.IgmpForceLeave = Value
        self.session.get()

    @property
    def RouterPresentTimeout(self):
        return self.session.Igmpv1RouterPresentTimeout

    @RouterPresentTimeout.setter
    def RouterPresentTimeout(self, Value):
        self.session.Igmpv1RouterPresentTimeout = Value
        self.session.get()

    @property
    def NotFragment(self):
        return self.session.IgmpIPv4DoNotFragment

    @NotFragment.setter
    def NotFragment(self, Value):
        self.session.IgmpIPv4DoNotFragment = Value
        self.session.get()

    @property
    def TosValue(self):
        return self.session.IgmpIPv4TosValue

    @TosValue.setter
    def TosValue(self, Value):
        self.session.IgmpIPv4TosValue = Value
        self.session.get()

    def send_leave(self):
        cmd = IgmpSendLeaveCommand(IgmpConfigs=self.handle)
        cmd.execute()
        return True

    def send_report(self):
        cmd = IgmpSendReportCommand(IgmpConfigs=self.handle)
        cmd.execute()
        return True

    def resend_report(self):
        cmd = IgmpResendReportCommand(IgmpConfigs=self.handle)
        cmd.execute()
        return True

    @staticmethod
    def apply():
        cmd = IgmpApplyCommand()
        cmd.execute()
        return True

    def create_memberships(self, **kwargs):
        param = {
            'numberofgroups': 'IgmpNumberOfGroups',
            'devicegroupmapping': 'IgmpDeviceGroupMapping',
            'sourcefiltermode': 'IgmpSourceFilterMode',
            'filternumberofsources': 'IgmpFilterNumberOfSources',
            'userdefinedsources': 'IgmpUserDefinedSources',
            'specifysourcesaslist': 'IgmpSpecifySourcesAsList',
            'sourceaddresslist': 'IgmpSourceAddressList',
            'numberofsources': 'IgmpNumberOfSources',
            'startingsourceip': 'IgmpStartingSourceIp',
            'prefixlength': 'IgmpPrefixLength',
            'increment': 'IgmpIncrement',
            'sourcecount': 'SourceCount',
        }
        params, temp_dict = self.transform_kwargs(kwargs, map_dict=param)
        config = IgmpMembershipsConfig(upper=self.session)
        if temp_dict:
            config.edit(**temp_dict)
        if params:
            config.edit(**params)
        return config

    @property
    def memberships(self):
        return self.session.get_children('IgmpMembershipsConfig')

    @staticmethod
    def binding_multicast_group(Memberships, MulticastGroup):
        cmd = IgmpSelectMulticastGroupCommand(IgmpMemberships=Memberships.handle,
                                              IgmpMulticastGroup=MulticastGroup.handle)
        cmd.execute()
        return True

    @staticmethod
    def select_source_interface(Memberships, Interface):
        if not isinstance(Memberships, list):
            Memberships = [Memberships]
        if isinstance(Interface, list):
            Interface = Interface[0]
        cmd = IgmpSelectSourceFilterCommand(IgmpMemberships=[x.handle for x in Memberships],
                                            IgmpSourceFilter=Interface.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'MEMBER'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True


class IgmpQuerier(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='IgmpQuerierProtocolConfig', Upper=Upper, Session=Session)
        params = kwargs.copy()
        for k, v in kwargs.items():
            if hasattr(self, k):
                params.pop(k)
                setattr(self, str(k), v)
        for k, v in params.items():
            if hasattr(self.session, k):
                setattr(self.session, str(k), v)

    @property
    def State(self):
        return self.session.RouterState.name

    @property
    def Version(self):
        return self.session.QuerierVersion.name

    @Version.setter
    def Version(self, Value):
        self.session.QuerierVersion = Value
        self.session.get()

    @property
    def RobustnessVariable(self):
        return self.session.RobustnessVariable

    @RobustnessVariable.setter
    def RobustnessVariable(self, Value):
        self.session.RobustnessVariable = Value
        self.session.get()

    @property
    def Interval(self):
        return self.session.QueryInterval

    @Interval.setter
    def Interval(self, Value):
        self.session.QueryInterval = Value
        self.session.get()

    @property
    def ResponseInterval(self):
        return self.session.QueryResponseInterval

    @ResponseInterval.setter
    def ResponseInterval(self, Value):
        self.session.QueryResponseInterval = Value
        self.session.get()

    @property
    def StartupQueryCount(self):
        return self.session.StartupQueryCount

    @StartupQueryCount.setter
    def StartupQueryCount(self, Value):
        self.session.StartupQueryCount = Value
        self.session.get()

    @property
    def LastMemberQueryInterval(self):
        return self.session.LastMemberQueryInterval

    @LastMemberQueryInterval.setter
    def LastMemberQueryInterval(self, Value):
        self.session.LastMemberQueryInterval = Value
        self.session.get()

    @property
    def LastMemberQueryCount(self):
        return self.session.LastMemberQueryCount

    @LastMemberQueryCount.setter
    def LastMemberQueryCount(self, Value):
        self.session.LastMemberQueryCount = Value
        self.session.get()

    @property
    def IPv4DoNotFragment(self):
        return self.session.IPv4DoNotFragment

    @IPv4DoNotFragment.setter
    def IPv4DoNotFragment(self, Value):
        self.session.IPv4DoNotFragment = Value
        self.session.get()

    @property
    def IPv4TosValue(self):
        return self.session.IPv4TosValue

    @IPv4TosValue.setter
    def IPv4TosValue(self, Value):
        self.session.IPv4TosValue = Value
        self.session.get()

    @staticmethod
    def apply():
        IgmpQuerierApplyCommand().execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

from renix_py_api.renix import *

LOCAATION = ['//10.0.11.191/1/3', '//10.0.11.191/1/4']


class Protocol:

    def __init__(self, ClassName, Upper, Session=None):
        self.__upper = Upper
        if Session is None:
            self.__session = self._create_session(ClassName=ClassName, Upper=Upper)
        else:
            self.__session = Session
        self.__handle = self.__session.handle
        self.__interface = None
        self.__sysEntry = get_sys_entry()
        from RenixLibrary.data import MAP_HANDLE_OBJECT
        MAP_HANDLE_OBJECT.update({self.__handle: self})

    @property
    def upper(self):
        return self.__upper

    @property
    def handle(self):
        return self.__handle

    @property
    def session(self):
        return self.__session

    @property
    def sys_entry(self):
        self.__sysEntry.get()
        return self.__sysEntry

    @property
    def Name(self):
        return self.session.Name

    @Name.setter
    def Name(self, Value):
        self.session.Name = Value
        self.session.get()

    @property
    def Enable(self):
        return self.session.Enable

    @Enable.setter
    def Enable(self, Value):
        self.session.Enable = Value
        self.session.get()

    @property
    def interface(self):
        return self.__interface

    @interface.setter
    def interface(self, Value):
        cmd = SelectInterfaceCommand(ProtocolList=self.__session.handle, InterfaceList=Value.handle)
        cmd.execute()
        self.__session.get()

    def delete(self):
        self.__session.delete()
        del self

    def start(self):
        StartProtocolCommand(ProtocolList=self.handle).execute()

    def stop(self):
        StopProtocolCommand(ProtocolList=self.handle).execute()

    def get(self):
        self.__session.get()

    def get_children(self, relative_name=None):
        return self.__session.get_children(relative_name=relative_name)

    def get_parent(self):
        return self.__session.get_parent()

    def get_relatives(self, relation_name, direction=EnumRelationDirection.TARGET, relative_name=None):
        return self.__session.get_relatives(self, relation_name=relation_name, direction=direction, relative_name=relative_name)

    @staticmethod
    def _create_session(ClassName, Upper):
        objClass = globals()[ClassName](upper=Upper)
        return objClass

    @staticmethod
    def get_options(Options):
        Options = str(Options).split('.')
        Options = Options[1].split('|')
        return Options

    @staticmethod
    def transform_options(OptionsEum, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        value = [OptionsEum[x].value for x in Value]
        value = int(sum(value))
        return value

    @staticmethod
    def transform_attribute(AttributeValue):
        # 将字符串:50000102030405转成列表[50, 00, 01, 02, 03, 04, 05]
        return [int("0x" + AttributeValue[i:i + 2], 16) for i in range(0, len(AttributeValue), 2)]

    @staticmethod
    def protocol_action(self, base):
        def action(command):
            cmd = eval(f'{command}({base}="{self.handle}")')
            cmd.execute()
            return True

        return action

    @staticmethod
    def transform_kwargs(param, map_dict):
        kwargs_dict = param.copy()
        temp_dict = {}
        for k, v in param.items():
            if k.lower() in set(map_dict.keys()):
                temp_dict.update({map_dict[k.lower()]: v})
                kwargs_dict.pop(k)
        return kwargs_dict, temp_dict

    def edit_options_of_kwargs(self, config, para, enum_, **kwargs):
        if para in kwargs.keys():
            value = kwargs[para]
            kwargs.pop(para)
            trans_value = self.transform_options(OptionsEum=enum_, Value=value)
            setattr(config, para, trans_value)
        return kwargs

    def wait_state(self, StateName, State=None, Interval=1, TimeOut=60):
        flag = True
        while flag:
            TimeOut = TimeOut - Interval
            state = getattr(self, StateName)
            if not isinstance(state, str):
                state = state.name
            if TimeOut == 0:
                flag = False
                break
            else:
                if State is None:
                    if state in State:
                        break
                else:
                    if not isinstance(State, list):
                        State = [State]
                    if state in State:
                        break
            time.sleep(Interval)
        return flag

from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *

class BfdRouter(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='BfdProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def RouterRole(self):
        return self.session.RouterRole.name

    @RouterRole.setter
    def RouterRole(self, Value):
        self.session.RouterRole = Value
        self.session.get()

    @property
    def ProtocolState(self):
        return self.session.ProtocolState.name

    @property
    def BFDSessionUpCount(self):
        return self.session.BFDSessionUpCount

    @property
    def BFDSessionDownCount(self):
        return self.session.BFDSessionDownCount

    @property
    def TimeIntervalUnit(self):
        return self.session.TimeIntervalUnit.name

    @TimeIntervalUnit.setter
    def TimeIntervalUnit(self, Value):
        self.session.TimeIntervalUnit = Value
        self.session.get()

    @property
    def DesiredMinTXInterval(self):
        return self.session.DesiredMinTXInterval

    @DesiredMinTXInterval.setter
    def DesiredMinTXInterval(self, Value):
        self.session.DesiredMinTXInterval = Value
        self.session.get()

    @property
    def RequiredMinRXInterval(self):
        return self.session.RequiredMinRXInterval

    @RequiredMinRXInterval.setter
    def RequiredMinRXInterval(self, Value):
        self.session.RequiredMinRXInterval = Value
        self.session.get()

    @property
    def RequiredMinEchoRXInterval(self):
        return self.session.RequiredMinEchoRXInterval

    @RequiredMinEchoRXInterval.setter
    def RequiredMinEchoRXInterval(self, Value):
        self.session.RequiredMinEchoRXInterval = Value
        self.session.get()

    @property
    def DetectMultiple(self):
        return self.session.DetectMultiple

    @DetectMultiple.setter
    def DetectMultiple(self, Value):
        self.session.DetectMultiple = Value
        self.session.get()

    @property
    def AuthenticationType(self):
        return self.session.AuthenticationType.name

    @AuthenticationType.setter
    def AuthenticationType(self, Value):
        self.session.AuthenticationType = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def KeyID(self):
        return self.session.KeyID

    @KeyID.setter
    def KeyID(self, Value):
        self.session.KeyID = Value
        self.session.get()

    @property
    def ProtocolDependentSession(self):
        return self.session.ProtocolDependentSession.name

    @property
    def Ipv4ControlPlaneIndependentSessionCount(self):
        return self.session.Ipv4ControlPlaneIndependentSessionCount

    @property
    def Ipv6ControlPlaneIndependentSessionCount(self):
        return self.session.Ipv6ControlPlaneIndependentSessionCount

    def create_ipv4_session(self, **kwargs):
        config = BfdIpv4SessionConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_ipv6_session(self, **kwargs):
        config = BfdIpv6SessionConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    @property
    def BfdIpv4Session(self):
        return self.session.get_children('BfdIpv4SessionConfig')

    @property
    def BfdIpv6Session(self):
        return self.session.get_children('BfdIpv6SessionConfig')

    def admin_down(self):
        cmd = BfdAdminDownCommand(BfdProtocolConfigs=self.handle)
        cmd.execute()
        return True

    def admin_up(self):
        cmd = BfdAdminUpCommand(BfdProtocolConfigs=self.handle)
        cmd.execute()
        return True

    def enable_demand_mode(self):
        cmd = BfdEnableDemandModeCommand(BfdProtocolConfigs=self.handle)
        cmd.execute()
        return True

    def disable_demand_mode(self):
        cmd = BfdDisableDemandModeCommand(BfdProtocolConfigs=self.handle)
        cmd.execute()
        return True

    def initiate_poll(self):
        cmd = BfdInitiatePollCommand(BfdProtocolConfigs=self.handle)
        cmd.execute()
        return True

    def resume_pdus(self):
        cmd = BfdResumePDUsCommand(BfdProtocolConfigs=self.handle)
        cmd.execute()
        return True

    def set_diagnostic_state(self, State):
        cmd = BfdSetDiagnosticStateCommand(BfdProtocolConfigs=self.handle, DiagnosticState=State)
        cmd.execute()
        return True

    def stop_pdus(self):
        cmd = BfdStopPDUsCommand(BfdProtocolConfigs=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'RUNNING'
        self.wait_state(StateName='ProtocolState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

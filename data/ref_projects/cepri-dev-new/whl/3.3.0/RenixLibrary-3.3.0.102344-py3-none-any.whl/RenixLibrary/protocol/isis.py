from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class IsisRouter(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='IsisProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.RouterState.name

    @property
    def ThreeWayP2pAdjState(self):
        return self.session.ThreeWayP2pAdjState.name

    @property
    def L1BroadcastAdjState(self):
        return self.session.L1BroadcastAdjState.name

    @property
    def L2BroadcastAdjState(self):
        return self.session.L2BroadcastAdjState.name

    @property
    def L1BroadcastLanId(self):
        return self.session.L1BroadcastLanId

    @property
    def L2BroadcastLanId(self):
        return self.session.L2BroadcastLanId

    @property
    def SystemIdLearned(self):
        return self.session.SystemIdLearned

    @property
    def CircuitIdLearned(self):
        return self.session.CircuitIdLearned

    @property
    def IpVersion(self):
        return self.session.IpVersion.name

    @IpVersion.setter
    def IpVersion(self, Value):
        self.session.IpVersion = Value
        self.session.get()

    @property
    def Level(self):
        return self.session.Level.name

    @Level.setter
    def Level(self, Value):
        self.session.Level = Value
        self.session.get()

    @property
    def NetworkType(self):
        return self.session.NetworkType.name

    @NetworkType.setter
    def NetworkType(self, Value):
        self.session.NetworkType = Value
        self.session.get()

    @property
    def SystemId(self):
        return self.session.SystemId

    @SystemId.setter
    def SystemId(self, Value):
        self.session.SystemId = Value
        self.session.get()

    @property
    def Priority(self):
        return self.session.Priority

    @Priority.setter
    def Priority(self, Value):
        self.session.Priority = Value
        self.session.get()

    @property
    def AuthMethod(self):
        return self.session.AuthMethod.name

    @AuthMethod.setter
    def AuthMethod(self, Value):
        self.session.AuthMethod = Value
        self.session.get()

    @property
    def Password(self):
        return self.session.Password

    @Password.setter
    def Password(self, Value):
        self.session.Password = Value
        self.session.get()

    @property
    def AuthSendOnly(self):
        return self.session.AuthSendOnly

    @AuthSendOnly.setter
    def AuthSendOnly(self, Value):
        self.session.AuthSendOnly = Value
        self.session.get()

    @property
    def HostName(self):
        return self.session.HostName

    @HostName.setter
    def HostName(self, Value):
        self.session.HostName = Value
        self.session.get()

    @property
    def CircuitId(self):
        return self.session.CircuitId

    @CircuitId.setter
    def CircuitId(self, Value):
        self.session.CircuitId = Value
        self.session.get()

    @property
    def Area1(self):
        return self.session.Area1

    @Area1.setter
    def Area1(self, Value):
        self.session.Area1 = Value
        self.session.get()

    @property
    def Area2(self):
        return self.session.Area2

    @Area2.setter
    def Area2(self, Value):
        self.session.Area2 = Value
        self.session.get()

    @property
    def Area3(self):
        return self.session.Area3

    @Area3.setter
    def Area3(self, Value):
        self.session.Area3 = Value
        self.session.get()

    @property
    def MetricMode(self):
        return self.session.MetricMode.name

    @MetricMode.setter
    def MetricMode(self, Value):
        self.session.MetricMode = Value
        self.session.get()

    @property
    def TeRouterId(self):
        return self.session.TeRouterId

    @TeRouterId.setter
    def TeRouterId(self, Value):
        self.session.TeRouterId = Value
        self.session.get()

    @property
    def TeRouterIdIpv6(self):
        return self.session.TeRouterIdIpv6

    @TeRouterIdIpv6.setter
    def TeRouterIdIpv6(self, Value):
        self.session.TeRouterIdIpv6 = Value
        self.session.get()

    @property
    def HelloInterval(self):
        return self.session.HelloInterval

    @HelloInterval.setter
    def HelloInterval(self, Value):
        self.session.HelloInterval = Value
        self.session.get()

    @property
    def HelloMultiplier(self):
        return self.session.HelloMultiplier

    @HelloMultiplier.setter
    def HelloMultiplier(self, Value):
        self.session.HelloMultiplier = Value
        self.session.get()

    @property
    def PsnInterval(self):
        return self.session.PsnInterval

    @PsnInterval.setter
    def PsnInterval(self, Value):
        self.session.PsnInterval = Value
        self.session.get()

    @property
    def LspRefreshTime(self):
        return self.session.LspRefreshTime

    @LspRefreshTime.setter
    def LspRefreshTime(self, Value):
        self.session.LspRefreshTime = Value
        self.session.get()

    @property
    def RetransInterval(self):
        return self.session.RetransInterval

    @RetransInterval.setter
    def RetransInterval(self, Value):
        self.session.RetransInterval = Value
        self.session.get()

    @property
    def HelloPadding(self):
        return self.session.HelloPadding

    @HelloPadding.setter
    def HelloPadding(self, Value):
        self.session.HelloPadding = Value
        self.session.get()

    @property
    def LspSize(self):
        return self.session.LspSize

    @LspSize.setter
    def LspSize(self, Value):
        self.session.LspSize = Value
        self.session.get()

    @property
    def ValidateIpAddr(self):
        return self.session.ValidateIpAddr

    @ValidateIpAddr.setter
    def ValidateIpAddr(self, Value):
        self.session.ValidateIpAddr = Value
        self.session.get()

    @property
    def EnableGracefulRestart(self):
        return self.session.EnableGracefulRestart

    @EnableGracefulRestart.setter
    def EnableGracefulRestart(self, Value):
        self.session.EnableGracefulRestart = Value
        self.session.get()

    @property
    def LspCount(self):
        return self.session.LspCount

    @LspCount.setter
    def LspCount(self, Value):
        self.session.LspCount = Value
        self.session.get()

    @property
    def EnableViewRoutes(self):
        return self.session.EnableViewRoutes

    @EnableViewRoutes.setter
    def EnableViewRoutes(self, Value):
        self.session.EnableViewRoutes = Value
        self.session.get()

    @property
    def EnableBFD(self):
        return self.session.EnableBFD

    @EnableBFD.setter
    def EnableBFD(self, Value):
        self.session.EnableBFD = Value
        self.session.get()

    @property
    def PerPduAuthentication(self):
        MTConfig = self.session.get_children('IsisMTConfig')
        return len(MTConfig)

    @PerPduAuthentication.setter
    def PerPduAuthentication(self, Value):
        if int(Value) > 4:
            raise ValueError('PerPduAuthentication should not be greater than 4')
        PduAuthenticationConfig = self.session.get_children('PerPduAuthenticationConfig')
        PerPduAuthentication = len(PduAuthenticationConfig)
        if PerPduAuthentication > int(Value):
            for i in range(int(Value), PerPduAuthentication): self.session.get_children('PerPduAuthenticationConfig')[
                -1].delete()
        else:
            for i in range(PerPduAuthentication, int(Value)): PerPduAuthenticationConfig(upper=self.session)
        self.session.get()

    def edit_per_pdu_authentication(self, Index, **kwargs):
        PduAuthenticationConfig = self.session.get_children('PerPduAuthenticationConfig')
        if kwargs:
            PduAuthenticationConfig[int(Index)].edit(**kwargs)
        return True

    def get_per_pdu_authentication(self, Index):
        PduAuthenticationConfig = self.session.get_children('PerPduAuthenticationConfig')
        return {'PdusType': PduAuthenticationConfig[int(Index)].PdusType.name,
                'AuthMethod': PduAuthenticationConfig[int(Index)].AuthMethod.name,
                'Password': PduAuthenticationConfig[int(Index)].Password}

    @property
    def MtParams(self):
        MTConfig = self.session.get_children('IsisMTConfig')
        return len(MTConfig)

    @MtParams.setter
    def MtParams(self, Value):
        if int(Value) > 2:
            raise ValueError('MtParams should not be greater than 2')
        MTConfig = self.session.get_children('IsisMTConfig')
        MtParams = len(MTConfig)
        if MtParams > int(Value):
            for i in range(int(Value), MtParams): self.session.get_children('IsisMTConfig')[-1].delete()
        else:
            for i in range(MtParams, int(Value)): IsisMTConfig(upper=self.session)
        self.session.get()

    def edit_mt_params(self, Index, MtId=None, MtFlags=None):
        MTConfig = self.session.get_children('IsisMTConfig')
        if MtId:
            MTConfig[int(Index)].edit(MtId=MtId)
        if MtFlags:
            MTConfig[int(Index)].edit(MtFlags=self.transform_options(OptionsEum=EnumMtFlagBit, Value=MtFlags))
        return True

    def get_mt_params(self, Index):
        MTConfig = self.session.get_children('IsisMTConfig')
        return {'MtId': MTConfig[int(Index)].MtId.name,
                'MtFlags': self.get_options(Options=MTConfig[int(Index)].MtFlags)}

    @property
    def ReportLabel(self):
        return self.session.ReportLabel

    @ReportLabel.setter
    def ReportLabel(self, Value):
        self.session.ReportLabel = Value
        self.session.get()

    @property
    def LearnRoute(self):
        return self.session.LearnRoute

    @LearnRoute.setter
    def LearnRoute(self, Value):
        self.session.LearnRoute = Value
        self.session.get()

    @property
    def RecordLspNextSequenceNum(self):
        return self.session.RecordLspNextSequenceNum

    @RecordLspNextSequenceNum.setter
    def RecordLspNextSequenceNum(self, Value):
        self.session.RecordLspNextSequenceNum = Value
        self.session.get()

    @property
    def L1NarrowMetric(self):
        return self.session.L1NarrowMetric

    @L1NarrowMetric.setter
    def L1NarrowMetric(self, Value):
        self.session.L1NarrowMetric = Value
        self.session.get()

    @property
    def L1WideMetric(self):
        return self.session.L1WideMetric

    @L1WideMetric.setter
    def L1WideMetric(self, Value):
        self.session.L1WideMetric = Value
        self.session.get()

    @property
    def L2NarrowMetric(self):
        return self.session.L2NarrowMetric

    @L2NarrowMetric.setter
    def L2NarrowMetric(self, Value):
        self.session.L2NarrowMetric = Value
        self.session.get()

    @property
    def L2WideMetric(self):
        return self.session.L2WideMetric

    @L2WideMetric.setter
    def L2WideMetric(self, Value):
        self.session.L2WideMetric = Value
        self.session.get()

    @property
    def FloodLsp(self):
        return self.session.FloodLsp

    @FloodLsp.setter
    def FloodLsp(self, Value):
        self.session.FloodLsp = Value
        self.session.get()

    def create_lsp(self, **kwargs):
        config = IsisLspConfig(upper=self.session)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_ipv4_tlv(cls, Lsp, **kwargs):
        config = IsisIpv4TlvConfig(upper=Lsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_ipv6_tlv(cls, Lsp, **kwargs):
        config = IsisIpv6TlvConfig(upper=Lsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_p2p_adjacency_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'UP'
        self.wait_state(StateName='ThreeWayP2pAdjState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_broadcast_l1_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['DISOTHER', 'DIS']
        self.wait_state(StateName='L1BroadcastAdjState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_broadcast_l2_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = ['DISOTHER', 'DIS']
        self.wait_state(StateName='L2BroadcastAdjState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    @classmethod
    def create_neighbor_tlv(cls, Lsp, **kwargs):
        config = IsisNeighborConfig(upper=Lsp)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_neighbor_te_config(cls, Neighbor, **kwargs):
        config = Neighbor.get_children('IsisTEConfig')[0]
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_neighbor_sr_adj_sid_sub_tlv(self, Neighbor, **kwargs):
        config = IsisSrAdjSidSubTlv(upper=Neighbor)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisAdjSidFlag, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_neighbor_sr_lan_adj_sid_sub_tlv(self, Neighbor, **kwargs):
        config = IsisSrLanAdjSidSubTlv(upper=Neighbor)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisAdjSidFlag, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_neighbor_srv6_endx_sid_sub_tlv(self, Neighbor, **kwargs):
        config = IsisSrv6LanEndXSidSubTlv(upper=Neighbor)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumSrv6EndXSidFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_neighbor_srv6_lan_endx_sid_sub_tlv(self, Neighbor, **kwargs):
        config = IsisSrv6LanEndXSidSubTlv(upper=Neighbor)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumSrv6EndXSidFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_neighbor_sr_link_msd_sub_tlv(self, Neighbor, **kwargs):
        config = IsisSrLinkMsdSubTlv(upper=Neighbor)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisSrMsdFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_custom_sub_tlv(cls, SubTlv, **kwargs):
        config = IsisCustomMsdSubTlv(upper=SubTlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_tlv_prefix_sid_sub_tlv(self, Tlv, **kwargs):
        config = IsisSrPrefixSidSubTlv(upper=Tlv)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisPrefixSidFlag, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_tlv_flex_algorithm_prefix_metric_sub_tlv(cls, Tlv, **kwargs):
        config = IsisFlexAlgoPrefixMetricSubTlv(upper=Tlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_tlv_bier_sub_tlv(cls, Tlv, **kwargs):
        config = IsisBierSubTlv(upper=Tlv)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_tlv_bier_Mpls_sub_sub_tlv(cls, Bier, **kwargs):
        config = IsisBierMplsSubTlv(upper=Bier)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_tlv_end_bier_sub_tlv(cls, Bier, **kwargs):
        config = IsisEndBierSubTlv(upper=Bier)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_tlv_bierv6_bift_id_sub_tlv(cls, Bier, **kwargs):
        config = IsisBierBiftIdSubTlv(upper=Bier)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_capability_tlv(self, Lsp, **kwargs):
        config = IsisCapabilityTlv(upper=Lsp)
        kwargs = self.edit_options_of_kwargs(config=config, para='Option', enum_=EnumIsisCapabilityFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_capability_sr_capability_sub_tlv(self, Capability, **kwargs):
        config = IsisSrCapabilitySubTlv(upper=Capability)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisSrCapabilityFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_capability_sr_algorithm_sub_tlv(cls, Capability, **kwargs):
        config = IsisSrAlgorithmSubTlv(upper=Capability)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_capability_srv6_capability_sub_tlv(self, Capability, **kwargs):
        config = IsisSrv6CapabilitySubTlv(upper=Capability)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisSrv6CapabilityFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_capability_sr_node_msd_sub_tlv(self, Capability, **kwargs):
        config = IsisSrMsdSubTlv(upper=Capability)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisSrMsdFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_capability_sr_fad_sub_tlv(self, Capability, **kwargs):
        config = IsisFelxAlgoDefinitionSubTlv(upper=Capability)
        kwargs = self.edit_options_of_kwargs(config=config, para='FlexAlgoSubTlv', enum_=EnumFlexAlgoSubTlvType,
                                             **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_capability_srms_preference_sub_tlv(cls, Capability, **kwargs):
        config = IsisSrSRMSPrefSubTlv(upper=Capability)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_sr_binding_tlv(self, Lsp, **kwargs):
        config = IsisSrBindingTlv(upper=Lsp)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisSrBindingFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def create_binding_sr_sid_sub_tlv(cls, Binding, **kwargs):
        config = IsisSrSidSubTlv(upper=Binding)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_location_tlv(self, Lsp, **kwargs):
        config = IsisSrv6LocatorTlv(upper=Lsp)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumIsisSrv6LocatorFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def create_srv6_end_sid_sub_tlv(self, Location, **kwargs):
        config = IsisSrv6EndSidSubTlv(upper=Location)
        kwargs = self.edit_options_of_kwargs(config=config, para='Flags', enum_=EnumSrv6EndSidFlags, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    @classmethod
    def advertise(cls, Lsps):
        if not isinstance(Lsps, (list, set, tuple)):
            Lsps = [Lsps]
        cmd = IsisLspAdvertiseCommand(IsisLspConfigs=[x.handle for x in Lsps])
        cmd.execute()
        return True

    @classmethod
    def withdraw(cls, Lsps):
        if not isinstance(Lsps, (list, set, tuple)):
            Lsps = [Lsps]
        cmd = IsisLspWithdrawCommand(IsisLspConfigs=[x.handle for x in Lsps])
        cmd.execute()
        return True

    def graceful_restart(self):
        cmd = IsisGrStartSessionCommand(IsisConfigs=self.handle)
        cmd.execute()
        return True



if __name__ == '__main__':
    initialize()
    sys_entry = get_sys_entry()
    port_location = ('//10.0.5.6/1/15', '//10.0.5.6/1/16')
    port1 = Port(upper=sys_entry, Location=port_location[0])
    port2 = Port(upper=sys_entry, Location=port_location[1])
    bring_port_online_cmd = BringPortsOnlineCommand(PortList=[port1.handle, port2.handle])
    bring_port_online_cmd.execute()
    interface1 = Interface(upper=port1)
    interface2 = Interface(upper=port2)
    build_ipv41 = BuildInterfaceCommand(InterfaceList=interface1.handle, NetworkLayers=['eth', 'ipv4'])
    build_ipv41.execute()
    build_ipv42 = BuildInterfaceCommand(InterfaceList=interface2.handle, NetworkLayers=['eth', 'ipv4'])
    build_ipv42.execute()
    router_1 = IsisRouter(Upper=port1)
    router_2 = IsisRouter(Upper=port2)
    router_1.interface = interface1
    router_2.interface = interface2
    lsp_1 = router_1.create_lsp()
    lsp_2 = router_2.create_lsp()
    router_1.create_ipv4_tlv(Lsp=lsp_1)
    router_2.create_ipv6_tlv(Lsp=lsp_2)
    SaveTestCaseCommand(TestCase="D:/isis.xcfg").execute()
    print(router_1.__dict__)
    print(router_2.__dict__)
    pass

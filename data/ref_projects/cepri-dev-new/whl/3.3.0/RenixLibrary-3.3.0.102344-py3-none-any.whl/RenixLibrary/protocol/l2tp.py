import time

from .protocol import *


# from RenixAPI.RenixLibrary.protocol.protocol import *


class L2tp(Protocol):

    def __init__(self, Upper, Session=None, **kwargs):
        super().__init__(ClassName='L2tpProtocolConfig', Upper=Upper, Session=Session)
        # if kwargs:
        #    self.session.edit(**kwargs)
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def State(self):
        return self.session.L2tpBlockState.name

    @property
    def Version(self):
        return self.session.L2tpVersion.name

    @property
    def EmulationMode(self):
        return self.session.EmulationMode.name

    @EmulationMode.setter
    def EmulationMode(self, Value):
        self.session.EmulationMode = Value
        self.session.get()

    @property
    def IpEncapsulation(self):
        return self.session.IpEncapsulation.name

    @property
    def TunnelCountPerNode(self):
        return self.session.TunnelCountPerNode

    @TunnelCountPerNode.setter
    def TunnelCountPerNode(self, Value):
        self.session.TunnelCountPerNode = Value
        self.session.get()

    @property
    def SessionCountPerTunnel(self):
        return self.session.SessionCountPerTunnel

    @SessionCountPerTunnel.setter
    def SessionCountPerTunnel(self, Value):
        self.session.SessionCountPerTunnel = Value
        self.session.get()

    @property
    def TunnelStartingId(self):
        return self.session.TunnelStartingId

    @TunnelStartingId.setter
    def TunnelStartingId(self, Value):
        self.session.TunnelStartingId = Value
        self.session.get()

    @property
    def SessionStartingId(self):
        return self.session.SessionStartingId

    @SessionStartingId.setter
    def SessionStartingId(self, Value):
        self.session.SessionStartingId = Value
        self.session.get()

    @property
    def UdpSourcePort(self):
        return self.session.UdpSourcePort

    @UdpSourcePort.setter
    def UdpSourcePort(self, Value):
        self.session.UdpSourcePort = Value
        self.session.get()

    @property
    def UdpChecksumEnabled(self):
        return self.session.UdpChecksumEnabled

    @UdpChecksumEnabled.setter
    def UdpChecksumEnabled(self, Value):
        self.session.UdpChecksumEnabled = Value
        self.session.get()

    @property
    def RetryTunnelCreationEnabled(self):
        return self.session.RetryTunnelCreationEnabled

    @RetryTunnelCreationEnabled.setter
    def RetryTunnelCreationEnabled(self, Value):
        self.session.RetryTunnelCreationEnabled = Value
        self.session.get()

    @property
    def TunnelCreationTimeout(self):
        return self.session.TunnelCreationTimeout

    @TunnelCreationTimeout.setter
    def TunnelCreationTimeout(self, Value):
        self.session.TunnelCreationTimeout = Value
        self.session.get()

    @property
    def MaxTunnelCreationTimes(self):
        return self.session.MaxTunnelCreationTimes

    @MaxTunnelCreationTimes.setter
    def MaxTunnelCreationTimes(self, Value):
        self.session.MaxTunnelCreationTimes = Value
        self.session.get()

    @property
    def HostName(self):
        return self.session.HostName

    @HostName.setter
    def HostName(self, Value):
        self.session.HostName = Value
        self.session.get()

    @property
    def EnableAuthentication(self):
        return self.session.EnableAuthentication

    @EnableAuthentication.setter
    def EnableAuthentication(self, Value):
        self.session.EnableAuthentication = Value
        self.session.get()

    @property
    def IncomingTunnelPassword(self):
        return self.session.IncomingTunnelPassword

    @IncomingTunnelPassword.setter
    def IncomingTunnelPassword(self, Value):
        self.session.IncomingTunnelPassword = Value
        self.session.get()

    @property
    def OutgoingTunnelPassword(self):
        return self.session.OutgoingTunnelPassword

    @OutgoingTunnelPassword.setter
    def OutgoingTunnelPassword(self, Value):
        self.session.OutgoingTunnelPassword = Value
        self.session.get()

    @property
    def HelloEnabled(self):
        return self.session.HelloEnabled

    @HelloEnabled.setter
    def HelloEnabled(self, Value):
        self.session.HelloEnabled = Value
        self.session.get()

    @property
    def HelloInterval(self):
        return self.session.HelloInterval

    @HelloInterval.setter
    def HelloInterval(self, Value):
        self.session.HelloInterval = Value
        self.session.get()

    @property
    def TxBitRate(self):
        return self.session.TxBitRate

    @TxBitRate.setter
    def TxBitRate(self, Value):
        self.session.TxBitRate = Value
        self.session.get()

    @property
    def BearerCapabilities(self):
        return self.session.BearerCapabilities.name

    @BearerCapabilities.setter
    def BearerCapabilities(self, Value):
        self.session.BearerCapabilities = Value
        self.session.get()

    @property
    def BearerType(self):
        return self.session.BearerType.name

    @BearerType.setter
    def BearerType(self, Value):
        self.session.BearerType = Value
        self.session.get()

    @property
    def FrameCapabilities(self):
        return self.session.FrameCapabilities.name

    @FrameCapabilities.setter
    def FrameCapabilities(self, Value):
        self.session.FrameCapabilities = Value
        self.session.get()

    @property
    def FrameType(self):
        return self.session.FrameType.name

    @FrameType.setter
    def FrameType(self, Value):
        self.session.FrameType = Value
        self.session.get()

    @property
    def CallingNumberEnabled(self):
        return self.session.CallingNumberEnabled

    @CallingNumberEnabled.setter
    def CallingNumberEnabled(self, Value):
        self.session.CallingNumberEnabled = Value
        self.session.get()

    @property
    def CallingNumber(self):
        return self.session.CallingNumber

    @CallingNumber.setter
    def CallingNumber(self, Value):
        self.session.CallingNumber = Value
        self.session.get()

    @property
    def RxWindowSize(self):
        return self.session.RxWindowSize

    @RxWindowSize.setter
    def RxWindowSize(self, Value):
        self.session.RxWindowSize = Value
        self.session.get()

    @property
    def UseGatewayAsRemoteIp(self):
        return self.session.UseGatewayAsRemoteIp

    @UseGatewayAsRemoteIp.setter
    def UseGatewayAsRemoteIp(self, Value):
        self.session.UseGatewayAsRemoteIp = Value
        self.session.get()

    @property
    def RemoteIpv4Address(self):
        return self.session.RemoteIpv4Address

    @RemoteIpv4Address.setter
    def RemoteIpv4Address(self, Value):
        self.session.RemoteIpv4Address = Value
        self.session.get()

    @property
    def RemoteIpv4AddressStep(self):
        return self.session.RemoteIpv4AddressStep

    @RemoteIpv4AddressStep.setter
    def RemoteIpv4AddressStep(self, Value):
        self.session.RemoteIpv4AddressStep = Value
        self.session.get()

    @property
    def RemoteIpv6Address(self):
        return self.session.RemoteIpv6Address

    @RemoteIpv6Address.setter
    def RemoteIpv6Address(self, Value):
        self.session.RemoteIpv6Address = Value
        self.session.get()

    @property
    def RemoteIpv6AddressStep(self):
        return self.session.RemoteIpv6AddressStep

    @RemoteIpv6AddressStep.setter
    def RemoteIpv6AddressStep(self, Value):
        self.session.RemoteIpv6AddressStep = Value
        self.session.get()

    @property
    def LcpProxyMode(self):
        return self.session.LcpProxyMode.name

    @LcpProxyMode.setter
    def LcpProxyMode(self, Value):
        self.session.LcpProxyMode = Value
        self.session.get()

    @property
    def ForceLcpRenegotiation(self):
        return self.session.ForceLcpRenegotiation

    @ForceLcpRenegotiation.setter
    def ForceLcpRenegotiation(self, Value):
        self.session.ForceLcpRenegotiation = Value
        self.session.get()

    @property
    def Ipv4TosValue(self):
        return self.session.Ipv4TosValue

    @Ipv4TosValue.setter
    def Ipv4TosValue(self, Value):
        self.session.Ipv4TosValue = Value
        self.session.get()

    @property
    def Ipv6TrafficClassValue(self):
        return self.session.Ipv6TrafficClassValue

    @Ipv6TrafficClassValue.setter
    def Ipv6TrafficClassValue(self, Value):
        self.session.Ipv6TrafficClassValue = Value
        self.session.get()

    @property
    def HideFramingCapabilities(self):
        return self.session.HideFramingCapabilities

    @HideFramingCapabilities.setter
    def HideFramingCapabilities(self, Value):
        self.session.HideFramingCapabilities = Value
        self.session.get()

    @property
    def HideBearerCapabilities(self):
        return self.session.HideBearerCapabilities

    @HideBearerCapabilities.setter
    def HideBearerCapabilities(self, Value):
        self.session.HideBearerCapabilities = Value
        self.session.get()

    @property
    def HideFirmwareRevision(self):
        return self.session.HideFirmwareRevision

    @property
    def HideVendorName(self):
        return self.session.HideVendorName

    @property
    def HideAssignedTunnelId(self):
        return self.session.HideAssignedTunnelId

    @HideAssignedTunnelId.setter
    def HideAssignedTunnelId(self, Value):
        self.session.HideAssignedTunnelId = Value
        self.session.get()

    @property
    def HideChallenge(self):
        return self.session.HideChallenge

    @HideChallenge.setter
    def HideChallenge(self, Value):
        self.session.HideChallenge = Value
        self.session.get()

    @property
    def HideChallengeResponse(self):
        return self.session.HideChallengeResponse

    @HideChallengeResponse.setter
    def HideChallengeResponse(self, Value):
        self.session.HideChallengeResponse = Value
        self.session.get()

    @property
    def HideAssignedSessionId(self):
        return self.session.HideAssignedSessionId

    @HideAssignedSessionId.setter
    def HideAssignedSessionId(self, Value):
        self.session.HideAssignedSessionId = Value
        self.session.get()

    @property
    def HideCallSerialNumber(self):
        return self.session.HideCallSerialNumber

    @HideCallSerialNumber.setter
    def HideCallSerialNumber(self, Value):
        self.session.HideCallSerialNumber = Value
        self.session.get()

    @property
    def HideMinBps(self):
        return self.session.HideMinBps

    @property
    def HideMaxBps(self):
        return self.session.HideMaxBps

    @property
    def HideBearerType(self):
        return self.session.HideBearerType

    @property
    def HideFramingType(self):
        return self.session.HideFramingType

    @HideFramingType.setter
    def HideFramingType(self, Value):
        self.session.HideFramingType = Value
        self.session.get()

    @property
    def HideCalledNumber(self):
        return self.session.HideCalledNumber

    @property
    def HideCallingNumber(self):
        return self.session.HideCallingNumber

    @HideCallingNumber.setter
    def HideCallingNumber(self, Value):
        self.session.HideCallingNumber = Value
        self.session.get()

    @property
    def HideSubAddress(self):
        return self.session.HideSubAddress

    @property
    def HideTxConnectSpeed(self):
        return self.session.HideTxConnectSpeed

    @HideTxConnectSpeed.setter
    def HideTxConnectSpeed(self, Value):
        self.session.HideTxConnectSpeed = Value
        self.session.get()

    @property
    def HidePhysicalChannelId(self):
        return self.session.HidePhysicalChannelId

    @property
    def HidePrivateGroupId(self):
        return self.session.HidePrivateGroupId

    @property
    def HideRxConnectSpeed(self):
        return self.session.HideRxConnectSpeed

    @property
    def HideInitialReceivedLcpConfReq(self):
        return self.session.HideInitialReceivedLcpConfReq

    @property
    def HideLastSentLcpConfReq(self):
        return self.session.HideLastSentLcpConfReq

    @HideLastSentLcpConfReq.setter
    def HideLastSentLcpConfReq(self, Value):
        self.session.HideLastSentLcpConfReq = Value
        self.session.get()

    @property
    def HideLastReceivedLcpConfReq(self):
        return self.session.HideLastReceivedLcpConfReq

    @HideLastReceivedLcpConfReq.setter
    def HideLastReceivedLcpConfReq(self, Value):
        self.session.HideLastReceivedLcpConfReq = Value
        self.session.get()

    @property
    def HideProxyAuthenType(self):
        return self.session.HideProxyAuthenType

    @HideProxyAuthenType.setter
    def HideProxyAuthenType(self, Value):
        self.session.HideProxyAuthenType = Value
        self.session.get()

    @property
    def HideProxyAuthenName(self):
        return self.session.HideProxyAuthenName

    @HideProxyAuthenName.setter
    def HideProxyAuthenName(self, Value):
        self.session.HideProxyAuthenName = Value
        self.session.get()

    @property
    def HideProxyAuthenChallenge(self):
        return self.session.HideProxyAuthenChallenge

    @HideProxyAuthenChallenge.setter
    def HideProxyAuthenChallenge(self, Value):
        self.session.HideProxyAuthenChallenge = Value
        self.session.get()

    @property
    def HideProxyAuthenId(self):
        return self.session.HideProxyAuthenId

    @HideProxyAuthenId.setter
    def HideProxyAuthenId(self, Value):
        self.session.HideProxyAuthenId = Value
        self.session.get()

    @property
    def HideProxyAuthenResponse(self):
        return self.session.HideProxyAuthenResponse

    @HideProxyAuthenResponse.setter
    def HideProxyAuthenResponse(self, Value):
        self.session.HideProxyAuthenResponse = Value
        self.session.get()

    @property
    def HideCallErrors(self):
        return self.session.HideCallErrors

    @property
    def HideAccm(self):
        return self.session.HideAccm

    def connect(self):
        cmd = L2tpConnectCommand(L2tpBlockHandles=self.handle)
        cmd.execute()
        return True

    def disconnect(self):
        cmd = L2tpDisconnectCommand(L2tpBlockHandles=self.handle)
        cmd.execute()
        return True

    def abort(self):
        cmd = L2tpAbortCommand(L2tpBlockHandles=self.handle)
        cmd.execute()
        return True

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'CONNECTED'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

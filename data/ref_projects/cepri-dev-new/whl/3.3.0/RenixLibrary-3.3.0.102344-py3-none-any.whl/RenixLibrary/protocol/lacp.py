from renix_py_api.renix import *


class Lacp:
    def __init__(self, Ports):
        if not isinstance(Ports, list):
            Ports = [Ports]
        cmd = AggregatePortsCommand(PortHandles=[i.handle for i in Ports])
        cmd.execute()
        self.handle = cmd.LagPortHandles[0]
        rom = cmd.cl_instance.rom_manager
        sys_entry_ = rom.get_object('SysEntry_1')
        rom_ = sys_entry_.cl_instance.rom_manager
        self.session = rom_.get_object(self.handle)

    def __del__(self):
        cmd = DeleteLagPortCommand(LacpPortHandles=[self.handle])
        cmd.execute()

    def add_members(self, Ports):
        if not isinstance(Ports, list):
            Ports = [Ports]
        cmd = AddLagMemberCommand(LagPort=self.handle, PortList=[i.handle for i in Ports])
        cmd.execute()
        return True

    def get_aggregation_group(self):
        return self.session.get_children('AggregationGroupConfig')[0]

    def edit_aggregation_group(self, **kwargs):
        config = self.session.get_children('AggregationGroupConfig')[0]
        for k, v in kwargs.items():
            if k == 'L2HashOption':
                value = [EnumLacpL2HashOption[i].value for i in v]
                value = int(sum(value))
                setattr(config, k, value)
            elif k == 'L3HashOption':
                value = [EnumLacpL3HashOption[i].value for i in v]
                value = int(sum(value))
                setattr(config, k, value)
            else:
                setattr(config, k, v)
        return True

    def delete_members(self, Ports):
        if not isinstance(Ports, list):
            Ports = [Ports]
        cmd = DeleteLagMemberCommand(LagPort=self.handle, PortList=[i.handle for i in Ports])
        cmd.execute()
        return True

    @staticmethod
    def get_members_port_config(Ports):
        configs = []
        if not isinstance(Ports, list):
            Ports = [Ports]
        for port in Ports:
            config = port.get_children('LacpPortConfig')[0]
            if config:
                configs.append(config)
        return configs

    @staticmethod
    def edit_members_port_config(Ports, **kwargs):
        for config in Lacp.get_members_port_config(Ports):
            for k, v in kwargs.items():
                if hasattr(config, k):
                    setattr(config, k, v)
        return True

    @classmethod
    def pause_send_lacp_pdus(cls, Ports):
        configs = cls.get_members_port_config(Ports)
        cmd = PauseSendLACPPDUsCommand(LacpPortHandles=[i.handle for i in configs])
        cmd.execute()
        return True

    @classmethod
    def resume_send_lacp_pdus(cls, Ports):
        configs = cls.get_members_port_config(Ports)
        cmd = ResumeSendLACPPDUsCommand(LacpPortHandles=[i.handle for i in configs])
        cmd.execute()
        return True

    @classmethod
    def send_in_sync_pdus(cls, Ports):
        configs = cls.get_members_port_config(Ports)
        cmd = SendInSyncPDUsCommand(LacpPortHandles=[i.handle for i in configs])
        cmd.execute()
        return True

    @classmethod
    def send_out_of_sync_pdus(cls, Ports):
        configs = cls.get_members_port_config(Ports)
        cmd = SendOutofSyncPDUsCommand(LacpPortHandles=[i.handle for i in configs])
        cmd.execute()
        return True

    @classmethod
    def start_lacp_port(cls, Ports):
        configs = cls.get_members_port_config(Ports)
        cmd = StartLacpPortCommand(LacpPortHandles=[i.handle for i in configs])
        cmd.execute()
        return True

    @classmethod
    def stop_lacp_port(cls, Ports):
        configs = cls.get_members_port_config(Ports)
        cmd = StopLacpPortCommand(LacpPortHandles=[i.handle for i in configs])
        cmd.execute()
        return True



from .protocol import *

class Dhcpv6Client(Protocol):

    def __init__(self, Upper, **kwargs):
        super(Dhcpv6Client, self).__init__(ClassName='Dhcpv6ClientConfig', Upper=Upper)
        self.__HostInterface = ""
        for k, v in kwargs.items():
            if hasattr(self, k):
                setattr(self, str(k), v)

    @property
    def EmulationMode(self):
        return self.session.EmulationMode.name

    @EmulationMode.setter
    def EmulationMode(self, value):
        self.session.EmulationMode = value
        self.session.get()

    @property
    def State(self):
        return self.session.Dhcpv6BlockState.name

    @property
    def PdState(self):
        return self.session.Dhcpv6PdBlockState.name

    @property
    def EnableRenewMsg(self):
        return self.session.EnableRenewMsg

    @EnableRenewMsg.setter
    def EnableRenewMsg(self, value):
        self.session.EnableRenewMsg = value
        self.session.get()

    @property
    def EnableRebindMsg(self):
        return self.session.EnableRebindMsg

    @EnableRebindMsg.setter
    def EnableRebindMsg(self, value):
        self.session.EnableRebindMsg = value
        self.session.get()

    @property
    def EnableReconfigAccept(self):
        return self.session.EnableReconfigAccept

    @EnableReconfigAccept.setter
    def EnableReconfigAccept(self, value):
        self.session.EnableReconfigAccept = value
        self.session.get()

    @property
    def EnableSyncAddressInterface(self):
        return self.session.EnableSyncAddressInterface

    @EnableSyncAddressInterface.setter
    def EnableSyncAddressInterface(self, value):
        self.session.EnableSyncAddressInterface = value
        self.session.get()

    @property
    def T1Timer(self):
        return self.session.T1Timer

    @T1Timer.setter
    def T1Timer(self, value):
        self.session.T1Timer = value
        self.session.get()

    @property
    def T2Timer(self):
        return self.session.T2Timer

    @T2Timer.setter
    def T2Timer(self, value):
        self.session.T2Timer = value
        self.session.get()

    @property
    def PreferredLifetime(self):
        return self.session.PreferredLifetime

    @PreferredLifetime.setter
    def PreferredLifetime(self, value):
        self.session.PreferredLifetime = value
        self.session.get()

    @property
    def ValidLifetime(self):
        return self.session.ValidLifetime

    @ValidLifetime.setter
    def ValidLifetime(self, value):
        self.session.ValidLifetime = value
        self.session.get()

    @property
    def RapidCommitOptMode(self):
        return self.session.RapidCommitOptMode.name

    @RapidCommitOptMode.setter
    def RapidCommitOptMode(self, value):
        self.session.RapidCommitOptMode = value
        self.session.get()

    @property
    def DuidType(self):
        return self.session.DuidType.name

    @DuidType.setter
    def DuidType(self, value):
        self.session.DuidType = value
        self.session.get()

    @property
    def DuidCustomValue(self):
        return self.session.DuidCustomValue

    @DuidCustomValue.setter
    def DuidCustomValue(self, value):
        self.session.DuidCustomValue = value
        self.session.get()

    @property
    def DuidEnterpriseNumber(self):
        return self.session.DuidEnterpriseNumber

    @DuidEnterpriseNumber.setter
    def DuidEnterpriseNumber(self, value):
        self.session.DuidEnterpriseNumber = value
        self.session.get()

    @property
    def DuidStartValue(self):
        return self.session.DuidStartValue

    @DuidStartValue.setter
    def DuidStartValue(self, value):
        self.session.DuidStartValue = value
        self.session.get()

    @property
    def DuidStepValue(self):
        return self.session.DuidStepValue

    @DuidStepValue.setter
    def DuidStepValue(self, value):
        self.session.DuidStepValue = value
        self.session.get()

    @property
    def DestinationAddress(self):
        return self.session.DestinationAddress.name

    @DestinationAddress.setter
    def DestinationAddress(self, value):
        self.session.DestinationAddress = value
        self.session.get()

    @property
    def EnableRelayAgent(self):
        return self.session.EnableRelayAgent

    @EnableRelayAgent.setter
    def EnableRelayAgent(self, value):
        self.session.EnableRelayAgent = value
        self.session.get()

    @property
    def RelayAgentIp(self):
        return self.session.RelayAgentIp

    @RelayAgentIp.setter
    def RelayAgentIp(self, value):
        self.session.RelayAgentIp = value
        self.session.get()

    @property
    def ServerIp(self):
        return self.session.ServerIp

    @ServerIp.setter
    def ServerIp(self, value):
        self.session.ServerIp = value
        self.session.get()

    @property
    def EnableUseRelayAgentMacForTraffic(self):
        return self.session.EnableUseRelayAgentMacForTraffic

    @EnableUseRelayAgentMacForTraffic.setter
    def EnableUseRelayAgentMacForTraffic(self, value):
        self.session.EnableUseRelayAgentMacForTraffic = value
        self.session.get()

    @property
    def RequestPrefixLength(self):
        return self.session.RequestPrefixLength

    @RequestPrefixLength.setter
    def RequestPrefixLength(self, value):
        self.session.RequestPrefixLength = value
        self.session.get()

    @property
    def RequestPrefixStartAddress(self):
        return self.session.RequestPrefixStartAddress

    @RequestPrefixStartAddress.setter
    def RequestPrefixStartAddress(self, value):
        self.session.RequestPrefixStartAddress = value
        self.session.get()

    @property
    def ControlPlaneSrcIPv6Addr(self):
        return self.session.ControlPlaneSrcIPv6Addr.name

    @ControlPlaneSrcIPv6Addr.setter
    def ControlPlaneSrcIPv6Addr(self, value):
        self.session.ControlPlaneSrcIPv6Addr = value
        self.session.get()

    @property
    def RequestStartAddress(self):
        return self.session.RequestStartAddress

    @RequestStartAddress.setter
    def RequestStartAddress(self, value):
        self.session.RequestStartAddress = value
        self.session.get()

    @property
    def EnableAuthentication(self):
        return self.session.EnableAuthentication

    @EnableAuthentication.setter
    def EnableAuthentication(self, value):
        self.session.EnableAuthentication = value
        self.session.get()

    @property
    def AuthenticationProtocol(self):
        return self.session.AuthenticationProtocol.name

    @AuthenticationProtocol.setter
    def AuthenticationProtocol(self, value):
        self.session.AuthenticationProtocol = value
        self.session.get()

    @property
    def DhcpRealm(self):
        return self.session.DhcpRealm

    @DhcpRealm.setter
    def DhcpRealm(self, value):
        self.session.DhcpRealm = value
        self.session.get()

    @property
    def AuthenticationKeyId(self):
        return self.session.AuthenticationKeyId

    @AuthenticationKeyId.setter
    def AuthenticationKeyId(self, value):
        self.session.AuthenticationKeyId = value
        self.session.get()

    @property
    def AuthenticationKey(self):
        return self.session.AuthenticationKey

    @AuthenticationKey.setter
    def AuthenticationKey(self, value):
        self.session.AuthenticationKey = value
        self.session.get()

    @property
    def AuthenticationKeyType(self):
        return self.session.AuthenticationKeyType.name

    @AuthenticationKeyType.setter
    def AuthenticationKeyType(self, value):
        self.session.AuthenticationKeyType = value
        self.session.get()

    @property
    def EnableDad(self):
        return self.session.EnableDad

    @EnableDad.setter
    def EnableDad(self, value):
        self.session.EnableDad = value
        self.session.get()

    @property
    def DadTimeout(self):
        return self.session.DadTimeout

    @DadTimeout.setter
    def DadTimeout(self, value):
        self.session.DadTimeout = value
        self.session.get()

    @property
    def DadTransmits(self):
        return self.session.DadTransmits

    @DadTransmits.setter
    def DadTransmits(self, value):
        self.session.DadTransmits = value
        self.session.get()

    # fake attribute of Dhcpv6ClientConfig
    @property
    def HostInterface(self):
        return self.__HostInterface

    @HostInterface.setter
    def HostInterface(self, Interface):
        Dhcpv6SelectHostInterfaceCommand(Dhcpv6Clients=self.session.handle, InterfaceHandles=Interface.handle).execute()
        self.__HostInterface = Interface

    def bind(self):
        cmd = Dhcpv6BindCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def abort(self):
        cmd = Dhcpv6AbortCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def rebind(self):
        cmd = Dhcpv6RebindCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def release(self):
        cmd = Dhcpv6ReleaseCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def renew(self):
        cmd = Dhcpv6RenewCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def confirm(self):
        cmd = Dhcpv6ConfirmCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def info_request(self):
        cmd = Dhcpv6InfoRequestCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def active_lease_query(self):
        cmd = Dhcpv6ActiveLeaseQueryCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def bulk_lease_query(self, **kwargs):
        cmd = Dhcpv6BulkLeaseQueryCommand(Dhcpv6Clients=self.handle, **kwargs)
        cmd.execute()
        return True

    def lease_query(self, **kwargs):
        cmd = Dhcpv6LeaseQueryCommand(Dhcpv6Clients=self.handle, **kwargs)
        cmd.execute()
        return True

    def start_tls(self):
        cmd = Dhcpv6StartTlsCommand(Dhcpv6Clients=self.handle)
        cmd.execute()
        return True

    def custom_options(self, **kwargs):
        config = Dhcpv6ClientCustomOptionsConfig(upper=self.session)
        kwargs = self.edit_options_of_kwargs(config=config, para='IncludeMsg', enum_=EnumDhcpv6IncludeMsg, **kwargs)
        if kwargs:
            config.edit(**kwargs)
        return config

    def wait_session_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'BOUND'
        self.wait_state(StateName='State', State=State, Interval=Interval, TimeOut=TimeOut)
        return True

    def wait_session_pd_state(self, State=None, Interval=1, TimeOut=60):
        if State is None:
            State = 'BOUND'
        self.wait_state(StateName='PdState', State=State, Interval=Interval, TimeOut=TimeOut)
        return True



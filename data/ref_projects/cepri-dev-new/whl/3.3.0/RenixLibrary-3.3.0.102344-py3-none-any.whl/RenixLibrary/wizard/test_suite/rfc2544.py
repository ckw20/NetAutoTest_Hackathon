from .test_item import *


class Rfc2544Throughput(TestItem, Other1Item):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc2544BackToBack(TestItem, Other2Item):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_duration_parameters(self,
                                 MinDuration=0.000064,
                                 MinFrameCount=1,
                                 DurationResolution=0.0001,
                                 FrameCountResolution=100,
                                 AcceptFrameLoss=0
                                 ):
        config_backtoback_binary_search(test_config=self.Item, min_duration=MinDuration, min_frame_count=MinFrameCount,
                                        duration_resolution=DurationResolution,
                                        frame_count_resolution=FrameCountResolution, accept_frame_loss=AcceptFrameLoss)
        return True


class Rfc2544FrameLoss(TestItem, Other2Item):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc2544Latency(TestItem, Other2Item):

    def __init__(self, Item):
        super().__init__(Item=Item)

from renix_py_api.renix import *


class RouteWizard:

    def __init__(self, Wizard, Sessions, Relation, **kwargs):
        wizard = globals()[Wizard](upper=get_sys_entry())
        for Session in Sessions:
            wizard.set_relatives(Relation, Session.session)
        self.__wizard = wizard
        for k, v in kwargs.items():
            if hasattr(wizard, k):
                setattr(wizard, str(k), v)

    def create_object(self, relatives, object_name):
        config = self.__wizard.get_relatives(relatives)
        if not len(config):
            config = globals()[object_name]()
            self.__wizard.set_relatives(relatives, config)
        else:
            config = config[0]
        return config

    def wizard(self):
        return self.__wizard

    @staticmethod
    def transform_options(OptionsEum, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        value = [OptionsEum[x].value for x in Value]
        value = int(sum(value))
        return value

    def edit_options_of_kwargs(self, config, para, enum_, **kwargs):
        if para in kwargs.keys():
            value = kwargs[para]
            kwargs.pop(para)
            trans_value = self.transform_options(OptionsEum=enum_, Value=value)
            setattr(config, para, trans_value)
        return kwargs

    def expand(self):
        ExpandWizardCommand(WizardConfig=self.__wizard.handle).execute()
        return True

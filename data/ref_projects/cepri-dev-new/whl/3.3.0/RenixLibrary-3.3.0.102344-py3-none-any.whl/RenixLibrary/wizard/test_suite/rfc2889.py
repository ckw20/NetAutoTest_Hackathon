from .test_item import *


class Rfc2889AddressCachingCapacity(TestItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_address_learning_capacity(self,
                                       MinAddressCount=1,
                                       MaxAddressCount=65536,
                                       InitAddressCount=20480,
                                       Resolution=2,
                                       AgingTime=15,
                                       LearningRate=10000,
                                       ):
        config_address_learning_capacity(test_config=self.Item,
                                         min_address_count=MinAddressCount,
                                         max_address_count=MaxAddressCount,
                                         init_address_count=InitAddressCount,
                                         resolution=Resolution,
                                         aging_time=AgingTime,
                                         learning_rate=LearningRate,
                                         )
        return True


class Rfc2889AddressLearningRate(TestItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_address_learning_rate(self,
                                   MinRateCount=1488,
                                   MaxRateCount=1488,
                                   InitRateCount=1488,
                                   Resolution=2,
                                   AgingTime=15,
                                   AddressCount=1000,
                                   ):
        config_address_learning_rate(test_config=self.Item,
                                     min_rate_count=MinRateCount,
                                     max_rate_count=MaxRateCount,
                                     init_rate_count=InitRateCount,
                                     resolution=Resolution,
                                     aging_time=AgingTime,
                                     address_count=AddressCount)
        return True


class Rfc2889BoadcastForwarding(TestItem, Other1Item, Rfc2889Item):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc2889BroadcastLatency(TestItem):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc2889CongestionControl(TestItem, Other2Item, Rfc2889Item):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc2889ErroredFrameFilter(TestItem, Other2Item, Rfc2889Item):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_errored_frame_filtering(self,
                                     CrcTested=True,
                                     CrcFrameLength=64,
                                     UndersizedTested=True,
                                     UndersizedFrameLength=60,
                                     OversizedTested=True,
                                     OversizedFrameLength=1519,
                                     MaxLegalFrameLength=1518,
                                     BurstSize=1,
                                     ):
        config_errored_frame_filtering(test_config=self.Item,
                                       crc_tested=CrcTested,
                                       crc_frame_length=CrcFrameLength,
                                       undersized_tested=UndersizedTested,
                                       undersized_frame_length=UndersizedFrameLength,
                                       oversized_tested=OversizedTested,
                                       oversized_frame_length=OversizedFrameLength,
                                       max_legal_frame_length=MaxLegalFrameLength,
                                       burst_size=BurstSize)
        return True


class Rfc2889Forwarding(TestItem, Other1Item, Rfc2889Item):

    def __init__(self, Item):
        super().__init__(Item=Item)

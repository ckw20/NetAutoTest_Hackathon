from .mpls import *


class MplsL3Vpn(Mpls):

    def __init__(self, Wizard):
        super().__init__(Wizard=Wizard)
        self.__as_number_config = Wizard.get_children('AsNumberConfig')[0]

    @property
    def AsNumberConfig(self):
        return self.__as_number_config

    def edit_vpn_parameters(self, **kwargs):
        """
        config vpn parameters

        Keyword Args:
            WizardConfig (:obj:`WizardConfig`): wizard config
            NumberOfVpns (int): number of vpns
            RdAssignment (str): Route Target Assignment, support: UseRT、Manual
            RouteTargetStart (str): route target start (e.g. '1:0')
            RouteTargetStep (str): route target step (e.g. '1:0')

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        config_vpn_parameters(WizardConfig=self.Wizard, **kwargs)
        return True

    def edit_vpn_customer_parameters(self, **kwargs):
        """
        config vpn customer parameters

        Keyword Args:
            VpnAssignment (int): number of vpns
            CeProtocol (str): CE protocol type, params:
                BGP
                RIP
                ISIS
                OSPF
                Static
                Mixed
            CeProAssignment (str): CE protocol assignment (e.g. 'BGP=100%')
            CustomerRdStart (str): customer RD start (e.g. '1:0')
            CustomerRdStepPerVpnEnabled (bool): customer Rd step PerVpn enabled
            CustomerRdStepPerVpn (str): customer Rd step PerVpn (e.g. '1:0')
            CustomerRdStepPerCeEnabled (bool): customer Rd step PerCe enabled
            CustomerRdStepPerCe (str): customer Rd step PerCe (e.g. '0:0')

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        config_vpn_customer_parameters(WizardConfig=self.Wizard, **kwargs)
        return True

    def edit_vpn_provider_parameters(self, **kwargs):
        """
        config vpn provider parameters

        Keyword Args:
            ProviderDisSel (str): provider distribution selector, support: VPNsPerPE、PEsPerVPN
            ProviderDisSelCount (int): provider distribution selector count
            ProviderMeshed (bool): provider meshed
            ProviderRdStart (str): provider RD start (e.g. '1:0')
            ProviderRdStepPerVpnEnabled (bool): provider Rd step PerVpn enabled
            ProviderRdStepPerVpn (str): route target start (e.g. '1:0')
            ProviderRdStepPerCeEnabled (bool): provider Rd step PerCe enabled
            ProviderRdStepPerCe (str): provider Rd step PerCe (e.g. '0:0')

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        config_vpn_provider_parameters(WizardConfig=self.Wizard, **kwargs)
        return True

    def edit_vpn_as_number(self, **kwargs):
        """

        Keyword Args:
            CustomerEnable4ByteAsNumber (bool): Enable 4-Byte AS Number
            CustomerCeAsNumberStart (int): Start
            CustomerCeAsNumberStepPerVpnEnabled (bool): Step per VPN Enabled
            CustomerCeAsNumberStepPerVpn (str): Step per VPN
            CustomerCeAsNumberStepPerCeEnabled (bool): Step per CE Enabled
            CustomerCeAsNumberStepPerCe (int): Step per CE
            CustomerCe4ByteAsNumberStart (int): Start
            CustomerCe4ByteAsNumberStepPerVpnEnabled (bool): Step per VPN Enabled
            CustomerCe4ByteAsNumberStepPerVpn (int): Step per VPN
            CustomerCe4ByteAsNumberStepPerCeEnabled (bool): Step per CE Enabled
            CustomerCe4ByteAsNumberStepPerCe (int): Step per CE
            ProviderAppendCeAsToPath (str): Append CE AS to path
            ProviderEnable4ByteAsNumber (int): Enable 4-Byte AS Number
            ProviderCeAsNumberStart (int): Start
            ProviderCeAsNumberStepPerVpnEnabled (bool): Step per VPN Enabled
            ProviderCeAsNumberStepPerVpn (int): Step per VPN
            ProviderCeAsNumberStepPerCeEnabled (bool): Step per CE Enabled
            ProviderCeAsNumberStepPerCe (int): Step per CE
            ProviderCe4ByteAsNumberStart (int): Start
            ProviderCe4ByteAsNumberStepPerVpnEnabled (bool): Step per VPN Enabled
            ProviderCe4ByteAsNumberStepPerVpn (int): Step per VPN
            ProviderCe4ByteAsNumberStepPerCeEnabled (bool): Step per CE Enabled
            ProviderCe4ByteAsNumberStepPerCe (int): Step per CE

        Returns:
            (bool): True
        """
        self.AsNumberConfig.edit(**kwargs)
        return True

from .test_item import *


class Rfc3918MixedThroughput(TestItem, Other1Item, Rfc3918Item, Rfc3918Item1):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_multicast_traffic_ratio_loop(self, LoopMode='step', FixedRatio=10, MinRatio=10, MaxRatio=50, StartRatio=10,
                                          EndRatio=50, StepRatio=10, CustomRatio=(10, 20, 100)):
        config_multicast_traffic_ratio_loop(test_config=self.Item, loop_mode=LoopMode, fixed_ratio=FixedRatio, min_ratio=MinRatio,
                                            max_ratio=MaxRatio, start_ratio=StartRatio, end_ratio=EndRatio, step_ratio=StepRatio, custom_ratio=CustomRatio)
        return True

    def edit_mixed_throughput_unicast_streams(self, UnicastStreamHandles):
        config_mixed_throughput_unicast_streams(test_config=self.Item, unicast_stream_handles=UnicastStreamHandles)
        return True


class Rfc3918MulticastJoinLeaveLatency(TestItem, Other2Item, Rfc3918Item, Rfc3918Item1):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_multicast_join_leave_delay(self, DelayBetweenJoinAndStartStream=10, DelayBetweenJoinAndLeave=10):
        config_multicast_join_leave_delay(test_config=self.Item,
                                          delay_between_join_and_start_stream=DelayBetweenJoinAndStartStream,
                                          delay_between_join_and_leave=DelayBetweenJoinAndLeave)
        return True


class Rfc3918ScaledGroupForwarding(TestItem, Other2Item, Rfc3918Item, Rfc3918Item1):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc3918MulticastThroughput(TestItem, Other1Item, Rfc3918Item, Rfc3918Item1):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc3918Multicastlatency(TestItem, Other2Item, Rfc3918Item, Rfc3918Item1):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc3918MulticastLatency(TestItem, Other2Item, Rfc3918Item, Rfc3918Item1):

    def __init__(self, Item):
        super().__init__(Item=Item)


class Rfc3918MulticastGroupCapacity(TestItem, Other1Item, Other2Item, Rfc3918Item):

    def __init__(self, Item):
        super().__init__(Item=Item)

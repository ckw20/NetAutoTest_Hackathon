from .mpls import *


class MplsL2Vpn(Mpls):

    def __init__(self, Wizard):
        super().__init__(Wizard=Wizard)
        self.__as_number_config = None

    @property
    def AsNumberConfig(self):
        return self.__as_number_config

    def edit_host(self,
                  HostMacStart='00:00:01:00:00:01',
                  HostMacStep='00:00:00:00:00:01',
                  EnableOverlapHosts=False,
                  EnableHostVlan=False,
                  NumberOfCustomerSideVlanHeaders=1,
                  NumberOfProviderSideVlanHeaders=1,
                  VlanIdStart=100,
                  VlanIdStepPerVpls=1,
                  VlanIdStepPerPw=1,
                  VlanIdStepPerHost=0,
                  HostAssignmentVpls='HostsOrMacsPerCe',
                  HostAssignmentPw='HostsOrMacsPerCe',
                  HostsPerCustomerCe=1,
                  HostsPerProviderCe=1,
                  HostsPerVpls=100,
                  HostsPerPw=100,
                  CustomerHostPercent=50,
                  ProviderHostPercent=50):
        """
        Config Hosts

        Args:
            HostMacStart (str): Host MAC start
            HostMacStep (str): Host MAC step
            EnableOverlapHosts (bool): Enable overlap hosts
            EnableHostVlan (bool): Enable host VLAN
            NumberOfCustomerSideVlanHeaders (int): Number of customer side VLAN headers
            NumberOfProviderSideVlanHeaders (int): Number of provider side VLAN headers
            VlanIdStart (int): VLAN ID start
            VlanIdStepPerVpls (int): VLAN ID step per VPLS
            VlanIdStepPerPw (int): VLAN ID step per Pw
            VlanIdStepPerHost (int): VLAN ID step per host
            HostAssignmentVpls (str): Host assignment EnumMplsVplsHostAssignment
            HostAssignmentPw (str): Host assignment EnumMplsPweHostAssignment
            HostsPerCustomerCe (int): Host per customer CE
            HostsPerProviderCe (int): Host per provider CE
            HostsPerVpls (int): Host per VPLS
            HostsPerPw (int): Host per Pw
            CustomerHostPercent (int): Customer host percent
            ProviderHostPercent (int): Providier host percent

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """

        config_host(wizard_config=self.Wizard,
                    host_mac_start=HostMacStart,
                    host_mac_step=HostMacStep,
                    enable_overlap_hosts=EnableOverlapHosts,
                    enable_host_vlan=EnableHostVlan,
                    number_of_customer_side_vlan_headers=NumberOfCustomerSideVlanHeaders,
                    number_of_provider_side_vlan_headers=NumberOfProviderSideVlanHeaders,
                    vlan_id_start=VlanIdStart,
                    vlan_id_step_per_vpls=VlanIdStepPerVpls,
                    vlan_id_step_per_pw=VlanIdStepPerPw,
                    vlan_id_step_per_host=VlanIdStepPerHost,
                    host_assignment_vpls=EnumMplsVplsHostAssignment[HostAssignmentVpls],
                    host_assignment_pwe=EnumMplsPweHostAssignment[HostAssignmentPw],
                    hosts_per_customer_ce=HostsPerCustomerCe,
                    hosts_per_provider_ce=HostsPerProviderCe,
                    hosts_per_vpls=HostsPerVpls,
                    hosts_per_pw=HostsPerPw,
                    customer_host_percent=CustomerHostPercent,
                    provider_host_percent=ProviderHostPercent)
        return True

    def edit_fec128(self, StartVcId=1, StepVcId=1):
        """
        Config VPLS FEC128

        Args:
            StartVcId (int): Start vc id
            StepVcId (int): Step vc id

        Returns:
            (bool): True

        Raises:
            exception.ValueError

        """

        config_fec128(wizard_config=self.Wizard, start_vc_id=StartVcId, step_vc_id=StepVcId)
        return True

    def edit_fec129(self,
                    Agi='100:1',
                    AgiIncrement='0:1',
                    Saii='10.0.0.2',
                    SaiiIncrement='0.0.0.1',
                    Taii='10.0.0.1',
                    TaiiIncrement='0.0.0.0',
                    EnableBgpAutoDiscovery=False,
                    DutAsNumber=1,
                    RdAssignment=EnumMplsRdAssignment.UseRT,
                    AgiAssignment=EnumMplsAgiAssignment.UseRT,
                    Rt='1:0',
                    RtIncrement='0:1',
                    Rd='1:0',
                    RdIncrement='0:1'):
        """
        Config VPLS FEC129

        Args:
            Agi (str): AGI
            AgiIncrement (str): AGI increment
            Saii (str): SAII
            SaiiIncrement (str): SAII increment
            Taii (str): TAII
            TaiiIncrement (str): TAII increment
            EnableBgpAutoDiscovery (bool): Enable BGP auto discovery
            DutAsNumber (int): DUT AS number
            RdAssignment (str): RD assignment:
                UseRT
                Manual
            AgiAssignment (str): AGI assignment
                UseRT
                Manual
            Rt (str): RT
            RtIncrement (str): RT increment
            Rd (str): RD
            RdIncrement (str): RD increment

        Returns:
            (bool): True

        Raises:
            exception.ValueError

        """
        config_fec129(wizard_config=self.Wizard,
                      agi=Agi,
                      agi_increment=AgiIncrement,
                      saii=Saii,
                      saii_increment=SaiiIncrement,
                      taii=Taii,
                      taii_increment=TaiiIncrement,
                      enable_bgp_auto_discovery=EnableBgpAutoDiscovery,
                      dut_as_number=DutAsNumber,
                      rd_assignment=RdAssignment,
                      agi_assignment=AgiAssignment,
                      rt=Rt,
                      rt_increment=RtIncrement,
                      rd=Rd,
                      rd_increment=RdIncrement)
        return True

from .mpls_l2_vpn import *
from renix_py_api.mpls_wizard.ldp_vpls_api import *


class LdpVpls(MplsL2Vpn):

    def __init__(self, **kwargs):
        wizard_config = create_ldp_vpls_wizard_config(**kwargs)
        super().__init__(Wizard=wizard_config)
        self._wizard_type = 'ldp_vpls'

    def expand(self):
        ExpandWizardCommand(WizardConfig=self.Wizard.handle).execute()
        return True

    def edit_vpls_basic_parameters(self,
                                   NumberOfVpls=1,
                                   Mtu=1500,
                                   GroupId=0,
                                   EnableCBit=False,
                                   IncludeStatusTlv=False,
                                   StatusCode='PseudowireNotForwarding',
                                   EnableOverrideEncapsulation=False,
                                   Encapsulation=EnumMplsPseudowiresEncapsulation.EthernetVlan,
                                   VplsAssignment=EnumMplsAssignment.RoundRobin,
                                   ProviderDistributionSelector='VPLSsPerPE',
                                   ProviderDistributionSelectorCount=1,
                                   ProviderEnableAll=True,
                                   EnableCreateProviderHostsForUnusedVpls=False,
                                   FecType=EnumMplsFecType.FEC128):
        """
        Config basic parameters of VPLSs

        Args:
            NumberOfVpls (int): Number of VPLSs
            Mtu (int): MTU
            GroupId (int): Group ID
            EnableCBit (bool): Enable C-Bit
            IncludeStatusTlv (bool): Include status TLV
            StatusCode (list): Status code:
                PseudowireNotForwarding
                LocalAttachmentCircuitReceiveFault
                LocalAttachmentCircuitTransmitFault
                LocalPsnFacingPwIngressReceiveFault
                LocalPsnFacingPwEgressTransmitFault
            EnableOverrideEncapsulation (bool): Enable override encapsulation
            Encapsulation (str): Encapsulation
                EthernetVlan
                Ethernet
                EthernetVpls
            VplsAssignment (str): Vpls assginment:
                RoundRobin
                Sequential
            ProviderDistributionSelector (str): Distribution selector of provider side
            ProviderDistributionSelectorCount (int): Distribution selector count of provider side
            ProviderEnableAll (bool): enable All of provider side
            EnableCreateProviderHostsForUnusedVpls (bool): Enable Create provider hosts for unsued VPLS
            FecType (str): FEC type:
                FEC128
                FEC129

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        StatusCode = self.transform_options(OptionsEum=EnumMplsStatusCode, Value=StatusCode)
        config_vpls_basic_parameters(ldp_wizard_config=self.Wizard,
                                     number_of_vpls=NumberOfVpls,
                                     mtu=Mtu,
                                     group_id=GroupId,
                                     enable_c_bit=EnableCBit,
                                     include_status_tlv=IncludeStatusTlv,
                                     status_code=StatusCode,
                                     enable_override_encapsulation=EnableOverrideEncapsulation,
                                     encapsulation=Encapsulation,
                                     vpls_assignment=VplsAssignment,
                                     provider_distribution_selector=EnumMplsDistributionVplsSelector[ProviderDistributionSelector],
                                     provider_distribution_selector_count=ProviderDistributionSelectorCount,
                                     provider_enable_all=ProviderEnableAll,
                                     enable_create_provider_hosts_for_unused_vplss=EnableCreateProviderHostsForUnusedVpls,
                                     fec_type=FecType)
        return True

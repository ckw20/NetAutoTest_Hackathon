from renix_py_api.renix import *
from RenixLibrary.wizard.route_base import *


class IsisLspWizard(RouteWizard):

    def __init__(self, Sessions, **kwargs):
        RouteWizard.__init__(self,
                             Wizard='IsisLspWizardConfig',
                             Sessions=Sessions,
                             Relation='WizardSelectedIsis',
                             **kwargs)
        self.__wizard = self.wizard()
        # ipv4 internal distributor
        self.__ipv4_internal_distributor = self.create_object(relatives='IPv4InterDistrubutionGenerator',
                                                              object_name='DistributionRouteGenerator')
        # ipv4 external distributor
        self.__ipv4_external_distributor = self.create_object(relatives='IPv4ExterDistrubutionGenerator',
                                                              object_name='DistributionRouteGenerator')
        # ipv6 internal distributor
        self.__ipv6_internal_distributor = self.create_object(relatives='IPv6InterDistrubutionGenerator',
                                                              object_name='DistributionRouteGenerator')
        # ipv6 external distributor
        self.__ipv6_external_distributor = self.create_object(relatives='IPv6ExterDistrubutionGenerator',
                                                              object_name='DistributionRouteGenerator')

    @property
    def CreateLspLevel(self):
        return self.__wizard.CreateLspLevel

    @CreateLspLevel.setter
    def CreateLspLevel(self, value):
        self.__wizard.CreateLspLevel = value

    @property
    def IsAppended(self):
        return self.__wizard.IsAppended

    @IsAppended.setter
    def IsAppended(self, value):
        self.__wizard.IsAppended = value

    def config_network_topo(self, Type, **kwargs):
        self.__wizard.edit(TopologyType=Type)
        for k, v in kwargs.items():
            if k in ['TreeSimulatedRoutersCount',
                     'TreeInterfaceType',
                     'TreeMaxInterfacesPerRouter',
                     'TreeMaxRoutersPerTransitNetwork',
                     'GridSimulatedRoutersCount',
                     'GridSimulatedRoutersPerEmulatedRouter',
                     'GridNumberOfRows',
                     'GridNumberOfColumns',
                     'GridEmulatedRouterPosition',
                     'GridEmulatedRouterRowIndex',
                     'GridEmulatedRouterColumnIndex',
                     'MeshSimulatedRoutersCount',
                     'MeshSimulatedRoutersPerEmulatedRouter',
                     'MeshNumberOfRouters',
                     'MeshEmulatedRouterPosition',
                     'RingSimulatedRoutersCount',
                     'RingSimulatedRoutersPerEmulatedRouter',
                     'RingNumberOfRouters',
                     'RingEmulatedRouterPosition',
                     'HubSimulatedRoutersCount',
                     'HubSimulatedRoutersPerEmulatedRouter',
                     'HubNumberOfRouters',
                     'HubEmulatedRouterPosition']:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

    def config_isis(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['InterfaceStartIpv4Prefix',
                     'InterfaceEndIpv4Prefix',
                     'InterfaceStartIpv6Prefix',
                     'InterfaceEndIpv6Prefix',
                     'AdvertiseLoopbackAddress',
                     'EnableTrafficEngine',
                     'EnableSegmentRouting',
                     'EnableSegmentRoutingIPv6',
                     'EnableFlexAlgo',
                     'StartSystemId',
                     'SystemIdStep',
                     'StartRouterId',
                     'RouterIdStep',
                     'StartIPv6RouterId',
                     'RouterIdIPv6Step']:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

    def config_isis_te(self, **kwargs):
        te = self.__wizard.get_children('IsisTeWizardConfig')[0]
        for k, v in kwargs.items():
            if hasattr(te, k):
                setattr(te, str(k), v)
        return te

    def config_isis_sr(self, **kwargs):
        sr = self.__wizard.get_children('IsisSrWizardConfig')[0]
        kwargs = self.edit_options_of_kwargs(config=sr, para='CapabilityFlags', enum_=EnumIsisSrCapabilityFlags,
                                             **kwargs)
        kwargs = self.edit_options_of_kwargs(config=sr, para='NodeSidFlags', enum_=EnumIsisPrefixSidFlag, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=sr, para='NeighborSidFlags', enum_=EnumIsisAdjSidFlag, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=sr, para='AnycastSidFlags', enum_=EnumIsisPrefixSidFlag, **kwargs)
        for k, v in kwargs.items():
            if hasattr(sr, k):
                setattr(sr, str(k), v)
        return sr

    def config_isis_srv6(self, **kwargs):
        srv6 = self.__wizard.get_children('IsisSrv6WizardConfig')[0]
        kwargs = self.edit_options_of_kwargs(config=srv6, para='Flags', enum_=EnumIsisSrv6LocatorFlags, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=srv6, para='EndFlags', enum_=EnumSrv6EndSidFlags, **kwargs)
        for k, v in kwargs.items():
            if hasattr(srv6, k):
                setattr(srv6, str(k), v)
        return srv6

    def config_isis_flex_algorithm(self, **kwargs):
        flex_algo = self.__wizard.get_children('IsisFlexAlgoWizardConfig')[0]
        for k, v in kwargs.items():
            if hasattr(flex_algo, k):
                setattr(flex_algo, str(k), v)
        return flex_algo

    def config_ipv4_internal_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['Ipv4InternalAdvEmulatedRouters',
                     'Ipv4InternalAdvSimulatedRouter',
                     'Ipv4InternalTotalNumberOfRoutes',
                     'Ipv4InternalRoutesOverride',
                     'Ipv4InternalStartRoutesPrefix',
                     'Ipv4InternalEndRoutesPrefix',
                     'Ipv4InternalRoutesNoneSeq',
                     'Ipv4InternalRoutesPrefixLenStart',
                     'Ipv4InternalRoutesPrefixLenEnd',
                     'Ipv4InternalNarrowMetric',
                     'Ipv4InternalWideMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'Ipv4InternalRoutesPrefixLenType':
                setattr(self.__wizard, str(k), v)
                if v in ['INTERNET', 'CUSTOM']:
                    self.__ipv4_internal_distributor.DistributionType = v
            elif k == 'Ipv4InternalRoutesPrefixLenCustom':
                self.__ipv4_internal_distributor.CustomDistributionValue = v
            elif k == 'Ipv4InternalRoutesPrefixLenInternet':
                self.__ipv4_internal_distributor.InternetDistributionValue = v
        return self.__wizard

    def config_ipv4_external_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['Ipv4ExternalAdvEmulatedRouters',
                     'Ipv4ExternalAdvSimulatedRouter',
                     'Ipv4ExternalTotalNumberOfRoutes',
                     'Ipv4ExternalRoutesOverride',
                     'Ipv4ExternalStartRoutesPrefix',
                     'Ipv4ExternalEndRoutesPrefix',
                     'Ipv4ExternalRoutesNoneSeq',
                     'Ipv4ExternalRoutesPrefixLenStart',
                     'Ipv4ExternalRoutesPrefixLenEnd',
                     'Ipv4ExternalNarrowMetric',
                     'Ipv4ExternalWideMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'Ipv4ExternalRoutesPrefixLenType':
                setattr(self.__wizard, str(k), v)
                if v in ['INTERNET', 'CUSTOM']:
                    self.__ipv4_external_distributor.DistributionType = v
            elif k == 'Ipv4ExternalRoutesPrefixLenCustom':
                self.__ipv4_external_distributor.CustomDistributionValue = v
            elif k == 'Ipv4ExternalRoutesPrefixLenInternet':
                self.__ipv4_external_distributor.InternetDistributionValue = v
        return self.__wizard

    def config_ipv6_internal_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['Ipv6InternalAdvEmulatedRouters',
                     'Ipv6InternalAdvSimulatedRouter',
                     'Ipv6InternalTotalNumberOfRoutes',
                     'Ipv6InternalRoutesOverride',
                     'Ipv6InternalStartRoutesPrefix',
                     'Ipv6InternalEndRoutesPrefix',
                     'Ipv6InternalRoutesNoneSeq',
                     'Ipv6InternalRoutesPrefixLenStart',
                     'Ipv6InternalRoutesPrefixLenEnd',
                     'Ipv6InternalWideMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'Ipv6InternalRoutesPrefixLenType':
                setattr(self.__wizard, str(k), v)
                if v in ['INTERNET', 'CUSTOM']:
                    self.__ipv6_internal_distributor.DistributionType = v
            elif k == 'Ipv6InternalRoutesPrefixLenCustom':
                self.__ipv6_internal_distributor.CustomDistributionValue = v
            elif k == 'Ipv6InternalRoutesPrefixLenInternet':
                self.__ipv6_internal_distributor.InternetDistributionValue = v
        return self.__wizard

    def config_ipv6_external_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['Ipv6ExternalAdvEmulatedRouters',
                     'Ipv6ExternalAdvSimulatedRouter',
                     'Ipv6ExternalTotalNumberOfRoutes',
                     'Ipv6ExternalRoutesOverride',
                     'Ipv6ExternalStartRoutesPrefix',
                     'Ipv6ExternalEndRoutesPrefix',
                     'Ipv6ExternalRoutesNoneSeq',
                     'Ipv6ExternalRoutesPrefixLenStart',
                     'Ipv6ExternalRoutesPrefixLenEnd',
                     'Ipv6ExternalWideMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'Ipv6ExternalRoutesPrefixLenType':
                setattr(self.__wizard, str(k), v)
                if v in ['INTERNET', 'CUSTOM']:
                    self.__ipv6_external_distributor.DistributionType = v
            elif k == 'Ipv6ExternalRoutesPrefixLenCustom':
                self.__ipv6_external_distributor.CustomDistributionValue = v
            elif k == 'Ipv6ExternalRoutesPrefixLenInternet':
                self.__ipv6_external_distributor.InternetDistributionValue = v
        return self.__wizard


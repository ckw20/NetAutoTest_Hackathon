from renix_py_api.renix import *
from RenixLibrary.wizard.route_base import *


class BgpRouteWizard(RouteWizard):

    def __init__(self, Sessions, **kwargs):
        RouteWizard.__init__(self,
                             Wizard='BgpRouteWizardConfig',
                             Sessions=Sessions,
                             Relation='WizardSelectedBgps',
                             **kwargs)
        self.__wizard = self.wizard()
        # ipv4 prefix length distributor
        self.__ipv4_prefix_length_distributor = self.create_object(relatives='BGPIPv4DistrubutionGenerator',
                                                                   object_name='DistributionRouteGenerator')
        # ipv4 as path distributor
        self.__ipv4_as_path_distributor = self.create_object(relatives='BGPIPv4AsPathDistrubutionGenerator',
                                                             object_name='AsPathDistributionGenerator')
        # ipv6 prefix length distributor
        self.__ipv6_prefix_length_distributor = self.create_object(relatives='BGPIPv6DistrubutionGenerator',
                                                                   object_name='DistributionRouteGenerator')
        # ipv6 as path distributor
        self.__ipv6_as_path_distributor = self.create_object(relatives='BGPIPv6AsPathDistrubutionGenerator',
                                                             object_name='AsPathDistributionGenerator')

    @property
    def BgpRouteType(self):
        return self.__wizard.BgpRouteType

    @BgpRouteType.setter
    def BgpRouteType(self, value):
        self.__wizard.BgpRouteType = value

    @property
    def EnableLinkState(self):
        return self.__wizard.EnableLinkState

    @EnableLinkState.setter
    def EnableLinkState(self, value):
        self.__wizard.EnableLinkState = value

    def config_ipv4_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['TotalIpv4RouteCount',
                     'DuplicateIpv4Route',
                     'FirstRoute',
                     'LastRoute',
                     'IPv4DistributionType',
                     'PrefixLength',
                     'EndPrefixLength',
                     'UseSessionAddressAsNextHop',
                     'NextHop',
                     'NextHopStep',
                     'LocalPref',
                     'LocalPrefStep',
                     'EnableMed',
                     'MultExitDisc',
                     'MultExitDiscStep',
                     'Ipv4AsPathDistributionType',
                     'Ipv4AsPathSuffix',
                     'Ipv4AsPathIncrement',
                     'Ipv4SecondaryAsPathSuffix',
                     'Ipv4SecondaryAsPathIncrement']:
                setattr(self.__wizard, str(k), v)
            elif k == 'CustomPrefixLength':
                self.__ipv4_prefix_length_distributor.CustomDistributionValue = v
            elif k == 'InternetPrefixLength':
                self.__ipv4_prefix_length_distributor.InternetDistributionValue = v
            elif k == 'CustomAsPath':
                self.__ipv4_as_path_distributor.CustomDistributionValue = v
            elif k == 'InternetAsPath':
                self.__ipv4_as_path_distributor.InternetDistributionValue = v
        return self.__wizard

    def config_ipv6_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['TotalIpv6RouteCount',
                     'DuplicateIpv6Route',
                     'FirstIpv6Route',
                     'LastIpv6Route',
                     'IPv6DistributionType',
                     'Ipv6PrefixLength',
                     'EndIpv6PrefixLength',
                     'CustomPrefixLength',
                     'InternetPrefixLength',
                     'Ipv6RouteUseSessionAddressAsNextHop',
                     'Ipv6NextHop',
                     'Ipv6NextHopStep',
                     'Ipv6RouteLocalPref',
                     'Ipv6RouteLocalPrefStep',
                     'Ipv6RouteEnableMed',
                     'Ipv6RouteMultExitDisc',
                     'Ipv6RouteMultExitDiscStep',
                     'Ipv6AsPathDistributionType',
                     'CustomAsPath',
                     'InternetAsPath',
                     'Ipv6AsPathSuffix',
                     'Ipv6AsPathIncrement',
                     'Ipv6SecondaryAsPathSuffix',
                     'Ipv6SecondaryAsPathIncrement']:
                setattr(self.__wizard, str(k), v)
            elif k == 'CustomPrefixLength':
                self.__ipv6_prefix_length_distributor.CustomDistributionValue = v
            elif k == 'InternetPrefixLength':
                self.__ipv6_prefix_length_distributor.InternetDistributionValue = v
            elif k == 'CustomAsPath':
                self.__ipv6_as_path_distributor.CustomDistributionValue = v
            elif k == 'InternetAsPath':
                self.__ipv6_as_path_distributor.InternetDistributionValue = v
        return self.__wizard

    def config_igp_topo(self, **kwargs):
        link_state = self.__wizard.get_children('BgpLinkStateRouteWizardConfig')[0]
        for k, v in kwargs.items():
            if k in ['ProtocolType',
                     'NumberOfArea',
                     'Topology',
                     'BackboneHeadendRouters',
                     'CoreRouterNum',
                     'BackboneRows',
                     'BackboneColumns',
                     'ABRNumber',
                     'IntraTopology',
                     'NonBackboneHeadendRouters',
                     'NonBackboneRows',
                     'NonBackboneColumns',
                     'TotalIntraRouters',
                     'InterfaceType',
                     'MaxInterfacePerRouter',
                     'MaxRouterPerTransit']:
                setattr(link_state, str(k), v)
        return link_state

    def config_igp(self, **kwargs):
        link_state = self.__wizard.get_children('BgpLinkStateRouteWizardConfig')[0]
        for k, v in kwargs.items():
            if k in ['Ipv4Prefix',
                     'EndIpv4Prefix',
                     'Ipv4PrefixLength',
                     'StartSystemId',
                     'SystemIdStep',
                     'EnableAdvLoopback',
                     'RouterId',
                     'RouterIdStep',
                     'EnableIGPmetric',
                     'IgpMetricTypeIsis',
                     'IgpMetricTypeOspf',
                     'EnableSegmentRouting',
                     'Algorithm',
                     'SidLabelType',
                     'SidLabelBase',
                     'SidLabelRange',
                     'LinkAdjSidLabel',
                     'PrefixAdjSidLabel',
                     'SidLabelStep',
                     'EnableTeOptions',
                     'EnableVaryheaderendMetric',
                     'HeaderendMetricEnableIGPMetric',
                     'HeaderendMetricEnableSegmentRoutingWeight',
                     'HeaderendMetricEnablePrefixMetric',
                     'EnableReservableStep',
                     'ReservableStep',
                     'EnableUnreserved',
                     'UnreservedBandwidth0',
                     'UnreservedBandwidth1',
                     'UnreservedBandwidth2',
                     'UnreservedBandwidth3',
                     'UnreservedBandwidth4',
                     'UnreservedBandwidth5',
                     'UnreservedBandwidth6',
                     'UnreservedBandwidth7']:
                setattr(link_state, str(k), v)
        return link_state

    def config_link_state_route_te(self, **kwargs):
        link_state = self.__wizard.get_children('BgpLinkStateRouteWizardConfig')[0]
        te_config = BgpLsTeLinkConfig()
        link_state.set_relatives('TrafficEngineeringRelation', te_config)
        for k, v in kwargs.items():
            if hasattr(te_config, k):
                setattr(te_config, str(k), v)
        return te_config


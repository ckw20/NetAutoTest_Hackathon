from .mpls_l2_vpn import *
from renix_py_api.mpls_wizard.bgp_vpls_api import *

class BgpVpls(MplsL2Vpn):

    def __init__(self, **kwargs):
        wizard_config = create_bgp_vpls_wizard_config(**kwargs)
        super().__init__(Wizard=wizard_config)
        self._wizard_type = 'bgp_vpls'

    def expand(self):
        ExpandWizardCommand(WizardConfig=self.Wizard.handle).execute()
        return True

    def edit_bgp_vpls(self,
                      NumberOfVplss=1,
                      RdAssignment=EnumMplsRdAssignment.UseRT,
                      RouteTargetStart='1:0',
                      RouteTargetStep='1:0',
                      Mtu=1500,
                      VplsAssignment=EnumMplsAssignment.RoundRobin,
                      CustomerRdStart='1:0',
                      CustomerVeIdStart=0,
                      CustomerStepPerVplsEnabled=True,
                      CustomerRdStepPerVpls='1:0',
                      CustomerStepPerCeEnabled=False,
                      CustomerRdStepPerCe='0:0',
                      CustomerVeIdStepPerCe=1,
                      CustomerOverlapEnabled=False,
                      ProviderDistributionSelector=EnumMplsDistributionVplsSelector.VPLSsPerPE,
                      ProviderDistributionSelectorCount=1,
                      ProviderMeshed=True,
                      ProviderRdStart='1:0',
                      ProviderVeIdStart=1,
                      ProviderStepPerVplsEnabled=True,
                      ProviderRdStepPerVpls='1:0',
                      ProviderStepPerCeEnabled=False,
                      ProviderRdStepPerCe='1:0',
                      ProviderVeIdStepPerCe=1,
                      ProviderOverlapEnabled=False
                      ):
        config_vpls(bgp_wizard_config=self.Wizard,
                    number_of_vpls=NumberOfVplss,
                    rd_assignment=RdAssignment,
                    rt_start=RouteTargetStart,
                    rt_step=RouteTargetStep,
                    mtu=Mtu,
                    vpls_assignment=VplsAssignment,
                    customer_rd_start=CustomerRdStart,
                    customer_ve_id_start=CustomerVeIdStart,
                    customer_enable_step_per_vpls=CustomerStepPerVplsEnabled,
                    customer_rd_step_per_vpls=CustomerRdStepPerVpls,
                    customer_enable_step_per_ce=CustomerStepPerCeEnabled,
                    customer_rd_step_per_ce=CustomerRdStepPerCe,
                    customer_ve_id_step_per_ce=CustomerVeIdStepPerCe,
                    customer_enable_overlap_ve_id_on_diff_vpls=CustomerOverlapEnabled,
                    provider_distribution_selector=ProviderDistributionSelector,
                    provider_distribution_selector_count=ProviderDistributionSelectorCount,
                    provider_enable_all=ProviderMeshed,
                    provider_rd_start=ProviderRdStart,
                    provider_ve_id_start=ProviderVeIdStart,
                    provider_enable_step_per_vpls=ProviderStepPerVplsEnabled,
                    provider_rd_step_per_vpls=ProviderRdStepPerVpls,
                    provider_enable_step_per_ce=ProviderStepPerCeEnabled,
                    provider_rd_step_per_ce=ProviderRdStepPerCe,
                    provider_ve_id_step_per_ce=ProviderVeIdStepPerCe,
                    provider_enable_overlap_ve_id_on_diff_vpls=ProviderOverlapEnabled
                    )
        return True
from renix_py_api.renix import *
from renix_py_api.mpls_wizard.mpls_l3vpn_api import *
from renix_py_api.mpls_wizard.mpls_base_api import *


class Mpls:

    def __init__(self, Wizard):
        self.__wizard = Wizard
        self._wizard_type = None
        self._route_reflector = None
        self._mpls_protocol = None

    @property
    def Wizard(self):
        return self.__wizard

    @property
    def RouteReflector(self):
        return self._route_reflector

    @property
    def MplsProtocol(self):
        return self._mpls_protocol

    @staticmethod
    def transform_options(OptionsEum, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        value = [OptionsEum[x].value for x in Value]
        value = int(sum(value))
        return value

    def expand(self):
        execute_expand_wizard(self.Wizard)
        return True

    def edit_provider_port(self,
                           Port,
                           PortIndex=0,
                           EnableSubInterface=False,
                           SubInterfaceCount=1,
                           DutIpv4Address='192.85.1.1',
                           DutIpv4AddressStep='0.0.1.0',
                           Ipv4PrefixLength=24,
                           VlanId=1,
                           VlanIdStep=1):
        config_provider_port(wizard_config=self.Wizard,
                             port=Port,
                             port_index=int(PortIndex),
                             enable_sub_interface=EnableSubInterface,
                             sub_interface_count=SubInterfaceCount,
                             dut_ipv4_address=DutIpv4Address,
                             dut_ipv4_address_step=DutIpv4AddressStep,
                             ipv4_prefix_length=Ipv4PrefixLength,
                             vlan_id=VlanId,
                             vlan_id_step=VlanIdStep)
        return True

    def edit_customer_port(self,
                           Port,
                           PortIndex=0,
                           EnableSubInterface=False,
                           SubInterfaceCount=1,
                           DutIpv4Address='192.85.1.1',
                           DutIpv4AddressStep='0.0.1.0',
                           Ipv4PrefixLength=24,
                           DutIpv6Address='::',
                           DutIpv6AddressStep='0:0:0:1::',
                           Ipv6PrefixLength=64,
                           VlanId=1,
                           VlanIdStep=1):
        config_customer_port(wizard_config=self.Wizard,
                             port=Port,
                             port_index=int(PortIndex),
                             enable_sub_interface=EnableSubInterface,
                             sub_interface_count=SubInterfaceCount,
                             dut_ipv4_address=DutIpv4Address,
                             dut_ipv4_address_step=DutIpv4AddressStep,
                             ipv4_prefix_length=Ipv4PrefixLength,
                             dut_ipv6_address=DutIpv6Address,
                             dut_ipv6_address_step=DutIpv6AddressStep,
                             ipv6_prefix_length=Ipv6PrefixLength,
                             vlan_id=VlanId,
                             vlan_id_step=VlanIdStep)
        return True

    def edit_provider_router_basic_parameters(self,
                                              DutRouterId='10.0.0.1',
                                              DutAsNumber=1,
                                              Enable4ByteDutAs=False,
                                              FourByteDutAsNumber='1:1',
                                              IgpProtocol='OSPF',
                                              MplsProtocol='LDP',
                                              EnablePRouter=True,
                                              PRoutersPerInterface=1,
                                              TopologyType='Tree',
                                              PRouterStartIp='1.0.0.1',
                                              PRouterPrefixLength=24,
                                              PRouterIdStart='192.0.1.1',
                                              PRouterIdStep='0.0.1.0',
                                              PeRoutersPerInterface=1,
                                              PeRouterIdStart='10.0.0.2',
                                              PeRouterIdStep='0.0.0.1',
                                              EnableRouteReflectors=None,
                                              Enable6Vpe=None
                                              ):

        config_provider_router_basic_parameters(wizard_config=self.Wizard,
                                                dut_router_id=DutRouterId,
                                                dut_as_number=DutAsNumber,
                                                enable_4byte_dut_as=Enable4ByteDutAs,
                                                four_byte_dut_as_number=FourByteDutAsNumber,
                                                igp_protocol=EnumMplsIgpProtocols[IgpProtocol],
                                                mpls_protocol=EnumMplsMplsProtocols[MplsProtocol],
                                                enable_p_router=EnablePRouter,
                                                p_routers_per_interface=PRoutersPerInterface,
                                                topology_type=TopologyType,
                                                p_router_start_ip=PRouterStartIp,
                                                p_router_prefix_length=PRouterPrefixLength,
                                                p_router_id_start=PRouterIdStart,
                                                p_router_id_step=PRouterIdStep,
                                                pe_routers_per_interface=PeRoutersPerInterface,
                                                pe_router_id_start=PeRouterIdStart,
                                                pe_router_id_step=PeRouterIdStep)
        if EnableRouteReflectors is not None:
            self.Wizard.edit(EnableRouteReflectors=EnableRouteReflectors)
            self._route_reflector = self.Wizard.get_children(relative_name=RouteReflectorConfig.__name__)[0]
        if Enable6Vpe is not None:
            self.Wizard.edit(Enable6Vpe=Enable6Vpe)
        self._mpls_protocol = MplsProtocol.lower()
        return True

    @staticmethod
    def edit_provider_router_mpls_ldp(HelloType=EnumHelloType.DIRECT,
                                      TransportAddressTlvMode=EnumTransportMode.TESTER_IP,
                                      LabelAdvertisementMode=EnumLabelAdvertType.DU,
                                      EgressLabelMode=EnumEgressLabel.NEXT_AVAILABLE,
                                      MinLabel=16,
                                      AuthenticationMode=EnumAuthentication.NONE,
                                      Password='Xinertel'):
        """
        Config the MPLS LDP protocol for provider routers

        Args:
            HelloType (str): Hello type:
                DIRECT
                TARGETED
                DIRECT_TARGETED
            TransportAddressTlvMode (str): Transport address TLV mode
                TESTER_IP
                ROUTER_ID
                NONE
            LabelAdvertisementMode (str): Label advertisement mode:
                DU
                DOD
            EgressLabelMode (str): Egress label mode:
                NEXT_AVAILABLE
                IMPLICIT
                EXPLICIT
            MinLabel (int): Min Label
            AuthenticationMode (str): Authentication mode:
                NONE
                MD5
            Password (str): Password

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        config_provider_router_mpls_ldp(hello_type=HelloType,
                                        transport_address_tlv_mode=TransportAddressTlvMode,
                                        label_advertisement_mode=LabelAdvertisementMode,
                                        egress_label_mode=EgressLabelMode,
                                        min_label=MinLabel,
                                        authentication_mode=AuthenticationMode,
                                        password=Password)
        return True

    def edit_provider_router_igp_ospf(self,
                                      AreaId='0.0.0.0',
                                      NetworkType='BROADCAST',
                                      RouterPriority=0,
                                      AuthenticationType='NONE',
                                      Password='Xinertel',
                                      Md5Key=1,
                                      Options=['EBIT'],
                                      EnableGracefulRestart=False,
                                      GracefulRestartReason='UNKNOWN',
                                      EnableBfd=False,
                                      Algorithm=0,
                                      SidLabelBase=100,
                                      SidLabelRange=100,
                                      NodeSidIndex=0,
                                      NodeSidIdnexStep=1
                                      ):
        """
        Config the IGP OSPF protocol for provider routers

        Args:
            AreaId (str): Area ID
            NetworkType (str): Network type: BROADCAST or P2P
            RouterPriority (int): Router priority
            AuthenticationType (str): Authentication type
                NONE
                SIMPLE
                MD5
            Password (str): Password
            Md5Key (int): MD5 key
            Options (list): Options:
                NONTBIT
                TOSBIT
                EBIT
                MCBIT
                NPBIT
                EABIT
                DCBIT
                OBIT
                DNBIT
            EnableGracefulRestart (bool): Enable graceful restart
            GracefulRestartReason (str): Gracefull restart reason:
                UNKNOWN
                SOFTWARE
                RELOADORUPGRADE
                SWITCH
            EnableBfd (bool): Enable BFD
            Algorithm (int): SR algorithm
            SidLabelBase (int): SR SID/Label base
            SidLabelRange (int): SR SID/Label range
            NodeSidIndex (int): SR node SID index
            NodeSidIdnexStep (int): SR node SID index step

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """

        Options = self.transform_options(OptionsEum=EnumOspfv2OptionBit, Value=Options)
        if self.MplsProtocol == 'ldp':
            config_provider_router_igp_ospf(area_id=AreaId,
                                            network_type=NetworkType,
                                            router_priority=RouterPriority,
                                            authentication_type=AuthenticationType,
                                            password=Password,
                                            md5_key=Md5Key,
                                            options=Options,
                                            enable_graceful_restart=EnableGracefulRestart,
                                            graceful_restart_reason=GracefulRestartReason,
                                            enable_bfd=EnableBfd)
        else:
            config_provider_router_mpls_ospf_sr(area_id=AreaId,
                                                network_type=NetworkType,
                                                router_priority=RouterPriority,
                                                authentication_type=AuthenticationType,
                                                password=Password,
                                                md5_key=Md5Key,
                                                options=Options,
                                                enable_graceful_restart=EnableGracefulRestart,
                                                graceful_restart_reason=GracefulRestartReason,
                                                enable_bfd=EnableBfd,
                                                algorithm=Algorithm,
                                                sid_label_base=SidLabelBase,
                                                sid_label_range=SidLabelRange,
                                                node_sid_index=NodeSidIndex,
                                                node_sid_idnex_step=NodeSidIdnexStep)
        return True

    def edit_provider_router_igp_isis(self,
                                      UseSrcMacAsSystemId=True,
                                      SystemId='00:00:00:00:00:01',
                                      SystemIdStep='00:00:00:00:00:01',
                                      Level=EnumLevel.L2,
                                      NetworkType=EnumNetworkType.BROADCAST,
                                      RouterPriority=0,
                                      MetricMode=EnumMetricMode.NARROWWIDE,
                                      AuthenticationMode=EnumAuthMethod.NONE,
                                      Password='Xinertel',
                                      AreaId=[0x10],
                                      EnableGracefulRestart=False,
                                      MultiTopologyId=['NOSHOW'],
                                      EnableBfd=False,
                                      HelloPadding=True,
                                      Algorithm=0,
                                      SidLabelBase=100,
                                      SidLabelRange=100,
                                      NodeSidIndex=0,
                                      NodeSidIdnexStep=1
                                      ):
        """
        Config the IGP ISIS protocol for provider routers

        Args:
            UseSrcMacAsSystemId (bool): Use source MAC as system id
            SystemId (str): System ID
            SystemIdStep (str): System ID step
            Level (str): Level:
                L1
                L2
                L1L2
            NetworkType (str): Network type
                BROADCAST
                P2P
            RouterPriority (int): Router priority
            MetricMode (str): Metric mode
                NARROW
                WIDE
                NARROWWIDE
            AuthenticationMode (str): Authentication mode
                NONE
                SIMPLE
                MD5
            Password (str): Password
            AreaId (list): Area ID, hex int
            EnableGracefulRestart (bool): Enable graceful restart
            MultiTopologyId (str): Multi-topology ID
                NOSHOW
                IPV4
                IPV6
            EnableBfd (bool): Enable BFD
            HelloPadding (bool): Enable hello padding
            Algorithm (int): SR algorithm
            SidLabelBase (int): SR SID/Label base
            SidLabelRange (int): SR SID/Label range
            NodeSidIndex (int): SR node SID index
            NodeSidIdnexStep (int): SR node SID index step

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """

        MultiTopologyId = self.transform_options(OptionsEum=EnumMtIdBit, Value=MultiTopologyId)
        if self.MplsProtocol == 'ldp':
            config_provider_router_igp_isis(use_src_mac_as_system_id=UseSrcMacAsSystemId,
                                            system_id=SystemId,
                                            system_id_step=SystemIdStep,
                                            level=Level,
                                            network_type=NetworkType,
                                            router_priority=RouterPriority,
                                            metric_mode=MetricMode,
                                            authentication_mode=AuthenticationMode,
                                            password=Password,
                                            area_id=AreaId,
                                            enable_graceful_restart=EnableGracefulRestart,
                                            multi_topology_id=MultiTopologyId,
                                            enable_bfd=EnableBfd,
                                            hello_padding=HelloPadding)
        else:
            config_provider_router_mpls_isis_sr(use_src_mac_as_system_id=UseSrcMacAsSystemId,
                                                system_id=SystemId,
                                                system_id_step=SystemIdStep,
                                                level=Level,
                                                network_type=NetworkType,
                                                router_priority=RouterPriority,
                                                metric_mode=MetricMode,
                                                authentication_mode=AuthenticationMode,
                                                password=Password,
                                                area_id=AreaId,
                                                enable_graceful_restart=EnableGracefulRestart,
                                                multi_topology_id=MultiTopologyId,
                                                enable_bfd=EnableBfd,
                                                hello_padding=HelloPadding,
                                                algorithm=Algorithm,
                                                sid_label_base=SidLabelBase,
                                                sid_label_range=SidLabelRange,
                                                node_sid_index=NodeSidIndex,
                                                node_sid_idnex_step=NodeSidIdnexStep)

        return True

    @staticmethod
    def edit_provider_router_igp_rip(RipVersion=EnumRipVersion.RIPV2,
                                     UpdateType=EnumUpdateType.MULTICAST,
                                     UpdateInterval=30,
                                     UpdateJitter=0,
                                     MaxRouteNumPerUpdate=25,
                                     AuthenticationMode=EnumRipAuthMethod.NONE,
                                     Password='Xinertel',
                                     Md5KeyId=1,
                                     SplitHorizon=False):
        """
        Config the IGP RIP protocol for provider routers

        Args:
            RipVersion (str): RIP version:
                RIPV1
                RIPV2
                RIPNG
            UpdateType (str): Update type:
                BROADCAST
                MULTICAST
                UNICAST
            UpdateInterval (int): Update interval(sec)
            UpdateJitter (int): Update jitter
            MaxRouteNumPerUpdate (int): Max route per update
            AuthenticationMode (str): Authentication mode:
                NONE
                SIMPLE
                MD5
            Password (str): Password
            Md5KeyId (int): MD5 key ID
            SplitHorizon (bool): Enable split horizon

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """

        config_provider_router_igp_rip(rip_version=RipVersion,
                                       update_type=UpdateType,
                                       update_interval=UpdateInterval,
                                       update_jitter=UpdateJitter,
                                       max_route_num_per_update=MaxRouteNumPerUpdate,
                                       authentication_mode=AuthenticationMode,
                                       password=Password,
                                       md5_key_id=Md5KeyId,
                                       split_horizon=SplitHorizon)
        return True

    def edit_provider_route_reflector(self, **kwargs):
        self.RouteReflector.edit(**kwargs)

    def edit_traffic_parameters(self, **kwargs):
        """
        config traffic parameters

        Keyword Args:
            TrafficFlow (str): traffic flow type, support:
                None
                FullyMeshedInVpn
                FullyMeshedInVpls
                Customer2Provider
                Provider2Customer
                CustomerProviderBoth
            StreamBlockGrouping (str): streamblock grouping type, support:
                Aggregate
                VPNAggregate
                NotAggregate
            UseSingleStreamNumber (bool): use single stream number
            TrafficLoadPercentProvider (int): traffic load percent provider
            TrafficLoadPercentCustomer (bool): traffic load percent customer

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        config_traffic_parameters(WizardConfig=self.Wizard, **kwargs)
        return True

    def edit_lsp_ping(self,
                      EnableLspPing=False,
                      DestinationIpv4Address='127.0.0.1',
                      PingInterval=4,
                      PingTimeout=2,
                      TimeToLive=255,
                      LspExpValue=0,
                      ValidateFecStack=False,
                      PadMode=EnumMplsPadMode.TransmitWithoutPadTlv,
                      PadData=[],
                      ):
        config_lsp_ping(wizard_config=self.Wizard,
                        enable_lsp_ping=EnableLspPing,
                        destination_ipv4_address=DestinationIpv4Address,
                        ping_interval=PingInterval,
                        ping_timeout=PingTimeout,
                        time_to_live=TimeToLive,
                        lsp_exp_value=LspExpValue,
                        validate_fec_stack=ValidateFecStack,
                        pad_mode=PadMode,
                        pad_data=PadData)
        return True

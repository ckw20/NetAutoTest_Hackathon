from .rfc2544 import *
from .rfc2889 import *
from .rfc3918 import *


MAP_BENCHMARK_ITEM = {
    'throughput': 'Rfc2544Throughput',
    'backtoback': 'Rfc2544BackToBack',
    'frameloss': 'Rfc2544FrameLoss',
    'latency': 'Rfc2544Latency',
    'addresscachingcapacity': 'Rfc2889AddressCachingCapacity',
    'addresslearningrate': 'Rfc2889AddressLearningRate',
    'broadcastlatency': 'Rfc2889BroadcastLatency',
    'broadcastforwarding': 'Rfc2889BoadcastForwarding',
    'congestioncontrol': 'Rfc2889CongestionControl',
    'erroredframefilter': 'Rfc2889ErroredFrameFilter',
    'forwarding': 'Rfc2889Forwarding',
    'mixedthroughput': 'Rfc3918MixedThroughput',
    'scaledgroupforwarding': 'Rfc3918ScaledGroupForwarding',
    'multicastthroughput': 'Rfc3918MulticastThroughput',
    'multicastgroupcapacity': 'Rfc3918MulticastGroupCapacity',
    'multicastlatency': 'Rfc3918MulticastLatency',
    'multicastjoinleavelatency': 'Rfc3918MulticastJoinLeaveLatency',
}


class Wizard:

    def __init__(self, Wizard):
        self._wizard = Wizard

    @property
    def handle(self):
        return self._wizard.handle

    @property
    def Wizard(self):
        return self._wizard

    @staticmethod
    def create_benchmark(Type='rfc2544', Items=None):
        if Items is None:
            Items = ['throughput', 'backtoback', 'frameloss', 'latency']
        if not isinstance(Items, (list, set, tuple)):
            Items = [Items]
        wizard, items = get_benchmark_wizard_config(benchmark_test=Type.lower(), test_items=Items)
        itemObjects = []
        for i, x in zip(Items, items):
            className = MAP_BENCHMARK_ITEM[i.lower()]
            itemObjects.append(globals()[className](Item=x))
        return Wizard(Wizard=wizard), itemObjects

    def relate_ports(self, Ports):
        relate_ports(wizard_config=self.Wizard, ports=Ports)
        return True

    def create_streams(self,
                       Items,
                       Type,
                       SrcPoints,
                       DstPoints,
                       Bidirectional=False,
                       Mode='1v1',
                       Mapping='roundrobin',
                       Monitors=()):
        if not isinstance(Items, (list, set, tuple)):
            Items = [Items]
        if not isinstance(Monitors, (list, set, tuple)):
            Monitors = [Monitors]
        create_streams(wizard_config=self.Wizard,
                       test_items=Items,
                       stream_type=Type,
                       src_endpoints=SrcPoints,
                       dst_endpoints=DstPoints,
                       bidirectional=Bidirectional,
                       mesh_mode=Mode,
                       endpoint_mapping=Mapping,
                       monitor_ports=Monitors)
        return True

    def use_stream_exist(self, Streams):
        if not isinstance(Streams, list):
            Streams = [Streams]
        create_streams_using_exist(wizard_config=self.Wizard, stream_handles=[x.handle for x in Streams])
        return True

    def expand_benchmark(self):
        ExpandWizardCommand(WizardConfig=self.handle).execute()
        return True

    @staticmethod
    def del_benchmark():
        clear_smart_scripter_commands()
        return True

from renix_py_api.renix import *
from RenixLibrary.wizard.route_base import *


class RipRouteWizard(RouteWizard):

    def __init__(self, Sessions, **kwargs):
        RouteWizard.__init__(self,
                             Wizard='RipRouteWizardConfig',
                             Sessions=Sessions,
                             Relation='WizardSelectedRip',
                             **kwargs)
        self.__wizard = self.wizard()

    def config_ipv4_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in [
                'Ipv4TotalNumberOfRoutes',
                'Ipv4StartRoutesPrefix',
                'Ipv4EndRoutesPrefix',
                'Ipv4RoutesNoneSeq',
                'Ipv4RoutesPrefixLenType',
                'Ipv4RoutesPrefixLenStart',
                'Ipv4RoutesPrefixLenEnd',
                'Ipv4Metric',
                'NextHop'
            ]:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

    def config_ipv6_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['Ipv6TotalNumberOfRoutes',
                     'Ipv6StartRoutesPrefix',
                     'Ipv6EndRoutesPrefix',
                     'Ipv6RoutesNoneSeq',
                     'Ipv6RoutesPrefixLenType',
                     'Ipv6RoutesPrefixLenStart',
                     'Ipv6RoutesPrefixLenEnd',
                     'Ipv6Metric'
                     ]:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

from .mpls_l2_vpn import *
from renix_py_api.mpls_wizard.pwe_api import *


class Pwe(MplsL2Vpn):

    def __init__(self):
        wizard_config = create_pwe_wizard_config()
        super().__init__(Wizard=wizard_config)
        self._wizard_type = 'pwe'

    def expand(self):
        ExpandWizardCommand(WizardConfig=self.Wizard.handle).execute()
        return True

    def edit_pwe_basic_parameters(self,
                                  NumberOfPseudoWire=1,
                                  Mtu=1500,
                                  GroupId=0,
                                  EnableCBit=False,
                                  IncludeStatusTlv=False,
                                  StatusCode='PseudowireNotForwarding',
                                  EnableOverrideEncapsulation=False,
                                  Encapsulation=EnumMplsPseudowiresEncapsulation.EthernetVlan,
                                  EnableOverlapVcidsOnDifferentPes=False,
                                  EnableCreateProviderHostsForUnusedVpls=False,
                                  FecType=EnumMplsFecType.FEC128):
        """
        Config basic parameters of pseudowires

        Args:
            NumberOfPseudoWire (int): Number of pseudowire
            Mtu (int): MTU
            GroupId (int): Group ID
            EnableCBit (bool): Enable C-Bit
            IncludeStatusTlv (bool): Include status TLV
            StatusCode (str): Status code
            EnableOverrideEncapsulation (bool): Enable override encapsulation
            Encapsulation (str): Encapsulation
            EnableOverlapVcidsOnDifferentPes (bool): Enable overlap VC IDs on different PEs
            EnableCreateProviderHostsForUnusedVpls (bool): Enable Create provider hosts for unsued VPLSs
            FecType (str): FEC type

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        StatusCode = self.transform_options(OptionsEum=EnumMplsStatusCode, Value=StatusCode)
        config_pw_basic_parameters(pwe_wizard_config=self.Wizard,
                                   number_of_pseudowire=NumberOfPseudoWire,
                                   mtu=Mtu,
                                   group_id=GroupId,
                                   enable_c_bit=EnableCBit,
                                   include_status_tlv=IncludeStatusTlv,
                                   status_code=StatusCode,
                                   enable_override_encapsulation=EnableOverrideEncapsulation,
                                   encapsulation=Encapsulation,
                                   enable_overlap_vcids_on_different_pes=EnableOverlapVcidsOnDifferentPes,
                                   enable_create_provider_hosts_for_unused_vplss=EnableCreateProviderHostsForUnusedVpls,
                                   fec_type=FecType)
        return True

from renix_py_api.benchmark_test.benchmark_test_api import *


class BaseItem:

    def __init__(self, Item):
        self._item = Item

    @property
    def handle(self):
        return self._item.handle

    @property
    def Item(self):
        return self._item


class TestItem(BaseItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_frame(self,
                   Type='custom',
                   Length=128,
                   Min=128,
                   Max=256,
                   Start=128,
                   End=256,
                   Step=128,
                   Custom=None,
                   ImixTemplates=(),
                   ):
        if not isinstance(ImixTemplates, (list, set, tuple)):
            ImixTemplates = [ImixTemplates]
        if Custom is None:
            Custom = (64, 128, 256, 512, 1024, 1280, 1518)
        config_frame_size_loop(test_config=self.Item, loop_type=Type, fixed_length=Length, min_length=Min,
                               max_length=Max,
                               start_length=Start,
                               end_length=End, step_length=Step, custom_length=Custom,
                               imix_templates=[x.template for x in ImixTemplates])
        return True

    def edit_latency(self, Type='FIFO', DelayBefore=2, DelayAfter=10):
        config_latency_parameters(test_configs=[self.Item], latency_type=Type, delay_before_start_stream=DelayBefore,
                                  delay_after_stop_stream=DelayAfter)
        return True

    def edit_address_learning(self, Frequency, EnableLearning=True,
                              LearningRate=1000, LearningRepeat=5, DelayBefore=2,
                              EnableArp=False, ArpRate=1000, ArpRepeat=5):
        config_address_learning(test_configs=[self.Item], learning_frequency=Frequency,
                                enable_address_learning=EnableLearning,
                                l2_learning_rate=LearningRate, l2_learning_repeat_count=LearningRepeat,
                                delay_before_l2_learning=DelayBefore,
                                enable_arp_learning=EnableArp, arp_learning_rate=ArpRate,
                                arp_learning_repeat_count=ArpRepeat)
        return True

    def edit_duration(self, Trial=1, Mode='second', Count=100):
        config_test_duration(test_config=self.Item, trial_number=Trial, duration_mode=Mode, duration_count=Count)
        return True

    def edit_transport_layer(self, HeaderType=None, EnableRandomPort=True, SrcPortBase=7, SrcPortStep=1, SrcPortCount=0,
                             DstPortBase=7, DstPortStep=1,
                             DstPortCount=0):
        if HeaderType is None:
            HeaderType = 'none'
        config_transport_layer_header(test_configs=[self.Item], header_type=HeaderType,
                                      use_random_port=EnableRandomPort,
                                      src_port_base=SrcPortBase,
                                      src_port_step=SrcPortStep, src_port_count=SrcPortCount, dst_port_base=DstPortBase,
                                      dst_port_step=DstPortStep,
                                      dst_port_count=DstPortCount)
        return True

    def edit_result_path(self, Path):
        if not os.path.exists(Path):
            os.makedirs(Path)
        config_result_path(test_configs=[self.Item], abs_path=Path)
        return True

    def edit_result_file_name(self, EnableCustomResult=False, ResultFileName=None, AddTimeStamp=True):
        config_result_file_name(test_config=self.Item, use_custom_result_file_name=EnableCustomResult,
                                result_file_name=ResultFileName, append_timestamp=AddTimeStamp)
        return True


class Other1Item(BaseItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_search(self,
                    Mode='binary',
                    Lower=1,
                    Upper=100,
                    Init=10,
                    Step=10,
                    Resolution=1,
                    Ratio=50,
                    Acceptance=0,
                    Ignore=False,
                    EnableLatency=False,
                    Maxlatency=30
                    ):
        config_binary_search_parameters(test_config=self.Item, search_mode=Mode, lower_rate=Lower, upper_rate=Upper,
                                        init_rate=Init,
                                        step_rate=Step, resolution=Resolution, back_off_ratio=Ratio,
                                        acceptance_loss=Acceptance,
                                        ignore_limit=Ignore, enable_latency_threshold=EnableLatency,
                                        max_latency=Maxlatency)
        return True


class Other2Item(BaseItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_traffic_load_loop(self,
                               LoadUnit='percent',
                               LoadMode='custom',
                               FixedLoad=10,
                               LoadMin=10,
                               LoadMax=50,
                               LoadStart=10,
                               LoadEnd=50,
                               LoadStep=10,
                               LoadCustom=(10, 20, 50),
                               ):
        config_traffic_load_loop(test_config=self.Item,
                                 load_unit=LoadUnit,
                                 load_mode=LoadMode,
                                 fixed_load=FixedLoad,
                                 load_min=LoadMin,
                                 load_max=LoadMax,
                                 load_start=LoadStart,
                                 load_end=LoadEnd,
                                 load_step=LoadStep,
                                 load_custom=LoadCustom,
                                 )
        return True


class Rfc2889Item(BaseItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_burst_count_loop(self, Mode='step', Start=1, End=1, Step=1, Custom=(1, 2)):
        config_burst_count_loop(test_config=self.Item,
                                burst_mode=Mode,
                                burst_start=Start,
                                burst_end=End,
                                burst_step=Step,
                                burst_custom=Custom)
        return True


class Rfc3918Item(BaseItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_multicast_base_parameters(self,
                                       Version='igmpv2',
                                       Ipv4GroupAddressStart='225.0.0.1',
                                       Ipv4GroupAddressStep='0.1.0.0',
                                       Ipv4PrefixLength=32,
                                       Ipv6GroupAddressStart='ff1e::1',
                                       Ipv6GroupAddressStep='0:0:0:1::',
                                       Ipv6PrefixLength=128,
                                       GroupIncrement=1,
                                       JoinGroupDelay=15,
                                       LeaveGroupDelay=15,
                                       JoinLeaveSendRate=1000,
                                       GroupDistributeMode='even',
                                       ):
        config_multicast_base_parameters(test_configs=[self.Item],
                                         version=Version,
                                         ipv4_group_address_start=Ipv4GroupAddressStart,
                                         ipv4_group_address_step=Ipv4GroupAddressStep,
                                         ipv4_prefix_length=Ipv4PrefixLength,
                                         ipv6_group_address_start=Ipv6GroupAddressStart,
                                         ipv6_group_address_step=Ipv6GroupAddressStep,
                                         ipv6_prefix_length=Ipv6PrefixLength,
                                         group_increment=GroupIncrement,
                                         join_group_delay=JoinGroupDelay,
                                         leave_group_delay=LeaveGroupDelay,
                                         join_leave_send_rate=JoinLeaveSendRate,
                                         group_distribute_mode=GroupDistributeMode,
                                         )
        return True

    def edit_multicast_stream_tos(self, Tos=0, FlowLabel=0, TTL=7, Priority=0):
        config_multicast_stream_tos(test_configs=[self.Item], ipv4_tos=Tos, ipv6_flow_label=FlowLabel, ip_ttl=TTL,
                                    vlan_priority=Priority)
        return True

    def edit_multicast_other(self, StopTestWhenFailed=True, VerifyFreq='topo_changed', DurationMode='second',
                             TimeDurationCount=1, BurstDurationCount=100, TxFrameRate=1000):
        config_rfc3918_others(test_configs=[self.Item], stop_test_when_failed=StopTestWhenFailed,
                              verify_freq=VerifyFreq, duration_mode=DurationMode, time_duration_count=TimeDurationCount,
                              burst_duration_count=BurstDurationCount, tx_frame_rate=TxFrameRate)
        return True

class Rfc3918Item1(BaseItem):

    def __init__(self, Item):
        super().__init__(Item=Item)

    def edit_multicast_group_count_loop(self, LoopMode='step', FixedGroup=10, MinGroup=10, MaxGroup=50, StartGroup=10,
                                        EndGroup=50, StepGroup=10, CustomGroup=(10, 20, 100)):
        config_multicast_group_count_loop(test_config=self.Item, loop_mode=LoopMode, fixed_group=FixedGroup,
                                          min_group=MinGroup, max_group=MaxGroup, start_group=StartGroup,
                                          end_group=EndGroup,  step_group=StepGroup, custom_group=CustomGroup)
        return True

from .mpls_l3_vpn import *


class Mpls6VPe(MplsL3Vpn):

    def __init__(self, **kwargs):
        wizard_config = create_mpls_l3_wizard_config(wizard_name='6vpe', **kwargs)
        super().__init__(Wizard=wizard_config)
        self._wizard_type = '6vpe'

    def edit_vpn_ipv6_route_customer_parameters(self, **kwargs):
        """
        config ipv6 vpn route customer parameters

        Keyword Args:
            CustomerStartRoute (str): customer start route, Ipv6Address
            CustomerRouteStep (str): customer route step, Ipv6Address
            CustomerPrefixLength (int): prefix length
            CustomerRoutesPerCe (int): customer route PerCe
            CustomerOverlapRoutes (bool): customer overlap routes
            CustomerRouteType (str): customer route type, Internal or External

        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        config_ipv6_vpn_route_customer_parameters(WizardConfig=self.Wizard, **kwargs)
        return True

    def edit_vpn_ipv6_route_provider_parameters(self, **kwargs):
        """
        config ipv6 vpn route customer parameters

        Keyword Args:
            ProviderStartRoute (str): provider start route Ipv6Address
            ProviderRouteStep (str): provider route step Ipv6Address
            ProviderPrefixLength (int): prefix length
            ProviderRoutesPerCe (int): provider route PerCe
            ProviderOverlapRoutes (bool): provider overlap routes
            ProviderLabelType (str): provider route type, LabelPerSite or LabelPerRoute
            ProviderStartLabel (int): start label
            
        Returns:
            (bool): True

        Raises:
            exception.ValueError
        """
        config_ipv6_vpn_route_provider_parameters(WizardConfig=self.Wizard, **kwargs)
        return True

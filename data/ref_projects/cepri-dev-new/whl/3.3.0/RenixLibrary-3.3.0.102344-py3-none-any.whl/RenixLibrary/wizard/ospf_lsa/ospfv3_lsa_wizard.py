from renix_py_api.renix import *
from RenixLibrary.wizard.route_base import *


class Ospfv3LsaWizard(RouteWizard):

    def __init__(self, Sessions, **kwargs):
        RouteWizard.__init__(self,
                             Wizard='Ospfv3LsaWizardConfig',
                             Sessions=Sessions,
                             Relation='WizardSelectedOspfv3',
                             **kwargs)
        self.__wizard = self.wizard()
        # intra area distributor
        self.__intra_area_distributor = self.create_object(relatives='IntraAreaDistributionGenerator',
                                                           object_name='DistributionRouteGenerator')
        # inter area distributor
        self.__inter_area_distributor = self.create_object(relatives='InterAreaDistributionGenerator',
                                                           object_name='DistributionRouteGenerator')
        # external distributor
        self.__external_distributor = self.create_object(relatives='ExternalDistributionGenerator',
                                                         object_name='DistributionRouteGenerator')

    def config_ospfv3_topo(self, Type, **kwargs):
        self.__wizard.TopologyType = Type
        for k, v in kwargs.items():
            if k in ['SimulatedRoutersCount',
                     'InterfaceType',
                     'RouterMaxInterfaceCount',
                     'TransitNetworkMaxRouterCount',
                     'UneditableSimulatedRoutersCount',
                     'EmulatedRouterPossessSimulatedRouterCount',
                     'RowCount',
                     'ColumnCount',
                     'GridEmulatedRouterPosition',
                     'EmulatedRouterAttachRowIndex',
                     'EmulatedRouterAttachColumnIndex',
                     'MeshRouterCount',
                     'MeshEmulatedRouterPosition',
                     'RingRouterCount',
                     'RingEmulatedRouterPosition',
                     'HubSpokeRouterCount',
                     'HubSpokeEmulatedRouterPosition']:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

    def config_ospfv3(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['StartingPrefixRange',
                     'EndingPrefixRange',
                     'AreaType',
                     'StartingRouterId',
                     'RouterIdStep']:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

    def config_ospfv3_intra_area_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['IntraAreaEmulated',
                     'IntraAreaSimulated',
                     'IntraAreaRoutesCount',
                     'IntraAreaOverride',
                     'IntraAreaStartingIpPrefix',
                     'IntraAreaEndingIpPrefix',
                     'IntraAreaDistributionType',
                     'IntraAreaStartPrefixLength',
                     'IntraAreaEndPrefixLength',
                     'IntraAreaPrimaryMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'IntraAreaInternetPrefixLength':
                self.__intra_area_distributor.InternetDistributionValue = v
            elif k == 'IntraAreaCustomPrefixLength':
                self.__intra_area_distributor.CustomDistributionValue = v
        return self.__wizard

    def config_ospfv3_inter_area_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['InterAreaEmulated',
                     'InterAreaSimulated',
                     'InterAreaRoutesCount',
                     'InterAreaOverride',
                     'InterAreaStartingIpPrefix',
                     'InterAreaEndingIpPrefix',
                     'InterAreaDistributionType',
                     'InterAreaStartPrefixLength',
                     'InterAreaEndPrefixLength',
                     'InterAreaPrimaryMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'InterAreaInternetPrefixLength':
                self.__inter_area_distributor.InternetDistributionValue = v
            elif k == 'InterAreaCustomPrefixLength':
                self.__inter_area_distributor.CustomDistributionValue = v
        return self.__wizard

    def config_ospfv3_external_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['ExternalEmulated',
                     'ExternalSimulated',
                     'ExternalRoutesCount',
                     'ExternalOverride',
                     'ExternalStartingIpPrefix',
                     'ExternalEndingIpPrefix',
                     'ExternalDistributionType',
                     'ExternalStartPrefixLength',
                     'ExternalEndPrefixLength',
                     'ExternalPrimaryMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'ExternalInternetPrefixLength':
                self.__external_distributor.InternetDistributionValue = v
            elif k == 'ExternalCustomPrefixLength':
                self.__external_distributor.CustomDistributionValue = v
        return self.__wizard

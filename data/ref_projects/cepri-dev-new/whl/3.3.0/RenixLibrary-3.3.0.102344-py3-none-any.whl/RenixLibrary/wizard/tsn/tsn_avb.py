from renix_py_api.api_gen import AvbWizardConfig, EnumClockAccuracy, ExpandWizardCommand
from renix_py_api.renix_common_api import get_sys_entry


class TsnAvbWizard:

    def __init__(self, TalkerPort, ListenerPort, NonAvbPort, IsAppended=False):
        self._wizard = self._create_avb_wizard_config(TalkerPort, ListenerPort, NonAvbPort, IsAppended)

    @property
    def wizard(self):
        return self._wizard

    @property
    def handle(self):
        return self._wizard.handle

    def _create_avb_wizard_config(self,
                                  TalkerPort,
                                  ListenerPort,
                                  NonAvbPort,
                                  IsAppended=False):
        """
        Create AVB wizard config
        Args:
            :param TalkerPort: Talker port
            :type TalkerPort: Port object
            :param ListenerPort: Listener port
            :type ListenerPort: Port object
            :param NonAvbPort: Non-AVB port
            :type NonAvbPort: Port object
            :param IsAppended: is appended
            :type IsAppended: bool
        Returns: AvbWizardConfig object
        Raises: None or ValueError
        """
        if (not TalkerPort) or (not ListenerPort) or (not NonAvbPort):
            raise ValueError('talker port, listener port or Non-AVB port is Null')

        sys_entry = get_sys_entry()
        wizard_configs = sys_entry.get_children('AvbWizardConfig')
        avb_wizard_config = None
        if len(wizard_configs) > 0:
            avb_wizard_config = wizard_configs[0]
        else:
            avb_wizard_config = AvbWizardConfig(upper=sys_entry)

        avb_wizard_config.edit(TalkerPort=TalkerPort.handle,
                               ListenerPort=ListenerPort.handle,
                               NonAvbPort=NonAvbPort.handle,
                               IsAppended=IsAppended)

        return avb_wizard_config

    def config_qav(self,
                   FrameSize=None,
                   SrClassVid=None,
                   EnableClassA=None,
                   ClassABwRsvPct=None,
                   ClassAStreamNum=None,
                   ClassAStreamsBwRsvPct=None,
                   EnableClassB=None,
                   ClassBBwRsvPct=None,
                   ClassBStreamNum=None,
                   ClassBStreamsBwRsvPct=None):
        """
        Create Qav
        Args:
            :param FrameSize: Frame Size
            :type FrameSize: UINT16,60-16383
            :param SrClassVid: SR Class VID
            :type SrClassVid: UINT16,1-4093
            :param EnableClassA: Enable Class A
            :type EnableClassA: bool
            :param ClassABwRsvPct: Class A BW Proportion(%)
            :type ClassABwRsvPct: UINT8,0-100
            :param ClassAStreamNum: Class A Stream Count
            :type ClassAStreamNum: UINT16,0-256
            :param ClassAStreamsBwRsvPct: Class A Streams BW Proportion(%)
            :type ClassAStreamsBwRsvPct: UIN8 List
            :param EnableClassB: Enable Class B
            :type EnableClassB: bool
            :param ClassBBwRsvPct: Class B BW Proportion(%)
            :type ClassBBwRsvPct: UINT8,0-100
            :param ClassBStreamNum: Class B Stream Count
            :type ClassBStreamNum: UINT16,0-256
            :param ClassBStreamsBwRsvPct: Class B Streams BW Proportion(%)
            :type ClassBStreamsBwRsvPct: UINT8 List
        Returns: None
        Raises: None or ValueError
        """
        if not self.wizard:
            raise ValueError('wizard_config is Null')

        # validate MSRP class configuration
        talker_port_bw = 0
        if EnableClassA:
            if ClassAStreamNum != len(ClassAStreamsBwRsvPct):
                raise ValueError('ClassAStreamNum != len(ClassAStreamsBwRsvPct)')
            bw_reservation = 0
            for i in ClassAStreamsBwRsvPct:
                if i > 100:
                    raise ValueError('ClassAStreamsBwRsvPct should be in 0-100')
                bw_reservation += i
            if bw_reservation != ClassABwRsvPct:
                raise ValueError('Class A BW Proportion config error.')
            talker_port_bw += ClassABwRsvPct

        if EnableClassB:
            if ClassBStreamNum != len(ClassBStreamsBwRsvPct):
                raise ValueError('ClassBStreamNum != len(ClassBStreamsBwRsvPct)')
            bw_reservation = 0
            for i in ClassBStreamsBwRsvPct:
                if i > 100:
                    raise ValueError('ClassBStreamsBwRsvPct should be in 0-100')
                bw_reservation += i
            if bw_reservation != ClassBBwRsvPct:
                raise ValueError('Class B BW Proportion config error.')
            talker_port_bw += ClassBBwRsvPct

        if talker_port_bw > 100:
            raise ValueError('Talker port BW Proportion ={}, it is bigger than 100.'.format(talker_port_bw))

        self.wizard.edit(FrameSize=FrameSize,
                         SrClassVid=SrClassVid,
                         EnableClassA=EnableClassA,
                         ClassABwRsvPct=ClassABwRsvPct,
                         ClassAStreamNum=ClassAStreamNum,
                         ClassAStreamsBwRsvPct=ClassAStreamsBwRsvPct,
                         EnableClassB=EnableClassB,
                         ClassBBwRsvPct=ClassBBwRsvPct,
                         ClassBStreamNum=ClassBStreamNum,
                         ClassBStreamsBwRsvPct=ClassBStreamsBwRsvPct)
        return True

    def config_gptp(self,
                    Priority1=None,
                    Priority2=None,
                    ClockAccuracy=None,
                    LogAnnounceInterval=None,
                    LogSyncInterval=None,
                    AnnounceReceiptTimeout=None,
                    PropogationDelay=None):
        """
        Create gPTP
        Args:
            :param Priority1: Priority 1
            :type Priority1: UINT8
            :param Priority2: Priority 2
            :type Priority2: UINT8
            :param ClockAccuracy: Clock Accuracy
            :type ClockAccuracy: EnumClockAccuracy
            :param LogAnnounceInterval: Log Announce Interval
            :type LogAnnounceInterval: INT16,-10-10
            :param LogSyncInterval: Log Sync Interval
            :type LogSyncInterval: INT16,-10-10
            :param AnnounceReceiptTimeout: Announce Receipt Timeout
            :type AnnounceReceiptTimeout: UINT8 3-255
            :param PropogationDelay: Propogation Delay
            :type PropogationDelay: UINT64
        Returns: None
        Raises: None or ValueError
        """
        EnumClockAccuracy
        if not self.wizard:
            raise ValueError('wizard_config is Null')

        self.wizard.edit(Priority1=Priority1,
                         Priority2=Priority2,
                         ClockAccuracy=ClockAccuracy,
                         LogAnnounceInterval=LogAnnounceInterval,
                         LogSyncInterval=LogSyncInterval,
                         AnnounceReceiptTimeout=AnnounceReceiptTimeout,
                         PropogationDelay=PropogationDelay)
        return True

    def config_non_stream(self,
                          NonAvbFrameSize=None,
                          LoadRate=None,
                          StreamNumber=None):
        """
        Create Non-AVB stream
        Args:
            :param wizard_config: AVB wizard config
            :type wizard_config: AvbWizardConfig Object
            :param NonAvbFrameSize: Frame Size
            :type NonAvbFrameSize: UINT16,60-16383
            :param LoadRate: Load Rate(%)
            :type LoadRate: UINT8 0-100
            :param StreamNumber: Number of Streams
            :type StreamNumber: UINT16 0-256
        Returns: None
        Raises: None or ValueError
        """
        if not self.wizard:
            raise ValueError('wizard_config is Null')

        self.wizard.edit(NonAvbFrameSize=NonAvbFrameSize,
                         LoadRate=LoadRate,
                         StreamNumber=StreamNumber)
        return True

    def expand(self):
        """
        expand wizard
        """
        command = ExpandWizardCommand(WizardConfig=self.wizard.handle)
        command.execute()
        return True

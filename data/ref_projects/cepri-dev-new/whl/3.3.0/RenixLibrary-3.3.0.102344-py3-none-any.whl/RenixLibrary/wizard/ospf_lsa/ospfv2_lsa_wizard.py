from renix_py_api.renix import *
from RenixLibrary.wizard.route_base import *


class Ospfv2LsaWizard(RouteWizard):

    def __init__(self, Sessions, **kwargs):
        RouteWizard.__init__(self,
                             Wizard='Ospfv2LsaWizardConfig',
                             Sessions=Sessions,
                             Relation='WizardSelectedOspfv2',
                             **kwargs)
        self.__wizard = self.wizard()
        # stub distributor
        self.__stub_distributor = self.create_object(relatives='StubDistributionGenerator',
                                                     object_name='DistributionRouteGenerator')
        # summary distributor
        self.__summary_distributor = self.create_object(relatives='SummaryDistributionGenerator',
                                                        object_name='DistributionRouteGenerator')
        # external distributor
        self.__external_distributor = self.create_object(relatives='ExternalDistributionGenerator',
                                                         object_name='DistributionRouteGenerator')

    def config_ospfv2_topo(self, Type, **kwargs):
        self.__wizard.TopologyType = Type
        for k, v in kwargs.items():
            if k in ['SimulatedRoutersCount',
                     'InterfaceType',
                     'RouterMaxInterfaceCount',
                     'TransitNetworkMaxRouterCount',
                     'UneditableSimulatedRoutersCount',
                     'EmulatedRouterPossessSimulatedRouterCount',
                     'RowCount',
                     'ColumnCount',
                     'GridEmulatedRouterPosition',
                     'EmulatedRouterAttachRowIndex',
                     'EmulatedRouterAttachColumnIndex',
                     'MeshRouterCount',
                     'MeshEmulatedRouterPosition',
                     'RingRouterCount',
                     'RingEmulatedRouterPosition',
                     'HubSpokeRouterCount',
                     'HubSpokeEmulatedRouterPosition']:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

    def config_ospfv2(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['StartingPrefixRange',
                     'EndingPrefixRange',
                     'EnableP2pLinks',
                     'EnableTeOption',
                     'EnableSegmentRouting',
                     'AreaType',
                     'StartingInterfaceIp',
                     'InterfacePrefixLength',
                     'InterfaceOverride',
                     'StartingRouterId',
                     'EnableAdvertiseRouterId',
                     'RouterIdStep']:
                setattr(self.__wizard, str(k), v)
        return self.__wizard

    def config_ospfv2_te_option(self, **kwargs):
        te_option = self.create_object(relatives='TrafficEnginRelation',
                                       object_name='TrafficEngineeringConfig')
        for k, v in kwargs.items():
            setattr(te_option, str(k), v)
        return te_option

    def config_ospfv2_sr(self, **kwargs):
        sr = self.create_object(relatives='SrParametersRelation',
                                object_name='Ospfv2SrConfig')
        kwargs = self.edit_options_of_kwargs(config=sr, para='NodeFlags', enum_=EnumOpsfv2PrefixSidTlvFlags, **kwargs)
        kwargs = self.edit_options_of_kwargs(config=sr, para='PrefixFlags', enum_=EnumOpsfv2PrefixSidTlvFlags, **kwargs)
        for k, v in kwargs.items():
            setattr(sr, str(k), v)
        return sr

    def config_ospfv2_stub_network(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['StubEmulated',
                     'StubSimulated',
                     'StubRoutesCount',
                     'StubOverride',
                     'StubStartingIpPrefix',
                     'StubEndingIpPrefix',
                     'StubDistributionType',
                     'StubStartPrefixLength',
                     'StubEndPrefixLength',
                     'StubPrimaryMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'StubInternetPrefixLength':
                self.__stub_distributor.InternetDistributionValue = v
            elif k == 'StubCustomPrefixLength':
                self.__stub_distributor.CustomDistributionValue = v
        return self.__wizard

    def config_ospfv2_summary_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['SummaryEmulated',
                     'SummarySimulated',
                     'SummaryRoutesCount',
                     'SummaryOverride',
                     'SummaryStartingIpPrefix',
                     'SummaryEndingIpPrefix',
                     'SummaryDistributionType',
                     'SummaryStartPrefixLength',
                     'SummaryEndPrefixLength',
                     'SummaryPrimaryMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'SummaryInternetPrefixLength':
                self.__summary_distributor.InternetDistributionValue = v
            elif k == 'SummaryCustomPrefixLength':
                self.__summary_distributor.CustomDistributionValue = v
        return self.__wizard

    def config_ospfv2_external_route(self, **kwargs):
        for k, v in kwargs.items():
            if k in ['ExternalEmulated',
                     'ExternalSimulated',
                     'ExternalRoutesCount',
                     'ExternalOverride',
                     'ExternalStartingIpPrefix',
                     'ExternalEndingIpPrefix',
                     'ExternalDistributionType',
                     'ExternalStartPrefixLength',
                     'ExternalEndPrefixLength',
                     'ExternalPrimaryMetric']:
                setattr(self.__wizard, str(k), v)
            elif k == 'ExternalInternetPrefixLength':
                self.__external_distributor.InternetDistributionValue = v
            elif k == 'ExternalCustomPrefixLength':
                self.__external_distributor.CustomDistributionValue = v
        return self.__wizard


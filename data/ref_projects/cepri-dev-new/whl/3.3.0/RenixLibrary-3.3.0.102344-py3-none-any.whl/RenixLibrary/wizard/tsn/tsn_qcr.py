from renix_py_api.api_gen import ExpandWizardCommand, QcrWizardConfig, QcrStreamConfig, \
    StreamIdentificationFunctionConfig
from renix_py_api.renix_common_api import get_sys_entry


class TsnQcrWizard:

    def __init__(self):
        self._wizard = self._create_qcr_wizard_config()
        self._stream_config = []

    @property
    def wizard(self):
        return self._wizard

    @property
    def handle(self):
        return self._wizard.handle

    @property
    def stream_config(self):
        return self._stream_config

    def _create_qcr_wizard_config(self):
        sys_entry = get_sys_entry()
        wizard_configs = sys_entry.get_children('QcrWizardConfig')
        qcr_wizard_config = None
        if len(wizard_configs) > 0:
            qcr_wizard_config = wizard_configs[0]
        else:
            qcr_wizard_config = QcrWizardConfig(upper=sys_entry)

        return qcr_wizard_config

    def create_qcr_stream(self,
                          TalkerPort=None,
                          ListenerPortList=None, Priority=None, LoadUnit=None, Load=None, FrameLengthType=None,
                          FixedFrameSize=None, MinFrameSize=None, MaxFrameSize=None, StepFrameSize=None, **kwargs):

        if not self.wizard:
            raise ValueError('wizard_config is Null')

        if not isinstance(ListenerPortList, (list, set, tuple)):
            ListenerPortList = [ListenerPortList]

        stream_config = QcrStreamConfig(upper=self.wizard)
        self._stream_config.append(stream_config)

        stream_config.edit(TalkerPort=TalkerPort.handle,
                           ListenerPortList=[i.handle for i in ListenerPortList], Priority=Priority, LoadUnit=LoadUnit, Load=Load,
                           FrameLengthType=FrameLengthType,
                           FixedFrameSize=FixedFrameSize, MinFrameSize=MinFrameSize, MaxFrameSize=MaxFrameSize,
                           StepFrameSize=StepFrameSize, **kwargs)
        return stream_config

    @staticmethod
    def config_stream_identification_function(Config=None,
                                              StreamIdentificationFunction=None, SourceMacAddress=None,
                                              DestinationMacAddress=None, VlanId=None, AddUdpHeader=None,
                                              SourcePort=None, DestinationPort=None, AddIpHeader=None,
                                              SourceIpAddress=None, DestinationIpAddress=None, IpDscp=None,
                                              IpNextProtocol=None, **kwargs):
        config = Config.get_children('StreamIdentificationFunctionConfig')[0]
        if not config:
            config = StreamIdentificationFunctionConfig(upper=Config)

        config.edit(StreamIdentificationFunction=StreamIdentificationFunction, SourceMacAddress=SourceMacAddress,
                    DestinationMacAddress=DestinationMacAddress, VlanId=VlanId, AddUdpHeader=AddUdpHeader,
                    SourcePort=SourcePort, DestinationPort=DestinationPort, AddIpHeader=AddIpHeader,
                    SourceIpAddress=SourceIpAddress, DestinationIpAddress=DestinationIpAddress, IpDscp=IpDscp,
                    IpNextProtocol=IpNextProtocol, **kwargs)
        return True

    def expand(self):
        """
        expand wizard
        """
        command = ExpandWizardCommand(WizardConfig=self.wizard.handle)
        command.execute()
        return True

from .header_base import *

file_path = SCHEMA_PATH + "MstpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("mstpCfg")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class MstpConfigHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("cfg")
        self.__protocolIdentifier = paramDict["protocolIdentifier"]
        self.__protocolVersionIdentifier = paramDict["protocolVersionIdentifier"]
        self.__BPDUType = paramDict["BPDUType"]
        self.__topologyChangeAck = 0
        self.__agreement = 1
        self.__forwarding = 1
        self.__learning = 1
        self.__portRole = 11
        self.__proposal = 0
        self.__topologyChange = 0
        self.__rootBridgePriority = 8
        self.__rootSystemIdExtension = 0
        self.__rootBridgeSystemID = '00:00:00:12:30:10'
        self.__rootPathCost = paramDict["rootPathCost"]
        self.__bridgePriority = 8
        self.__bridgeSystemIdExtension = 0
        self.__bridgeSystemID = '00:00:00:12:30:10'
        self.__portIdentifier = paramDict["portIdentifier"]
        self.__messageAge = paramDict["messageAge"]
        self.__maxAge = paramDict["maxAge"]
        self.__helloTime = paramDict["helloTime"]
        self.__forwardDelay = paramDict["forwardDelay"]
        self.__version1Length = paramDict["version1Length"]
        self.__version3Length = paramDict["version3Length"]
        self.__configId = 0
        self.__configName = '726567696f6e3100000000000000000000000000000000000000000000000000'
        self.__configRevision = 0
        self.__configDigest = '90fba5e9774b09524a17ebb75f8d065a'
        self.__cistRootPathCost = 0
        self.__cistBridgePriority = 8
        self.__cistSystemIdExtension = 0
        self.__cistBridgeSystemID = '00:00:00:12:30:10'
        self.__cistRemainingHops = 20
        self.__mstInstances = 0

    @property
    def protocolIdentifier(self):
        return self.__protocolIdentifier

    @protocolIdentifier.setter
    def protocolIdentifier(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__protocolIdentifier = Value

    @property
    def protocolVersionIdentifier(self):
        return self.__protocolVersionIdentifier

    @protocolVersionIdentifier.setter
    def protocolVersionIdentifier(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__protocolVersionIdentifier = Value

    @property
    def BPDUType(self):
        return self.__BPDUType

    @BPDUType.setter
    def BPDUType(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__BPDUType = Value

    @property
    def topologyChangeAck(self):
        return self.__topologyChangeAck

    @topologyChangeAck.setter
    def topologyChangeAck(self, Value):
        self.update('{}.BPDUFlags.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__topologyChangeAck = Value

    @property
    def agreement(self):
        return self.__agreement

    @agreement.setter
    def agreement(self, Value):
        self.update('{}.BPDUFlags.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__agreement = Value

    @property
    def forwarding(self):
        return self.__forwarding

    @forwarding.setter
    def forwarding(self, Value):
        self.update('{}.BPDUFlags.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__forwarding = Value

    @property
    def learning(self):
        return self.__learning

    @learning.setter
    def learning(self, Value):
        self.update('{}.BPDUFlags.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__learning = Value

    @property
    def portRole(self):
        return self.__portRole

    @portRole.setter
    def portRole(self, Value):
        self.update('{}.BPDUFlags.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__portRole = Value

    @property
    def proposal(self):
        return self.__proposal

    @proposal.setter
    def proposal(self, Value):
        self.update('{}.BPDUFlags.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__proposal = Value

    @property
    def topologyChange(self):
        return self.__topologyChange

    @topologyChange.setter
    def topologyChange(self, Value):
        self.update('{}.BPDUFlags.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__topologyChange = Value

    @property
    def rootBridgePriority(self):
        return self.__rootBridgePriority

    @rootBridgePriority.setter
    def rootBridgePriority(self, Value):
        self.update('{}.rootIdentifier.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__rootBridgePriority = Value

    @property
    def rootSystemIdExtension(self):
        return self.__rootSystemIdExtension

    @rootSystemIdExtension.setter
    def rootSystemIdExtension(self, Value):
        self.update('{}.rootIdentifier.systemIdExtension={} '.format(self.name, Value))
        self.__rootSystemIdExtension = Value

    @property
    def rootBridgeSystemID(self):
        return self.__rootBridgeSystemID

    @rootBridgeSystemID.setter
    def rootBridgeSystemID(self, Value):
        self.update('{}.rootIdentifier.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__rootBridgeSystemID = Value

    @property
    def rootPathCost(self):
        return self.__rootPathCost

    @rootPathCost.setter
    def rootPathCost(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__rootPathCost = Value

    @property
    def bridgePriority(self):
        return self.__bridgePriority

    @bridgePriority.setter
    def bridgePriority(self, Value):
        self.update('{}.bridgeIdentifier.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__bridgePriority = Value

    @property
    def bridgeSystemIdExtension(self):
        return self.__bridgeSystemIdExtension

    @bridgeSystemIdExtension.setter
    def bridgeSystemIdExtension(self, Value):
        self.update('{}.bridgeIdentifier.systemIdExtension={} '.format(self.name, Value))
        self.__bridgeSystemIdExtension = Value

    @property
    def bridgeSystemID(self):
        return self.__bridgeSystemID

    @bridgeSystemID.setter
    def bridgeSystemID(self, Value):
        self.update('{}.bridgeIdentifier.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__bridgeSystemID = Value

    @property
    def portIdentifier(self):
        return self.__portIdentifier

    @portIdentifier.setter
    def portIdentifier(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__portIdentifier = Value

    @property
    def messageAge(self):
        return self.__messageAge

    @messageAge.setter
    def messageAge(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__messageAge = Value

    @property
    def maxAge(self):
        return self.__maxAge

    @maxAge.setter
    def maxAge(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__maxAge = Value

    @property
    def helloTime(self):
        return self.__helloTime

    @helloTime.setter
    def helloTime(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__helloTime = Value

    @property
    def forwardDelay(self):
        return self.__forwardDelay

    @forwardDelay.setter
    def forwardDelay(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__forwardDelay = Value

    @property
    def version1Length(self):
        return self.__version1Length

    @version1Length.setter
    def version1Length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version1Length = Value

    @property
    def version3Length(self):
        return self.__version3Length

    @version3Length.setter
    def version3Length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version3Length = Value

    @property
    def configId(self):
        return self.__configId

    @configId.setter
    def configId(self, Value):
        self.update('{}.mstExtension.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__configId = Value

    @property
    def configName(self):
        return self.__configName

    @configName.setter
    def configName(self, Value):
        self.update('{}.mstExtension.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__configName = Value

    @property
    def configRevision(self):
        return self.__configRevision

    @configRevision.setter
    def configRevision(self, Value):
        self.update('{}.mstExtension.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__configRevision = Value

    @property
    def configDigest(self):
        return self.__configDigest

    @configDigest.setter
    def configDigest(self, Value):
        self.update('{}.mstExtension.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__configDigest = Value

    @property
    def cistRootPathCost(self):
        return self.__cistRootPathCost

    @cistRootPathCost.setter
    def cistRootPathCost(self, Value):
        self.update('{}.mstExtension.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__cistRootPathCost = Value

    @property
    def cistBridgePriority(self):
        return self.__cistBridgePriority

    @cistBridgePriority.setter
    def cistBridgePriority(self, Value):
        self.update('{}.mstExtension.cistBridgeIdentifier.bridgePriority={} '.format(self.name, Value))
        self.__cistBridgePriority = Value

    @property
    def cistSystemIdExtension(self):
        return self.__cistSystemIdExtension

    @cistSystemIdExtension.setter
    def cistSystemIdExtension(self, Value):
        self.update('{}.mstExtension.cistBridgeIdentifier.systemIdExtension={} '.format(self.name, Value))
        self.__cistSystemIdExtension = Value

    @property
    def cistBridgeSystemID(self):
        return self.__cistBridgeSystemID

    @cistBridgeSystemID.setter
    def cistBridgeSystemID(self, Value):
        self.update('{}.mstExtension.cistBridgeIdentifier.bridgeSystemID={} '.format(self.name, Value))
        self.__cistBridgeSystemID = Value

    @property
    def cistRemainingHops(self):
        return self.__cistRemainingHops

    @cistRemainingHops.setter
    def cistRemainingHops(self, Value):
        self.update('{}.mstExtension.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__cistRemainingHops = Value

    @property
    def mstInstances(self):
        return self.__mstInstances

    @mstInstances.setter
    def mstInstances(self, Value):
        if not Value:
            # delete node
            pass
        else:
            for i in range(Value):
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName='{}.mstExtension.mstInstances'.format(self.name),
                                        NodeName='mstInstance').execute()
        self.__mstInstances = Value

    def config_mst_instance(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k in ['TopologyChangeAck', 'Agreement', 'Forwarding', 'Learning',
                     'PortRole', 'Proposal', 'TopologyChange']:
                self.update('{}.mstExtension.mstInstances.mstInstance_{}.MSTIFlags.{}={} '.format(self.name, Index, k_, v))
                result.update({k: 'mstExtension.mstInstances.mstInstance_{}.MSTIFlags.{}'.format(Index, k_)})
            else:
                self.update('{}.mstExtension.mstInstances.mstInstance_{}.{}={} '.format(self.name, Index, k_, v))
                result.update({k: 'mstExtension.mstInstances.mstInstance_{}.{}'.format(Index, k_)})
        return result

    def get_mst_instance(self, Index, Item):
        Item_ = Item[:1].lower()+Item[1:]
        if Item in ['TopologyChangeAck', 'Agreement', 'Forwarding', 'Learning',
                 'PortRole', 'Proposal', 'TopologyChange']:
            return self.get_value(field='{}.mstExtension.mstInstances.mstInstance_{}.MSTIFlags.{}'.format(
                self.name, Index, Item_))
        else:
            return self.get_value(field='{}.mstExtension.mstInstances.mstInstance_{}.{}'.format(
                self.name, Index, Item_))

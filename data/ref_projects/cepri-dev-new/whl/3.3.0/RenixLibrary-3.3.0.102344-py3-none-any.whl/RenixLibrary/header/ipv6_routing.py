from .header_base import *

file_path = SCHEMA_PATH + "Ipv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv6RoutingHeader")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv6RoutingHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ipv6RoutingHeader")
        self.__nextHeader = paramDict["nextHeader"]
        self.__length = paramDict["length"]
        self.__routingType = paramDict["routingType"]
        self.__segLeft = paramDict["segLeft"]
        self.__reserved = paramDict["reserved"]
        self.__nodes = []

    @property
    def nextHeader(self):
        return self.__nextHeader

    @nextHeader.setter
    def nextHeader(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nextHeader = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def routingType(self):
        return self.__routingType

    @routingType.setter
    def routingType(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__routingType = Value

    @property
    def segLeft(self):
        return self.__segLeft

    @segLeft.setter
    def segLeft(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__segLeft = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved = Value

    @property
    def nodes(self):
        return self.__nodes

    @nodes.setter
    def nodes(self, Value):
        for i, v in enumerate(Value):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.node.Ipv6Address_{}.value={}".format(self.name, i, v)).execute()
        self.__nodes = Value


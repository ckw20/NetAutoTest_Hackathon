from .header_base import *

file_path = SCHEMA_PATH + "IcmpV6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("icmpv6Redirect")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Icmpv6RedirectHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("icmpv6Redirect")
        self.__type = paramDict["type"]
        self.__code = paramDict["code"]
        self.__checksum = paramDict["checksum"]
        self.__reserve = paramDict["reserve"]
        self.__targetAddress = paramDict["targetAddress"]
        self.__destAddress = paramDict["destAddress"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def code(self):
        return self.__code

    @code.setter
    def code(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__code = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def reserve(self):
        return self.__reserve

    @reserve.setter
    def reserve(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserve = Value

    @property
    def targetAddress(self):
        return self.__targetAddress

    @targetAddress.setter
    def targetAddress(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__targetAddress = Value

    @property
    def destAddress(self):
        return self.__destAddress

    @destAddress.setter
    def destAddress(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__destAddress = Value

    # Option:
    # optionSourceLinkLayerAddress
    # optionTargetLinkLayerAddress
    # optionPrefixInformation
    # optionMTU
    # generalTLV
    # generalWildcardTLV
    def insertLinkLayerOption(self, Option):
        for i in Option:
            i = i[:1].lower()+i[1:]
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.linkLayerOption'.format(self.name),
                                    NodeName=i).execute()

    # options:
    # RedirectedHeader
    def insertRedirectorOption(self):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.redirectedHdrOption'.format(self.name),
                                NodeName='RedirectedHeader').execute()

    # icmpv6Redirect_1.linkLayerOption
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation.type
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation.length
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation.prefixLength
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation.onLinkFlag
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation.autonomousFlag
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation.reserved
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_0.optionPrefixInformation.validLifetime
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_1.generalWildcardTLV
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_1.generalWildcardTLV.type
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_2.generalTLV
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_2.generalTLV.type
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_2.generalTLV.length
    # icmpv6Redirect_1.linkLayerOption.icmpv6HeaderOptionList_2.generalTLV.value
    def getLinkLayerOption(self, Option, Field, Index=0):
        Option = Option[:1].lower() + Option[1:]
        Field = Field[:1].lower() + Field[1:]
        return self.get_value(
            '{}.linkLayerOption.icmpv6HeaderOptionList_{}.{}.{}'.format(self.name, Index, Option, Field))

    def editLinkLayerOption(self, Option, Index=0, **kwargs):
        result = {}
        Option = Option[:1].lower() + Option[1:]
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.linkLayerOption.icmpv6HeaderOptionList_{}.{}.{}={}'.format(self.name, Index, Option, k_, v))
            result.update({k: f'linkLayerOption.icmpv6HeaderOptionList_{Index}.{Option}.{k_}'})
        return result

    # icmpv6Redirect_1.redirectedHdrOption
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.type
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.length
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.reserved1
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.reserved2
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.version
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.trafficClass
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.FlowLabel
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.payloadLength
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.nextHeader
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.hopLimit
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.source
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.destination
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.ipv6Header.gateway
    # icmpv6Redirect_1.redirectedHdrOption.RedirectedHeader_0.ipData.data
    def getRedirectorOption(self, Field, Index=0):
        if Field != 'FlowLabel':
            Field = Field[:1].lower()+Field[1:]
        if Field in ['type', 'length', 'reserved1', 'reserved2']:
            return self.get_value('{}.redirectedHdrOption.RedirectedHeader_{}.{}'.format(self.name, Index, Field))
        elif Field == 'data':
            return self.get_value(
                '{}.redirectedHdrOption.RedirectedHeader_{}.ipData.{}'.format(self.name, Index, Field))
        else:
            return self.get_value(
                '{}.redirectedHdrOption.RedirectedHeader_{}.ipData.ipv6Header.{}'.format(self.name, Index, Field))

    def editRedirectorOption(self, Index=0, **kwargs):
        result = {}
        for k, v in kwargs.items():
            if k != 'FlowLabel':
                k_ = k[:1].lower()+k[1:]
            else:
                k_ = k
            if k in ['type', 'length', 'reserved1', 'reserved2']:
                self.update('{}.redirectedHdrOption.RedirectedHeader_{}.{}={}'.format(self.name, Index, k_, v))
                result.update({k: f'redirectedHdrOption.RedirectedHeader_{Index}.{k_}'})
            elif k == 'data':
                self.update('{}.redirectedHdrOption.RedirectedHeader_{}.ipData.{}={}'.format(self.name, Index, k_, v))
                result.update({k: f'redirectedHdrOption.RedirectedHeader_{Index}.ipData.{k_}'})
            else:
                self.update(
                    '{}.redirectedHdrOption.RedirectedHeader_{}.ipData.ipv6Header.{}={}'.format(self.name, Index, k_, v))
                result.update({k: f'redirectedHdrOption.RedirectedHeader_{Index}.ipData.ipv6Header.{k_}'})
        return result
from .header_base import *

file_path = SCHEMA_PATH + "MacInMac.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("mac-in-mac")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class MacInMacHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("mac-in-mac")
        self.__destMacAdd = paramDict["destMacAdd"]
        self.__sourceMacAdd = paramDict["sourceMacAdd"]
        self.__etherType = paramDict["etherType"]
        self.__vlanType = '88a8'
        self.__vlanPCP = '001'
        self.__dei = '1'
        self.__vid = '100'
        # need insert node of bTag
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.bVLANTag'.format(self.name),
                                NodeName='btag').execute()

    @property
    def destMacAdd(self):
        return self.__destMacAdd

    @destMacAdd.setter
    def destMacAdd(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__destMacAdd = Value

    @property
    def sourceMacAdd(self):
        return self.__sourceMacAdd

    @sourceMacAdd.setter
    def sourceMacAdd(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sourceMacAdd = Value

    @property
    def etherType(self):
        return self.__etherType

    @etherType.setter
    def etherType(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__etherType = Value

    @property
    def vlanType(self):
        return self.__vlanType

    @vlanType.setter
    def vlanType(self, Value):
        self.update('{}.bVLANTag.tagOption_0.btag.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__vlanType = Value

    @property
    def vlanPCP(self):
        return self.__vlanPCP

    @vlanPCP.setter
    def vlanPCP(self, Value):
        self.update('{}.bVLANTag.tagOption_0.btag.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__vlanPCP = Value

    @property
    def dei(self):
        return self.__dei

    @dei.setter
    def dei(self, Value):
        self.update('{}.bVLANTag.tagOption_0.btag.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__dei = Value

    @property
    def vid(self):
        return self.__vid

    @vid.setter
    def vid(self, Value):
        self.update('{}.bVLANTag.tagOption_0.btag.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__vid = Value


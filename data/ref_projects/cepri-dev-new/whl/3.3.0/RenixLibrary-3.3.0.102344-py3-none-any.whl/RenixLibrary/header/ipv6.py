from .header_base import *

file_path = SCHEMA_PATH + "Ipv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv6")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv6Header(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, Icmp=False, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ipv6")
        self.__icmp = Icmp
        self.__version = paramDict["version"]
        self.__trafficClass = paramDict["trafficClass"]
        self.__FlowLabel = paramDict["FlowLabel"]
        self.__payloadLength = paramDict["payloadLength"]
        self.__nextHeader = paramDict["nextHeader"]
        self.__hopLimit = paramDict["hopLimit"]
        self.__source = paramDict["source"]
        self.__destination = paramDict["destination"]
        self.__gateway = paramDict["gateway"]

    @property
    def keyword(self):
        if self.__icmp:
            self.__keyword = '{}.headerData.ipv6Header'.format(self.name)
        else:
            self.__keyword = self.name
        return self.__keyword

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        self.update("{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value))
        # UpdateHeaderCommand(Stream=self.stream.handle,
        #                     Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__version = Value

    @property
    def trafficClass(self):
        return self.__trafficClass

    @trafficClass.setter
    def trafficClass(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__trafficClass = Value

    @property
    def FlowLabel(self):
        return self.__FlowLabel

    @FlowLabel.setter
    def FlowLabel(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__FlowLabel = Value

    @property
    def payloadLength(self):
        return self.__payloadLength

    @payloadLength.setter
    def payloadLength(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__payloadLength = Value

    @property
    def nextHeader(self):
        return self.__nextHeader

    @nextHeader.setter
    def nextHeader(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__nextHeader = Value

    @property
    def hopLimit(self):
        return self.__hopLimit

    @hopLimit.setter
    def hopLimit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__hopLimit = Value

    @property
    def source(self):
        return self.__source

    @source.setter
    def source(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__source = Value

    @property
    def destination(self):
        return self.__destination

    @destination.setter
    def destination(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__destination = Value

    @property
    def gateway(self):
        return self.__gateway

    @gateway.setter
    def gateway(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__gateway = Value


if __name__ == '__main__':
    object_ = Ipv6Header()
    print(object_)
    print(Ipv6Header.destination)
    print(Ipv6Header.source)
    print(Ipv6Header.gateway)
    object_ = Ipv6Header(destination="3001::1:f1:11", source="4001::1:f1:11", gateway="5001::1:f1:11")
    print(object_.destination)
    print(object_.source)
    print(object_.gateway)

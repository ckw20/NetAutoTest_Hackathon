from .header_base import *

file_path = SCHEMA_PATH + "EthernetTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ethernetII")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class EthernetHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ethernetII")
        self.__destMacAdd = paramDict["destMacAdd"]
        self.__sourceMacAdd = paramDict["sourceMacAdd"]
        self.__protocolType = paramDict["protocolType"]

    @property
    def destMacAdd(self):
        return self.__destMacAdd

    @destMacAdd.setter
    def destMacAdd(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__destMacAdd = Value

    @property
    def sourceMacAdd(self):
        return self.__sourceMacAdd

    @sourceMacAdd.setter
    def sourceMacAdd(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sourceMacAdd = Value

    @property
    def protocolType(self):
        return self.__protocolType

    @protocolType.setter
    def protocolType(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__protocolType = Value


if __name__ == '__main__':
    object_1 = EthernetHeader(Upper="")
    print(object_1)
    print(EthernetHeader.destMacAdd)
    print(EthernetHeader.sourceMacAdd)
    print(EthernetHeader.protocolType)
    object_2 = EthernetHeader(Upper="", destMacAdd="00:00:00:13:40:21", sourceMacAdd="00:00:00:12:30:11",
                              protocolType="1111")
    print(object_2.destMacAdd)
    print(object_2.sourceMacAdd)
    print(object_2.protocolType)
    print(type(object_1))
    print(type(object_2))
    if type(object_1) == type(object_2):
        print(1)
    else:
        print(2)

    if type(object_1) is type(object_2):
        print(3)
    else:
        print(4)

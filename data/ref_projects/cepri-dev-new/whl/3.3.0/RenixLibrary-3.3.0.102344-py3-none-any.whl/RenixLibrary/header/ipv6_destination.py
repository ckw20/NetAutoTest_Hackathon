from .header_base import *

file_path = SCHEMA_PATH + "Ipv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv6DestinationHeader")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv6DestinationHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ipv6DestinationHeader")
        self.__nextHeader = paramDict["nextHeader"]
        self.__length = paramDict["length"]
        self.__pad = paramDict["pad"]

    @property
    def nextHeader(self):
        return self.__nextHeader

    @nextHeader.setter
    def nextHeader(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nextHeader = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def pad(self):
        return self.__pad

    @pad.setter
    def pad(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pad = Value

    def insert_option_header(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.options'.format(self.name),
                                    NodeName='{}'.format(x)).execute()

    def edit_pad1_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'type' in set(kwargs.keys()):
            self.update("{}.options.ipv6DestinationOptionList_{}.pad1.type={}".format(
                self.name, Index, kwargs['type']))
            result.update({'Type': f"options.ipv6DestinationOptionList_{Index}.pad1.type"})
        return result

    def edit_padN_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'padding']:
                self.update("{}.options.ipv6DestinationOptionList_{}.padN.{}={}".format(self.name, Index, k, v))
                result.update(
                    {(k[:1].upper() + k[1:]): "options.ipv6DestinationOptionList_{}.padN.{}".format(Index, k)})
        return result

    def edit_custom_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'data']:
                self.update("{}.options.ipv6DestinationOptionList_{}.generalTLV.{}={}".format(self.name, Index, k, v))
                result.update(
                    {(k[:1].upper() + k[1:]): "options.ipv6DestinationOptionList_{}.generalTLV.{}".format(Index, k)})
        return result

    def edit_bier(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['optiontype', 'optionlen', 'biftId', 'trafficClass', 'sBit', 'ttl', 'nibble', 'bierVer', 'bsl',
                     'entropy', 'oam', 'rsv', 'dscp', 'protocol', 'bfirId']:
                self.update("{}.options.ipv6DestinationOptionList_{}.bierv6.{}={}".format(self.name, Index, k, v))
                result.update(
                    {(k[:1].upper() + k[1:]): "options.ipv6DestinationOptionList_{}.bierv6.{}".format(Index, k)})
            elif k == 'bierbitString':
                for i in range(v):
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName='{}.options.ipv6DestinationOptionList_{}.bierv6.bierbitString'.format(self.name, Index),
                                            NodeName='bitStringsOption').execute()
        return result

    def get_bier(self, Index, Item):
        Item_ = Item[:1].lower() + Item[1:]
        if Item_ in ['optiontype', 'optionlen', 'biftId', 'trafficClass', 'sBit', 'ttl', 'nibble', 'bierVer', 'bsl',
                 'entropy', 'oam', 'rsv', 'dscp', 'protocol', 'bfirId', 'bierbitString']:
            return self.get_value(field='{}.options.ipv6DestinationOptionList_{}.bierv6.{}'.format(
                self.name, Index, Item_))

    def edit_bier_bit_string(self, BierIndex, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k_ in ['bitString', 'bitString2']:
                self.update("{}.options.ipv6DestinationOptionList_{}.bierv6.bierbitString.customOption_{}.bitStringsOption.{}={}".format(
                    self.name, BierIndex, Index, k_, v))
                result.update({k: "options.ipv6DestinationOptionList_{}.bierv6.bierbitString.customOption_{}.bitStringsOption.{}".format(
                    BierIndex, Index, k_)})
        return result

    def get_bier_bit_string(self, BierIndex, Index, Item):
        Item_ = Item[:1].lower() + Item[1:]
        if Item_ in ['bitString', 'bitString2']:
            return self.get_value(field='{}.options.ipv6DestinationOptionList_{}.bierv6.bierbitString.customOption_{}.bitStringsOption.{}'.format(
                self.name, BierIndex, Index, Item_))

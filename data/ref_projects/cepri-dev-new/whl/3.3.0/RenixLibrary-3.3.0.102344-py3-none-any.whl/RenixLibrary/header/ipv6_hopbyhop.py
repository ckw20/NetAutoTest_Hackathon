from .header_base import *

file_path = SCHEMA_PATH + "Ipv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv6HopByHopHeader")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv6HopByHopHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ipv6HopByHopHeader")
        self.__nextHeader = paramDict["nextHeader"]
        self.__length = paramDict["length"]
        self.__pad = paramDict["pad"]

    @property
    def nextHeader(self):
        return self.__nextHeader

    @nextHeader.setter
    def nextHeader(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nextHeader = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def pad(self):
        return self.__pad

    @pad.setter
    def pad(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pad = Value

    def insert_option_header(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.options'.format(self.name),
                                    NodeName='{}'.format(x)).execute()

    def edit_pad1_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'type' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.options.ipv6HopByHopOptionList_{}.pad1.type={}".format(
                                    self.name, Index, kwargs['type'])).execute()
            result.update({'Type': f"options.ipv6HopByHopOptionList_{Index}.pad1.type"})
        return result

    def edit_padN_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'padding']:
                self.update("{}.options.ipv6HopByHopOptionList_{}.padN.{}={}".format(self.name, Index, k, v))
                result.update(
                    {(k[:1].upper() + k[1:]): "options.ipv6HopByHopOptionList_{}.padN.{}".format(Index, k)})
        return result

    def edit_router_alert_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.ipv6HopByHopOptionList_{}.routerAlert.{}={}".format(self.name, Index, k, v))
                result.update(
                    {(k[:1].upper() + k[1:]): "options.ipv6HopByHopOptionList_{}.routerAlert.{}".format(Index, k)})
        return result

    def edit_jumbo_payload_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'data']:
                self.update("{}.options.ipv6HopByHopOptionList_{}.jumbo.{}={}".format(self.name, Index, k, v))
                result.update(
                    {(k[:1].upper() + k[1:]): "options.ipv6HopByHopOptionList_{}.jumbo.{}".format(Index, k)})
        return result

    def edit_custom_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'data']:
                self.update("{}.options.ipv6HopByHopOptionList_{}.generalTLV.{}={}".format(self.name, Index, k, v))
                result.update(
                    {(k[:1].upper() + k[1:]): "options.ipv6HopByHopOptionList_{}.generalTLV.{}".format(Index, k)})
        return result
from .l2tpv3_control import *

file_path = SCHEMA_PATH + "L2tpv3Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("l2tpv3ControlOverUdp")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class l2tpv3ControlOverUdpHeader(L2tpv3Control):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("l2tpv3ControlOverUdp")
        self.__type = paramDict["type"]
        self.__useLength = paramDict["useLength"]
        self.__reserved1 = paramDict["reserved1"]
        self.__useSequence = paramDict["useSequence"]
        self.__reserved2 = paramDict["reserved2"]
        self.__version = paramDict["version"]
        self.__controlId = paramDict["controlId"]
        self.__errorCode = None
        self.__errorMessage = None
        self.__cookie4Byte = None
        self.__cookie8Byte = None
        self.__length = None
        self.__sequenceNumberNs = None
        self.__sequenceNumberNr = None

    # @property
    # def type(self):
    #     return self.__type
    #
    # @type.setter
    # def type(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__type = Value
    #
    # @property
    # def useLength(self):
    #     return self.__useLength
    #
    # @useLength.setter
    # def useLength(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__useLength = Value
    #
    # @property
    # def reserved1(self):
    #     return self.__reserved1
    #
    # @reserved1.setter
    # def reserved1(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__reserved1 = Value
    #
    # @property
    # def useSequence(self):
    #     return self.__useSequence
    #
    # @useSequence.setter
    # def useSequence(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__useSequence = Value
    #
    # @property
    # def reserved2(self):
    #     return self.__reserved2
    #
    # @reserved2.setter
    # def reserved2(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__reserved2 = Value
    #
    # @property
    # def version(self):
    #     return self.__version
    #
    # @version.setter
    # def version(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__version = Value
    #
    # @property
    # def controlId(self):
    #     return self.__controlId
    #
    # @controlId.setter
    # def controlId(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__controlId = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.lengthOption.length_0.value={} '.format(self.name, Value))
        self.__length = Value

    # def insert_lengthOption_length(self, length):
    #     if self.__length is None:
    #         self.__length = length
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.lengthOption'.format(self.name),
    #                                 NodeName='length').execute()
    #     self.edit_lengthOption_length(length=length)
    #     return True
    #
    # def edit_lengthOption_length(self, length=None):
    #     if length is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.lengthOption.length_0.value={}".format(
    #                                 self.name, length)).execute()
    #     return True

    # @property
    # def sequenceNumber(self):
    #     return self.__sequenceNumber
    #
    # def insert_seqNum_sequenceNumber(self, ns=None, nr=None):
    #     if self.__sequenceNumber == {}:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.seqNum'.format(self.name),
    #                                 NodeName='sequenceNumber').execute()
    #     if ns is not None:
    #         self.__sequenceNumber.update({'ns': ns})
    #     if nr is not None:
    #         self.__sequenceNumber.update({'nr': nr})
    #
    #     self.edit_seqNum_sequenceNumber(ns=ns, nr=nr)
    #     return True
    #
    # def edit_seqNum_sequenceNumber(self, ns=None, nr=None):
    #     if ns is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.seqNum.sequenceNumber_0.ns={}".format(self.name, ns)).execute()
    #     if nr is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.seqNum.sequenceNumber_0.nr={}".format(self.name, nr)).execute()
    #     return True
    #
    # def insert_option_header(self, Value):
    #     if not isinstance(Value, (list, set, tuple)):
    #         Value = [Value]
    #     for x in Value:
    #         if x == 'generalTLV':
    #             InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                     ParentName='{}.avpOptions'.format(self.name),
    #                                     NodeName='generalTLV').execute()
    #         else:
    #             InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                     ParentName='{}.avpOptions'.format(self.name),
    #                                     NodeName='{}AvpOption'.format(x)).execute()
    #     return True
    #
    # def _edit_common_parameters(self, Tlv, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     if 'mbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.mbit={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'mbit'])).execute()
    #     if 'hbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.hbit={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'hbit'])).execute()
    #     if 'reserved' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.reserved={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'reserved'])).execute()
    #     if 'length' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.length={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'length'])).execute()
    #     if 'vendorId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.vendorId={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'vendorId'])).execute()
    #
    #     if 'type' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.vendorId={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'type'])).execute()
    #
    # def edit_general_tlv_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='generalTLV', Index=Index, **kwargs)
    #
    #     if 'attributeValue' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.generalTLV.attributeValue={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'attributeValue'])).execute()
    #
    # def edit_message_type_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='messageTypeAvpOption', Index=Index, **kwargs)
    #     if 'messageType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.messageTypeAvpOption.messageType={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'messageType'])).execute()
    #     return True
    #
    # def edit_result_code_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='resultCodeAvpOption', Index=Index, **kwargs)
    #     if 'resultCode' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.resultCodeAvpOption.resultCode={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'resultCode'])).execute()
    #     if 'errorCode' in set(kwargs.keys()):
    #         self.insert_resultcode_errorcode(Index=Index, value=kwargs['errorCode'])
    #     if 'errorMessage' in set(kwargs.keys()):
    #         self.insert_resultcode_errormessage(Index=Index, value=kwargs['errorMessage'])
    #
    # def insert_resultcode_errorcode(self, Index, value):
    #     if self.__errorCode is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorCode'.format(
    #                                     self.name, Index),
    #                                 NodeName='errorCode').execute()
    #         self.__errorCode = True
    #     self.edit_resultcode_errorcode(Index=Index, value=value)
    #     return True
    #
    # def edit_resultcode_errorcode(self, Index, value=None):
    #     if value is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorCode.errorCode_0.value={}".format(
    #                                 self.name, Index, value)).execute()
    #     return True
    #
    # def insert_resultcode_errormessage(self, Index, value):
    #     if self.__errorMessage is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorMessage'.format(
    #                                     self.name, Index),
    #                                 NodeName='errorMessage').execute()
    #         self.__errorMessage = True
    #     self.edit_resultcode_errormessage(Index=Index, value=value)
    #     return True
    #
    # def edit_resultcode_errormessage(self, Index, value=None):
    #     if value is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorMessage.errorMessage_0.value={}".format(
    #                                 self.name, Index, value)).execute()
    #     return True
    #
    # def edit_tie_breaker_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='tieBreakerAvpOption', Index=Index, **kwargs)
    #     if 'tieBreakerValue' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.tieBreakerAvpOption.tieBreakerValue={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'tieBreakerValue'])).execute()
    #
    # def edit_receive_windowsize_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='receiveWindowSizeAvpOption', Index=Index, **kwargs)
    #     if 'windowSize' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.receiveWindowSizeAvpOption.windowSize={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'windowSize'])).execute()
    #
    # def edit_call_serialnumber_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='callSerialNumberAvpOption', Index=Index, **kwargs)
    #     if 'callSerialNumber' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.callSerialNumberAvpOption.callSerialNumber={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'callSerialNumber'])).execute()
    #
    # def edit_physical_channelid_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='physicalChannelIdAvpOption', Index=Index, **kwargs)
    #     if 'physicalChannelId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.physicalChannelIdAvpOption.physicalChannelId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'physicalChannelId'])).execute()
    #
    # def edit_circuit_error_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='circuitErrorAvpOption', Index=Index, **kwargs)
    #     if 'reserved1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitErrorAvpOption.reserved1={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'reserved1'])).execute()
    #     if 'hardwareOverruns' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitErrorAvpOption.hardwareOverruns={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'hardwareOverruns'])).execute()
    #     if 'bufferOverruns' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitErrorAvpOption.bufferOverruns={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'bufferOverruns'])).execute()
    #     if 'timeoutOverruns' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitErrorAvpOption.timeoutOverruns={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'timeoutOverruns'])).execute()
    #     if 'alignmentOverruns' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitErrorAvpOption.alignmentOverruns={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'alignmentOverruns'])).execute()
    #
    # def edit_routeid_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='routeIdAvpOption', Index=Index, **kwargs)
    #     if 'routeId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.routeIdAvpOption.routeId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'routeId'])).execute()
    #
    # def edit_assigned_connection_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='assignedConnectionAvpOption', Index=Index, **kwargs)
    #     if 'connectionId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.assignedConnectionAvpOption.connectionId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'connectionId'])).execute()
    #
    # def edit_local_sessionid_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='localSessionIdAvpOption', Index=Index, **kwargs)
    #     if 'sessionId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.localSessionIdAvpOption.sessionId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'sessionId'])).execute()
    #
    # def edit_remote_sessionid_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='remoteSessionIdAvpOption', Index=Index, **kwargs)
    #     if 'sessionId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.remoteSessionIdAvpOption.sessionId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'sessionId'])).execute()
    #
    # def edit_assigned_cookie_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='assignedCookieAvpOption', Index=Index, **kwargs)
    #     if 'assignedCookie' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.assignedCookieAvpOption.assignedCookie={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'assignedCookie'])).execute()
    #     if 'cookie4Byte' in set(kwargs.keys()):
    #         self.insert_cookie_4byte(Index=Index, value=kwargs['cookie4Byte'])
    #     else:
    #         'cookie8Byte' in set(kwargs.keys())
    #         self.insert_cookie_8byte(Index=Index, value=kwargs['cookie8Byte'])
    #
    # def insert_cookie_4byte(self, Index, value):
    #     if self.__cookie4Byte is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.avpOptions.avpOption_{}.assignedCookieAvpOption.assignedCookie'.format(
    #                                     self.name, Index),
    #                                 NodeName='cookie4Byte').execute()
    #         self.__cookie4Byte = True
    #     self.edit_cookie_4byte(Index=Index, value=value)
    #     return True
    #
    # def edit_cookie_4byte(self, Index, value=None):
    #     if value is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.assignedCookieAvpOption.assignedCookie.cookie_0.cookie4Byte.value={}".format(
    #                                 self.name, Index, value)).execute()
    #     return True
    #
    # def insert_cookie_8byte(self, Index, value):
    #     if self.__cookie8Byte is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.avpOptions.avpOption_{}.assignedCookieAvpOption.assignedCookie'.format(
    #                                     self.name, Index),
    #                                 NodeName='cookie8Byte').execute()
    #         self.__cookie8Byte = True
    #     self.edit_cookie_8byte(Index=Index, value=value)
    #     return True
    #
    # def edit_cookie_8byte(self, Index, value=None):
    #     if value is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.assignedCookieAvpOption.assignedCookie.cookie_0.cookie8Byte.value={}".format(
    #                                 self.name, Index, value)).execute()
    #     return True
    #
    # def edit_pw_type_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='pwTypeAvpOption', Index=Index, **kwargs)
    #     if 'pwType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.pwTypeAvpOption.pwType={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'pwType'])).execute()
    #
    # def edit_l2_specificsub_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='l2SpecificSubAvpOption', Index=Index, **kwargs)
    #     if 'l2SpecificSublayer' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.l2SpecificSubAvpOption.l2SpecificSublayer={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'l2SpecificSublayer'])).execute()
    #
    # def edit_data_sequencing_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='dataSequencingAvpOption', Index=Index, **kwargs)
    #     if 'dataSequencing' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.dataSequencingAvpOption.dataSequencing={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'dataSequencing'])).execute()
    #
    # def edit_tx_connectspeed_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='txConnectSpeedAvpOption', Index=Index, **kwargs)
    #     if 'speedBps' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.txConnectSpeedAvpOption.speedBps={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'speedBps'])).execute()
    #
    #     if 'lowBPS' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.rxConnectSpeedAvpOption.lowBPS={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'lowBPS'])).execute()
    #
    # def edit_rx_connectspeed_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='rxConnectSpeedAvpOption', Index=Index, **kwargs)
    #     if 'speedBps' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.rxConnectSpeedAvpOption.speedBps={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'speedBps'])).execute()
    #
    # def edit_circuit_status_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='circuitStatusAvpOption', Index=Index, **kwargs)
    #     if 'reserved1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitStatusAvpOption.reserved1={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'reserved1'])).execute()
    #     if 'nbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitStatusAvpOption.nbit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'nbit'])).execute()
    #     if 'abit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.circuitStatusAvpOption.abit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'abit'])).execute()



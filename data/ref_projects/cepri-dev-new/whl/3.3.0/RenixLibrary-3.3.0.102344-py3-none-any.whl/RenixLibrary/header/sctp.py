from .header_base import *

file_path = SCHEMA_PATH + "SctpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("sctpHeader")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class SctpHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("sctp")
        self.__sourcePort = paramDict["sourcePort"]
        self.__destPort = paramDict["destPort"]
        self.__verTag = paramDict["verTag"]
        self.__checksum = paramDict["checksum"]
        self.__chunkList = 0

    @property
    def sourcePort(self):
        return self.__sourcePort

    @sourcePort.setter
    def sourcePort(self, Value):
        self.update('{}.header.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sourcePort = Value

    @property
    def destPort(self):
        return self.__destPort

    @destPort.setter
    def destPort(self, Value):
        self.update('{}.header.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__destPort = Value

    @property
    def verTag(self):
        return self.__verTag

    @verTag.setter
    def verTag(self, Value):
        self.update('{}.header.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__verTag = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.header.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def chunkList(self):
        return self.__chunkList

    @chunkList.setter
    def chunkList(self, Value):
        if Value > 0:
            InsertNodeToASetCommand(Stream=self.stream.handle, ParentName=f'{self.name}.chunks', NodeName='sctpChunk',
                                    NodeCount=Value).execute()
        else:
            # delete nodes
            pass
        self.__chunkList = Value

    def insert_chunk_type(self, Index, Type):
        InsertNodeToASetCommand(Stream=self.stream.handle, ParentName=f'{self.name}.chunks.sctpChunk_{Index}.chunkType',
                                NodeName=Type[:1].lower()+Type[1:]).execute()
        return True

    def edit_data_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.dataChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.dataChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_init_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k == 'InitOptionalParams':
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName=f'{self.name}.chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initChunk.initOptionalParams',
                                        NodeName='InitOptionalParameters',
                                        NodeCount=v).execute()
                continue
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_init_optional_parameters_tlv(self, ChunkType, ChunkIndex, TlvIndex, **kwargs):
        result = {}
        ChunkType_ = ChunkType[:1].lower()+ChunkType[1:]
        for k, v in kwargs.items():
            if k in ['InitAckOptionalParamType', 'InitOptionalParamType']:
                k_ = k
            else:
                k_ = k[:1].lower() + k[1:]
            if ChunkType == 'InitChunk':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.initOptionalParams.InitOptionalParameters_{TlvIndex}.{k_}'
            elif ChunkType == 'InitAckChunk':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.initOptionalParams.InitAckOptionalParamTLV_{TlvIndex}.{k_}'
            else:
                return False
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_init_ack_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k == 'InitOptionalParams':
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName=f'{self.name}.chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initAckChunk.initOptionalParams',
                                        NodeName='InitAckOptionalParamTLV',
                                        NodeCount=v).execute()
                continue
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initAckChunk.flags.{k_}'
            elif k == 'StateCookieType':
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initAckChunk.stateCookie.type'
            elif k == 'StateCookieLength':
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initAckChunk.stateCookie.length'
            elif k == 'StateCookieValue':
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initAckChunk.stateCookie.value'
            elif k == 'StateCookiePadding':
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initAckChunk.stateCookie.padding'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.initAckChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_sack_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k == 'GapAckBlocks':
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName=f'{self.name}.chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.sackChunk.gapackBlocks',
                                        NodeName='GapAckBlock',
                                        NodeCount=v).execute()
                continue
            elif k == 'DuplicateTSNs':
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName=f'{self.name}.chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.sackChunk.duplicateTSNs',
                                        NodeName='DuplicateTSN',
                                        NodeCount=v).execute()
                continue
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.sackChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.sackChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_sack_chunk_gap_ack_block(self, ChunkIndex, BlockIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.sackChunk.gapackBlocks.GapAckBlock_{BlockIndex}.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_sack_chunk_duplicate_tsn(self, ChunkIndex, TsnIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.sackChunk.duplicateTSNs.DuplicateTSN_{TsnIndex}.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_heartbeat_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatChunk.flags.{k_}'
            elif k in ['HbInfoType', 'HbInfoLength', 'HbInfoValue']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatChunk.heartbeatInformationTLV.{k_}'
            elif k == 'HbInfoPadding':
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatChunk.heartbeatInformationTLV.padding'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_heartbeat_ack_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatAckChunk.flags.{k_}'
            elif k in ['HbInfoType', 'HbInfoLength', 'HbInfoValue']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatAckChunk.heartbeatInformationTLV.{k_}'
            elif k == 'HbInfoPadding':
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatAckChunk.heartbeatInformationTLV.padding'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.heartbeatAckChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_abort_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k == 'ErrorCauses':
                if not isinstance(v, list):
                    v = [v]
                for value in v:
                    value_ = value[:1].lower()+value[1:]
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName=f'{self.name}.chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.abortChunk.errorCauses',
                                            NodeName=value_).execute()
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.abortChunk.{k_}'
                self.update(f'{self.name}.{field}={v} ')
                result.update({k: field})
        return result

    def edit_abort_error_chunk_error_cause(self, ChunkType, ChunkIndex, CauseIndex, CauseType, **kwargs):
        result = {}
        ChunkType_ = ChunkType[:1].lower()+ChunkType[1:]
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if CauseType == 'InvalidStreamIdentifier':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.invalidStreamIdentifier.{k_}'
            elif CauseType == 'MissingMandatoryParameter':
                if k == 'MissingParamType':
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName=f'{self.name}.chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.missingMandatoryParameter.missingParamTypes',
                                            NodeName='MissingParamType',
                                            NodeCount=v).execute()
                    continue
                else:
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.missingMandatoryParameter.{k_}'
            elif CauseType == 'StaleCookieError':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.staleCookieError.{k_}'
            elif CauseType == 'OutOfResource':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.outOfResource.{k_}'
            elif CauseType == 'UnresolvableAddress':
                if k == 'NewAddressTlvs':
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName=f'{self.name}.chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unresolvableAddress.addressTLVs',
                                            NodeName='AddressTLV',
                                            NodeCount=v).execute()
                    continue
                else:
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unresolvableAddress.{k_}'
            elif CauseType == 'UnrecognizedChunk':
                if k == 'UnrecognizedChunkType':
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedChunk.unrecognizedChunk.type'
                elif k == 'UnrecognizedChunkFlagReserved':
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedChunk.unrecognizedChunk.flags.reserved'
                elif k == 'UnrecognizedChunkFlagUbit':
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedChunk.unrecognizedChunk.flags.ubit'
                elif k == 'UnrecognizedChunkFlagBbit':
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedChunk.unrecognizedChunk.flags.bbit'
                elif k == 'UnrecognizedChunkFlagEbit':
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedChunk.unrecognizedChunk.flags.ebit'
                elif k == 'UnrecognizedChunkLength':
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedChunk.unrecognizedChunk.length'
                else:
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedChunk.{k_}'
            elif CauseType == 'InvalidMandatoryParameter':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.invalidMandatoryParameter.{k_}'
            elif CauseType == 'UnrecognizedParameters':
                if k == 'UnrecognizedParameters':
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName=f'{self.name}.chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedParameters.unrecognizedParameters',
                                            NodeName='UnrecognizedParameterLTV',
                                            NodeCount=v).execute()
                    continue
                else:
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedParameters.{k_}'
            elif CauseType == 'NoUserData':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.noUserData.{k_}'
            elif CauseType == 'CookieReceivedWhileShuttingDown':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.cookieReceivedWhileShuttingDown.{k_}'
            elif CauseType == 'RestartOfAnAssociationWithNewAddresses':
                if k == 'NewAddressTlvs':
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName=f'{self.name}.chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.restartOfAnAssociationWithNewAddresses.newAddressTLVs',
                                            NodeName='NewAddressTLV',
                                            NodeCount=v).execute()
                    continue
                else:
                    field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.restartOfAnAssociationWithNewAddresses.{k_}'
            elif CauseType == 'UserInitiatedAbort':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.userInitiatedAbort.{k_}'
            elif CauseType == 'ProtocolViolation':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.protocolViolation.{k_}'
            else:
                return False
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_abort_error_chunk_error_cause_missing_parameter_type(self, ChunkType, ChunkIndex, CauseIndex, TypeIndex, **kwargs):
        result = {}
        ChunkType_ = ChunkType[:1].lower()+ChunkType[1:]
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.missingMandatoryParameter.missingParamTypes.MissingParamType_{TypeIndex}.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_abort_error_chunk_error_cause_unrecognized_parameter_tlv(self, ChunkType, ChunkIndex, CauseIndex, TlvIndex, **kwargs):
        result = {}
        ChunkType_ = ChunkType[:1].lower()+ChunkType[1:]
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unrecognizedParameters.unrecognizedParameters.UnrecognizedParameterLTV_{TlvIndex}.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_error_cause_new_address_tlv(self, ChunkType, ChunkIndex, CauseType, CauseIndex, TlvIndex, **kwargs):
        result = {}
        ChunkType_ = ChunkType[:1].lower()+ChunkType[1:]
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if CauseType == 'UnresolvableAddress':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.unresolvableAddress.addressTLVs.AddressTLV_{TlvIndex}.{k_}'
            elif CauseType == 'RestartOfAnAssociationWithNewAddresses':
                field = f'chunks.sctpChunk_{ChunkIndex}.chunkType.sctpChunkChoice_0.{ChunkType_}.errorCauses.ErrorCausesTLV_{CauseIndex}.restartOfAnAssociationWithNewAddresses.newAddressTLVs.NewAddressTLV_{TlvIndex}.{k_}'
            else:
                return False
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_shutdown_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.shutdownChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.shutdownChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_shutdown_ack_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.shutdownAckChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.shutdownAckChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_error_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k == 'ErrorCauses':
                if not isinstance(v, list):
                    v = [v]
                for value in v:
                    value_ = value[:1].lower()+value[1:]
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName=f'{self.name}.chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.errorChunk.errorCauses',
                                            NodeName=value_).execute()
                continue
            if k in ['Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.errorChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.errorChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_cookie_echo_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.cookieEchoChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.cookieEchoChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_cookie_ack_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            if k in ['Reserved', 'Ubit', 'Bbit', 'Ebit']:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.cookieAckChunk.flags.{k_}'
            else:
                field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.cookieAckChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result

    def edit_shutdown_complete_chunk(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            field = f'chunks.sctpChunk_{Index}.chunkType.sctpChunkChoice_0.shutdownCompleteChunk.{k_}'
            self.update(f'{self.name}.{field}={v} ')
            result.update({k: field})
        return result



from .raw_802_3 import Raw8023Header
from .header_base import *

file_path = SCHEMA_PATH + "EthernetTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("8023")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Dot3Header(Raw8023Header):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("8023")
        self.__dsap = 'AA'
        self.__ssap = 'AA'
        self.__control = '03'
        self.__oui = '000000'
        self.__type = 'FFFF'

    @property
    def dsap(self):
        return self.__dsap

    @dsap.setter
    def dsap(self, Value):
        self.update('{}.llcHeaderIns.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__dsap = Value

    @property
    def ssap(self):
        return self.__ssap

    @ssap.setter
    def ssap(self, Value):
        self.update('{}.llcHeaderIns.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__ssap = Value

    @property
    def control(self):
        return self.__control

    @control.setter
    def control(self, Value):
        self.update('{}.llcHeaderIns.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__control = Value

    @property
    def oui(self):
        return self.__oui

    @oui.setter
    def oui(self, Value):
        self.update('{}.snapIns.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__oui = Value

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.snapIns.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value







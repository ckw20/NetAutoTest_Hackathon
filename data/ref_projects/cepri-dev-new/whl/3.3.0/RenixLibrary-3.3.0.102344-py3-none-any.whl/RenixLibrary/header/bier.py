from .header_base import *

file_path = SCHEMA_PATH + "BierTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("bier")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class BierHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("bier")
        self.__biftId = paramDict["biftId"]
        self.__trafficClass = paramDict["trafficClass"]
        self.__sBit = paramDict["sBit"]
        self.__ttl = paramDict["ttl"]
        self.__nibble = paramDict["nibble"]
        self.__bierVer = paramDict["bierVer"]
        self.__bsl = paramDict["bsl"]
        self.__entropy = paramDict["entropy"]
        self.__oam = paramDict["oam"]
        self.__rsv = paramDict["rsv"]
        self.__dscp = paramDict["dscp"]
        self.__protocol = paramDict["protocol"]
        self.__bfirId = paramDict["bfirId"]
        self.__bierbitString = 0

    @property
    def biftId(self):
        return self.__biftId

    @biftId.setter
    def biftId(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__biftId = Value

    @property
    def trafficClass(self):
        return self.__trafficClass

    @trafficClass.setter
    def trafficClass(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__trafficClass = Value

    @property
    def sBit(self):
        return self.__sBit

    @sBit.setter
    def sBit(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sBit = Value

    @property
    def ttl(self):
        return self.__ttl

    @ttl.setter
    def ttl(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__ttl = Value

    @property
    def nibble(self):
        return self.__nibble

    @nibble.setter
    def nibble(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nibble = Value

    @property
    def bierVer(self):
        return self.__bierVer

    @bierVer.setter
    def bierVer(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__bierVer = Value

    @property
    def bsl(self):
        return self.__bsl

    @bsl.setter
    def bsl(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__bsl = Value

    @property
    def entropy(self):
        return self.__entropy

    @entropy.setter
    def entropy(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__entropy = Value

    @property
    def oam(self):
        return self.__oam

    @oam.setter
    def oam(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__oam = Value

    @property
    def rsv(self):
        return self.__rsv

    @rsv.setter
    def rsv(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__rsv = Value

    @property
    def dscp(self):
        return self.__dscp

    @dscp.setter
    def dscp(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__dscp = Value

    @property
    def protocol(self):
        return self.__protocol

    @protocol.setter
    def protocol(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__protocol = Value

    @property
    def bfirId(self):
        return self.__bfirId

    @bfirId.setter
    def bfirId(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__bfirId = Value

    @property
    def bierbitString(self):
        return self.__bierbitString

    @bierbitString.setter
    def bierbitString(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.bierbitString'.format(self.name),
                                    NodeName='bitStringsOption').execute()
        self.__bierbitString = Value

    def config_bit_string(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.bierbitString.customOption_{}.bitStringsOption.{}={} '.format(
                self.name, Index, k_, v))
            result.update({k: 'bierbitString.customOption_{}.bitStringsOption.{}'.format(Index, k_)})
        return result

    def get_bit_string(self, Index, Item):
        return self.get_value(field='{}.bierbitString.customOption_{}.bitStringsOption.{}'.format(
            self.name, Index, Item[:1].lower()+Item[1:]))




from .header_base import *

file_path = SCHEMA_PATH + "L2tpv2Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("l2tpv2Data")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class l2tpv2DataHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("l2tpv2Data")
        self.__type = paramDict["type"]
        self.__useLength = paramDict["useLength"]
        self.__reserved1 = paramDict["reserved1"]
        self.__useSequence = paramDict["useSequence"]
        self.__reserved2 = paramDict["reserved2"]
        self.__useOffset = paramDict["useOffset"]
        self.__usePriority = paramDict["usePriority"]
        self.__reserved3 = paramDict["reserved3"]
        self.__version = paramDict["version"]
        self.__lengthOption = paramDict["lengthOption"]
        self.__tunnelId = paramDict["tunnelId"]
        self.__sessionId = paramDict["sessionId"]
        self.__seqNum = paramDict["seqNum"]
        self.__offsetPadding = paramDict["offsetPadding"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def useLength(self):
        return self.__useLength

    @useLength.setter
    def useLength(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__useLength = Value

    @property
    def reserved1(self):
        return self.__reserved1

    @reserved1.setter
    def reserved1(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved1 = Value

    @property
    def useSequence(self):
        return self.__useSequence

    @useSequence.setter
    def useSequence(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__useSequence = Value

    @property
    def reserved2(self):
        return self.__reserved2

    @reserved2.setter
    def reserved2(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved2 = Value

    @property
    def useOffset(self):
        return self.__useOffset

    @useOffset.setter
    def useOffset(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__useOffset = Value

    @property
    def usePriority(self):
        return self.__usePriority

    @usePriority.setter
    def usePriority(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__usePriority = Value

    @property
    def reserved3(self):
        return self.__reserved3

    @reserved3.setter
    def reserved3(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved3 = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version = Value

    @property
    def lengthOption(self):
        return self.__lengthOption

    @lengthOption.setter
    def lengthOption(self, Value):
        self.update('{}.{}.length_0.value={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lengthOption = Value

    @property
    def tunnelId(self):
        return self.__tunnelId

    @tunnelId.setter
    def tunnelId(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__tunnelId = Value

    @property
    def sessionId(self):
        return self.__sessionId

    @sessionId.setter
    def sessionId(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__destPort = Value

    @property
    def seqNum(self):
        return self.__seqNum

    @seqNum.setter
    def seqNum(self, Value):
        # cmd = ListInstanceLeafCommand(Stream=self.stream, Deep=True)
        # cmd.execute()
        # nodes = cmd.Leaves
        # if '{}.{}.sequenceNumber_0'.format(self.name, sys._getframe().f_code.co_name) not in nodes:
        #     InsertNodeToASetCommand(Stream=self.stream.handle,
        #                             ParentName='{}.{}'.format(self.name, sys._getframe().f_code.co_name),
        #                             NodeName='sequenceNumber').execute()
        if Value == 0:
            # TBD delete node
            pass
        self.__seqNum = Value

    @property
    def offsetPadding(self):
        return self.__offsetPadding

    @offsetPadding.setter
    def offsetPadding(self, Value):
        # cmd = ListInstanceLeafCommand(Stream=self.stream, Deep=True)
        # cmd.execute()
        # nodes = cmd.Leaves
        # if '{}.{}.padding_0'.format(self.name, sys._getframe().f_code.co_name) not in nodes:
        #     InsertNodeToASetCommand(Stream=self.stream.handle,
        #                             ParentName='{}.{}'.format(self.name, sys._getframe().f_code.co_name),
        #                             NodeName='padding').execute()
        if Value == 0:
            # TBD delete node
            pass
        self.__offsetPadding = Value

    def editHeaderOptions(self, **kwargs):
        result = {}
        for k, v in kwargs.items():
            if k.lower() in ['ns', 'nr']:
                self.update('{}.seqNum.sequenceNumber_0.{}={} '.format(self.name, k.lower(), v))
                result.update({(k[:1].upper() + k[1:]): f'seqNum.sequenceNumber_0.{k.lower()}'})
            elif k.lower() in ['size', 'value']:
                self.update('{}.offsetPadding.padding_0.{}={} '.format(self.name, k.lower(), v))
                result.update({(k[:1].upper() + k[1:]): f'offsetPadding.padding_0.{k.lower()}'})
        return result

from .header_base import *

file_path = SCHEMA_PATH + "TcpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("tcp")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class TcpHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("tcp")
        self.__sourcePort = paramDict["sourcePort"]
        self.__destPort = paramDict["destPort"]
        self.__seqNum = paramDict["seqNum"]
        self.__ackNum = paramDict["ackNum"]
        self.__dataOffset = paramDict["dataOffset"]
        self.__reserved = paramDict["reserved"]
        self.__flags = paramDict["flags"]
        self.__windowSize = paramDict["windowSize"]
        self.__checksum = paramDict["checksum"]
        self.__urgentPointer = paramDict["urgentPointer"]
        self.__option = paramDict["option"]

    @property
    def sourcePort(self):
        return self.__sourcePort

    @sourcePort.setter
    def sourcePort(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sourcePort = Value

    @property
    def destPort(self):
        return self.__destPort

    @destPort.setter
    def destPort(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__destPort = Value

    @property
    def seqNum(self):
        return self.__seqNum

    @seqNum.setter
    def seqNum(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__seqNum = Value

    @property
    def ackNum(self):
        return self.__ackNum

    @ackNum.setter
    def ackNum(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__ackNum = Value

    @property
    def dataOffset(self):
        return self.__dataOffset

    @dataOffset.setter
    def dataOffset(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__dataOffset = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved = Value

    @property
    def flags(self):
        return self.__flags

    @flags.setter
    def flags(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__flags = Value

    @property
    def windowSize(self):
        return self.__windowSize

    @windowSize.setter
    def windowSize(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__windowSize = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__checksum = Value

    @property
    def urgentPointer(self):
        return self.__urgentPointer

    @urgentPointer.setter
    def urgentPointer(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__urgentPointer = Value

    @property
    def option(self):
        return self.__option

    @option.setter
    def option(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__option = Value


if __name__ == '__main__':
    object_ = TcpHeader()
    print(object_)
    print(TcpHeader.sourcePort)
    print(TcpHeader.destPort)
    print(TcpHeader.flags)
    # arp = ArpHeader()
    object_ = TcpHeader(sourcePort=1025, destPort=1026, flags="000213")
    print(object_.sourcePort)
    print(object_.destPort)
    print(object_.flags)

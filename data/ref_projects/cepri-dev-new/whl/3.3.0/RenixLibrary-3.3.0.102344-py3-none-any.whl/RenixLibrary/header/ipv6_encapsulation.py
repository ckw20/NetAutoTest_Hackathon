from .header_base import *

file_path = SCHEMA_PATH + "Ipv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv6EncapsulationHeader")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv6EncapsulationHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ipv6EncapsulationHeader")
        self.__spi = paramDict["spi"]
        self.__seqNum = paramDict["seqNum"]
        self.__payloadData = paramDict["payloadData"]
        self.__padData = paramDict["padData"]
        self.__length = paramDict["length"]
        self.__nextHeader = paramDict["nextHeader"]
        self.__authData = paramDict["authData"]
        self.__pad = paramDict["pad"]

    @property
    def spi(self):
        return self.__spi

    @spi.setter
    def spi(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__spi = Value

    @property
    def seqNum(self):
        return self.__seqNum

    @seqNum.setter
    def seqNum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__seqNum = Value

    @property
    def payloadData(self):
        return self.__payloadData

    @payloadData.setter
    def payloadData(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__payloadData = Value

    @property
    def padData(self):
        return self.__padData

    @padData.setter
    def padData(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__padData = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def nextHeader(self):
        return self.__nextHeader

    @nextHeader.setter
    def nextHeader(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nextHeader = Value

    @property
    def authData(self):
        return self.__authData

    @authData.setter
    def authData(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__authData = Value

    @property
    def pad(self):
        return self.__pad

    @pad.setter
    def pad(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pad = Value
from .header_base import *

file_path = SCHEMA_PATH + "L2tpv2Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("l2tpv2Control")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class l2tpv2ControlHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("l2tpv2Control")
        self.__type = paramDict["type"]
        self.__useLength = paramDict["useLength"]
        self.__reserved1 = paramDict["reserved1"]
        self.__useLength = paramDict["useLength"]
        self.__reserved2 = paramDict["reserved2"]
        self.__useOffset = paramDict["useOffset"]
        self.__usePriority = paramDict["usePriority"]
        self.__reserved3 = paramDict["reserved3"]
        self.__version = paramDict["version"]
        self.__length = paramDict["length"]
        self.__tunnelId = paramDict["tunnelId"]
        self.__sessionId = paramDict["sessionId"]
        self.__ns = paramDict["ns"]
        self.__nr = paramDict["nr"]
        self.__errorCode = None
        self.__errorMessage = None

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__type = Value

    @property
    def useLength(self):
        return self.__useLength

    @useLength.setter
    def useLength(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__useLength = Value

    @property
    def reserved1(self):
        return self.__reserved1

    @reserved1.setter
    def reserved1(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved1 = Value

    @property
    def useSequence(self):
        return self.__useSequence

    @useSequence.setter
    def useSequence(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__useSequence = Value

    @property
    def reserved2(self):
        return self.__reserved2

    @reserved2.setter
    def reserved2(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved2 = Value

    @property
    def useOffset(self):
        return self.__useOffset

    @useOffset.setter
    def useOffset(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__useOffset = Value

    @property
    def usePriority(self):
        return self.__usePriority

    @usePriority.setter
    def usePriority(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__usePriority = Value

    @property
    def reserved3(self):
        return self.__reserved3

    @reserved3.setter
    def reserved3(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved3 = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__version = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__length = Value

    @property
    def tunnelId(self):
        return self.__tunnelId

    @tunnelId.setter
    def tunnelId(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__tunnelId = Value

    @property
    def sessionId(self):
        return self.__sessionId

    @sessionId.setter
    def sessionId(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sessionId = Value

    @property
    def ns(self):
        return self.__ns

    @ns.setter
    def ns(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__ns = Value

    @property
    def nr(self):
        return self.__nr

    @nr.setter
    def nr(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__nr = Value

    def insert_option_header(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            if x == 'generalTLV':
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName='{}.avpOptions'.format(self.name),
                                        NodeName='generalTLV').execute()
            else:
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName='{}.avpOptions'.format(self.name),
                                        NodeName='{}AvpOption'.format(x)).execute()
        return True

    def edit_general_tlv_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'attributeValue']:
                self.update("{}.avpOptions.avpOption_{}.generalTLV.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.generalTLV.{}".format(Index, k)})
        return result

    def edit_message_type_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'messageType']:
                self.update("{}.avpOptions.avpOption_{}.messageTypeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.messageTypeAvpOption.{}".format(Index, k)})
        return result

    def edit_result_code_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'resultCode']:
                self.update("{}.avpOptions.avpOption_{}.resultCodeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.resultCodeAvpOption.{}".format(Index, k)})
            elif k == 'errorCode':
                self.update("{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorCode.errorCode_0.value={}".format(self.name, Index, v))
                result.update({(k[:1].upper()+k[1:]): f'avpOptions.avpOption_{Index}.resultCodeAvpOption.errorCode.errorCode_0.value'})
            elif k == 'errorMessage':
                self.update("{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorMessage.errorMessage_0.value={}".format(self.name, Index, v))
                result.update({(k[:1].upper()+k[1:]): f'avpOptions.avpOption_{Index}.resultCodeAvpOption.errorMessage.errorMessage_0.value'})
        return result

    def edit_protocol_version_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'ver', 'rev']:
                self.update("{}.avpOptions.avpOption_{}.protocolVersionAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.protocolVersionAvpOption.{}".format(Index, k)})
        return result

    def edit_framing_capabilities_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'reserved1', 'abit', 'sbit']:
                self.update("{}.avpOptions.avpOption_{}.framingCapabilitiesAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.framingCapabilitiesAvpOption.{}".format(Index, k)})
        return result

    def edit_bearer_capabilities_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'reserved1', 'abit', 'dbit']:
                self.update("{}.avpOptions.avpOption_{}.bearerCapabilitiesAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.bearerCapabilitiesAvpOption.{}".format(Index, k)})
        return result

    def edit_tie_breaker_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'tieBreakerValue']:
                self.update("{}.avpOptions.avpOption_{}.tieBreakerAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.tieBreakerAvpOption.{}".format(Index, k)})
        return result

    def edit_firmware_revision_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'firmwareRevision']:
                self.update("{}.avpOptions.avpOption_{}.firmwareRevisionAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.firmwareRevisionAvpOption.{}".format(Index, k)})
        return result

    def edit_assigned_tunnelid_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'tunnelId']:
                self.update("{}.avpOptions.avpOption_{}.assignedTunnelIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.assignedTunnelIdAvpOption.{}".format(Index, k)})
        return result

    def edit_receive_windowsize_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'windowSize']:
                self.update("{}.avpOptions.avpOption_{}.receiveWindowSizeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.receiveWindowSizeAvpOption.{}".format(Index, k)})
        return result

    def edit_response_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'responseValue']:
                self.update("{}.avpOptions.avpOption_{}.responseAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.responseAvpOption.{}".format(Index, k)})
        return result

    def edit_assigned_sessionid_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'sessionId']:
                self.update("{}.avpOptions.avpOption_{}.assignedSessionIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.assignedSessionIdAvpOption.{}".format(Index, k)})
        return result

    def edit_call_serialnumber_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'callSerialNumber']:
                self.update("{}.avpOptions.avpOption_{}.callSerialNumberAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.callSerialNumberAvpOption.{}".format(Index, k)})
        return result

    def edit_minimum_bps_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'minimumBps']:
                self.update("{}.avpOptions.avpOption_{}.minimumBpsAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.minimumBpsAvpOption.{}".format(Index, k)})
        return result

    def edit_maximum_bpsavpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'maximumBps']:
                self.update("{}.avpOptions.avpOption_{}.maximumBpsAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.maximumBpsAvpOption.{}".format(Index, k)})
        return result

    def edit_bearer_type_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'reserved1', 'abit', 'dbit']:
                self.update("{}.avpOptions.avpOption_{}.bearerTypeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.bearerTypeAvpOption.{}".format(Index, k)})
        return result

    def edit_framing_type_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'reserved1', 'abit', 'sbit']:
                self.update("{}.avpOptions.avpOption_{}.framingTypeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.framingTypeAvpOption.{}".format(Index, k)})
        return result

    def edit_tx_connectspeed_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'bps']:
                self.update("{}.avpOptions.avpOption_{}.txConnectSpeedAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.txConnectSpeedAvpOption.{}".format(Index, k)})
        return result

    def edit_rx_connectspeed_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'highBPS', 'lowBPS']:
                self.update("{}.avpOptions.avpOption_{}.rxConnectSpeedAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.rxConnectSpeedAvpOption.{}".format(Index, k)})
        return result

    def edit_physical_channelid_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'physicalChannelId']:
                self.update("{}.avpOptions.avpOption_{}.physicalChannelIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.physicalChannelIdAvpOption.{}".format(Index, k)})
        return result

    def edit_proxy_authentype_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'authenType']:
                self.update("{}.avpOptions.avpOption_{}.proxyAuthenTypeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.proxyAuthenTypeAvpOption.{}".format(Index, k)})
        return result

    def edit_proxy_authenid_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'reserved1', 'authenId']:
                self.update("{}.avpOptions.avpOption_{}.proxyAuthenIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.proxyAuthenIdAvpOption.{}".format(Index, k)})
        return result

    # def _edit_common_parameters(self, Tlv, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     if 'mbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.mbit={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'mbit'])).execute()
    #     if 'hbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.hbit={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'hbit'])).execute()
    #     if 'reserved' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.reserved={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'reserved'])).execute()
    #     if 'length' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.length={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'length'])).execute()
    #     if 'vendorId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.vendorId={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'vendorId'])).execute()
    #     if 'type' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.{}.type={} ".format(
    #                                 self.name, Index, Tlv, kwargs[
    #                                     'type'])).execute()
    #
    # def edit_general_tlv_header(self, Index, **kwargs):
    #     result = {}
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     for k, v in kwargs.items():
    #         if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'attributeValue']:
    #             self.update("{}.avpOptions.avpOption_{}.generalTLV.{}={}".format(self.name, Index, k, v))
    #             result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.generalTLV.{}".format(Index, k)})
    #     return result
    #
    # def edit_message_type_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='messageTypeAvpOption', Index=Index, **kwargs)
    #     if 'messageType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.messageTypeAvpOption.messageType={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'messageType'])).execute()
    #     return True
    #
    # def edit_result_code_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='resultCodeAvpOption', Index=Index, **kwargs)
    #     if 'resultCode' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.resultCodeAvpOption.resultCode={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'resultCode'])).execute()
    #     if 'errorCode' in set(kwargs.keys()):
    #         self.insert_resultcode_errorcode(Index=Index, value=kwargs['errorCode'])
    #     if 'errorMessage' in set(kwargs.keys()):
    #         self.insert_resultcode_errorMessage(Index=Index, value=kwargs['errorMessage'])
    #
    # def insert_resultcode_errorcode(self, Index, value):
    #     if self.__errorCode is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorCode'.format(
    #                                     self.name, Index),
    #                                 NodeName='errorCode').execute()
    #         self.__errorCode = True
    #     self.edit_resultcode_errorcode(Index=Index, value=value)
    #     return True
    #
    # def edit_resultcode_errorcode(self, Index, value=None):
    #     if value is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorCode.errorCode_0.value={}".format(
    #                                 self.name, Index, value)).execute()
    #     return True
    #
    # def insert_resultcode_errorMessage(self, Index, value):
    #     if self.__errorMessage is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorMessage'.format(
    #                                     self.name, Index),
    #                                 NodeName='errorMessage').execute()
    #         self.__errorMessage = True
    #     self.edit_resultcode_errorMessage(Index=Index, value=value)
    #     return True
    #
    # def edit_resultcode_errorMessage(self, Index, value=None):
    #     if value is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorMessage.errorMessage_0.value={}".format(
    #                                 self.name, Index, value)).execute()
    #     return True
    #
    # def edit_protocol_version_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='protocolVersionAvpOption', Index=Index, **kwargs)
    #     if 'ver' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.protocolVersionAvpOption.ver={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'ver'])).execute()
    #     if 'rev' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.protocolVersionAvpOption.rev={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'rev'])).execute()
    #
    # def edit_framing_capabilities_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='framingCapabilitiesAvpOption', Index=Index, **kwargs)
    #     if 'reserved1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.framingCapabilitiesAvpOption.reserved1={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'reserved1'])).execute()
    #     if 'abit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.framingCapabilitiesAvpOption.abit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'abit'])).execute()
    #     if 'sbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.framingCapabilitiesAvpOption.sbit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'sbit'])).execute()
    #
    # def edit_bearer_capabilities_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='bearerCapabilitiesAvpOption', Index=Index, **kwargs)
    #     if 'reserved1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.bearerCapabilitiesAvpOption.reserved1={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'reserved1'])).execute()
    #     if 'abit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.bearerCapabilitiesAvpOption.abit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'abit'])).execute()
    #     if 'dbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.bearerCapabilitiesAvpOption.dbit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'dbit'])).execute()
    #
    # def edit_tie_breaker_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='tieBreakerAvpOption', Index=Index, **kwargs)
    #     if 'tieBreakerValue' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.tieBreakerAvpOption.tieBreakerValue={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'tieBreakerValue'])).execute()
    #
    # def edit_firmware_revision_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='firmwareRevisionAvpOption', Index=Index, **kwargs)
    #     if 'firmwareRevision' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.firmwareRevisionAvpOption.firmwareRevision={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'firmwareRevision'])).execute()
    #
    # def edit_assigned_tunnelid_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='assignedTunnelIdAvpOption', Index=Index, **kwargs)
    #     if 'tunnelId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.assignedTunnelIdAvpOption.tunnelId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'tunnelId'])).execute()
    #
    # def edit_receive_windowsize_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='receiveWindowSizeAvpOption', Index=Index, **kwargs)
    #     if 'windowSize' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.receiveWindowSizeAvpOption.windowSize={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'windowSize'])).execute()
    #
    # def edit_assigned_sessionid_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='assignedSessionIdAvpOption', Index=Index, **kwargs)
    #     if 'sessionId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.assignedSessionIdAvpOption.sessionId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'sessionId'])).execute()
    #
    # def edit_response_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='responseAvpOption', Index=Index, **kwargs)
    #     if 'responseValue' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.responseAvpOption.responseValue={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'responseValue'])).execute()
    #
    # def edit_call_serialnumber_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='callSerialNumberAvpOption', Index=Index, **kwargs)
    #     if 'callSerialNumber' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.callSerialNumberAvpOption.callSerialNumber={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'callSerialNumber'])).execute()
    #
    # def edit_minimum_bps_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='minimumBpsAvpOption', Index=Index, **kwargs)
    #     if 'minimumBps' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.minimumBpsAvpOption.minimumBps={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'minimumBps'])).execute()
    #
    # def edit_maximum_bpsavpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='maximumBpsAvpOption', Index=Index, **kwargs)
    #     if 'maximumBps' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.maximumBpsAvpOption.maximumBps={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'maximumBps'])).execute()
    #
    # def edit_bearer_type_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='bearerTypeAvpOption', Index=Index, **kwargs)
    #     if 'reserved1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.bearerTypeAvpOption.reserved1={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'reserved1'])).execute()
    #     if 'abit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.bearerTypeAvpOption.abit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'abit'])).execute()
    #     if 'dbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.bearerTypeAvpOption.dbit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'dbit'])).execute()
    #
    # def edit_framing_type_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='framingTypeAvpOption', Index=Index, **kwargs)
    #     if 'reserved1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.framingTypeAvpOption.reserved1={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'reserved1'])).execute()
    #     if 'abit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.framingTypeAvpOption.abit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'abit'])).execute()
    #     if 'sbit' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.framingTypeAvpOption.sbit={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'sbit'])).execute()
    #
    # def edit_tx_connectspeed_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='txConnectSpeedAvpOption', Index=Index, **kwargs)
    #     if 'bps' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.txConnectSpeedAvpOption.bps={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'bps'])).execute()
    #
    # def edit_rx_connectspeed_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='rxConnectSpeedAvpOption', Index=Index, **kwargs)
    #     if 'highBPS' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.rxConnectSpeedAvpOption.highBPS={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'highBPS'])).execute()
    #
    #     if 'lowBPS' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.rxConnectSpeedAvpOption.lowBPS={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'lowBPS'])).execute()
    #
    # def edit_physical_channelid_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='physicalChannelIdAvpOption', Index=Index, **kwargs)
    #     if 'physicalChannelId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.physicalChannelIdAvpOption.physicalChannelId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'physicalChannelId'])).execute()
    #
    # def edit_proxy_authentype_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='proxyAuthenTypeAvpOption', Index=Index, **kwargs)
    #     if 'authenType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.proxyAuthenTypeAvpOption.authenType={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'authenType'])).execute()
    #
    # def edit_proxy_authenid_avpoption_header(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_common_parameters(Tlv='proxyAuthenIdAvpOption', Index=Index, **kwargs)
    #     if 'reserved1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.proxyAuthenIdAvpOption.reserved1={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'reserved1'])).execute()
    #     if 'authenId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.avpOptions.avpOption_{}.proxyAuthenIdAvpOption.authenId={} ".format(
    #                                 self.name, Index, kwargs[
    #                                     'authenId'])).execute()

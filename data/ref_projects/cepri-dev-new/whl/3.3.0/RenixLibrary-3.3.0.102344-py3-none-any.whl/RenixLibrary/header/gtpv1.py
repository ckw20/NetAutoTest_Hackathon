from .header_base import *

file_path = SCHEMA_PATH + "Gtpv1Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("gtpv1")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Gtpv1Header(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("gtpv1")
        self.__version = paramDict["version"]
        self.__pt = paramDict["pt"]
        self.__reserved = paramDict["reserved"]
        self.__nexthead = paramDict["nexthead"]
        self.__sequenceNumber = paramDict["sequenceNumber"]
        self.__pduNumberPresent = paramDict["pduNumberPresent"]
        self.__messageType = paramDict["messageType"]
        self.__length = paramDict["length"]
        self.__teid = paramDict["teid"]

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version = Value

    @property
    def pt(self):
        return self.__pt

    @pt.setter
    def pt(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pt = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved = Value

    @property
    def nexthead(self):
        return self.__nexthead

    @nexthead.setter
    def nexthead(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nexthead = Value

    @property
    def sequenceNumber(self):
        return self.__sequenceNumber

    @sequenceNumber.setter
    def sequenceNumber(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sequenceNumber = Value

    @property
    def pduNumberPresent(self):
        return self.__pduNumberPresent

    @pduNumberPresent.setter
    def pduNumberPresent(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pduNumberPresent = Value

    @property
    def messageType(self):
        return self.__messageType

    @messageType.setter
    def messageType(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__messageType = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def teid(self):
        return self.__teid

    @teid.setter
    def teid(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__teid = Value


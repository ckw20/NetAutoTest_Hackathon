from .header_base import *

file_path = SCHEMA_PATH + "PRPTagTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("prptag")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class PrpTagHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("prptag")
        self.__seqnum = paramDict["seqnum"]
        self.__lanid = paramDict["lanid"]
        self.__lsdusize = paramDict["lsdusize"]
        self.__prpsuffix = paramDict["prpsuffix"]

    @property
    def seqnum(self):
        return self.__seqnum

    @seqnum.setter
    def seqnum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__seqnum = Value

    @property
    def lanid(self):
        return self.__lanid

    @lanid.setter
    def lanid(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lanid = Value

    @property
    def lsdusize(self):
        return self.__lsdusize

    @lsdusize.setter
    def lsdusize(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lsdusize = Value

    @property
    def prpsuffix(self):
        return self.__prpsuffix

    @prpsuffix.setter
    def prpsuffix(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__prpsuffix = Value






from renix_py_api.api_gen import InsertNodeToASetCommand

from .header_base import *

file_path = SCHEMA_PATH + "Ipv4Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv4")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv4Header(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, Icmp=False, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.__icmp = Icmp
        self.update_upper("ipv4")
        self.__version = paramDict["version"]
        self.__headLen = paramDict["headLen"]
        self.__tos = paramDict["tos"]
        self.__totalLength = paramDict["totalLength"]
        self.__id = paramDict["id"]
        self.__flags = paramDict["flags"]
        self.__offset = paramDict["offset"]
        self.__ttl = paramDict["ttl"]
        self.__protocol = paramDict["protocol"]
        self.__checksum = paramDict["checksum"]
        self.__source = paramDict["source"]
        self.__destination = paramDict["destination"]
        self.__padding = paramDict["padding"]
        self.__gateway = paramDict["gateway"]
        self.__tosPrecedence = "000"
        self.__tosDelay = '0'
        self.__tosThroughput = '0'
        self.__tosReliability = '0'
        self.__tosMonetaryCost = '0'
        self.__tosReserved = '0'
        self.__diffserveDscp = 'codePoint'
        self.__diffserveCodepointPrecedence = "000000"
        self.__diffserveClassSelectorPrecedence = '000'
        self.__diffserveClassSelectorDrop = '00'
        self.__diffserveClassSelectorUndefine = '0'
        self.__diffserveEcn = '0'
        self.__tosByte = '00'
        self.__headerOption = []
        self.__optionTypes = {'endofoption': 'optionEndOfOptionList',
                              'nop': 'optionNop',
                              'security': 'optionSecurity',
                              'loosesourceroute': 'optionLooseSourceRoute',
                              'strictsourceroute': 'optionStrictSourceRoute',
                              'recordroute': 'optionRecordRoute',
                              'timestamp': 'optionTimeStamp',
                              'streamidentifier': 'optionStreamIdentifier',
                              'general': 'generalTLV',
                              'routeralert': 'optionRouterAlert'}
        self.__fieldTrans = {'Version': 'version',
                             'HeadLen': 'headLen',
                             'TosPrecedence': 'tos.tos.precedence',
                             'TosDelay': 'tos.tos.delay',
                             'TosThroughtput': 'tos.tos.throughput',
                             'TosReliability': 'tos.tos.reliability',
                             'TosMonetaryCost': 'tos.tos.monetaryCost',
                             'TosReserved': 'tos.tos.reserved',
                             'DiffserveDscp': 'tos.diffServe.dscp',
                             'DiffserveCodePointPrecedence': 'tos.diffServe.dscp.codePoint.precedence',
                             'DiffserveClassSelectorPrecedence': 'tos.diffServe.dscp.classSelector.precedence',
                             'DiffserveClassSelectorDrop': 'tos.diffServe.dscp.classSelector.drop',
                             'DiffserveClassSelectorUndefine': 'tos.diffServe.dscp.classSelector.undefine',
                             'DiffserveEcn': 'tos.diffServe.ecnSetting',
                             'TosByte': 'tos.tosByte.data',
                             'TotalLength': 'totalLength',
                             'Flags': 'flags',
                             'ID': 'id',
                             'Offset': 'offset',
                             'TTL': 'ttl',
                             'Protocol': 'protocol',
                             'Checksum': 'checksum',
                             'Source': 'source',
                             'Destination': 'destination',
                             'HeaderOption': 'ipv4HeaderOption',
                             'Padding': 'padding',
                             'Gateway': 'gateway'}

    @property
    def keyword(self):
        if self.__icmp:
            self.__keyword = '{}.headerData.ipv4Header'.format(self.name)
        else:
            self.__keyword = self.name
        return self.__keyword

    @property
    def headerOption(self):
        return self.__headerOption

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__version = Value

    @property
    def headLen(self):
        return self.__headLen

    @headLen.setter
    def headLen(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__headLen = Value

    @property
    def tos(self):
        return self.__tos

    @tos.setter
    def tos(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__tos = Value

    @property
    def totalLength(self):
        return self.__totalLength

    @totalLength.setter
    def totalLength(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__totalLength = Value

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__id = Value

    @property
    def flags(self):
        return self.__flags

    @flags.setter
    def flags(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__flags = Value

    @property
    def offset(self):
        return self.__offset

    @offset.setter
    def offset(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__offset = Value

    @property
    def ttl(self):
        return self.__ttl

    @ttl.setter
    def ttl(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__ttl = Value

    @property
    def protocol(self):
        return self.__protocol

    @protocol.setter
    def protocol(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__protocol = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__checksum = Value

    @property
    def source(self):
        return self.__source

    @source.setter
    def source(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__source = Value

    @property
    def destination(self):
        return self.__destination

    @destination.setter
    def destination(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__destination = Value

    @property
    def padding(self):
        return self.__padding

    @padding.setter
    def padding(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__padding = Value

    @property
    def gateway(self):
        return self.__gateway

    @gateway.setter
    def gateway(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.keyword, sys._getframe().f_code.co_name, Value)).execute()
        self.__gateway = Value

    def insert_header_option(self, Types):
        if not isinstance(Types, (list, set, tuple)):
            Types = [Types]
        for x in Types:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.ipv4HeaderOption'.format(self.keyword),
                                    NodeName=self.__optionTypes[x.lower()]).execute()
        self.__headerOption = self.__headerOption + Types
        return True

    def edit_header_option(self, Index, Option, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        header = '' if 'ipv4' in self.name else 'headerData.ipv4Header.'
        if not isinstance(Option, (list, set, tuple)):
            Option = [Option]
        for t in Option:
            for k, v in kwargs.items():
                if k == 'addressList':
                    if not isinstance(v, (list, set, tuple)):
                        v = [v]
                    for i, addr in enumerate(v):
                        param = f'{header}ipv4HeaderOption.ipv4HeaderOptionList_{int(Index)}.{self.__optionTypes[t.lower()]}.addressList.ipv4AddrContainer_{i}.ipv4Addr'
                        result.update({f'{k[0].upper()+k[1:]}: {addr}': param})
                        self.update(f'{self.name}.{param}={addr} ')
                elif k == 'timeStampSet':
                    if not isinstance(v, (list, set, tuple)):
                        v = [v]
                    for i, item in enumerate(v):
                        param = f'{header}ipv4HeaderOption.ipv4HeaderOptionList_{int(Index)}.{self.__optionTypes[t.lower()]}.timeStampSet.timeStamp_{i}.timeStamp'
                        result.update({f'{k[0].upper() + k[1:]}: {item}': param})
                        self.update(f'{self.name}.{param}={item} ')
                else:
                    param = f'{header}ipv4HeaderOption.ipv4HeaderOptionList_{int(Index)}.{self.__optionTypes[t.lower()]}.{k}'
                    result.update({k[0].upper()+k[1:]: param})
                    UpdateHeaderCommand(Stream=self.stream.handle,
                                        BindingModifier=True,
                                        Parameter=f"{self.name}.{param}={v} ").execute()
        return result if result else False

    def edit_tos(self, **kwargs):
        for k, v in kwargs.items():
            self.update('{}.tos.tos.{}={} '.format(self.keyword, k, v))

    def edit_diffserv(self, k, v):
        self.update('{}.tos.diffServe.{}={} '.format(self.keyword, k, v))

    def edit_tosbyte(self, value):
        self.update('{}.tos.tosByte.data={} '.format(self.keyword, value))

    def get_ipv4_value(self, field):
        return self.get_value('{}.{}'.format(self.keyword, self.__fieldTrans[field]))

    @property
    def tosPrecedence(self):
        return self.__tosPrecedence

    @tosPrecedence.setter
    def tosPrecedence(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter=f"{self.keyword}.tos.tos.precedence={Value} ").execute()
        self.__tosPrecedence = Value

    @property
    def tosDelay(self):
        return self.__tosDelay

    @tosDelay.setter
    def tosDelay(self, Value):
        self.edit_tos(delay=Value)
        self.__tosDelay = Value

    @property
    def tosThroughput(self):
        return self.__tosThroughput

    @tosThroughput.setter
    def tosThroughput(self, Value):
        self.edit_tos(throughput=Value)
        self.__tosThroughput = Value

    @property
    def tosReliability(self):
        return self.__tosReliability

    @tosReliability.setter
    def tosReliability(self, Value):
        self.edit_tos(reliability=Value)
        self.__tosReliability = Value

    @property
    def tosMonetaryCost(self):
        return self.__tosMonetaryCost

    @tosMonetaryCost.setter
    def tosMonetaryCost(self, Value):
        self.edit_tos(monetaryCost=Value)
        self.__tosMonetaryCost = Value

    @property
    def tosReserved(self):
        return self.__tosReserved

    @tosReserved.setter
    def tosReserved(self, Value):
        self.edit_tos(reserved=Value)
        self.__tosReserved = Value

    # @property
    # def diffserveDscp(self):
    #     self.__diffserveDscp = self.get_ipv4_value('tos.diffServe.dscp')
    #     return self.__diffserveDscp

    @property
    def diffserveCodepointPrecedence(self):
        return self.__diffserveCodepointPrecedence

    @diffserveCodepointPrecedence.setter
    def diffserveCodepointPrecedence(self, Value):
        self.edit_diffserv('dscp.codePoint.precedence', Value)
        self.__diffserveCodepointPrecedence = Value

    @property
    def diffserveClassSelectorPrecedence(self):
        return self.__diffserveClassSelectorPrecedence

    @diffserveClassSelectorPrecedence.setter
    def diffserveClassSelectorPrecedence(self, Value):
        self.edit_diffserv('dscp.classSelector.precedence', Value)
        self.__diffserveClassSelectorPrecedence = Value

    @property
    def diffserveClassSelectorDrop(self):
        return self.__diffserveClassSelectorDrop

    @diffserveClassSelectorDrop.setter
    def diffserveClassSelectorDrop(self, Value):
        self.edit_diffserv('dscp.classSelector.drop', Value)
        self.__diffserveClassSelectorDrop = Value

    @property
    def diffserveClassSelectorUndefine(self):
        return self.__diffserveClassSelectorUndefine

    @diffserveClassSelectorUndefine.setter
    def diffserveClassSelectorUndefine(self, Value):
        self.edit_diffserv('dscp.classSelector.undefine', Value)
        self.__diffserveClassSelectorUndefine = Value

    @property
    def diffserveEcn(self):
        return self.__diffserveEcn

    @diffserveEcn.setter
    def diffserveEcn(self, Value):
        self.edit_diffserv('ecnSetting', Value)
        self.__diffserveEcn = Value

    @property
    def tosByte(self):
        return self.__tosByte

    @tosByte.setter
    def tosByte(self, Value):
        self.edit_tosbyte(Value)
        self.__tosByte = Value


if __name__ == '__main__':
    object_ = Ipv4Header()
    print(object_)
    print(Ipv4Header.destination)
    print(Ipv4Header.source)
    print(Ipv4Header.gateway)
    object_ = Ipv4Header(destination="1.1.1.1", source="2.2.2.2", gateway="3.3.3.3")
    print(object_.destination)
    print(object_.source)
    print(object_.gateway)

from .header_base import *

file_path = SCHEMA_PATH + "Ipv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv6FragmentHeader")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv6FragmentHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ipv6FragmentHeader")
        self.__nextHeader = paramDict["nextHeader"]
        self.__reserved1 = paramDict["reserved1"]
        self.__fragOffset = paramDict["fragOffset"]
        self.__reserved2 = paramDict["reserved2"]
        self.__m_flag = paramDict["m_flag"]
        self.__ident = paramDict["ident"]

    @property
    def nextHeader(self):
        return self.__nextHeader

    @nextHeader.setter
    def nextHeader(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nextHeader = Value

    @property
    def reserved1(self):
        return self.__reserved1

    @reserved1.setter
    def reserved1(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved1 = Value

    @property
    def fragOffset(self):
        return self.__fragOffset

    @fragOffset.setter
    def fragOffset(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__fragOffset = Value

    @property
    def reserved2(self):
        return self.__reserved2

    @reserved2.setter
    def reserved2(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved2 = Value

    @property
    def m_flag(self):
        return self.__m_flag

    @m_flag.setter
    def m_flag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__m_flag = Value

    @property
    def ident(self):
        return self.__ident

    @ident.setter
    def ident(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__ident = Value

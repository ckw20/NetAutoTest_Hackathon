from .pppoe import *

file_path = SCHEMA_PATH + "PppoeTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("pppoeDiscovery")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class PppoeDiscoveryHeader(PppoeHeader):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("pppoeDiscovery")
        self.__endOfListTag = 0
        self.__serviceNameTag = 0
        self.__acNameTag = 0
        self.__hostUniqTag = 0
        self.__acCookieTag = 0
        self.__vendorSpecificTag = 0
        self.__relaySessionIdTag = 0
        self.__serviceNameErrorTag = 0
        self.__acSystemErrorTag = 0
        self.__genericErrorTag = 0
        self.__unknownTag = 0

    @property
    def endOfListTag(self):
        return self.__endOfListTag

    @endOfListTag.setter
    def endOfListTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagEndOfList').execute()
        self.__endOfListTag = Value

    @property
    def serviceNameTag(self):
        return self.__serviceNameTag

    @serviceNameTag.setter
    def serviceNameTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagServiceName').execute()
        self.__serviceNameTag = Value

    @property
    def acNameTag(self):
        return self.__acNameTag

    @acNameTag.setter
    def acNameTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagACName').execute()
        self.__acNameTag = Value

    @property
    def hostUniqTag(self):
        return self.__hostUniqTag

    @hostUniqTag.setter
    def hostUniqTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagHostUniq').execute()
        self.__hostUniqTag = Value

    @property
    def acCookieTag(self):
        return self.__acCookieTag

    @acCookieTag.setter
    def acCookieTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagACCookie').execute()
        self.__acCookieTag = Value

    @property
    def vendorSpecificTag(self):
        return self.__vendorSpecificTag

    @vendorSpecificTag.setter
    def vendorSpecificTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagVendorSpecific').execute()
        self.__vendorSpecificTag = Value

    @property
    def relaySessionIdTag(self):
        return self.__relaySessionIdTag

    @relaySessionIdTag.setter
    def relaySessionIdTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagRelaySessionId').execute()
        self.__relaySessionIdTag = Value

    @property
    def serviceNameErrorTag(self):
        return self.__serviceNameErrorTag

    @serviceNameErrorTag.setter
    def serviceNameErrorTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagServiceNameError').execute()
        self.__serviceNameErrorTag = Value

    @property
    def acSystemErrorTag(self):
        return self.__acSystemErrorTag

    @acSystemErrorTag.setter
    def acSystemErrorTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagACSystemError').execute()
        self.__acSystemErrorTag = Value

    @property
    def genericErrorTag(self):
        return self.__genericErrorTag

    @genericErrorTag.setter
    def genericErrorTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='tagGenericError').execute()
        self.__genericErrorTag = Value

    @property
    def unknownTag(self):
        return self.__unknownTag

    @unknownTag.setter
    def unknownTag(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.tags'.format(self.name),
                                    NodeName='generalTLV').execute()
        self.__unknownTag = Value

    def config_end_of_list_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagEndOfList.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagEndOfList.{}'.format(TagIndex, k_)})
        return result

    def get_end_of_list_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagEndOfList.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_service_name_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagServiceName.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagServiceName.{}'.format(TagIndex, k_)})
        return result

    def get_server_name_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagServiceName.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_ac_name_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagACName.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagACName.{}'.format(TagIndex, k_)})
        return result

    def get_ac_name_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagACName.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_host_uniq_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagHostUniq.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagHostUniq.{}'.format(TagIndex, k_)})
        return result

    def get_host_uniq_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagHostUniq.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_ac_cookie_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagACCookie.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagACCookie.{}'.format(TagIndex, k_)})
        return result

    def get_ac_cookie_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagACCookie.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_vendor_specific_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagVendorSpecific.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagVendorSpecific.{}'.format(TagIndex, k_)})
        return result

    def get_vendor_specific_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagVendorSpecific.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_relay_session_id_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagRelaySessionId.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagRelaySessionId.{}'.format(TagIndex, k_)})
        return result

    def get_relay_session_id_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagRelaySessionId.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_server_name_error_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagServiceNameError.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagServiceNameError.{}'.format(TagIndex, k_)})
        return result

    def get_server_name_error_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagServiceNameError.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_ac_system_error_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagACSystemError.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagACSystemError.{}'.format(TagIndex, k_)})
        return result

    def get_ac_system_error_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagACSystemError.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_generic_error_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.tagGenericError.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.tagGenericError.{}'.format(TagIndex, k_)})
        return result

    def get_generic_error_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.tagGenericError.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

    def config_unknown_tag(self, TagIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.tags.tagList_{}.generalTLV.{}={} '.format(
                self.name, TagIndex, k_, v))
            result.update({k: 'tags.tagList_{}.generalTLV.{}'.format(TagIndex, k_)})
        return result

    def get_unknown_tag(self, TagIndex, Item):
        return self.get_value(field='{}.tags.tagList_{}.generalTLV.{}'.format(
            self.name, TagIndex, Item[:1].lower()+Item[1:]))

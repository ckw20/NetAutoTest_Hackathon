from renix_py_api.api_gen import InsertNodeToASetCommand

from .ospfv2_option import *


class Ospfv2LsaHeader(Ospfv2OptionHeader):

    def __init__(self, Upper, Attributes, Displays, Values, OptionType):
        super().__init__(Upper=Upper, Attributes=Attributes, Displays=Displays, Values=Values, OptionType=OptionType)

    def insert_lsa_header(self, Value):
        for x in range(int(Value)):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.lsaHeaders'.format(self.name),
                                    NodeName='ospfv2LsaHeader').execute()
        return True

    def edit_lsa_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'lsaAge' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaAge={} ".format(self.name, Index, kwargs[
                                    'lsaAge'])).execute()
            result.update({'LsaAge': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaAge'})
        if 'lsType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsType={} ".format(self.name, Index, kwargs[
                                    'lsType'])).execute()
            result.update({'LsType': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsType'})
        if 'linkStateId' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.linkStateId={} ".format(self.name, Index,
                                                                                                    kwargs[
                                                                                                        'linkStateId'])).execute()
            result.update({'LinkStateId': f'lsaHeaders.ospfv2LsaHeader_{Index}.linkStateId'})
        if 'advertisingRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.advertisingRouter={} ".format(self.name,
                                                                                                          Index, kwargs[
                                                                                                              'advertisingRouter'])).execute()
            result.update({'AdvertisingRouter': f'lsaHeaders.ospfv2LsaHeader_{Index}.advertisingRouter'})
        if 'lsSequenceNumber' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsSequenceNumber={} ".format(self.name,
                                                                                                         Index, kwargs[
                                                                                                             'lsSequenceNumber'])).execute()
            result.update({'LsSequenceNumber': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsSequenceNumber'})
        if 'lsChecksum' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsChecksum={} ".format(self.name, Index,
                                                                                                   kwargs[
                                                                                                       'lsChecksum'])).execute()
            result.update({'LsChecksum': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsChecksum'})
        if 'lsaLength' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaLength={} ".format(self.name, Index,
                                                                                                  kwargs[
                                                                                                      'lsaLength'])).execute()
            result.update({'LsaLength': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaLength'})
        if 'reserved7' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.reserved7={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved7'])).execute()
            result.update({'Reserved7': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.reserved7'})
        if 'reserved6' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.reserved6={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved6'])).execute()
            result.update({'Reserved6': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.reserved6'})
        if 'dcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.dcBit={} ".format(self.name,
                                                                                                            Index,
                                                                                                            kwargs[
                                                                                                                'dcBit'])).execute()
            result.update({'DcBit': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.dcBit'})
        if 'eaBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.eaBit={} ".format(self.name,
                                                                                                            Index,
                                                                                                            kwargs[
                                                                                                                'eaBit'])).execute()
            result.update({'EaBit': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.eaBit'})
        if 'npBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.npBit={} ".format(self.name,
                                                                                                            Index,
                                                                                                            kwargs[
                                                                                                                'npBit'])).execute()
            result.update({'NpBit': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.npBit'})
        if 'mcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.mcBit={} ".format(self.name,
                                                                                                            Index,
                                                                                                            kwargs[
                                                                                                                'mcBit'])).execute()
            result.update({'McBit': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.mcBit'})
        if 'eBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.eBit={} ".format(self.name,
                                                                                                           Index,
                                                                                                           kwargs[
                                                                                                               'eBit'])).execute()
            result.update({'EBit': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.eBit'})
        if 'reserved0' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.lsaHeaders.ospfv2LsaHeader_{}.lsaHdrOptions.reserved0={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved0'])).execute()
            result.update({'Reserved0': f'lsaHeaders.ospfv2LsaHeader_{Index}.lsaHdrOptions.reserved0'})
        return result

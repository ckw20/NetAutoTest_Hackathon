from .header_base import *

file_path = SCHEMA_PATH + "UdpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("udp")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class UdpHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("udp")
        self.__sourcePort = paramDict["sourcePort"]
        self.__destPort = paramDict["destPort"]
        self.__length = paramDict["length"]
        self.__checksum = paramDict["checksum"]

    @property
    def sourcePort(self):
        return self.__sourcePort

    @sourcePort.setter
    def sourcePort(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sourcePort = Value

    @property
    def destPort(self):
        return self.__destPort

    @destPort.setter
    def destPort(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__destPort = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__length = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__checksum = Value


if __name__ == '__main__':
    object_ = UdpHeader()
    print(object_)
    print(UdpHeader.sourcePort)
    print(UdpHeader.destPort)
    print(UdpHeader.length)
    # arp = ArpHeader()
    object_ = UdpHeader(sourcePort=1025, destPort=1026, length=1024)
    print(object_.sourcePort)
    print(object_.destPort)
    print(object_.length)

from .header_base import *

file_path = SCHEMA_PATH + "LldpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("chassisIdTlv")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class LldpChassisIdHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("chassisIdTlv")
        self.__type = paramDict["type"]
        self.__length = paramDict["length"]
        self.__chassisIdSubType = '05'
        self.__ianaAddressFamily = 1
        self.__chassisId = '192.168.0.1'

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def chassisIdSubType(self):
        return self.__chassisIdSubType

    @chassisIdSubType.setter
    def chassisIdSubType(self, Value):
        self.update('{}.chassisId.networkAddress4.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__chassisIdSubType = Value

    @property
    def ianaAddressFamily(self):
        return self.__ianaAddressFamily

    @ianaAddressFamily.setter
    def ianaAddressFamily(self, Value):
        self.update('{}.chassisId.networkAddress4.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__ianaAddressFamily = Value

    @property
    def chassisId(self):
        return self.__chassisId

    @chassisId.setter
    def chassisId(self, Value):
        self.update('{}.chassisId.networkAddress4.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__chassisId = Value

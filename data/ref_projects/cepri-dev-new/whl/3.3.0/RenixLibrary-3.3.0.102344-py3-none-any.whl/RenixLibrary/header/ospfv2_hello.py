from renix_py_api.api_gen import InsertNodeToASetCommand

from .ospfv2_option import *

file_path = SCHEMA_PATH + "ospfv2.def.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ospfv2Hello")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ospfv2HelloHeader(Ospfv2OptionHeader):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues,
                         OptionType='helloOptions')
        self.update_upper("ospfv2Hello")
        self.__networkMask = paramDict["networkMask"]
        self.__helloInterval = paramDict["helloInterval"]
        self.__routerPriority = paramDict["routerPriority"]
        self.__routerDeadInterval = paramDict["routerDeadInterval"]
        self.__designatedRouter = paramDict["designatedRouter"]

    @property
    def networkMask(self):
        return self.__networkMask

    @networkMask.setter
    def networkMask(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__networkMask = Value

    @property
    def helloInterval(self):
        return self.__helloInterval

    @helloInterval.setter
    def helloInterval(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__helloInterval = Value

    @property
    def routerPriority(self):
        return self.__routerPriority

    @routerPriority.setter
    def routerPriority(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__routerPriority = Value

    @property
    def routerDeadInterval(self):
        return self.__routerDeadInterval

    @routerDeadInterval.setter
    def routerDeadInterval(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__routerDeadInterval = Value

    @property
    def designatedRouter(self):
        return self.__designatedRouter

    @designatedRouter.setter
    def designatedRouter(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__designatedRouter = Value

    @property
    def backupDesignatedRouter(self):
        return self.__backupDesignatedRouter

    @backupDesignatedRouter.setter
    def backupDesignatedRouter(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__backupDesignatedRouter = Value

    def insert_neighbors(self, Value):
        result = {}
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for num, x in enumerate(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.neighbors'.format(self.name),
                                    NodeName='ospfv2Neighbor').execute()
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.neighbors.ospfv2Neighbor_{}.neighborID={} ".format(self.name, num,
                                                                                                 x)).execute()
            result.update({f'Neighbors: {x}': f'neighbors.ospfv2Neighbor_{num}.neighborID'})
        return result

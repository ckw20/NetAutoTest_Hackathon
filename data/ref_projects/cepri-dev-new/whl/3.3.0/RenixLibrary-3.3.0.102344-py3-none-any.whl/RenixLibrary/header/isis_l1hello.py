from .header_base import *

file_path = SCHEMA_PATH + "IsIsTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndexes = [headers.index("l1HelloCommonHeader"), headers.index('l1HelloMsg')]
    attributes, displays, defaultValues = [], [], []
    for headerIndex in headerIndexes:
        attributes.extend([i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        displays.extend([i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        defaultValues.extend([i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    if a in paramDict.keys():
        a = f'{a}_'
    paramDict.update({a: v})


class IsisL1HelloHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("IsIsl1HelloHeader")
        self.__InterRoutingProtocolDiscriminator = paramDict["InterRoutingProtocolDiscriminator"]
        self.__lengthIndicator = paramDict["lengthIndicator"]
        self.__versionIdExtend = paramDict["versionIdExtend"]
        self.__idLength = paramDict["idLength"]
        self.__commonReserved1 = paramDict["reserved1"]
        self.__pDUType = paramDict["pDUType"]
        self.__version = paramDict["version"]
        self.__commonReserved2 = paramDict["reserved2"]
        self.__maxAreaAddress = paramDict["maxAreaAddress"]
        self.__fixedReserved1 = paramDict["reserved1_"]
        self.__circuitType = paramDict["circuitType"]
        self.__senderSystemID = paramDict["senderSystemID"]
        self.__holderTimer = paramDict["holderTimer"]
        self.__pDULength = paramDict["pDULength"]
        self.__fixedReserved2 = paramDict["reserved2_"]
        self.__priority = paramDict["priority"]
        self.__designatedSystemID = paramDict["designatedSystemID"]
        self.__isIsTlv = paramDict["isIsTlv"]

    @property
    def InterRoutingProtocolDiscriminator(self):
        return self.__InterRoutingProtocolDiscriminator

    @InterRoutingProtocolDiscriminator.setter
    def InterRoutingProtocolDiscriminator(self, Value):
        self.update('{}.l1CommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__InterRoutingProtocolDiscriminator = Value

    @property
    def lengthIndicator(self):
        return self.__lengthIndicator

    @lengthIndicator.setter
    def lengthIndicator(self, Value):
        self.update('{}.l1CommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lengthIndicator = Value

    @property
    def versionIdExtend(self):
        return self.__versionIdExtend

    @versionIdExtend.setter
    def versionIdExtend(self, Value):
        self.update('{}.l1CommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__versionIdExtend = Value

    @property
    def idLength(self):
        return self.__idLength

    @idLength.setter
    def idLength(self, Value):
        self.update('{}.l1CommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__idLength = Value

    @property
    def commonReserved1(self):
        return self.__commonReserved1

    @commonReserved1.setter
    def commonReserved1(self, Value):
        self.update('{}.l1CommonHeader.reserved1={} '.format(self.name, Value))
        self.__commonReserved1 = Value

    @property
    def pDUType(self):
        return self.__pDUType

    @pDUType.setter
    def pDUType(self, Value):
        self.update('{}.l1CommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pDUType = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        self.update('{}.l1CommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version = Value

    @property
    def commonReserved2(self):
        return self.__commonReserved2

    @commonReserved2.setter
    def commonReserved2(self, Value):
        self.update('{}.l1CommonHeader.reserved2={} '.format(self.name, Value))
        self.__commonReserved2 = Value

    @property
    def maxAreaAddress(self):
        return self.__maxAreaAddress

    @maxAreaAddress.setter
    def maxAreaAddress(self, Value):
        self.update('{}.l1CommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__maxAreaAddress = Value

    @property
    def fixedReserve1(self):
        return self.__fixedReserve1

    @fixedReserve1.setter
    def fixedReserve1(self, Value):
        self.update('{}.l1HelloMsg.reserved1={} '.format(self.name, Value))
        self.__fixedReserve1 = Value

    @property
    def circuitType(self):
        return self.__circuitType

    @circuitType.setter
    def circuitType(self, Value):
        self.update('{}.l1HelloMsg.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__circuitType = Value

    @property
    def senderSystemID(self):
        return self.__senderSystemID

    @senderSystemID.setter
    def senderSystemID(self, Value):
        self.update('{}.l1HelloMsg.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__senderSystemID = Value

    @property
    def holderTimer(self):
        return self.__holderTimer

    @holderTimer.setter
    def holderTimer(self, Value):
        self.update('{}.l1HelloMsg.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__holderTimer = Value

    @property
    def pDULength(self):
        return self.__pDULength

    @pDULength.setter
    def pDULength(self, Value):
        self.update('{}.l1HelloMsg.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pDULength = Value

    @property
    def fixedReserve2(self):
        return self.__fixedReserve2

    @fixedReserve2.setter
    def fixedReserve2(self, Value):
        self.update('{}.l1HelloMsg.reserved2={} '.format(self.name, Value))
        self.__fixedReserve2 = Value

    @property
    def priority(self):
        return self.__priority

    @priority.setter
    def priority(self, Value):
        self.update('{}.l1HelloMsg.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__priority = Value

    @property
    def designatedSystemID(self):
        return self.__designatedSystemID

    @designatedSystemID.setter
    def designatedSystemID(self, Value):
        self.update('{}.l1HelloMsg.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__designatedSystemID = Value

    @property
    def isIsTlv(self):
        return self.__isIsTlv

    @isIsTlv.setter
    def isIsTlv(self, Value):
        # isIsAreaAddress padding authentionInfo protocolSupport ipInterfaceAddress neighbor restartSignal Ipv6InterfaceAddress
        # if not isinstance(Value, (list, tuple, set)):
        #     Value = [Value]
        # for i in Value:
        #     InsertNodeToASetCommand(Stream=self.stream.handle,
        #                             ParentName='{}.l1HelloMsg.{}'.format(self.name, sys._getframe().f_code.co_name),
        #                             NodeName=i).execute()
        self.__isIsTlv = Value

    def editTlvHeader(self, Option, Index=0, **kwargs):
        result = {}
        if Option != 'Ipv6InterfaceAddress':
            Option = Option[:1].lower()+Option[1:]
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if Option == 'isIsAreaAddress':
            for k, v in kwargs.items():
                if k == 'areaAddressEntries':
                    # TBD need delete node
                    for i in range(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries'.format(
                                                    self.name, Index),
                                                NodeName='AreaAddressEntry').execute()
                else:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.{}={}'.format(self.name, Index, k, v))
                    result.update({(k[:1].upper()+k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.{}'.format(Index, k)})
        elif Option == 'padding':
            for k, v in kwargs.items():
                self.update(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.padding.{}={}'.format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.padding.{}'.format(Index, k)})
        elif Option == 'authentionInfo':
            for k, v in kwargs.items():
                if k in ['authenticationType', 'authenticationLength', 'authentication']:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.authentionInfo.authen.{}={}'.format(self.name, Index, k, v))
                    result.update(
                        {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.authentionInfo.authen.{}'.format(Index, k)})
                else:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.authentionInfo.{}={}'.format(self.name, Index, k, v))
                    result.update(
                        {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.authentionInfo.{}'.format(Index, k)})
        elif Option == 'protocolSupport':
            for k, v in kwargs.items():
                if k == 'nlPIDEntriesField':
                    # TBD need delete node
                    for i in range(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.NlPIDEntriesField'.format(
                                                    self.name, Index),
                                                NodeName='nlPIDEntry').execute()
                else:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.{}={}'.format(self.name, Index, k, v))
                    result.update(
                        {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.{}'.format(Index, k)})
        elif Option == 'ipInterfaceAddress':
            for k, v in kwargs.items():
                if k == 'ipv4InterfaceAddress':
                    # TBD need delete node
                    for i, address in enumerate(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress'.format(
                                                    self.name, Index),
                                                NodeName='ipv4InterfaceAddressEntry').execute()
                        self.update(
                            '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress.ipv4InterfaceAddressEntry_{}.ipv4InterfaceAddress={}'.format(
                                self.name, Index, i, address))
                        k_ = k[:1].upper() + k[1:]
                        result.update({f'{k_}: {address}':
                            'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress.ipv4InterfaceAddressEntry_{}.ipv4InterfaceAddress'.format(
                            Index, i)})
                else:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.ipInterfaceAddress.{}={}'.format(self.name, Index, k, v))
                    result.update(
                        {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.ipInterfaceAddress.{}'.format(Index, k)})
        elif Option == 'neighbor':
            for k, v in kwargs.items():
                if k == 'macAdd':
                    # TBD need delete node
                    for i, address in enumerate(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.neighbor.lanEntries'.format(
                                                    self.name, Index),
                                                NodeName='ISNeighborEntry').execute()
                        self.update(
                            '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.neighbor.lanEntries.ISNeighborEntry_{}.MacAdd={}'.format(
                                self.name, Index, i, address))
                        k_ = k[:1].upper() + k[1:]
                        result.update({f'{k_}: {address}':
                            'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.neighbor.lanEntries.ISNeighborEntry_{}.MacAdd'.format(
                            Index, i)})
                else:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.neighbor.{}={}'.format(self.name, Index, k, v))
                    result.update(
                        {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.neighbor.{}'.format(Index, k)})
        elif Option == 'restartSignal':
            for k, v in kwargs.items():
                if k == 'restartNeighborIdField':
                    # TBD need delete node
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName='{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.restartSignal.restartNeighborIdContainer'.format(
                                                self.name, Index),
                                            NodeName='restartNeighborId').execute()
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.restartSignal.restartNeighborIdContainer.restartNeighborId_0.restartNeighborIdField={}'.format(
                            self.name, Index, v))
                    result.update(
                        {(k[:1].upper() + k[1:]):
                             'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.restartSignal.restartNeighborIdContainer.restartNeighborId_0.restartNeighborIdField'.format(
                                 Index)})
                else:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.restartSignal.{}={}'.format(self.name, Index, k, v))
                    result.update(
                        {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.restartSignal.{}'.format(Index, k)})
        elif Option == 'Ipv6InterfaceAddress':
            for k, v in kwargs.items():
                if k == 'ipv6InterfaceAddress':
                    # TBD need delete node
                    for i, address in enumerate(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress'.format(
                                                    self.name, Index),
                                                NodeName='ipv6InterfaceAddressEntry').execute()
                        self.update(
                            '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress.ipv6InterfaceAddressEntry_{}.ipv6InterfaceAddress={}'.format(
                                self.name, Index, i, address))
                        k_ = k[:1].upper() + k[1:]
                        result.update({f'{k_}: {address}':
                            'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress.ipv6InterfaceAddressEntry_{}.ipv6InterfaceAddress'.format(
                            Index, i)})
                else:
                    self.update(
                        '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.Ipv6InterfaceAddress.{}={}'.format(self.name, Index,
                                                                                                     k, v))
                    result.update(
                        {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.Ipv6InterfaceAddress.{}'.format(Index, k)})
        return result

    def getTlvHeader(self, Option, Field, Index=0, EntryIndex=0):
        if Option != 'Ipv6InterfaceAddress':
            Option = Option[:1].lower()+Option[1:]
        Field = Field[:1].lower()+Field[1:]
        if Option == 'isIsAreaAddress':
            if Field == 'AreaAddressEntries':
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_{}.{}'.format(
                        self.name, Index, EntryIndex, Field))
            else:
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.{}'.format(self.name, Index, Field))
        elif Option == 'padding':
            return self.get_value('{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.padding.{}'.format(self.name, Index, Field))
        elif Option == 'authentionInfo':
            if Field in ['authenticationType', 'authenticationLength', 'authentication']:
                return self.get_value(
                '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.authentionInfo.authen.{}'.format(self.name, Index, Field))
            else:
                return self.get_value(
                '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.authentionInfo.{}'.format(self.name, Index, Field))
        elif Option == 'protocolSupport':
            if Field == 'nlPIDEntriesField':
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.NlPIDEntriesField.nlPIDEntry_{}.NlPIDEntriesField'.format(
                        self.name, Index, EntryIndex))
            else:
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.{}'.format(self.name, Index, Field))
        elif Option == 'ipInterfaceAddress':
            if Field == 'ipv4InterfaceAddress':
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress.ipv4InterfaceAddressEntry_{}.{}'.format(
                        self.name, Index, EntryIndex, Field))
            else:
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.ipInterfaceAddress.{}'.format(self.name, Index, Field))
        elif Option == 'neighbor':
            if Field == 'macAdd':
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.neighbor.lanEntries.ISNeighborEntry_{}.MacAdd'.format(
                        self.name, Index, EntryIndex))
            else:
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.neighbor.{}'.format(self.name, Index, Field))
        elif Option == 'restartSignal':
            if Field == 'restartNeighborIdField':
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.restartSignal.restartNeighborIdContainer.restartNeighborId_{}.{}'.format(
                        self.name, Index, EntryIndex, Field))
            else:
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.restartSignal.{}'.format(self.name, Index, Field))
        elif Option == 'Ipv6InterfaceAddress':
            if Field == 'ipv6InterfaceAddress':
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress.ipv6InterfaceAddressEntry_{}.{}'.format(
                        self.name, Index, EntryIndex, Field))
            else:
                return self.get_value(
                    '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.Ipv6InterfaceAddress.{}'.format(self.name, Index, Field))

    def editAddressEntry(self, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        for k, v in kwargs.items():
            if k != 'AreaAddress':
                k = k[:1].lower()+k[1:]
            self.update(
                '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_{}.{}={}'.format(
                    self.name, TlvIndex, EntryIndex, k, v))
            result.update(
                {(k[:1].upper() + k[1:]): 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_{}.{}'.format(
                    TlvIndex, EntryIndex, k)})
        return result

    def getAddressEntry(self, Field, TlvIndex=0, EntryIndex=0):
        if Field != 'AreaAddress':
            Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_{}.{}'.format(
                self.name, TlvIndex, EntryIndex, Field))

    def editProtocolsSupported(self, TlvIndex=0, NlpidIndex=0, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            self.update(
                '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.NlPIDEntriesField.nlPIDEntry_{}.{}={}'.format(
                    self.name, TlvIndex, NlpidIndex, k, v))
            result.update(
                {(k[:1].upper() + k[1:]):
                    'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.NlPIDEntriesField.nlPIDEntry_{}.{}'.format(
                    TlvIndex, NlpidIndex, k)})
        return result

    def getProtocolsSupported(self, Field, TlvIndex=0, NlpidIndex=0):
        Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.l1HelloMsg.isIsTlv.l1HelloisIsTlvs_{}.protocolSupport.NlPIDEntriesField.nlPIDEntry_{}.{}'.format(
                self.name, TlvIndex, NlpidIndex, Field))

from .header_base import *

file_path = SCHEMA_PATH + "ArpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("arp")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class ArpHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("arp")
        self.__hardwareType = paramDict["hardwareType"]
        self.__protocolType = paramDict["protocolType"]
        self.__hardwareSize = paramDict["hardwareSize"]
        self.__protocolSize = paramDict["protocolSize"]
        self.__opcode = paramDict["opcode"]
        self.__sendMac = paramDict["sendMac"]
        self.__sendIpv4 = paramDict["sendIpv4"]
        self.__targetMac = paramDict["targetMac"]
        self.__targetIpv4 = paramDict["targetIpv4"]

    @property
    def hardwareType(self):
        return self.__hardwareType

    @hardwareType.setter
    def hardwareType(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__hardwareType = Value

    @property
    def protocolType(self):
        return self.__protocolType

    @protocolType.setter
    def protocolType(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__protocolType = Value

    @property
    def hardwareSize(self):
        return self.__hardwareSize

    @hardwareSize.setter
    def hardwareSize(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__hardwareSize = Value

    @property
    def protocolSize(self):
        return self.__protocolSize

    @protocolSize.setter
    def protocolSize(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__protocolSize = Value

    @property
    def opcode(self):
        return self.__opcode

    @opcode.setter
    def opcode(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__opcode = Value

    @property
    def sendMac(self):
        return self.__sendMac

    @sendMac.setter
    def sendMac(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sendMac = Value

    @property
    def sendIpv4(self):
        return self.__sendIpv4

    @sendIpv4.setter
    def sendIpv4(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sendIpv4 = Value

    @property
    def targetMac(self):
        return self.__targetMac

    @targetMac.setter
    def targetMac(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__targetMac = Value

    @property
    def targetIpv4(self):
        return self.__targetIpv4

    @targetIpv4.setter
    def targetIpv4(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__targetIpv4 = Value


if __name__ == '__main__':
    object_ = ArpHeader()
    print(object_)
    print(ArpHeader.sendMac)
    print(ArpHeader.sendIpv4)
    print(ArpHeader.targetMac)
    object_ = ArpHeader(sendMac="00:00:00:12:30:11", sendIpv4="2.2.2.2", targetMac="00:00:00:12:30:12")
    print(object_.sendMac)
    print(object_.sendIpv4)
    print(object_.targetMac)

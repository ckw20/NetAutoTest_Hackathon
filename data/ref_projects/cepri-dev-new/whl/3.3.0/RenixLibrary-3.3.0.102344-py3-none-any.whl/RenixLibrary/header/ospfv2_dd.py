from .ospfv2_lsa import *

file_path = SCHEMA_PATH + "ospfv2.def.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ospfv2DatabaseDescription")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ospfv2DatabaseDescriptionHeader(Ospfv2LsaHeader):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues,
                         OptionType='ddOptions')
        self.update_upper("ospfv2DatabaseDescription")
        self.__interfaceMtu = paramDict["interfaceMtu"]
        self.__sequenceNumber = paramDict["sequenceNumber"]
        self.__ddOptions = 'ddSpecificOptions'
        self.__ddOptionsReserved7 = None
        self.__ddOptionsReserved6 = None
        self.__ddOptionsReserved5 = None
        self.__ddOptionsReserved4 = None
        self.__ddOptionsReserved3 = None
        self.__ddOptionsIBit = None
        self.__ddOptionsMBit = None
        self.__ddOptionsMsBit = None

    @property
    def ddOptionsReserved7(self):
        return self.__ddOptionsReserved7

    @ddOptionsReserved7.setter
    def ddOptionsReserved7(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved7={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsReserved7 = Value

    @property
    def ddOptionsReserved6(self):
        return self.__ddOptionsReserved6

    @ddOptionsReserved6.setter
    def ddOptionsReserved6(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved6={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsReserved6 = Value

    @property
    def ddOptionsReserved5(self):
        return self.__ddOptionsReserved5

    @ddOptionsReserved5.setter
    def ddOptionsReserved5(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved5={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsReserved5 = Value

    @property
    def ddOptionsReserved4(self):
        return self.__ddOptionsReserved4

    @ddOptionsReserved4.setter
    def ddOptionsReserved4(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved4={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsReserved4 = Value

    @property
    def ddOptionsReserved3(self):
        return self.__ddOptionsReserved3

    @ddOptionsReserved3.setter
    def ddOptionsReserved3(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved3={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsReserved3 = Value

    @property
    def ddOptionsIBit(self):
        return self.__ddOptionsIBit

    @ddOptionsIBit.setter
    def ddOptionsIBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.iBit={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsIBit = Value

    @property
    def ddOptionsMBit(self):
        return self.__ddOptionsMBit

    @ddOptionsMBit.setter
    def ddOptionsMBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.mBit={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsMBit = Value

    @property
    def ddOptionsMsBit(self):
        return self.__ddOptionsMsBit

    @ddOptionsMsBit.setter
    def ddOptionsMsBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.msBit={} ".format(self.name, self.__ddOptions, Value)).execute()
        self.__ddOptionsMsBit = Value

    @property
    def interfaceMtu(self):
        return self.__interfaceMtu

    @interfaceMtu.setter
    def interfaceMtu(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__interfaceMtu = Value

    @property
    def sequenceNumber(self):
        return self.__sequenceNumber

    @sequenceNumber.setter
    def sequenceNumber(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sequenceNumber = Value

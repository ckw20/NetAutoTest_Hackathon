from .header_base import *

file_path = SCHEMA_PATH + "Serviceoam.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("CCM")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class EoamHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("CCM")
        self.__MDlevel = 0
        self.__Version = '00000'
        self.__OpCode = paramDict["OpCode"]
        self.__RDIbit = paramDict["RDIbit"]
        self.__Reserved = paramDict["Reserved"]
        self.__CCMIntervalField = paramDict["CCMIntervalField"]
        self.__FirstTLVOffset = paramDict["FirstTLVOffset"]
        self.__SequenceNumber = paramDict["SequenceNumber"]
        self.__MAEPI = paramDict["MAEPI"]
        self.__MDNF = '01'
        self.__MDNL = '00'
        self.__MDN = '00'
        self.__SMAF = '01'
        self.__SMAL = '01'
        self.__SMAN = '00'
        self.__pad = '00'
        self.__ITUTY1731 = paramDict["ITU-TY1731"]
        self.__Tlvs = None
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.MAID.theMDNL'.format(self.name),
                                NodeName='MDNLength').execute()
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.MAID.theMDN'.format(self.name),
                                NodeName='MaintenanceDomainName').execute()
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.MAID.thePad'.format(self.name),
                                NodeName='Padding').execute()

    @property
    def MDlevel(self):
        return self.__MDlevel

    @MDlevel.setter
    def MDlevel(self, Value):
        self.update('{}.cfmHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__MDlevel = Value

    @property
    def Version(self):
        return self.__Version

    @Version.setter
    def Version(self, Value):
        self.update('{}.cfmHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__Version = Value

    @property
    def OpCode(self):
        return self.__OpCode

    @OpCode.setter
    def OpCode(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__OpCode = Value

    @property
    def RDIbit(self):
        return self.__RDIbit

    @RDIbit.setter
    def RDIbit(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__RDIbit = Value

    @property
    def Reserved(self):
        return self.__Reserved

    @Reserved.setter
    def Reserved(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__Reserved = Value

    @property
    def CCMIntervalField(self):
        return self.__CCMIntervalField

    @CCMIntervalField.setter
    def CCMIntervalField(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__CCMIntervalField = Value

    @property
    def FirstTLVOffset(self):
        return self.__FirstTLVOffset

    @FirstTLVOffset.setter
    def FirstTLVOffset(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__FirstTLVOffset = Value

    @property
    def SequenceNumber(self):
        return self.__SequenceNumber

    @SequenceNumber.setter
    def SequenceNumber(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__SequenceNumber = Value

    @property
    def MAEPI(self):
        return self.__MAEPI

    @MAEPI.setter
    def MAEPI(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__MAEPI = Value

    @property
    def MDNF(self):
        return self.__MDNF

    @MDNF.setter
    def MDNF(self, Value):
        self.update('{}.MAID.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__MDNF = Value

    @property
    def MDNL(self):
        return self.__MDNL

    @MDNL.setter
    def MDNL(self, Value):
        self.update('{}.MAID.theMDNL.MDNLength_0.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__MDNL = Value

    @property
    def MDN(self):
        return self.__MDN

    @MDN.setter
    def MDN(self, Value):
        self.update('{}.MAID.theMDN.MaintenanceDomainName_0.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__MDN = Value

    @property
    def SMAF(self):
        return self.__SMAF

    @SMAF.setter
    def SMAF(self, Value):
        self.update('{}.MAID.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__SMAF = Value

    @property
    def SMAL(self):
        return self.__SMAL

    @SMAL.setter
    def SMAL(self, Value):
        self.update('{}.MAID.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__SMAL = Value

    @property
    def SMAN(self):
        return self.__SMAN

    @SMAN.setter
    def SMAN(self, Value):
        self.update('{}.MAID.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__SMAN = Value

    @property
    def ITUTY1731(self):
        return self.__ITUTY1731

    @ITUTY1731.setter
    def ITUTY1731(self, Value):
        self.update('{}.ITU-TY1731={} '.format(self.name, Value))
        self.__ITUTY1731 = Value

    @property
    def pad(self):
        return self.__pad

    @pad.setter
    def pad(self, Value):
        self.update('{}.MAID.thePad.Padding_0.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pad = Value

    @property
    def Tlvs(self):
        return self.__Tlvs

    @Tlvs.setter
    def Tlvs(self, Values):
        if not isinstance(Values, (list, set)):
            Values = [Values]
        for Value in Values:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.theCCMTLVS'.format(self.name),
                                    NodeName=Value).execute()
        self.__Tlvs = Values

    def config_sender_id_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ not in ['theChassisID', 'theManagementAddressDomain']:
                self.update('{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.{}={} '.format(self.name, Index, k, v))
                result.update({k: 'theCCMTLVS.CCMTLVList_{}.SenderIDTLV.{}'.format(Index, k)})
            else:
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName='{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.{}'.format(self.name, Index, k_),
                                        NodeName=v).execute()
        return result

    def get_sender_id_tlv(self, Index, Item):
        return self.get_value(field='{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.{}'.format(
            self.name, Index, Item))

    def config_sender_id_tlv_chassis_id(self, TlvIndex, Index, Type, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theChassisID.ChassisIDList_{}.{}.{}={} '.format(
                self.name, TlvIndex, Index, Type, k, v))
            result.update({k: 'theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theChassisID.ChassisIDList_{}.{}.{}'.format(
                TlvIndex, Index, Type, k)})
        return result

    def get_sender_id_tlv_chassis_id(self, TlvIndex, Index, Type, Item):
        return self.get_value(field='{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theChassisID.ChassisIDList_{}.{}.{}'.format(
            self.name, TlvIndex, Index, Type, Item))

    def config_sender_id_tlv_management_address_domain(self, TlvIndex, Index, Type, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k in ['IPv4', 'Port', 'IPv6', 'Name']:
                self.update('{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theManagementAddressDomain.MADList_{}.{}.ManAdd.{}={} '.format(
                    self.name, TlvIndex, Index, Type, k, v))
                result.update({k: 'theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theManagementAddressDomain.MADList_{}.{}.ManAdd.{}'.format(
                    TlvIndex, Index, Type, k)})
            else:
                self.update('{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theManagementAddressDomain.MADList_{}.{}.{}={} '.format(
                    self.name, TlvIndex, Index, Type, k, v))
                result.update({k: 'theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theManagementAddressDomain.MADList_{}.{}.{}'.format(
                    TlvIndex, Index, Type, k)})
        return result

    def get_sender_id_tlv_management_address_domain(self, TlvIndex, Index, Type, Item):
        if Item in ['IPv4', 'Port', 'IPv6', 'Name']:
            return self.get_value(field='{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theManagementAddressDomain.MADList_{}.{}.ManAdd.{}'.format(
                self.name, TlvIndex, Index, Type, Item))
        else:
            return self.get_value(field='{}.theCCMTLVS.CCMTLVList_{}.SenderIDTLV.theManagementAddressDomain.MADList_{}.{}.{}'.format(
                self.name, TlvIndex, Index, Type, Item))

    def config_port_status_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.theCCMTLVS.CCMTLVList_{}.PortStatusTLV.{}={} '.format(self.name, Index, k, v))
            result.update({k: 'theCCMTLVS.CCMTLVList_{}.PortStatusTLV.{}'.format(Index, k)})
        return result

    def get_port_status_tlv(self, Index, Item):
        return self.get_value(
            field='{}.theCCMTLVS.CCMTLVList_{}.PortStatusTLV.{}'.format(self.name, Index, Item))

    def config_interface_status_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.theCCMTLVS.CCMTLVList_{}.InterfaceStatusTLV.{}={} '.format(self.name, Index, k, v))
            result.update({k: 'theCCMTLVS.CCMTLVList_{}.InterfaceStatusTLV.{}'.format(Index, k)})
        return result

    def get_interface_status_tlv(self, Index, Item):
        return self.get_value(
            field='{}.theCCMTLVS.CCMTLVList_{}.InterfaceStatusTLV.{}'.format(self.name, Index, Item))

    def config_organization_specific_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k == 'Value':
                self.update('{}.theCCMTLVS.CCMTLVList_{}.OrgSpecTLV.theValue.Value_0.{}={} '.format(self.name, Index, k, v))
                result.update({k: 'theCCMTLVS.CCMTLVList_{}.OrgSpecTLV.theValue.Value_0.{}'.format(Index, k)})
            else:
                self.update('{}.theCCMTLVS.CCMTLVList_{}.OrgSpecTLV.{}={} '.format(self.name, Index, k, v))
                result.update({k: 'theCCMTLVS.CCMTLVList_{}.OrgSpecTLV.{}'.format(Index, k)})
        return result

    def get_organization_specific_tlv(self, Index, Item):
        if Item == 'Value':
            return self.get_value(field='{}.theCCMTLVS.CCMTLVList_{}.OrgSpecTLV.theValue.Value_0.{}'.format(
                self.name, Index, Item))
        else:
            return self.get_value(field='{}.theCCMTLVS.CCMTLVList_{}.OrgSpecTLV.{}'.format(self.name, Index, Item))

    def config_end_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.theCCMTLVS.CCMTLVList_{}.EndTLV.{}={} '.format(self.name, Index, k, v))
            result.update({k: 'theCCMTLVS.CCMTLVList_{}.EndTLV.{}'.format(Index, k)})
        return result

    def get_end_tlv(self, Index, Item):
        return self.get_value(
            field='{}.theCCMTLVS.CCMTLVList_{}.EndTLV.{}'.format(self.name, Index, Item))

from .header_base import *

file_path = SCHEMA_PATH + "PppTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ppp")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class PppHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ppp")
        self.__addresses = paramDict["addresses"]
        self.__controls = paramDict["controls"]
        self.__protocol = paramDict["protocol"]

    @property
    def addresses(self):
        return self.__addresses

    @addresses.setter
    def addresses(self, Value):
        # support to insert only 1 node
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.addresses'.format(self.name, sys._getframe().f_code.co_name),
                                NodeName='Address').execute()
        self.update('{}.addresses.Address_0.value={}'.format(self.name, Value))
        self.__addresses = Value

    @property
    def controls(self):
        return self.__controls

    @controls.setter
    def controls(self, Value):
        # support to insert only 1 node
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.controls'.format(self.name, sys._getframe().f_code.co_name),
                                NodeName='Control').execute()
        self.update('{}.controls.Control_0.value={}'.format(self.name, Value))
        self.__controls = Value

    @property
    def protocol(self):
        return self.__protocol

    @protocol.setter
    def protocol(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__protocol = Value

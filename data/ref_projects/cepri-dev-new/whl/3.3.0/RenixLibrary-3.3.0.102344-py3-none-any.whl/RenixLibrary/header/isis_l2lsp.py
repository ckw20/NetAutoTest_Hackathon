from .header_base import *
import re

file_path = SCHEMA_PATH + "IsIsTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndexes = [headers.index("l2LspCommonHeader"), headers.index('LspDataUnitHeader')]
    attributes, displays, defaultValues = [], [], []
    for headerIndex in headerIndexes:
        attributes.extend([i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        displays.extend([i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        defaultValues.extend([i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class IsisL2LspHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("l2lspHeader")
        self.__InterRoutingProtocolDiscriminator = paramDict["InterRoutingProtocolDiscriminator"]
        self.__lengthIndicator = paramDict["lengthIndicator"]
        self.__versionIdExtend = paramDict["versionIdExtend"]
        self.__idLength = paramDict["idLength"]
        self.__reserved1 = paramDict["reserved1"]
        self.__pDUType = paramDict["pDUType"]
        self.__version = paramDict["version"]
        self.__reserved2 = paramDict["reserved2"]
        self.__maxAreaAddress = paramDict["maxAreaAddress"]
        self.__pDULength = paramDict["pDULength"]
        self.__remainTime = paramDict["remainTime"]
        self.__lspId = paramDict["lspId"]
        self.__seqcenceNum = paramDict["seqcenceNum"]
        self.__checksum = paramDict["checksum"]
        self.__partitionRepair = paramDict["partitionRepair"]
        self.__attchment = paramDict["attchment"]
        self.__OverloadBit = paramDict["OverloadBit"]
        self.__TypeOfIntermediateSystem = paramDict["TypeOfIntermediateSystem"]
        self.__LspisIsTlvOptionSet = paramDict["LspisIsTlvOptionSet"]

    @property
    def InterRoutingProtocolDiscriminator(self):
        return self.__InterRoutingProtocolDiscriminator

    @InterRoutingProtocolDiscriminator.setter
    def InterRoutingProtocolDiscriminator(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__InterRoutingProtocolDiscriminator = Value

    @property
    def lengthIndicator(self):
        return self.__lengthIndicator

    @lengthIndicator.setter
    def lengthIndicator(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lengthIndicator = Value

    @property
    def versionIdExtend(self):
        return self.__versionIdExtend

    @versionIdExtend.setter
    def versionIdExtend(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__versionIdExtend = Value

    @property
    def idLength(self):
        return self.__idLength

    @idLength.setter
    def idLength(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__idLength = Value

    @property
    def reserved1(self):
        return self.__reserved1

    @reserved1.setter
    def reserved1(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved1 = Value

    @property
    def pDUType(self):
        return self.__pDUType

    @pDUType.setter
    def pDUType(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pDUType = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version = Value

    @property
    def reserved2(self):
        return self.__reserved2

    @reserved2.setter
    def reserved2(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved2 = Value

    @property
    def maxAreaAddress(self):
        return self.__maxAreaAddress

    @maxAreaAddress.setter
    def maxAreaAddress(self, Value):
        self.update('{}.l2LspCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__maxAreaAddress = Value

    @property
    def pDULength(self):
        return self.__pDULength

    @pDULength.setter
    def pDULength(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pDULength = Value

    @property
    def remainTime(self):
        return self.__remainTime

    @remainTime.setter
    def remainTime(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__remainTime = Value

    @property
    def lspId(self):
        return self.__lspId

    @lspId.setter
    def lspId(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lspId = Value

    @property
    def seqcenceNum(self):
        return self.__seqcenceNum

    @seqcenceNum.setter
    def seqcenceNum(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__seqcenceNum = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def partitionRepair(self):
        return self.__partitionRepair

    @partitionRepair.setter
    def partitionRepair(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__partitionRepair = Value

    @property
    def attchment(self):
        return self.__attchment

    @attchment.setter
    def attchment(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__attchment = Value

    @property
    def OverloadBit(self):
        return self.__OverloadBit

    @OverloadBit.setter
    def OverloadBit(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__OverloadBit = Value

    @property
    def TypeOfIntermediateSystem(self):
        return self.__TypeOfIntermediateSystem

    @TypeOfIntermediateSystem.setter
    def TypeOfIntermediateSystem(self, Value):
        self.update('{}.LspDataUnitHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__TypeOfIntermediateSystem = Value

    @property
    def LspisIsTlvOptionSet(self):
        return self.__LspisIsTlvOptionSet

    @LspisIsTlvOptionSet.setter
    def LspisIsTlvOptionSet(self, Value):
        # isIsAreaAddress isIsReachability extendedReachability isIsIpInterReachability isIsProtocolsSupported
        # isIsIPExternalReachability ipInterfaceAddress Ipv6InterfaceAddress isIsIpv6Reachability
        # if not isinstance(Value, (list, tuple, set)):
        #     Value = [Value]
        # for i in Value:
        #     InsertNodeToASetCommand(Stream=self.stream.handle,
        #                             ParentName='{}.LspDataUnitHeader.{}'.format(self.name,
        #                                                                         sys._getframe().f_code.co_name),
        #                             NodeName=i).execute()
        self.__LspisIsTlvOptionSet = Value

    def editTlvHeader(self, Option, Index=0, **kwargs):
        result = {}
        Option = Option[:1].lower() + Option[1:]
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if Option == 'isIsAreaAddress':
            for k, v in kwargs.items():
                if k == 'areaAddressEntries':
                    # need delete node
                    for i in range(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries'.format(
                                                    self.name, Index),
                                                NodeName='AreaAddressEntry').execute()
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsAreaAddress.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsAreaAddress.{}'.format(
                            Index, k)})
        elif Option == 'isIsReachability':
            for k, v in kwargs.items():
                if k == 'metricEntries':
                    # need delete node
                    for i in range(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsReachability.metricEntries'.format(
                                                    self.name, Index),
                                                NodeName='metricEntry').execute()
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsReachability.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsReachability.{}'.format(
                            Index, k)})
        elif Option == 'extendedReachability':
            for k, v in kwargs.items():
                if k == 'iisNeighborSubTlv':
                    # need delete node
                    # for i in v:
                    #     InsertNodeToASetCommand(Stream=self.stream.handle,
                    #                             ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.extendedReachability.iisNeighborSubTlv'.format(
                    #                                 self.name, Index),
                    #                             NodeName=i).execute()
                    pass
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.extendedReachability.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.extendedReachability.{}'.format(
                            Index, k)})
        elif Option == 'isIsIpInterReachability':
            for k, v in kwargs.items():
                if k == 'internalmetricEntries':
                    # need delete node
                    for i in range(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpInterReachability.internalmetricEntries'.format(
                                                    self.name, Index),
                                                NodeName='internalMetricEntry').execute()
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpInterReachability.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpInterReachability.{}'.format(
                            Index, k)})
        elif Option == 'isIsProtocolsSupported':
            for k, v in kwargs.items():
                if k == 'nlPIDEntriesField':
                    # need delete node
                    for i in range(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsProtocolsSupported.NlPIDEntriesField'.format(
                                                    self.name, Index),
                                                NodeName='nlPIDEntry').execute()
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsProtocolsSupported.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsProtocolsSupported.{}'.format(
                            Index, k)})
        elif Option == 'isIsIPExternalReachability':
            for k, v in kwargs.items():
                if k == 'externalmetricEntries':
                    # need delete node
                    for i in range(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIPExternalReachability.externalmetricEntries'.format(
                                                    self.name, Index),
                                                NodeName='externalMetricEntry').execute()
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIPExternalReachability.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIPExternalReachability.{}'.format(
                            Index, k)})
        elif Option == 'ipInterfaceAddress':
            for k, v in kwargs.items():
                if k == 'ipv4InterfaceAddress':
                    # need delete node
                    for i, address in enumerate(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress'.format(
                                                    self.name, Index),
                                                NodeName='ipv4InterfaceAddressEntry').execute()
                        self.update(
                            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress.ipv4InterfaceAddressEntry_{}.ipv4InterfaceAddress={}'.format(
                                self.name, Index, i, address))
                        k_ = k[:1].upper() + k[1:]
                        result.update({f'{k_}: {address}':
                            'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress.ipv4InterfaceAddressEntry_{}.ipv4InterfaceAddress'.format(
                                Index, i)})
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.ipInterfaceAddress.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.ipInterfaceAddress.{}'.format(
                            Index, k)})
        elif Option == 'ipv6InterfaceAddress':
            for k, v in kwargs.items():
                if k == 'ipv6InterfaceAddress':
                    # need delete node
                    for i, address in enumerate(v):
                        InsertNodeToASetCommand(Stream=self.stream.handle,
                                                ParentName='{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress'.format(
                                                    self.name, Index),
                                                NodeName='ipv6InterfaceAddressEntry').execute()
                        self.update(
                            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress.ipv6InterfaceAddressEntry_{}.ipv6InterfaceAddress={}'.format(
                                self.name, Index, i, address))
                        k_ = k[:1].upper() + k[1:]
                        result.update({f'{k_}: {address}':
                            'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress.ipv6InterfaceAddressEntry_{}.ipv6InterfaceAddress'.format(
                                Index, i)})
                else:
                    self.update(
                        '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.Ipv6InterfaceAddress.{}={}'.format(
                            self.name, Index, k, v))
                    result.update({(k[:1].upper() + k[1:]):
                        'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.Ipv6InterfaceAddress.{}'.format(
                            Index, k)})
        elif Option == 'isIsIpv6Reachability':
            for k, v in kwargs.items():
                self.update(
                    '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpv6Reachability.{}={}'.format(
                        self.name, Index, k, v))
                result.update({(k[:1].upper() + k[1:]):
                    'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpv6Reachability.{}'.format(
                        Index, k)})
        return result

    def getTlvHeader(self, Option, Field, Index=0):
        Option = Option[:1].lower() + Option[1:]
        Field = Field[:1].lower()+Field[1:]
        if Option == 'isIsAreaAddress':
            return self.get_value(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsAreaAddress.{}'.format(self.name, Index,
                                                                                                    Field))
        elif Option == 'isIsReachability':
            return self.get_value(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsReachability.{}'.format(self.name, Index,
                                                                                                     Field))
        elif Option == 'extendedReachability':
            return self.get_value(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.extendedReachability.{}'.format(self.name,
                                                                                                         Index, Field))
        elif Option == 'isIsIpInterReachability':
            return self.get_value(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpInterReachability.{}'.format(self.name,
                                                                                                            Index,
                                                                                                            Field))
        elif Option == 'isIsProtocolsSupported':
            return self.get_value(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsProtocolsSupported.{}'.format(self.name,
                                                                                                           Index,
                                                                                                           Field))
        elif Option == 'isIsIPExternalReachability':
            return self.get_value(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIPExternalReachability.{}'.format(
                    self.name, Index, Field))
        elif Option == 'ipInterfaceAddress':
            if Field == 'ipv4InterfaceAddress':
                addresses = []
                cmd = ListInstanceLeafCommand(Stream=self.stream.handle, Deep=True)
                cmd.execute()
                for i in cmd.Leaves:
                    result = re.match('.*(ipv4InterfaceAddressEntry_\d+[.]ipv4InterfaceAddress).*', i)
                    if result is not None:
                        item = result.group(1)
                        address = self.get_value(
                            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.ipInterfaceAddress.ipv4InterfaceAddress.{}'.format(
                                self.name, Index, item))
                        if address != '':
                            addresses.append(address)
                return addresses
            else:
                return self.get_value(
                    '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.ipInterfaceAddress.{}'.format(self.name,
                                                                                                           Index,
                                                                                                           Field))
        elif Option == 'ipv6InterfaceAddress':
            if Field == 'ipv6InterfaceAddress':
                addresses = []
                cmd = ListInstanceLeafCommand(Stream=self.stream.handle, Deep=True)
                cmd.execute()
                for i in cmd.Leaves:
                    result = re.match('.*(ipv6InterfaceAddressEntry_\d+[.]ipv6InterfaceAddress).*', i)
                    if result is not None:
                        item = result.group(1)
                        address = self.get_value(
                            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.Ipv6InterfaceAddress.ipv6InterfaceAddress.{}'.format(
                                self.name, Index, item))
                        if address != '':
                            addresses.append(address)
                return addresses
            else:
                return self.get_value(
                    '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.Ipv6InterfaceAddress.{}'.format(self.name,
                                                                                                             Index,
                                                                                                             Field))
        elif Option == 'isIsIpv6Reachability':
            return self.get_value(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpv6Reachability.{}'.format(self.name,
                                                                                                         Index, Field))

    def editAddressEntry(self, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        for k, v in kwargs.items():
            if k != 'AreaAddress':
                k = k[:1].lower()+k[1:]
            self.update(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_{}.{}={}'.format(
                    self.name, TlvIndex, EntryIndex, k, v))
            result.update({(k[:1].upper() + k[1:]):
                'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_{}.{}'.format(
                    TlvIndex, EntryIndex, k)})
        return result

    def getAddressEntry(self, Field, TlvIndex=0, EntryIndex=0):
        if Field != 'AreaAddress':
            Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_{}.{}'.format(
                self.name, TlvIndex, EntryIndex, Field))

    def editMetricEntry(self, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            self.update(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsReachability.metricEntries.metricEntry_{}.{}={}'.format(
                    self.name, TlvIndex, EntryIndex, k, v))
            result.update({(k[:1].upper() + k[1:]):
                'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsReachability.metricEntries.metricEntry_{}.{}'.format(
                    TlvIndex, EntryIndex, k)})
        return result

    def getMetricEntry(self, Field, TlvIndex=0, EntryIndex=0):
        Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsReachability.metricEntries.metricEntry_{}.{}'.format(
                self.name, TlvIndex, EntryIndex, Field))

    def editSubTlv(self, SubTlv, TlvIndex=0, SubTlvIndex=0, **kwargs):
        result = {}
        if SubTlv != 'ReservableLinkBandwidthSubtlv':
            SubTlv = SubTlv[:1].lower()+SubTlv[1:]
        for k, v in kwargs.items():
            if k not in ['ReservableLinkBandwidthValue']:
                k = k[:1].lower()+k[1:]
            self.update(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.extendedReachability.iisNeighborSubTlv.iisNeighborSubContainer_{}.{}.{}={}'.format(
                    self.name, TlvIndex, SubTlvIndex, SubTlv, k, v))
            result.update({(k[:1].upper() + k[1:]):
                'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.extendedReachability.iisNeighborSubTlv.iisNeighborSubContainer_{}.{}.{}'.format(
                    TlvIndex, SubTlvIndex, SubTlv, k)})
        return result

    def getSubTlv(self, SubTlv, Field, TlvIndex=0, SubTlvIndex=0):
        if SubTlv != 'ReservableLinkBandwidthSubtlv':
            SubTlv = SubTlv[:1].lower() + SubTlv[1:]
        if Field != 'ReservableLinkBandwidthValue':
            Field = Field[:1].lower() + Field[1:]
        return self.get_value(
            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.extendedReachability.iisNeighborSubTlv.iisNeighborSubContainer_{}.{}.{}'.format(
                self.name, TlvIndex, SubTlvIndex, SubTlv, Field))

    def editInternalMetricEntry(self, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            self.update(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_{}.{}={}'.format(
                    self.name, TlvIndex, EntryIndex, k, v))
            result.update({(k[:1].upper() + k[1:]):
                'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_{}.{}'.format(
                    TlvIndex, EntryIndex, k)})
        return result

    def getInternalMetricEntry(self, Field, TlvIndex=0, EntryIndex=0):
        Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_{}.{}'.format(
                self.name, TlvIndex, EntryIndex, Field))

    def editProtocolsSupported(self, TlvIndex=0, NlpidIndex=0, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            self.update(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsProtocolsSupported.NlPIDEntriesField.nlPIDEntry_{}.{}={}'.format(
                    self.name, TlvIndex, NlpidIndex, k, v))
            result.update({(k[:1].upper() + k[1:]):
                'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsProtocolsSupported.NlPIDEntriesField.nlPIDEntry_{}.{}'.format(
                    TlvIndex, NlpidIndex, k)})
        return result

    def getProtocolsSupported(self, Field, TlvIndex=0, NlpidIndex=0):
        Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsProtocolsSupported.NlPIDEntriesField.nlPIDEntry_{}.{}'.format(
                self.name, TlvIndex, NlpidIndex, Field))

    def editExternalMetricEntry(self, TlvIndex=0, EntryIndex=0, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            self.update(
                '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_{}.{}={}'.format(
                    self.name, TlvIndex, EntryIndex, k, v))
            result.update({(k[:1].upper() + k[1:]):
                'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_{}.{}'.format(
                    TlvIndex, EntryIndex, k)})
        return result

    def getExternalMetricEntry(self, Field, TlvIndex=0, EntryIndex=0):
        Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_{}.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_{}.{}'.format(
                self.name, TlvIndex, EntryIndex, Field))

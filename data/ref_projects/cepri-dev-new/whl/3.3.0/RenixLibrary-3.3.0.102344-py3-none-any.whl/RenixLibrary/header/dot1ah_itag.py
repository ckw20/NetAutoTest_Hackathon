from .header_base import *

file_path = SCHEMA_PATH + "ITag.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("iTag")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class iTagHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("itag")
        self.__pcp = paramDict["pcp"]
        self.__drop = paramDict["drop"]
        self.__uca = paramDict["uca"]
        self.__res1 = paramDict["res1"]
        self.__res2 = paramDict["res2"]
        self.__serviceId = paramDict["serviceId"]
        self.__encapCusDstAddr = paramDict["encapCusDstAddr"]
        self.__sourceMacAdd = paramDict["sourceMacAdd"]

    @property
    def pcp(self):
        return self.__pcp

    @pcp.setter
    def pcp(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pcp = Value

    @property
    def drop(self):
        return self.__drop

    @drop.setter
    def drop(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__drop = Value

    @property
    def uca(self):
        return self.__uca

    @uca.setter
    def uca(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__uca = Value

    @property
    def res1(self):
        return self.__res1

    @res1.setter
    def res1(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__res1 = Value

    @property
    def res2(self):
        return self.__res2

    @res2.setter
    def res2(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__res2 = Value

    @property
    def serviceId(self):
        return self.__serviceId

    @serviceId.setter
    def serviceId(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__serviceId = Value

    @property
    def encapCusDstAddr(self):
        return self.__encapCusDstAddr

    @encapCusDstAddr.setter
    def encapCusDstAddr(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__encapCusDstAddr = Value

    @property
    def sourceMacAdd(self):
        return self.__sourceMacAdd

    @sourceMacAdd.setter
    def sourceMacAdd(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sourceMacAdd = Value

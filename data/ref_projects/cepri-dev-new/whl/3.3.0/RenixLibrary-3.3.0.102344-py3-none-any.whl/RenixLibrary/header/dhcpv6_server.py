from .dhcpv6_base import *

file_path = SCHEMA_PATH + "Dhcpv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("dhcpv6Server")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class dhcpv6ServerHeader(Dhcpv6):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("dhcpv6Server")
        self.__messageType = paramDict["messageType"]
        self.__transId = paramDict["transId"]
        self.__iaOption = None
        self.__iaOptionIndex = 0
        self.__iaOptions = None
        self.__iapdOptionIndex = 0

    # @property
    # def messageType(self):
    #     return self.__messageType
    #
    # @messageType.setter
    # def messageType(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__messageType = Value
    #
    # @property
    # def transId(self):
    #     return self.__transId
    #
    # @transId.setter
    # def transId(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__transId = Value
    #
    # def insert_dhcpv6_server_option_header(self, Value):
    #     if not isinstance(Value, (list, set, tuple)):
    #         Value = [Value]
    #     for x in Value:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.options'.format(self.name),
    #                                 NodeName='{}'.format(x)).execute()
    #     return True
    #
    # def _edit_public_attribute(self, Options, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     if 'type' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.{}.type={}".format(
    #                                 self.name, Index, Options, kwargs[
    #                                     'type'])).execute()
    #     if 'length' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.{}.length={}".format(
    #                                 self.name, Index, Options, kwargs[
    #                                     'length'])).execute()
    #
    # def edit_client_id_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='clientIdOption', Index=Index, **kwargs)
    #     if 'duid' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.clientIdOption.duid={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'duid'])).execute()
    #     return True
    #
    # def edit_server_id_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='serverIdOption', Index=Index, **kwargs)
    #     if 'duidType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.serverIdOption.duidType={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'duidType'])).execute()
    #     if 'hardwareType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.serverIdOption.hardwareType={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'hardwareType'])).execute()
    #     if 'linkAddress' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.serverIdOption.linkAddress={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'linkAddress'])).execute()
    #     return True
    #
    # def edit_iana_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='ianaOption', Index=Index, **kwargs)
    #     if 'iaid' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.ianaOption.iaid={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'iaid'])).execute()
    #     if 't1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.ianaOption.t1={}".format(
    #                                 self.name, Index, kwargs[
    #                                     't1'])).execute()
    #     if 't2' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.ianaOption.t2={}".format(
    #                                 self.name, Index, kwargs[
    #                                     't2'])).execute()
    #     if 't2' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.ianaOption.t2={}".format(
    #                                 self.name, Index, kwargs[
    #                                     't2'])).execute()
    #     if 'iaOption' in set(kwargs.keys()):
    #         if kwargs['iaOption'] is None:
    #             if self.__iaOption is not None:
    #                 # TODO 删除节点
    #                 self.__iaOption = None
    #                 pass
    #         else:
    #             if self.__iaOption is not None:
    #                 self.edit_dhcpv6_ia(Subtype='dhcpv6iaaddress', Index=Index, OptionIndex=self.__iaOptionIndex,
    #                                     **kwargs['iaOption'])
    #             else:
    #                 InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                         ParentName='{}.options.Dhcpv6Options_{}.ianaOption.iaOption'.format(
    #                                             self.name, Index),
    #                                         NodeName='Dhcpv6IaAddress').execute()
    #                 self.edit_dhcpv6_ia(Subtype='dhcpv6iaaddress', Index=Index, OptionIndex=self.__iaOptionIndex,
    #                                     **kwargs['iaOption'])
    #                 self.__iaOptionIndex += 1
    #                 self.__iaOption = True
    #     return True
    #
    #
    #
    # def edit_request_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='requestOption', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.requestOption.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_elapsed_time_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='elapsedTimeOption', Index=Index, **kwargs)
    #     if 'elapseTime' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.elapsedTimeOption.elapseTime={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'elapseTime'])).execute()
    #     return True
    #
    # def edit_server_unicast_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='serverUnicastOption', Index=Index, **kwargs)
    #     if 'serverAddress' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.serverUnicastOption.serverAddress={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'serverAddress'])).execute()
    #     return True
    #
    # def edit_status_code_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='statusCodeOption', Index=Index, **kwargs)
    #     if 'statusCode' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.statusCodeOption.statusCode={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'statusCode'])).execute()
    #     if 'statusMsg' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.statusCodeOption.statusMsg={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'statusMsg'])).execute()
    #     return True
    #
    # def edit_rapid_commit_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='rapidCommitOption', Index=Index, **kwargs)
    #
    # def edit_interface_id_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='interfaceIdOption', Index=Index, **kwargs)
    #     if 'interfaceId' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.interfaceIdOption.interfaceId={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'interfaceId'])).execute()
    #     return True
    #
    # def edit_reconfigure_accept_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='reconfigureAcceptOption', Index=Index, **kwargs)
    #
    # def edit_iapd_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='iapdOption', Index=Index, **kwargs)
    #     if 'iaid' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.iapdOption.iaid={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'iaid'])).execute()
    #     if 't1' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.iapdOption.t1={}".format(
    #                                 self.name, Index, kwargs[
    #                                     't1'])).execute()
    #     if 't2' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.iapdOption.t2={}".format(
    #                                 self.name, Index, kwargs[
    #                                     't2'])).execute()
    #     if 'iaOption' in set(kwargs.keys()):
    #         if kwargs['iaOption'] is None:
    #             if self.__iaOptions is not None:
    #                 # TODO 删除节点
    #                 self.__iaOptions = None
    #                 pass
    #         else:
    #             if self.__iaOptions is not None:
    #                 self.edit_dhcpv6_ia(Subtype='dhcpv6iaprefix', Index=Index, OptionIndex=self.__iapdOptionIndex,
    #                                     **kwargs['iaOption'])
    #             else:
    #                 InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                         ParentName='{}.options.Dhcpv6Options_{}.iapdOption.iaOption'.format(
    #                                             self.name, Index),
    #                                         NodeName='Dhcpv6IaPrefix').execute()
    #                 self.edit_dhcpv6_ia(Subtype='dhcpv6iaprefix', Index=Index, OptionIndex=self.__iapdOptionIndex,
    #                                     **kwargs['iaOption'])
    #                 self.__iapdOptionIndex += 1
    #                 self.__iaOptions = True
    #     return True
    #
    # def edit_custom_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='customOption', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.customOption.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_general_tlv(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='generalTLV', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv6Options_{}.generalTLV.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_dhcpv6_ia(self, Subtype, Index, OptionIndex, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     if Subtype.lower() == 'dhcpv6iaaddress':
    #         if 'type' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.ianaOption.iaOption.Dhcpv6IaAddress_{}.type={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'type'])).execute()
    #         if 'length' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.ianaOption.iaOption.Dhcpv6IaAddress_{}.length={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'length'])).execute()
    #         if 'ipv6Address' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.ianaOption.iaOption.Dhcpv6IaAddress_{}.ipv6Address={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'ipv6Address'])).execute()
    #         if 'preferredLifetime' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.ianaOption.iaOption.Dhcpv6IaAddress_{}.preferredLifetime={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'preferredLifetime'])).execute()
    #         if 'validLifetime' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.ianaOption.iaOption.Dhcpv6IaAddress_{}.validLifetime={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'validLifetime'])).execute()
    #     elif Subtype.lower() == 'dhcpv6iaprefix':
    #         if 'type' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_{}.type={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'type'])).execute()
    #         if 'length' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_{}.length={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'length'])).execute()
    #         if 'preferredLifetime' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_{}.preferredLifetime={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'preferredLifetime'])).execute()
    #         if 'validLifetime' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_{}.validLifetime={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'validLifetime'])).execute()
    #         if 'prefixLength' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_{}.prefixLength={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'prefixLength'])).execute()
    #         if 'ipv6Address' in set(kwargs.keys()):
    #             UpdateHeaderCommand(Stream=self.stream.handle,
    #                                 Parameter="{}.options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_{}.ipv6Address={} ".format(
    #                                     self.name, Index, OptionIndex, kwargs[
    #                                         'ipv6Address'])).execute()
from .header_base import *

class L2tpv3Control(HeaderBase):

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, **kwargs)

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__type = Value

    @property
    def useLength(self):
        return self.__useLength

    @useLength.setter
    def useLength(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__useLength = Value

    @property
    def reserved1(self):
        return self.__reserved1

    @reserved1.setter
    def reserved1(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved1 = Value

    @property
    def useSequence(self):
        return self.__useSequence

    @useSequence.setter
    def useSequence(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__useSequence = Value

    @property
    def reserved2(self):
        return self.__reserved2

    @reserved2.setter
    def reserved2(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved2 = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__version = Value

    @property
    def controlId(self):
        return self.__controlId

    @controlId.setter
    def controlId(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__controlId = Value

    @property
    def sequenceNumberNs(self):
        return self.__sequenceNumberNs

    @sequenceNumberNs.setter
    def sequenceNumberNs(self, Value):
        self.update('{}.seqNum.sequenceNumber_0.ns={} '.format(self.name, Value))
        self.__sequenceNumberNs = Value

    @property
    def sequenceNumberNr(self):
        return self.__sequenceNumberNr

    @sequenceNumberNr.setter
    def sequenceNumberNr(self, Value):
        self.update('{}.seqNum.sequenceNumber_0.nr={} '.format(self.name, Value))
        self.__sequenceNumberNr = Value

    def insert_option_header(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            if x == 'generalTLV':
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName='{}.avpOptions'.format(self.name),
                                        NodeName='generalTLV').execute()
            else:
                InsertNodeToASetCommand(Stream=self.stream.handle,
                                        ParentName='{}.avpOptions'.format(self.name),
                                        NodeName='{}AvpOption'.format(x)).execute()
        return True

    def edit_general_tlv_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'attributeValue']:
                self.update("{}.avpOptions.avpOption_{}.generalTLV.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.generalTLV.{}".format(Index, k)})
        return result

    def edit_message_type_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'messageType']:
                self.update("{}.avpOptions.avpOption_{}.messageTypeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.messageTypeAvpOption.{}".format(Index, k)})
        return result

    def edit_result_code_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'resultCode']:
                self.update("{}.avpOptions.avpOption_{}.resultCodeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.resultCodeAvpOption.{}".format(Index, k)})
            elif k == 'errorCode':
                self.update("{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorCode.errorCode_0.value={}".format(self.name, Index, v))
                result.update({(k[:1].upper()+k[1:]): f'avpOptions.avpOption_{Index}.resultCodeAvpOption.errorCode.errorCode_0.value'})
            elif k == 'errorMessage':
                self.update("{}.avpOptions.avpOption_{}.resultCodeAvpOption.errorMessage.errorMessage_0.value={}".format(self.name, Index, v))
                result.update({(k[:1].upper()+k[1:]): f'avpOptions.avpOption_{Index}.resultCodeAvpOption.errorMessage.errorMessage_0.value'})
        return result

    def edit_tie_breaker_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'tieBreakerValue']:
                self.update("{}.avpOptions.avpOption_{}.tieBreakerAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.tieBreakerAvpOption.{}".format(Index, k)})
        return result

    def edit_receive_windowsize_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'windowSize']:
                self.update("{}.avpOptions.avpOption_{}.receiveWindowSizeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.receiveWindowSizeAvpOption.{}".format(Index, k)})
        return result

    def edit_call_serialnumber_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'callSerialNumber']:
                self.update("{}.avpOptions.avpOption_{}.callSerialNumberAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.callSerialNumberAvpOption.{}".format(Index, k)})
        return result

    def edit_physical_channelid_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'physicalChannelId']:
                self.update("{}.avpOptions.avpOption_{}.physicalChannelIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.physicalChannelIdAvpOption.{}".format(Index, k)})
        return result

    def edit_circuit_error_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'reserved1', 'hardwareOverruns', 'bufferOverruns',
                     'timeoutOverruns', 'alignmentOverruns']:
                self.update("{}.avpOptions.avpOption_{}.circuitErrorAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.circuitErrorAvpOption.{}".format(Index, k)})
        return result

    def edit_routeid_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'routeId']:
                self.update("{}.avpOptions.avpOption_{}.routeIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.routeIdAvpOption.{}".format(Index, k)})
        return result

    def edit_assigned_connection_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'connectionId']:
                self.update("{}.avpOptions.avpOption_{}.assignedConnectionAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.assignedConnectionAvpOption.{}".format(Index, k)})
        return result

    def edit_local_sessionid_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'sessionId']:
                self.update("{}.avpOptions.avpOption_{}.localSessionIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.localSessionIdAvpOption.{}".format(Index, k)})
        return result

    def edit_remote_sessionid_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'sessionId']:
                self.update("{}.avpOptions.avpOption_{}.remoteSessionIdAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.remoteSessionIdAvpOption.{}".format(Index, k)})
        return result

    def edit_assigned_cookie_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type']:
                self.update("{}.avpOptions.avpOption_{}.assignedCookieAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.assignedCookieAvpOption.{}".format(Index, k)})
            elif k in ['cookie4Byte', 'cookie8Byte']:
                self.update("{}.avpOptions.avpOption_{}.assignedCookieAvpOption.assignedCookie.cookie_0.{}.value={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.assignedCookieAvpOption.assignedCookie.cookie_0.{}.value".format(Index, k)})
        return result

    def edit_pw_type_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'pwType']:
                self.update("{}.avpOptions.avpOption_{}.pwTypeAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.pwTypeAvpOption.{}".format(Index, k)})
        return result

    def edit_l2_specificsub_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'l2SpecificSublayer']:
                self.update("{}.avpOptions.avpOption_{}.l2SpecificSubAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.l2SpecificSubAvpOption.{}".format(Index, k)})
        return result

    def edit_data_sequencing_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'dataSequencing']:
                self.update("{}.avpOptions.avpOption_{}.dataSequencingAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.dataSequencingAvpOption.{}".format(Index, k)})
        return result

    def edit_tx_connectspeed_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'speedBps']:
                self.update("{}.avpOptions.avpOption_{}.txConnectSpeedAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.txConnectSpeedAvpOption.{}".format(Index, k)})
        return result

    def edit_rx_connectspeed_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'speedBps']:
                self.update("{}.avpOptions.avpOption_{}.rxConnectSpeedAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.rxConnectSpeedAvpOption.{}".format(Index, k)})
        return result

    def edit_circuit_status_avpoption_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['mbit', 'hbit', 'reserved', 'length', 'vendorId', 'type', 'reserved1', 'nbit', 'abit']:
                self.update("{}.avpOptions.avpOption_{}.circuitStatusAvpOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "avpOptions.avpOption_{}.circuitStatusAvpOption.{}".format(Index, k)})
        return result















from .header_base import *

file_path = SCHEMA_PATH + "GreTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("gre")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class GreHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("gre")
        self.__checksumPresent = paramDict["checksumPresent"]
        self.__routing = paramDict["routing"]
        self.__keyPresent = paramDict["keyPresent"]
        self.__sequenceNumberPresent = paramDict["sequenceNumberPresent"]
        self.__reserved = paramDict["reserved"]
        self.__version = paramDict["version"]
        self.__protocol = paramDict["protocol"]
        self.__enableKeepAlive = paramDict["enableKeepAlive"]
        self.__keepAlivePeriod = paramDict["keepAlivePeriod"]
        self.__keepAliveRetries = paramDict["keepAliveRetries"]
        self.__key = None
        self.__checksum = {}
        self.__sequenceNumber = None

    @property
    def checksumPresent(self):
        return self.__checksumPresent

    @checksumPresent.setter
    def checksumPresent(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__checksumPresent = Value

    @property
    def routing(self):
        return self.__routing

    @routing.setter
    def routing(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__routing = Value

    @property
    def keyPresent(self):
        return self.__keyPresent

    @keyPresent.setter
    def keyPresent(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__keyPresent = Value

    @property
    def sequenceNumberPresent(self):
        return self.__sequenceNumberPresent

    @sequenceNumberPresent.setter
    def sequenceNumberPresent(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sequenceNumberPresent = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__version = Value

    @property
    def protocol(self):
        return self.__protocol

    @protocol.setter
    def protocol(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__protocol = Value

    @property
    def enableKeepAlive(self):
        return self.__enableKeepAlive

    @enableKeepAlive.setter
    def enableKeepAlive(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__enableKeepAlive = Value

    @property
    def keepAlivePeriod(self):
        return self.__keepAlivePeriod

    @keepAlivePeriod.setter
    def keepAlivePeriod(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__keepAlivePeriod = Value

    @property
    def keepAliveRetries(self):
        return self.__keepAliveRetries

    @keepAliveRetries.setter
    def keepAliveRetries(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__keepAliveRetries = Value

    @property
    def checksum(self):
        return self.__checksum

    def insert_gre_checksum(self, checksum=None, reserved=None):
        if self.__checksum == {}:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.checksum'.format(self.name),
                                    NodeName='GreChecksum').execute()
        if checksum is not None:
            self.__checksum.update({'checksum': checksum})
        if reserved is not None:
            self.__checksum.update({'reserved': reserved})

        self.edit_gre_checksum(checksum=checksum, reserved=reserved)
        return True

    def edit_gre_checksum(self, checksum=None, reserved=None):
        if checksum is not None:
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.checksum.GreChecksum_0.checksum={}".format(self.name, checksum)).execute()
        if reserved is not None:
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.checksum.GreChecksum_0.reserved={}".format(self.name, reserved)).execute()
        return True

    @property
    def key(self):
        return self.__key

    def insert_gre_key(self, key):
        if self.__key is None:
            self.__key = key
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.key'.format(self.name),
                                    NodeName='GreKey').execute()
        self.edit_gre_key(key=key)
        return True

    def edit_gre_key(self, key=None):
        if key is not None:
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.key.GreKey_0.key={}".format(self.name, key)).execute()
        return True

    @property
    def sequenceNumber(self):
        return self.__sequenceNumber

    def insert_gre_sequenceNumber(self, sequenceNumber):
        self.__sequenceNumber = sequenceNumber
        if self.__sequenceNumber is not None:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.sequenceNumber'.format(self.name),
                                    NodeName='GreSequenceNumber').execute()
            self.edit_gre_sequenceNumber(sequenceNumber=sequenceNumber)
        return True

    def edit_gre_sequenceNumber(self, sequenceNumber=None):
        if sequenceNumber is not None:
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.sequenceNumber.GreSequenceNumber_0.sequenceNumber={}".format(
                                    self.name, sequenceNumber)).execute()
        return True

from .header_base import *

file_path = SCHEMA_PATH + "PfcTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("pfc")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class PfcHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("pfc")
        self.__opCode = paramDict["opCode"]
        self.__msOctet = '00000000'
        self.__p7 = 0
        self.__p6 = 0
        self.__p5 = 0
        self.__p4 = 0
        self.__p3 = 0
        self.__p2 = 0
        self.__p1 = 0
        self.__p0 = 0
        self.__time0 = paramDict["time0"]
        self.__time1 = paramDict["time1"]
        self.__time2 = paramDict["time2"]
        self.__time3 = paramDict["time3"]
        self.__time4 = paramDict["time4"]
        self.__time5 = paramDict["time5"]
        self.__time6 = paramDict["time6"]
        self.__time7 = paramDict["time7"]

    @property
    def opCode(self):
        return self.__opCode

    @opCode.setter
    def opCode(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__opCode = Value

    @property
    def msOctet(self):
        return self.__msOctet

    @msOctet.setter
    def msOctet(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__msOctet = Value

    @property
    def p7(self):
        return self.__p7

    @p7.setter
    def p7(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p7 = Value

    @property
    def p6(self):
        return self.__p6

    @p6.setter
    def p6(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p6 = Value

    @property
    def p5(self):
        return self.__p5

    @p5.setter
    def p5(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p5 = Value

    @property
    def p4(self):
        return self.__p4

    @p4.setter
    def p4(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p4 = Value

    @property
    def p3(self):
        return self.__p3

    @p3.setter
    def p3(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p3 = Value

    @property
    def p2(self):
        return self.__p2

    @p2.setter
    def p2(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p2 = Value

    @property
    def p1(self):
        return self.__p1

    @p1.setter
    def p1(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p1 = Value

    @property
    def p0(self):
        return self.__p0

    @p0.setter
    def p0(self, Value):
        self.update('{}.priorityEnableVector.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__p0 = Value

    @property
    def time0(self):
        return self.__time0

    @time0.setter
    def time0(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time0 = Value

    @property
    def time1(self):
        return self.__time1

    @time1.setter
    def time1(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time1 = Value

    @property
    def time2(self):
        return self.__time2

    @time2.setter
    def time2(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time2 = Value

    @property
    def time3(self):
        return self.__time3

    @time3.setter
    def time3(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time3 = Value

    @property
    def time4(self):
        return self.__time4

    @time4.setter
    def time4(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time4 = Value

    @property
    def time5(self):
        return self.__time5

    @time5.setter
    def time5(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time5 = Value

    @property
    def time6(self):
        return self.__time6

    @time6.setter
    def time6(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time6 = Value

    @property
    def time7(self):
        return self.__time7

    @time7.setter
    def time7(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__time7 = Value



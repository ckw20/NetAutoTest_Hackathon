from .header_base import *

file_path = SCHEMA_PATH + "Ipv6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ipv6SrHeader")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ipv6SrHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ipv6SrHeader")
        self.__nextHeader = paramDict["nextHeader"]
        self.__length = paramDict["length"]
        self.__routingType = paramDict["routingType"]
        self.__segLeft = paramDict["segLeft"]
        self.__lastEntry = paramDict["lastEntry"]
        self.__sRHeaderFlag = paramDict["sRHeaderFlag"]
        self.__tag = paramDict["tag"]
        self.__sRHOption = []

    @property
    def nextHeader(self):
        return self.__nextHeader

    @nextHeader.setter
    def nextHeader(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nextHeader = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def routingType(self):
        return self.__routingType

    @routingType.setter
    def routingType(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__routingType = Value

    @property
    def segLeft(self):
        return self.__segLeft

    @segLeft.setter
    def segLeft(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__segLeft = Value

    @property
    def lastEntry(self):
        return self.__lastEntry

    @lastEntry.setter
    def lastEntry(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lastEntry = Value

    @property
    def sRHeaderFlag(self):
        return self.__sRHeaderFlag

    @sRHeaderFlag.setter
    def sRHeaderFlag(self, Value):
        self.update('{}.{}.unusedFlags={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sRHeaderFlag = Value

    @property
    def tag(self):
        return self.__tag

    @tag.setter
    def tag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__tag = Value

    @property
    def sRHOption(self):
        return self.__sRHOption

    @sRHOption.setter
    def sRHOption(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.sRHOption'.format(self.name),
                                    NodeName='{}'.format(x)).execute()
        self.__sRHOption = Value

    def edit_segment(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['segment']:
                self.update("{}.sRHOption.sRHOptionList_{}.sRSegment.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.sRSegment.{}".format(Index, k_)})
        return result

    def edit_ingress_node_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['type', 'length', 'reserved', 'flags', 'ingressNode']:
                self.update("{}.sRHOption.sRHOptionList_{}.sRIngressNodeTlv.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.sRIngressNodeTlv.{}".format(Index, k_)})
        return result

    def edit_egress_node_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['type', 'length', 'reserved', 'flags', 'engressNode']:
                self.update("{}.sRHOption.sRHOptionList_{}.sREgressNodeTlv.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.sREgressNodeTlv.{}".format(Index, k_)})
        return result

    def edit_opaque_container_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['type', 'length', 'reserved', 'flags', 'opaqueContainer']:
                self.update("{}.sRHOption.sRHOptionList_{}.sROpaqueContainerTlv.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.sROpaqueContainerTlv.{}".format(Index, k_)})
        return result

    def edit_srh_mac_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['type', 'length', 'reserved', 'hmacKeyId', 'hmac']:
                self.update("{}.sRHOption.sRHOptionList_{}.sRHmacTlv.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.sRHmacTlv.{}".format(Index, k_)})
        return result

    def edit_sr_padding1_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['type']:
                self.update("{}.sRHOption.sRHOptionList_{}.sRPadding1Tlv.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.sRPadding1Tlv.{}".format(Index, k_)})
        return result

    def edit_sr_padding_tlv(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['type', 'length', 'padding']:
                self.update("{}.sRHOption.sRHOptionList_{}.sRPaddingTlv.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.sRPaddingTlv.{}".format(Index, k_)})
        return result

    def edit_custom_option(self, Index, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k_ in ['type', 'length', 'data']:
                self.update("{}.sRHOption.sRHOptionList_{}.generalTLV.{}={}".format(self.name, Index, k_, v))
                result.update({k: "sRHOption.sRHOptionList_{}.generalTLV.{}".format(Index, k_)})
        return result

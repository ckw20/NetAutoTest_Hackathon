from .header_base import *

file_path = SCHEMA_PATH + "VlanTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("vlan")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class VlanHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("vlan")
        self.__priority = paramDict["priority"]
        self.__cfi = paramDict["cfi"]
        self.__id = paramDict["id"]
        self.__protocol = paramDict["protocol"]

    @property
    def priority(self):
        return self.__priority

    @priority.setter
    def priority(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__priority = Value

    @property
    def cfi(self):
        return self.__cfi

    @cfi.setter
    def cfi(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, str(Value))).execute()
        self.__cfi = Value

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__id = Value

    @property
    def protocol(self):
        return self.__protocol

    @protocol.setter
    def protocol(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__protocol = Value


if __name__ == '__main__':
    object_ = VlanHeader()
    print(object_)
    print(VlanHeader.priority)
    print(VlanHeader.cfi)
    print(VlanHeader.id)
    object_ = VlanHeader(priority=8, cfi=8, id=10)
    print(object_.priority)
    print(object_.cfi)
    print(object_.id)

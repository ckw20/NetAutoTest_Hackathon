from .header_base import *

file_path = SCHEMA_PATH + "Gtpv1ExtTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("gtpv1Ext")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Gtpv1OptionalExtensionHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("gtpv1Ext")
        self.__sequence = paramDict["sequence"]
        self.__nPDUNumber = paramDict["nPDUNumber"]
        self.__nextHeaderType1 = paramDict["nextHeaderType"]
        self.__length = paramDict["length"]
        self.__bytePattern = paramDict["bytePattern"]
        self.__nextHeaderType2 = paramDict["nextHeaderType2"]

    @property
    def sequence(self):
        return self.__sequence

    @sequence.setter
    def sequence(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sequence = Value

    @property
    def nPDUNumber(self):
        return self.__nPDUNumber

    @nPDUNumber.setter
    def nPDUNumber(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nPDUNumber = Value

    @property
    def nextHeaderType1(self):
        return self.__nextHeaderType1

    @nextHeaderType1.setter
    def nextHeaderType1(self, Value):
        self.update('{}.nextHeaderType={} '.format(self.name, Value))
        self.__nextHeaderType1 = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def bytePattern(self):
        return self.__bytePattern

    @bytePattern.setter
    def bytePattern(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__bytePattern = Value

    @property
    def nextHeaderType2(self):
        return self.__nextHeaderType2

    @nextHeaderType2.setter
    def nextHeaderType2(self, Value):
        # TBD csr-9238
        self.update('{}.nextHeaderType={} '.format(self.name, Value))
        self.__nextHeaderType2 = Value


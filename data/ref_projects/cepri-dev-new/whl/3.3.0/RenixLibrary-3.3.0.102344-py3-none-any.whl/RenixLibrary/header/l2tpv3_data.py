from .header_base import *

class L2tpv3Data(HeaderBase):

    def __init__(self, Upper, **kwargs):
        super(L2tpv3Data, self).__init__(self, Upper=Upper, **kwargs)

    @property
    def sessionId(self):
        return self.__sessionId

    @sessionId.setter
    def sessionId(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sessionId = Value

    @property
    def cookie4Byte(self):
        return self.__cookie4Byte

    @cookie4Byte.setter
    def cookie4Byte(self, Value):
        self.update('{}.cookieData.cookie_0.{}.value={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__cookie4Byte = Value

    @property
    def cookie8Byte(self):
        return self.__cookie8Byte

    @cookie8Byte.setter
    def cookie8Byte(self, Value):
        self.update('{}.cookieData.cookie_0.{}.value={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__cookie8Byte = Value

    @property
    def l2specificsublayer(self):
        return self.__l2specificsublayer

    @l2specificsublayer.setter
    def l2specificsublayer(self, Value):
        if Value == 0:
            # TBD delete node
            pass
        self.__l2specificsublayer = Value

    @property
    def atmspecificsublayer(self):
        return self.__atmspecificsublayer

    @atmspecificsublayer.setter
    def atmspecificsublayer(self, Value):
        if Value == 0:
            # TBD delete node
            pass
        self.__atmspecificsublayer = Value

    def edit_specific_sublayer(self, Type, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if Type == 'L2specificsublayer':
                if k in ['xbit', 'sbit', 'xbits', 'sequence']:
                    self.update('{}.l2SpecificSublayer.l2-SpecificSublayerList_0.l2-SpecificSublayerOption.{}={}'.format(self.name, k, v))
                    result.update({(k[:1].upper() + k[1:]): f"l2SpecificSublayer.l2-SpecificSublayerList_0.l2-SpecificSublayerOption.{k}"})
            elif Type == 'Atmspecificsublayer':
                if k in ['xbit', 'sbit', 'bbit', 'ebit', 'tbit', 'gbit', 'cbit', 'ubit', 'sequence']:
                    self.update('{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.{}={}'.format(self.name, k, v))
                    result.update({(k[:1].upper() + k[1:]): f"l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.{k}"})
        return result
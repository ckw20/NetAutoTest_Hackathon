from .l2tpv3_data import *

file_path = SCHEMA_PATH + "L2tpv3Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("l2tpv3DataOverIp")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class l2tpv3DataOverIpHeader(L2tpv3Data):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("l2tpv3DataOverIp")
        self.__sessionId = paramDict["sessionId"]
        self.__cookie4Byte = None
        self.__cookie8Byte = None
        self.__l2specificsublayer = 0
        self.__atmspecificsublayer = 0

    # @property
    # def sessionId(self):
    #     return self.__sessionId
    #
    # @sessionId.setter
    # def sessionId(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__sessionId = Value
    #
    # @property
    # def cookie4Byte(self):
    #     return self.__cookie4Byte
    #
    # def insert_cookie_4byte(self, cookie4Byte):
    #     if self.__cookie4Byte is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.cookieData'.format(
    #                                     self.name),
    #                                 NodeName='cookie4Byte').execute()
    #     self.edit_cookie_4byte(cookie4Byte=cookie4Byte)
    #     return True
    #
    # def edit_cookie_4byte(self, cookie4Byte=None):
    #     if cookie4Byte is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.cookieData.cookie_0.cookie4Byte.value={}".format(
    #                                 self.name, cookie4Byte)).execute()
    #     self.__cookie4Byte = cookie4Byte
    #     return True
    #
    # @property
    # def cookie8Byte(self):
    #     return self.__cookie8Byte
    #
    # def insert_cookie_8byte(self, cookie8Byte):
    #     if self.__cookie8Byte is None:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.cookieData'.format(
    #                                     self.name),
    #                                 NodeName='cookie8Byte').execute()
    #     self.edit_cookie_8byte(cookie8Byte=cookie8Byte)
    #     return True
    #
    # def edit_cookie_8byte(self, cookie8Byte=None):
    #     if cookie8Byte is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.cookieData.cookie_0.cookie8Byte.value={}".format(
    #                                 self.name, cookie8Byte)).execute()
    #     self.__cookie8Byte = cookie8Byte
    #     return True
    #
    # @property
    # def l2specificsublayer(self):
    #     return self.__l2specificsublayer
    #
    # def insert_l2_specificsublayer_option(self, xbit=None, sbit=None, xbits=None, sequence=None):
    #     if self.__l2specificsublayer == {}:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.l2SpecificSublayer'.format(self.name),
    #                                 NodeName='l2-SpecificSublayerOption').execute()
    #     if xbit is not None:
    #         self.__l2specificsublayer.update({'xbit': xbit})
    #     if sbit is not None:
    #         self.__l2specificsublayer.update({'sbit': sbit})
    #     if xbits is not None:
    #         self.__l2specificsublayer.update({'xbits': xbits})
    #     if sequence is not None:
    #         self.__l2specificsublayer.update({'sequence': sequence})
    #
    #     self.edit_l2_specificsublayer_option(xbit=xbit, sbit=sbit, xbits=xbits, sequence=sequence)
    #     return True
    #
    # def edit_l2_specificsublayer_option(self, xbit=None, sbit=None, xbits=None, sequence=None):
    #     if xbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.l2-SpecificSublayerOption.xbit={}".format(
    #                                 self.name, xbit)).execute()
    #     if sbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.l2-SpecificSublayerOption.sbit={}".format(
    #                                 self.name, sbit)).execute()
    #     if xbits is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.l2-SpecificSublayerOption.xbits={}".format(
    #                                 self.name, xbits)).execute()
    #     if sequence is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.l2-SpecificSublayerOption.sequence={}".format(
    #                                 self.name, sequence)).execute()
    #     return True
    #
    # @property
    # def atmspecificsublayer(self):
    #     return self.__atmspecificsublayer
    #
    # def insert_atm_specificsublayer_option(self, xbit=None, sbit=None, bbit=None, ebit=None, tbit=None, gbit=None,
    #                                        cbit=None, ubit=None, sequence=None):
    #     if self.__atmspecificsublayer == {}:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.l2SpecificSublayer'.format(self.name),
    #                                 NodeName='atm-SpecificSublayerOption').execute()
    #     if xbit is not None:
    #         self.__atmspecificsublayer.update({'xbit': xbit})
    #     if sbit is not None:
    #         self.__atmspecificsublayer.update({'sbit': sbit})
    #     if bbit is not None:
    #         self.__atmspecificsublayer.update({'bbit': bbit})
    #     if ebit is not None:
    #         self.__atmspecificsublayer.update({'ebit': ebit})
    #     if tbit is not None:
    #         self.__atmspecificsublayer.update({'tbit': tbit})
    #     if gbit is not None:
    #         self.__atmspecificsublayer.update({'gbit': gbit})
    #     if cbit is not None:
    #         self.__atmspecificsublayer.update({'cbit': cbit})
    #     if ubit is not None:
    #         self.__atmspecificsublayer.update({'ubit': ubit})
    #     if sequence is not None:
    #         self.__atmspecificsublayer.update({'sequence': sequence})
    #
    #     self.edit_atm_specificsublayer_option(xbit=xbit, sbit=sbit, bbit=bbit, ebit=ebit, tbit=tbit, gbit=gbit,
    #                                           cbit=cbit,
    #                                           ubit=ubit, sequence=sequence)
    #     return True
    #
    # def edit_atm_specificsublayer_option(self, xbit=None, sbit=None, bbit=None, ebit=None, tbit=None, gbit=None,
    #                                      cbit=None, ubit=None, sequence=None):
    #     if xbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.xbit={}".format(
    #                                 self.name, xbit)).execute()
    #     if sbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.sbit={}".format(
    #                                 self.name, sbit)).execute()
    #     if bbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.bbit={}".format(
    #                                 self.name, bbit)).execute()
    #     if ebit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.ebit={}".format(
    #                                 self.name, ebit)).execute()
    #     if tbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.tbit={}".format(
    #                                 self.name, tbit)).execute()
    #     if gbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.gbit={}".format(
    #                                 self.name, gbit)).execute()
    #     if cbit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.cbit={}".format(
    #                                 self.name, cbit)).execute()
    #     if ubit is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.ubit={}".format(
    #                                 self.name, ubit)).execute()
    #     if sequence is not None:
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.sequence={}".format(
    #                                 self.name, sequence)).execute()
    #     return True

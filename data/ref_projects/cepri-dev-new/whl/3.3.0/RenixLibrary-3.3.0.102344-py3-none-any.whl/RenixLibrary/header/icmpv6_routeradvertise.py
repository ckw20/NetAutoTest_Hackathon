from .header_base import *

file_path = SCHEMA_PATH + "IcmpV6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("routerAdvertise")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Icmpv6RouterAdvertiseHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("routerAdvertise")
        self.__type = paramDict["type"]
        self.__code = paramDict["code"]
        self.__checksum = paramDict["checksum"]
        self.__curHopLimit = paramDict["curHopLimit"]
        self.__managedAddrFlag = paramDict["managedAddrFlag"]
        self.__otherConfigFlag = paramDict["otherConfigFlag"]
        self.__reserved = paramDict["reserved"]
        self.__routerLifetime = paramDict["routerLifetime"]
        self.__reachableTime = paramDict["reachableTime"]
        self.__retransTime = paramDict["retransTime"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def code(self):
        return self.__code

    @code.setter
    def code(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__code = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def curHopLimit(self):
        return self.__curHopLimit

    @curHopLimit.setter
    def curHopLimit(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__curHopLimit = Value

    @property
    def managedAddrFlag(self):
        return self.__managedAddrFlag

    @managedAddrFlag.setter
    def managedAddrFlag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__managedAddrFlag = Value

    @property
    def otherConfigFlag(self):
        return self.__otherConfigFlag

    @otherConfigFlag.setter
    def otherConfigFlag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__otherConfigFlag = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved = Value

    @property
    def routerLifetime(self):
        return self.__routerLifetime

    @routerLifetime.setter
    def routerLifetime(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__routerLifetime = Value

    @property
    def reachableTime(self):
        return self.__reachableTime

    @reachableTime.setter
    def reachableTime(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reachableTime = Value

    @property
    def retransTime(self):
        return self.__retransTime

    @retransTime.setter
    def retransTime(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__retransTime = Value

    # Option:
    # optionSourceLinkLayerAddress
    # optionTargetLinkLayerAddress
    # optionPrefixInformation
    # optionMTU
    # generalTLV
    # generalWildcardTLV
    def insertHeaderOption(self, Option):
        for i in Option:
            i = i[:1].lower()+i[1:]
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.option'.format(self.name),
                                    NodeName=i).execute()

    def getHeaderOption(self, Option, Field, Index=0):
        Option = Option[:1].lower() + Option[1:]
        return self.get_value('{}.option.icmpv6HeaderOptionList_{}.{}.{}'.format(self.name, Index, Option, Field))

    def editHeaderOption(self, Option, Index=0, **kwargs):
        result = {}
        Option = Option[:1].lower() + Option[1:]
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            self.update('{}.option.icmpv6HeaderOptionList_{}.{}.{}={}'.format(self.name, Index, Option, k_, v))
            result.update({k: f'option.icmpv6HeaderOptionList_{Index}.{Option}.{k_}'})
        return result
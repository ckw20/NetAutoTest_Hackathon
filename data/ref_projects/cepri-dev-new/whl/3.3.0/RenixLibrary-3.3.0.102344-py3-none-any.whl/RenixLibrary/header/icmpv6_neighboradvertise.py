from .header_base import *

file_path = SCHEMA_PATH + "IcmpV6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("neighborAdvertise")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Icmpv6NeighborAdvertiseHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("neighborAdvertise")
        self.__type = paramDict["type"]
        self.__code = paramDict["code"]
        self.__checksum = paramDict["checksum"]
        self.__rFlag = paramDict["rFlag"]
        self.__sFlag = paramDict["sFlag"]
        self.__oFlag = paramDict["oFlag"]
        self.__reserve = paramDict["reserve"]
        self.__targetAddress = paramDict["targetAddress"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def code(self):
        return self.__code

    @code.setter
    def code(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__code = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def rFlag(self):
        return self.__rFlag

    @rFlag.setter
    def rFlag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__rFlag = Value

    @property
    def sFlag(self):
        return self.__sFlag

    @sFlag.setter
    def sFlag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sFlag = Value

    @property
    def oFlag(self):
        return self.__oFlag

    @oFlag.setter
    def oFlag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__oFlag = Value

    @property
    def reserve(self):
        return self.__reserve

    @reserve.setter
    def reserve(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserve = Value

    @property
    def targetAddress(self):
        return self.__targetAddress

    @targetAddress.setter
    def targetAddress(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__targetAddress = Value

    # Option:
    # optionSourceLinkLayerAddress
    # optionTargetLinkLayerAddress
    # optionPrefixInformation
    # optionMTU
    # generalTLV
    # generalWildcardTLV
    def insertHeaderOption(self, Option):
        for i in Option:
            i = i[:1].lower()+i[1:]
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.option'.format(self.name),
                                    NodeName=i).execute()

    def getHeaderOption(self, Option, Field, Index=0):
        Option = Option[:1].lower() + Option[1:]
        return self.get_value('{}.option.icmpv6HeaderOptionList_{}.{}.{}'.format(self.name, Index, Option, Field))

    def editHeaderOption(self, Option, Index=0, **kwargs):
        result = {}
        Option = Option[:1].lower() + Option[1:]
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            self.update('{}.option.icmpv6HeaderOptionList_{}.{}.{}={}'.format(self.name, Index, Option, k_, v))
            result.update({k: f'option.icmpv6HeaderOptionList_{Index}.{Option}.{k_}'})
        return result
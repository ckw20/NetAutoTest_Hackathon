from .header_base import *

file_path = SCHEMA_PATH + "FcoeTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("elsFLOGI")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class FcoeHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("elsFLOGI")
        self.__commandCode = paramDict["commandCode"]
        self.__fcPhVersion = '2020'
        self.__btobCredit = '1'
        self.__commonFeatures = '0000'
        self.__bbscn = '0'
        self.__btobDataFieldSize = '0'
        self.__reserved = '0'
        self.__portName = paramDict["portName"]
        self.__nodeName = paramDict["nodeName"]
        self.__class1serviceOptions = self.__class2serviceOptions = self.__class3serviceOptions = '0000'
        self.__class1InitatorControl = self.__class2InitatorControl = self.__class3InitatorControl = '0000'
        self.__class1recipientControl = self.__class2recipientControl = self.__class3recipientControl = '0000'
        self.__class1reserved1 = self.__class2reserved1 = self.__class3reserved1 = '0'
        self.__class1totalConcurrentSeq = self.__class2totalConcurrentSeq = self.__class3totalConcurrentSeq = '0'
        self.__class1Nx_Porte2eCredit = self.__class2Nx_Porte2eCredit = self.__class3Nx_Porte2eCredit = '0'
        self.__class1reserved2 = self.__class2reserved2 = self.__class3reserved2 = '0'
        self.__class1openSeqPerExchange = self.__class2openSeqPerExchange = self.__class3openSeqPerExchange = '0'
        self.__class1reserved3 = self.__class2reserved3 = self.__class3reserved3 = '0'
        self.__obsolete = paramDict["obsolete"]
        self.__vendorVersionLevel = paramDict["vendorVersionLevel"]

    @property
    def commandCode(self):
        return self.__commandCode

    @commandCode.setter
    def commandCode(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__commandCode = Value

    @property
    def fcPhVersion(self):
        return self.__fcPhVersion

    @fcPhVersion.setter
    def fcPhVersion(self, Value):
        self.update('{}.commonSvcPara.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__fcPhVersion = Value

    @property
    def btobCredit(self):
        return self.__btobCredit

    @btobCredit.setter
    def btobCredit(self, Value):
        self.update('{}.commonSvcPara.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__btobCredit = Value

    @property
    def commonFeatures(self):
        return self.__commonFeatures

    @commonFeatures.setter
    def commonFeatures(self, Value):
        self.update('{}.commonSvcPara.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__commonFeatures = Value

    @property
    def bbscn(self):
        return self.__bbscn

    @bbscn.setter
    def bbscn(self, Value):
        self.update('{}.commonSvcPara.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__bbscn = Value

    @property
    def btobDataFieldSize(self):
        return self.__btobDataFieldSize

    @btobDataFieldSize.setter
    def btobDataFieldSize(self, Value):
        self.update('{}.commonSvcPara.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__btobDataFieldSize = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.commonSvcPara.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved = Value

    @property
    def portName(self):
        return self.__portName

    @portName.setter
    def portName(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__portName = Value

    @property
    def nodeName(self):
        return self.__nodeName

    @nodeName.setter
    def nodeName(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__nodeName = Value

    @property
    def class1serviceOptions(self):
        return self.__class1serviceOptions

    @class1serviceOptions.setter
    def class1serviceOptions(self, Value):
        self.update('{}.class1SvcPara.serviceOptions={} '.format(self.name, Value))
        self.__class1serviceOptions = Value

    @property
    def class1InitatorControl(self):
        return self.__class1InitatorControl

    @class1InitatorControl.setter
    def class1InitatorControl(self, Value):
        self.update('{}.class1SvcPara.InitatorControl={} '.format(self.name, Value))
        self.__class1InitatorControl = Value

    @property
    def class1recipientControl(self):
        return self.__class1recipientControl

    @class1recipientControl.setter
    def class1recipientControl(self, Value):
        self.update('{}.class1SvcPara.recipientControl={} '.format(self.name, Value))
        self.__class1recipientControl = Value

    @property
    def class1reserved1(self):
        return self.__class1reserved1

    @class1reserved1.setter
    def class1reserved1(self, Value):
        self.update('{}.class1SvcPara.reserved1={} '.format(self.name, Value))
        self.__class1reserved1 = Value

    @property
    def class1totalConcurrentSeq(self):
        return self.__class1totalConcurrentSeq

    @class1totalConcurrentSeq.setter
    def class1totalConcurrentSeq(self, Value):
        self.update('{}.class1SvcPara.totalConcurrentSeq={} '.format(self.name, Value))
        self.__class1totalConcurrentSeq = Value

    @property
    def class1Nx_Porte2eCredit(self):
        return self.__class1Nx_Porte2eCredit

    @class1Nx_Porte2eCredit.setter
    def class1Nx_Porte2eCredit(self, Value):
        self.update('{}.class1SvcPara.Nx_Porte2eCredit={} '.format(self.name, Value))
        self.__class1Nx_Porte2eCredit = Value

    @property
    def class1reserved2(self):
        return self.__class1reserved2

    @class1reserved2.setter
    def class1reserved2(self, Value):
        self.update('{}.class1SvcPara.reserved2={} '.format(self.name, Value))
        self.__class1reserved2 = Value

    @property
    def class1openSeqPerExchange(self):
        return self.__class1openSeqPerExchange

    @class1openSeqPerExchange.setter
    def class1openSeqPerExchange(self, Value):
        self.update('{}.class1SvcPara.openSeqPerExchange={} '.format(self.name, Value))
        self.__class1openSeqPerExchange = Value

    @property
    def class1reserved3(self):
        return self.__class1reserved3

    @class1reserved3.setter
    def class1reserved3(self, Value):
        self.update('{}.class1SvcPara.reserved3={} '.format(self.name, Value))
        self.__class1reserved3 = Value

    @property
    def class2serviceOptions(self):
        return self.__class2serviceOptions

    @class2serviceOptions.setter
    def class2serviceOptions(self, Value):
        self.update('{}.class2SvcPara.serviceOptions={} '.format(self.name, Value))
        self.__class2serviceOptions = Value

    @property
    def class2InitatorControl(self):
        return self.__class2InitatorControl

    @class2InitatorControl.setter
    def class2InitatorControl(self, Value):
        self.update('{}.class2SvcPara.InitatorControl={} '.format(self.name, Value))
        self.__class2InitatorControl = Value

    @property
    def class2recipientControl(self):
        return self.__class2recipientControl

    @class2recipientControl.setter
    def class2recipientControl(self, Value):
        self.update('{}.class2SvcPara.recipientControl={} '.format(self.name, Value))
        self.__class2recipientControl = Value

    @property
    def class2reserved1(self):
        return self.__class2reserved1

    @class2reserved1.setter
    def class2reserved1(self, Value):
        self.update('{}.class2SvcPara.reserved1={} '.format(self.name, Value))
        self.__class2reserved1 = Value

    @property
    def class2totalConcurrentSeq(self):
        return self.__class2totalConcurrentSeq

    @class2totalConcurrentSeq.setter
    def class2totalConcurrentSeq(self, Value):
        self.update('{}.class2SvcPara.totalConcurrentSeq={} '.format(self.name, Value))
        self.__class2totalConcurrentSeq = Value

    @property
    def class2Nx_Porte2eCredit(self):
        return self.__class2Nx_Porte2eCredit

    @class2Nx_Porte2eCredit.setter
    def class2Nx_Porte2eCredit(self, Value):
        self.update('{}.class2SvcPara.Nx_Porte2eCredit={} '.format(self.name, Value))
        self.__class2Nx_Porte2eCredit = Value

    @property
    def class2reserved2(self):
        return self.__class2reserved2

    @class2reserved2.setter
    def class2reserved2(self, Value):
        self.update('{}.class2SvcPara.reserved2={} '.format(self.name, Value))
        self.__class2reserved2 = Value

    @property
    def class2openSeqPerExchange(self):
        return self.__class2openSeqPerExchange

    @class2openSeqPerExchange.setter
    def class2openSeqPerExchange(self, Value):
        self.update('{}.class2SvcPara.openSeqPerExchange={} '.format(self.name, Value))
        self.__class2openSeqPerExchange = Value

    @property
    def class2reserved3(self):
        return self.__class2reserved3

    @class2reserved3.setter
    def class2reserved3(self, Value):
        self.update('{}.class2SvcPara.reserved3={} '.format(self.name, Value))
        self.__class2reserved3 = Value

    @property
    def class3serviceOptions(self):
        return self.__class3serviceOptions

    @class3serviceOptions.setter
    def class3serviceOptions(self, Value):
        self.update('{}.class3SvcPara.serviceOptions={} '.format(self.name, Value))
        self.__class3serviceOptions = Value

    @property
    def class3InitatorControl(self):
        return self.__class3InitatorControl

    @class3InitatorControl.setter
    def class3InitatorControl(self, Value):
        self.update('{}.class3SvcPara.InitatorControl={} '.format(self.name, Value))
        self.__class3InitatorControl = Value

    @property
    def class3recipientControl(self):
        return self.__class3recipientControl

    @class3recipientControl.setter
    def class3recipientControl(self, Value):
        self.update('{}.class3SvcPara.recipientControl={} '.format(self.name, Value))
        self.__class3recipientControl = Value

    @property
    def class3reserved1(self):
        return self.__class3reserved1

    @class3reserved1.setter
    def class3reserved1(self, Value):
        self.update('{}.class3SvcPara.reserved1={} '.format(self.name, Value))
        self.__class3reserved1 = Value

    @property
    def class3totalConcurrentSeq(self):
        return self.__class3totalConcurrentSeq

    @class3totalConcurrentSeq.setter
    def class3totalConcurrentSeq(self, Value):
        self.update('{}.class3SvcPara.totalConcurrentSeq={} '.format(self.name, Value))
        self.__class3totalConcurrentSeq = Value

    @property
    def class3Nx_Porte2eCredit(self):
        return self.__class3Nx_Porte2eCredit

    @class3Nx_Porte2eCredit.setter
    def class3Nx_Porte2eCredit(self, Value):
        self.update('{}.class3SvcPara.Nx_Porte2eCredit={} '.format(self.name, Value))
        self.__class3Nx_Porte2eCredit = Value

    @property
    def class3reserved2(self):
        return self.__class3reserved2

    @class3reserved2.setter
    def class3reserved2(self, Value):
        self.update('{}.class3SvcPara.reserved2={} '.format(self.name, Value))
        self.__class3reserved2 = Value

    @property
    def class3openSeqPerExchange(self):
        return self.__class3openSeqPerExchange

    @class3openSeqPerExchange.setter
    def class3openSeqPerExchange(self, Value):
        self.update('{}.class3SvcPara.openSeqPerExchange={} '.format(self.name, Value))
        self.__class3openSeqPerExchange = Value

    @property
    def class3reserved3(self):
        return self.__class3reserved3

    @class3reserved3.setter
    def class3reserved3(self, Value):
        self.update('{}.class3SvcPara.reserved3={} '.format(self.name, Value))
        self.__class3reserved3 = Value

    @property
    def obsolete(self):
        return self.__obsolete

    @obsolete.setter
    def obsolete(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__obsolete = Value

    @property
    def vendorVersionLevel(self):
        return self.__vendorVersionLevel

    @vendorVersionLevel.setter
    def vendorVersionLevel(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__vendorVersionLevel = Value

from .header_base import *

class Dhcpv6(HeaderBase):

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, **kwargs)

    @property
    def messageType(self):
        return self.__messageType

    @messageType.setter
    def messageType(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__messageType = Value

    @property
    def transId(self):
        return self.__transId

    @transId.setter
    def transId(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__transId = Value

    def insert_option_header(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.options'.format(self.name),
                                    NodeName='{}'.format(x)).execute()
        return True

    def edit_client_id_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'duid']:
                self.update("{}.options.Dhcpv6Options_{}.clientIdOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.clientIdOption.{}".format(Index, k)})
        return result

    def edit_server_id_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'duidType', 'hardwareType', 'linkAddress']:
                self.update("{}.options.Dhcpv6Options_{}.serverIdOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.serverIdOption.{}".format(Index, k)})
        return result

    def edit_iana_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'iaid', 't1', 't2']:
                self.update("{}.options.Dhcpv6Options_{}.ianaOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.ianaOption.{}".format(Index, k)})
            elif k == 'iaOption' and v == 0:
                # TBD delete node
                pass
        return result

    def edit_ia_address_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'ipv6Address', 'preferredLifetime', 'validLifetime']:
                self.update("{}.options.Dhcpv6Options_{}.ianaOption.iaOption.Dhcpv6IaAddress_0.{}={} ".format(self.name, Index, k, v))
                result.update({
                    (k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.ianaOption.iaOption.Dhcpv6IaAddress_0.{}".format(Index, k)})
        return result

    def edit_request_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv6Options_{}.requestOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.requestOption.{}".format(Index, k)})
        return result

    def edit_elapsed_time_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'elapseTime']:
                self.update("{}.options.Dhcpv6Options_{}.elapsedTimeOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.elapsedTimeOption.{}".format(Index, k)})
        return result

    def edit_server_unicast_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'serverAddress']:
                self.update("{}.options.Dhcpv6Options_{}.serverUnicastOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.serverUnicastOption.{}".format(Index, k)})
        return result

    def edit_status_code_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'statusCode', 'statusMsg']:
                self.update("{}.options.Dhcpv6Options_{}.statusCodeOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.statusCodeOption.{}".format(Index, k)})
        return result

    def edit_rapid_commit_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length']:
                self.update("{}.options.Dhcpv6Options_{}.rapidCommitOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.rapidCommitOption.{}".format(Index, k)})
        return result

    def edit_interface_id_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'interfaceId']:
                self.update("{}.options.Dhcpv6Options_{}.interfaceIdOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.interfaceIdOption.{}".format(Index, k)})
        return result

    def edit_reconfigure_accept_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length']:
                self.update("{}.options.Dhcpv6Options_{}.reconfigureAcceptOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.reconfigureAcceptOption.{}".format(Index, k)})
        return result

    def edit_iapd_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'iaid', 't1', 't2']:
                self.update("{}.options.Dhcpv6Options_{}.iapdOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.iapdOption.{}".format(Index, k)})
            elif k == 'iaOption' and v == 0:
                # TBD delete node
                pass
        return result

    def edit_ia_prefix_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'preferredLifetime', 'validLifetime', 'prefixLength', 'ipv6Address']:
                self.update("{}.options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_0.{}={} ".format(self.name, Index, k, v))
                result.update({
                    (k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.iapdOption.iaOption.Dhcpv6IaPrefix_0.{}".format(Index, k)})
        return result

    def edit_custom_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv6Options_{}.customOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.customOption.{}".format(Index, k)})
        return result

    def edit_general_tlv(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv6Options_{}.generalTLV.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv6Options_{}.generalTLV.{}".format(Index, k)})
        return result


# from .header_base import *
# from RenixAPI.RenixLibrary.header.ipv4 import *
from .ipv4 import *

file_path = SCHEMA_PATH + "IcmpV4Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("icmpv4Redirect")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Icmpv4RedirectHeader(Ipv4Header):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues, Icmp=True)
        self.update_upper("icmpv4Redirect")
        self.__type = paramDict["type"]
        self.__code = paramDict["code"]
        self.__icmpChecksum = paramDict["checksum"]
        self.__gatewayAddress = paramDict['gatewayAddress']
        self.__headerData = paramDict["headerData"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def code(self):
        return self.__code

    @code.setter
    def code(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__code = Value

    @property
    def icmpChecksum(self):
        return self.__icmpChecksum

    @icmpChecksum.setter
    def icmpChecksum(self, Value):
        self.update('{}.checksum={} '.format(self.name, Value))
        self.__icmpChecksum = Value

    @property
    def gatewayAddress(self):
        return self.__gatewayAddress

    @gatewayAddress.setter
    def gatewayAddress(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__gatewayAddress = Value

    @property
    def headerData(self):
        return self.__headerData

    @headerData.setter
    def headerData(self, Value):
        self.update('{}.{}.data={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__headerData = Value

    def get_icmp_value(self, field):
        if field == 'Type':
            return self.get_value('{}.{}'.format(self.name, 'type'))
        elif field == 'Code':
            return self.get_value('{}.{}'.format(self.name, 'code'))
        elif field == 'Checksum':
            return self.get_value('{}.{}'.format(self.name, 'checksum'))
        elif field == 'GatewayAddress':
            return self.get_value('{}.{}'.format(self.name, 'gatewayAddress'))
        elif field == 'Data':
            return self.get_value('{}.{}'.format(self.name, 'headerData.data'))
        elif field == 'Ipv4HeaderVersion':
            return self.get_ipv4_value('Version')
        elif field == 'Ipv4HeaderHeadLen':
            return self.get_ipv4_value('HeadLen')
        elif field == 'Ipv4HeaderTosPrecedence':
            return self.get_ipv4_value('TosPrecedence')
        elif field == 'Ipv4HeaderTosDelay':
            return self.get_ipv4_value('TosDelay')
        elif field == 'Ipv4HeaderTosThroughput':
            return self.get_ipv4_value('TosThroughtput')
        elif field == 'Ipv4HeaderTosReliability':
            return self.get_ipv4_value('TosReliability')
        elif field == 'Ipv4HeaderTosMonetaryCost':
            return self.get_ipv4_value('TosMonetaryCost')
        elif field == 'Ipv4HeaderTosReserved':
            return self.get_ipv4_value('TosReserved')
        elif field == 'Ipv4HeaderDiffserveDscp':
            return self.get_ipv4_value('DiffserveDscp')
        elif field == 'Ipv4HeaderDiffserveCodePointPrecedence':
            return self.get_ipv4_value('DiffserveCodePointPrecedence')
        elif field == 'Ipv4HeaderDiffserveClassSelectorPrecedence':
            return self.get_ipv4_value('DiffserveClassSelectorPrecedence')
        elif field == 'Ipv4HeaderDiffserveDscpDrop':
            return self.get_ipv4_value('DiffserveClassSelectorDrop')
        elif field == 'Ipv4HeaderDiffserveDscpUndefine':
            return self.get_ipv4_value('DiffserveClassSelectorUndefine')
        elif field == 'Ipv4HeaderDiffserveEcn':
            return self.get_ipv4_value('DiffserveEcn')
        elif field == 'Ipv4HeaderTosByte':
            return self.get_ipv4_value('TosByte')
        elif field == 'Ipv4HeaderTotalLength':
            return self.get_ipv4_value('TotalLength')
        elif field == 'Ipv4HeaderID':
            return self.get_ipv4_value('ID')
        elif field == 'Ipv4HeaderFlags':
            return self.get_ipv4_value('Flags')
        elif field == 'Ipv4HeaderOffset':
            return self.get_ipv4_value('Offset')
        elif field == 'Ipv4HeaderTTL':
            return self.get_ipv4_value('TTL')
        elif field == 'Ipv4HeaderProtocol':
            return self.get_ipv4_value('Protocol')
        elif field == 'Ipv4HeaderChecksum':
            return self.get_ipv4_value('Checksum')
        elif field == 'Ipv4HeaderSource':
            return self.get_ipv4_value('Source')
        elif field == 'Ipv4HeaderDestination':
            return self.get_ipv4_value('Destination')
        elif field == 'Ipv4HeaderHeaderOption':
            return self.get_ipv4_value('ipv4HeaderOption')
        elif field == 'Ipv4HeaderPadding':
            return self.get_ipv4_value('Padding')
        elif field == 'Ipv4HeaderGateway':
            return self.get_ipv4_value('Gateway')
        else:
            return 'Invalid Field!'


if __name__ == '__main__':
    from renix_py_api.renix import *

    # 初始化Renix
    initialize()
    # 修改产品类型
    sys_entry = get_sys_entry()
    sys_entry.ProductType = 'DARYU'
    # 创建端口
    Port_UP = Port(upper=sys_entry)
    # 创建流量
    stream = StreamTemplate(upper=Port_UP)
    object_ = Icmpv4RedirectHeader(Upper=stream)
    print(object_)
    print(Ipv4Header.destination)
    print(Ipv4Header.source)
    print(Ipv4Header.gateway)
    object_ = Ipv4Header(destination="1.1.1.1", source="2.2.2.2", gateway="3.3.3.3")
    print(object_.destination)
    print(object_.source)
    print(object_.gateway)

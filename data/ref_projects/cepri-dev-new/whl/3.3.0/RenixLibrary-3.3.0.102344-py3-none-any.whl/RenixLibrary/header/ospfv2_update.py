from renix_py_api.api_gen import InsertNodeToASetCommand

from .ospfv2 import *

file_path = SCHEMA_PATH + "ospfv2.def.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ospfv2LinkStateUpdate")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Ospfv2LinkStateUpdateHeader(Ospfv2Header):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ospfv2LinkStateUpdate")
        self.__numberOfLsas = paramDict["numberOfLsas"]

    @property
    def numberOfLsas(self):
        return self.__numberOfLsas

    @numberOfLsas.setter
    def numberOfLsas(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__numberOfLsas = Value

    def insert_lsa_header(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.updatedLsas'.format(self.name),
                                    NodeName='ospfv2{}Lsa'.format(x)).execute()
        return True

    def edit_route_lsa_tos_metric(self, LsaIndex, MetricIndex, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'routerLsaLinkType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaTosMetrics.ospfv2RouterLsaTosMetric_{}.routerLsaLinkType={} ".format(
                                    self.name, LsaIndex, MetricIndex, Index, kwargs['routerLsaLinkType'])).execute()
            result.update({'RouterLsaLinkType':
                           'updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaTosMetrics.ospfv2RouterLsaTosMetric_{}.routerLsaLinkType'.format(
                               LsaIndex, MetricIndex, Index)})
        if 'routerLsaMetricReserved' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaTosMetrics.ospfv2RouterLsaTosMetric_{}.routerLsaMetricReserved={} ".format(
                                    self.name, LsaIndex, MetricIndex, Index,
                                    kwargs['routerLsaMetricReserved'])).execute()
            result.update({'RouterLsaMetricReserved':
                            'updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaTosMetrics.ospfv2RouterLsaTosMetric_{}.routerLsaMetricReserved'.format(
                                LsaIndex, MetricIndex, Index)})
        if 'routerTosLinkMetrics' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaTosMetrics.ospfv2RouterLsaTosMetric_{}.routerTosLinkMetrics={} ".format(
                                    self.name, LsaIndex, MetricIndex, Index, kwargs['routerTosLinkMetrics'])).execute()
            result.update({'RouterTosLinkMetrics':
                            'updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaTosMetrics.ospfv2RouterLsaTosMetric_{}.routerTosLinkMetrics'.format(
                                LsaIndex, MetricIndex, Index)})
        return result

    def edit_route_lsa_link(self, LsaIndex, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'routerLsaTosMetricsCount' in set(kwargs.keys()):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaTosMetrics'.format(
                                        self.name, LsaIndex, Index),
                                    NodeName='ospfv2RouterLsaTosMetric',
                                    NodeCount=int(kwargs['routerLsaTosMetricsCount'])).execute()
        if 'linkId' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.linkId={} ".format(
                                    self.name, LsaIndex, Index, kwargs['linkId'])).execute()
            result.update({'LinkId':
                        f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{Index}.linkId'})
        if 'linkData' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.linkData={} ".format(
                                    self.name, LsaIndex, Index, kwargs['linkData'])).execute()
            result.update({'LinkData':
                        f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{Index}.linkData'})
        if 'routerLsaLinkType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLsaLinkType={} ".format(
                                    self.name, LsaIndex, Index, kwargs['routerLsaLinkType'])).execute()
            result.update({'RouterLsaLinkType':
                        f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{Index}.routerLsaLinkType'})
        if 'numRouterLsaTosMetrics' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.numRouterLsaTosMetrics={} ".format(
                                    self.name, LsaIndex, Index, kwargs['numRouterLsaTosMetrics'])).execute()
            result.update({'NumRouterLsaTosMetrics':
                        f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{Index}.linkData'})
        if 'routerLinkMetrics' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{}.routerLinkMetrics={} ".format(
                                    self.name, LsaIndex, Index, kwargs['routerLinkMetrics'])).execute()
            result.update({'RouterLinkMetrics':
                        f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_{Index}.routerLinkMetrics'})
        return result

    def edit_route_lsa_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'routerLsaLinkCount' in set(kwargs.keys()):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaLinks'.format(
                                        self.name, Index),
                                    NodeName='ospfv2RouterLsaLink',
                                    NodeCount=int(kwargs['routerLsaLinkCount'])).execute()
        if 'lsaAge' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaAge={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaAge'])).execute()
            result.update({'LsaAge': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaAge'})
        if 'reserved7' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.reserved7={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved7'])).execute()
            result.update(
                {'Reserved7': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.reserved7'})
        if 'reserved6' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.reserved6={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved6'])).execute()
            result.update(
                {'Reserved6': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.reserved6'})
        if 'dcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.dcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'dcBit'])).execute()
            result.update({'DcBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.dcBit'})
        if 'eaBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.eaBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eaBit'])).execute()
            result.update({'EaBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.eaBit'})
        if 'npBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.npBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'npBit'])).execute()
            result.update({'NpBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.npBit'})
        if 'mcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.mcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'mcBit'])).execute()
            result.update({'McBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.mcBit'})
        if 'eBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.eBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eBit'])).execute()
            result.update({'EBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.eBit'})
        if 'reserved0' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.reserved0={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved0'])).execute()
            result.update(
                {'Reserved0': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.reserved0'})
        if 'lsType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsType={} ".format(
                                    self.name, Index, kwargs[
                                        'lsType'])).execute()
            result.update({'LsType': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsType'})
        if 'linkStateId' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.linkStateId={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'linkStateId'])).execute()
            result.update({'LinkStateId': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.linkStateId'})
        if 'advertisingRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.advertisingRouter={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'advertisingRouter'])).execute()
            result.update({'AdvertisingRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.advertisingRouter'})
        if 'lsSequenceNumber' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsSequenceNumber={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'lsSequenceNumber'])).execute()
            result.update({'LsSequenceNumber': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsSequenceNumber'})
        if 'lsChecksum' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsChecksum={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsChecksum'])).execute()
            result.update({'LsChecksum': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsChecksum'})
        if 'lsaLength' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.lsaHeader.lsaLength={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsaLength'])).execute()
            result.update({'LsaLength': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.lsaHeader.lsaLength'})
        if 'reserved7Router' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.reserved7={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved7Router'])).execute()
            result.update({'Reserved7Router': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.reserved7'})
        if 'reserved6Router' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.reserved6={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved6Router'])).execute()
            result.update({'Reserved6Router': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.reserved6'})
        if 'reserved5Router' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.reserved5={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved5Router'])).execute()
            result.update({'Reserved5Router': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.reserved5'})
        if 'reserved4Router' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.reserved4={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved4Router'])).execute()
            result.update({'Reserved4Router': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.reserved4'})
        if 'reserved3Router' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.reserved3={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved3Router'])).execute()
            result.update({'Reserved3Router': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.reserved3'})
        if 'vBitRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.vBit={} ".format(
                                    self.name, Index, kwargs[
                                        'vBitRouter'])).execute()
            result.update({'VBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.vBit'})
        if 'eBitRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.eBit={} ".format(
                                    self.name, Index, kwargs[
                                        'eBitRouter'])).execute()
            result.update({'EBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.eBit'})
        if 'bBitRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.bBit={} ".format(
                                    self.name, Index, kwargs[
                                        'bBitRouter'])).execute()
            result.update({'BBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.bBit'})
        if 'routerLsaReserved1' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaReserved1={} ".format(
                                    self.name, Index, kwargs[
                                        'routerLsaReserved1'])).execute()
            result.update({'RouterLsaReserved1': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaReserved1'})
        if 'numberOfLinks' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.numberOfLinks={} ".format(
                                    self.name, Index, kwargs[
                                        'numberOfLinks'])).execute()
            result.update({'NumberOfLinks': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.numberOfLinks'})
        # if 'dcBitRouter' in set(kwargs.keys()):
        #     UpdateHeaderCommand(Stream=self.stream.handle,
        #                         Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.dcBit={} ".format(
        #                             self.name,
        #                             Index,
        #                             kwargs[
        #                                 'dcBitRouter'])).execute()
        #     result.update({'DcBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.dcBit'})
        # if 'eaBitRouter' in set(kwargs.keys()):
        #     UpdateHeaderCommand(Stream=self.stream.handle,
        #                         Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.eaBit={} ".format(
        #                             self.name,
        #                             Index,
        #                             kwargs[
        #                                 'eaBitRouter'])).execute()
        #     result.update({'EaBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.eaBit'})
        # if 'npBitRouter' in set(kwargs.keys()):
        #     UpdateHeaderCommand(Stream=self.stream.handle,
        #                         Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.npBit={} ".format(
        #                             self.name,
        #                             Index,
        #                             kwargs[
        #                                 'npBitRouter'])).execute()
        #     result.update({'NpBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.npBit'})
        # if 'mcBitRouter' in set(kwargs.keys()):
        #     UpdateHeaderCommand(Stream=self.stream.handle,
        #                         Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.mcBit={} ".format(
        #                             self.name,
        #                             Index,
        #                             kwargs[
        #                                 'mcBitRouter'])).execute()
        #     result.update({'McBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.mcBit'})
        # if 'eBitRouter' in set(kwargs.keys()):
        #     UpdateHeaderCommand(Stream=self.stream.handle,
        #                         Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.eBit={} ".format(
        #                             self.name,
        #                             Index,
        #                             kwargs[
        #                                 'eBitRouter'])).execute()
        #     result.update({'EBitRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.eBit'})
        # if 'reserved0Router' in set(kwargs.keys()):
        #     UpdateHeaderCommand(Stream=self.stream.handle,
        #                         Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2RouterLsa.routerLsaOptions.reserved0={} ".format(
        #                             self.name, Index, kwargs[
        #                                 'reserved0Router'])).execute()
        #     result.update({'Reserved0Router': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2RouterLsa.routerLsaOptions.reserved0'})
        return result

    def edit_network_lsa_attachedrouters(self, LsaIndex, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'routerID' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.attachedRouters.ospfv2AttachedRouter_{}.routerID={} ".format(
                                    self.name, LsaIndex, Index, kwargs[
                                        'routerID'])).execute()
            result.update({'RouterID': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2NetworkLsa.attachedRouters.ospfv2AttachedRouter_{Index}.routerID'})
        return result

    def edit_network_lsa_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'lsaAge' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaAge={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaAge'])).execute()
            result.update({'LsaAge': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaAge'})
        if 'reserved7' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.reserved7={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved7'])).execute()
            result.update({
                              'Reserved7': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.reserved7'})
        if 'reserved6' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.reserved6={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved6'])).execute()
            result.update({'Reserved6': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.reserved6'})
        if 'dcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.dcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'dcBit'])).execute()
            result.update(
                {'DcBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.dcBit'})
        if 'eaBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.eaBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eaBit'])).execute()
            result.update(
                {'EaBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.eaBit'})
        if 'npBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.npBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'npBit'])).execute()
            result.update({'NpBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.npBit'})
        if 'mcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.mcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'mcBit'])).execute()
            result.update({'McBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.mcBit'})
        if 'eBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.eBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eBit'])).execute()
            result.update(
                {'EBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.eBit'})
        if 'reserved0' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.reserved0={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved0'])).execute()
            result.update({'Reserved0': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaHdrOptions.reserved0'})
        if 'lsType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsType={} ".format(
                                    self.name, Index, kwargs[
                                        'lsType'])).execute()
            result.update({'LsType': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsType'})
        if 'linkStateId' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.linkStateId={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'linkStateId'])).execute()
            result.update({'LinkStateId': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.linkStateId'})
        if 'advertisingRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.advertisingRouter={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'advertisingRouter'])).execute()
            result.update({'AdvertisingRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.advertisingRouter'})
        if 'lsSequenceNumber' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsSequenceNumber={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'lsSequenceNumber'])).execute()
            result.update({'LsSequenceNumber': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsSequenceNumber'})
        if 'lsChecksum' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsChecksum={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsChecksum'])).execute()
            result.update({'LsChecksum': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsChecksum'})
        if 'lsaLength' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkLsaHeader.lsaLength={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsaLength'])).execute()
            result.update({'LsaLength': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkLsaHeader.lsaLength'})
        if 'networkMask' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.networkMask={} ".format(
                                    self.name, Index, kwargs[
                                        'networkMask'])).execute()
            result.update({'NetworkMask': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.networkMask'})
        if 'attachedRoute1' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.attachedRoute1={} ".format(
                                    self.name, Index, kwargs[
                                        'attachedRoute1'])).execute()
            result.update({'AttachedRoute1': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2NetworkLsa.attachedRoute1'})
        if 'attachedRouteCount' in set(kwargs.keys()):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.updatedLsas.ospfv2Lsa_{}.ospfv2NetworkLsa.attachedRouters'.format(
                                        self.name, Index),
                                    NodeName='ospfv2AttachedRouter',
                                    NodeCount=int(kwargs['attachedRouteCount'])).execute()
        return result

    def edit_summary_lsa_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'lsaAge' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaAge={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaAge'])).execute()
            result.update({'LsaAge': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaAge'})
        if 'reserved7' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.reserved7={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved7'])).execute()
            result.update({
                              'Reserved7': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.reserved7'})
        if 'reserved6' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.reserved6={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved6'])).execute()
            result.update({'Reserved6': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.reserved6'})
        if 'dcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.dcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'dcBit'])).execute()
            result.update(
                {'DcBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.dcBit'})
        if 'eaBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.eaBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eaBit'])).execute()
            result.update(
                {'EaBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.eaBit'})
        if 'npBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.npBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'npBit'])).execute()
            result.update({'NpBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.npBit'})
        if 'mcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.mcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'mcBit'])).execute()
            result.update({'McBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.mcBit'})
        if 'eBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.eBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eBit'])).execute()
            result.update(
                {'EBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.eBit'})
        if 'reserved0' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.reserved0={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved0'])).execute()
            result.update({'Reserved0': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaHdrOptions.reserved0'})
        if 'lsType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsType={} ".format(
                                    self.name, Index, kwargs[
                                        'lsType'])).execute()
            result.update({'LsType': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsType'})
        if 'linkStateId' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.linkStateId={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'linkStateId'])).execute()
            result.update({'LinkStateId': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.linkStateId'})
        if 'advertisingRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.advertisingRouter={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'advertisingRouter'])).execute()
            result.update({'AdvertisingRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.advertisingRouter'})
        if 'lsSequenceNumber' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsSequenceNumber={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'lsSequenceNumber'])).execute()
            result.update({'LsSequenceNumber': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsSequenceNumber'})
        if 'lsChecksum' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsChecksum={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsChecksum'])).execute()
            result.update({'LsChecksum': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsChecksum'})
        if 'lsaLength' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaHeader.lsaLength={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsaLength'])).execute()
            result.update({'LsaLength': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaHeader.lsaLength'})
        if 'networkMask' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.networkMask={} ".format(
                                    self.name, Index, kwargs[
                                        'networkMask'])).execute()
            result.update({'NetworkMask': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.networkMask'})
        if 'lsaReserved1' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaReserved1={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaReserved1'])).execute()
            result.update({'LsaReserved1': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaReserved1'})
        if 'lsaMetric' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryLsaMetric={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaMetric'])).execute()
            result.update({'LsaMetric': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryLsa.summaryLsaMetric'})
        if 'tosMetricsCount' in set(kwargs.keys()):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryAdditionalMetrics'.format(
                                        self.name, Index),
                                    NodeName='ospfv2SummaryLsaTosMetric',
                                    NodeCount=int(kwargs['tosMetricsCount'])).execute()
        return result

    def edit_summary_asbr_lsa_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'tosMetricsCount' in set(kwargs.keys()):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAdditionalMetrics'.format(
                                        self.name, Index),
                                    NodeName='ospfv2SummaryLsaTosMetric',
                                    NodeCount=int(kwargs['tosMetricsCount'])).execute()
        if 'networkMask' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.networkMask={} ".format(
                                    self.name, Index, kwargs[
                                        'networkMask'])).execute()
            result.update({'NetworkMask': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.networkMask'})
        if 'lsaReserved1' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryLsaReserved1={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaReserved1'])).execute()
            result.update({'LsaReserved1': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryLsaReserved1'})
        if 'lsaMetric' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryLsaMetric={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaMetric'])).execute()
            result.update({'LsaMetric': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryLsaMetric'})
        if 'lsaAge' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaAge={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaAge'])).execute()
            result.update({'LsaAge': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaAge'})
        if 'lsType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsType={} ".format(
                                    self.name, Index, kwargs[
                                        'lsType'])).execute()
            result.update({'LsType': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsType'})
        if 'linkStateId' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.linkStateId={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'linkStateId'])).execute()
            result.update({'LinkStateId': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.linkStateId'})
        if 'advertisingRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.advertisingRouter={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'advertisingRouter'])).execute()
            result.update({'AdvertisingRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.advertisingRouter'})
        if 'lsSequenceNumber' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsSequenceNumber={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'lsSequenceNumber'])).execute()
            result.update({'LsSequenceNumber': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsSequenceNumber'})
        if 'lsChecksum' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsChecksum={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsChecksum'])).execute()
            result.update({'LsChecksum': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsChecksum'})
        if 'lsaLength' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaLength={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsaLength'])).execute()
            result.update({'LsaLength': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaLength'})
        if 'reserved7' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.reserved7={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved7'])).execute()
            result.update({'Reserved7': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.reserved7'})
        if 'reserved6' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.reserved6={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved6'])).execute()
            result.update({'Reserved6': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.reserved6'})
        if 'dcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.dcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'dcBit'])).execute()
            result.update({'DcBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.dcBit'})
        if 'eaBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.eaBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eaBit'])).execute()
            result.update({'EaBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.eaBit'})
        if 'npBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.npBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'npBit'])).execute()
            result.update({'NpBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.npBit'})
        if 'mcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.mcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'mcBit'])).execute()
            result.update({'McBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.mcBit'})
        if 'eBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.eBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eBit'])).execute()
            result.update({'EBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.eBit'})
        if 'reserved0' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.reserved0={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved0'])).execute()
            result.update({'Reserved0': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2SummaryAsbrLsa.summaryAsbrLsaHeader.lsaHdrOptions.reserved0'})
        return result

    def edit_external_lsa_header(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if 'tosMetricsCount' in set(kwargs.keys()):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalAdditionalMetrics'.format(
                                        self.name, Index),
                                    NodeName='ospfv2ExternalLsaTosMetric',
                                    NodeCount=int(kwargs['tosMetricsCount'])).execute()
        if 'networkMask' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.networkMask={} ".format(
                                    self.name, Index, kwargs[
                                        'networkMask'])).execute()
            result.update({'NetworkMask': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.networkMask'})
        if 'externalOptionsEBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaOptions.eBit={} ".format(
                                    self.name, Index, kwargs[
                                        'externalOptionsEBit'])).execute()
            result.update({'ExternalOptionsEBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaOptions.eBit'})
        if 'externalOptionsReserved' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaOptions.reserved={} ".format(
                                    self.name, Index, kwargs[
                                        'externalOptionsReserved'])).execute()
            result.update({'ExternalOptionsReserved': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaOptions.reserved'})
        if 'externalRouteMetric' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalRouteMetric={} ".format(
                                    self.name, Index, kwargs[
                                        'externalRouteMetric'])).execute()
            result.update({'ExternalRouteMetric': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalRouteMetric'})
        if 'forwardingAddress' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.forwardingAddress={} ".format(
                                    self.name, Index, kwargs[
                                        'forwardingAddress'])).execute()
            result.update({'ForwardingAddress': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.forwardingAddress'})
        if 'externalRouteTag' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalRouteTag={} ".format(
                                    self.name, Index, kwargs[
                                        'externalRouteTag'])).execute()
            result.update({'ExternalRouteTag': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalRouteTag'})
        if 'lsaAge' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaAge={} ".format(
                                    self.name, Index, kwargs[
                                        'lsaAge'])).execute()
            result.update({'LsaAge': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaAge'})
        if 'lsType' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsType={} ".format(
                                    self.name, Index, kwargs[
                                        'lsType'])).execute()
            result.update({'LsType': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsType'})
        if 'linkStateId' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.linkStateId={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'linkStateId'])).execute()
            result.update({'LinkStateId': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.linkStateId'})
        if 'advertisingRouter' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.advertisingRouter={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'advertisingRouter'])).execute()
            result.update({'AdvertisingRouter': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.advertisingRouter'})
        if 'lsSequenceNumber' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsSequenceNumber={} ".format(
                                    self.name,
                                    Index, kwargs[
                                        'lsSequenceNumber'])).execute()
            result.update({'LsSequenceNumber': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsSequenceNumber'})
        if 'lsChecksum' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsChecksum={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsChecksum'])).execute()
            result.update({'LsChecksum': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsChecksum'})
        if 'lsaLength' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaLength={} ".format(
                                    self.name, Index,
                                    kwargs[
                                        'lsaLength'])).execute()
            result.update({'LsaLength': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaLength'})
        if 'reserved7' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.reserved7={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved7'])).execute()
            result.update({'Reserved7': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.reserved7'})
        if 'reserved6' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.reserved6={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved6'])).execute()
            result.update({'Reserved6': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.reserved6'})
        if 'dcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.dcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'dcBit'])).execute()
            result.update({'DcBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.dcBit'})
        if 'eaBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.eaBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eaBit'])).execute()
            result.update({'EaBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.eaBit'})
        if 'npBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.npBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'npBit'])).execute()
            result.update({'NpBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.npBit'})
        if 'mcBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.mcBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'mcBit'])).execute()
            result.update({'McBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.mcBit'})
        if 'eBit' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.eBit={} ".format(
                                    self.name,
                                    Index,
                                    kwargs[
                                        'eBit'])).execute()
            result.update({'EBit': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.eBit'})
        if 'reserved0' in set(kwargs.keys()):
            UpdateHeaderCommand(Stream=self.stream.handle,
                                Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.reserved0={} ".format(
                                    self.name, Index, kwargs[
                                        'reserved0'])).execute()
            result.update({'Reserved0': f'updatedLsas.ospfv2Lsa_{Index}.ospfv2AsExternalLsa.externalLsaHeader.lsaHdrOptions.reserved0'})
        return result

    def edit_lsa_tosmetric(self, Type, LsaIndex, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        if Type.lower() == 'summary':
            if 'metricReserved' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{}.summaryLsaMetricReserved={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'metricReserved'])).execute()
                result.update({'MetricReserved': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2SummaryLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{Index}.summaryLsaMetricReserved'})
            if 'linkMetrics' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{}.routerTosLinkMetrics={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'linkMetrics'])).execute()
                result.update({'LinkMetrics': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2SummaryLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{Index}.routerTosLinkMetrics'})
        elif Type.lower() == 'summaryasbr':
            if 'metricReserved' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{}.summaryLsaMetricReserved={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'metricReserved'])).execute()
                result.update({'MetricReserved': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2SummaryAsbrLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{Index}.summaryLsaMetricReserved'})
            if 'linkMetrics' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2SummaryAsbrLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{}.routerTosLinkMetrics={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'linkMetrics'])).execute()
                result.update({'LinkMetrics': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2SummaryAsbrLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_{Index}.routerTosLinkMetrics'})
        elif Type.lower() == 'asexternal':
            if 'eBit' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{}.eBit={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'eBit'])).execute()
                result.update({'EBit': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{Index}.eBit'})
            if 'routeTos' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{}.externalLsaRouteTos={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'routeTos'])).execute()
                result.update({'RouteTos': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{Index}.externalLsaRouteTos'})
            if 'routeMetrics' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{}.externalLsaRouteMetrics={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'routeMetrics'])).execute()
                result.update({'RouteMetrics': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{Index}.externalLsaRouteMetrics'})
            if 'forwardingAddress' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{}.forwardingAddress={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'forwardingAddress'])).execute()
                result.update({'ForwardingAddress': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{Index}.forwardingAddress'})
            if 'routeTag' in set(kwargs.keys()):
                UpdateHeaderCommand(Stream=self.stream.handle,
                                    Parameter="{}.updatedLsas.ospfv2Lsa_{}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{}.externalRouteTag={} ".format(
                                        self.name, LsaIndex, Index, kwargs[
                                            'routeTag'])).execute()
                result.update({'RouteTag': f'updatedLsas.ospfv2Lsa_{LsaIndex}.ospfv2AsExternalLsa.externalAdditionalMetrics.ospfv2ExternalLsaTosMetric_{Index}.externalRouteTag'})
        return result
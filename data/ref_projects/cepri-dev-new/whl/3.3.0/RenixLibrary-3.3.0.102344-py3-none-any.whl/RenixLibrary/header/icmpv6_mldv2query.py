from .header_base import *

file_path = SCHEMA_PATH + "IcmpV6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("mldv2Query")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Icmpv6Mldv2QueryHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("mldv2Query")
        self.__type = paramDict["type"]
        self.__code = paramDict["code"]
        self.__checksum = paramDict["checksum"]
        self.__maxRespCode = paramDict["maxRespCode"]
        self.__reserved = paramDict["reserved"]
        self.__groupAddress = paramDict["groupAddress"]
        self.__resv = paramDict["resv"]
        self.__sFlag = paramDict["sFlag"]
        self.__qrv = paramDict["qrv"]
        self.__qqic = paramDict["qqic"]
        self.__numberOfSources = paramDict["numberOfSources"]
        self.__sourceAddressList = paramDict["sourceAddressList"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def code(self):
        return self.__code

    @code.setter
    def code(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__code = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def maxRespCode(self):
        return self.__maxRespCode

    @maxRespCode.setter
    def maxRespCode(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__maxRespCode = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved = Value

    @property
    def groupAddress(self):
        return self.__groupAddress

    @groupAddress.setter
    def groupAddress(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__groupAddress = Value

    @property
    def resv(self):
        return self.__resv

    @resv.setter
    def resv(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__resv = Value

    @property
    def sFlag(self):
        return self.__sFlag

    @sFlag.setter
    def sFlag(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sFlag = Value

    @property
    def qrv(self):
        return self.__qrv

    @qrv.setter
    def qrv(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__qrv = Value

    @property
    def qqic(self):
        return self.__qqic

    @qqic.setter
    def qqic(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__qqic = Value

    @property
    def numberOfSources(self):
        return self.__numberOfSources

    @numberOfSources.setter
    def numberOfSources(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__numberOfSources = Value

    @property
    def sourceAddressList(self):
        return self.__sourceAddressList

    @sourceAddressList.setter
    def sourceAddressList(self, Value):
        for addr in Value:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.{}'.format(self.name, sys._getframe().f_code.co_name),
                                    NodeName='ipv6AddrContainer').execute()
            list_instance_leaf_cmd = ListInstanceLeafCommand(Stream=self.stream.handle, Deep=True)
            list_instance_leaf_cmd.execute()
            self.update('{}={}'.format(list_instance_leaf_cmd.Leaves[-1], addr))
        self.__sourceAddressList = Value

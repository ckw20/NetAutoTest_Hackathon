from .header_base import *

class Dhcpv4(HeaderBase):

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, **kwargs)

    @property
    def messageType(self):
        return self.__messageType

    @messageType.setter
    def messageType(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__messageType = Value

    @property
    def hardwareType(self):
        return self.__hardwareType

    @hardwareType.setter
    def hardwareType(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__hardwareType = Value

    @property
    def haddrLen(self):
        return self.__haddrLen

    @haddrLen.setter
    def haddrLen(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__haddrLen = Value

    @property
    def hops(self):
        return self.__hops

    @hops.setter
    def hops(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__hops = Value

    @property
    def xid(self):
        return self.__xid

    @xid.setter
    def xid(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__xid = Value

    @property
    def elapsed(self):
        return self.__elapsed

    @elapsed.setter
    def elapsed(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__elapsed = Value

    @property
    def bootpflags(self):
        return self.__bootpflags

    @bootpflags.setter
    def bootpflags(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__bootpflags = Value

    @property
    def clientAddr(self):
        return self.__clientAddr

    @clientAddr.setter
    def clientAddr(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__clientAddr = Value

    @property
    def yourAddr(self):
        return self.__yourAddr

    @yourAddr.setter
    def yourAddr(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__yourAddr = Value

    @property
    def nextServerAddr(self):
        return self.__nextServerAddr

    @nextServerAddr.setter
    def nextServerAddr(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__nextServerAddr = Value

    @property
    def relayAgentAddr(self):
        return self.__relayAgentAddr

    @relayAgentAddr.setter
    def relayAgentAddr(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__relayAgentAddr = Value

    @property
    def clientMac(self):
        return self.__clientMac

    @clientMac.setter
    def clientMac(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__clientMac = Value

    @property
    def clientHWPad(self):
        return self.__clientHWPad

    @clientHWPad.setter
    def clientHWPad(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__clientHWPad = Value

    @property
    def serverHostName(self):
        return self.__serverHostName

    @serverHostName.setter
    def serverHostName(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__serverHostName = Value

    @property
    def bootFileName(self):
        return self.__bootFileName

    @bootFileName.setter
    def bootFileName(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__bootFileName = Value

    @property
    def magicCookie(self):
        return self.__magicCookie

    @magicCookie.setter
    def magicCookie(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__magicCookie = Value

    @property
    def padding(self):
        return self.__padding

    @padding.setter
    def padding(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__padding = Value

    def insert_option_header(self, Value):
        if not isinstance(Value, (list, set, tuple)):
            Value = [Value]
        for x in Value:
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.options'.format(self.name),
                                    NodeName='{}'.format(x)).execute()
        return True

    def edit_message_type(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'code']:
                self.update("{}.options.Dhcpv4Options_{}.messageType.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.messageType.{}".format(Index, k)})
        return result

    def edit_message_size(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv4Options_{}.messageSize.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.messageSize.{}".format(Index, k)})
        return result

    def edit_clientid_hw(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'idType', 'clientHWA']:
                self.update("{}.options.Dhcpv4Options_{}.clientIdHW.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.clientIdHW.{}".format(Index, k)})
        return result

    def edit_clientid_nonehw(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'idType', 'value']:
                self.update("{}.options.Dhcpv4Options_{}.clientIdNoneHW.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.clientIdNoneHW.{}".format(Index, k)})
        return result

    def edit_host_name(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv4Options_{}.hostName.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.hostName.{}".format(Index, k)})
        return result

    def edit_param_req_list(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv4Options_{}.paramReqList.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.paramReqList.{}".format(Index, k)})
        return result

    def edit_req_addr(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'reqAddr']:
                self.update("{}.options.Dhcpv4Options_{}.reqAddr.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.reqAddr.{}".format(Index, k)})
        return result

    def edit_option_over_load(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'overload']:
                self.update("{}.options.Dhcpv4Options_{}.optionOverload.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.optionOverload.{}".format(Index, k)})
        return result

    def edit_server_id(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'reqAddr']:
                self.update("{}.options.Dhcpv4Options_{}.serverId.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.serverId.{}".format(Index, k)})
        return result

    def edit_message(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv4Options_{}.message.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.message.{}".format(Index, k)})
        return result

    def edit_lease_time(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'leaseTime']:
                self.update("{}.options.Dhcpv4Options_{}.leaseTime.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.leaseTime.{}".format(Index, k)})
        return result

    def edit_custom_option(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'overload']:
                self.update("{}.options.Dhcpv4Options_{}.customOption.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.customOption.{}".format(Index, k)})
        return result

    def edit_end_of_options(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k == 'type':
                self.update("{}.options.Dhcpv4Options_{}.endOfOptions.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.endOfOptions.{}".format(Index, k)})
        return result

    def edit_general_tlv(self, Index, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k in ['type', 'length', 'value']:
                self.update("{}.options.Dhcpv4Options_{}.generalTLV.{}={}".format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): "options.Dhcpv4Options_{}.generalTLV.{}".format(Index, k)})
        return result
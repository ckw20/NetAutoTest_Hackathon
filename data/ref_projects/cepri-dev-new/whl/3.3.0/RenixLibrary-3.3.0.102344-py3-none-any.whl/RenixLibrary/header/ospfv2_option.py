from .ospfv2 import *


class Ospfv2OptionHeader(Ospfv2Header):

    def __init__(self, Upper, Attributes, Displays, Values, OptionType):
        super().__init__(Upper=Upper, Attributes=Attributes, Displays=Displays, Values=Values)
        self.__optionType = OptionType
        self.__optionsReserved7 = None
        self.__optionsReserved6 = None
        self.__optionsDcBit = None
        self.__optionsEaBit = None
        self.__optionsNpBit = None
        self.__optionsMcBit = None
        self.__optionsEBit = None
        self.__optionsReserved0 = None

    @property
    def optionsReserved7(self):
        return self.__optionsReserved7

    @optionsReserved7.setter
    def optionsReserved7(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved7={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsReserved7 = Value

    @property
    def optionsReserved6(self):
        return self.__optionsReserved6

    @optionsReserved6.setter
    def optionsReserved6(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved6={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsReserved6 = Value

    @property
    def optionsDcBit(self):
        return self.__optionsDcBit

    @optionsDcBit.setter
    def optionsDcBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.dcBit={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsDcBit = Value

    @property
    def optionsEaBit(self):
        return self.__optionsEaBit

    @optionsEaBit.setter
    def optionsEaBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.eaBit={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsEaBit = Value

    @property
    def optionsNpBit(self):
        return self.__optionsNpBit

    @optionsNpBit.setter
    def optionsNpBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.npBit={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsNpBit = Value

    @property
    def optionsMcBit(self):
        return self.__optionsMcBit

    @optionsMcBit.setter
    def optionsMcBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.mcBit={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsMcBit = Value

    @property
    def optionsEBit(self):
        return self.__optionsEBit

    @optionsEBit.setter
    def optionsEBit(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.eBit={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsEBit = Value

    @property
    def optionsReserved0(self):
        return self.__optionsReserved0

    @optionsReserved0.setter
    def optionsReserved0(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}.reserved0={} ".format(self.name, self.__optionType, Value)).execute()
        self.__optionsReserved0 = Value

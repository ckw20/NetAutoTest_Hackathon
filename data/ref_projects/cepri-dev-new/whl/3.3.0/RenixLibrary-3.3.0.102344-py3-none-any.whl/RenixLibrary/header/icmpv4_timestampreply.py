from .header_base import *

# from RenixAPI.RenixLibrary.header.header_base import *

file_path = SCHEMA_PATH + "IcmpV4Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("timestampReply")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Icmpv4TimeStampReplyHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("timestampReply")
        self.__type = paramDict["type"]
        self.__code = paramDict["code"]
        self.__checksum = paramDict["checksum"]
        self.__identifier = paramDict["identifier"]
        self.__sequenceNumber = paramDict["sequenceNumber"]
        self.__originateTimestamp = paramDict["originateTimestamp"]
        self.__receiveTimestamp = paramDict["receiveTimestamp"]
        self.__transmitTimestamp = paramDict["transmitTimestamp"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.apply()
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def code(self):
        return self.__code

    @code.setter
    def code(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__code = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def identifier(self):
        return self.__identifier

    @identifier.setter
    def identifier(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__identifier = Value

    @property
    def sequenceNumber(self):
        return self.__sequenceNumber

    @sequenceNumber.setter
    def sequenceNumber(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sequenceNumber = Value

    @property
    def originateTimestamp(self):
        return self.__originateTimestamp

    @originateTimestamp.setter
    def originateTimestamp(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__originateTimestamp = Value

    @property
    def receiveTimestamp(self):
        return self.__receiveTimestamp

    @receiveTimestamp.setter
    def receiveTimestamp(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__receiveTimestamp = Value

    @property
    def transmitTimestamp(self):
        return self.__transmitTimestamp

    @transmitTimestamp.setter
    def transmitTimestamp(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__transmitTimestamp = Value

    def get_icmp_value(self, field):
        return self.get_value('{}.{}'.format(self.name, field))

from .header_base import *

file_path = SCHEMA_PATH + "MacInMacEthernet.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("macInMacEncapEthernetII")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class EncapsulatedCustomerEthernetIIHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("encapEthernetII")
        self.__etherType = paramDict["etherType"]

    @property
    def etherType(self):
        return self.__etherType

    @etherType.setter
    def etherType(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__etherType = Value

    def insert_service_tag(self):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.sTag'.format(self.name),
                                NodeName='serviceTag').execute()

    def insert_customer_tag(self):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.cTag'.format(self.name),
                                NodeName='customerTag').execute()

    def config_service_tag(self, **kwargs):
        attr = {}
        for k, v in kwargs.items():
            self.update('{}.sTag.serviceTag_0.{}={} '.format(self.name, k, v))
            attr[k[0].upper()+k[1:]] = f'sTag.serviceTag_0.{k}'
        return attr

    def config_customer_tag(self, **kwargs):
        attr = {}
        for k, v in kwargs.items():
            self.update('{}.cTag.customerTag_0.{}={} '.format(self.name, k, v))
            attr[k[0].upper()+k[1:]] = f'cTag.customerTag_0.{k}'
        return attr




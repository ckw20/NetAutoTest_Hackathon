from .dhcpv4_base import *

file_path = SCHEMA_PATH + "Dhcpv4Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("dhcpv4Server")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class dhcpv4ServerHeader(Dhcpv4):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("dhcpv4Server")
        self.__messageType = paramDict["messageType"]
        self.__hardwareType = paramDict["hardwareType"]
        self.__haddrLen = paramDict["haddrLen"]
        self.__hops = paramDict["hops"]
        self.__xid = paramDict["xid"]
        self.__elapsed = paramDict["elapsed"]
        self.__bootpflags = paramDict["bootpflags"]
        self.__clientAddr = paramDict["clientAddr"]
        self.__yourAddr = paramDict["yourAddr"]
        self.__nextServerAddr = paramDict["nextServerAddr"]
        self.__relayAgentAddr = paramDict["relayAgentAddr"]
        self.__clientMac = paramDict["clientMac"]
        self.__clientHWPad = paramDict["clientHWPad"]
        self.__serverHostName = paramDict["serverHostName"]
        self.__bootFileName = paramDict["bootFileName"]
        self.__magicCookie = paramDict["magicCookie"]
        self.__padding = paramDict["padding"]

    # @property
    # def messageType(self):
    #     return self.__messageType
    #
    # @messageType.setter
    # def messageType(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__messageType = Value
    #
    # @property
    # def hardwareType(self):
    #     return self.__hardwareType
    #
    # @hardwareType.setter
    # def hardwareType(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__hardwareType = Value
    #
    # @property
    # def haddrLen(self):
    #     return self.__haddrLen
    #
    # @haddrLen.setter
    # def haddrLen(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__haddrLen = Value
    #
    # @property
    # def hops(self):
    #     return self.__hops
    #
    # @hops.setter
    # def hops(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__hops = Value
    #
    # @property
    # def xid(self):
    #     return self.__xid
    #
    # @xid.setter
    # def xid(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__xid = Value
    #
    # @property
    # def elapsed(self):
    #     return self.__elapsed
    #
    # @elapsed.setter
    # def elapsed(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__elapsed = Value
    #
    # @property
    # def bootpflags(self):
    #     return self.__bootpflags
    #
    # @bootpflags.setter
    # def bootpflags(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__bootpflags = Value
    #
    # @property
    # def clientAddr(self):
    #     return self.__clientAddr
    #
    # @clientAddr.setter
    # def clientAddr(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__clientAddr = Value
    #
    # @property
    # def yourAddr(self):
    #     return self.__yourAddr
    #
    # @yourAddr.setter
    # def yourAddr(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__yourAddr = Value
    #
    # @property
    # def nextServerAddr(self):
    #     return self.__nextServerAddr
    #
    # @nextServerAddr.setter
    # def nextServerAddr(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__nextServerAddr = Value
    #
    # @property
    # def relayAgentAddr(self):
    #     return self.__relayAgentAddr
    #
    # @relayAgentAddr.setter
    # def relayAgentAddr(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__relayAgentAddr = Value
    #
    # @property
    # def clientMac(self):
    #     return self.__clientMac
    #
    # @clientMac.setter
    # def clientMac(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__clientMac = Value
    #
    # @property
    # def clientHWPad(self):
    #     return self.__clientHWPad
    #
    # @clientHWPad.setter
    # def clientHWPad(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__clientHWPad = Value
    #
    # @property
    # def serverHostName(self):
    #     return self.__serverHostName
    #
    # @serverHostName.setter
    # def serverHostName(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__serverHostName = Value
    #
    # @property
    # def bootFileName(self):
    #     return self.__bootFileName
    #
    # @bootFileName.setter
    # def bootFileName(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__bootFileName = Value
    #
    # @property
    # def magicCookie(self):
    #     return self.__magicCookie
    #
    # @magicCookie.setter
    # def magicCookie(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__magicCookie = Value
    #
    # @property
    # def padding(self):
    #     return self.__padding
    #
    # @padding.setter
    # def padding(self, Value):
    #     UpdateHeaderCommand(Stream=self.stream.handle,
    #                         Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
    #     self.__padding = Value
    #
    # def insert_option_header(self, Value):
    #     if not isinstance(Value, (list, set, tuple)):
    #         Value = [Value]
    #     for x in Value:
    #         InsertNodeToASetCommand(Stream=self.stream.handle,
    #                                 ParentName='{}.options'.format(self.name),
    #                                 NodeName='{}'.format(x)).execute()
    #     return True
    #
    # def _edit_public_attribute(self, Options, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     if 'type' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.{}.type={}".format(
    #                                 self.name, Index, Options, kwargs[
    #                                     'type'])).execute()
    #     if 'length' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.{}.length={}".format(
    #                                 self.name, Index, Options, kwargs[
    #                                     'length'])).execute()
    #
    # def edit_server_id(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='serverId', Index=Index, **kwargs)
    #     if 'reqAddr' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.serverId.reqAddr={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'reqAddr'])).execute()
    #     return True
    #
    # def edit_message(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='message', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.message.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_lease_time(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='leaseTime', Index=Index, **kwargs)
    #     if 'leaseTime' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.leaseTime.leaseTime={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'leaseTime'])).execute()
    #     return True
    #
    # def edit_end_of_options(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     if 'type' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.endOfOptions.type={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'type'])).execute()
    #     return True
    #
    # def edit_message_size(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='messageSize', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.messageSize.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_clientid_hw(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='clientIdHW', Index=Index, **kwargs)
    #     if 'idType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.clientIdHW.idType={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'idType'])).execute()
    #     if 'clientHWA' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.clientIdHW.clientHWA={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'clientHWA'])).execute()
    #     return True
    #
    # def edit_clientid_nonehw(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='clientIdNoneHW', Index=Index, **kwargs)
    #     if 'idType' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.clientIdNoneHW.idType={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'idType'])).execute()
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.clientIdNoneHW.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_host_name(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='hostName', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.hostName.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_param_req_list(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='paramReqList', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.paramReqList.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
    #
    # def edit_req_addr(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='reqAddr', Index=Index, **kwargs)
    #     if 'reqAddr' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.reqAddr.reqAddr={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'reqAddr'])).execute()
    #     return True
    #
    # def edit_option_over_load(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='optionOverload', Index=Index, **kwargs)
    #     if 'overload' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.optionOverload.overload={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'overload'])).execute()
    #     return True
    #
    # def edit_custom_option(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='customOption', Index=Index, **kwargs)
    #     if 'overload' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.customOption.overload={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'overload'])).execute()
    #     return True
    #
    # def edit_general_tlv(self, Index, **kwargs):
    #     kwargs = self.dict_keys_initial_lowercase(**kwargs)
    #     self._edit_public_attribute(Options='generalTLV', Index=Index, **kwargs)
    #     if 'value' in set(kwargs.keys()):
    #         UpdateHeaderCommand(Stream=self.stream.handle,
    #                             Parameter="{}.options.Dhcpv4Options_{}.generalTLV.value={}".format(
    #                                 self.name, Index, kwargs[
    #                                     'value'])).execute()
    #     return True
from .header_base import *

file_path = SCHEMA_PATH + "VNTagTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("vnTag")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class VntagHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("vnTag")
        self.__ver = paramDict["ver"]
        self.__res = paramDict["res"]
        self.__dir = paramDict["dir"]
        self.__pointer = paramDict["pointer"]
        self.__dstVif = paramDict["dstVif"]
        self.__srcVif = paramDict["srcVif"]
        self.__looped = paramDict["looped"]
        self.__protocol = paramDict["protocol"]

    @property
    def ver(self):
        return self.__ver

    @ver.setter
    def ver(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__ver = Value

    @property
    def res(self):
        return self.__res

    @res.setter
    def res(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__res = Value

    @property
    def dir(self):
        return self.__dir

    @dir.setter
    def dir(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__dir = Value

    @property
    def pointer(self):
        return self.__pointer

    @pointer.setter
    def pointer(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pointer = Value

    @property
    def dstVif(self):
        return self.__dstVif

    @dstVif.setter
    def dstVif(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__dstVif = Value

    @property
    def srcVif(self):
        return self.__srcVif

    @srcVif.setter
    def srcVif(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__srcVif = Value

    @property
    def looped(self):
        return self.__looped

    @looped.setter
    def looped(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__looped = Value

    @property
    def protocol(self):
        return self.__protocol

    @protocol.setter
    def protocol(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__protocol = Value


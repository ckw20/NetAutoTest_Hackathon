from .header_base import *

file_path = SCHEMA_PATH + "IgmpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("igmpv3Report")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Igmpv3ReportHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("igmpv3Report")
        self.__type = paramDict["type"]
        self.__reserved1 = paramDict["reserved1"]
        self.__checksum = paramDict["checksum"]
        self.__reserved2 = paramDict["reserved2"]
        self.__numGroupRecords = paramDict["numGroupRecords"]
        self.__groupRecords = paramDict["groupRecords"]

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__type = Value

    @property
    def reserved1(self):
        return self.__reserved1

    @reserved1.setter
    def reserved1(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved1 = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__checksum = Value

    @property
    def reserved2(self):
        return self.__reserved2

    @reserved2.setter
    def reserved2(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved2 = Value

    @property
    def numGroupRecords(self):
        return self.__numGroupRecords

    @numGroupRecords.setter
    def numGroupRecords(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__numGroupRecords = Value

    def insertGroupRecords(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.groupRecords'.format(self.name),
                                    NodeName='groupRecord').execute()

    def getGroupRecords(self, Field, Index=0):
        return self.get_value('{}.groupRecords.groupRecord_{}.{}'.format(self.name, Index, Field))

    def editGroupRecords(self, Index=0, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            self.update('{}.groupRecords.groupRecord_{}.{}={}'.format(self.name, Index, k_, v))
            result.update({k: f'groupRecords.groupRecord_{Index}.{k_}'})
        return result

    def insertIpv4AddressContainer(self, GroupIndex):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.groupRecords.groupRecord_{}.sourceAddressList'.format(self.name,
                                                                                                     GroupIndex),
                                NodeName='ipv4AddrContainer').execute()

    def getIpv4AddressContainer(self, GroupIndex=0, Index=0):
        return self.get_value(
            '{}.groupRecords.groupRecord_{}.sourceAddressList.ipv4AddrContainer_{}.ipv4Addr'.format(self.name,
                                                                                                    GroupIndex, Index))

    def editIpv4AddressContainer(self, Value, GroupIndex=0, Index=0):
        self.update(
            '{}.groupRecords.groupRecord_{}.sourceAddressList.ipv4AddrContainer_{}.ipv4Addr={}'.format(self.name,
                                                                                                       GroupIndex,
                                                                                                       Index, Value))
        return f'groupRecords.groupRecord_{GroupIndex}.sourceAddressList.ipv4AddrContainer_{Index}.ipv4Addr'

    def insertAuxDataContainer(self, GroupIndex):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.groupRecords.groupRecord_{}.exceedauxDataList'.format(self.name,
                                                                                                     GroupIndex),
                                NodeName='auxDataContainer').execute()

    def getAuxDataContainer(self, GroupIndex=0, Index=0):
        return self.get_value(
            '{}.groupRecords.groupRecord_{}.exceedauxDataList.auxDataContainer_{}.auxData'.format(self.name, GroupIndex,
                                                                                                  Index))

    def editAuxDataContainer(self, Value, GroupIndex=0, Index=0):
        self.update('{}.groupRecords.groupRecord_{}.exceedauxDataList.auxDataContainer_{}.auxData={}'.format(self.name,
                                                                                                             GroupIndex,
                                                                                                             Index,
                                                                                                             Value))
        return f'groupRecords.groupRecord_{GroupIndex}.exceedauxDataList.auxDataContainer_{Index}.auxData'
from .header_base import *

file_path = SCHEMA_PATH + "IcmpV6Template.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("mldv2Report")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Icmpv6Mldv2ReportHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("mldv2Report")
        self.__type = paramDict["type"]
        self.__unused = paramDict["unused"]
        self.__checksum = paramDict["checksum"]
        self.__reserved = paramDict["reserved2"]
        self.__numberOfGroupRecords = paramDict["numberOfGroupRecords"]
        self.__sourceAddressList = {}

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def unused(self):
        return self.__unused

    @unused.setter
    def unused(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__unused = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__checksum = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.reserved2={} '.format(self.name, Value))
        self.__reserved = Value

    @property
    def numberOfGroupRecords(self):
        return self.__numberOfGroupRecords

    @numberOfGroupRecords.setter
    def numberOfGroupRecords(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__numberOfGroupRecords = Value

    def insertMldv2GroupRecord(self):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.{}'.format(self.name, sys._getframe().f_code.co_name),
                                NodeName='groupRecord').execute()

    def getMldv2GroupRecord(self, Field, Index=0):
        if Field != 'sourceAddressList':
            return self.get_value('{}.groupRecords.groupRecord_{}.{}'.format(self.name, Index, Field))
        else:
            return self.__sourceAddressList[Index]

    def editMldv2GroupRecord(self, Index=0, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k != 'sourceAddressList':
                self.update('{}.groupRecords.groupRecord_{}.{}={} '.format(self.name, Index, k, v))
                result.update({(k[:1].upper()+k[1:]): f'groupRecords.groupRecord_{Index}.{k}'})
            else:
                for i, addr in enumerate(v):
                    # self.update(f'{}.groupRecords.groupRecord_{}.{}.ipv6AddrContainer')
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName='{}.groupRecords.groupRecord_{}.{}'.format(self.name, Index, k),
                                            NodeName='ipv6AddrContainer').execute()
                    list_instance_leaf_cmd = ListInstanceLeafCommand(Stream=self.stream.handle, Deep=True)
                    list_instance_leaf_cmd.execute()
                    self.update('{}={}'.format(list_instance_leaf_cmd.Leaves[-1], addr))
                    result.update({f'{k[:1].upper() + k[1:]}: {addr}': f'groupRecords.groupRecord_{Index}.sourceAddressList.ipv6AddrContainer_{i}.ipv6Addr'})
                self.__sourceAddressList[Index] = v
        return result
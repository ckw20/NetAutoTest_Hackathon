from .header_base import *

file_path = SCHEMA_PATH + "IsIsTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndexes = [headers.index("l1psnpCommonHeader"), headers.index('psnpDataHeader')]
    attributes, displays, defaultValues = [], [], []
    for headerIndex in headerIndexes:
        attributes.extend([i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        displays.extend([i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        defaultValues.extend([i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class IsisL1PsnpHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("l1psnpHeader")
        self.__InterRoutingProtocolDiscriminator = paramDict["InterRoutingProtocolDiscriminator"]
        self.__lengthIndicator = paramDict["lengthIndicator"]
        self.__versionIdExtend = paramDict["versionIdExtend"]
        self.__idLength = paramDict["idLength"]
        self.__reserved1 = paramDict["reserved1"]
        self.__pDUType = paramDict["pDUType"]
        self.__version = paramDict["version"]
        self.__reserved2 = paramDict["reserved2"]
        self.__maxAreaAddress = paramDict["maxAreaAddress"]
        self.__pDULength = paramDict["pDULength"]
        self.__sourceId = paramDict["sourceId"]
        self.__reserved = paramDict["reserved"]
        self.__CsnpDataTlvOptionHeader = paramDict["CsnpDataTlvOptionHeader"]

    @property
    def InterRoutingProtocolDiscriminator(self):
        return self.__InterRoutingProtocolDiscriminator

    @InterRoutingProtocolDiscriminator.setter
    def InterRoutingProtocolDiscriminator(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__InterRoutingProtocolDiscriminator = Value

    @property
    def lengthIndicator(self):
        return self.__lengthIndicator

    @lengthIndicator.setter
    def lengthIndicator(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__lengthIndicator = Value

    @property
    def versionIdExtend(self):
        return self.__versionIdExtend

    @versionIdExtend.setter
    def versionIdExtend(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__versionIdExtend = Value

    @property
    def idLength(self):
        return self.__idLength

    @idLength.setter
    def idLength(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__idLength = Value

    @property
    def reserved1(self):
        return self.__reserved1

    @reserved1.setter
    def reserved1(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved1 = Value

    @property
    def pDUType(self):
        return self.__pDUType

    @pDUType.setter
    def pDUType(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pDUType = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version = Value

    @property
    def reserved2(self):
        return self.__reserved2

    @reserved2.setter
    def reserved2(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved2 = Value

    @property
    def maxAreaAddress(self):
        return self.__maxAreaAddress

    @maxAreaAddress.setter
    def maxAreaAddress(self, Value):
        self.update('{}.l1psnpCommonHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__maxAreaAddress = Value

    @property
    def pDULength(self):
        return self.__pDULength

    @pDULength.setter
    def pDULength(self, Value):
        self.update('{}.psnpDataHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__pDULength = Value

    @property
    def sourceId(self):
        return self.__sourceId

    @sourceId.setter
    def sourceId(self, Value):
        self.update('{}.psnpDataHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sourceId = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.psnpDataHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved = Value

    @property
    def CsnpDataTlvOptionHeader(self):
        return self.__CsnpDataTlvOptionHeader

    @CsnpDataTlvOptionHeader.setter
    def CsnpDataTlvOptionHeader(self, Value):
        # isIsLspEntries authentionInfo
        # if not isinstance(Value, (list, tuple, set)):
        #     Value = [Value]
        # for i in Value:
        #     InsertNodeToASetCommand(Stream=self.stream.handle,
        #                             ParentName='{}.psnpDataHeader.{}'.format(self.name, sys._getframe().f_code.co_name),
        #                             NodeName=i).execute()
        self.__CsnpDataTlvOptionHeader = Value

    def getTlvHeader(self, Option, Field, Index=0):
        Option = Option[:1].lower() + Option[1:]
        Field = Field[:1].lower()+Field[1:]
        if Field in ['authenticationType', 'authenticationLength', 'authentication']:
            return self.get_value(
                '{}.psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.{}.authen.{}'.format(self.name, Index, Option,
                                                                                     Field))
        else:
            return self.get_value(
                '{}.psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.{}.{}'.format(self.name, Index, Option, Field))

    def editTlvHeader(self, Option, Index=0, **kwargs):
        result = {}
        if Option != 'Ipv6InterfaceAddress':
            Option = Option[:1].lower()+Option[1:]
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            if k == 'lspEntries':
                # need delete node
                if not isinstance(v, int):
                    return False
                for i in range(v):
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName='{}.psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.isIsLspEntries.lspEntries'.format(
                                                self.name, Index),
                                            NodeName='LSPEntry').execute()
            elif k in ['authenticationType', 'authenticationLength', 'authentication']:
                self.update(
                    '{}.psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.{}.authen.{}={}'.format(self.name, Index,
                                                                                                Option, k, v))
                result.update({(k[:1].upper() + k[1:]):
                    'psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.{}.authen.{}'.format(
                        Index, Option, k)})
            else:
                self.update(
                    '{}.psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.{}.{}={}'.format(self.name, Index,
                                                                                                Option, k, v))
                result.update({(k[:1].upper() + k[1:]):
                    'psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.{}.{}'.format(
                        Index, Option, k)})
        return result

    def editLspEntry(self, TlvIndex=0, LspIndex=0, **kwargs):
        result = {}
        kwargs = self.dict_keys_initial_lowercase(**kwargs)
        for k, v in kwargs.items():
            self.update(
                '{}.psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.isIsLspEntries.lspEntries.LSPEntry_{}.{}={}'.format(
                    self.name, TlvIndex, LspIndex, k, v))
            result.update({(k[:1].upper() + k[1:]):
                'psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.isIsLspEntries.lspEntries.LSPEntry_{}.{}'.format(
                    TlvIndex, LspIndex, k)})
        return result

    def getLspEntry(self, Field, TlvIndex=0, LspIndex=0):
        Field = Field[:1].lower()+Field[1:]
        return self.get_value(
            '{}.psnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_{}.isIsLspEntries.lspEntries.LSPEntry_{}.{}'.format(
                self.name, TlvIndex, LspIndex, Field))

from .header_base import *

file_path = SCHEMA_PATH + "ANCPTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    attributes, displays, defaultValues = [], [], []
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    for tmp in ['tcpipEncapHeader', 'portManagementMessageHeader']:
        headerIndex = headers.index(tmp)
        attributes.extend([i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        displays.extend([i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
        defaultValues.extend([i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField])
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    if a in paramDict.keys():
        a = a + '_'
    paramDict.update({a: v})


class ANCPPortManagementHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("portManagement")
        self.__id = paramDict["id"]
        self.__len = paramDict["len"]
        self.__version = paramDict["version"]
        self.__messageType1 = paramDict["messageType1"]
        self.__resultField = paramDict["resultField"]
        self.__resultCode = paramDict["resultCode"]
        self.__partitionID = paramDict["partitionID"]
        self.__transactionID = paramDict["transactionID"]
        self.__ignore = paramDict["ignore"]
        self.__subMessageNum = paramDict["subMessageNum"]
        self.__len_ = paramDict["len_"]
        self.__unused = paramDict["unused"]
        self.__function = paramDict["function"]
        self.__xFunction = paramDict["xFunction"]
        self.__unused2 = paramDict["unused2"]
        self.__extensionFlag = paramDict["extensionFlag"]
        self.__messageType2 = paramDict["messageType2"]
        self.__reserved = paramDict["reserved"]
        self.__numberOfTLV = paramDict["numberOfTLV"]
        self.__extBlockLength = paramDict["extBlockLength"]
        self.__accLineIdentifyingTLVs = 0
        self.__testRelatedTLVs = 0
        self.__statusInfoTLVs = 0

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, Value):
        self.update('{}.tcpipEncapHeaderField.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__id = Value

    @property
    def len(self):
        return self.__len

    @len.setter
    def len(self, Value):
        self.update('{}.tcpipEncapHeaderField.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__len = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__version = Value

    @property
    def messageType1(self):
        return self.__messageType1

    @messageType1.setter
    def messageType1(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__messageType1 = Value

    @property
    def resultField(self):
        return self.__resultField

    @resultField.setter
    def resultField(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__resultField = Value

    @property
    def resultCode(self):
        return self.__resultCode

    @resultCode.setter
    def resultCode(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__resultCode = Value

    @property
    def partitionID(self):
        return self.__partitionID

    @partitionID.setter
    def partitionID(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__partitionID = Value

    @property
    def transactionID(self):
        return self.__transactionID

    @transactionID.setter
    def transactionID(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__transactionID = Value

    @property
    def ignore(self):
        return self.__ignore

    @ignore.setter
    def ignore(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__ignore = Value

    @property
    def subMessageNum(self):
        return self.__subMessageNum

    @subMessageNum.setter
    def subMessageNum(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__subMessageNum = Value

    @property
    def len_(self):
        return self.__len_

    @len_.setter
    def len_(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.len={} '.format(self.name, Value))
        self.__len_ = Value

    @property
    def unused(self):
        return self.__unused

    @unused.setter
    def unused(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__unused = Value

    @property
    def function(self):
        return self.__function

    @function.setter
    def function(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__function = Value

    @property
    def xFunction(self):
        return self.__xFunction

    @xFunction.setter
    def xFunction(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__xFunction = Value

    @property
    def unused2(self):
        return self.__unused2

    @unused2.setter
    def unused2(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__unused2 = Value

    @property
    def extensionFlag(self):
        return self.__extensionFlag

    @extensionFlag.setter
    def extensionFlag(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__extensionFlag = Value

    @property
    def messageType2(self):
        return self.__messageType2

    @messageType2.setter
    def messageType2(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__messageType2 = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__reserved = Value

    @property
    def numberOfTLV(self):
        return self.__numberOfTLV

    @numberOfTLV.setter
    def numberOfTLV(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__numberOfTLV = Value

    @property
    def extBlockLength(self):
        return self.__extBlockLength

    @extBlockLength.setter
    def extBlockLength(self, Value):
        self.update('{}.ancpPortManagementMsgHeader.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__extBlockLength = Value

    @property
    def accLineIdentifyingTLVs(self):
        return self.__accLineIdentifyingTLVs

    @accLineIdentifyingTLVs.setter
    def accLineIdentifyingTLVs(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.accLineIdentifyingTLVs'.format(self.name),
                                    NodeName='accLoopCircuitIdTLV').execute()
        self.__accLineIdentifyingTLVs = Value

    @property
    def testRelatedTLVs(self):
        return self.__testRelatedTLVs

    @testRelatedTLVs.setter
    def testRelatedTLVs(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.testRelatedTLVs'.format(self.name),
                                    NodeName='opaqueTLV').execute()
        self.__testRelatedTLVs = Value

    @property
    def statusInfoTLVs(self):
        return self.__statusInfoTLVs

    @statusInfoTLVs.setter
    def statusInfoTLVs(self, Value):
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.statusInfoTLVs'.format(self.name),
                                    NodeName='statusinfoTLV').execute()
        self.__statusInfoTLVs = Value

    def config_access_loop_circuit_id_tlv(self, TlvIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.accLineIdentifyingTLVs.accessLineIdentifyingTLVs_{}.accLoopCircuitIdTLV.{}={} '.format(
                self.name, TlvIndex, k_, v))
            result.update({k: 'accLineIdentifyingTLVs.accessLineIdentifyingTLVs_{}.accLoopCircuitIdTLV.{}'.format(TlvIndex, k_)})
        return result

    def get_access_loop_circuit_id_tlv(self, TlvIndex, Item):
        return self.get_value(field='{}.accLineIdentifyingTLVs.accessLineIdentifyingTLVs_{}.accLoopCircuitIdTLV.{}'.format(
            self.name, TlvIndex, Item[:1].lower()+Item[1:]))

    def config_testing_related_tlv(self, TlvIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.testRelatedTLVs.testingRelatedTLVs_{}.opaqueTLV.{}={} '.format(
                self.name, TlvIndex, k_, v))
            result.update({k: 'testRelatedTLVs.testingRelatedTLVs_{}.opaqueTLV.{}'.format(TlvIndex, k_)})
        return result

    def get_testing_related_tlv(self, TlvIndex, Item):
        return self.get_value(field='{}.testRelatedTLVs.testingRelatedTLVs_{}.opaqueTLV.{}'.format(
            self.name, TlvIndex, Item[:1].lower()+Item[1:]))

    def config_status_info_tlv(self, TlvIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            if k == 'OptionalSubTLV':
                for i in range(v):
                    InsertNodeToASetCommand(Stream=self.stream.handle,
                                            ParentName='{}.statusInfoTLVs.status-InfoTLV_{}.statusinfoTLV.optionalSubTLV'.format(self.name, TlvIndex),
                                            NodeName='customTLV').execute()
            else:
                self.update('{}.statusInfoTLVs.status-InfoTLV_{}.statusinfoTLV.{}={} '.format(
                    self.name, TlvIndex, k_, v))
                result.update({k: 'statusInfoTLVs.status-InfoTLV_{}.statusinfoTLV.{}'.format(TlvIndex, k_)})
        return result

    def get_status_info_tlv(self, TlvIndex, Item):
        return self.get_value(field='{}.statusInfoTLVs.status-InfoTLV_{}.statusinfoTLV.{}'.format(
            self.name, TlvIndex, Item[:1].lower()+Item[1:]))

    def config_status_info_tlv_optional_sub_tlv(self, TlvIndex, SubTlvIndex, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower() + k[1:]
            self.update('{}.statusInfoTLVs.status-InfoTLV_{}.statusinfoTLV.optionalSubTLV.customTLV_{}.{}={} '.format(
                self.name, TlvIndex, SubTlvIndex, k_, v))
            result.update({k: 'statusInfoTLVs.status-InfoTLV_{}.statusinfoTLV.optionalSubTLV.customTLV_{}.{}'.format(
                TlvIndex, SubTlvIndex, k_)})
        return result

    def get_status_info_tlv_optional_sub_tlv(self, TlvIndex, SubTlvIndex, Item):
        return self.get_value(field='{}.statusInfoTLVs.status-InfoTLV_{}.statusinfoTLV.optionalSubTLV.customTLV_{}.{}'.format(
            self.name, TlvIndex, SubTlvIndex, Item[:1].lower()+Item[1:]))


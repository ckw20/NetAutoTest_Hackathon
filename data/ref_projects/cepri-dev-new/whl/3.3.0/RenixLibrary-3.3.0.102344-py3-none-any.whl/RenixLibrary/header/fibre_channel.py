from .header_base import *

file_path = SCHEMA_PATH + "FcoeTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("fc")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class FibreChannelHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("fc")
        self.__rctl = paramDict["rctl"]
        self.__destAddr = paramDict["destAddr"]
        self.__csctl = paramDict["csctl"]
        self.__sourceAddr = paramDict["sourceAddr"]
        self.__type = paramDict["type"]
        self.__frameControl = paramDict["frameControl"]
        self.__seqID = paramDict["seqID"]
        self.__dataField = paramDict["dataField"]
        self.__seqCount = paramDict["seqCount"]
        self.__originatorExchangeID = paramDict["originatorExchangeID"]
        self.__responseExchangeID = paramDict["responseExchangeID"]
        self.__paraRelativeOffset = paramDict["paraRelativeOffset"]

    @property
    def rctl(self):
        return self.__rctl

    @rctl.setter
    def rctl(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__rctl = Value

    @property
    def destAddr(self):
        return self.__destAddr

    @destAddr.setter
    def destAddr(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__destAddr = Value

    @property
    def csctl(self):
        return self.__csctl

    @csctl.setter
    def csctl(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__csctl = Value

    @property
    def sourceAddr(self):
        return self.__sourceAddr

    @sourceAddr.setter
    def sourceAddr(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__sourceAddr = Value

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def frameControl(self):
        return self.__frameControl

    @frameControl.setter
    def frameControl(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__frameControl = Value

    @property
    def seqID(self):
        return self.__seqID

    @seqID.setter
    def seqID(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__seqID = Value

    @property
    def dataField(self):
        return self.__dataField

    @dataField.setter
    def dataField(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__dataField = Value

    @property
    def seqCount(self):
        return self.__seqCount

    @seqCount.setter
    def seqCount(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__seqCount = Value

    @property
    def originatorExchangeID(self):
        return self.__originatorExchangeID

    @originatorExchangeID.setter
    def originatorExchangeID(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__originatorExchangeID = Value

    @property
    def responseExchangeID(self):
        return self.__responseExchangeID

    @responseExchangeID.setter
    def responseExchangeID(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__responseExchangeID = Value

    @property
    def paraRelativeOffset(self):
        return self.__paraRelativeOffset

    @paraRelativeOffset.setter
    def paraRelativeOffset(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__paraRelativeOffset = Value

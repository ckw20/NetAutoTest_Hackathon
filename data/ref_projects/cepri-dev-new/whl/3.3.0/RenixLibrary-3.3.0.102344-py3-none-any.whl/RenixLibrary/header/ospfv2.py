from .header_base import *


class Ospfv2Header(HeaderBase):

    def __init__(self, Upper, Attributes, Displays, Values):
        super().__init__(Upper=Upper, Attributes=Attributes, Displays=Displays, Values=Values)
        self.__version = None
        self.__type = None
        self.__packetLength = None
        self.__routerID = None
        self.__areaID = None
        self.__checksum = None
        self.__checksum = None
        self.__authSelect = 'hdrAuthSelectNone'
        self.__authType = None
        self.__authValue1 = None
        self.__authValue2 = None

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.{}={} ".format(self.name, sys._getframe().f_code.co_name,
                                                                    Value)).execute()
        self.__version = Value

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.{}={} ".format(self.name, sys._getframe().f_code.co_name,
                                                                    Value)).execute()
        self.__type = Value

    @property
    def packetLength(self):
        return self.__packetLength

    @packetLength.setter
    def packetLength(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.{}={} ".format(self.name, sys._getframe().f_code.co_name,
                                                                    Value)).execute()
        self.__packetLength = Value

    @property
    def routerID(self):
        return self.__routerID

    @routerID.setter
    def routerID(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.{}={} ".format(self.name, sys._getframe().f_code.co_name,
                                                                    Value)).execute()
        self.__routerID = Value

    @property
    def areaID(self):
        return self.__areaID

    @areaID.setter
    def areaID(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.{}={} ".format(self.name, sys._getframe().f_code.co_name,
                                                                    Value)).execute()
        self.__areaID = Value

    @property
    def checksum(self):
        return self.__checksum

    @checksum.setter
    def checksum(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.{}={} ".format(self.name, sys._getframe().f_code.co_name,
                                                                    Value)).execute()
        self.__checksum = Value

    @property
    def authSelect(self):
        return self.__authSelect

    @authSelect.setter
    def authSelect(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.{}={} ".format(self.name, sys._getframe().f_code.co_name,
                                                                    Value)).execute()
        self.__authSelect = Value

    @property
    def authType(self):
        return self.__authType

    @authType.setter
    def authType(self, Value):
        inputValue = 0
        if Value.lower() == 'simplepassword':
            self.__authSelect = 'hdrAuthSelectPassword'
            inputValue = 1
        elif Value.lower() == 'md5':
            self.__authSelect = 'hdrAuthSelectCrypto'
            inputValue = 2
        elif Value.lower() == 'userdefined':
            self.__authSelect = 'hdrAuthSelectUserDef'
            inputValue = 3
        else:
            self.__authSelect = 'hdrAuthSelectNone'
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.authSelect.{}.{}={} ".format(self.name, self.__authSelect,
                                                                                  sys._getframe().f_code.co_name,
                                                                                  inputValue)).execute()
        self.__authType = Value

    @property
    def authValue1(self):
        return self.__authValue1

    @authValue1.setter
    def authValue1(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.authSelect.{}.{}={} ".format(self.name, self.__authSelect,
                                                                                  sys._getframe().f_code.co_name,
                                                                                  Value)).execute()
        self.__authValue1 = Value

    @property
    def authValue2(self):
        return self.__authValue2

    @authValue2.setter
    def authValue2(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.ospfHeader.authSelect.{}.{}={} ".format(self.name, self.__authSelect,
                                                                                  sys._getframe().f_code.co_name,
                                                                                  Value)).execute()
        self.__authValue2 = Value

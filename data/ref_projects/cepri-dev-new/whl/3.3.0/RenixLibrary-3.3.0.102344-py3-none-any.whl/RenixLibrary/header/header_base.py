import os
import sys
import untangle

from renix_py_api.api_gen import StreamTemplate, UpdateHeaderCommand, GetProtocolParameterCommand, \
    InsertNodeToASetCommand, ListInstanceLeafCommand

SCHEMA_PATH = os.path.dirname(os.environ.get("RENIX_SERVER_PATH").replace("server", "")) + "/ProtocolTemplate" \
                                                                                           "/ProtocolTemplateSchema/"


class HeaderBase:

    def __init__(self, SchemaPath=SCHEMA_PATH, Upper=None, Attributes=None, Displays=None, Values=None):
        self.schemaPath = SchemaPath
        self.__name = None
        self.__headerType = None
        self.__upper = Upper
        self.__lower = None
        self.__stream = None
        self.__map = {}
        self._modifier = {}
        self.__attributes = Attributes
        self.__displays = Displays
        self.__values = Values
        from RenixLibrary.data import MAP_HANDLE_OBJECT
        MAP_HANDLE_OBJECT.update({'{}.{}'.format(self.stream.handle, self.__name): self})

    @property
    def name(self):
        return self.__name

    @property
    def header_type(self):
        return self.__headerType

    @property
    def upper(self):
        return self.__upper

    @property
    def lower(self):
        return self.__lower

    @property
    def map(self):
        return self.__map

    @property
    def attributes(self):
        return self.__attributes

    @property
    def displays(self):
        return self.__displays

    @property
    def values(self):
        self.__values = []
        for a in self.attributes:
            self.__values.append(getattr(self, a))
        return self.__values

    @property
    def stream(self):
        flag = 1
        upperObject = self.upper
        while flag:
            if type(upperObject) is StreamTemplate:
                flag = 0
            else:
                upperObject = upperObject.upper
        self.__stream = upperObject
        return self.__stream

    @property
    def modifier(self):
        return self._modifier

    def get_modifier(self, Attribute):
        return self.modifier[str(Attribute)]

    def update_upper(self, HeaderType):
        self.__headerType = HeaderType.lower()
        upperObject = self.upper
        if type(upperObject) is StreamTemplate:
            self.__name = HeaderType + "_1"
        else:
            count = 1
            upperMap = upperObject.map
            for i in upperMap.keys():
                if type(i) == type(self):
                    count += 1
            self.__name = HeaderType + "_{}".format(count)
            self.__map = upperMap.copy()
        self.__map.update({self: self.__name})
        upperObject.__lower = self

    def apply(self):
        parameter = ""
        for a, v in zip(self.attributes, self.values):
            parameter = parameter + "{}.{}={} ".format(self.name, a, v)
        UpdateHeaderCommand(Stream=self.stream.handle, Parameter=parameter).execute()

    def puts(self):
        result = "{} : {}\n".format(type(self), id(self))
        for a, v, d in zip(self.attributes, self.values, self.displays):
            result = result + ("{} : {} = {}\n".format(d, a, v))
        print(result)
        return result

    def update(self, Parameter):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            BindingModifier=True,
                            Parameter=Parameter).execute()

    def get_value(self, field):
        tmp = GetProtocolParameterCommand(Stream=self.stream.handle, HeaderName=field)
        tmp.execute()
        return tmp.Value

    @staticmethod
    def dict_keys_initial_lowercase(**kwargs):
        return {str(k)[0].lower() + str(k)[1:]: v for k, v in kwargs.items()}

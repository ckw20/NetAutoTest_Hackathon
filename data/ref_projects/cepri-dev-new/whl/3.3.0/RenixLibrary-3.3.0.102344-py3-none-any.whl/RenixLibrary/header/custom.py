from renix_py_api.api_gen import InsertNodeToASetCommand

from .header_base import *

file_path = SCHEMA_PATH + "CustomTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("custom")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class CustomHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("custom")
        self.__customOption = []

    def edit_option_checksum(self, Level, Value):
        parameter = f"patternByte.customOption_{self.__customOption[int(Level - 1)]}.customChecksumOption.checksumOption"
        UpdateHeaderCommand(Stream=self.stream.handle, Parameter=f'{self.name}.{parameter}={Value} ').execute()
        return parameter

    def edit_option_pattern(self, Level, Value):
        parameter = f"patternByte.customOption_{self.__customOption[int(Level - 1)]}.customPatternByteOption.patternByteOption"
        UpdateHeaderCommand(Stream=self.stream.handle,
                            BindingModifier=True,
                            Parameter=f'{self.name}.{parameter}={Value} ').execute()
        return parameter

    def insert_option_checksum(self, Value):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.patternByte'.format(self.name),
                                NodeName='customChecksumOption',
                                NodeCount=1,
                                ).execute()
        if self.__customOption:
            self.__customOption.append(len(self.__customOption))
        else:
            self.__customOption.append(0)
        if str(Value).lower() != 'auto':
            return self.edit_option_checksum(Level=len(self.__customOption), Value=Value)
        else:
            return f"patternByte.customOption_{self.__customOption[int(len(self.__customOption) - 1)]}.customChecksumOption.checksumOption"

    def insert_option_pattern(self, Value):
        InsertNodeToASetCommand(Stream=self.stream.handle,
                                ParentName='{}.patternByte'.format(self.name),
                                NodeName='customPatternByteOption',
                                NodeCount=1,
                                ).execute()
        if self.__customOption:
            self.__customOption.append(len(self.__customOption))
        else:
            self.__customOption.append(0)
        return self.edit_option_pattern(Level=len(self.__customOption), Value=Value)

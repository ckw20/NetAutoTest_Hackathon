import string
import sys

from renix_py_api.api_gen import UpdateHeaderCommand

from RenixLibrary.data import MAP_STREAM_MODIFIER_ID


class Modifier:
    def __init__(self, Header, Attribute, Mode='realtime', Index=None, **kwargs):
        propertyDict = kwargs.copy()
        self.__header = Header
        self.__attribute = Attribute
        self.__mode = Mode
        self.__add_modifier()
        self.__type = None
        self.__streamType = None
        self.__start = None
        self.__step = None
        self.__count = None
        self.__mask = None
        self.__repeat = None
        self.__offset = None
        self.__range = None
        self.__seed = None
        self.__list = None
        if "Type" in propertyDict.keys():
            self.__type = propertyDict["Type"]
        if "StreamType" in propertyDict.keys():
            self.__streamType = propertyDict["StreamType"]
        if "Start" in propertyDict.keys():
            self.__start = propertyDict["Start"]
        if "Step" in propertyDict.keys():
            self.__step = propertyDict["Step"]
        if "Count" in propertyDict.keys():
            self.__count = propertyDict["Count"]
        if "Mask" in propertyDict.keys():
            self.__mask = propertyDict["Mask"]
        if "Repeat" in propertyDict.keys():
            self.__repeat = propertyDict["Repeat"]
        if "Offset" in propertyDict.keys():
            self.__offset = propertyDict["Offset"]
        if "Range" in propertyDict.keys():
            self.__range = propertyDict["Range"]
        if "Seed" in propertyDict.keys():
            self.__seed = propertyDict["Seed"]
        if "List" in propertyDict.keys():
            self.__list = propertyDict["List"]
        self.__index = self.set_index(Index)

    @property
    def Header(self):
        return self.__header

    @property
    def Attribute(self):
        return self.__attribute

    @property
    def Index(self):
        return self.__index

    def set_index(self, Index):
        if self.Header.stream.handle in MAP_STREAM_MODIFIER_ID:
            dict_map = MAP_STREAM_MODIFIER_ID[self.Header.stream.handle]
            if "{}.{}.XetModifier".format(self.Header.name, self.Attribute) in dict_map:
                list_map = dict_map["{}.{}.XetModifier".format(self.Header.name, self.Attribute)]
                if Index is not None and Index in list_map:
                    real_index = Index
                else:
                    if Index is None:
                        real_index = dict_map['index number'] + 1
                        dict_map.update({'index number': real_index})
                        list_map.append(real_index)
                        dict_map.update({"{}.{}.XetModifier".format(self.Header.name, self.Attribute): list_map})
                    else:
                        raise ValueError('{Index} is error')
            else:
                real_index = dict_map['index number'] + 1
                dict_map.update({'index number': real_index})
                dict_map.update({"{}.{}.XetModifier".format(self.Header.name, self.Attribute): [real_index]})
        else:
            real_index = 0
            dict_map = {
                'index number': 0,
                "{}.{}.XetModifier".format(self.Header.name, self.Attribute): [0]
            }
        MAP_STREAM_MODIFIER_ID.update({self.Header.stream.handle: dict_map})
        self.__index = real_index
        return real_index


    @property
    def Mode(self):
        return self.__mode

    @Mode.setter
    def Mode(self, Value):
        self.__mode = Value

    @property
    def Type(self):
        return self.__type

    @Type.setter
    def Type(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__type = Value

    @property
    def StreamType(self):
        return self.__streamType

    @StreamType.setter
    def StreamType(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__streamType = Value

    @property
    def Start(self):
        return self.__start

    @Start.setter
    def Start(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__start = Value

    @property
    def Step(self):
        return self.__step

    @Step.setter
    def Step(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__step = Value

    @property
    def Count(self):
        return self.__count

    @Count.setter
    def Count(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__count = Value

    @property
    def Mask(self):
        return self.__mask

    @Mask.setter
    def Mask(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__mask = Value

    @property
    def Repeat(self):
        return self.__repeat

    @Repeat.setter
    def Repeat(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__repeat = Value

    @property
    def Offset(self):
        return self.__offset

    @Offset.setter
    def Offset(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__offset = Value

    @property
    def Range(self):
        return self.__range

    @Range.setter
    def Range(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__range = Value

    @property
    def Seed(self):
        return self.__seed

    @Seed.setter
    def Seed(self, Value):
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle,
                                BindingModifier=True,
                                Parameter="{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                            sys._getframe().f_code.co_name,
                                                                            Value)).execute()
        self.__seed = Value

    @property
    def List(self):
        return self.__list

    @List.setter
    def List(self, Value):
        if not isinstance(Value, list):
            Value = [Value]
        parameter = ''
        for x in Value:
            parameter = parameter + "{}.{}.XetModifier:{}.{}={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                      sys._getframe().f_code.co_name, x)
        if self.Mode.lower() == "realtime":
            UpdateHeaderCommand(Stream=self.Header.stream.handle, BindingModifier=True, Parameter=parameter).execute()
        self.__list = Value

    def __add_modifier(self):
        self.Header._modifier.update({self.Attribute: self})

    def apply(self):
        # parameter = "{}.{}.XetModifier.enable=TRUE ".format(self.Header.name, self.Attribute)
        parameter = ""
        if self.Type is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Type={} ".format(self.Header.name, self.Attribute, self.Index, self.Type)
        if self.Start is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Start={} ".format(self.Header.name, self.Attribute, self.Index, self.Start)
        if self.Step is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Step={} ".format(self.Header.name, self.Attribute, self.Index, self.Step)
        if self.Count is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Count={} ".format(self.Header.name, self.Attribute, self.Index, self.Count)
        if self.Repeat is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Repeat={} ".format(self.Header.name, self.Attribute, self.Index, self.Repeat)
        if self.Mask is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Mask={} ".format(self.Header.name, self.Attribute, self.Index, self.Mask)
        if self.Offset is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Offset={} ".format(self.Header.name, self.Attribute, self.Index, self.Offset)
        if self.Range is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Range={} ".format(self.Header.name, self.Attribute, self.Index, self.Range)
        if self.Seed is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.Seed={} ".format(self.Header.name, self.Attribute, self.Index, self.Seed)
        if self.List is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.List=Clear ".format(self.Header.name, self.Attribute, self.Index)
            for x in self.List:
                parameter = parameter + "{}.{}.XetModifier:{}.List={} ".format(self.Header.name, self.Attribute, self.Index, x)
        # TODO StreamType必须放到最后Renix下发才能生效
        if self.StreamType is not None:
            parameter = parameter + "{}.{}.XetModifier:{}.StreamType={} ".format(self.Header.name, self.Attribute, self.Index,
                                                                              self.StreamType)
        UpdateHeaderCommand(Stream=self.Header.stream.handle, BindingModifier=True, Parameter=parameter).execute()
        return True

    def puts(self):
        result = "{} : {}\n".format(type(self), id(self))
        result = result + ("{}<{}> : {}\n".format(self.Header.__class__.__name__, id(self.Header), self.Attribute))
        print(result)
        return result

from .header_base import *

file_path = SCHEMA_PATH + "LldpTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("portIdTlv")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class LldpPortIdHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("portIdTlv")
        self.__type = paramDict["type"]
        self.__length = paramDict["length"]
        self.__portIdSubType = '03'
        self.__portId = '00:00:00:00:00:00'

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__type = Value

    @property
    def length(self):
        return self.__length

    @length.setter
    def length(self, Value):
        self.update('{}.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__length = Value

    @property
    def portIdSubType(self):
        return self.__portIdSubType

    @portIdSubType.setter
    def portIdSubType(self, Value):
        self.update('{}.portId.macAddr.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__portIdSubType = Value

    @property
    def portId(self):
        return self.__portId

    @portId.setter
    def portId(self, Value):
        self.update('{}.portId.macAddr.{}={} '.format(self.name, sys._getframe().f_code.co_name, Value))
        self.__portId = Value


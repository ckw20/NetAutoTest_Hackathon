from .header_base import *

file_path = SCHEMA_PATH + "EthernetTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("raw")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class Raw8023Header(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("raw")
        self.__destMacAdd = paramDict["destMacAdd"]
        self.__sourceMacAdd = paramDict["sourceMacAdd"]
        self.__payloadLength = paramDict["length"]

    @property
    def destMacAdd(self):
        return self.__destMacAdd

    @destMacAdd.setter
    def destMacAdd(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__destMacAdd = Value

    @property
    def sourceMacAdd(self):
        return self.__sourceMacAdd

    @sourceMacAdd.setter
    def sourceMacAdd(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__sourceMacAdd = Value

    @property
    def payloadLength(self):
        return self.__payloadLength

    @payloadLength.setter
    def payloadLength(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.length={} ".format(self.name, Value)).execute()
        self.__payloadLength = Value

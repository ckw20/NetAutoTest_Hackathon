from .header_base import *

file_path = SCHEMA_PATH + "RipTemplate.xml"
doc = untangle.parse(file_path)
if type(doc.XetRoot.XetNode) is list:
    headers = [i["name"] for i in doc.XetRoot.XetNode]
    headerIndex = headers.index("ripng")
    attributes = [i["name"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode[headerIndex].XetField]
else:
    attributes = [i["name"] for i in doc.XetRoot.XetNode.XetField]
    displays = [i["display"] for i in doc.XetRoot.XetNode.XetField]
    defaultValues = [i["defaultValue"] for i in doc.XetRoot.XetNode.XetField]

paramDict = {}
for a, v in zip(attributes, defaultValues):
    paramDict.update({a: v})


class RipngHeader(HeaderBase):
    names = locals()
    for i, j in zip(attributes, defaultValues):
        names[str(i).upper()] = j

    def __init__(self, Upper, **kwargs):
        super().__init__(Upper=Upper, Attributes=attributes, Displays=displays, Values=defaultValues)
        self.update_upper("ripng")
        self.__command = paramDict["command"]
        self.__version = paramDict["version"]
        self.__reserved = paramDict["reserved"]
        self.__numEntries = 0

    @property
    def command(self):
        return self.__command

    @command.setter
    def command(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__command = Value

    @property
    def version(self):
        return self.__version

    @version.setter
    def version(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__version = Value

    @property
    def reserved(self):
        return self.__reserved

    @reserved.setter
    def reserved(self, Value):
        UpdateHeaderCommand(Stream=self.stream.handle,
                            Parameter="{}.{}={} ".format(self.name, sys._getframe().f_code.co_name, Value)).execute()
        self.__reserved = Value

    @property
    def numEntries(self):
        return self.__numEntries

    def insertEntries(self, Value):
        result = []
        for i in range(Value):
            InsertNodeToASetCommand(Stream=self.stream.handle,
                                    ParentName='{}.ripngEntries'.format(self.name),
                                    NodeName='ripngEntriesList').execute()
            result.append(self.__numEntries)
            self.__numEntries += 1
        return result if len(result) != 1 else result[0]

    def getEntries(self, Field, Index=0):
        return self.get_value('{}.ripngEntries.ripngEntriesList_{}.{}'.format(self.name, Index, Field))

    def editRipngEntries(self, Index=0, **kwargs):
        result = {}
        for k, v in kwargs.items():
            k_ = k[:1].lower()+k[1:]
            self.update('{}.ripngEntries.ripngEntriesList_{}.{}={}'.format(self.name, Index, k_, v))
            result.update({k: f'ripngEntries.ripngEntriesList_{Index}.{k_}'})
        return result



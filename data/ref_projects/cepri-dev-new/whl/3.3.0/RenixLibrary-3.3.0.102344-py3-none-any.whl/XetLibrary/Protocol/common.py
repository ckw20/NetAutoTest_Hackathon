"""测试仪表协议配置参数模块

测试仪表协议配置和常用功能:

start_protocol: 测试仪表启动协议;

stop_protocol: 测试仪表停止协议;

select_interface:协议绑定测试仪表接口;
"""

import sys
from renix_py_api.api_gen import (
    Port,
    Interface,
    BgpProtocolConfig,
    BfdProtocolConfig,
    IsisProtocolConfig,
    Ospfv2ProtocolConfig,
    Ospfv3ProtocolConfig,
    PimProtocolConfig,
    RipProtocolConfig,
    Dot1xProtocolConfig,
    Dot1agProtocolConfig,
    Dot3ahProtocolConfig,
    Dhcpv4ServerConfig,
    Dhcpv4ClientConfig,
    Dhcpv6ServerConfig,
    Dhcpv6ClientConfig,
    VxlanProtocolConfig,
    SaaProtocolConfig,
    IgmpProtocolConfig,
    IgmpQuerierProtocolConfig,
    MldProtocolConfig,
    MldQuerierProtocolConfig,
    L2tpProtocolConfig,
    PppoeClientConfig,
    PppoeServerConfig,
    LdpProtocolConfig,
    LspPingConfig,
    PcepProtocolConfig
)
from RenixLibrary.protocol.bgp import BgpRouter
from RenixLibrary.protocol.bfd import BfdRouter
from RenixLibrary.protocol.isis import IsisRouter
from RenixLibrary.protocol.ospfv2 import OspfRouter
from RenixLibrary.protocol.ospfv3 import Ospfv3Router
from RenixLibrary.protocol.pim import PimRouter
from RenixLibrary.protocol.rip import RipRouter
from RenixLibrary.protocol.dot1x import Dot1x
from RenixLibrary.protocol.dot1ag import Dot1ag
from RenixLibrary.protocol.dot3ah import Dot3ah
from RenixLibrary.protocol.dhcp_server import DhcpServer
from RenixLibrary.protocol.dhcp_client import DhcpClient
from RenixLibrary.protocol.dhcpv6_server import Dhcpv6Server
from RenixLibrary.protocol.dhcpv6_client import Dhcpv6Client
from RenixLibrary.protocol.vxlan import Vxlan
from RenixLibrary.protocol.saa import Saa
from RenixLibrary.protocol.igmp import Igmp, IgmpQuerier
from RenixLibrary.protocol.mld import Mld, MldQuerier
from RenixLibrary.protocol.l2tp import L2tp
from RenixLibrary.protocol.pppoe import PppoeClient, PppoeServer
from RenixLibrary.protocol.ldp import Ldp
from RenixLibrary.protocol.lsp_ping import LspPing
from RenixLibrary.protocol.pcep import Pcep
from XetLibrary.Encryption.data import renix, ProtocolNameType
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def start_protocol(Ports=None, Protocols=None, Objects=None):
    """
    测试仪表启动协议

    Args:

        Ports (List[Port] or Port): 测试仪表端口Port对象列表或单个测试仪表端口Port对象

        Protocols (List[ProtocolNameType]): 指定需要启动的协议类型列表, 支持的有: 

            ProtocolNameType.BGP
            
            ProtocolNameType.BFD
            
            ProtocolNameType.ISIS
            
            ProtocolNameType.OSPFv2
            
            ProtocolNameType.OSPFv3
            
            ProtocolNameType.PIM
            
            ProtocolNameType.RIP
            
            ProtocolNameType.DOT1X
            
            ProtocolNameType.DOT1AG
            
            ProtocolNameType.DOT3AH
            
            ProtocolNameType.DHCPV4SERVER
            
            ProtocolNameType.DHCPV4
            
            ProtocolNameType.DHCPV6SERVER
            
            ProtocolNameType.DHCPV6
            
            ProtocolNameType.VXLAN
            
            ProtocolNameType.SAA
            
            ProtocolNameType.IGMP
            
            ProtocolNameType.IGMPQUERY
            
            ProtocolNameType.MLD
            
            ProtocolNameType.MLDQUERY
            
            ProtocolNameType.L2TP
            
            ProtocolNameType.PPPoECLIENT
            
            ProtocolNameType.PPPoESERVER
            
            ProtocolNameType.LDP
            
            ProtocolNameType.LSPPING
            
            ProtocolNameType.PCEP

        Objects (List): 当Ports参数和Protocols参数都为None时, 用于指定协议会话对象列表, 支持的有:

            BgpProtocolConfig
            
            Bgp
            
            BfdProtocolConfig
            
            Bfd
            
            IsisProtocolConfig
            
            Isis
            
            Ospfv2ProtocolConfig
            
            Ospfv2
            
            Ospfv3ProtocolConfig
            
            Ospfv3
            
            PimProtocolConfig
            
            Pim
            
            RipProtocolConfig
            
            Rip
            
            Dot1xProtocolConfig
            
            Dot1x
            
            Dot1agProtocolConfig
            
            Dot1ag
            
            Dot3ahProtocolConfig
            
            Dot3ah
            
            Dhcpv4ServerConfig
            
            Dhcpv4
            
            Dhcpv6ServerConfig
            
            Dhcpv6
            
            VxlanProtocolConfig
            
            Vxlan
            
            SaaProtocolConfig
            
            Saa
            
            IgmpProtocolConfig
            
            Igmp
            
            IgmpQuerierProtocolConfig
            
            IgmpQuerier
            
            MldProtocolConfig
            
            Mld
            
            MldQuerierProtocolConfig
            
            MldQuerier
            
            L2tpProtocolConfig
            
            L2tp
            
            PppoeClientConfig
            
            PppoeClient
            
            PppoeServerConfig
            
            PppoeServer
            
            LdpProtocolConfig
            
            Ldp
            
            LspPingConfig
            
            LspPing
            
            PcepProtocolConfig
            
            Pcep

    Returns:

        布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        start_protocol(Ports=ports)
    """

    result = renix.start_protocol(Ports=Ports, Protocols=Protocols, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_protocol(Ports=None, Protocols=None, Objects=None):
    """
    测试仪表停止协议

    Args:

        Ports (List[Port] or Port): 测试仪表端口Port对象列表或单个测试仪表端口Port对象

        Protocols (List[ProtocolNameType]): 指定需要启动的协议类型列表, 支持的有: 

            ProtocolNameType.BGP
            
            ProtocolNameType.BFD
            
            ProtocolNameType.ISIS
            
            ProtocolNameType.OSPFv2
            
            ProtocolNameType.OSPFv3
            
            ProtocolNameType.PIM
            
            ProtocolNameType.RIP
            
            ProtocolNameType.DOT1X
            
            ProtocolNameType.DOT1AG
            
            ProtocolNameType.DOT3AH
            
            ProtocolNameType.DHCPV4SERVER
            
            ProtocolNameType.DHCPV4
            
            ProtocolNameType.DHCPV6SERVER
            
            ProtocolNameType.DHCPV6
            
            ProtocolNameType.VXLAN
            
            ProtocolNameType.SAA
            
            ProtocolNameType.IGMP
            
            ProtocolNameType.IGMPQUERY
            
            ProtocolNameType.MLD
            
            ProtocolNameType.MLDQUERY
            
            ProtocolNameType.L2TP
            
            ProtocolNameType.PPPoECLIENT
            
            ProtocolNameType.PPPoESERVER
            
            ProtocolNameType.LDP
            
            ProtocolNameType.LSPPING
            
            ProtocolNameType.PCEP

        Objects (List): 当Ports参数和Protocols参数都为None时, 用于指定协议会话对象列表, 支持的有:

            BgpProtocolConfig
            
            Bgp
            
            BfdProtocolConfig
            
            Bfd
            
            IsisProtocolConfig
            
            Isis
            
            Ospfv2ProtocolConfig
            
            Ospfv2
            
            Ospfv3ProtocolConfig
            
            Ospfv3
            
            PimProtocolConfig
            
            Pim
            
            RipProtocolConfig
            
            Rip
            
            Dot1xProtocolConfig
            
            Dot1x
            
            Dot1agProtocolConfig
            
            Dot1ag
            
            Dot3ahProtocolConfig
            
            Dot3ah
            
            Dhcpv4ServerConfig
            
            Dhcpv4
            
            Dhcpv6ServerConfig
            
            Dhcpv6
            
            VxlanProtocolConfig
            
            Vxlan
            
            SaaProtocolConfig
            
            Saa
            
            IgmpProtocolConfig
            
            Igmp
            
            IgmpQuerierProtocolConfig
            
            IgmpQuerier
            
            MldProtocolConfig
            
            Mld
            
            MldQuerierProtocolConfig
            
            MldQuerier
            
            L2tpProtocolConfig
            
            L2tp
            
            PppoeClientConfig
            
            PppoeClient
            
            PppoeServerConfig
            
            PppoeServer
            
            LdpProtocolConfig
            
            Ldp
            
            LspPingConfig
            
            LspPing
            
            PcepProtocolConfig
            
            Pcep

    Returns:

        布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        stop_protocol(Ports=ports)
    """

    result = renix.get_sessions(Ports=Ports, Protocols=Protocols)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def select_interface(Session, Interface):
    """
    协议绑定测试仪表接口

    Args:

        Session (List[Session] or Session): 测试仪表协议对象, 支持的有:

            BgpProtocolConfig
            
            Bgp
            
            BfdProtocolConfig
            
            Bfd
            
            IsisProtocolConfig
            
            Isis
            
            Ospfv2ProtocolConfig
            
            Ospfv2
            
            Ospfv3ProtocolConfig
            
            Ospfv3
            
            PimProtocolConfig
            
            Pim
            
            RipProtocolConfig
            
            Rip
            
            Dot1xProtocolConfig
            
            Dot1x
            
            Dot1agProtocolConfig
            
            Dot1ag
            
            Dot3ahProtocolConfig
            
            Dot3ah
            
            Dhcpv4ServerConfig
            
            Dhcpv4
            
            Dhcpv6ServerConfig
            
            Dhcpv6
            
            VxlanProtocolConfig
            
            Vxlan
            
            SaaProtocolConfig
            
            Saa
            
            IgmpProtocolConfig
            
            Igmp
            
            IgmpQuerierProtocolConfig
            
            IgmpQuerier
            
            MldProtocolConfig
            
            Mld
            
            MldQuerierProtocolConfig
            
            MldQuerier
            
            L2tpProtocolConfig
            
            L2tp
            
            PppoeClientConfig
            
            PppoeClient
            
            PppoeServerConfig
            
            PppoeServer
            
            LdpProtocolConfig
            
            Ldp
            
            LspPingConfig
            
            LspPing
            
            PcepProtocolConfig
            
            Pcep

        Interface (List[Interface] or Interface): 测试仪表接口对象

    Returns:

        布尔值Bool (范围: True / False)

    Examples:
        .. code:: RobotFramework

            | Select Interface | Session=${Session} | Interface=${Interface} |
    """

    result = renix.select_interface(Session=Session, Interface=Interface)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
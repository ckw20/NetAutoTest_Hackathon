"""测试仪表协议配置参数模块

测试仪表协议配置和常用功能: 
create_dhcp_client: 创建DHCPv4客户端协议会话对象;

edit_dhcp_client: 修改DHCPv4客户端协议会话对象参数;

dhcp_bind: DHCPv4客户端协议会话对象请求地址;

dhcp_abort: DHCPv4客户端协议会话对象中断;

dhcp_rebind: DHCPv4客户端协议会话对象广播续租;

dhcp_reboot: DHCPv4客户端协议会话对象重新启动;

dhcp_release: DHCPv4客户端协议会话对象释放地址;

dhcp_renew: DHCPv4客户端协议会话对象单播续租;

create_dhcp_client_custom_option: 创建DHCPv4客户端协议会话option对象;

edit_dhcp_client_port_config: 修改DHCPv4客户端协议会话端口配置对象;

create_dhcp_server: 创建DHCPv4服务端协议会话对象;

edit_dhcp_server: 修改DHCPv4服务端协议会话对象;

create_dhcp_server_custom_option: 创建DHCPv4服务端option对象;

create_dhcp_server_address_pool: 创建DHCPv4服务端协议会话对象地址池;

edit_dhcp_server_port_config: 修改DHCPv4服务端协议会话端口配置;

dhcp_force_renew: DHCPv4服务端协议会话对象强制单播续租;

dhcp_abort_server: DHCPv4服务端协议会话对象中断;
"""

import sys
from renix_py_api.api_gen import (
    Port,
    Interface,
    Dhcpv4ClientOption,
    Dhcpv4PortConfig,
    Dhcpv4ServerPortConfig,
    Dhcpv4ServerOption,
    Dhcpv4AddressPool,
)
from RenixLibrary.protocol.dhcp_client import DhcpClient
from RenixLibrary.protocol.dhcp_server import DhcpServer
from XetLibrary.Encryption.data import (
    renix,
    Dhcpv4ClientModeType,
    Dhcpv4ClientParameterRequestsType,
    Dhcpv4ClientBroadcastFlagType,
    Dhcpv4OptionType,
    Dhcpv4ClientOptionMessageType,
)
from robot.api import ContinuableFailure, Failure


# -------------------------DHCPv4-------------------------------------
def create_dhcp_client(Port, **kwargs):
    """
    创建DHCPv4客户端协议会话对象

    Args:
        Port (Port): 测试仪表端口Port对象

    Keyword Args:
        Name (str): DHCPv4客户端协议会话名称

        Mode (Dhcpv4ClientModeType): DHCPv4客户端协议会话模式, 默认值: Dhcpv4ClientModeType.Client, 支持的有:

            Dhcpv4ClientModeType.Client
            Dhcpv4ClientModeType.RelayAgent

        HostName (str): 主机名字, 默认值: "XINERTEL"

        ParameterRequests (List[Dhcpv4ClientParameterRequestsType]): 主机请求选项, 默认值: [Dhcpv4ClientParameterRequestsType.NoneOption, Dhcpv4ClientParameterRequestsType.SubMask, Dhcpv4ClientParameterRequestsType.DomainNameServers, Dhcpv4ClientParameterRequestsType.DomainName, Dhcpv4ClientParameterRequestsType.StaticRoutes], 支持的有:

            Dhcpv4ClientParameterRequestsType.NoneOption
            Dhcpv4ClientParameterRequestsType.SubnetMask
            Dhcpv4ClientParameterRequestsType.Routers
            Dhcpv4ClientParameterRequestsType.DomainNameServers
            Dhcpv4ClientParameterRequestsType.DomainName
            Dhcpv4ClientParameterRequestsType.StaticRoutes
            Dhcpv4ClientParameterRequestsType.IpLeaseTime
            Dhcpv4ClientParameterRequestsType.ServerIdentifier
            Dhcpv4ClientParameterRequestsType.T1
            Dhcpv4ClientParameterRequestsType.T2

        EnableRouterOption (bool): 启用路由选项, 默认值: False

        VendorClassIdentifier (str): 供应商识别, 默认值: "XINERTEL"

        BroadcastFlag (Dhcpv4ClientBroadcastFlagType): Broadcast标记, 默认值: Dhcpv4ClientBroadcastFlagType.Broadcast, 支持的有:

            Dhcpv4ClientBroadcastFlagType.Broadcast
            Dhcpv4ClientBroadcastFlagType.Unicast

        RelayAgentIp (str): 代理端IPv4地址, 默认值: "1.1.1.1"

        ServerIp (str): DHCPv4服务端IPv4地址, 默认值: "2.1.1.3"

        EnableRelayAgentCircuitID (bool): 能代理电路标识, 默认值: False

        RelayAgentCircuitID (str): 代理电路标识, 默认值:""

        EnableRelayAgentRemoteID (str): 使能代理远程标识, 默认值:False

        RelayAgentRemoteID (str): 代理远程标识, 默认值:""

        EnableSyncAddressToInterface (bool): 使能同步地址到接口, 默认值:True

        HostInterface (Interface): 客户端接口Interface对象

    Returns:

        DhcpClient: DHCPv4客户端协议会话对象

    Examples:
        python:

    .. code:: python

        dhcpClientSession = create_dhcp_client(Port, Mode=Dhcpv4ClientModeType.Client)
    """

    result = renix.create_dhcp_client(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_dhcp_client(Session, **kwargs):
    """
    编辑DHCPv4客户端协议会话对象

    Args:
        Session (DhcpClient): DHCPv4客户端协议会话对象

    Keyword Args:
        Name (str): DHCPv4客户端协议会话名称

        Mode (Dhcpv4ClientModeType): DHCPv4客户端协议会话模式, 默认值: Dhcpv4ClientModeType.Client, 支持的有:

            Dhcpv4ClientModeType.Client

            Dhcpv4ClientModeType.RelayAgent

        HostName (str): 主机名字, 默认值: "XINERTEL"

        ParameterRequests (List[Dhcpv4ClientParameterRequestsType]): 主机请求选项, 默认值: [Dhcpv4ClientParameterRequestsType.NoneOption, Dhcpv4ClientParameterRequestsType.SubMask, Dhcpv4ClientParameterRequestsType.DomainNameServers, Dhcpv4ClientParameterRequestsType.DomainName, Dhcpv4ClientParameterRequestsType.StaticRoutes], 支持的有:

            Dhcpv4ClientParameterRequestsType.NoneOption

            Dhcpv4ClientParameterRequestsType.SubnetMask
            
            Dhcpv4ClientParameterRequestsType.Routers
            
            Dhcpv4ClientParameterRequestsType.DomainNameServers
            
            Dhcpv4ClientParameterRequestsType.DomainName
            
            Dhcpv4ClientParameterRequestsType.StaticRoutes
            
            Dhcpv4ClientParameterRequestsType.IpLeaseTime
            
            Dhcpv4ClientParameterRequestsType.ServerIdentifier
            
            Dhcpv4ClientParameterRequestsType.T1
            
            Dhcpv4ClientParameterRequestsType.T2

        EnableRouterOption (bool): 启用路由选项, 默认值: False

        VendorClassIdentifier (str): 供应商识别, 默认值: "XINERTEL"

        BroadcastFlag (Dhcpv4ClientBroadcastFlagType): Broadcast标记, 默认值: Dhcpv4ClientBroadcastFlagType.Broadcast, 支持的有:

            Dhcpv4ClientBroadcastFlagType.Broadcast
            
            Dhcpv4ClientBroadcastFlagType.Unicast

        RelayAgentIp (str): 代理端IPv4地址, 默认值: "1.1.1.1"

        ServerIp (str): DHCPv4服务端IPv4地址, 默认值: "2.1.1.3"

        EnableRelayAgentCircuitID (bool): 能代理电路标识, 默认值: False

        RelayAgentCircuitID (str): 代理电路标识, 默认值:""

        EnableRelayAgentRemoteID (str): 使能代理远程标识, 默认值:False

        RelayAgentRemoteID (str): 代理远程标识, 默认值:""

        EnableSyncAddressToInterface (bool): 使能同步地址到接口, 默认值:True

        HostInterface (Interface): 客户端接口Interface对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = edit_dhcp_client(dhcpClientSession, Mode=Dhcpv4ClientModeType.RelayAgent)
    """
    result = renix.edit_dhcp_client(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_bind(Sessions):
    """
    DHCPv4客户端协议会话对象请求地址

    Args:
        Sessions (List[DhcpClient] or DhcpClient): DHCPv4客户端协议会话对象列表或单个DHCPv4客户端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_bind(dhcpClientSession)
    """
    result = renix.dhcp_bind(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_abort(Sessions):
    """
    DHCPv4客户端协议会话对象中断

    Args:
        Sessions (List[DhcpClient] or DhcpClient): DHCPv4客户端协议会话对象列表或单个DHCPv4客户端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_abort(dhcpClientSession)
    """
    result = renix.dhcp_abort(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_rebind(Sessions):
    """
    DHCPv4客户端协议会话对象广播续租

    Args:

        Sessions (List[DhcpClient] or DhcpClient): DHCPv4客户端协议会话对象列表或单个DHCPv4客户端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_rebind(dhcpClientSession)
    """
    result = renix.dhcp_rebind(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_reboot(Sessions):
    """
    DHCPv4客户端协议会话对象重新启动

    Args:

        Sessions (List[DhcpClient] or DhcpClient): DHCPv4客户端协议会话对象列表或单个DHCPv4客户端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_reboot(dhcpClientSession)
    """
    result = renix.dhcp_reboot(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_release(Sessions):
    """
    DHCPv4客户端协议会话对象释放地址

    Args:

        Sessions (List[DhcpClient] or DhcpClient): DHCPv4客户端协议会话对象列表或单个DHCPv4客户端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_release(dhcpClientSession)
    """
    result = renix.dhcp_release(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_renew(Sessions):
    """
    DHCPv4客户端协议会话对象单播续租

    Args:

        Sessions (List[DhcpClient] or DhcpClient): DHCPv4客户端协议会话对象列表或单个DHCPv4客户端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_renew(dhcpClientSession)
    """
    result = renix.dhcp_renew(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def create_dhcp_client_custom_option(Session, **kwargs):
    """
    创建DHCPv4客户端协议会话option对象

    Args:

        Session (List[DhcpClient] or DhcpClient): DHCPv4客户端协议会话对象列表或单个DHCPv4客户端协议会话对象

    Keyword Args:

        OptionTag (int): option可选项类型标识, 默认值: 0, 取值范围: 0-255

        OptionType (Dhcpv4OptionType): option可选项类型, 默认值: Dhcpv4OptionType.Hex, 支持的有:

            Dhcpv4OptionType.Hex
            
            Dhcpv4OptionType.String
            
            Dhcpv4OptionType.Boolean
            
            Dhcpv4OptionType.Int8
            
            Dhcpv4OptionType.Int16
            
            Dhcpv4OptionType.Int32
            
            Dhcpv4OptionType.Ip

        EnableOptionValueList (bool): 是否启用option可选项值列表, 默认值: False

        OptionValue (str): option可选项值, 默认值: ""

        MessageType (List[Dhcpv4ClientOptionMessageType]): 携带option消息类型, 默认值: [Dhcpv4ClientOptionMessageType.Discover], 支持的有:

            Dhcpv4ClientOptionMessageType.Discover
            
            Dhcpv4ClientOptionMessageType.Request

    Returns:

        DhcpClientOption: DHCPv4客户端协议会话option对象

    Examples:
        python:

    .. code:: python

        dhcpClientOption = create_dhcp_client_custom_option(dhcpClientSession)
    """
    result = renix.create_dhcp_client_custom_option(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_dhcp_client_port_config(Ports, **kwargs):
    """
    修改DHCPv4客户端协议会话端口配置对象

    Args:

        Ports (List[Port] or Port): 测试仪表端口Port对象列表或单个测试仪表端口Port对象

    Keyword Args:

        SetupRate (int): 建立速率, 默认值: 100, 范围: 1-65535

        TeardownRate (int): 拆除速率, 默认值: 100, 范围: 1-65535

        MaxOutstanding (int): 最大同时请求个数速率, 默认值: 100, 范围: 1-65535

        LeaseTime (int): 期望租约时间（秒）, 默认值: 600, 范围: 1-4294967295

        SessionRetryCount (int): 创建会话尝试次数, 默认值: 0, 范围: 0-65535

        MessageRetryCount (int): 消息发送超时尝试次数, 默认值: 5, 范围: 0-65535

        MessageTimeout (int): 消息超时时间（秒）, 默认值: 10, 范围: 1-99999

        MaxMessageSize (int): 允许最大有效负荷（字节）, 默认值: 576, 范围: 291-1500
    
    Returns:

        Dhcpv4PortConfig: DHCPv4客户端协议会话端口配置对象

    Examples:
        python:

    .. code:: python

        dhcpv4PortConfig = edit_dhcp_client_port_config(dhcpClientSession)
    """

    result = renix.edit_dhcp_client_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def create_dhcp_server(Port, **kwargs):
    """
    创建DHCPv4服务端协议会话对象

    Args:

        Port (Port): 测试仪表端口Port对象
    
    Keyword Args:

        Name (str): DHCP Server协议会话名称

        LeaseTime (int): 租约时间（秒）, 默认值: 600, 范围: 1-4294967295

        RenewTime (int): T1租约更新时间(%), 默认值: 50, 范围: 0-200

        RebindTime (int): T2租约更新时间(%), 默认值: 87.5, 范围: 0-200

        MinLeaseTime (int): 最小允许租约时间(秒), 默认值: 10, 范围: 1-4294967295

        DeclineReserveTime (int): 资源释放等待时间(秒), 默认值: 10, 范围: 1-600

        OfferReserveTime (int): 租约申请超时(秒), 默认值: 10, 范围: 1-600

        ServerHostName (str): 服务端名字, 默认值: ""

        DuplicateAddressDetection (bool): 重复地址检测(DAD), 默认值: False

        DuplicateAddressDetectionTimeout (int): DAD超时时间, 默认值: 0.5, 范围: 0-60

    Returns:

        DhcpServer: DHCPv4服务端协议会话对象

    Examples:
        python:

    .. code:: python

        dhcpServer = create_dhcp_server(dhcpClientSession)
    """

    result = renix.create_dhcp_server(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_dhcp_server(Session, **kwargs):
    """
    修改DHCPv4服务端协议会话对象

    Args:

        Session (DhcpServer): DHCPv4服务端协议会话对象

    Keyword Args:

        Name (str): DHCP Server协议会话名称

        LeaseTime (int): 租约时间（秒）, 默认值: 600, 范围: 1-4294967295

        RenewTime (int): T1租约更新时间(%), 默认值: 50, 范围: 0-200

        RebindTime (int): T2租约更新时间(%), 默认值: 87.5, 范围: 0-200

        MinLeaseTime (int): 最小允许租约时间(秒), 默认值: 10, 范围: 1-4294967295

        DeclineReserveTime (int): 资源释放等待时间(秒), 默认值: 10, 范围: 1-600

        OfferReserveTime (int): 租约申请超时(秒), 默认值: 10, 范围: 1-600

        ServerHostName (str): 服务端主机名, 默认值: ""

        DuplicateAddressDetection (bool): 重复地址检测(DAD), 默认值: False

        DuplicateAddressDetectionTimeout (int): DAD超时时间, 默认值: 0.5, 范围: 0-60

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = edit_dhcp_server(dhcpServerSession)
    """
    result = renix.edit_dhcp_server(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def create_dhcp_server_custom_option(Session, Upper, **kwargs):
    """
    创建DHCPv4服务端option对象

    Args:

        Session (DhcpServer): DHCPv4服务端协议会话对象

        Upper (DhcpServer or Dhcpv4AddressPool): DHCPv4服务端协议会话对象或DHCPv4地址池

    Keyword Args:

        OptionTag (number): option可选项类型标识, 默认值: 0, 取值范围: 0-255

        OptionType (Dhcpv4OptionType): option可选项数据类型, 默认值: Dhcpv4OptionType.Hex, 支持的有: 

            Dhcpv4OptionType.Hex
            
            Dhcpv4OptionType.String
            
            Dhcpv4OptionType.Boolean
            
            Dhcpv4OptionType.Int8
            
            Dhcpv4OptionType.Int16
            
            Dhcpv4OptionType.Int32
            
            Dhcpv4OptionType.Ip

        EnableOptionValueList (bool): 是否启用option可选项值列表, 默认值: False

        OptionValue (str): option可选项值, 默认值: ""

        MessageType (List[Dhcpv4ServerOptionMessageType]): 携带Option消息类型, 默认值: [Dhcpv4ServerOptionMessageType.Offer, Dhcpv4ServerOptionMessageType.Ack], 支持的有:

            Dhcpv4ServerOptionMessageType.Offer
            Dhcpv4ServerOptionMessageType.Ack
            Dhcpv4ServerOptionMessageType.Nak
    

    Returns:

        Dhcpv4ServerOption: DHCPv4服务端option对象

    Examples:
        python:

    .. code:: python

        dhcpv4ServerOption = create_dhcp_server_custom_option(Session=dhcpServerSession)
    """

    result = renix.create_dhcp_server_custom_option(
        Session=Session, Upper=Upper, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def create_dhcp_server_address_pool(Sessions, **kwargs):
    """
    创建DHCPv4服务端协议会话对象地址池

    Args:

        Sessions (List[DhcpServer] or DhcpServer): DHCPv4服务端协议会话对象列表或单个DHCPv4服务端协议会话对象

    Keyword Args:

        Name (str): DHCP Server协议会话名称

        PoolAddressStart (str): 起始IPv4地址, 默认值: 1.1.1.2

        PoolAddressStep (str): IPv4地址步长, 默认值: 0.0.0.1

        PrefixLength (int): IPv4前缀长度, 默认值: 24, 范围: 0-32

        RouterList (list[str]): IPv4网关列表, 默认值: ""

        LimitPoolCount (bool): 限制地址池个数, 默认值: True

        PoolAddressCount (int): 地址池地址个数, 默认值: 255, 范围: 0-4294967295

        DomainName (str): 域名, 默认值: ""

        DnsList (list[str]): DNS地址列表, 默认值: ""
    
    Returns:

        Dhcpv4AddressPool: DHCPv4服务端协议会话地址池对象

    Examples:
        python:

    .. code:: python

        dhcpv4AddressPool = create_dhcp_server_address_pool(dhcpServerSession)
    """

    result = renix.create_dhcp_server_address_pool(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_dhcp_server_port_config(Ports, **kwargs):
    """
    修改DHCPv4服务端协议会话端口配置

    Args:

        Ports (List[Port] or Port): 测试仪表端口Port对象列表或单个测试仪表端口Port对象

    Keyword Args:
        
        RenewRate (int): 强制单播续租速度, 默认值: 100, 范围: 1-65535

        MaxOutstanding (int): 最大请求个数, 默认值: 1000, 范围: 1-65535
    
    Returns:

        Dhcpv4ServerPortConfig: DHCPv4服务端协议会话端口配置对象

    Examples:
        python:

    .. code:: python

        dhcpServerPortConfig = edit_dhcp_server_port_config(dhcpServerSession)
    """

    result = renix.edit_dhcp_server_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_force_renew(Sessions):
    """
    DHCPv4服务端协议会话对象强制单播续租

    Args:

        Sessions (List[DhcpServer] or DhcpServer): DHCPv4服务端协议会话对象列表或单个DHCPv4服务端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_force_renew(dhcpServerSession)
    """

    result = renix.dhcp_force_renew(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def dhcp_abort_server(Sessions):
    """
    DHCPv4服务端协议会话对象中断

    Args:

        Sessions (List[DhcpServer] or DhcpServer): DHCPv4服务端协议会话对象列表或单个DHCPv4服务端协议会话对象

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = dhcp_abort_server(dhcpServerSession)
    """

    result = renix.dhcp_abort_server(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

"""测试仪表协议配置参数模块

测试仪表协议配置和常用功能:
create_igmp: 创建IGMP协议会话对象;

edit_igmp: 修改IGMP协议会话对象参数;

select_source_interface: 将IGMP协议会话组播组过滤源地址绑定到指定Interface;

igmp_send_report: IGMP协议会话对象加入组;

igmp_send_leave: IGMP协议会话对象离开组;

igmp_resend_report: IGMP协议会话对象重新加入组;

create_igmp_querier: 创建IGMP Querier协议会话对象;

edit_igmp_querier: 编辑IGMP Querier协议会话对象;

apply_igmp_querier: 应用IGMP Querier协议会话对象;
"""

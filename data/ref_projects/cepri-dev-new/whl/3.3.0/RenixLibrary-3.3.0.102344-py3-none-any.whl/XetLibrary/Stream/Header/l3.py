"""
edit_header_ipv4: 修改测试仪表流量模板中IPv4报文头部内容;

edit_header_ipv4_option: 修改测试仪表流量模板中IPv4报文头部内容;

edit_header_ipv6: 修改测试仪表流量模板中IPv6报文头部内容;

edit_header_ipv6_fragment: 修改测试仪表流量模板中IPv6 Fragment报文头部内容;

edit_header_ipv6_routing: 修改测试仪表流量模板中IPv6 Routing报文头部内容;

edit_header_ipv6_authentication: 修改测试仪表流量模板中IPv6 Authentication报文头部内容;

edit_header_ipv6_destination: 修改测试仪表流量模板中IPv6 Destination报文头部内容;

edit_header_ipv6_destination_option: 修改测试仪表流量模板中Ipv6 Destination报文中头部Options内容;

edit_header_ipv6_destination_bier_bit_string: 修改测试仪表流量模板中Ipv6 Destination报文头部Bier Option中的bit string内容;

edit_header_ipv6_encapsulation: 修改测试仪表流量模板中IPv6 Encapsulation报文头部内容;

edit_header_ipv6_hopbyhop: 修改测试仪表流量模板中IPv6 Hopbyhop报文头部内容;

edit_header_ipv6_hopbyhop_option: 修改测试仪表流量模板中Ipv6 Hopbyhop报文中头部Options内容;

edit_header_ipv6_sr: 修改测试仪表流量模板中IPv6 Sr报文头部内容;

edit_header_ipv6_sr_option: 修改测试仪表流量模板中Ipv6 Sr报文中头部Options内容;

"""

import sys
from renix_py_api.api_gen import StreamTemplate
from XetLibrary.Encryption.data import (
    renix,
    Ipv4HeaderOptionsType,
    HeaderOptionType,
    Ipv6DestinationHeaderOptionsType,
    Ipv6HopbyhopHeaderOptionsType,
    Ipv6SrHeaderOptionsType,
)
from robot.api import ContinuableFailure, Failure


def edit_header_ipv4(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv4报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的vlan头部在流量模板中所有IPv4头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        Version (int): Version, 默认值: 4, 取值范围: 0<=Level<=15

        HeadLen (int): Header Length, 默认值: <AUTO>5, 取值范围: 0<=Level<=15

        TotalLength (int): Total Length, 默认值: <AUTO>20, 取值范围: 0<=Level<=65535

        Flags (bit): Flags, 默认值: 000, 取值范围: 000<=Level<=111

        ID (int): Identification, 默认值: <AUTO>123, 取值范围: 0<=Level<=65535

        Offset (int): Fragment Offset, 默认值: 0, 取值范围: 0<=Level<=8191

        TTL (int): TTL, 默认值: 128, 取值范围: 0<=Level<=255

        Protocol (int): Protocol, 默认值: 235, 取值范围: 0<=Level<=255

        Checksum (hex): Checksum, 默认值: 0000, 取值范围: 0000<=Level<=FFFF

        Source (str): Source Address, 默认值: 192.168.0.2, 取值范围: 有效的ipv4地址

        Destination (str): Destination Address, 默认值: 192.168.0.10, 取值范围: 有效的ipv4地址

        Padding (hex): IPv4 Padding, 默认值: 000000, 取值范围: 长度0-3字节的十六进制数

        Gateway (str): Gateway Address, 默认值: 192.168.0.1, 取值范围: 有效的ipv4地址

        Tos (int): Tos, 默认值: 0, 取值范围: 0<=Level<=255

        TosPrecedence (bit): Tos Precedence, 默认值: 000, 取值范围: 000<=Level<=111

        TosDelay (bit): Tos Delay, 默认值: 0, 取值范围: 0<=Level<=1

        TosThroughput (bit): Tos Throughput, 默认值: 0, 取值范围: 0<=Level<=1

        TosReliability (bit): Tos Reliability, 默认值: 0, 取值范围: 0<=Level<=1

        TosMonetaryCost (bit): Tos Monetary Cost, 默认值: 0, 取值范围: 0<=Level<=1

        TosReserved (bit): Tos Reserved, 默认值: 0, 取值范围: 0<=Level<=1

        DiffserveCodepointPrecedence (bit): DSCP Codepoint Precedence, 默认值: 000000, 取值范围: 000000<=Level<=111111

        DiffserveClassSelectorPrecedence (bit): DSCP Class Selector Precedence, 默认值: 000, 取值范围: 000<=Level<=111

        DiffserveClassSelectorDrop (bit): DSCP Class Selector Drop Precedence, 默认值: 00, 取值范围: 00<=Level<=11

        DiffserveClassSelectorUndefine (bit): DSCP Class Selector Drop Undefined, 默认值: 0, 取值范围: 0<=Level<=1

        DiffserveEcn (bit): ECN Setting, 默认值: 00, 取值范围: 00<=Level<=11

        TosByte (hex): Tos Byte Data, 默认值: 00, 取值范围: 00<=Level<=FF

        HeaderOption (list[Ipv4HeaderOptionsType]): 插入HeaderOption字段, 支持传入列表, 支持的参数有:

            Ipv4HeaderOptionsType.EndOfOption

            Ipv4HeaderOptionsType.Nop

            Ipv4HeaderOptionsType.Security

            Ipv4HeaderOptionsType.LooseSourceRoute

            Ipv4HeaderOptionsType.StrictSourceRoute

            Ipv4HeaderOptionsType.RouterAlert

            Ipv4HeaderOptionsType.RecordRoute

            Ipv4HeaderOptionsType.TimeStamp

            Ipv4HeaderOptionsType.StreamIdentifier

            Ipv4HeaderOptionsType.General

    Returns:

        dict: eg::

            {
                'Version': 'version',
                'HeadLen': 'headLen',
                'TotalLength': 'totalLength',
                'ID': 'id',
                'Flags': 'flags',
                'Offset': 'offset',
                'TTL': 'ttl',
                'Protocol': 'protocol',
                'Checksum': 'checksum',
                'Source': 'source',
                'Destination': 'destination',
                'Padding': 'padding',
                'Gateway': 'gateway',
                'Tos': 'tos',
                'TosPrecedence': 'tos.tos.precedence',
                'TosDelay': 'tos.tos.delay',
                'TosThroughput': 'tos.tos.throughput',
                'TosReliability': 'tos.tos.reliability',
                'TosMonetaryCost': 'tos.tos.monetaryCost',
                'TosReserved': 'tos.tos.reserved',
                'DiffserveCodepointPrecedence': 'tos.diffServe.dscp.codePoint.precedence',
                'DiffserveClassSelectorPrecedence': 'tos.diffServe.dscp.classSelector.precedence',
                'DiffserveClassSelectorDrop': 'tos.diffServe.dscp.classSelector.drop',
                'DiffserveClassSelectorUndefine': 'tos.diffServe.dscp.classSelector.undefine',
                'DiffserveEcn': 'tos.diffServe.ecnSetting',
                'TosByte': 'tos.tosByte.data',
                'HeaderOption': True
            }

    Examples:
        python:

    .. code:: python

        stream = add_stream(Port=port1)
        create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv4, StreamHeaderType.Tcp])
        attr = edit_header_ipv4(Stream=stream, Level=0, Source=192.168.1.1, HeaderOption=[Ipv4HeaderOptionsType.RouterAlert, Ipv4HeaderOptionsType.EndOfOption])
        edit_modifier(Stream=stream, Level=0, Attribute=attr[Source], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv4(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv4_option(Stream, Option, Level=0, Index=0, Header="ipv4", **kwargs):
    """
    修改测试仪表流量模板中IPv4报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Option (Ipv4HeaderOptionsType): HeaderOption字段, 支持的参数有:

            Ipv4HeaderOptionsType.EndOfOption

            Ipv4HeaderOptionsType.Nop

            Ipv4HeaderOptionsType.Security

            Ipv4HeaderOptionsType.LooseSourceRoute

            Ipv4HeaderOptionsType.StrictSourceRoute

            Ipv4HeaderOptionsType.RouterAlert

            Ipv4HeaderOptionsType.RecordRoute

            Ipv4HeaderOptionsType.TimeStamp

            Ipv4HeaderOptionsType.StreamIdentifier

            Ipv4HeaderOptionsType.General

        Level (int): 要修改的IPv4头部在流量模板中所有IPv4头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        Index (int): 要修改的IPv4 Option头部在流量模板中所有IPv4 Option的序列号, 默认值: 0, 范围: 0<=Index<=65535

        Header (HeaderOptionType): 要修改的流量头部, 默认修改ipv4头部对象:HeaderOptionType.Ipv4, 支持头部对象包括:

            HeaderOptionType.Ipv4

            HeaderOptionType.Destunreach

            HeaderOptionType.Parameterproblem

            HeaderOptionType.Redirect

            HeaderOptionType.Sourcequench

            HeaderOptionType.Timeexceeded

    Keyword Args:

        EndOfOption类型支持:

            Optiontype (int): Option Type, 默认值: 0, 取值范围: 0<=Optiontype<=255

        Nop类型支持:

            Optiontype (int): Option Type, 默认值: 1, 取值范围: 0<=Optiontype<=255

        Security类型支持:

            Optiontype (int): Option Type, 默认值: 130, 取值范围: 0<=Optiontype<=255

            Length (int): Length, 默认值: <AUTO>11, 取值范围: 0<=Length<=255

            Security (int): Security, 默认值: 0, 取值范围: 0<=Security<=65535

            Compartments (int): Compartments, 默认值: 0, 取值范围: 0<=Compartments<=65535

            HandlingRestrictions (int): Handling Restrictions, 默认值: 1, 取值范围: 0<=HandlingRestrictions<=65535

            TxControlCode (int): Transmission Control Code, 默认值: 0, 取值范围: 0<=TxControlCode<=16777215

        LooseSourceRoute类型支持:

            Optiontype (int): Option Type, 默认值: 131, 取值范围: 0<=Index<=255

            Length (int): Length, 默认值: <AUTO>0, 取值范围: 0<=Index<=255

            Pointer (int): Pointer, 默认值: 4, 取值范围: 0<=Index<=255

            AddressList (list[str]): IPv4 Address List, 默认值: [], 取值范围: 有效的ipv4地址

        StrictSourceRoute类型支持:

            Optiontype (int): Option Type, 默认值: 137, 取值范围: 0<=Optiontype<=255

            Length (int): Length, 默认值: <AUTO>0, 取值范围: 0<=Length<=255

            Pointer (int): Pointer, 默认值: 4, 取值范围: 0<=Pointer<=255

            AddressList (list[str]): IPv4 Address List, 默认值: [], 取值范围: 有效的ipv4地址

        RouterAlert类型支持:

            Optiontype (int): Option Type, 默认值: 148, 取值范围: 0<=Optiontype<=255

            Length (int): Length, 默认值: <AUTO>4, 取值范围: 0<=Length<=255

            RouterAlertValue (int): Router Alert Value, 默认值: 0, 取值范围: 0<=RouterAlertValue<=65535

        RecordRoute类型支持:

            Optiontype (int): Option Type, 默认值: 7, 取值范围: 0<=Optiontype<=255

            Length (int): Length, 默认值: <AUTO>0, 取值范围: 0<=Length<=255

            Pointer (int): Pointer, 默认值: 4, 取值范围: 0<=Pointer<=255

            AddressList (list(str)): IPv4 Address List, 默认值: [], 取值范围: 有效的ipv4地址

        TimeStamp类型支持:

            Optiontype (int): Option Type, 默认值: 7, 取值范围: 0<=Optiontype<=255

            Length (int): Length, 默认值: <AUTO>0, 取值范围: 0<=Length<=255

            Pointer (int): Pointer, 默认值: 4, 取值范围: 0<=Pointer<=255

            Overflow (int): Overflow, 默认值: 0, 取值范围: 0<=Overflow<=15

            Flag (int): Flag, 默认值: 0, 取值范围: 0<=Flag<=15

            TimeStamp (hex): Time Stamp, 默认值: 00000000, 取值范围: 00000000<=TimeStamp<=FFFFFFFF

            TimeStampSet (list(hex)): Time Stamp List, 默认值: [], 列表元素取值范围: 00000000<=TimeStampSet<=FFFFFFFF

        StreamIdentifier类型支持:

            Optiontype (int): Option Type, 默认值: 136, 取值范围: 0<=Optiontype<=255

            Length (int): Length, 默认值: <AUTO>4, 取值范围: 0<=Length<=255

            SystemId (int): System ID, 默认值: 0, 取值范围: 0<=SystemId<=65535

        General类型支持:

            Type (int): Option Type, 默认值: 0, 取值范围: 0<=Type<=255

            Length (int): Length, 默认值: <AUTO>2, 取值范围: 0<=Length<=255

            Value (hex): Option Value, 默认值: "", 取值范围: 长度0-40字节的十六进制数
    Returns:

        dict: eg::

            {
                'Security': 'ipv4HeaderOption.ipv4HeaderOptionList_0.optionSecurity.security',
                'Length': 'ipv4HeaderOption.ipv4HeaderOptionList_1.optionRouterAlert.length',
                'AddressList, 1.1.1.1': 'ipv4HeaderOption.ipv4HeaderOptionList_2.optionLooseSourceRoute.addressList.ipv4AddrContainer_0.ipv4Addr',
                'AddressList, 2.2.2.2': 'ipv4HeaderOption.ipv4HeaderOptionList_2.optionLooseSourceRoute.addressList.ipv4AddrContainer_1.ipv4Addr'
            }

    Examples:
        python:

    .. code:: python

        stream = add_stream(Port=port1)
        create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv4, StreamHeaderType.Tcp])
        attr = edit_header_ipv4(Stream=stream, Level=0, Source=192.168.1.1, HeaderOption=[Ipv4HeaderOptionsType.RouterAlert, Ipv4HeaderOptionsType.EndOfOption])
        edit_modifier(Stream=stream, Level=0, Attribute=attr[Source], Type=Increment, Count=10, Step=2)
        attr = edit_header_ipv4_option(Stream=stream, Option=RouterAlert, routerAlertValue=5)
        edit_modifier(Stream=stream, Level=0, HeaderType=HeaderOptionType.Ipv4, Attribute=attr[routerAlertValue], Type=Decrement, Count=3, Step=2)
    """

    result = renix.edit_header_ipv4_option(
        Stream=Stream, Option=Option, Level=Level, Index=Index, Header=Header, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6头部在流量模板中所有IPv6头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        Version (int): Version, 默认值: 6, 取值范围: 0<=Version<=15

        TrafficClass (int): Traffic Class, 默认值: 0, 取值范围: 0<=TrafficClass<=255

        FlowLabel (int): Flow Label, 默认值: 0, 取值范围: 0<=FlowLabel<=1048575

        PayloadLength (int): Payload Length, 默认值: 0, 取值范围: 0<=PayloadLength<=65535

        NextHeader (int): Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        HopLimit (int): Hop Limit, 默认值: 255, 取值范围: 0<=HopLimit<=255

        Source (str): Source Address, 默认值: 2001::2, 取值范围: 有效的ipv6地址

        Destination (str): Destination Address, 默认值: 2001::1:f1:11, 取值范围: 有效的ipv6地址

        Gateway (str): Gateway Address, 默认值: 2001::1, 取值范围: 有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Version': 'version',
                'TrafficClass': 'trafficClass',
                'FlowLabel': 'FlowLabel',
                'PayloadLength': 'payloadLength',
                'NextHeader': 'nextHeader',
                'HopLimit': 'hopLimit',
                'Source': 'source',
                'Destination': 'destination',
                'Gateway': 'gateway'
            }

    Examples:
        python:

    .. code:: python

        stream = add_stream(Port=port1)
        create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv6])
        attr = edit_header_ipv6(Stream=stream, Level=0, Source='2000::1')
        edit_modifier(Stream=stream, Level=0, Attribute=attr[Source], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_fragment(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6 Fragment报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6 Fragment头部在流量模板中所有IPv6 Fragment头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        NextHeader (int): Fragment Header Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        Reserved1 (int): Reserved, 默认值: 0, 取值范围: 0<=Reserved1<=255

        FragOffset (int): Fragment Offset, 默认值: 0, 取值范围: 0<=FragOffset<=8191

        Reserved2 (hex): Reserved, 默认值: 00, 取值范围: 00<=Reserved2<=11

        Mflag (bit): More Flag, 默认值: 0, 取值范围: 0<=Mflag<=1

        Ident (int): Identification, 默认值: 255, 取值范围: 0<=Ident<=4294967295

    Returns:

        dict: eg::

            {
                'NextHeader': 'nextHeader',
                'Reserved1': 'reserved1',
                'FragOffset': 'fragOffset',
                'Reserved2': 'reserved2',
                'Mflag': 'm_flag',
                'Ident': 'ident'
            }

    Examples:
        python:

    .. code:: python

        attr = edit_header_ipv6_fragment(Stream=stream, Level=0, NextHeader=10)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[NextHeader], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6_fragment(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_routing(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6 Routing报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6 Routing头部在流量模板中所有IPv6 Routing头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        NextHeader (int): Routing Header Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        Length (int): Routing Header Length, 默认值: 0, 取值范围: 0<=Length<=255

        RoutingType (int): Routing Type, 默认值: 0, 取值范围: 0<=RoutingType<=255

        SegLeft (hex): Segments Left, 默认值: 0, 取值范围: 0<=SegLeft<=255

        Reserved (bit): Reserved, 默认值: 0, 取值范围: 0<=Reserved<=4294967295

        Nodes (list[str]): Nodes IPv6 Address, 默认值: []

    Returns:

        dict: eg::

            {
                'NextHeader': 'nextHeader',
                'Length': 'length',
                'RoutingType': 'routingType',
                'SegLeft': 'segLeft',
                'Reserved': 'reserved',
                'Nodes_2022::2': 'node.Ipv6Address_0.value'
            }

    Examples:
        python:

    .. code:: python

        attr = edit_header_ipv6_routing(Stream=stream, Level=0, NextHeader=10)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[NextHeader], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6_routing(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_authentication(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6 Authentication报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6 Authentication头部在流量模板中所有IPv6 Authentication头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        NextHeader (int): Authentication Header Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        Length (int): Authentication Header Length, 默认值: 0, 取值范围: 0<=Length<=255

        Reserved (int): Reserved, 默认值: 0, 取值范围: 0<=Reserved<=65535

        Spi (hex): Security Parameter Index, 默认值: 0, 取值范围: 0<=Spi<=4294967295

        SeqNum (bit): Sequence Number, 默认值: 0, 取值范围: 0<=SeqNum<=4294967295

        AuthData (hex): Authentication Data, 默认值: 0000, 取值范围: 长度2-128字节的十六进制数

        Pad (hex): 8 Byte Alignment Padding, 默认值: <Auto>0000, 取值范围: 长度0-7字节的十六进制数

    Returns:

        dict: eg::

            {
                'NextHeader': 'nextHeader',
                'Length': 'length',
                'Reserved': 'reserved',
                'Spi': 'spi',
                'SeqNum': 'seqNum',
                'AuthData': 'authData'
                'Pad': 'pad'
            }

    Examples:
        python:

    .. code:: python

        attr = edit_header_ipv6_authentication(Stream=stream, Level=0, NextHeader=10)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[NextHeader], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6_authentication(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_destination(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6 Destination报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6 Destination头部在流量模板中所有IPv6 Destination头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        NextHeader (int): Destination Header Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        Length (int): Destination Header Length, 默认值: 0, 取值范围: 0<=Length<=255

        Pad (hex): 8 Byte Alignment Padding, 默认值: <Auto>000000000000, 取值范围: 长度0-7字节的十六进制数

        OptionHeaders (list[Ipv6DestinationHeaderOptionsType]): 支持的参数有:

            Ipv6DestinationHeaderOptionsType.Pad1

            Ipv6DestinationHeaderOptionsType.PadN

            Ipv6DestinationHeaderOptionsType.GeneralTLV

            Ipv6DestinationHeaderOptionsType.Bierv6

    Returns:

        dict: eg::

            {
                'NextHeader': 'nextHeader',
                'Length': 'length',
                'Pad': 'pad'
                'OptionHeaders': True
            }

    Examples:
        python:

    .. code:: python

        attr = edit_header_ipv6_destination(Stream=stream, Level=0, NextHeader=10, OptionHeaders=[Ipv6DestinationHeaderOptionsType.Pad1])
        edit_modifier(Stream=stream, Level=0, Attribute=attr[NextHeader], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6_destination(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_destination_option(Stream, Option, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Ipv6 Destination报文中头部Options内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Option (Ipv6DestinationHeaderOptionsType): IPv6 Options, 取值范围:

            Ipv6DestinationHeaderOptionsType.Pad1

            Ipv6DestinationHeaderOptionsType.PadN

            Ipv6DestinationHeaderOptionsType.GeneralTLV

            Ipv6DestinationHeaderOptionsType.Bierv6

        Level (int): 要修改的Ipv6 Destination头部在流量模板中所有Ipv6 Destination头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        Index (int): 要修改的Options头部在流量模板中所有Options头部的序列号, 默认值: 0, 范围: 0<=Index<=65535

    Keyword Args:

        pad1:

            Type (int): Pad 1 Option, 默认值: 0, 取值范围: 0<=Type<=255

        padN:

            Type (int): Pad N Option, 默认值: 0, 取值范围: 0<=Type<=255

            Length (int): Pad N Option Length, 默认值: 1, 取值范围: 0<=Type<=5

            Padding (hex): Pad N Option Padding, 默认值: 00, 取值范围: 长度为0-5字节的十六进制数

        generalTLV:

            Type (int): Custom Option Type, 默认值: 15, 取值范围: 0<=Index<=255

            Length (int): Custom Option Length, 默认值: 10, 取值范围: 0<=Index<=255

            Data (hex): Custom Data Padding, 默认值: 0102030405060708090A, 取值范围: 长度为0<=Level<=1024字节的十六进制数

        bierv6:

            Optiontype (int): Option Type, 默认值: 122, 取值范围: 0<=Optiontype<=255

            Optionlen (int): Option Length, 默认值: 0, 取值范围: 0<=Optionlen<=255

            BiftId (int): BIFT-ID, 默认值: 1, 取值范围: 0<=BiftId<=1048575

            TrafficClass (int): Traffic Class, 默认值: 0, 取值范围: 0<=TrafficClass<=7

            SBit (bit): sBit, 默认值: 1, 取值范围: 0<=SBit<=1

            Ttl (int): TTL, 默认值: 64, 取值范围: 0<=Ttl<=255

            Nibble (bit): Nibble, 默认值: 0101, 取值范围: 0000<=Nibble<=1111

            BierVer (int): Bier Version, 默认值: 0, 取值范围: 0<=BierVer<=15

            Bsl (int): BSL, 默认值: 4, 取值范围: 0<=Bsl<=15

            Entropy (int): Entropy, 默认值: 1, 取值范围: 0<=Entropy<=1048575

            Oam (int): OAM, 默认值: 0, 取值范围: 0<=Oam<=3

            Rsv (int): RSV, 默认值: 0, 取值范围: 0<=Rsv<=3

            Dscp (int): DSCP, 默认值: 0, 取值范围: 0<=Dscp<=63

            Protocol (int): Protocol, 默认值: 63, 取值范围: 0<=Protocol<=63

            BfirId (int): BFIR-ID, 默认值: 1, 取值范围: 0<=BfirId<=65535

            BierbitString (int): 要插入的BIER Bit Strings个数, 默认值: 0, 取值范围: 0<=BierbitString<=100

    Returns:

        dict: eg::

            {
                'Type': 'options.ipv6DestinationOptionList_1.padN.type',
                'Length': 'options.ipv6DestinationOptionList_1.padN.length',
                'Padding': 'options.ipv6DestinationOptionList_1.padN.padding'
            }

    Examples:
        .. code:: python

        edit_header_ipv6_destination(Stream=stream, Level=0, NextHeader=10, OptionHeaders=[Ipv6DestinationHeaderOptionsType.Pad1])
        edit_header_ipv6_destination_option(Stream=stream, Level=0, Ipv6DestinationHeaderOptionsType.Pad1, Type=1)
    """

    result = renix.edit_header_ipv6_destination_option(
        Stream=Stream, Option=Option, Level=Level, Index=Index, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_destination_bier_bit_string(
    Stream, Level=0, BierIndex=0, Index=0, **kwargs
):
    """
    修改测试仪表流量模板中Ipv6 Destination报文头部Bier Option中的bit string内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的Ipv6 Destination头部在流量模板中所有Ipv6 Destination头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        BierIndex (int): 要修改的Bier Option头部在流量模板中所有Bier Option头部的序列号, 默认值: 0, 范围: 0<=BierIndex<=65535

        Index (int): 要修改的bit string头部在流量模板中所有bit string头部的序列号, 默认值: 0, 范围: 0<=Index<=65535

    Keyword Args:

        bitString (bit): Bit String, 默认值: 01010101010101010101010101010101, 取值范围: 长度为32bit的二进制数

        bitString2 (bit): Bit String, 默认值: 01010101010101010101010101010101, 取值范围: 长度为32bit的二进制数

    Returns:

        dict: eg::

            {
                'BitString': 'options.ipv6DestinationOptionList_3.bierv6.bierbitString.customOption_1.bitStringsOption.bitString',
                'bitString2': 'options.ipv6DestinationOptionList_3.bierv6.bierbitString.customOption_1.bitStringsOption.bitString2'
            }

    Examples:
        .. code:: python

        edit_header_ipv6_destination(Stream=stream, Level=0, OptionHeaders=[Ipv6DestinationHeaderOptionsType.Bierv6])
        edit_header_ipv6_destination_option(Stream=stream, Level=0, Ipv6DestinationHeaderOptionsType.Pad1, Type=1)
        edit_header_ipv6_destination_bier_bit_string(Stream=stream, bitString='10101010101010101010101010101010')
    """

    result = renix.edit_header_ipv6_destination_bier_bit_string(
        Stream=Stream, BierIndex=BierIndex, Level=Level, Index=Index, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_encapsulation(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6 Encapsulation报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6 Encapsulation头部在流量模板中所有IPv6 Encapsulation头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        Spi (int): Security Parameter Index, 默认值: 0, 取值范围: 0<=Spi<=4294967295

        SeqNum (int): Sequence Number, 默认值: 0, 取值范围: 0<=SeqNum<=4294967295

        PayloadData (hex): Payload Data, 默认值: 0000, 取值范围: 长度2-128字节的十六进制数

        PadData (hex): Pad Data, 默认值: 00, 取值范围: 长度0-255字节的十六进制数

        Length (int): Pad Length, 默认值: 0, 取值范围: 0<=Length<=255

        NextHeader (int): Encapsulation Header Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        AuthData (hex): Authentication Data, 默认值: 0000, 取值范围: 长度2-128字节的十六进制数

        Pad (hex): 8 Byte Alignment Padding, 默认值: '', 取值范围: 长度0-7字节的十六进制数

    Returns:

        dict: eg:

            {
                'Spi': 'spi',
                'SeqNum': 'seqNum',
                'PayloadData': 'payloadData',
                'PadData': 'padData',
                'Length': 'length',
                'NextHeader': 'nextHeader',
                'AuthData': 'authData',
                'Pad': 'pad'
            }

    Examples:
        python:

    .. code:: python

        attr = edit_header_ipv6_encapsulation(Stream=stream, Level=0, NextHeader=10)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[NextHeader], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6_encapsulation(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_hopbyhop(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6 Hopbyhop报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6 Hopbyhop头部在流量模板中所有IPv6 Hopbyhop头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        NextHeader (int): Destination Header Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        Length (int): Destination Header Length, 默认值: 0, 取值范围: 0<=Length<=255

        Pad (hex): 8 Byte Alignment Padding, 默认值: Auto, 取值范围: 长度0-7字节的十六进制数

        OptionHeaders (list[Ipv6HopbyhopHeaderOptionsType]): 支持的参数有:

            Ipv6HopbyhopHeaderOptionsType.Pad1

            Ipv6HopbyhopHeaderOptionsType.PadN

            Ipv6HopbyhopHeaderOptionsType.RouterAlert

            Ipv6HopbyhopHeaderOptionsType.Jumbo

            Ipv6HopbyhopHeaderOptionsType.GeneralTLV

    Returns:

        dict: eg::

            {
                'NextHeader': 'nextHeader',
                'Length': 'length',
                'Pad': 'pad'
                'OptionHeaders': True
            }

    Examples:
        python:

    .. code:: python

        attr = edit_header_ipv6_hopbyhop(Stream=stream, Level=0, NextHeader=10)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[NextHeader], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6_hopbyhop(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_hopbyhop_option(Stream, Option, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Ipv6 Hopbyhop报文中头部Options内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Option (Ipv6HopbyhopHeaderOptionsType): IPv6 Options, 取值范围:

            Ipv6HopbyhopHeaderOptionsType.Pad1

            Ipv6HopbyhopHeaderOptionsType.PadN

            Ipv6HopbyhopHeaderOptionsType.RouterAlert

            Ipv6HopbyhopHeaderOptionsType.Jumbo

            Ipv6HopbyhopHeaderOptionsType.GeneralTLV

        Level (int): 要修改的Ipv6 Hopbyhop头部在流量模板中所有Ipv6 Hopbyhop头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        Index (int): 要修改的Options头部在流量模板中所有Options头部的序列号, 默认值: 0, 范围: 0<=Index<=65535

    Keyword Args:

        pad1:

            Type (int): Pad 1 Option, 默认值: 0, 取值范围: 0<=Type<=255

        padN:

            Type (int): Pad N Option, 默认值: 0, 取值范围: 0<=Type<=255

            Length (int): Pad N Option Length, 默认值: 1, 取值范围: 0<=Length<=5

            Padding (hex): Pad N Option Padding, 默认值: 00, 取值范围: 长度为0-5字节的十六进制数

        routerAlert:

            Type (int): Router Alert Option, 默认值: 5, 取值范围: 0<=Type<=255

            Length (int): Router Alert Option Length, 默认值: 2, 取值范围: 0<=Length<=255

            Value (int): Router Alert Option Value, 默认值: 0, 取值范围: 0<=Value<=65535

        jumbo:

            Type (int): Jumbo Payload Option, 默认值: 194, 取值范围: 0<=Type<=255

            Length (int): Jumbo Payload Option Length, 默认值: 4, 取值范围: 0<=Length<=5

            Data (int): Jumbo Payload Option Value, 默认值: 0, 取值范围: 0<=Data<=4294967295

        generalTLV:

            Type (int): Custom Option Type, 默认值: 15, 取值范围: 0<=Type<=255

            Length (int): Custom Option Length, 默认值: 10, 取值范围: 0<=Length<=255

            Data (hex): Custom Data Padding, 默认值: 0102030405060708090A, 取值范围: 长度为0-1024字节的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'options.ipv6HopByHopOptionList_0.pad1.type'
            }

    Examples:
        .. code:: python

        edit_header_ipv6_hopbyhop(Stream=stream, Level=0, OptionHeaders=Ipv6HopbyhopHeaderOptionsType.GeneralTLV)
        edit_header_ipv6_hopbyhop_option(Stream=stream, Option=Ipv6HopbyhopHeaderOptionsType.GeneralTLV, Data='FFFFFF')
    """

    result = renix.edit_header_ipv6_hopbyhop_option(
        Stream=Stream, Option=Option, Level=Level, Index=Index, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_sr(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IPv6 Sr报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的IPv6 Sr头部在流量模板中所有IPv6 Sr头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        NextHeader (int): Routing Header Next Header, 默认值: 59, 取值范围: 0<=NextHeader<=255

        Length (int): Routing Header Length, 默认值: 0, 取值范围: 0<=Length<=255

        RoutingType (int): Routing Type, 默认值: 4, 取值范围: 0<=RoutingType<=255

        SegLeft (int): Segments Left, 默认值: 0, 取值范围: 0<=SegLeft<=255

        LastEntry (int): Last Entry, 默认值: 0, 取值范围: 0<=LastEntry<=255

        SRHeaderFlag (bit): Routing Type, 默认值: 00000000, 取值范围: 长度为8的二进制数

        Tag (int): Tag, 默认值: 0, 取值范围: 0<=Tag<=65535

        SRHOption (list[Ipv6SrHeaderOptionsType]): 支持的参数有:

            Ipv6SrHeaderOptionsType.SRSegment

            Ipv6SrHeaderOptionsType.SRIngressNodeTlv

            Ipv6SrHeaderOptionsType.SREgressNodeTlv

            Ipv6SrHeaderOptionsType.SROpaqueContainerTlv

            Ipv6SrHeaderOptionsType.SRHmacTlv

            Ipv6SrHeaderOptionsType.SRPadding1Tlv

            Ipv6SrHeaderOptionsType.SRPaddingTlv

            Ipv6SrHeaderOptionsType.GeneralTLV

    Returns:

        dict: eg::

            {
                'NextHeader': 'nextHeader',
                'Length': 'length',
                'Pad': 'pad'
                'OptionHeaders': True
            }

    Examples:
        python:

    .. code:: python

        attr = edit_header_ipv6_sr(Stream=stream, Level=0, NextHeader=10, SRHOption=Ipv6SrHeaderOptionsType.GeneralTLV)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[NextHeader], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ipv6_sr(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_ipv6_sr_option(Stream, Option, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Ipv6 Sr报文中头部Options内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Option (Ipv6SrHeaderOptionsType): IPv6 Options, 取值范围:

            Ipv6SrHeaderOptionsType.SRSegment

            Ipv6SrHeaderOptionsType.SRIngressNodeTlv

            Ipv6SrHeaderOptionsType.SREgressNodeTlv

            Ipv6SrHeaderOptionsType.SROpaqueContainerTlv

            Ipv6SrHeaderOptionsType.SRHmacTlv

            Ipv6SrHeaderOptionsType.SRPadding1Tlv

            Ipv6SrHeaderOptionsType.SRPaddingTlv

            Ipv6SrHeaderOptionsType.GeneralTLV

        Level (int): 要修改的Ipv6 Sr头部在流量模板中所有Ipv6 Sr头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        Index (int): 要修改的Options头部在流量模板中所有Options头部的序列号, 默认值: 0, 范围: 0<=Index<=65535

    Keyword Args:

        sRSegment:

            Segment (str): Segment, 默认值: 2000::2, 取值范围: 有效的ipv6地址

        sRIngressNodeTlv:

            Type (int): Type, 默认值: 1, 取值范围: 0<=Type<=255

            Length (int): Length, 默认值: 18, 取值范围: 0<=Length<=255

            Reserved (int): Reserved, 默认值: 0, 取值范围: 0<=Reserved<=255

            Flags (int): Flags, 默认值: 0, 取值范围: 0<=Flags<=255

            IngressNode (str): Ingress Node, 默认值: 2000::2, 取值范围: 有效的ipv6地址

        sREgressNodeTlv:

            Type (int): Type, 默认值: 2, 取值范围: 0<=Type<=255

            Length (int): Length, 默认值: 18, 取值范围: 0<=Length<=255

            Reserved (int): Reserved, 默认值: 0, 取值范围: 0<=Reserved<=255

            Flags (int): Flags, 默认值: 0, 取值范围: 0<=Flags<=255

            EngressNode (str): Engress Node, 默认值: 2000::2, 取值范围: 有效的ipv6地址

        sROpaqueContainerTlv:

            Type (int): Type, 默认值: 3, 取值范围: 0<=Type<=255

            Length (int): Length, 默认值: 18, 取值范围: 0<=Length<=255

            Reserved (int): Reserved, 默认值: 0, 取值范围: 0<=Reserved<=255

            Flags (int): Flags, 默认值: 0, 取值范围: 0<=Flags<=255

            OpaqueContainer (str): Opaque Container, 默认值: 2000::2, 取值范围: 有效的ipv6地址

        sRHmacTlv:

            Type (int): Type, 默认值: 5, 取值范围: 0<=Type<=255

            Length (int): Length, 默认值: 38, 取值范围: 0<=Length<=255

            Reserved (int): Reserved, 默认值: 0, 取值范围: 0<=Reserved<=65535

            HmacKeyId (int): HMAC Key ID, 默认值: 0, 取值范围: 0<=HmacKeyId<=255

            hmac (hex): HMAC, 默认值: 0000000000000000000000000000000000000000000000000000000000000000, 取值范围: 长度为32字节的十六进制数

        sRPadding1Tlv:

            Type (int): Type, 默认值: 0, 取值范围: 0<=Type<=255

        sRPaddingTlv:

            Type (int): Type, 默认值: 4, 取值范围: 0<=Type<=255

            Length (int): Length, 默认值: 0, 取值范围: 0<=Length<=255

            Padding (hex): Padding, 默认值: 00, 取值范围: 长度为0-7的十六进制数

        generalTLV:

            Type (int): Custom Option Type, 默认值: 15, 取值范围: 0<=Type<=255

            Length (int): Custom Option Length, 默认值: 10, 取值范围: 0<=Length<=255

            Data (hex): Custom Data Padding, 默认值: 0102030405060708090A, 取值范围: 长度为0<=Level<=1024字节的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'options.ipv6HopByHopOptionList_0.pad1.type'
            }

    Examples:
        .. code:: python

        edit_header_ipv6_sr(Stream=stream, Level=0, NextHeader=10, SRHOption=Ipv6SrHeaderOptionsType.GeneralTLV)
        edit_header_ipv6_sr_option(Stream=stream, Option=Ipv6SrHeaderOptionsType.GeneralTLV, Data='FFFFFF')
    """

    result = renix.edit_header_ipv6_sr_option(
        Stream=Stream, Option=Option, Level=Level, Index=Index, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

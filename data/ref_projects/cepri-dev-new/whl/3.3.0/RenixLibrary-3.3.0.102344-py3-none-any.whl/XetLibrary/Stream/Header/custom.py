"""
edit_header_custom: 修改测试仪表流量模板中Custom报文头部内容;

"""

import sys

from renix_py_api.api_gen import StreamTemplate
from XetLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def edit_header_custom(Stream, Level=0, Index=None, **kwargs):
    """
    修改测试仪表流量模板中Custom报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的Custom头部在流量模板中所有Custom头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        Index (int): Custom头部在中需要修改pattern位于所有PatternByte和Checksum的序号, 默认值: 空, 范围: 0<=Index<=2

    Keyword Args:

        Pattern (list): Option Pattern, 默认值: 00, 列表元素取值范围: 长度1-16384字节的十六进制数

        Checksum (str): Option Checksum, 默认值: 0000, 取值范围: 0000-FFFF or AUTO

    Returns:

        dict: eg::

            {
                'Pattern': 'patternByte.customOption_0.customPatternByteOption.patternByteOption',
                'Checksum': 'patternByte.customOption_1.customChecksumOption.checksumOption'
            }

    Examples:
        python:

    .. code:: python

        create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv4, StreamHeaderType.Custom])
        edit_header_custom(Stream=stream, Pattern='1212121212')
        edit_header_custom(Stream=stream, Checksum='Auto')
        edit_header_custom(Stream=stream, Pattern='343434343', Checksum='Auto')
        attr = edit_header_custom(Stream=stream, Index=2, Pattern='1212121212')
        edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Custom, Attribute=attr[Pattern], Count=10)
    """

    result = renix.edit_header_custom(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

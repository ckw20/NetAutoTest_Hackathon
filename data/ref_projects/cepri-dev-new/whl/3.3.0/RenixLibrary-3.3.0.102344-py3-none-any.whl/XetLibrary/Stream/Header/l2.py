"""
edit_header_ethernet: 修改测试仪表流量模板中Ethernet报文头部内容;

edit_header_arp: 修改测试仪表流量模板中ARP报文头部内容;

edit_header_vlan: 修改测试仪表流量模板中vlan报文头部内容;

"""

import sys
from renix_py_api.api_gen import StreamTemplate
from XetLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def edit_header_ethernet(
    Stream, Level=0, DestMacAdd=None, SourceMacAdd=None, ProtocolType=None
):
    """
    修改测试仪表流量模板中Ethernet报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        DestMacAdd (str): 目的mac地址, 默认值: 00:00:00:13:40:20, 取值范围: 有效的mac地址

        SourceMacAdd (str): 源mac地址, 默认值: 00:00:00:12:30:10, 取值范围: 有效的mac地址

        ProtocolType (hex): 上层协议类型, 默认值: 88B5, 取值范围: 0000<=ProtocolType<=FFFF

    Returns:

        dict: eg::

            {
                'DestMacAdd': 'destMacAdd',
                'SourceMacAdd': 'sourceMacAdd',
                'ProtocolType': 'protocolType'
            }

    Examples:
        python:

    .. code:: python

        stream = add_stream(Port=port1)
        create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv4, StreamHeaderType.Tcp])
        attr = edit_header_ethernet(Stream=stream, Level=0, DestMacAdd=00:01:01:01:01:02)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[DestMacAdd], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_ethernet(
        Stream=Stream,
        Level=Level,
        DestMacAdd=DestMacAdd,
        SourceMacAdd=SourceMacAdd,
        ProtocolType=ProtocolType,
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_arp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中ARP报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        HardwareType (int): Hardware Type, 默认值: 1, 取值范围: 1<=HardwareType<=65535

        ProtocolType (hex): Protocol Type, 默认值: 0800, 取值范围: 0000<=ProtocolType<=FFFF

        HardwareSize (int): Hardware address Size, 默认值: 6, 取值范围: 0<=HardwareSize<=255

        ProtocolSize (int): Protocol address Size, 默认值: 4, 取值范围: 0<=ProtocolSize<=255

        Opcode (int): Opcode, 默认值: 1, 取值范围: 0<=Opcode<=65535

        SendMac (str): Sender MAC address, 默认值: 00:00:00:12:30:10, 取值范围: 有效的mac地址

        SendIpv4 (str): Sender IP address, 默认值: 192.168.0.1, 取值范围: 有效的ipv4地址

        TargetMac (str): Target MAC address, 默认值: 00:00:00:00:00:00, 取值范围: 有效的mac地址

        TargetIpv4 (str): Target IP address, 默认值: 0.0.0.0, 取值范围: 有效的ipv4地址

    Returns:

         dict: eg::

            {
                'HardwareType': 'hardwareType',
                'ProtocolType': 'protocolType',
                'HardwareSize': 'hardwareSize',
                'ProtocolSize': 'protocolSize',
                'Opcode': 'opcode',
                'SendMac': 'sendMac',
                'SendIpv4': 'sendIpv4',
                'TargetMac': 'targetMac',
                'TargetIpv4': 'targetIpv4'
            }

    Examples:
        python:

    .. code:: python

        stream = add_stream(Port=port1)
        create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Arp])
        attr = edit_header_arp(Stream=stream, Level=0, SendMac=00:00:01:01:01:01)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[SendMac], Type=Increment, Count=10, Step=2)

    """

    result = renix.edit_header_arp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_vlan(Stream, Level=0, ID=None, Priority=None, CFI=None, Protocol=None):
    """
    修改测试仪表流量模板中vlan报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

        Priority (int): vlan优先级, 默认值: 0, 取值范围: 0<=Priority<=7

        CFI (int): vlan cfi值, 默认值: 0, 取值范围: 0<=CFI<=1

        ID (int): vlan id, 默认值: 1, 取值范围: 1<=ID<=4095

        Protocol (hex): 上层协议类型, 默认值: 88B5, 取值范围: 0000<=ProtocolType<=FFFF

    Returns:

        dict: eg::

            {
                'Priority': 'priority',
                'CFI': 'cfi',
                'ID': 'id',
                'Protocol': 'protocol'
            }


    Examples:
        python:

    .. code:: python

        stream = add_stream(Port=port1)
        create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Vlan])
        attr = edit_header_arp(Stream=stream, Level=0, ID=4000)
        edit_modifier(Stream=stream, Level=0, Attribute=attr[ID], Type=Increment, Count=10, Step=2)
    """

    result = renix.edit_header_vlan(
        Stream=Stream, Level=Level, ID=ID, Priority=Priority, CFI=CFI, Protocol=Protocol
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

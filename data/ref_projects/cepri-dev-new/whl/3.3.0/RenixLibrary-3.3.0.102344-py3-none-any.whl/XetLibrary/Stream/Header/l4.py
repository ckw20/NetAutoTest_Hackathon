"""
edit_header_tcp: 修改测试仪表流量模板中TCP报文头部内容;

edit_header_udp: 修改测试仪表流量模板中UDP报文头部内容;

"""

import sys
from renix_py_api.api_gen import StreamTemplate
from XetLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def edit_header_tcp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中TCP报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的tcp头部在流量模板中所有tcp头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

        SourcePort (int): Source Port, 默认值: 1024, 取值范围: 0<=SourcePort<=65535

        DestPort (int): Destination Port, 默认值: 1024, 取值范围: 0<=DestPort<=65535

        SeqNum (int): Sequence Number, 默认值: 1024, 取值范围: 0<=SeqNum<=4294967295

        AckNum (int): Acknowledgment Number, 默认值: 1024, 取值范围: 0<=AckNum<=4294967295

        DataOffset (int): Data Offset, 默认值: 5, 取值范围: 0<=DataOffset<=15

        Reserved (bit): Reserved, 默认值: 000000, 取值范围: 000000<=Reserved<=111111

        Flags (bit): Flags, 默认值: 010000, 取值范围: 000000<=Flags<=111111

        WindowSize (int): Window Size, 默认值: 4096, 取值范围: 0<=WindowSize<=65535

        Checksum (hex): TCP Checksum, 默认值: 0000, 取值范围: 0000<=Level<=FFFF

        UrgentPointer (hex): Urgent Pointer, 默认值: 0000, 取值范围: 0000<=UrgentPointer<=FFFF

        Option (hex): TCP option, 默认值: "", 取值范围: 长度0<=Level<=40字节的十六进制数

    Returns:

        dict: eg::

            {
                'SourcePort': 'sourcePort',
                'DestPort': 'destPort',
                'SeqNum': 'seqNum',
                'AckNum': 'ackNum',
                'DataOffset': 'dataOffset',
                'Reserved': 'reserved',
                'Flags': 'flags',
                'WindowSize': 'windowSize',
                'Checksum': 'checksum',
                'UrgentPointer': 'urgentPointer',
                'Option': 'option'
            }

    Examples:
        .. code:: python

            edit_header_tcp(Stream=stream, Level=0, SourcePort=1024)
    """

    result = renix.edit_header_tcp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_header_udp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中UDP报文头部内容

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Level (int): 要修改的udp头部在流量模板中所有udp头部的序列号, 默认值: 0, 范围: 0<=Level<=65535

    Keyword Args:

            SourcePort (int): Source Port, 默认值: 1024, 取值范围: 0<=SourcePort<=65535

            DestPort (int): Destination Port, 默认值: 1024, 取值范围: 0<=DestPort<=65535

            Length (int): Length, 默认值: <AUTO>0, 取值范围: 0<=Length<=65535

            Checksum (hex): UDP Checksum, 默认值: 0000, 取值范围: 0000<=Checksum<=FFFF

    Returns:

        dict: eg::

            {
                'SourcePort': 'sourcePort',
                'DestPort': 'destPort',
                'Length': 'length',
                'Checksum': 'checksum'
            }

    Examples:
        .. code:: python

            edit_header_udp(Stream=stream, Level=0, SourcePort=1024)
    """

    result = renix.edit_header_udp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

"""测试仪表流量配置参数模块

测试仪表流量配置和常用功能: 
add_stream: 测试仪表创建流量;

edit_stream: 修改测试仪表流量模板参数;

create_stream_header: 创建流量报文头部;

edit_modifier: 修改测试仪表流量模板中指定报文字段的跳变域;

edit_modifier_link: 修改测试仪表流量模板中指定报文字段的跳变域的link;

select_rx_port: 选择流量的收端口;

start_stream: 测试仪表开始发送数据流;

stop_stream: 测试仪表停止发送数据流;

wait_stream_state: 等待测试仪表流量达到指定状态;

start_l2_learning: 启动测试仪表流量二层学习;

stop_l2_learning: 停止测试仪表流量二层学习;

start_l3_learning: 启动测试仪表流量三层ARP ND学习;

stop_l3_learning: 停止测试仪表流量三层ARP ND学习;

del_stream: 删除测试仪流量;

get_streams: 获取测试仪表流量对象;

start_stream_arp: 测试仪表启动接口ARP功能;

stop_stream_arp: 测试仪表停止接口ARP功能;

edit_stream_load_profile: 编辑测试仪表负载配置文件参数;
"""

import sys
from renix_py_api.api_gen import Port, StreamTemplate
from XetLibrary.Encryption.data import (
    renix,
    StreamType,
    StreamLayerType,
    StreamTrafficMeshModeType,
    StreamEndPointMappingType,
    StreamFrameLengthType,
    StreamPayloadType,
    StreamPayLoadValueType,
    StreamModifierType,
    StreamModifierStreamType,
    StreamLinkModifierType,
    StreamSelectRxPortModeType,
    StreamStartType,
    StreamStateType,
    StreamL2LearningType,
)
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def add_stream(
    Type=StreamType.Raw.value,
    Ports=None,
    Names=None,
    FilePath=None,
    IncludeCrc=True,
    SrcPoints=None,
    DstPoints=None,
    SrcInterface=None,
    DstInterface=None,
    Bidirection=None,
    Direction=None,
    Layer=None,
    TrafficMeshMode=None,
    EndpointMapping=None,
    AutoCreateTunnel=False,
    StreamOnly=None,
    **kwargs,
):
    """
    测试仪表创建流量

    Args:

        Type (StreamType): 创建绑定流类型, 默认值: StreamType.Raw, 支持raw流、binding流以及pcap文件导入流:

            StreamType.Raw

            StreamType.Binding

            StreamType.Pcap

        Ports (Port): raw流和pcap流参数, 端口对象, 测试仪表端口对象object列表

        Names (list[str]): raw流参数, 流量名称, 流量名称列表

        FilePath (str): pcap流参数, 当Type为pcap需要指定导入pcap文件的路径

        IncludeCrc (bool): pcap流参数, 当Type为pcap指定导入方式是否携带CRC, 布尔值Bool (范围: True / False)

        SrcInterface (list[str]): binding流参数, 指定源接口

        DstInterface (list[str]): binding流参数, 指定目的接口

        SrcPoints (list[str]): binding流参数, 指定源端点

        DstPoints (list[str]): binding流参数, 指定目的端点

        Bidirection (bool): 是否是能双向流量, 布尔值Bool (范围: True / False)

        Direction (str): binding流参数

        Layer (StreamLayerType): binding流参数, 指定接口网络层, 默认值: StreamLayerType.Ipv4, 支持值:

            StreamLayerType.Ethernetii

            StreamLayerType.Vlan

            StreamLayerType.Gre

            StreamLayerType.Ipv4

            StreamLayerType.Ipv6

        TrafficMeshMode (StreamTrafficMeshModeType): binding流参数, 默认值: StreamTrafficMeshModeType.ManyToMany, 支持值:

            StreamTrafficMeshModeType.OneToOne

            StreamTrafficMeshModeType.ManyToMany

            StreamTrafficMeshModeType.FullMesh

            StreamTrafficMeshModeType.Congestion

            StreamTrafficMeshModeType.Learning

            StreamTrafficMeshModeType.BackBone

            StreamTrafficMeshModeType.Pair

        EndpointMapping (StreamEndPointMappingType): binding流参数, 默认值: StreamEndPointMappingType.RoundRobin, 支持值:

            StreamEndPointMappingType.RoundRobin

            StreamEndPointMappingType.ManyToMany

        AutoCreateTunnel (bool): binding流参数, 自动绑定隧道, 默认值: False

        StreamOnly (bool): True为每个flow创建一个stream,  False为多个flow创建一个stream, 默认值: False

    Returns:

        list (StreamTemplate): 创建的流量对象object列表

    Examples:
        .. code:: Python

            # raw流
            add_stream(Port=port)
            # pcap流
            add_stream(Port=port, Type=StreamType.Pcap, FilePath=path, IncludeCrc=True)
            # binding流
            add_stream(Port=port, Type=StreamType.Binding, SrcPoints=point1, DstPoints=point2, Bidirection=True)
    """

    result = renix.add_stream(
        Type=Type,
        Ports=Ports,
        Names=Names,
        FilePath=FilePath,
        IncludeCrc=IncludeCrc,
        SrcPoints=SrcPoints,
        DstPoints=DstPoints,
        SrcInterface=SrcInterface,
        DstInterface=DstInterface,
        Bidirection=Bidirection,
        Direction=Direction,
        Layer=Layer,
        TrafficMeshMode=TrafficMeshMode,
        EndpointMapping=EndpointMapping,
        AutoCreateTunnel=AutoCreateTunnel,
        StreamOnly=StreamOnly,
        **kwargs,
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_stream(Stream, **kwargs):
    """
    修改测试仪表流量模板参数

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

    Keyword Args:

        RepeatCount (int): 流模板发送重复次数, 默认值: 1, 支持值: 1<=RepeatCount<=4294967295

        EnableSignature (bool): 启用签名, 默认值: True

        FrameLengthType (StreamFrameLengthType): 流模板帧长度类型 类型为: string, 默认值: StreamFrameLengthType.Fixed, 支持值:

            StreamFrameLengthType.Fixed

            StreamFrameLengthType.Increment

            StreamFrameLengthType.Random

            StreamFrameLengthType.Auto

            StreamFrameLengthType.Decrement

            StreamFrameLengthType.Imix

        RandomLengthSeed (int): 随机种子, 类型为: number, 默认值: 10900842, 支持值: 0<=RandomLengthSeed<=4294967295

        FixedLength (int): 固定帧长, 默认值: 128, 支持值: 12<=FixedLength<=16383

        MinLength (int): 最小帧长, 默认值: 128, 支持值: 12<=MinLength<=16383

        MaxLength (int): 最大帧长, 默认值: 256, 支持值: 12<=MaxLength<=16383

        StepLength (int): 帧长跳变步长, 默认值: 1, 支持值: 1<=StepLength<=8192

        PayloadType (StreamPayloadType): 净荷类型, 默认值: StreamPayloadType.Cycle, 支持值:

            StreamPayloadType.Cycle

            StreamPayloadType.Increment

            StreamPayloadType.Random

        PayloadValue (str): 帧长跳变步长, 默认值: 0x0

        PayloadValueType (StreamPayLoadValueType): 净荷类型, 默认值: StreamPayLoadValueType.SingleByte, 支持值:

            StreamPayLoadValueType.SingleByte

            StreamPayLoadValueType.DoubleByte

        EnableNDResponse (bool): 使用ARP ND自动回复, 默认值: False

        TopLayerType (StreamLayerType): 流模板报文模板类型, 默认值: StreamLayerType.Ipv4, 支持值:

            StreamLayerType.Ethernetii

            StreamLayerType.Vlan

            StreamLayerType.Gre

            StreamLayerType.Ipv4

            StreamLayerType.Ipv6

        RxPorts (list[Port]): 指定流量收端口

        TrafficMeshMode (StreamTrafficMeshModeType): binding流参数, 默认值: StreamTrafficMeshModeType.ManyToMany, 支持值:

            StreamTrafficMeshModeType.OneToOne

            StreamTrafficMeshModeType.ManyToMany

            StreamTrafficMeshModeType.FullMesh

            StreamTrafficMeshModeType.Congestion

            StreamTrafficMeshModeType.Learning

            StreamTrafficMeshModeType.BackBone

            StreamTrafficMeshModeType.Pair

        HostsMesh (StreamEndPointMappingType): binding流参数, 默认值: StreamEndPointMappingType.RoundRobin, 支持值:

            StreamEndPointMappingType.RoundRobin

            StreamEndPointMappingType.ManyToMany

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        .. code:: Python

            edit_stream(Stream=stream, TopLayerType=StreamHeaderType.Ethernetii, TrafficMeshMode=StreamTrafficMeshModeType.FullMesh)
    """

    result = renix.edit_stream(Stream=Stream, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def create_stream_header(Stream, HeaderTypes, Index=None):
    """
    创建流量报文头部

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Index (int): 报文头部创建在当前流量头部的序号, 类型为: number, 取值范围None或0-16383,当Index为None表示重新创建流量报文类型。绑定流需要指定该参数。

        HeaderTypes (list[StreamHeaderType]): 报文头部类型列表,类型为: list,支持的报文头部(不区分大小写):

            StreamHeaderType.Ethernetii: EthernetII Instance

            StreamHeaderType.Raw: Ethernet802.3 Raw Instance

            StreamHeaderType.Vlan: VLAN Instance

            StreamHeaderType.Vxlan: VXLAN Header Instance

            StreamHeaderType.Arp: ARP Instance

            StreamHeaderType.Gre: GRE Instance

            StreamHeaderType.Ipv4: IPv4 Instance

            StreamHeaderType.Ipv6: IPv6 Instance

            StreamHeaderType.Tcp: TCP Instance

            StreamHeaderType.Udp: UDP Instance

            StreamHeaderType.L2tpv2data: L2TPv2 Data Over UDP Instance

            StreamHeaderType.L2tpv2control: L2TPv2 Control Over UDP Instance

            StreamHeaderType.L2tpv3controloverip: L2TPv3 Control Over IP Instance

            StreamHeaderType.L2tpv3controloverudp: L2TPv3 Control Over UDP Instance

            StreamHeaderType.L2tpv3dataoverip: L2TPv3 Data Over IP Instance

            StreamHeaderType.L2tpv3dataoverudp: L2TPv3 Data Over UDP Instance

            StreamHeaderType.Dhcpv4server

            StreamHeaderType.Dhcpv4client

            StreamHeaderType.Dhcpv6client

            StreamHeaderType.Dhcpv6server

            StreamHeaderType.Ppp: PPP Instance

            StreamHeaderType.Pppoe: PPPoE Instance

            StreamHeaderType.Pppoediscovery: PPPoE Discovery Instance

            StreamHeaderType.Icmpv4echorequest: ICMPv4 EchoRequest Instance

            StreamHeaderType.Destunreach: ICMPv4 DestUnreach Instance

            StreamHeaderType.Icmpv4echoreply: ICMPv4 EchoReply Instance

            StreamHeaderType.Informationreply: ICMPv4 InformationReply Instance

            StreamHeaderType.Informationrequest: ICMPv4 InformationRequest Instance

            StreamHeaderType.Icmpv4parameterproblem: ICMPv4 ParameterProblem Instance

            StreamHeaderType.Icmpv4redirect: ICMPv4 Redirect Instance

            StreamHeaderType.Sourcequench: ICMPv4 SourceQuench Instance

            StreamHeaderType.Timeexceeded: ICMPv4 TimeExceeded Instance

            StreamHeaderType.Timestampreply: ICMPv4 TimestampReply Instance

            StreamHeaderType.Timestamprequest: ICMPv4 TimestampRequest Instance

            StreamHeaderType.Icmpmaskrequest: ICMPv4 Address Mask Request Instance

            StreamHeaderType.Icmpmaskreply: ICMPv4 Address Mask Reply Instance

            StreamHeaderType.Destinationunreachable: ICMPv6 DestinationUnreachable Instance

            StreamHeaderType.Icmpv6echoreply: ICMPv6 EchoReply Instance

            StreamHeaderType.Icmpv6echorequest: ICMPv6 EchoRequest Instance

            StreamHeaderType.Packettoobig: ICMPv6 PacketTooBig Instance

            StreamHeaderType.Icmpv6parameterproblem: ICMPv6 ParameterProblem Instance

            StreamHeaderType.Timeexceed: ICMPv6 TimeExceed Instance

            StreamHeaderType.Soutersolicit: Router Solicitation Instance

            StreamHeaderType.Souteradvertise: Router Advertisement Instance

            StreamHeaderType.Icmpv6redirect: Redirect Instance

            StreamHeaderType.Neighborsolicit: Neighbor Solicitation Instance

            StreamHeaderType.Neighboradvertise: Neighbor Advertisement Instance

            StreamHeaderType.Mldv1query: ICMPv6 MLDv1 Query Instance

            StreamHeaderType.Mldv1report: ICMPv6 MLDv1 Report Instance

            StreamHeaderType.Mldv1done: ICMPv6 MLDv1 Done Instance

            StreamHeaderType.Mldv2query: ICMPv6 MLDv2 Query Instance

            StreamHeaderType.Mldv2report: ICMPv6 MLDv2 Report Instance

            StreamHeaderType.Igmpv1: IGMPv1 Report Instance

            StreamHeaderType.Igmpv1query: IGMPv1 Query Instance

            StreamHeaderType.Igmpv2: IGMPv2 Report Instance

            StreamHeaderType.Igmpv2query: IGMPv2 Query Instance

            StreamHeaderType.Igmpv3report: IGMPv3 Report Instance

            StreamHeaderType.Igmpv3query: IGMPv3 Query Instance

            StreamHeaderType.Custom: Custom Instance

            StreamHeaderType.Ospfv2linkstateupdate: OSPFv2 Link State Updata Instance

            StreamHeaderType.Ospfv2linkstaterequest: OSPFv2 Link State Request Instance

            StreamHeaderType.Ospfv2databasedescription: OSPFv2 Database Description Instance

            StreamHeaderType.Ospfv2linkstateacknowledge: OSPFv2 Link State Acknowledge Instance

            StreamHeaderType.Ospfv2unknown: OSPFv2 Unknown Instance

            StreamHeaderType.Ospfv2hello: OSPFv2 Hello Instance

            StreamHeaderType.Mpls: MPLS Instance

            StreamHeaderType.L1csnpheader: ISIS-L1 CSNP Config Instance

            StreamHeaderType.Isisl1helloheader: ISIS-L1 Hello Config Instance

            StreamHeaderType.L1lspheader: ISIS-L1 LSP Config Instance

            StreamHeaderType.L1psnpheader: ISIS-L1 PSNP Config Instance

            StreamHeaderType.L2csnpheader: ISIS-L2 CSNP Config Instance

            StreamHeaderType.Isisl2helloheader: ISIS-L2 Hello Config Instance

            StreamHeaderType.L2lspheader: ISIS-L2 LSP Config Instance

            StreamHeaderType.L2psnpheader: ISIS-L2 PSNP Config Instance

            StreamHeaderType.P2phelloheader: ISIS P2P Hello Config Instance

            StreamHeaderType.Gtpv1: GTPv1 Instance

            StreamHeaderType.Gtpv1opt: GTPv1 Optional Fields Instance

            StreamHeaderType.Gtpv1exthdr: GTPv1 Extension Header

            StreamHeaderType.Gtpv1ext: GTPv1 Optional Fields and Extension Header Instance

            StreamHeaderType.Ipv6fragmentheader: IPv6 Fragment Header

            StreamHeaderType.Ipv6routingheader: IPv6 Routing Header

            StreamHeaderType.Ipv6authenticationheader: IPv6 Authentication Header

            StreamHeaderType.Ipv6destinationheader: IPv6 Destination Header

            StreamHeaderType.Ipv6encapsulationheader: IPv6 Encapsulation Header

            StreamHeaderType.Ipv6hopbyhopheader: IPv6 Hop By Hop Header

            StreamHeaderType.Ipv6srheader: IPv6 SR Header

            StreamHeaderType.Stag: Customer STag Ethernet

            StreamHeaderType.Encapethernetii: Encapsulated Customer EthernetII Instance

            StreamHeaderType.Encapbackboneeth: Encapsulated MAC-in-Mac

            StreamHeaderType.Itag: iTag Instance

            StreamHeaderType.MacInMAc: MAC-in-MAC Instance

            StreamHeaderType.Encapcustomereth: Encapsulated Customer Ethernet Instance

            StreamHeaderType.Portmanagement: ANCP Instance

            StreamHeaderType.Bier: BIER Instance

            StreamHeaderType.Ccm: Continuty Check Message (CCM)

            StreamHeaderType.Chdlc: Cisco HDLC Instance

            StreamHeaderType.Cw: Control Word Instance

            StreamHeaderType.Elsflogi: ELS FLOGI Instance

            StreamHeaderType.Ethernet8023: Ethernet802.3 Instance

            StreamHeaderType.Goose: Goose Instance

            StreamHeaderType.Logiclinkcontrol: LLC Header

            StreamHeaderType.Cfg: MSTP Config Instance

            StreamHeaderType.Pause: Pause Instance

            StreamHeaderType.Pfc: PFC Instance

            StreamHeaderType.Vntag: VN Tag Instance

            StreamHeaderType.Fc: Fibre Channel Instance

            StreamHeaderType.Chassisidtlv: LLDP Chassis ID TLV

            StreamHeaderType.Portidtlv: LLDP Port ID TLV

            StreamHeaderType.Ttltlv: LLDP Time To Live TLV

            StreamHeaderType.Endtlv: LLDP End TLV

            StreamHeaderType.Hsrtag: HSR Tag Instance

            StreamHeaderType.Prptag: PRP Tag Instance

            StreamHeaderType.Stag: R Tag Instance

            StreamHeaderType.Sctp: SCTP Instance

            StreamHeaderType.Trill: Thrill Instance

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        .. code:: Python

            create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv4, StreamHeaderType.Tcp])
    """

    result = renix.create_stream_header(
        Stream=Stream, HeaderTypes=HeaderTypes, Index=Index
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_modifier(Stream, Attribute, Level=0, Index=None, **kwargs):
    """
    修改测试仪表流量模板中指定报文字段的跳变域

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object, 类型为: object

        Attribute (str): 要修改的报文字段参数名称

        Level (int): 当HeaderType=None表示要修改的报文字段在流量模板中所有报文头部的序列号, 当HeaderType!=None表示要修改的报文字段在流量模板中所有相同类型报文头部的序列号, 默认值: 0, 支持值: 0<=RandomLengthSeed<=4294967295

        Index (int): 默认是None,  跳变编号, 默认值: 0, 支持值: 0<=RandomLengthSeed<=4294967295

    Keyword Args:

        Type (StreamModifierType): 跳变类型:

            StreamModifierType.Increment

            StreamModifierType.Decrement

            StreamModifierType.Random

            StreamModifierType.List

        Start (str): 跳变起始数据

        Count (int): 跳变数量, 支持值: 0<=Count<=4294967295

        Step (int): 跳变步长, 支持值: 0<=Step<=4294967295

        Repeat(int): 重复次数, 支持值: 0<=Repeat<=4294967295

        Range (int): 随机跳变范围, 支持值: 0<=Range<=4294967295

        Seed (int): 随机跳变种子, 支持值: 0<=Seed<=4294967295

        StreamType (StreamModifierStreamType): 流跳变类型, 支持:

            StreamModifierStreamType.IntraModifier

            StreamModifierStreamType.InterModifier

        Offset (int): 跳变偏移位, 支持值: 0<=RandomLengthSeed<=4294967295

        Mask (str): 跳变掩码

        List (list(str)): list跳变时, 跳变列表

        HeaderType (StreamHeaderType): 要跳变的报文头部名称, 默认是None, 如果HeaderType为None, 修改的报文头Level决定(要修改的报文字段在流量模板中所有报文头部的序列号), 支持:

            StreamHeaderType.Ethernetii: EthernetII Instance

            StreamHeaderType.Raw: Ethernet802.3 Raw Instance

            StreamHeaderType.Vlan: VLAN Instance

            StreamHeaderType.Vxlan: VXLAN Header Instance

            StreamHeaderType.Arp: ARP Instance

            StreamHeaderType.Gre: GRE Instance

            StreamHeaderType.Ipv4: IPv4 Instance

            StreamHeaderType.Ipv6: IPv6 Instance

            StreamHeaderType.Tcp: TCP Instancce

            StreamHeaderType.Udp: UDP Instance

            StreamHeaderType.L2tpv2data: L2TPv2 Data Over UDP Instance

            StreamHeaderType.L2tpv2control: L2TPv2 Control Over UDP Instance

            StreamHeaderType.L2tpv3controloverip: L2TPv3 Control Over IP Instance

            StreamHeaderType.L2tpv3controloverudp: L2TPv3 Control Over UDP Instance

            StreamHeaderType.L2tpv3dataoverip: L2TPv3 Data Over IP Instance

            StreamHeaderType.L2tpv3dataoverudp: L2TPv3 Data Over UDP Instance

            StreamHeaderType.Dhcpv4server

            StreamHeaderType.Dhcpv4client

            StreamHeaderType.Dhcpv6client

            StreamHeaderType.Dhcpv6server

            StreamHeaderType.Ppp: PPP Instance

            StreamHeaderType.Pppoe: PPPoE Instance

            StreamHeaderType.Pppoediscovery: PPPoE Discovery Instance

            StreamHeaderType.Icmpv4echorequest: ICMPv4 EchoRequest Instance

            StreamHeaderType.Destunreach: ICMPv4 DestUnreach Instance

            StreamHeaderType.Icmpv4echoreply: ICMPv4 EchoReply Instance

            StreamHeaderType.Informationreply: ICMPv4 InformationReply Instance

            StreamHeaderType.Informationrequest: ICMPv4 InformationRequest Instance

            StreamHeaderType.Icmpv4parameterproblem: ICMPv4 ParameterProblem Instance

            StreamHeaderType.Icmpv4redirect: ICMPv4 Redirect Instance

            StreamHeaderType.Sourcequench: ICMPv4 SourceQuench Instance

            StreamHeaderType.Timeexceeded: ICMPv4 TimeExceeded Instance

            StreamHeaderType.Timestampreply: ICMPv4 TimestampReply Instance

            StreamHeaderType.Timestamprequest: ICMPv4 TimestampRequest Instance

            StreamHeaderType.Icmpmaskrequest: ICMPv4 Address Mask Request Instance

            StreamHeaderType.Icmpmaskreply: ICMPv4 Address Mask Reply Instance

            StreamHeaderType.Destinationunreachable: ICMPv6 DestinationUnreachable Instance

            StreamHeaderType.Icmpv6echoreply: ICMPv6 EchoReply Instance

            StreamHeaderType.Icmpv6echorequest: ICMPv6 EchoRequest Instance

            StreamHeaderType.Packettoobig: ICMPv6 PacketTooBig Instance

            StreamHeaderType.Icmpv6parameterproblem: ICMPv6 ParameterProblem Instance

            StreamHeaderType.Timeexceed: ICMPv6 TimeExceed Instance

            StreamHeaderType.Soutersolicit: Router Solicitation Instance

            StreamHeaderType.Souteradvertise: Router Advertisement Instance

            StreamHeaderType.Icmpv6redirect: Redirect Instance

            StreamHeaderType.Neighborsolicit: Neighbor Solicitation Instance

            StreamHeaderType.Neighboradvertise: Neighbor Advertisement Instance

            StreamHeaderType.Mldv1query: ICMPv6 MLDv1 Query Instance

            StreamHeaderType.Mldv1report: ICMPv6 MLDv1 Report Instance

            StreamHeaderType.Mldv1done: ICMPv6 MLDv1 Done Instance

            StreamHeaderType.Mldv2query: ICMPv6 MLDv2 Query Instance

            StreamHeaderType.Mldv2report: ICMPv6 MLDv2 Report Instance

            StreamHeaderType.Igmpv1: IGMPv1 Report Instance

            StreamHeaderType.Igmpv1query: IGMPv1 Query Instance

            StreamHeaderType.Igmpv2: IGMPv2 Report Instance

            StreamHeaderType.Igmpv2query: IGMPv2 Query Instance

            StreamHeaderType.Igmpv3report: IGMPv3 Report Instance

            StreamHeaderType.Igmpv3query: IGMPv3 Query Instance

            StreamHeaderType.Custom: Custom Instance

            StreamHeaderType.Ospfv2linkstateupdate: OSPFv2 Link State Updata Instance

            StreamHeaderType.Ospfv2linkstaterequest: OSPFv2 Link State Request Instance

            StreamHeaderType.Ospfv2databasedescription: OSPFv2 Database Description Instance

            StreamHeaderType.Ospfv2linkstateacknowledge: OSPFv2 Link State Acknowledge Instance

            StreamHeaderType.Ospfv2unknown: OSPFv2 Unknown Instance

            StreamHeaderType.Ospfv2hello: OSPFv2 Hello Instance

            StreamHeaderType.Mpls: MPLS Instance

            StreamHeaderType.L1csnpheader: ISIS-L1 CSNP Config Instance

            StreamHeaderType.Isisl1helloheader: ISIS-L1 Hello Config Instance

            StreamHeaderType.L1lspheader: ISIS-L1 LSP Config Instance

            StreamHeaderType.L1psnpheader: ISIS-L1 PSNP Config Instance

            StreamHeaderType.L2csnpheader: ISIS-L2 CSNP Config Instance

            StreamHeaderType.Isisl2helloheader: ISIS-L2 Hello Config Instance

            StreamHeaderType.L2lspheader: ISIS-L2 LSP Config Instance

            StreamHeaderType.L2psnpheader: ISIS-L2 PSNP Config Instance

            StreamHeaderType.P2phelloheader: ISIS P2P Hello Config Instance

            StreamHeaderType.Gtpv1: GTPv1 Instance

            StreamHeaderType.Gtpv1opt: GTPv1 Optional Fields Instance

            StreamHeaderType.Gtpv1exthdr: GTPv1 Extension Header

            StreamHeaderType.Gtpv1ext: GTPv1 Optional Fields and Extension Header Instance

            StreamHeaderType.Ipv6fragmentheader: IPv6 Fragment Header

            StreamHeaderType.Ipv6routingheader: IPv6 Routing Header

            StreamHeaderType.Ipv6authenticationheader: IPv6 Authentication Header

            StreamHeaderType.Ipv6destinationheader: IPv6 Destination Header

            StreamHeaderType.Ipv6encapsulationheader: IPv6 Encapsulation Header

            StreamHeaderType.Ipv6hopbyhopheader: IPv6 Hop By Hop Header

            StreamHeaderType.Ipv6srheader: IPv6 SR Header

            StreamHeaderType.Stag: Customer STag Ethernet

            StreamHeaderType.Encapethernetii: Encapsulated Customer EthernetII Instance

            StreamHeaderType.Encapbackboneeth: Encapsulated MAC-in-Mac

            StreamHeaderType.Itag: iTag Instance

            StreamHeaderType.MacInMAc: MAC-in-MAC Instance

            StreamHeaderType.Encapcustomereth: Encapsulated Customer Ethernet Instance

            StreamHeaderType.Portmanagement: ANCP Instance

            StreamHeaderType.Bier: BIER Instance

            StreamHeaderType.Ccm: Continuty Check Message (CCM)

            StreamHeaderType.Chdlc: Cisco HDLC Instance

            StreamHeaderType.Cw: Control Word Instance

            StreamHeaderType.Elsflogi: ELS FLOGI Instance

            StreamHeaderType.Ethernet8023: Ethernet802.3 Instance

            StreamHeaderType.Goose: Goose Instance

            StreamHeaderType.Logiclinkcontrol: LLC Header

            StreamHeaderType.Cfg: MSTP Config Instance

            StreamHeaderType.Pause: Pause Instance

            StreamHeaderType.Pfc: PFC Instance

            StreamHeaderType.Vntag: VN Tag Instance

            StreamHeaderType.Fc: Fibre Channel Instance

            StreamHeaderType.Chassisidtlv: LLDP Chassis ID TLV

            StreamHeaderType.Portidtlv: LLDP Port ID TLV

            StreamHeaderType.Ttltlv: LLDP Time To Live TLV

            StreamHeaderType.Endtlv: LLDP End TLV

            StreamHeaderType.Hsrtag: HSR Tag Instance

            StreamHeaderType.Prptag: PRP Tag Instance

            StreamHeaderType.Stag: R Tag Instance

            StreamHeaderType.Sctp: SCTP Instance

            StreamHeaderType.Trill: Thrill Instance

    Returns:

        dict: {
            'Stream': 'StreamTemplate_1',
            'Header': 'IPv4_1',
            'Attribute': 'Source',
            'Index': 0
        }

    Examples:
        Python:

        .. code:: Python

            stream = add_stream(Port=ports)
            create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv4, StreamHeaderType.Tcp])
            # 不指定HeaderType, Level=1选中IPv4头部
            edit_modifier(Stream=stream, Level=1, Attribute='source', Start='192.168.1.1', Count=10, Step=1)
            # 指定HeaderType=IPv4, Level=0选中IPv4头部
            edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ipv4, Attribute='destination', Start='192.168.1.1', Count=10, Step=1)
    """

    result = renix.edit_modifier(
        Stream=Stream, Index=Index, Attribute=Attribute, Level=Level, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_modifier_link(
    Stream,
    Link,
    LinkModifierType=StreamLinkModifierType.ModifierId,
    BindingModifier=False,
):
    """
    修改测试仪表流量模板中指定报文字段的跳变域的link

    Args:

        Stream (StreamTemplate): 测试仪表流量对象object列表

        Link (list(str)): link modifier设置

        LinkModifierType (StreamLinkModifierType): 跳变域link类型, 默认值: StreamLinkModifierType.ModifierId, 支持:

            StreamLinkModifierType.ModifierId

            StreamLinkModifierType.LinkModifierPath

        BindingModifier (bool): 是否是绑定跳变

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

            stream = add_stream(Port=port)
            create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii, StreamHeaderType.Ipv4, StreamHeaderType.Tcp])
            # 不指定HeaderType, Level=1选中IPv4头部
            modifier1 = edit_modifier(Stream=stream, Level=1, Attribute=source, Start='192.168.1.1', Count=10, Step=1)
            # 指定HeaderType=IPv4, Level=0选中IPv4头部
            modifier2 = edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ipv4, Attribute=destination, Start='192.168.1.1', Count=10, Step=1)
            edit_modifier_link(Stream=stream, Link=[modifier1, modifier2])
    """

    result = renix.edit_modifier_link(
        Stream=Stream,
        Link=Link,
        LinkModifierType=LinkModifierType,
        BindingModifier=BindingModifier,
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def select_rx_port(Streams, RxPorts, Mode=1, ExcludeTxPort=True):
    """
    选择流量的收端口

    Args:

        Streams (list[StreamTemplate]): 测试仪表流量对象object列表

        RxPorts (list[Port]): 指定流量收端口对象列表

        Mode (StreamSelectRxPortModeType): 模式, 默认值: StreamSelectRxPortModeType.ONE_TO_ONE, 支持类型

            StreamSelectRxPortModeType.ONE_TO_ONE

            StreamSelectRxPortModeType.ONE_TO_MANY

            StreamSelectRxPortModeType.MANY_TO_ONE

            StreamSelectRxPortModeType.PAIR

        ExcludeTxPort (bool): 是否包括流量发送端口

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

        select_rx_port(Streams=streams, Rxports=ports, Mode=StreamSelectRxPortModeType.ONE_TO_MANY, ExcludeTxPort=True)
    """

    result = renix.select_rx_port(
        Streams=Streams, RxPorts=RxPorts, Mode=Mode, ExcludeTxPort=ExcludeTxPort
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def start_stream(Type=None, Objects=None):
    """
    测试仪表开始发送数据流

    Args:

        Type (StreamStartType): 当值为None时发送所有流量, 按指定端口发送数据流或者按指定流模板发送数据流, 默认值: None, 支持:

            StreamStartType.Port

            StreamStartType.Stream

        Objects (list[Port, StreamTemplate]): 按指定端口发送数据流或者按指定流模板发送数据流时需要指定端口对象或流模板对象列表

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

            start_stream(Type=port, Objects=get_ports())
    """

    result = renix.start_stream(Type=Type, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def stop_stream(Type=None, Objects=None):
    """
    测试仪表停止发送数据流

    Args:

        Type (StreamStartType): 当值为None时发送所有流量, 按指定端口发送数据流或者按指定流模板停止数据流, 默认值: None, 支持:

            StreamStartType.Port

            StreamStartType.Stream

        Objects (list[Port, StreamTemplate]): 按指定端口停止数据流或者按指定流模板发送数据流时需要指定端口对象或流模板对象列表

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        .. code:: Python

            stop_stream(Type=port, Objects=get_ports())
    """

    result = renix.stop_stream(Type=Type, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def wait_stream_state(Stream=None, State=StreamStateType.Ready, TimeOut=60):
    """
    等待测试仪表流量达到指定状态

    Args:

        Stream (list[StreamTemplate]): 测试仪表流模板对象列表

        State (list[StreamStateType]): 流模板状态, 默认值:StreamStateType.Ready, 支持:

            StreamStateType.Disable

            StreamStateType.NotReady

            StreamStateType.Ready

            StreamStateType.Running

            StreamStateType.Stopped

            StreamStateType.Pause

        TimeOut (int): 超时时间,默认值:60, 支持值: 1<=TimeOut<=4294967295

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

            wait_stream_state()
    """

    result = renix.wait_stream_state(Stream=Stream, State=State, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def start_l2_learning(
    Type=None, Ports=None, Streams=None, WaitLearningDone=True, WaitTime=30
):
    """
    启动测试仪表流量二层学习

    Args:

        Type (StreamL2LearningType): 启动流二层学习的的类型, 默认值: StreamL2LearningType.None_, 支持:

            StreamL2LearningType.Tx

            StreamL2LearningType.Rx

            StreamL2LearningType.None_

        Ports (list[Port]): 测试仪表端口对象object列表, 类型为: list, 端口对象object列表

        Streams (list[StreamTemplate]): 测试仪表流量模板对象object列表, 类型为: list, 目流量模板对象object列表

        WaitLearningDone (bool): 是否等待二层学习完成, 类型为: Bool (范围: True / False)

        WaitTime (int): 等待二层学习完成时间, 类型为: number, 默认值: 30 sec

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

            start_l2_learning()
    """

    result = renix.start_l2_learning(
        Type=Type,
        Ports=Ports,
        Streams=Streams,
        WaitLearningDone=WaitLearningDone,
        WaitTime=WaitTime,
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def stop_l2_learning(Ports=None, Streams=None):
    """
    停止测试仪表流量二层学习

    Args:

        Ports (list[Port]): 测试仪表端口对象object列表, 类型为: list, 端口对象object列表, 默认值: None

        Streams (list[StreamTemplate]): 测试仪表流量模板对象object列表, 类型为: list, 目流量模板对象object列表, 默认值: None

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        .. code:: Python

            stop_l2_learning()
    """

    result = renix.stop_l2_learning(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def start_l3_learning(Ports=None, Streams=None):
    """
    启动测试仪表流量三层ARP ND学习

    Args:

        Ports (list[Port]): 测试仪表端口对象object列表, 类型为: list, 端口对象object列表, 默认值: None

        Streams (list[StreamTemplate]): 测试仪表流量模板对象object列表, 类型为: list, 目流量模板对象object列表, 默认值: None

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

            start_l3_learning()
    """

    result = renix.start_l3_learning(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def stop_l3_learning(self, Ports=None, Streams=None):
    """
    停止测试仪表流量三层ARP ND学习

    Args:

        Ports (list[Port]): 测试仪表端口对象object列表, 类型为: list, 端口对象object列表, 默认值: None

        Streams (list[StreamTemplate]): 测试仪表流量模板对象object列表, 类型为: list, 目流量模板对象object列表, 默认值: None

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

            stop_l3_learning()
    """

    result = renix.stop_l3_learning(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def del_stream(Ports=None, Streams=None):
    """
    删除测试仪流量

    Args:

        Ports (list[Port]): 测试仪表端口对象列表, 默认值: None

        Streams (list[StreamTemplate]): 测试仪表流量对象列表, 默认值: None

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

        .. code:: Python

            del_stream(Streams=stream1)
            del_stream(Ports=port1)
            del_stream()
    """

    result = renix.del_stream(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_streams(Ports=None):
    """
    获取测试仪表流量对象

    Args:

        Ports (list[Port]): 测试仪表端口对象列表, 默认值: None

    Returns:

        Streams (list[StreamTemplate]): 测试仪表流量对象列表

    Examples:
        Python:

        .. code:: Python

            get_streams(Ports=port1)
    """

    result = renix.get_streams(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def start_stream_arp(Ports=None, Stream=None):
    """
    测试仪表启动接口ARP功能

    Args:

        Ports (list[Port]): 端口对象的列表, 默认值: None

        Stream (list[StreamTemplate]): 接口对象的列表, 默认值: None, 当Ports和Stream都为None时, 表示启动所有流量的ARP

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        Python:

    .. code:: Python

        start_stream_arp()
    """

    result = renix.start_stream_arp(Ports=Ports, Stream=Stream)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def stop_stream_arp(Ports=None, Stream=None):
    """
    测试仪表停止接口ARP功能

    Args:

        Ports (list[Port]): 端口对象的列表, 默认值: None

        Stream (list[StreamTemplate]): 接口对象的列表, 默认值: None, 当Ports和Stream都为None时, 表示启动所有流量的ARP

    Returns: 布尔值Bool (范围: True / False)

    Examples:
        Python:

    .. code:: Python

        stop_stream_arp()
    """

    result = renix.stop_stream_arp(Ports=Ports, Stream=Stream)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_stream_load_profile(Streams, **kwargs):
    """
    编辑测试仪表负载配置文件参数

    Args:

        Streams (list[StreamTemplate]): 测试仪表流量对象列表, 测试仪表流量对象object列表

    Keyword Args:

        Rate (int or str): 流量负载, 默认值: 10

        Unit (StreamLoadProfileType): 流量负载单位, 默认值: PERCENT, 取值范围:

            StreamLoadProfileType.Percent
            StreamLoadProfileType.FramePerSec
            StreamLoadProfileType.BytePerSec
            StreamLoadProfileType.LineBitPerSec
            StreamLoadProfileType.KLineBitPerSec
            StreamLoadProfileType.MLineBitPerSec
            StreamLoadProfileType.InterFrameGapByte

        StreamTransmitMode (StreamTransmitModeType): BigTao参数, 传输模式, 默认值: StreamTransmitModeType.Continuous, 支持:

            StreamTransmitModeType.Continuous
            StreamTransmitModeType.Burst

        FramePerBurst (int): BigTao参数, 仅当StreamTransmitMode为BURST有效, 突发数量, 默认值: 100, 范围: 1 <= FramePerBurst <= 4294967295

        BurstCount (int): BigTao参数, 仅当StreamTransmitMode为BURST有效, 突发次数, 默认值: 1, 范围: 1 <= BurstCount <= 4294967295

        BurstGap (int): BigTao参数, 仅当StreamTransmitMode为BURST有效, 突发间隙, 默认值: 1, 范围: 1 <= BurstGap <= 4294967295

        BurstGapUnit (StreamBurstGapUnit): BigTao参数, 仅当StreamTransmitMode为BURST有效, 突发间隔单位, 支持:

            StreamBurstGapUnit.Ns
            StreamBurstGapUnit.Us
            StreamBurstGapUnit.Ms
            StreamBurstGapUnit.Sec

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        edit_port_load_profile(Ports=port, LoadProfileType=PortLoadProfileType.StreamBase)
        edit_stream_load_profile(Streams=stream, Rate=50, Unit=StreamLoadProfileType.FramePerSec)
    """

    result = renix.edit_stream_load_profile(Streams=Streams, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

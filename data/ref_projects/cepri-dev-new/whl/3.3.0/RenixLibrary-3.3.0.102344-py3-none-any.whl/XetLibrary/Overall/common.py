"""测试仪表全局配置公共参数模块

测试仪表全局配置和常用功能: 
reset_tester:清空测试仪表所有配置;
init_tester:初始化测试仪表;
edit_overall_setting:编辑测试仪表全局参数;
save_case:测试仪表保存配置文件;
connect_chassis:连接测试仪表机箱后台;
"""

import sys

from renix_py_api.api_gen import SysEntry, HardwareChassis

from XetLibrary.Encryption.data import (
    renix,
    ProductType,
    PortSendModeType,
    MeshCreationModeType,
    RxLearningEncapsulationType,
    TestModeTypeType,
    DmTimeUnitType,
)
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def reset_tester():
    """
    清空测试仪表所有配置

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        reset_tester()
    """

    result = renix.reset_tester()
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def init_tester(Product=ProductType.BigTao, Log=True, **kwargs):
    """
    初始化测试仪表

    Args:

        Product (ProductType): ProductType 测试产品类型, 支持:
            ProductType.BigTao
            ProductType.DarYu

        Log (bool): 是否打印日志

    Keyword Args:

        Rtsm (str): 使用远端RTSM服务器上的cl进行测试,远程RTSM的IP地址

        RtsmPort (int): 远端RTSM服务器端口号, 默认值: 10001, 值范围: 0 <= RtsmPort <= 65535

        CL (str): 使用已存在cl测试, 已存在cl的IP地址

        CLPort (int): 远端RTSM服务器端口号, 默认值: 9001, 值范围: 0 <= CLPort <= 65535

        TimeOut (int): 连接远端RTSM服务器或cl实例超时时间, 单位: sec, 默认值: 30, 值范围: 0 <= TimeOut <= 65535

        StartApp (bool): 使用远端RTSM功能时是否自动启动Renix界面程序

    Returns:

        (SysEntry): sys_entry测试仪表根节点对象

    Examples:
        python:

    .. code:: python

        sys_entry = init_tester(Product=ProductType.BigTao, Log=True)
        sys_entry = init_tester(Product=ProductType.DarYu, Log=False, Rtsm='192.168.0.180', RtsmPort=10001, TimeOut=120, StartApp=True)
        sys_entry = init_tester(Product=ProductType.DarYu, Log=True, CL='192.168.0.180', CLPort=9001, TimeOut=60)
    """

    result = renix.init_tester(Product=Product, Mode="performance", Log=Log, **kwargs)
    if result is False:
        raise Failure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_overall_setting(**kwargs):
    """
    编辑测试仪表全局配置

    Keyword Args:

        流全局配置, 参数支持:

            PortSendMode (PortSendModeType): 端口发送模式, 默认值: PortSendModeType.Synchronous, 取值范围:

                PortSendModeType.Synchronous

                PortSendModeType.Asynchronous

            MeshCreationMode (MeshCreationModeType): 拓扑创建模式, 默认值: MeshCreationModeType.PortBased, 取值范围:

                MeshCreationModeType.PortBased

                MeshCreationModeType.EndpointBased

        二层学习, 参数支持:

            Rate (int): 速率（帧/秒）, 类型: number, 取值范围: 1 <= Rate <= 4294967295, 默认值: 100

            RepeatCount (int): 重复次数, 类型: number, 取值范围: 0 <= RepeatCount <= 4294967295, 默认值: 3

            DelayTime (int): 学习前延迟时间, 类型: number, 取值范围: 0 <= DelayTime <= 4294967295, 默认值: 1

            RxLearningEncapsulation (RxLearningEncapsulationType): 封装类型, 默认值: RxLearningEncapsulationType.NoEncapsuLation, 取值范围:

                RxLearningEncapsulationType.NoEncapsuLation

                RxLearningEncapsulationType.TxEncapsuLation

        ARP/ND选项, 参数支持:

            EnableAutoArp (bool): 使能自动ARP/ND, 类型: bool, 默认值: True

            StopOnArpFail (bool): ARP/ND失败自动停止测试, 类型: bool, 默认值: False

            AutoArpWaitTime (int): 自动ARP/ND等待时间（秒）, 类型: number, 取值范围: 0 <= AutoArpWaitTime <= 4294967295, 默认值: 30

        Y.1731, 参数支持:

            TestModeType (TestModeTypeType): 测试模式, 类型: string, 默认值: TestModeTypeType.TypeNorml, 取值范围:

                TestModeTypeType.TypeNorml

                TestModeTypeType.TypeCcScaleMode

                TestModeTypeType.TypeCcScaleModeWithoutRx

            LmrRxFCfStart (int): LMR帧的RxFCF初始值, 类型: number, 取值范围: 0 <= LmrRxFCfStart <= 4294967295, 默认值: 1

            LmrRxFCfStep (int): LMR帧的RxFCF更新步长, 类型: number, 取值范围: 0 <= LmrRxFCfStep <= 65535, 默认值: 1

            LmrTxFCbStart (int): LMR帧的TxFCF初始值, 类型: number, 取值范围: 0 <= LmrTxFCbStart <= 4294967295, 默认值: 1

            LmrTxFCbStep (int): LMR帧的TxFCF更新步长, 类型: number, 取值范围: 1 <= LmrTxFCbStep <= 65535, 默认值: 9

            LmmTxFCfOffset (int): LMM帧的TxFCF的偏移值, 类型: number, 取值范围: 0 <= LmmTxFCfOffset <= 32767, 默认值: 0

            LmrRxFCfOffset (int): LMR帧的RxFCF的偏移值, 类型: number, 取值范围: 0 <= LmrRxFCfOffset <= 32767, 默认值: 0

            LmrTxFCbOffset (int): LMR帧的TxFCF的偏移值, 类型: number, 取值范围: 0 <= LmrTxFCbOffset <= 32767, 默认值: 0

            DmTimeUnit (DmTimeUnitType): DM时间统计单位, 类型: string, 默认值: DmTimeUnitType.TimeMs, 取值范围:

                DmTimeUnitType.TimeMs

                DmTimeUnitType.TimeNs

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

    # 修改流全局配置
    edit_overall_setting(PortSendMode=PortSendModeType.Asynchronous, MeshCreationMode=MeshCreationModeType.EndpointBased)

    # 修改二层学习配置
    edit_overall_setting(Rate=4294967295, RepeatCount=4294967295, DelayTime=4294967295, RxLearningEncapsulation=RxLearningEncapsulationType.TxEncapsuLation)

    # 修改ARP/ND选项
    edit_overall_setting(EnableAutoArp=False, StopOnArpFail=False, AutoArpWaitTime=4294967295)

    # 修改Y.1731全局配置
    edit_overall_setting(TestModeType=TestModeTypeType.TypeCcScaleMode, LmrRxFCfStart=4294967295, LmrRxFCfStep=65535, DmTimeUnit=DmTimeUnitType.TimeNs)
    """

    result = renix.edit_overall_setting(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def save_case(Path):
    """
    测试仪表保存配置文件

    Args:

        Path (str): 配置文件路径, 例如: "C:/test.xcfg"

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        ret = save_case("C:/test.xcfg")
    """

    result = renix.save_case(Path=Path)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def connect_chassis(Chassis):
    """
    连接测试仪表机箱后台.

    Args:

        Chassis (str or list): 机箱主机IP地址或IP地址列表列表, 值范围: 0.0.0.0 <= Chassis <= 255.255.255.255

    Returns:

        list[HardwareChassis]: Chassis对象列表

    Examples:
        python:

    .. code:: python

        host_address = ['192.168.0.1', '192.168.0.2', '192.168.0.3', '192.168.0.4']
        chassis_objs = connect_chassis(host_address)

        host_address = '192.168.0.1'
        chassis_objs = connect_chassis(host_address)
    """

    result = renix.connect_chassis(Chassis=Chassis)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

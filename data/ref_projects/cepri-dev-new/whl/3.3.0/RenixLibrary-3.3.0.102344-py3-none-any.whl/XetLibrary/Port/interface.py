"""测试仪表端口配置参数模块

测试仪表端口配置和常用功能: 
create_interface: 在指定端口上创建接口;

edit_interface_stack: 修改测试仪表接口的结构;

edit_interface: 修改测试仪表接口的参数;

start_arp: 测试仪表启动接口ARP功能;

stop_arp: 测试仪表停止接口ARP功能;

get_gateway_mac: 获取测试仪表学习到的网关Mac地址;

get_interfaces: 获取测试仪表指定端口下指定类型接口;

get_layer_from_interfaces: 获取测试仪表接口的封装层对象;

ipv4_ping: 启动ipv4 ping;

ipv6_ping: 启动ipv6 ping
"""

import sys
from renix_py_api.api_gen import (
    Port,
    Interface,
    EthIILayer,
    VlanLayer,
    PppoeLayer,
    L2tpLayer,
    Ipv4Layer,
    Ipv6Layer,
)
from XetLibrary.Encryption.data import (
    renix,
    InterfaceLayersType,
    InterfaceTopsType,
    InterfaceRouterIdModeType,
    InterfaceLayerType,
    InterfaceIpv6LinkLocalGenType,
    InterfaceIpVersionType,
)
from robot.api import ContinuableFailure, Failure


# -------------------------Interface-------------------------------------
def create_interface(Port, Layers=None, Tops=None, **kwargs):
    """
    在指定端口上創建接口

    Args:

        Port (Port): 测试仪仪表端口Port对象

        Layers (list[InterfaceLayersType] or InterfaceLayersType): 链路层封装, 默认值: InterfaceLayersType.Eth, 支持的有:

            InterfaceLayersType.Eth
            InterfaceLayersType.Vlan
            InterfaceLayersType.Pppoe
            InterfaceLayersType.L2tp
            InterfaceLayersType.Ipv4
            InterfaceLayersType.Ipv6

        Tops (list[InterfaceTopsType] or InterfaceTopsType): 网络层封装, 默认值: InterfaceTopsType.Ipv4, 支持的有:

            InterfaceTopsType.NoneType
            InterfaceTopsType.Ipv4
            InterfaceTopsType.Ipv6

        Keyword Args:

            Name (str): 接口名称

            Count (int): 地址数量, 默认值: 1, 取值范围: 1 <= Count <= 16777216

            EnableInterfaceCount (bool): 启用接口地址数量, 默认值: True

            EnableLearningGatewayMac (bool): 启用网关MAC地址学习, 默认值: True

            RouterIdMode (InterfaceRouterIdModeType): IPv4路由器标识跳变模式, 默认值: InterfaceRouterIdModeType.Range, 支持:

                InterfaceRouterIdModeType.Range
                InterfaceRouterIdModeType.List
                InterfaceRouterIdModeType.Rfc4814

            RouterId (str): IPv4路由器标识, 默认值: "2.1.1.2"

            RouterIdStep (str): IPv4路由器标识跳变步长, 默认值: "0.0.0.1"

            RouterIdList (list or str): IPv4路由器标识列表, 默认值: []

            Ipv6RouterId (str): IPv6路由器标识, 默认值: "2001::2"

            Ipv6RouterIdList (list or str): IPv6路由器标识列表, 默认值: []

            EnableVlansAssociation (bool): 启用VLANs间关联变化, 默认值: False

    Returns:

        Interface: 接口interface对象

    Examples:
        python:

    .. code:: python

        port = reserve_port(Locations=["//192.168.0.1/1/1"])
        interfaces = create_interface(Port=port, Layers=[InterfaceLayersType.Eth, InterfaceLayersType.Ipv4])
    """

    result = renix.create_interface(Port=Port, Layers=Layers, Tops=Tops, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_interface_stack(Interfaces, Layers=None, Tops=None):
    """
    修改测试仪表接口的结构

    Args:

        Interfaces (list[Interface]): 测试仪仪表接口Interface对象列表

        Layers (list[InterfaceLayersType] or InterfaceLayersType): 链路层封装, 默认值: InterfaceLayersType.Eth, 支持的有:

            InterfaceLayersType.Eth
            InterfaceLayersType.Vlan
            InterfaceLayersType.Pppoe
            InterfaceLayersType.L2tp
            InterfaceLayersType.Ipv4
            InterfaceLayersType.Ipv6


        Tops (list[InterfaceTopsType] or InterfaceTopsType): 网络层封装, 默认值: InterfaceTopsType.Ipv4, 支持的有:

            InterfaceTopsType.NoneType
            InterfaceTopsType.Ipv4
            InterfaceTopsType.Ipv6

    Returns:

    dict: eg::

            {
                <renix_py_api.api_gen.Interface_Autogen.Interface object at 0x000001B2BE89ACD0>: [<renix_py_api.api_gen.EthIILayer_Autogen.EthIILayer object at 0x000002176CB13430>, <renix_py_api.api_gen.VlanLayer_Autogen.VlanLayer object at 0x000002176CB13580>, <renix_py_api.api_gen.Ipv4Layer_Autogen.Ipv4Layer object at 0x000002176CB13130>, <renix_py_api.api_gen.Ipv4Layer_Autogen.Ipv4Layer object at 0x000002176CB13730>, <renix_py_api.api_gen.L2tpLayer_Autogen.L2tpLayer object at 0x000002176CB130D0>, <renix_py_api.api_gen.PppoeLayer_Autogen.PppoeLayer object at 0x000002176CB137C0>],
            }

    Examples:
        python:

    .. code:: robotframework

        port = reserve_port(Locations=["//192.168.0.1/1/1"])
        interfaces = create_interface(Port=port, Layers=[InterfaceLayersType.Eth, InterfaceLayersType.Ipv4])
        edit_interface_stack(Interfaces=interfaces, Layers=[InterfaceLayersType.Eth, InterfaceLayersType.Vlan], Tops=[InterfaceLayersType.Ipv4])
    """

    result = renix.edit_interface_stack(Interfaces=Interfaces, Layers=Layers, Tops=Tops)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_interface(Interface, Layer=None, Level=None, **kwargs):
    """
    修改测试仪表接口的参数

    Args:

        Interface (Interface): 测试仪仪表接口Interface对象

        Layer (InterfaceLayerType): 创建接口类型, 支持的有:

            InterfaceLayerType.EthIILayer
            InterfaceLayerType.VLANLayer
            InterfaceLayerType.IPv4Layer
            InterfaceLayerType.IPv6Layer

        Level (int): 要修改的Layer在interface的所有相同Layer的序号, 默认值: None, 范围: 0-1, 为None表示修改所有Layer

    Keyword Args:

        Count (int): 地址数量, 默认值: 1, 取值范围: 1 <= Count <= 16777216

        EnableInterfaceCount (bool): 启用接口地址数量, 默认值: True

        EnableLearningGatewayMac (bool): 启用网关MAC地址学习, 默认值: True

        RouterIdMode (InterfaceRouterIdModeType): IPv4路由器标识跳变模式, 默认值: InterfaceRouterIdModeType.Range, 支持:

            InterfaceRouterIdModeType.Range
            InterfaceRouterIdModeType.List
            InterfaceRouterIdModeType.Rfc4814

        RouterId (str): IPv4路由器标识, 默认值: "2.1.1.2"

        RouterIdStep (str): IPv4路由器标识跳变步长, 默认值: "0.0.0.1"

        RouterIdList (list or str): IPv4路由器标识列表, 默认值: []

        Ipv6RouterId (str): IPv6路由器标识, 默认值: "2001::2"

        Ipv6RouterIdList (list or str): IPv6路由器标识列表, 默认值: []

        EnableVlansAssociation (bool): 启用VLANs间关联变化, 默认值: False

        EthIILayer支持:

            AddressMode (InterfaceRouterIdModeType): MAC地址跳变模式, 默认值: InterfaceRouterIdModeType.Range, 支持:

                InterfaceRouterIdModeType.Range
                InterfaceRouterIdModeType.List
                InterfaceRouterIdModeType.Rfc4814

            Address (str): 源MAC地址, 默认值: "00:00:02:01:01:02"

            Step (str): MAC地址跳变, 默认值: "00:00:00:00:00:01"

            AddressList (list[str]): MAC地址列表

            EnableRandMac (bool): 使能RFC 4814随机mac地址, 默认值: False

            RandomSeed (int): 随机种子, 默认值: 4814, 取值范围: 0 <= RandomSeed <= 65536

        VLANLayer支持:

            AddressMode (InterfaceRouterIdModeType): vlan跳变模式, 默认值: InterfaceRouterIdModeType.Range, 支持:

                InterfaceRouterIdModeType.Range
                InterfaceRouterIdModeType.List
                InterfaceRouterIdModeType.Rfc4814

            VlanId (int): VLAN ID, 默认值: 1

            Step (int): VLAN ID跳变, 默认值: 1

            VlanIdList (list[int]): VLAN ID列表, 默认值: []

            Priority (int): VLAN Priority, 默认值: 7

            PriorityStep (int): VLAN Priority跳变, 默认值: 0

            PriorityList (list[int]): VLAN Priority列表, 默认值: []

            Cfi (bool): CFI, 默认值: False

            Tpid (int): TPID, 默认值: 33024, 取值范围: 0 <= RandomSeed <= 65536

        IPv4Layer支持:

            AddressMode (InterfaceRouterIdModeType): ipv4地址跳变模式, 默认值: InterfaceRouterIdModeType.Range, 支持:

                InterfaceRouterIdModeType.Range
                InterfaceRouterIdModeType.List
                InterfaceRouterIdModeType.Rfc4814

            Address (str): ipv4地址, 默认值: "2.1.1.2"

            Step  (str): ipv4地址, 默认值: "0.0.0.1"

            AddressList (list[str]): ipv4地址列表, 默认值: []

            PrefixLength (int): IPv4前缀长度, 默认值: 24, 取值范围: 1 <= PrefixLength <= 32

            Gateway (str): IPv4网关地址, 默认值: "2.1.1.1"

            GatewayStep (str): IPv4网关地址步长, 默认值: "0.0.0.0"

            GatewayList (list[str]): IPv4网关地址列表, 默认值: []

            GatewayCount (int): IPv4网关地址数量, 默认值: 1, 取值范围: 0 <= GatewayCount <= 4294967295

            GatewayMac (str): IPv4网关MAC地址, 默认值: "00:00:02:01:01:02"

            ResolvedState (bool): mac地址解析, 默认值: False

        IPv6Layer支持:

            AddressMode (InterfaceRouterIdModeType): ipv6地址跳变模式, 默认值: InterfaceRouterIdModeType.Range, 支持:

                InterfaceRouterIdModeType.Range
                InterfaceRouterIdModeType.List
                InterfaceRouterIdModeType.Rfc4814

            Address (str): ipv6地址, 默认值: "2001::2"

            Step (str): ipv6地址, 默认值: "::1"

            AddressList (list[str]): ipv6地址, 默认值: []

            PrefixLength (int): IPv6前缀长度, 默认值: 64, 取值范围: 1 <= PrefixLength <= 128

            Gateway (str): IPv6网关地址, 默认值: "2001::1"

            GatewayStep (str): IPv6网关地址步长, 默认值: "::"

            GatewayList (list[str]): IPv6网关地址列表, 默认值: []

            GatewayCount (str): IPv6网关地址数量, 默认值: 1, 取值范围: 0 <= GatewayCount <= 4294967295

            GatewayMac (str): IPv6网关MAC地址, 默认值: "00:00:02:01:01:02"

            ResolvedState (bool): mac地址解析, 默认值: False

            LinkLocalGenType (InterfaceIpv6LinkLocalGenType): Link Local地址类型, 默认值: InterfaceIpv6LinkLocalGenType.Eui64, 支持:

                InterfaceIpv6LinkLocalGenType.FromGlobal
                InterfaceIpv6LinkLocalGenType.Eui64
                InterfaceIpv6LinkLocalGenType.Customized

            LinkLocal (str): IPv6 Link Local地址, 默认值: "fe80::200:2ff:fe01:102"

            LinkLocalStep (str): IPv6 Link Local地址步长, 默认值: "::1"

            LinkLocalList (list[str]): IPv6 Link Local地址列表, 默认值: []

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: robotframework

        port = reserve_port(Locations=["//192.168.0.1/1/1"])
        interface = create_interface(Port=port, Layers=[InterfaceLayersType.Eth, InterfaceLayersType.Ipv4])
        edit_interface(Interfaces=interface, Layer=InterfaceLayerType.IPv4Layer, Gateway=192.168.1.1)
    """

    result = renix.edit_interface(
        Interface=Interface, Layer=Layer, Level=Level, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def start_arp(Ports=None, Interfaces=None):
    """
    测试仪表启动接口ARP功能

    Args:

        Ports (list[Port]): 端口对象的列表, 默认值: None

        Interfaces (list[Interface]): 接口对象的列表, 默认值: None, 当Ports和Interfaces都为None时, 表示启动所有接口的ARP

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: robotframework

        start_arp(Interfaces=interfaces)
    """

    result = renix.start_arp(Ports=Ports, Interfaces=Interfaces)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def stop_arp(Ports=None, Interfaces=None):
    """
    测试仪表停止接口ARP功能

    Args:

        Ports (list[Port]): 端口对象的列表, 默认值: None

        Interfaces (list[Interface]): 接口对象的列表, 默认值: None, 当Ports和Interfaces都为None时, 表示启动所有接口的ARP

    Returns: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: robotframework

        stop_arp(Interfaces=interfaces)
    """

    result = renix.stop_arp(Ports=Ports, Interfaces=Interfaces)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_gateway_mac(Interface, Version=None):
    """
    获取测试仪表学习到的网关Mac地址

    Args:

        Interface (Interface): 测试仪表接口对象

        Version (InterfaceIpVersionType): 网关地址ip版本, 支持:

            InterfaceIpVersionType.Ipv4
            InterfaceIpVersionType.Ipv6

    Returns:

        list[str]: Mac地址列表List

    Examples:
        python:

    .. code:: robotframework

        get_gateway_mac(Interface=interface)
    """

    result = renix.get_gateway_mac(Interface=Interface, Version=Version)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_interfaces(Ports=None, Types=None):
    """
    获取测试仪表指定端口下指定类型接口

    Args:

        Ports (list[Port]): 测试仪表接口对象列表

        Types (InterfaceLayersType): 接口类型列表, 当取值为: None返回当前所有接口, 支持下列类型:

            InterfaceLayersType.Eth
            InterfaceLayersType.Vlan
            InterfaceLayersType.Pppoe
            InterfaceLayersType.L2tp
            InterfaceLayersType.Ipv4
            InterfaceLayersType.Ipv6

    Returns:

        list[Interface]: 测试仪表接口对象列表List

    Examples:
        python:

    .. code:: robotframework

        get_interfaces(Ports=port, Type=InterfaceLayersType.Vlan)
    """

    result = renix.get_interfaces(Ports=Ports, Types=Types)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_layer_from_interfaces(Interfaces, Layer="ipv4"):
    """
    获取测试仪表接口的封装层对象

    Args:

        Interface (list[Interface]): 测试仪表接口对象列表

        Layer (InterfaceLayersType): 封装层, 默认值: InterfaceLayersType.Ipv4, 支持:

            InterfaceLayersType.Eth
            InterfaceLayersType.Vlan
            InterfaceLayersType.Pppoe
            InterfaceLayersType.L2tp
            InterfaceLayersType.Ipv4
            InterfaceLayersType.Ipv6

    Returns:

        list[EthIILayer, VlanLayer, PppoeLayer, L2tpLayer, Ipv4Layer, Ipv6Layer]: 测试仪表接口的封装层对象列表List

    Examples:
        python:

    .. code:: robotframework

        get_layer_from_interfaces(Interfaces=interface, Layer=InterfaceLayersType.Eth)
    """

    result = renix.get_layer_from_interfaces(Interfaces=Interfaces, Layer=Layer)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def ipv4_ping(Interface=None, IpAddr=None, PacketCount=5):
    """
    获取测试仪表接口的封装层对象

    Args:

        Interface (Interface): 测试仪表接口对象列表

        IpAddr (str): ipv4地址

        PacketCount (int): ping包数量, 默认值: 5, 取值范围: 1 <= PacketCount <= 1000

    Returns:

        bool: True或False

     Examples:
        python:

    .. code:: robotframework

        ipv4_ping(Interface=interface, IpAddr='192.168.0.2')
    """

    result = renix.ipv4_ping(
        Interface=Interface, IpAddr=IpAddr, PacketCount=PacketCount
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def ipv6_ping(Interface=None, IpAddr=None, PacketCount=5):
    """
    获取测试仪表接口的封装层对象

    Args:

        Interface (Interface): 测试仪表接口对象列表

        IpAddr (str): ipv6地址

        PacketCount (int): ping包数量, 默认值: 5, 取值范围: 1 <= PacketCount <= 1000

    Returns:

        bool: True或False

     Examples:
        python:

    .. code:: robotframework

        ipv4_ping(Interface=interface, IpAddr='2000::2')
    """

    result = renix.ipv6_ping(
        Interface=Interface, IpAddr=IpAddr, PacketCount=PacketCount
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

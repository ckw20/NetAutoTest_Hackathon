"""测试仪表端口配置参数模块

测试仪表端口配置和常用功能: 
start_capture: 启动测试仪表端口数据抓包;

stop_capture: 停止测试仪表端口数据抓包;

edit_capture: 编辑端口数据捕获参数;

create_capture_byte_pattern: 在指定端口上创建Byte Pattern;

create_capture_pdu_pattern: 在指定端口上创建Pdu Pattern;

edit_capture_pattern: 修改Capture Pattern参数;

edit_capture_filter: 编辑测试仪表端口参数;

edit_capture_event: 在指定端口上设置报文过滤逻辑表达式;

download_packages: 下载指定端口捕获到的数据包;

get_capture_info: 在指定端口报文捕获信息;

get_capture_data: 在指定端口报文捕获信息;
"""

import sys
from renix_py_api.api_gen import Port
from XetLibrary.Encryption.data import (
    renix,
    CaptureModeType,
    CaptureCacheCapacityType,
    CaptureFilterModeType,
    CaptureBufferFullAction,
    CaptureSliceModeType,
    CapturePatternOperatorType,
    StreamHeaderType,
    CaptureLogicalRelationType,
    CaptureEventType,
    CaptureInfoType,
)
from robot.api import ContinuableFailure, Failure


# -------------------------Capture-------------------------------------
def start_capture(Ports=None):
    """
    启动测试仪表端口数据抓包

    Args:

        Ports (list[Port]): 测试仪仪表端口Port对象列表

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        locations = ['/192.168.0.1/1/1', '/192.168.0.1/1/2']
        ports = reserve_port(Locations=locations)
        start_capture(Ports=ports)
    """

    result = renix.start_capture(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def stop_capture(Ports=None):
    """
    停止测试仪表端口数据抓包

    Args:

        Ports (list[port]): 测试仪仪表端口Port对象列表

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        stop_capture(Ports=ports)
    """
    result = renix.stop_capture(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_capture(Ports, **kwargs):
    """
    编辑端口数据捕获参数

    Args:

        Ports: 测试仪表端口对象列表, 类型为: list

    Keyword Args:

        Name (str): 端口捕获名称, 类型为: string

        CaptureMode (CaptureModeType): 捕获模式: , 默认值: CaptureModeType.All, 支持参数

            CaptureModeType.All

            CaptureModeType.CtrlPlane

            CaptureModeType.RealTimeAll

        CacheCapacity (CaptureCacheCapacityType): 缓存容量, 默认值: CaptureCacheCapacityType.CacheMax, 支持参数

            CaptureCacheCapacityType.CacheMax

            CaptureCacheCapacityType.Cache32Kb

            CaptureCacheCapacityType.Cache64Kb

            CaptureCacheCapacityType.Cache128Kb

            CaptureCacheCapacityType.Cache256Kb

            CaptureCacheCapacityType.Cache512Kb

            CaptureCacheCapacityType.Cache1Mb

            CaptureCacheCapacityType.Cache2Mb

            CaptureCacheCapacityType.Cache4Mb

            CaptureCacheCapacityType.Cache8Mb

            CaptureCacheCapacityType.Cache16Mb

            CaptureCacheCapacityType.Cache32Mb

            CaptureCacheCapacityType.Cache64Mb

            CaptureCacheCapacityType.Cache128Mb

            CaptureCacheCapacityType.Cache256Mb

            CaptureCacheCapacityType.Cache512Mb

            CaptureCacheCapacityType.Cache1Gb

        FilterMode (CaptureFilterModeType): 筛选模式, 默认值: CaptureFilterModeType.Byte, 支持选项有:

            CaptureFilterModeType.Byte

            CaptureFilterModeType.Pdu

        BufferFullAction (CaptureBufferFullAction): 缓存区满后执行动作, 默认值: CaptureBufferFullAction.Stop, 支持选项有:

            CaptureBufferFullAction.Stop

            CaptureBufferFullAction.Wrap

        StartingFrameIndex (int): 下载报文的起始编号, 默认值: 1, 取值范围: 1 <= StartingFrameIndex <= 4294967295

        AttemptDownloadPacketCount (int): 下载报文数量, 默认值: 0, 0表示下载所有报文, 取值范围: 0 <= AttemptDownloadPacketCount <= 4294967295

        FcsError (bool): Fec错误, 类型为: bool, 取值范围: True或False, 默认值: False

        Ipv4ChecksumError (bool): Ipv4 Checksum错误, 类型为: bool, 取值范围: True或False, 默认值: False

        PayloadError (bool): Payload错误, 类型为: bool, 取值范围: True或False, 默认值: False

        EnableRealtimeCapture (bool): 捕获模式为Control Plane (Tx and Rx)或RealTime All(Control Plane tx/rx and data plane rx), 类型为: bool, 取值范围: True或False, 默认值: False

        SliceMode (CaptureSliceModeType): 切片模式, 默认值: CaptureSliceModeType.Disable, 支持选项有:

            CaptureSliceModeType.Disable

            CaptureSliceModeType.Enable

        SliceByteSize (int): 切片字节大小, 取值范围: 32 <= SliceByteSize <= 16383, 默认值: 128

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        edit_capture(Ports=port, CaptureMode=CaptureModeType.CtrlPlane)
    """

    result = renix.edit_capture(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def create_capture_byte_pattern(Port, **kwargs):
    """
    在指定端口上创建Byte Pattern

    Args:

        Port (Port): 测试仪表端口对象, 类型为: object

    Keyword Args:

        CustomCapturePatternOperatorType (CapturePatternOperatorType): 表达式位运算符, 默认值: CapturePatternOperatorType.And, 支持参数

            CapturePatternOperatorType.And

            CapturePatternOperatorType.Or

            CapturePatternOperatorType.Xor

        CustomCapturePatternNot (bool): 表达式取反, 类型为: bool, 取值范围: True或False, 默认值: False

        UseFrameLength (bool): 使用Frame长度, 类型为: bool, 取值范围: True或False, 默认值: False

        Data (list(hex)): 最小值, 类型为: string, 取值范围: 十六进制字符串, 默认值: 0x0

        MaxData (list(hex)): 最大值, 类型为: string, 取值范围: 十六进制字符串, 默认值: 0xff

        Mask (list(hex)): 掩码, 类型为: string, 取值范围: 十六进制字符串, 默认值: 0xff

        Offset (int): 偏移位, 取值范围: 0 <= Offset <= 16378, 默认值: 0

        MinFrameLength (int): 最小长度,当UseFrameLength为True有效, 取值范围: 64 <= MinFrameLength <= 16383, 默认值: 64

        MaxFrameLength (int): 最大长度,当UseFrameLength为True有效, 取值范围: 64 <= MaxFrameLength <= 16383, 默认值: 16383

    Returns:

        str: Byte Pattern唯一索引字符串string，例如: CaptureBytePattern_1

    Examples:
        python:

    .. code:: python

        create_capture_byte_pattern(Port=port, Data=[0x0, 0x01], Mask=[0xff, 0xff], Offset=0, CustomCapturePatternOperatorType=CapturePatternOperatorType.Or, CustomCapturePatternNot=True)
    """

    result = renix.create_capture_byte_pattern(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def create_capture_pdu_pattern(Port, HeaderTypes, **kwargs):
    """
    在指定端口上创建Pdu Pattern

    Args:

        Port (Port): 测试仪表端口对象, 类型为: object

        HeaderTypes (list[StreamHeaderType]): 指定报文结构，支持:

            StreamHeaderType.Ethernetii: EthernetII Instance

            StreamHeaderType.Raw: Ethernet802.3 Raw Instance

            StreamHeaderType.Vlan: VLAN Instance

            StreamHeaderType.Vxlan: VXLAN Header Instance

            StreamHeaderType.Arp: ARP Instance

            StreamHeaderType.Gre: GRE Instance

            StreamHeaderType.Ipv4: IPv4 Instance

            StreamHeaderType.Ipv6: IPv6 Instance

            StreamHeaderType.Tcp: TCP Instancce

            StreamHeaderType.Udp: UDP Instance

            StreamHeaderType.L2tpv2data: L2TPv2 Data Over UDP Instance

            StreamHeaderType.L2tpv2control: L2TPv2 Control Over UDP Instance

            StreamHeaderType.L2tpv3controloverip: L2TPv3 Control Over IP Instance

            StreamHeaderType.L2tpv3controloverudp: L2TPv3 Control Over UDP Instance

            StreamHeaderType.L2tpv3dataoverip: L2TPv3 Data Over IP Instance

            StreamHeaderType.L2tpv3dataoverudp: L2TPv3 Data Over UDP Instance

            StreamHeaderType.Dhcpv4server

            StreamHeaderType.Dhcpv4client

            StreamHeaderType.Dhcpv6client

            StreamHeaderType.Dhcpv6server

            StreamHeaderType.Ppp: PPP Instance

            StreamHeaderType.Pppoe: PPPoE Instance

            StreamHeaderType.Pppoediscovery: PPPoE Discovery Instance

            StreamHeaderType.Icmpv4echorequest: ICMPv4 EchoRequest Instance

            StreamHeaderType.Destunreach: ICMPv4 DestUnreach Instance

            StreamHeaderType.Icmpv4echoreply: ICMPv4 EchoReply Instance

            StreamHeaderType.Informationreply: ICMPv4 InformationReply Instance

            StreamHeaderType.Informationrequest: ICMPv4 InformationRequest Instance

            StreamHeaderType.Icmpv4parameterproblem: ICMPv4 ParameterProblem Instance

            StreamHeaderType.Icmpv4redirect: ICMPv4 Redirect Instance

            StreamHeaderType.Sourcequench: ICMPv4 SourceQuench Instance

            StreamHeaderType.Timeexceeded: ICMPv4 TimeExceeded Instance

            StreamHeaderType.Timestampreply: ICMPv4 TimestampReply Instance

            StreamHeaderType.Timestamprequest: ICMPv4 TimestampRequest Instance

            StreamHeaderType.Icmpmaskrequest: ICMPv4 Address Mask Request Instance

            StreamHeaderType.Icmpmaskreply: ICMPv4 Address Mask Reply Instance

            StreamHeaderType.Destinationunreachable: ICMPv6 DestinationUnreachable Instance

            StreamHeaderType.Icmpv6echoreply: ICMPv6 EchoReply Instance

            StreamHeaderType.Icmpv6echorequest: ICMPv6 EchoRequest Instance

            StreamHeaderType.Packettoobig: ICMPv6 PacketTooBig Instance

            StreamHeaderType.Icmpv6parameterproblem: ICMPv6 ParameterProblem Instance

            StreamHeaderType.Timeexceed: ICMPv6 TimeExceed Instance

            StreamHeaderType.Soutersolicit: Router Solicitation Instance

            StreamHeaderType.Souteradvertise: Router Advertisement Instance

            StreamHeaderType.Icmpv6redirect: Redirect Instance

            StreamHeaderType.Neighborsolicit: Neighbor Solicitation Instance

            StreamHeaderType.Neighboradvertise: Neighbor Advertisement Instance

            StreamHeaderType.Mldv1query: ICMPv6 MLDv1 Query Instance

            StreamHeaderType.Mldv1report: ICMPv6 MLDv1 Report Instance

            StreamHeaderType.Mldv1done: ICMPv6 MLDv1 Done Instance

            StreamHeaderType.Mldv2query: ICMPv6 MLDv2 Query Instance

            StreamHeaderType.Mldv2report: ICMPv6 MLDv2 Report Instance

            StreamHeaderType.Igmpv1: IGMPv1 Report Instance

            StreamHeaderType.Igmpv1query: IGMPv1 Query Instance

            StreamHeaderType.Igmpv2: IGMPv2 Report Instance

            StreamHeaderType.Igmpv2query: IGMPv2 Query Instance

            StreamHeaderType.Igmpv3report: IGMPv3 Report Instance

            StreamHeaderType.Igmpv3query: IGMPv3 Query Instance

            StreamHeaderType.Custom: Custom Instance

            StreamHeaderType.Ospfv2linkstateupdate: OSPFv2 Link State Updata Instance

            StreamHeaderType.Ospfv2linkstaterequest: OSPFv2 Link State Request Instance

            StreamHeaderType.Ospfv2databasedescription: OSPFv2 Database Description Instance

            StreamHeaderType.Ospfv2linkstateacknowledge: OSPFv2 Link State Acknowledge Instance

            StreamHeaderType.Ospfv2unknown: OSPFv2 Unknown Instance

            StreamHeaderType.Ospfv2hello: OSPFv2 Hello Instance

            StreamHeaderType.Mpls: MPLS Instance

            StreamHeaderType.L1csnpheader: ISIS-L1 CSNP Config Instance

            StreamHeaderType.Isisl1helloheader: ISIS-L1 Hello Config Instance

            StreamHeaderType.L1lspheader: ISIS-L1 LSP Config Instance

            StreamHeaderType.L1psnpheader: ISIS-L1 PSNP Config Instance

            StreamHeaderType.L2csnpheader: ISIS-L2 CSNP Config Instance

            StreamHeaderType.Isisl2helloheader: ISIS-L2 Hello Config Instance

            StreamHeaderType.L2lspheader: ISIS-L2 LSP Config Instance

            StreamHeaderType.L2psnpheader: ISIS-L2 PSNP Config Instance

            StreamHeaderType.P2phelloheader: ISIS P2P Hello Config Instance

            StreamHeaderType.Gtpv1: GTPv1 Instance

            StreamHeaderType.Gtpv1opt: GTPv1 Optional Fields Instance

            StreamHeaderType.Gtpv1exthdr: GTPv1 Extension Header

            StreamHeaderType.Gtpv1ext: GTPv1 Optional Fields and Extension Header Instance

            StreamHeaderType.Ipv6fragmentheader: IPv6 Fragment Header

            StreamHeaderType.Ipv6routingheader: IPv6 Routing Header

            StreamHeaderType.Ipv6authenticationheader: IPv6 Authentication Header

            StreamHeaderType.Ipv6destinationheader: IPv6 Destination Header

            StreamHeaderType.Ipv6encapsulationheader: IPv6 Encapsulation Header

            StreamHeaderType.Ipv6hopbyhopheader: IPv6 Hop By Hop Header

            StreamHeaderType.Ipv6srheader: IPv6 SR Header

            StreamHeaderType.Stag: Customer STag Ethernet

            StreamHeaderType.Encapethernetii: Encapsulated Customer EthernetII Instance

            StreamHeaderType.Encapbackboneeth: Encapsulated MAC-in-Mac

            StreamHeaderType.Itag: iTag Instance

            StreamHeaderType.MacInMAc: MAC-in-MAC Instance

            StreamHeaderType.Encapcustomereth: Encapsulated Customer Ethernet Instance

            StreamHeaderType.Portmanagement: ANCP Instance

            StreamHeaderType.Bier: BIER Instance

            StreamHeaderType.Ccm: Continuty Check Message (CCM)

            StreamHeaderType.Chdlc: Cisco HDLC Instance

            StreamHeaderType.Cw: Control Word Instance

            StreamHeaderType.Elsflogi: ELS FLOGI Instance

            StreamHeaderType.Ethernet8023: Ethernet802.3 Instance

            StreamHeaderType.Goose: Goose Instance

            StreamHeaderType.Logiclinkcontrol: LLC Header

            StreamHeaderType.Cfg: MSTP Config Instance

            StreamHeaderType.Pause: Pause Instance

            StreamHeaderType.Pfc: PFC Instance

            StreamHeaderType.Vntag: VN Tag Instance

            StreamHeaderType.Fc: Fibre Channel Instance

            StreamHeaderType.Chassisidtlv: LLDP Chassis ID TLV

            StreamHeaderType.Portidtlv: LLDP Port ID TLV

            StreamHeaderType.Ttltlv: LLDP Time To Live TLV

            StreamHeaderType.Endtlv: LLDP End TLV

            StreamHeaderType.Hsrtag: HSR Tag Instance

            StreamHeaderType.Prptag: PRP Tag Instance

            StreamHeaderType.Stag: R Tag Instance

            StreamHeaderType.Sctp: SCTP Instance

            StreamHeaderType.Trill: Thrill Instance

    Keyword Args:

        Level (int): 报文字段在流量模板中所有报文头部的序列号, 需要和Attribute字段同时使用

        Attribute (str): 报文字段参数名称, 需要和Level字段同时使用

        FieldName (str): 过滤字段名, 该字段不能与Level和Attribute同时使用

        CustomCapturePatternOperatorType (CapturePatternOperatorType): 表达式位运算符, 默认值: AND, 支持参数

            CapturePatternOperatorType.And

            CapturePatternOperatorType.Or

            CapturePatternOperatorType.Xor

        CustomCapturePatternNot (bool): 表达式取反: , 类型为: bool, 取值范围: True或False, 默认值: False

        Value (str): 最小值, 类型为: string

        MaxValue (str): 最大值, 类型为: string

        Mask (str): 掩码, 类型为: string

    Returns:

        str: Pdu Pattern的句柄，例如: CapturePduPattern_1

    Examples:
        python:

    .. code:: python

        init_test()
        port = reserve_port(Locations='//192.168.0.180/1/1')
        stream = add_stream(Ports=port)
        create_stream_header(Stream=stream, HeaderTypes=['EthernetII', 'IPv4'])
        attribute = edit_header_ipv4(Stream=stream, Level=0, TTL=200, Source='1.1.1.1')
        # 使用Level和Attribute参数设置Pdu Pattern
        create_capture_pdu_pattern(Port=port, HeaderTypes=['EthernetII', 'IPv4'], Level=1,
                                   Attribute=attribute[TTL], Value=200, MaxValue=200)
        # 等价于: 使用FieldName参数设置Pdu Pattern
        create_capture_pdu_pattern(Port=port, HeaderTypes=['EthernetII', 'IPv4'],
                                    FieldName='ipv4_1.ttl', Value=200, MaxValue=200)
    """

    result = renix.create_capture_pdu_pattern(
        Port=Port, HeaderTypes=HeaderTypes, **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_capture_pattern(Pattern, **kwargs):
    """
    修改Capture Pattern参数

    Args:

        Pattern (str): Capture Pattern的标识, 类型为: sting，例如: CaptureBytePattern_1或CapturePduPattern_1

    Keyword Args:

        Byte Pattern支持的Args:

            CustomCapturePatternOperatorType (str): 表达式位运算符, 类型为: string, 默认值: AND, 支持参数

                CapturePatternOperatorType.And

                CapturePatternOperatorType.Or

                CapturePatternOperatorType.Xor

            CustomCapturePatternNot (bool): 表达式取反, 类型为: bool, 取值范围: True或False, 默认值: False

            UseFrameLength (bool): 使用Frame长度, 类型为: bool, 取值范围: True或False, 默认值: False

            Data (str): 最小值, 类型为: string, 取值范围: 十六进制字符串, 默认值: 0x0,

            MaxData (str): 最大值, 类型为: string, 取值范围: 十六进制字符串, 默认值: 0xff,

            Mask (str): 掩码, 类型为: string, 取值范围: 十六进制字符串, 默认值: 0xff,

            Offset (int): 偏移位, 取值范围: 0 <= Offset <= 16378, 默认值: 0

            MinFrameLength (int): 最小长度,当UseFrameLength为True有效, 取值范围: 64 <= MinFrameLength <= -16383, 默认值: 64

            MaxFrameLength (int): 最大长度,当UseFrameLength为True有效, 取值范围: 64 <= MaxFrameLength <= 16383, 默认值: 16383

        Pdu Pattern支持的Args:

            Level (int): 报文字段在流量模板中所有报文头部的序列号, 需要和Attribute字段同时使用

            Attribute (str): 报文字段参数名称, 需要和Level字段同时使用

            FieldName (str): 过滤字段名, 该字段不能与Level和Attribute同时使用

            CustomCapturePatternOperatorType (str): 表达式位运算符, 类型为: string, 默认值: AND, 支持参数

                CapturePatternOperatorType.And

                CapturePatternOperatorType.Or

                CapturePatternOperatorType.Xor

            CustomCapturePatternNot (bool): 表达式取反, 类型为: bool, 取值范围: True或False, 默认值: False

            Value (str): 最小值, 类型为: string

            MaxValue (str): 最大值, 类型为: string

            Mask (str): 掩码, 类型为: string

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        BytePattern = create_capture_byte_pattern(Port=port, CustomCapturePatternOperatorType=CapturePatternOperatorType.Or, CustomCapturePatternNot=True)
        PduPattern = create_capture_pdu_pattern(Port=port, HeaderTypes=['EthernetII', 'IPv4', 'Icmpv4EchoReply'],
                                                FieldName=Icmpv4EchoReply_1.code, Value=4, MaxValue=5, CustomCapturePatternOperatorType=CapturePatternOperatorType.Or, CustomCapturePatternNot=True)
        edit_capture_pattern(Pattern=BytePattern, CustomCapturePatternOperatorType=CapturePatternOperatorType.Xor)
        edit_capture_pattern(Pattern=PduPattern, CustomCapturePatternOperatorType=CapturePatternOperatorType.Xor)
    """

    result = renix.edit_capture_pattern(Pattern=Pattern, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_capture_filter(Port, Expression):
    """
    在指定端口上设置报文过滤逻辑表达式

    Args:

        Port (Port`): 测试仪表端口对象, 类型为: object

        Expression (str): 过滤逻辑表达式, 类型为: string

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        BytePattern = create_capture_byte_pattern(Port=port, CustomCapturePatternOperatorType=CapturePatternOperatorType.Or, CustomCapturePatternNot=True)
        PduPattern = create_capture_pdu_pattern(Port=port, HeaderTypes=['EthernetII', 'IPv4', 'Icmpv4EchoReply'],
                                                FieldName=Icmpv4EchoReply_1.code, Value=4, MaxValue=5, CustomCapturePatternOperatorType=CapturePatternOperatorType.Or, CustomCapturePatternNot=True)
        edit_capture_filter(Port=port, Expression='BytePattern && PduPattern')
    """

    result = renix.edit_capture_filter(Port=Port, Expression=Expression)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_capture_event(Port, EventType="QUALIFY", **kwargs):
    """
    在指定端口上设置帧捕获条件

    Args:

        Port (Port): 测试仪表端口对象, 类型为: object

        EventType (CaptureEventType): 帧捕获类型，支持参数:

            CaptureEventType.Qualify

            CaptureEventType.Start

            CaptureEventType.Stop

    Keyword Args:

        LogicRelation (CaptureLogicalRelationType): 指定捕获事件之间的逻辑关系，默认值: CaptureLogicalRelationType.And，支持:

            CaptureLogicalRelationType.And

            CaptureLogicalRelationType.Or

        PatternMatch (CaptureEventType): 指定捕获事件之间的逻辑关系，默认值: CaptureEventType.Include，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        FcsError (CaptureEventType): FCS错误，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        PrbsError (CaptureEventType): FCS错误，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        Ipv4ChecksumError (CaptureEventType): IPv4校验和错误帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        TcpChecksumError (CaptureEventType): TCP校验和错误帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        UdpChecksumError (CaptureEventType): UDP校验和错误帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        IgmpChecksumError (CaptureEventType): Igmp校验和错误帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        IcmpChecksumError (CaptureEventType): Icmp校验和错误帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        SequenceError (CaptureEventType): 序列号错误帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        UndersizedFrame (CaptureEventType): 超短帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        OversizedFrame (CaptureEventType): 超长帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        JumboFrame (CaptureEventType): Jumbo帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        FrameLength (CaptureEventType): 特定长度帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        FrameLengthValue (int): 特定帧长度，默认值: 0

        SignaturePresent (CaptureEventType): 带有签名的流帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        StreamIdMatch (CaptureEventType): 特定流号的流帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        StreamId (int): 特定流号，默认值: 0

        Ipv4Packets (CaptureEventType): IPv4报文，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        TcpPackets (CaptureEventType): TCP报文，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        UdpPackets (CaptureEventType): UDP报文，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        Ipv6Packets (CaptureEventType): IPv6报文，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        IgmpPackets (CaptureEventType): IGMP报文，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

        PayloadError (CaptureEventType): PRBS错误帧，默认值: CaptureEventType.Ignore，支持:

            CaptureEventType.Ignore

            CaptureEventType.Include

            CaptureEventType.Exclude

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        edit_capture_event(Port=port, EventType=CaptureEventType.Qualify, LogicRelation=CaptureLogicalRelationType.Or, PrbsError=CaptureEventType.Include, FrameLengthValue=128)
    """

    result = renix.edit_capture_event(Port=Port, EventType=EventType, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def download_packages(
    Port, FileDir, FileName, MaxCount=0, TimeOut=30, AppendPortHandle=True
):
    """
    下载指定端口捕获到的数据包

    Args:

        Port (Port): 测试仪表端口对象object

        FileDir (str): 报文保存的路径, ("D:/test")

        FileName (str): 报文保存的文件的名称

        MaxCount (int): 下载报文最大数量，默认值0, 表示下载端口上捕获到的所有报文，取值范围: 0<=MaxCount<=4294967295

        TimeOut (int): 下载报文的超时时间单位秒，超时时间内为下载完成则下载失败, 默认值30，取值范围: 0<=TimeOut<=4294967295

        AppendPortHandle (bool): 下载报文保存路径是否自动添加端口句柄，默认值: True

    Returns:

        str: 下载数据包文件的绝对路径(例如: "D:\\test\\10.0.5.10_1_1\\dowload.pcap")

    Examples:
        python:

    .. code:: python

        download_packages(Port=port, FileDir='D:/test', FileName='download')
    """

    result = renix.download_packages(
        Port=Port,
        FileDir=FileDir,
        FileName=FileName,
        MaxCount=MaxCount,
        TimeOut=TimeOut,
        AppendPortHandle=AppendPortHandle,
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_capture_info(Port, Items=CaptureInfoType.None_):
    """
    在指定端口报文捕获信息

    Args:

        Port (Port): 测试仪表端口对象, 类型为: object

        Items (list[CaptureInfoType]): 端口报文捕获信息, 默认值: CaptureInfoType.None_支持参数:

            CaptureInfoType.CaptureState

            CaptureInfoType.ElapsedTime

            CaptureInfoType.CapturedPacketCount

            CaptureInfoType.BufferFull

            CaptureInfoType.DownloadedPacketCount

            CaptureInfoType.CurrentDataFile

            CaptureInfoType.None_

    Returns:

        dict:

    Examples:
        python:

    .. code:: python

        get_capture_info(Port=Port)
    """

    result = renix.get_capture_info(Port=Port, Items=Items)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_capture_data(Port, Index=1):
    """
    在指定端口报文捕获信息

    Args:

        Port (Port): 测试仪表端口对象, 类型为: object

        Index (int): 报文序号，默认值: 1，取值范围: 0<=Index<=4294967295


    Returns:

        dict:

    Examples:
        python:

    .. code:: python

        renix.get_capture_data(Port=port, Index=10)
    """

    result = renix.get_capture_data(Port=Port, Index=Index)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

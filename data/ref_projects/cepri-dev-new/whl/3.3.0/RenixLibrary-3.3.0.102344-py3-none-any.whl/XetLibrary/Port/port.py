"""测试仪表端口配置参数模块

测试仪表端口配置和常用功能: 
relocate_ports: 逻辑端口迁移到执行的测试仪表的物理端口;

reserve_port: 预约测试仪表的端口;

release_port: 释放测试仪表的端口;

get_ports: 获取当前测试仪表配置中所有的端口对象;

del_port: 删除测试仪端口;

get_port_speed: 获取测试仪表端口速率;

edit_port: 编辑测试仪表端口参数;

wait_port_state: 等待测试仪表端口链路达到指定状态;

edit_port_load_profile: 编辑测试仪表负载配置文件参数;
"""

import sys

from renix_py_api.api_gen import Port

from XetLibrary.Encryption.data import (
    renix,
    PortLineSpeedTpye,
    PortFecType,
    PortDuplexType,
    PortFlowControlType,
    PortMediaType,
    PortPhyModeType,
    PortDataPathModeType,
    PortRemoteFaultType,
    PortMasterType,
    PortTransmitModeType,
    PortInterFrameGapUnitType,
    PortLoadProfileType,
    PortLoadProfileUnitType,
    PortGenerateErrorType,
    PortIgnoreLinkStateType,
    PortTimeStampPosType,
    PortStateType,
)

from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def relocate_ports(Ports, Locations, Force=False, Debug=False):
    """
    逻辑端口迁移到执行的测试仪表的物理端口.

    Args:

        Ports (list[Port]): 端口对象的列表

        Locations (list[str]): 端口在测试仪表机箱硬件中的位置, //$(机箱IP地址)/$(板卡序号)/$(端口序号) (例如: ["//192.168.0.1/1/1",  "//192.168.0.1/1/2"])

        Force (bool): 强制释放端口, 默认值: False

        Debug (bool): 使用离线端口, 默认值: False

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        location = ["//192.168.0.1/1/1",  "//192.168.0.1/1/2"]
        relocate_ports(Ports=ports, Locations=location)
    """

    result = renix.relocate_ports(
        Ports=Ports, Locations=Locations, Force=Force, Debug=Debug
    )
    if result is False:
        raise Failure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def reserve_port(Locations, Force=False, Debug=False, WaitForStatusUp=True):
    """
    预约测试仪表的端口

    Args:

        Locations (list[str]): 端口在测试仪表机箱硬件中的位置, //$(机箱IP地址)/$(板卡序号)/$(端口序号) (例如: ["//192.168.0.1/1/1",  "//192.168.0.1/1/2"])

        Force (bool): 强制占用测试仪表端口, 默认值: False

        Debug (bool): 调试模式, 只创建离线端口, 默认值: False

        WaitForStatusUp (bool): 等待端口UP, 默认值: True

    Returns:

        list[Port]: 端口对象列表

    Examples:
        python:

    .. code:: python

        location = ["//192.168.0.1/1/1",  "//192.168.0.1/1/2"]
        ports = reserve_port(Locations=location,  False=True)
    """

    result = renix.reserve_port(
        Locations=Locations, Force=Force, Debug=Debug, WaitForStatusUp=WaitForStatusUp
    )
    if result is False:
        raise Failure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def release_port(Locations=None, Ports=None, Force=False, Debug=False):
    """
    释放测试仪表的端口

    Args:

        Locations (list[str]): 端口在测试仪表机箱硬件中的位置, //$(机箱IP地址)/$(板卡序号)/$(端口序号) (例如: ["//192.168.0.1/1/1",  "//192.168.0.1/1/2"])

        Ports (list[Port]): 端口在测试仪表端口对象列表

        Force (bool): 强制释放测试仪表端口, 默认值: False

        Debug (bool): 使用离线端口, 调用实际不会对端口做任何操作配合reserve_port的Debug模式, 默认值: False

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        location = ["//192.168.0.1/1/1",  "//192.168.0.1/1/2"]
        release_port(Locations=location)
    """

    result = renix.release_port(
        Locations=Locations, Ports=Ports, Force=Force, Debug=Debug
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_ports():
    """
    获取当前测试仪表配置中所有的端口对象

    Returns:

        list[Port]: Port对象列表

    Examples:
        python:

    .. code:: python

        ports = get_ports()
    """

    result = renix.get_ports()
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def del_port(Ports=None):
    """
    删除测试仪端口

    Args:

        Ports (list[Port]): 测试仪表端口对象列表, 类型为: list

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        del_port(Ports=port1)
        del_port()
    """

    result = renix.del_port(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def get_port_speed(Ports):
    """
    获取测试仪表端口速率

    Args:

        Ports (list(Port)): 测试仪表端口列表

    Returns:

        list[PortLineSpeedTpye]: 端口速率列表

    Examples:
        python:

    .. code:: python

        get_port_speed(Ports=ports)
    """

    result = renix.get_port_speed(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_port(Ports, **kwargs):
    """
    编辑测试仪表端口参数

    Args:

        Ports (list(Port)): 测试仪表端口列表

    Keyword Args:

        EnableLink (bool): 设置端口link Up和Down, 默认值: True

        AutoNegotiation (bool): 自协商, 默认值: False

        Mtu (int): 端口MTU值, 默认值: 1500, 范围: 128 <= Mtu <= 9600

        FecType (PortFecType): Fec类型, 默认值: None, 支持:

            PortFecType.TypeOff
            PortFecType.TypeRsFecClause91
            PortFecType.TypeFecClause74
            PortFecType.TypeRsFecClause108
            PortFecType.TypeRsFecConsortium
            PortFecType.TypeRsFecClause119

        LineSpeed (PortLineSpeedTpye): 端口速率切换, 默认值: None, 支持:

            PortLineSpeedTpye.SpeedUnknown
            PortLineSpeedTpye.Speed10M
            PortLineSpeedTpye.Speed100M
            PortLineSpeedTpye.Speed1G
            PortLineSpeedTpye.Speed2_5G
            PortLineSpeedTpye.Speed5G
            PortLineSpeedTpye.Speed10G
            PortLineSpeedTpye.Speed25G
            PortLineSpeedTpye.Speed40G
            PortLineSpeedTpye.Speed50G
            PortLineSpeedTpye.Speed100G
            PortLineSpeedTpye.Speed200G
            PortLineSpeedTpye.Speed400G
            PortLineSpeedTpye.Speed800G

        Duplex (PortDuplexType): 全双工半双工, 默认值: None, 支持:

            PortDuplexType.Half
            PortDuplexType.Full

        FlowControl (PortFlowControlType): 流控, 默认值: None, 支持:

            PortFlowControl.Disable
            PortFlowControl.Enable
            PortFlowControl.Auto

        Media (PortMediaType): 媒介, 默认值: None, 支持:

            PortMediaType.Copper
            PortMediaType.Fiber
            PortMediaType.Fake

        PhyMode (PortPhyModeType): Phy Mode, 默认值: None, 支持:

            PortPhyModeType.ModeAuto
            PortPhyModeType.Mode1000BaseX
            PortPhyModeType.ModeSgmii

        PpmAdjust (int): Ppm Adjust, 默认值: None, 范围: -300 <= PpmAdjust <=300

        DataPathMode (PortDataPathModeType): Data Path模式, 默认值: None, 支持:

            PortDataPathModeType.Normal
            PortDataPathModeType.Loopback

        RemoteFault (PortRemoteFaultType): 远端错误, 默认值: None, 支持:

            PortRemoteFaultType.Normal
            PortRemoteFaultType.Ignore

        Master (PortMasterType): Master, 默认值: None, 支持:

            PortMasterType.AdvertiseSinglePort
            PortMasterType.AdvertiseMultiPort
            PortMasterType.ManualMaster
            PortMasterType.ManualSlave

        NoParam (bool): 远端错误, 默认值: False

        ArpTimeout (int): ARP/ND超时（秒）范围: 1 <= ArpTimeout <= 255, 默认值: 1

        ArpRate (int): ARP/ND速率（包/秒范围: 1 <= ArpRate <= 1000000, 默认值: 250

        ArpRetryCount (int): ARP/ND重传次数 范围: 0 <= ArpRetryCount <=100, 默认值: 3

        ArpSuppressDuplicateGateway (bool): ARP/ND抑制重复网关, 默认值: False

        ArpDelayTime (int): 在ARP/ND前延迟（秒） 范围: 0 <= ArpDelayTime <= 4294967295, 默认值: 0

        ArpUseLinkLocalForNd (bool): 使用LinkLocal执行ND, 默认值: False

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        edit_port(Ports=port1, FlowControl=PortFlowControl.Auto, ArpRetryCount=5)
    """

    result = renix.edit_port(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def wait_port_state(Ports=None, State=None, Interval=1, TimeOut=60):
    """
    等待测试仪表端口链路达到指定状态

    Args:

        Ports (list[Port]): 测试仪表端口对象列表

        State (PortStateType): 测试仪表连接端口状态, 默认值: PortStateType.Up, 取值范围:

            PortStateType.Down
            PortStateType.Up

        Interval (int): 状态查询间隔, 默认值:1, 取值范围: 0 < Interval <= 4294967295

        TimeOut (int): 超时时间, 默认值:60, 取值范围: 0 < TimeOut <= 4294967295

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        edit_port(Ports=port, EnableLink=False)
        wait_port_state(Ports=port, State=PortStateType.Down)
    """

    result = renix.wait_port_state(
        Ports=Ports, State=State, Interval=Interval, TimeOut=TimeOut
    )
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result


def edit_port_load_profile(Ports, **kwargs):
    """
    编辑测试仪表负载配置文件参数

    Args:

        Ports (list[Port]): 测试仪表端口对象object列表

    Keyword Args:

        TransmitMode (PortTransmitModeType): 传输模式, 默认值: PortTransmitModeType.Continuous, 取值范围:

            PortTransmitModeType.Continuous
            PortTransmitModeType.Burst
            PortTransmitModeType.Time
            PortTransmitModeType.Step
            PortTransmitModeType.Onstream


        BurstSize (int):突发报文数, 默认值: 1, 取值范围: 1 <= BurstSize <= 4294967295

        InterFrameGap (float):突发间隔, 默认值: 12.0, 取值范围: 0 < InterFrameGap <= 4294967295

        InterFrameGapUnit (PortInterFrameGapUnitType):突发间隔单位, 默认值: PortInterFrameGapUnitType.Bytes, 取值范围:

            PortInterFrameGapUnitType.Ns
            PortInterFrameGapUnitType.Us
            PortInterFrameGapUnitType.Ms
            PortInterFrameGapUnitType.Sec
            PortInterFrameGapUnitType.Bytes

        BurstCount (int):突发次数, 默认值: 1, 取值范围: 1 <= BurstCount <= 4294967295

        Seconds (float):发送时间, 单位: sec, 默认值: 100, 取值范围: 0 < Seconds <= 4294967295

        Frames (int):发送帧数, 默认值: 1, 取值范围: 0 < Frames <= 4294967295

        LoadProfileType (PortLoadProfileType): 负载类型, 默认值: PORT_BASE, 取值范围:

            PortLoadProfileType.PortBase
            PortLoadProfileType.StreamBase
            PortLoadProfileType.PriorityBase
            PortLoadProfileType.ManualBase

        Rate (str):端口负载, 默认值: 10.0

        Unit (PortLoadProfileUnitType): 端口负载单位, 默认值: PortInterFrameGapUnitType.Percent, 取值范围:

            PortLoadProfileUnitType.Ns
            PortLoadProfileUnitType.Percent
            PortLoadProfileUnitType.FramePerSec
            PortLoadProfileUnitType.BytePerSec
            PortLoadProfileUnitType.DataBitPerSec
            PortLoadProfileUnitType.LineBitPerSec
            PortLoadProfileUnitType.InterFrameGapByte
            PortLoadProfileUnitType.KLineBitPerSec
            PortLoadProfileUnitType.MLineBitPerSec

        GenerateError (PortGenerateErrorType): 报文造错, 默认值: PortGenerateErrorType.NoError, 取值范围:

            PortGenerateErrorType.NoError
            PortGenerateErrorType.Crc

        IgnoreLinkState (PortIgnoreLinkStateType): 忽略连接状态, 默认值: PortIgnoreLinkStateType.No, 取值范围:

            PortIgnoreLinkStateType.No
            PortIgnoreLinkStateType.Yes

        TimeStampPosTx (PortTimeStampPosType): 发送时间戳位置, 默认值: PortTimeStampPosType.TimestampHead, 取值范围:

            PortTimeStampPosType.TimestampHead
            PortTimeStampPosType.TimestampTail

        TimeStampPosRx (PortTimeStampPosType): 接收时间戳位置, 默认值: PortTimeStampPosType.TimestampHead, 取值范围:

            PortTimeStampPosType.TimestampHead
            PortTimeStampPosType.TimestampTail

        LatencyCompensationTx (int): 发送时延补偿, 默认值: 0, 取值范围: 0 <= LatencyCompensationTx <= 4294967295

        LatencyCompensationRx (int): 接收时延补偿, 默认值: 0, 取值范围: 0 <= LatencyCompensationRx <= 4294967295

        LatencyCompensationOn (bool): 时延补偿开启, 默认值: True

    Returns:

        bool: 布尔值Bool (范围: True / False)

    Examples:
        python:

    .. code:: python

        edit_port_load_profile(Ports=ports, TransmitMode=PortTransmitModeType.Continuous, Unit=PortLoadProfileUnitType.FramePerSec, Rate=100)
        edit_port_load_profile(Ports=ports, TransmitMode=PortTransmitModeType.Burst, BurstSize=100, InterFrameGap=20, InterFrameGapUnit=PortInterFrameGapUnitType.Ms, BurstCount=100)
        edit_port_load_profile(Ports=ports, TransmitMode=PortTransmitModeType.Time, Seconds=10)
        edit_port_load_profile(Ports=ports, TransmitMode=PortTransmitModeType.Step, Frames=10)
        edit_port_load_profile(Ports=ports, TransmitMode=PortTransmitModeType.OnStream, Rate=50)
    """

    result = renix.edit_port_load_profile(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f"{sys._getframe().f_code.co_name} Failure")
    else:
        return result

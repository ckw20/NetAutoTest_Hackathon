from RenixLibrary.common.base import *
from enum import Enum

renix = RenixAPI()


class ProductType(Enum):
    BigTao = "BIGTAO"
    DarYu = "DARYU"


class PortSendModeType(Enum):
    Synchronous = "SYNCHRONOUS"
    Asynchronous = "ASYNCHRONOUS"


class MeshCreationModeType(Enum):
    PortBased = "PortBased"
    EndpointBased = "EndpointBased"


class RxLearningEncapsulationType(Enum):
    NoEncapsuLation = "NO_ENCAPSULATION"
    TxEncapsuLation = "TX_ENCAPSULATION"


class TestModeTypeType(Enum):
    TypeNorml = "TYPE_NORMAL"
    TypeCcScaleMode = "TYPE_CC_SCALE_MODE"
    TypeCcScaleModeWithoutRx = "TYPE_CC_SCALE_MODE_WITHOUT_RX"


class DmTimeUnitType(Enum):
    TimeMs = "TIME_MS"
    TimeNs = "TIME_NS"


class PortLineSpeedTpye(Enum):
    SpeedUnknown = "SPEED_UNKNOWN"
    Speed10M = "SPEED_10M"
    Speed100M = "SPEED_100M"
    Speed1G = "SPEED_1G"
    Speed2_5G = "SPEED_2_5G"
    Speed5G = "SPEED_5G"
    Speed10G = "SPEED_10G"
    Speed25G = "SPEED_25G"
    Speed40G = "SPEED_40G"
    Speed50G = "SPEED_50G"
    Speed100G = "SPEED_100G"
    Speed200G = "SPEED_200G"
    Speed400G = "SPEED_400G"
    Speed800G = "SPEED_800G"


class PortFecType(Enum):
    TypeOff = "TYPE_OFF"
    TypeRsFecClause91 = "TYPE_RS_FEC_CLAUSE91"
    TypeFecClause74 = "TYPE_FEC_CLAUSE74"
    TypeRsFecClause108 = "TYPE_RS_FEC_CLAUSE108"
    TypeRsFecConsortium = "TYPE_RS_FEC_CONSORTIUM"
    TypeRsFecClause119 = "TYPE_RS_FEC_CLAUSE119"


class PortDuplexType(Enum):
    Half = "HALF"
    Full = "FULL"


class PortFlowControlType(Enum):
    Disable = "DISABLE"
    Enable = "ENABLE"
    Auto = "AUTO"


class PortMediaType(Enum):
    Copper = "COPPER"
    Fiber = "FIBER"
    Fake = "FAKE"


class PortPhyModeType(Enum):
    ModeAuto = "MODE_AUTO"
    Mode100BaseX = "MODE_1000BASEX"
    ModeSgmii = "MODE_SGMII"


class PortDataPathModeType(Enum):
    Normal = "NORMAL"
    Loopback = "LOOPBACK"


class PortRemoteFaultType(Enum):
    Normal = "NORMAL"
    Ignore = "IGNORE"


class PortMasterType(Enum):
    AdvertiseSinglePort = "ADVERTISE_SINGLE_PORT"
    AdvertiseMultiPort = "ADVERTISE_MULTI_PORT"
    ManualMaster = "MANUAL_MASTER"
    ManualSlave = "MANUAL_SLAVE"


class PortTransmitModeType(Enum):
    Continuous = "CONTINUOUS"
    Burst = "BURST"
    Time = "TIME"
    Step = "STEP"
    OnStream = "ONSTREAM"


class PortInterFrameGapUnitType(Enum):
    Ns = "NS"
    Us = "US"
    Ms = "MS"
    Sec = "SEC"
    Bytes = "BYTES"


class PortLoadProfileType(Enum):
    PortBase = "PORT_BASE"
    StreamBase = "STREAM_BASE"
    PriorityBase = "PRIORITY_BASE"
    ManualBase = "MANUAL_BASE"


class PortLoadProfileUnitType(Enum):
    Ns = "Ns"
    Percent = "PERCENT"
    FramePerSec = "FRAME_PER_SEC"
    BytePerSec = "BYTE_PER_SEC"
    DataBitPerSec = "DATABIT_PER_SEC"
    LineBitPerSec = "LINEBIT_PER_SEC"
    InterFrameGapByte = "INTER_FRAME_GAP_BYTE"
    KLineBitPerSec = "KLINEBIT_PER_SEC"
    MLineBitPerSec = "MLINEBIT_PER_SEC"


class PortGenerateErrorType(Enum):
    NoError = "NO_ERROR"
    Crc = "CRC"


class PortIgnoreLinkStateType(Enum):
    Yes = "YES"
    No = "NO"


class PortTimeStampPosType(Enum):
    TimestampHead = "TIMESTAMP_HEAD"
    TimestampTail = "TIMESTAMP_TAIL"


class PortStateType(Enum):
    Down = "DOWN"
    Up = "UP"


class StreamLoadProfileType(Enum):
    Percent = "PERCENT"
    FramePerSec = "FRAME_PER_SEC"
    BytePerSec = "BYTE_PER_SEC"
    LineBitPerSec = "LINEBIT_PER_SEC"
    KLineBitPerSec = "KLINEBIT_PER_SEC"
    MLineBitPerSec = "MLINEBIT_PER_SEC"
    InterFrameGapByte = "INTER_FRAME_GAP_BYTE"


class StreamTransmitModeType(Enum):
    Continuous = "CONTINUOUS"
    Burst = "BURST"


class StreamBurstGapUnit(Enum):
    Ns = "NS"
    Us = "US"
    Ms = "MS"
    Sec = "SEC"


class InterfaceLayersType(Enum):
    Eth = "eth"
    Vlan = "vlan"
    Pppoe = "pppoe"
    L2tp = "l2tp"
    Ipv4 = "ipv4"
    Ipv6 = "ipv6"


class InterfaceTopsType(Enum):
    NoneType = "None"
    Ipv4 = "ipv4"
    Ipv6 = "ipv6"


class InterfaceRouterIdModeType(Enum):
    Range = "RANGE"
    List = "LIST"
    Rfc4814 = "RFC_4814"


class InterfaceLayerType(Enum):
    EthIILayer = "EthIILayer"
    VLANLayer = "VLANLayer"
    IPv4Layer = "IPv4Layer"
    IPv6Layer = "IPv6Layer"


class InterfaceIpv6LinkLocalGenType(Enum):
    FromGlobal = "FromGlobal"
    Eui64 = "EUI64"
    Customized = "Customized"


class InterfaceIpVersionType(Enum):
    Ipv4 = "IPv4"
    Ipv6 = "IPv6"


class CaptureModeType(Enum):
    All = "ALL"
    CtrlPlane = "CTRL_PLANE"
    RealTimeAll = "RealTime_All"


class CaptureCacheCapacityType(Enum):
    CacheMax = "Cache_Max"
    Cache32Kb = "Cache_32KB"
    Cache64Kb = "Cache_64KB"
    Cache128Kb = "Cache_256KB"
    Cache256Kb = "Cache_256KB"
    Cache512Kb = "Cache_512KB"
    Cache1Mb = "Cache_1MB"
    Cache2Mb = "Cache_2MB"
    Cache4Mb = "Cache_4MB"
    Cache8Mb = "Cache_8MB"
    Cache16Mb = "Cache_16MB"
    Cache32Mb = "Cache_32MB"
    Cache64Mb = "Cache_64MB"
    Cache128Mb = "Cache_128MB"
    Cache256Mb = "Cache_512MB"
    Cache512Mb = "Cache_512MB"
    Cache1Gb = "Cache_1GB"


class CaptureFilterModeType(Enum):
    Byte = "BYTE"
    Pdu = "PDU"


class CaptureBufferFullAction(Enum):
    Stop = "STOP"
    Wrap = "WRAP"


class CaptureSliceModeType(Enum):
    Disable = "DISABLE"
    Enable = "ENABLE"


class CapturePatternOperatorType(Enum):
    And = "AND"
    Or = "OR"
    Xor = "XOR"


class StreamHeaderType(Enum):
    Ethernetii = "ethernetii"
    Raw = "raw"
    Vlan = "vlan"
    Vxlan = "vxlan"
    Arp = "arp"
    Gre = "gre"
    Ipv4 = "ipv4"
    Ipv6 = "ipv6"
    Tcp = "tcp"
    Udp = "udp"
    L2tpv2data = "l2tpv2data"
    L2tpv2control = "l2tpv2control"
    L2tpv3controloverip = "l2tpv3controloverip"
    L2tpv3controloverudp = "l2tpv3controloverudp"
    L2tpv3dataoverip = "l2tpv3dataoverip"
    L2tpv3dataoverudp = "l2tpv3dataoverudp"
    Dhcpv4server = "dhcpv4server"
    Dhcpv4client = "dhcpv4client"
    Dhcpv6client = "dhcpv6client"
    Dhcpv6server = "dhcpv6server"
    Ppp = "ppp"
    Pppoe = "pppoe"
    Pppoediscovery = "pppoediscovery"
    Icmpv4echorequest = "icmpv4echorequest"
    Destunreach = "destunreach"
    Icmpv4echoreply = "icmpv4echoreply"
    Informationreply = "informationreply"
    Informationrequest = "informationrequest"
    Icmpv4parameterproblem = "icmpv4parameterproblem"
    Icmpv4redirect = "icmpv4redirect"
    Sourcequench = "sourcequench"
    Timeexceeded = "timeexceeded"
    Timestampreply = "timestampreply"
    Timestamprequest = "timestamprequest"
    Icmpmaskrequest = "icmpmaskrequest"
    Icmpmaskreply = "icmpmaskreply"
    Destinationunreachable = "destinationunreachable"
    Icmpv6echoreply = "icmpv6echoreply"
    Icmpv6echorequest = "icmpv6echorequest"
    Packettoobig = "packettoobig"
    Icmpv6parameterproblem = "icmpv6parameterproblem"
    Timeexceed = "timeexceed"
    Routersolicit = "routersolicit"
    Routeradvertise = "routeradvertise"
    Icmpv6redirect = "icmpv6redirect"
    Neighborsolicit = "neighborsolicit"
    Neighboradvertise = "neighboradvertise"
    Mldv1query = "mldv1query"
    Mldv1report = "mldv1report"
    Mldv1done = "mldv1done"
    Mldv2query = "mldv2query"
    Mldv2report = "mldv2report"
    Igmpv1 = "igmpv1"
    Igmpv1query = "igmpv1query"
    Igmpv2 = "igmpv2"
    Igmpv2query = "igmpv2query"
    Igmpv3report = "igmpv3report"
    Igmpv3query = "igmpv3query"
    Custom = "custom"
    Ospfv2linkstateupdate = "ospfv2linkstateupdate"
    Ospfv2linkstaterequest = "ospfv2linkstaterequest"
    Ospfv2databasedescription = "ospfv2databasedescription"
    Ospfv2linkstateacknowledge = "ospfv2linkstateacknowledge"
    Ospfv2unknown = "ospfv2unknown"
    Ospfv2hello = "ospfv2hello"
    Mpls = "mpls"
    L1csnpheader = "l1csnpheader"
    Isisl1helloheader = "isisl1helloheader"
    L1lspheader = "l1lspheader"
    L1psnpheader = "l1psnpheader"
    L2csnpheader = "l2csnpheader"
    Isisl2helloheader = "isisl2helloheader"
    L2lspheader = "l2lspheader"
    L2psnpheader = "l2psnpheader"
    P2phelloheader = "p2phelloheader"
    Gtpv1 = "gtpv1"
    Gtpv1opt = "gtpv1opt"
    Gtpv1exthdr = "gtpv1exthdr"
    Gtpv1ext = "gtpv1ext"
    Ipv6fragmentheader = "ipv6fragmentheader"
    Ipv6routingheader = "ipv6routingheader"
    Ipv6authenticationheader = "ipv6authenticationheader"
    Ipv6destinationheader = "ipv6destinationheader"
    Ipv6encapsulationheader = "ipv6encapsulationheader"
    Ipv6hopbyhopheader = "ipv6hopbyhopheader"
    Ipv6srheader = "ipv6srheader"
    Stag = "stag"
    Encapethernetii = "encapethernetii"
    Encapbackboneeth = "encapbackboneeth"
    Itag = "itag"
    MacInMAc = "mac-in-mac"
    Encapcustomereth = "encapcustomereth"
    Portmanagement = "portmanagement"
    Bier = "bier"
    Ccm = "ccm"
    Chdlc = "chdlc"
    Cw = "cw"
    Elsflogi = "elsflogi"
    Ethernet8023 = "8023"
    Goose = "goose"
    Logiclinkcontrol = "logiclinkcontrol"
    Cfg = "cfg"
    Pause = "pause"
    Pfc = "pfc"
    Vntag = "vntag"
    Fc = "fc"
    Chassisidtlv = "chassisidtlv"
    Portidtlv = "portidtlv"
    Ttltlv = "ttltlv"
    Endtlv = "endtlv"
    Hsrtag = "hsrtag"
    Prptag = "prptag"
    Rtag = "rtag"
    Sctp = "sctp"
    Trill = "trill"


class CaptureEventType(Enum):
    Qualify = "QUALIFY"
    Start = "START"
    Stop = "STOP"


class CaptureLogicalRelationType(Enum):
    And = "AND"
    Or = "OR"


class CaptureEventType(Enum):
    Ignore = "IGNORE"
    Include = "INCLUDE"
    Exclude = "EXCLUDE"


class CaptureInfoType(Enum):
    CaptureState = "CaptureState"
    ElapsedTime = "ElapsedTime"
    CapturedPacketCount = "CapturedPacketCount"
    BufferFull = "BufferFull"
    DownloadedPacketCount = "DownloadedPacketCount"
    CurrentDataFile = "CurrentDataFile"
    None_ = "None"


class StreamType(Enum):
    Raw = "raw"
    Binding = "binding"
    Pcap = "pcap"


class StreamLayerType(Enum):
    Ethernetii = "ETHERNETII"
    Vlan = "VLAN"
    Gre = "GRE"
    Ipv4 = "IPV4"
    Ipv6 = "IPV6"


class StreamTrafficMeshModeType(Enum):
    OneToOne = "ONE_TO_ONE"
    ManyToMany = "MANY_TO_MANY"
    FullMesh = "FULL_MESH"
    Congestion = "CONGESTION"
    Learning = "LEARNING"
    BackBone = "BACK_BONE"
    Pair = "PAIR"


class StreamEndPointMappingType(Enum):
    RoundRobin = "ROUND_ROBIN"
    ManyToMany = "MANY_TO_MANY"


class StreamFrameLengthType(Enum):
    Fixed = "FIXED"
    Increment = "INCREMENT"
    Random = "RANDOM"
    Auto = "AUTO"
    Decrement = "DECREMENT"
    Imix = "IMIX"


class StreamPayloadType(Enum):
    Cycle = "CYCLE"
    Increment = "INCREMENT"
    Random = "RANDOM"


class StreamPayLoadValueType(Enum):
    SingleByte = "SINGLE_BYTE"
    DoubleByte = "DOUBLE_BYTE"


class StreamModifierType(Enum):
    Increment = "Increment"
    Decrement = "Decrement"
    Random = "Random"
    List = "List"


class StreamModifierStreamType(Enum):
    IntraModifier = "IntraModifier"
    InterModifier = "InterModifier"


class StreamLinkModifierType(Enum):
    ModifierId = "MODIFIER_ID"
    LinkModifierPath = "LINK_MODIFIER_PATH"


class StreamSelectRxPortModeType(Enum):
    OneToOne = "ONE_TO_ONE"
    OneToMany = "ONE_TO_MANY"
    ManyToOne = "MANY_TO_ONE"
    Pair = "PAIR"


class StreamStartType(Enum):
    Port = "port"
    Stream = "stream"


class StreamStateType(Enum):
    Disable = "DISABLED"
    NotReady = "NOTREADY"
    Ready = "READY"
    Running = "RUNNING"
    Stopped = "STOPPED"
    Pause = "PAUSED"


class StreamL2LearningType(Enum):
    Tx = "Tx"
    Rx = "Rx"
    None_ = None


class Ipv4HeaderOptionsType(Enum):
    EndOfOption = "EndOfOption"
    Nop = "Nop"
    Security = "Security"
    LooseSourceRoute = "LooseSourceRoute"
    StrictSourceRoute = "StrictSourceRoute"
    RouterAlert = "RouterAlert"
    RecordRoute = "RecordRoute"
    TimeStamp = "TimeStamp"
    StreamIdentifier = "StreamIdentifier"
    General = "General"


class HeaderOptionType(Enum):
    Ipv4 = "ipv4"
    Destunreach = "destunreach"
    Parameterproblem = "parameterproblem"
    Redirect = "redirect"
    Sourcequench = "sourcequench"
    Timeexceeded = "timeexceeded"


class Ipv6DestinationHeaderOptionsType(Enum):
    Pad1 = "pad1"
    PadN = "padN"
    GeneralTLV = "generalTLV"
    Bierv6 = "bierv6"


class Ipv6HopbyhopHeaderOptionsType(Enum):
    Pad1 = "pad1"
    PadN = "padN"
    RouterAlert = "routerAlert"
    Jumbo = "jumbo"
    GeneralTLV = "generalTLV"


class Ipv6SrHeaderOptionsType(Enum):
    SRSegment = "sRSegment"
    SRIngressNodeTlv = "sRIngressNodeTlv"
    SREgressNodeTlv = "sREgressNodeTlv"
    SROpaqueContainerTlv = "sROpaqueContainerTlv"
    SRHmacTlv = "sRHmacTlv"
    SRPadding1Tlv = "sRPadding1Tlv"
    SRPaddingTlv = "sRPaddingTlv"
    GeneralTLV = "generalTLV"


class ProtocolNameType(Enum):
    BGP = "bgp"
    BFD = "bfd"
    ISIS = "isis"
    OSPFv2 = "ospfv2"
    OSPFv3 = "ospfv3"
    PIM = "pim"
    RIP = "rip"
    DOT1X = "dot1x"
    DOT1AG = "dot1ag"
    DOT3AH = "dot3ah"
    DHCPV4SERVER = "dhcpv4server"
    DHCPV4 = "dhcpv4"
    DHCPV6SERVER = "dhcpv6server"
    DHCPV6 = "dhcpv6"
    VXLAN = "vxlan"
    SAA = "saa"
    IGMP = "igmp"
    IGMPQUERY = "igmpquery"
    MLD = "mld"
    MLDQUERY = "mldquery"
    L2TP = "l2tp"
    PPPoECLIENT = "pppoeclient"
    PPPoESERVER = "pppoeserver"
    LDP = "ldp"
    LSPPING = "lspping"
    PCEP = "pcep"


class Dhcpv4ClientModeType(Enum):
    Client = "CLIENT"
    RelayAgent = "RELAY_AGENT"


class Dhcpv4ClientParameterRequestsType(Enum):
    NoneOption = "NONEOPTION"
    SubMask = "SUBNET_MASK"
    Routes = "ROUTES"
    DomainNameServers = "DOMAIN_NAME_SERVERS"
    DomainName = "DOMAIN_NAME"
    StaticRoutes = "STATIC_ROUTES"
    IpLeaseTime = "IP_LEASE_TIME"
    ServerIdentifier = "SERVER_IDENTIFIER"
    T1 = "T1"
    T2 = "T2"


class Dhcpv4ClientBroadcastFlagType(Enum):
    Unicast = "UNICAST"
    Broadcast = "BROADCAST"


class Dhcpv4OptionType(Enum):
    Hex = "HEX"
    String = "STRING"
    Boolean = "BOOLEAN"
    Int8 = "INT8"
    Int16 = "INT16"
    Int32 = "INT32"
    Ip = "IP"


class Dhcpv4ClientOptionMessageType(Enum):
    Discover = "DISCOVER"
    Request = "REQUEST"


class Dhcpv4ServerOptionMessageType(Enum):
    Offer = "OFFER"
    Ack = "ACK"
    Nak = "NAK"

# =================================================================================
# Objective   	:   测试目的 : 测试仪表连接机框
#
# Step			:	测试步骤1: 初始化仪表;
#                   测试步骤2: 连接单个机框;
#                   测试步骤3: 同时连接单两个机框;
#
# Criteria    	:   预期结果1: 步骤2，3机箱连接成功，能查看到机箱信息;
#
# Created by   	:  	Tester-001
#
# Bugs   	    :  	# None
# =================================================================================

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

# 获取文件路径和文件名称
dirname, tempfilename = os.path.split(os.path.abspath(__file__))
filename, extension = os.path.splitext(tempfilename)

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    print(sys_entry.__dict__)

    # 连接单个机框
    chassis_1 = connect_chassis(Chassis='10.0.11.192')[0]
    print(chassis_1.__dict__)

    # 同时连接单两个机框
    chassis_list = connect_chassis(Chassis=['10.0.11.103', '10.0.11.191'])
    for chassis in chassis_list:
        print(chassis.__dict__)


except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

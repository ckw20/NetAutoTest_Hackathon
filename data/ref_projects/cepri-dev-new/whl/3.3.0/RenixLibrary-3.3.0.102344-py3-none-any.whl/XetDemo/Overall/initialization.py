# =================================================================================
# Objective   	:   测试目的 : 初始化仪表测试
#
# Step			:	测试步骤1: 导入仪表包，初始化仪表;
#
# Criteria    	:   预期结果1: 步骤1 初始化仪表成功;
#
# Created by   	:  	Tester-001
#
# Bugs   	    :  	# None
# =================================================================================

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    print(sys_entry.__dict__)

except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

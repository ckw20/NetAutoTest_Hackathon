# =================================================================================
# Objective   	:   测试目的 : 测试仪表全局配置
#
# Step			:	测试步骤1: 初始化仪表;
#                   测试步骤2: 修改流全局配置;
#                   测试步骤3: 修改二层学习配置;
#                   测试步骤4: 修改ARP/ND选项;
#                   测试步骤5: 修改Y.1731全局配置;
#
# Criteria    	:   预期结果1: 步骤2，3，4 5配置修改成功;
#
# Created by   	:  	Tester-001
#
# Bugs   	    :  	# None
# =================================================================================

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

# 获取文件路径和文件名称
dirname, tempfilename = os.path.split(os.path.abspath(__file__))
filename, extension = os.path.splitext(tempfilename)

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    print(sys_entry.__dict__)

    # 修改流全局配置
    edit_overall_setting(PortSendMode=PortSendModeType.Asynchronous,
                         MeshCreationMode=MeshCreationModeType.EndpointBased)

    # 修改二层学习配置
    edit_overall_setting(Rate=4294967295, RepeatCount=4294967295, DelayTime=4294967295,
                         RxLearningEncapsulation=RxLearningEncapsulationType.TxEncapsuLation)

    # 修改ARP/ND选项
    edit_overall_setting(EnableAutoArp=False, StopOnArpFail=False, AutoArpWaitTime=4294967295)

    # 修改Y.1731全局配置
    edit_overall_setting(TestModeType=TestModeTypeType.TypeCcScaleMode, LmrRxFCfStart=4294967295, LmrRxFCfStep=65535,
                         DmTimeUnit=DmTimeUnitType.TimeNs)

    # 保存配置文件
    save_case(Path=f'{dirname}/{filename}.xcfg')

except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

# =================================================================================
# Objective   	:   测试目的 : DHCPv4协议操作
#
# Step			:	测试步骤1: 预约端口;
#                   测试步骤2: 创建接口;
#                   测试步骤3: 创建DHCPv4协议会话;
#                   测试步骤4: 修改DHCPv4协议会话;
#
# Criteria    	:   预期结果1: DHCPv4协议相关操作均正确;
#
# Created by   	:  	Tester-007
#
# Bugs   	    :  	None
# =================================================================================
import time

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

# 获取文件路径和文件名称
dirname, tempfilename = os.path.split(os.path.abspath(__file__))
filename, extension = os.path.splitext(tempfilename)

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)

    # 预约端口
    port1, port2 = reserve_port(Locations=['//10.0.11.191/1/5', '//10.0.11.191/1/6'])

    # 创建接口
    interface1 = create_interface(Port=port1)
    interface2 = create_interface(Port=port2)

    # 保证MAC地址不冲突
    edit_interface(Interface=interface2,
                   Layer=InterfaceLayerType.EthIILayer,
                   Address='12:12:12:12:12:12')
    edit_interface(Interface=interface2,
                   Layer=InterfaceLayerType.EthIILayer,
                   Address='12.12.12.1',
                   PrefixLength=19,
                   Gateway='12.12.12.2')

    # 创建DHCPv4协议会话
    client = create_dhcp_client(Port=port1)
    server = create_dhcp_server(Port=port2)

    # DHCPv4协议会话与接口绑定
    select_interface(Session=client, Interface=interface1)
    select_interface(Session=server, Interface=interface2)

    # 创建DHCP Server地址池
    dhcpv4AddressPool = create_dhcp_server_address_pool(Session=server,  PoolAddressStart='12.12.12.2', PrefixLength=19, PoolAddressCount=5100)

    # 保存配置文件
    dirname, tempfilename = os.path.split(os.path.abspath(__file__))
    filename, extension = os.path.splitext(tempfilename)
    save_case(Path=f'{dirname}/xcfg/{filename}.xcfg')

    # 启动DHCPv4协议会话
    start_protocol()
    time.sleep(5)

    # 停止DHCPv4协议会话
    stop_protocol()
    time.sleep(5)
    
except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

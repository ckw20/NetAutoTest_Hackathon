# =================================================================================
# Objective   	:   测试目的 : 测试仪表端口捕获操作
#
# Step			:	测试步骤1: 预约端口;
#                   测试步骤2: 修改捕获方式;
#                   测试步骤3: 下载捕获报文;
#                   测试步骤4: 获取捕获报文信息;
#
# Criteria    	:   预期结果1: 捕获相关操作均正确;
#
# Created by   	:  	Tester-002
#
# Bugs   	    :  	# None
# =================================================================================
import time

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

# 获取文件路径和文件名称
dirname, tempfilename = os.path.split(os.path.abspath(__file__))
filename, extension = os.path.splitext(tempfilename)

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    print(sys_entry.__dict__)

    # 预约端口
    port1, port2 = reserve_port(Locations=['//10.0.11.191/1/9', '//10.0.11.191/1/10'])

    # 修改端口数据捕获参数
    edit_capture(Ports=[port1, port2], CaptureMode=CaptureModeType.CtrlPlane.value)

    # 启动捕获
    start_capture()

    time.sleep(10)

    # 停止捕获
    stop_capture()

    # 下载报文
    download_packages(Port=port2, FileDir='C:/test', FileName='test.pcap')

    # 在指定端口报文捕获信息
    info = get_capture_info(Port=port2, Items=[CaptureInfoType.CapturedPacketCount.value, CaptureInfoType.DownloadedPacketCount.value])
    print(info)

    # 在指定端口报文捕获信息
    info = get_capture_data(Port=port2)
    print(info)


except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

# =================================================================================
# Objective   	:   测试目的 : 测试仪表端口操作
#
# Step			:	测试步骤1: 预约端口;
#                   测试步骤2: 重定向端口;
#                   测试步骤3: 修改端口配置;
#                   测试步骤4: 获取端口速率;
#                   测试步骤5: 修改端口负载;
#                   测试步骤6: 删除端口;
#
# Criteria    	:   预期结果1: 端口相关操作均正确;
#
# Created by   	:  	Tester-002
#
# Bugs   	    :  	# None
# =================================================================================

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

# 获取文件路径和文件名称
dirname, tempfilename = os.path.split(os.path.abspath(__file__))
filename, extension = os.path.splitext(tempfilename)

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    print(sys_entry.__dict__)

    # 预约端口
    port1, port2 = reserve_port(Locations=['//10.0.11.191/1/5', '//10.0.11.191/1/6'])
    print(port1.__dict__)
    print(port2.__dict__)

    # 重定向端口，需要端口下线
    release_port(Ports=[port1, port2])
    relocate_ports(Ports=[port1, port2], Locations=['//10.0.11.191/1/1', '//10.0.11.191/1/2'])
    print(port1.__dict__)
    print(port1.__dict__)

    # 修改端口配置
    edit_port(Ports=[port1, port2], Mtu=1518)
    assert port1.get_children('EthFiber')[0].get_children('EthFiberConfig')[0].Mtu == 1518
    assert port2.get_children('EthFiber')[0].get_children('EthFiberConfig')[0].Mtu == 1518

    # 获取端口速率
    print(get_port_speed(Ports=[port1, port2]))

    # 修改端口负载
    edit_port_load_profile(Ports=port1, TransmitMode=PortTransmitModeType.Burst, BurstSize=100)

    # 保存配置文件
    save_case(Path=f'{dirname}/{filename}.xcfg')

    # 删除端口
    del_port(Ports=[port1, port2])

except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

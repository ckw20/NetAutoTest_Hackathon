# =================================================================================
# Objective   	:   测试目的 : 测试仪表接口操作
#
# Step			:	测试步骤1: 预约端口;
#                   测试步骤2: 创建接口;
#                   测试步骤3: 修改接口结构;
#                   测试步骤4: 修改接口参数;
#                   测试步骤5: 启动接口arp;
#                   测试步骤6: 获取网关mac;
#
# Criteria    	:   预期结果1: 接口相关操作均正确;
#
# Created by   	:  	Tester-002
#
# Bugs   	    :  	# None
# =================================================================================
import time

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

# 获取文件路径和文件名称
dirname, tempfilename = os.path.split(os.path.abspath(__file__))
filename, extension = os.path.splitext(tempfilename)

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    print(sys_entry.__dict__)

    # 预约端口
    port1, port2 = reserve_port(Locations=['//10.0.11.191/1/5', '//10.0.11.191/1/6'])

    # 创建接口
    interface1 = create_interface(Port=port1)
    interface2 = create_interface(Port=port2)

    # 修改接口结构
    edit_interface_stack(Interfaces=[interface1, interface2], Tops=[InterfaceTopsType.Ipv4.value, InterfaceTopsType.Ipv6.value])

    # 修改接口参数
    edit_interface(Interface=interface1, Layer=InterfaceLayerType.IPv4Layer.value, Address='1.1.1.2', Gateway='1.1.1.1')
    edit_interface(Interface=interface2, Layer=InterfaceLayerType.IPv4Layer.value, Address='1.1.1.1', Gateway='1.1.1.2')
    edit_interface(Interface=interface1, Layer=InterfaceLayerType.IPv6Layer.value, Address='2001::2', Gateway='2001::1')
    edit_interface(Interface=interface2, Layer=InterfaceLayerType.IPv6Layer.value, Address='2001::1', Gateway='2001::2')

    # 启动接口arp
    start_arp()
    time.sleep(5)
    # 获取网关mac
    assert get_gateway_mac(Interface=interface1) != ''
    assert get_gateway_mac(Interface=interface2) != ''

    # 保存配置文件
    save_case(Path=f'{dirname}/{filename}.xcfg')


except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

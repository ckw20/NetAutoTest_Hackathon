# =================================================================================
# Objective   	:   测试目的 : 测试仪表端口操作
#
# Step			:	测试步骤1: 预约端口;
#                   测试步骤2: 创建流量;
#                   测试步骤3: 修改流量配置;
#                   测试步骤4: 修改流量报文头部;
#                   测试步骤5: 修改流量跳变;
#                   测试步骤6: 修改流量负载;
#                   测试步骤7: 发送、停止流的arp学习;
#                   测试步骤8: 发送、停止流量;
#
# Criteria    	:   预期结果1: 流量相关操作均正确;
#
# Created by   	:  	Tester-002
#
# Bugs   	    :  	# None
# =================================================================================
import time

from XetLibrary.base import *

verdict = 'pass'
errInfo = ''

# 获取文件路径和文件名称
dirname, tempfilename = os.path.split(os.path.abspath(__file__))
filename, extension = os.path.splitext(tempfilename)

try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)

    # 预约端口
    port1, port2 = reserve_port(Locations=['//10.0.11.191/1/5', '//10.0.11.191/1/6'])

    # 创建流量
    stream = add_stream(Ports=port1, FixedLength=256)

    # 修改流量
    edit_stream(Stream=stream, FrameLengthType=StreamFrameLengthType.Auto)

    # 修改流量报文头部
    create_stream_header(Stream=stream, HeaderTypes=['EthernetII', 'IPv4'])

    # ipv4头部Source字段添加Increment跳变
    edit_modifier(Stream=stream, Level=0, HeaderType='IPv4', Attribute='Source',
                  Type='Increment', Count=10, Step=2)

    # 修改流量负载
    edit_port_load_profile(Ports=port1, LoadProfileType=PortLoadProfileType.StreamBase.value)
    edit_stream_load_profile(Streams=stream, Unit=StreamLoadProfileType.FramePerSec.value, Rate=100)

    dirname, tempfilename = os.path.split(os.path.abspath(__file__))
    filename, extension = os.path.splitext(tempfilename)
    save_case(Path=f'{dirname}/xcfg/{filename}.xcfg')

    # 启动流的arp学习
    start_stream_arp()
    time.sleep(5)
    stop_stream_arp()

    # 发送流量
    start_stream()
    time.sleep(10)
    stop_stream()



except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')



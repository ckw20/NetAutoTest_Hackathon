# =================================================================================
# Objective   	:   测试目的 : 测试仪表组建ethernet vlan arp报文
#
# Step			:	测试步骤1: 预约两个自环端口Port_1、Port_2;
#                   测试步骤2: 修改流量StreamTemplate_1的头部内容;
#
# Criteria    	:   预期结果1: 步骤2中流量StreamTemplate_1修改正确;
#
# Created by   	:  	Tester-002
#
# Bugs   	    :  	None
# =================================================================================

from XetLibrary.base import *

locations = ['//10.0.11.191/1/5', '//10.0.11.191/1/6'] if len(sys.argv) < 2 else sys.argv[1].split(' ')

verdict = 'pass'
errInfo = ''
try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    # 创建端口，并预约端口
    Ports = reserve_port(Locations=locations, Force=True)
    # 创建流量
    stream = add_stream(Ports=Ports[0], FixedLength=256)
    # 修改流量报文头部
    create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii.value, StreamHeaderType.Vlan.value,
                                                     StreamHeaderType.Arp.value])
    # 修改EthernetII头部
    attribute_dict = edit_header_ethernet(Stream=stream, Level=0, DestMacAdd='00:00:00:00:00:01',
                                          SourceMacAdd='00:00:00:00:00:02')
    print(attribute_dict)
    # EthernetII头部目的Mac地址字段添加跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ethernetii.value, Attribute=attribute_dict['DestMacAdd'],
                  Count=10, Step=2)
    # EthernetII头部源Mac地址字段添加跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ethernetii.value, Attribute=attribute_dict['SourceMacAdd'],
                  Type=StreamModifierType.List,
                  List=['00:00:00:00:00:02', '00:00:00:00:00:03', '00:00:00:00:00:04', '00:00:00:00:00:05'])
    # 修改vlan头部
    attribute_dict = edit_header_vlan(Stream=stream, Level=0, ID=100, Priority=5, CFI=0)
    # vlan头部目字段添加Increment跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Vlan.value, Attribute=attribute_dict['ID'],
                  StreamType=StreamModifierStreamType.InterModifier,
                  Count=10, Step=2)
    # vlan头部目字段添加List跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Vlan.value, Attribute=attribute_dict['Priority'],
                  Type=StreamModifierType.List,
                  List=[2, 4, 6, 3])
    # vlan头部目字段添加Random跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Vlan.value, Attribute=attribute_dict['CFI'],
                  Type=StreamModifierType.Random,
                  Range=1)
    # 修改arp头部
    attribute_dict = edit_header_arp(Stream=stream, Level=0, SendMac='00:00:00:00:00:01',
                                     SendIpv4='192.168.0.2', TargetIpv4='192.168.0.1')
    # arp头部SendMac字段添加Increment跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Arp.value, Attribute=attribute_dict['SendMac'],
                  Count=10, Step=2)
    # arp头部目SendIpv4字段添加List跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Arp.value, Attribute=attribute_dict['SendIpv4'],
                  Type=StreamModifierType.List,
                  List=['192.168.0.2', '192.168.0.5', '192.168.0.3'])
    # arp头部目TargetIpv4字段添加Random跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Arp.value, Attribute=attribute_dict['TargetIpv4'],
                  Type=StreamModifierType.Random,
                  Range='200.168.0.1')

    # 保存配置文件
    dirname, tempfilename = os.path.split(os.path.abspath(__file__))
    filename, extension = os.path.splitext(tempfilename)
    save_case(Path=f'{dirname}/xcfg/{filename}.xcfg')

    # 释放端口资源
    result = release_port(Locations=locations)
except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

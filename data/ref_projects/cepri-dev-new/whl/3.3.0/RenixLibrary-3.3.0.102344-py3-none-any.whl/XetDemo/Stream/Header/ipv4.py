# =================================================================================
# Objective   	:   测试目的 : 测试仪表组建ipv4报文
#
# Step			:	测试步骤1: 预约两个自环端口Port_1、Port_2;
#                   测试步骤2: 修改流量StreamTemplate_1的ipv4头部内容;
#
# Criteria    	:   预期结果1: 步骤2中流量StreamTemplate_1修改正确;
#
# Created by   	:  	Tester-002
#
# Bugs   	    :  	None
# =================================================================================

from XetLibrary.base import *

locations = ['//10.0.11.191/1/5', '//10.0.11.191/1/6'] if len(sys.argv) < 2 else sys.argv[1].split(' ')

verdict = 'pass'
errInfo = ''
try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    # 创建端口，并预约端口
    Ports = reserve_port(Locations=locations, Force=True)
    # 创建流量
    stream = add_stream(Ports=Ports[0], FixedLength=256)
    # 修改流量报文头部
    create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii.value, StreamHeaderType.Ipv4.value])
    # 修改ipv4头部
    attribute_dict = edit_header_ipv4(Stream=stream, Level=0, TTL=200, Source='10.1.1.2', Destination='20.1.1.2',
                                      Flags=111, HeaderOption=[Ipv4HeaderOptionsType.Security, Ipv4HeaderOptionsType.RouterAlert,
                                                               Ipv4HeaderOptionsType.LooseSourceRoute])
    # ipv4头部Source字段添加Increment跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ipv4.value, Attribute=attribute_dict['Source'],
                  Type=StreamModifierType.Increment, Count=10, Step=2)
    # 修改ipv4头部，添加一个Security
    attribute_dict_security = edit_header_ipv4_option(Stream=stream, Index=0, Option=Ipv4HeaderOptionsType.Security, Security=1)
    # ipv4头部Security的Security字段添加List跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ipv4.value, Attribute=attribute_dict_security['Security'],
                  Type=StreamModifierType.List, List=[1, 11, 111])
    # ipv4头部RouterAlert的Length字段添加Random跳变
    attribute_dict_RouterAlert = edit_header_ipv4_option(Stream=stream, Index=1, Option=Ipv4HeaderOptionsType.RouterAlert, Length=10)
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ipv4.value, Attribute=attribute_dict_RouterAlert['Length'],
                  Type=StreamModifierType.Random, Range=15)
    # 修改ipv4头部，添加一个LooseSourceRoute节点
    attribute_dict_loose = edit_header_ipv4_option(Stream=stream, Index=2, Option=Ipv4HeaderOptionsType.LooseSourceRoute,
                                                   AddressList=['1.1.1.1', '2.2.2.2'])
    # 修改其中一个地址的跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ipv4.value, Attribute=attribute_dict_loose['AddressList: 2.2.2.2'],
                  Type=StreamModifierType.Increment, Count=10)
    # 修改ipv4头部，添加一个TimeStamp节点
    timestamp = edit_header_ipv4_option(Stream=stream, Index=3, Option=Ipv4HeaderOptionsType.TimeStamp,
                                        TimeStampSet=['10203040', '50607080'])
    # 修改其中一个地址的跳变
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Ipv4.value, Attribute=timestamp['TimeStampSet: 50607080'],
                  Type=StreamModifierType.Increment, Count=10)


    # 保存配置文件
    dirname, tempfilename = os.path.split(os.path.abspath(__file__))
    filename, extension = os.path.splitext(tempfilename)
    save_case(Path=f'{dirname}/xcfg/{filename}.xcfg')

    # 释放端口资源
    result = release_port(Locations=locations)
except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

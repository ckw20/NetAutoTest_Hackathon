# =================================================================================
# Objective   	:   测试目的 : 测试仪表组建udp报文
#
# Step			:	测试步骤1: 预约两个自环端口Port_1、Port_2;
#                   测试步骤2: 修改流量StreamTemplate_1的udp头部内容;
#
# Criteria    	:   预期结果1: 步骤2中流量StreamTemplate_1修改正确;
#
# Created by   	:  	Tester-002
#
# Bugs   	    :  	None
# =================================================================================

from XetLibrary.base import *

locations = ['//10.0.11.191/1/5', '//10.0.11.191/1/6'] if len(sys.argv) < 2 else sys.argv[1].split(' ')

verdict = 'pass'
errInfo = ''
try:

    # 初始化仪表，执行仪表平台为DarYu
    sys_entry = init_tester(Product=ProductType.DarYu)
    # 创建端口，并预约端口
    Ports = reserve_port(Locations=locations, Force=True)
    # 创建流量
    stream = add_stream(Ports=Ports[0], FixedLength=256)
    # 修改流量报文头部
    create_stream_header(Stream=stream, HeaderTypes=[StreamHeaderType.Ethernetii.value, StreamHeaderType.Ipv4.value,
                                                     StreamHeaderType.Udp.value])
    # 修改udp头部
    header = edit_header_udp(Stream=stream, Level=0,
                             SourcePort=1000, DestPort=2000)
    edit_modifier(Stream=stream, Level=0, HeaderType=StreamHeaderType.Udp.value,
                  Attribute=header['SourcePort'],
                  Type=StreamModifierType.Increment,
                  Count=10, Step=2)

    # 保存配置文件
    dirname, tempfilename = os.path.split(os.path.abspath(__file__))
    filename, extension = os.path.splitext(tempfilename)
    save_case(Path=f'{dirname}/xcfg/{filename}.xcfg')

    # 释放端口资源
    result = release_port(Locations=locations)
except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')

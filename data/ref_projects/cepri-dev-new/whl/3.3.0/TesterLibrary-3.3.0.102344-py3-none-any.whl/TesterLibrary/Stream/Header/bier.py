import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure

def edit_header_bier(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Bier报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Bier头部在流量模板中所有Bier头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        BiftId (int): BIFT-ID, 默认值：1，取值范围：0-1048575

        TrafficClass (int): Traffic Class, 默认值：0，取值范围：0-7

        SBit (bit): BIFT-ID, 默认值：1，取值范围：0-1

        Ttl (int): TTL, 默认值：64，取值范围：0-255

        Nibble (bit): Nibble, 默认值：0101，取值范围：0000-1111

        BierVer (int): Bier Version, 默认值：0，取值范围：0-7

        Bsl (int): BSL, 默认值：4，取值范围：0-7

        Entropy (int): Entropy, 默认值：1，取值范围：0-1048575

        Oam (int): OAM, 默认值：0，取值范围：0-3

        Rsv (int): RSV, 默认值：0，取值范围：0-3

        Dscp (int): DSCP, 默认值：0，取值范围：0-63

        Protocol (int): Protocol, 默认值：63，取值范围：0-63

        BfirId (int): BFIR-ID, 默认值：1，取值范围：0-65535

        BierbitString (int): 要插入的bit string个数, 默认值：0，取值范围：0-100

    Returns:

        dict: eg::

            {
                'BiftId': 'biftId',
                'TrafficClass': 'trafficClass',
                'SBit': 'sBit',
                'Ttl': 'ttl',
                'Nibble': 'nibble',
                'BierVer': 'bierVer',
                'Bsl': 'bsl',
                'Entropy': 'entropy',
                'Oam': 'oam',
                'Rsv': 'rsv',
                'Dscp': 'dscp',
                'Protocol': 'protocol',
                'BfirId': 'bfirId'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Bier | Stream=${Stream} | Level=0 | BiftId=10 |
    """

    result = renix.edit_header_bier(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_bier_bit_string(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Bier报文头部的Bit String内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Bier头部在流量模板中所有Bier头部的序列号

        Index (int): 要修改的Bier头部Bit String在流量模板中所有Bier头部Bit String的序列号

    Keyword Args:

        BitString (bit): Bit String, 默认值：01010101010101010101010101010101，取值范围：长度为32的二进制数

        BitString2 (bit): Bit String, 默认值：01010101010101010101010101010101，取值范围：长度为32的二进制数

    Returns:

        dict: eg::

            {
                'BitString': 'bierbitString.customOption_0.bitStringsOption.bitString',
                'BitString2': 'bierbitString.customOption_0.bitStringsOption.bitString2',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=bier |
            | Edit Header Bier Bit String | Stream=${Stream} | Level=0 | Index=0 | BitString=10101010101010101010101010101010 |
    """

    result = renix.edit_header_bier_bit_string(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_dhcpv6_client(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv6 Client报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的DHCPv6 Client头部在流量模板中所有DHCPv6 Client头部的序列号

    Keyword Args:

        MessageType (int): Message Type，默认值：1，取值范围：0-255

        TransId (int): Transaction ID，默认值：1，取值范围：0-16777215

        OptionHeaders (list): 支持的参数有：

            clientIdOption

            serverIdOption

            ianaOption

            requestOption

            elapsedTimeOption

            serverUnicastOption

            statusCodeOption

            rapidCommitOption

            interfaceIdOption

            reconfigureAcceptOption

            iapdOption

            customOption

            generalTLV

    Returns:

        dict: eg::

            {
                'MessageType': 'messageType'
                'TransId': 'transId'
                'OptionHeaders': True
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | UDP | dhcpv6Client |
            | ${OptionHeaders} | Create List | clientIdOption | serverIdOption | ianaOption | requestOption |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header DHCPv6 Client | Stream=${Stream} | Level=0 | messageType=1 | OptionHeaders=${OptionHeaders} |
    """

    result = renix.edit_header_dhcpv6_client(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_dhcpv6_server(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv6 Server报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的DHCPv6 Server头部在流量模板中所有DHCPv6 Server头部的序列号

    Keyword Args:

         MessageType (int): Message Type，默认值：1，取值范围：0-255

         TransId (int): Transaction ID，默认值：1，取值范围：0-16777215

         OptionHeaders (list): Options，默认值：“”，支持的参数有：

             clientIdOption

             serverIdOption

             ianaOption

             requestOption

             elapsedTimeOption

             serverUnicastOption

             statusCodeOption

             rapidCommitOption

             interfaceIdOption

             reconfigureAcceptOption

             iapdOption

             customOption

             generalTLV

    Returns:

        dict: eg::

            {
                'MessageType': 'messageType'
                'TransId': 'transId'
                'OptionHeaders': True
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | UDP | dhcpv6Server |
            | ${OptionHeaders} | Create List | clientIdOption | serverIdOption | ianaOption | requestOption |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header DHCPv6 Server | Stream=${Stream} | Level=0 | messageType=1 | OptionHeaders=${OptionHeaders} |
    """

    result = renix.edit_header_dhcpv6_server(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_dhcpv6_option(Stream, Types, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv6 Server/Client报文中Option头部内容.

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Types (str): DHCPv6 Server/Client报文option类型支持：

            ClientIdOption

            ServerIdOption

            IanaOption

            RequestOption

            ElapsedTimeOption

            ServerUnicastOption

            StatusCodeOption

            RapidCommitOption

            InterfaceIdOption

            ReconfigureAcceptOption

            IapdOption

            CustomOption

            GeneralTLV

        Level (int): 要修改的DHCPv6 Server/Client头部在流量模板中所有DHCPv6 Server/Client头部的序列号

        Index (int): 要修改的DHCPv6 Server/Client Option头部在流量模板中所有DHCPv6 Server/Client Option头部的序列号

    Keyword Args:

        clientIdOption支持：

            Type (int): Option Type，默认值：<AUTO>1，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>10，取值范围：0-65535

            Duid (hex): DUID，默认值：00030001000003010103，取值范围：长度0-1024字节的十六进制数

        serverIdOption支持：

            Type (int): Option Type，默认值：<AUTO>1，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>10，取值范围：0-65535

            DuidType (int): DUID Type，默认值：<AUTO>3，取值范围：0-65535

            HardwareType (int): hardware Type，默认值：<AUTO>1，取值范围：0-65535

            LinkAddress (str): Link-layer Address，默认值：00:00:03:01:01:02，取值范围：有效的mac地址

        ianaOption支持：

            Type (int): Option Type，默认值：<AUTO>3，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>12，取值范围：0-65535

            Iaid (hex): IAID，默认值：00050001，取值范围：长度为4字节的十六进制数

            T1 (int): T1，默认值：302400，取值范围：0-65535

            T2 (int): T2，默认值：483840，取值范围：0-65535

            IaOption (int): IA Option数量, 默认值：0，取值范围：0-1

        requestOption支持：

            Type (int): Option，默认值：<AUTO>6，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>2，取值范围：0-65535

            Value (hex): Request Code，默认值：0018，取值范围：长度为0-1024的十六进制数

        elapsedTimeOption支持：

            Type (int): Option，默认值：<AUTO>8，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>2，取值范围：0-65535

            ElapseTime (int): Elapsed Time，默认值：0，取值范围：0-65535

        serverUnicastOption支持：

            Type (int): Option，默认值：<AUTO>12，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>16，取值范围：0-65535

            ServerAddress (str): Server Address，默认值：2001::2，取值范围：有效的ipv6地址

        statusCodeOption支持：

            Type (int): Option，默认值：<AUTO>13，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>9，取值范围：0-65535

            StatusCode (int): Status Code，默认值：0，取值范围：0-65535

            StatusMsg (hex): Status Messag，默认值：53756363657373，取值范围：长度为5-1024的十六进制数

        rapidCommitOption支持：

            Type (int): Option，默认值：<AUTO>14，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>0，取值范围：0-65535

        interfaceIdOption支持：

            Type (int): Option，默认值：<AUTO>14，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>0，取值范围：0-65535

            InterfaceId (hex): Interface-ID，默认值：0123456789，取值范围：长度为5-1024的十六进制数

        reconfigureAcceptOption支持：

            Type (int): Option，默认值：<AUTO>20，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>0，取值范围：0-65535

        iapdOption支持：

            Type (int): Option，默认值：<AUTO>25，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>41，取值范围：0-65535

            Iaid (hex): IAID，默认值：00050001，取值范围：0000-FFFF

            T1 (int): T1，默认值：302400，取值范围：0-65535

            T2 (int): T2，默认值：483840，取值范围：0-65535

            IaOption (int): IA Option数量, 默认值：0，取值范围：0-1

        customOption支持：

            Type (int): Option，默认值：<AUTO>0，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>0，取值范围：0-65535

            Value (hex): Request Code，默认值：00，取值范围：长度为0-256的十六进制数

        generalTLV支持：

            Type (int): Option，默认值：<AUTO>0，取值范围：0-65535

            Length (int): Length，默认值：<AUTO>0，取值范围：0-65535

            Value (hex): Request Code，默认值：00，取值范围：长度为0-256的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'options.Dhcpv6Options_0.generalTLV.type'
                'Length': 'options.Dhcpv6Options_0.generalTLV.length'
                'Value': 'options.Dhcpv6Options_0.generalTLV.value'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | UDP | dhcpv6Server |
            | ${LsaHeaders} | Create List | clientIdOption | serverIdOption | ianaOption | iapdOption |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header DHCPv6 Server | Stream=${Stream} | Level=0 | UsePriority=1 | OptionHeaders=${OptionHeaders} |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=0 | Types=ClientIdOption | Length=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=1 | Types=ServerIdOption | Length=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=2 | Types=IanaOption | Length=1 | OptionIndex=0 | Subtype=Dhcpv6IaAddress | IaOption=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=2 | Types=iapdOption | Length=1 | OptionIndex=0 | Subtype=Dhcpv6IaPrefix | IaOption=1 |
    """

    result = renix.edit_header_dhcpv6_option(Stream=Stream, Types=Types, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_dhcpv6_option_ia_address(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv6 Server/Client IANA头部IA Option内容.

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的DHCPv6 Server头部在流量模板中所有DHCPv6 Server头部的序列号

        Index (int): 要修改的DHCPv6 Server Option头部在流量模板中所有DHCPv6 Server Option头部的序列号

    Keyword Args:

        Type (int): Option，默认值：<AUTO>5，取值范围：0-65535

        Length (int): Length，默认值：<AUTO>24，取值范围：0-65535

        Ipv6Address (str): IPv6 Address，默认值：2001::3，取值范围：有效的ipv6地址

        PreferredLifetime (hex): Preferred Lifetime，默认值：604800，取值范围：0-4294967245

        ValidLifetime (int): Valid Lifetime，默认值：2592000，取值范围：0-4294967245

    Returns:

        dict: eg::

            {
                'Type': 'options.Dhcpv6Options_2.ianaOption.iaOption.Dhcpv6IaAddress_0.type',
                'Length': 'options.Dhcpv6Options_2.ianaOption.iaOption.Dhcpv6IaAddress_0.length',
                'Ipv6Address': 'options.Dhcpv6Options_2.ianaOption.iaOption.Dhcpv6IaAddress_0.ipv6Address',
                'PreferredLifetime': 'options.Dhcpv6Options_2.ianaOption.iaOption.Dhcpv6IaAddress_0.preferredLifetime',
                'ValidLifetime': 'options.Dhcpv6Options_2.ianaOption.iaOption.Dhcpv6IaAddress_0.validLifetime'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | UDP | dhcpv6Server |
            | ${LsaHeaders} | Create List | clientIdOption | serverIdOption | ianaOption | iapdOption |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | ${IaOptionone} | Create Dictionary | type=5 | ipv6Address=2020::1 |
            | ${IaOptiontwo} | Create Dictionary | prefixLength=128 | ipv6Address=2022::3 |
            | Edit Header DHCPv6 Server | Stream=${Stream} | Level=0 | UsePriority=1 | OptionHeaders=${OptionHeaders} |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=0 | Types=ClientIdOption | Length=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=1 | Types=ServerIdOption | Length=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=2 | Types=IanaOption | Length=1 | OptionIndex=0 | Subtype=Dhcpv6IaAddress | IaOption=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=3 | Types=iapdOption | Length=1 | OptionIndex=0 | Subtype=Dhcpv6IaPrefix | IaOption=1 |
            | Edit Header Dhcpv6 Option Ia Address | Stream=${Stream} | Level=0 | Index=2 | Type=5 | Ipv6Address=2020::1 |
    """

    result = renix.edit_header_dhcpv6_option_ia_address(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_dhcpv6_option_ia_prefix(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv6 Server/Client IAPD头部IA Prefix内容.

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的DHCPv6 Server头部在流量模板中所有DHCPv6 Server头部的序列号

        Index (int): 要修改的DHCPv6 Server Option头部在流量模板中所有DHCPv6 Server Option头部的序列号

    Keyword Args:

        Type (int): Option，默认值：<AUTO>26，取值范围：0-65535

        Length (int): Length，默认值：<AUTO>25，取值范围：0-65535

        PreferredLifetime (hex): Preferred Lifetime，默认值：604800，取值范围：0-4294967245

        ValidLifetime (int): Valid Lifetime，默认值：2592000，取值范围：0-4294967245

        PrefixLength (int): Prefix Length，默认值：64，取值范围：0-255

        Ipv6Address (str): IPv6 Address，默认值：2001::3，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'options.Dhcpv6Options_0.generalTLV.type'
                'Length': 'options.Dhcpv6Options_0.generalTLV.length'
                'Ipv6Address': 'options.Dhcpv6Options_0.generalTLV.value'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | UDP | dhcpv6Server |
            | ${LsaHeaders} | Create List | clientIdOption | serverIdOption | ianaOption | iapdOption |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | ${IaOptionone} | Create Dictionary | type=5 | ipv6Address=2020::1 |
            | ${IaOptiontwo} | Create Dictionary | prefixLength=128 | ipv6Address=2022::3 |
            | Edit Header DHCPv6 Server | Stream=${Stream} | Level=0 | UsePriority=1 | OptionHeaders=${OptionHeaders} |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=0 | Types=ClientIdOption | Length=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=1 | Types=ServerIdOption | Length=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=2 | Types=IanaOption | Length=1 | OptionIndex=0 | Subtype=Dhcpv6IaAddress | IaOption=1 |
            | Edit Header DHCPv6 Server Option | Stream=${Stream} | Level=0 | Index=3 | Types=iapdOption | Length=1 | OptionIndex=0 | Subtype=Dhcpv6IaPrefix | IaOption=1 |
            | Edit Header Dhcpv6 Option Ia Address | Stream=${Stream} | Level=0 | Index=2 | Type=5 | Ipv6Address=2020::1 |
            | Edit Header Dhcpv6 Option Ia Prefix | Stream=${Stream} | Level=0 | Index=3 | PrefixLength=128 | Ipv6Address=2022::3 |
    """

    result = renix.edit_header_dhcpv6_option_ia_prefix(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_ppp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中PPP报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的PPP头部在流量模板中所有PPP头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Addresses (hex): address, 默认值：<AUTO>FF, 取值范围：00-FF

        Controls (hex): control, 默认值：<AUTO>03, 取值范围：00-FF

        Protocol (hex): protocol, 默认值：<AUTO>0000, 取值范围：0000-FFFF

    Returns:

        dict: eg::

            {
                'Addresses': 'addresses.Address_0.value',
                'Controls': 'controls.Control_0.value',
                'Protocol': 'protocol'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Ppp | Stream=${Stream} | Level=0 | Addresses=192.168.0.1 |
    """

    result = renix.edit_header_ppp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中PPPoE报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的PPPoE头部在流量模板中所有PPPoE头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version, 默认值：1, 取值范围：0-15

        Type (int): Type, 默认值：1, 取值范围：0-15

        Code (hex): Code, 默认值：00, 取值范围：00-FF

        SessionId (int): Session ID, 默认值：0, 取值范围：0-65535

        PayloadLen (int): Payload Length, 默认值：<AUTO>0, 取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Version': 'addresses',
                'Type': 'controls',
                'Code': 'protocol',
                'SessionId': 'sessionId',
                'PayloadLen': 'payloadLen'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Pppoe | Stream=${Stream} | Level=0 | Code=11 |
    """

    result = renix.edit_header_pppoe(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_pppoe_discovery(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中PPPoE Discovery报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的PPPoE Discovery头部在流量模板中所有PPPoE Discovery头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version, 默认值：1, 取值范围：0-15

        Type (int): Type, 默认值：1, 取值范围：0-15

        Code (int): Code, 默认值：9, 取值范围：

            9: PADI

            7: PADO

            25: PADR

            101: PADS

            167: PADT

        SessionId (int): Session ID, 默认值：0, 取值范围：0-65535

        PayloadLen (int): Payload Length, 默认值：<AUTO>0, 取值范围：0-65535

        EndOfListTag (int): 要插入的End Of List Tag个数，默认值：0，取值范围：0-1

        ServiceNameTag (int): 要插入的Server Name Tag个数，默认值：0，取值范围：0-1

        AcNameTag (int): 要插入的Ac Name Tag个数，默认值：0，取值范围：0-1

        HostUniqTag (int): 要插入的Host Uniq Tag个数，默认值：0，取值范围：0-1

        AcCookieTag (int): 要插入的Ac Cookie Tag个数，默认值：0，取值范围：0-1

        VendorSpecificTag (int): 要插入的Vendor Specific Tag个数，默认值：0，取值范围：0-1

        RelaySessionIdTag (int): 要插入的Relay Session Id Tag个数，默认值：0，取值范围：0-1

        ServiceNameErrorTag (int): 要插入的Service Name Error Tag个数，默认值：0，取值范围：0-1

        AcSystemErrorTag (int): 要插入的Ac System Error Tag个数，默认值：0，取值范围：0-1

        GenericErrorTag (int): 要插入的Generic Error Tag个数，默认值：0，取值范围：0-1

        UnknownTag (int): 要插入的Unknown Tag个数，默认值：0，取值范围：0-1

    Returns:

        dict: eg::

            {
                'Version': 'addresses',
                'Type': 'controls',
                'Code': 'protocol',
                'SessionId': 'sessionId',
                'PayloadLen': 'payloadLen'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Pppoe Discovery | Stream=${Stream} | Level=0 | Code=11 |
    """

    result = renix.edit_header_pppoe_discovery(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_pppoe_discovery_end_of_list_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的End Of List Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部End Of List Tag在流量模板中所有Pppoe Discovery头部End Of List Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0000，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagEndOfList.type',
                'Length': 'tags.tagList_0.tagEndOfList.length',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery End Of List Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_end_of_list_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_service_name_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Server Name Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Server Name Tag在流量模板中所有Pppoe Discovery头部Server Name Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0101，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagServiceName.type',
                'Length': 'tags.tagList_0.tagServiceName.length',
                'Value': 'tags.tagList_0.tagServiceName.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Server Name Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_service_name_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_ac_name_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Ac Name Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Ac Name Tag在流量模板中所有Pppoe Discovery头部Ac Name Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0102，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagACName.type',
                'Length': 'tags.tagList_0.tagACName.length',
                'Value': 'tags.tagList_0.tagACName.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Ac Name Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_ac_name_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_pppoe_discovery_host_uniq_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Host Uniq Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Host Uniq Tag在流量模板中所有Pppoe Discovery头部Host Uniq Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0103，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagHostUniq.type',
                'Length': 'tags.tagList_0.tagHostUniq.length',
                'Value': 'tags.tagList_0.tagHostUniq.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Host Uniq Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_host_uniq_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_ac_cookie_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Ac Cookie Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Ac Cookie Tag在流量模板中所有Pppoe Discovery头部Ac Cookie Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0104，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagACCookie.type',
                'Length': 'tags.tagList_0.tagACCookie.length',
                'Value': 'tags.tagList_0.tagACCookie.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Ac Cookie Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_ac_cookie_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_vendor_specific_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Vendor Specific Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Vendor Specific Tag在流量模板中所有Pppoe Discovery头部Vendor Specific Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0105，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagVendorSpecific.type',
                'Length': 'tags.tagList_0.tagVendorSpecific.length',
                'Value': 'tags.tagList_0.tagVendorSpecific.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Vendow Specific Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_vendor_specific_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_relay_session_id_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Relay Session Id Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Relay Session Id Tag在流量模板中所有Pppoe Discovery头部Relay Session Id Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0110，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagRelaySessionId.type',
                'Length': 'tags.tagList_0.tagRelaySessionId.length',
                'Value': 'tags.tagList_0.tagRelaySessionId.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Relay Session Id Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_relay_session_id_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_server_name_error_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Relay Session Id Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Relay Session Id Tag在流量模板中所有Pppoe Discovery头部Relay Session Id Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0110，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagServiceNameError.type',
                'Length': 'tags.tagList_0.tagServiceNameError.length',
                'Value': 'tags.tagList_0.tagServiceNameError.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Server Name Error Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_server_name_error_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_ac_system_error_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Ac System Error Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Ac System Error Tag在流量模板中所有Pppoe Discovery头部Ac System Error Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0202，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagACSystemError.type',
                'Length': 'tags.tagList_0.tagACSystemError.length',
                'Value': 'tags.tagList_0.tagACSystemError.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Ac System Error Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_ac_system_error_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_generic_error_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Generic Error Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Generic Error Tag在流量模板中所有Pppoe Discovery头部Generic Error Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0203，取值范围：

            0000: End Of List

            0101: Service Name

            0102: AC Name

            0103: Host Uniq

            0104: AC Cookie

            0105: Vendor Specific

            0110: Relay Session Id

            0201: Service Name Error

            0202: AC System Error

            0203: Generic Error

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-250的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagGenericError.type',
                'Length': 'tags.tagList_0.tagGenericError.length',
                'Value': 'tags.tagList_0.tagGenericError.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Generic Error Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_generic_error_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_pppoe_discovery_unknown_tag(Stream, Level=0, TagIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Pppoe Discovery报文头部的Unknown Tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pppoe Discovery头部在流量模板中所有Pppoe Discovery头部的序列号

        TagIndex (int): 要修改的Pppoe Discovery头部Unknown Tag在流量模板中所有Pppoe Discovery头部Unknown Tag的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0000，取值范围：00-FF

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Tag Value, 默认值：0，取值范围：长度0-40的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'tags.tagList_0.tagGenericError.type',
                'Length': 'tags.tagList_0.tagGenericError.length',
                'Value': 'tags.tagList_0.tagGenericError.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=pppoediscovery |
            | Edit Header Pppoe Discovery Unknown Tag | Stream=${Stream} | Level=0 | TagIndex=0 | Type=0101 |
    """

    result = renix.edit_header_pppoe_discovery_unknown_tag(Stream=Stream, Level=Level, TagIndex=TagIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


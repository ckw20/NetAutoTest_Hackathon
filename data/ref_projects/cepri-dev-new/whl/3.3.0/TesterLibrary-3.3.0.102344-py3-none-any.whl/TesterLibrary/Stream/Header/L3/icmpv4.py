import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Header ICMPv4-------------------------------------
def edit_header_icmp_echo_request(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Echo Request报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 范围: 0-65535: 要修改的Icmp Echo Request头部在流量模板中所有Icmp Echo Request头部的序列号

    Keyword Args:

        Type (int): Type，默认值：8，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'Checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Icmpv4EchoRequest |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_icmp_echorequest | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_echorequest(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmp_mask_reply(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Mask Reply报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Mask Reply头部在流量模板中所有Icmp Mask Reply头部的序列号

    Keyword Args:

        Type (int): Type，默认值：18，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

        AddrMask (int): Address Mask，默认值：0，范围: 0-4294967295

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'Checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber',
                'AddrMask': 'addrMask'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Icmpv4MaskReply |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Mask Reply | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_maskreply(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmp_mask_request(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Mask Request报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Mask Request头部在流量模板中所有Icmp Mask Request头部的序列号

    Keyword Args:

        Type (int): Type，默认值：17，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

        AddrMask (int): Address Mask，默认值：0，范围: 0-4294967295

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'Checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber',
                'AddrMask': 'addrMask'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Mask Request | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_maskrequest(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmp_dest_unreach(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Dest Unreach报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Dest Unreach头部在流量模板中所有Icmp Dest Unreach头部的序列号

    Keyword Args:

        Type (int): Type，默认值：3，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Unused (int): Unused，默认值：3，范围: 0-4294967295

        Data (hex): Data，默认值：0000000000000000，范围: 长度为8字节的十六进制数

        Ipv4HeaderVersion (int): Version, 默认值：4，取值范围：0-15

        Ipv4HeaderHeadLen (int): Header Length, 默认值：<AUTO>5，取值范围：0-15

        Ipv4HeaderTosPrecedence (bit): Tos Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderTosDelay (bit): Tos Delay, 默认值：0，取值范围：0-1

        Ipv4HeaderTosThroughput (bit): Tos Throughput, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReliability (bit): Tos Reliability, 默认值：0，取值范围：0-1

        Ipv4HeaderTosMonetaryCost (bit): Tos Monetary Cost, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReserved (bit): Tos Reserved, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffserveCodePointPrecedence (bit): DSCP Codepoint Precedence, 默认值：000000，取值范围：000000-111111

        Ipv4HeaderDiffserveClassSelectorPrecedence (bit): DSCP Class Selector Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderDiffservDscpDrop (bit): DSCP Class Selector Drop Precedence, 默认值：00，取值范围：00-11

        Ipv4HeaderDiffservDscpUndefine (bit): DSCP Class Selector Drop Undefined, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffservEcn (bit): ECN Setting, 默认值：00，取值范围：00-11

        Ipv4HeaderTosByte (hex): Tos Byte Data, 默认值：00，取值范围：00-FF

        Ipv4HeaderTotalLength (int): Total Length, 默认值：<AUTO>20，取值范围：0-65535

        Ipv4HeaderID (int): Identification, 默认值：<AUTO>123，取值范围：0-65535

        Ipv4HeaderFlags (bit): Flags, 默认值：000，取值范围：000-111

        Ipv4HeaderOffset (int): Fragment Offset, 默认值：0，取值范围：0-8191

        Ipv4HeaderTTL (int): TTL, 默认值：128，取值范围：0-255

        Ipv4HeaderProtocol (int): Protocol, 默认值：235，取值范围：0-255

        Ipv4HeaderChecksum (hex): Checksum, 默认值：0000，取值范围：0000-FFFF

        Ipv4HeaderSource (str): Source Address, 默认值：192.168.0.2，取值范围：有效的ipv4地址

        Ipv4HeaderDestination (str): Destination Address, 默认值：192.168.0.10，取值范围：有效的ipv4地址

        Ipv4HeaderPadding (hex): IPv4 Padding, 默认值：000000，取值范围：长度0-3字节的十六进制数

        Ipv4HeaderGateway (str): Gateway Address, 默认值：192.168.0.1，取值范围：有效的ipv4地址

        Ipv4HeaderHeaderOption (list): 插入HeaderOption字段，支持传入列表，支持的参数有：

            EndOfOption

            Nop

            Security

            LooseSourceRoute

            StrictSourceRoute

            RouterAlert

            RecordRoute

            TimeStamp

            StreamIdentifier

            General

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'icmpChecksum',
                'Unused': 'unused',
                'Data': 'headerData',
                'Ipv4HeaderVersion': 'version',
                'Ipv4HeaderHeadLen': 'headLen',
                'Ipv4HeaderTotalLength': 'totalLength',
                'Ipv4HeaderID': 'id',
                'Ipv4HeaderFlags': 'flags',
                'Ipv4HeaderOffset': 'offset',
                'Ipv4HeaderTTL': 'ttl',
                'Ipv4HeaderProtocol': 'protocol',
                'Ipv4HeaderChecksum': 'checksum',
                'Ipv4HeaderSource': 'source',
                'Ipv4HeaderDestination': 'destination',
                'Ipv4HeaderPadding': 'padding',
                'Ipv4HeaderGateway': 'gateway',
                'Ipv4HeaderTosPrecedence': 'headerData.ipv4Header.tos.tos.precedence',
                'Ipv4HeaderTosDelay': 'headerData.ipv4Header.tos.tos.delay',
                'Ipv4HeaderTosThroughput': 'headerData.ipv4Header.tos.tos.throughput',
                'Ipv4HeaderTosReliability': 'headerData.ipv4Header.tos.tos.reliability',
                'Ipv4HeaderTosMonetaryCost': 'headerData.ipv4Header.tos.tos.monetaryCost',
                'Ipv4HeaderTosReserved': 'headerData.ipv4Header.tos.tos.reserved',
                'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp',
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence',
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence',
                'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop',
                'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine',
                'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting',
                'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Dest Unreach | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmp_destunreach(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmp_echo_reply(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Echo Reply报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 范围: 0-65535: 要修改的Icmp Echo Reply头部在流量模板中所有Icmp Echo Reply头部的序列号

    Keyword Args:

        Type (int): Type，默认值：0，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'Checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Icmpv4EchoReply |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Echo Reply | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_echoreply(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmp_information_reply(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Information Reply报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Information Reply头部在流量模板中所有Icmp Information Reply头部的序列号

    Keyword Args:

        Type (int): Type，默认值：16，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'Checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Information Reply | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_informationreply(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmp_information_request(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Information Request报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Information Request头部在流量模板中所有Icmp Information Request头部的序列号

    Keyword Args:

        Type (int): Type，默认值：15，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'Checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Information Request | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_informationrequest(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmp_parameter_problem(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Parameter Problem报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Parameter Problem头部在流量模板中所有Icmp Parameter Problem头部的序列号

    Keyword Args:

        Type (int): Type，默认值：3，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Pointer (int): Pointer，默认值：0，范围: 0-255

        Reserve (int): Unused，默认值：0，范围: 0-16777215

        Data (hex): Data，默认值：0000000000000000，范围: 长度为8字节的十六进制数

        Ipv4HeaderVersion (int): Version, 默认值：4，取值范围：0-15

        Ipv4HeaderHeadLen (int): Header Length, 默认值：<AUTO>5，取值范围：0-15

        Ipv4HeaderTosPrecedence (bit): Tos Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderTosDelay (bit): Tos Delay, 默认值：0，取值范围：0-1

        Ipv4HeaderTosThroughput (bit): Tos Throughput, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReliability (bit): Tos Reliability, 默认值：0，取值范围：0-1

        Ipv4HeaderTosMonetaryCost (bit): Tos Monetary Cost, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReserved (bit): Tos Reserved, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffserveCodePointPrecedence (bit): DSCP Codepoint Precedence, 默认值：000000，取值范围：000000-111111

        Ipv4HeaderDiffserveClassSelectorPrecedence (bit): DSCP Class Selector Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderDiffservDscpDrop (bit): DSCP Class Selector Drop Precedence, 默认值：00，取值范围：00-11

        Ipv4HeaderDiffservDscpUndefine (bit): DSCP Class Selector Drop Undefined, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffservEcn (bit): ECN Setting, 默认值：00，取值范围：00-11

        Ipv4HeaderTosByte (hex): Tos Byte Data, 默认值：00，取值范围：00-FF

        Ipv4HeaderTotalLength (int): Total Length, 默认值：<AUTO>20，取值范围：0-65535

        Ipv4HeaderID (int): Identification, 默认值：<AUTO>123，取值范围：0-65535

        Ipv4HeaderFlags (bit): Flags, 默认值：000，取值范围：000-111

        Ipv4HeaderOffset (int): Fragment Offset, 默认值：0，取值范围：0-8191

        Ipv4HeaderTTL (int): TTL, 默认值：128，取值范围：0-255

        Ipv4HeaderProtocol (int): Protocol, 默认值：235，取值范围：0-255

        Ipv4HeaderChecksum (hex): Checksum, 默认值：0000，取值范围：0000-FFFF

        Ipv4HeaderSource (str): Source Address, 默认值：192.168.0.2，取值范围：有效的ipv4地址

        Ipv4HeaderDestination (str): Destination Address, 默认值：192.168.0.10，取值范围：有效的ipv4地址

        Ipv4HeaderPadding (hex): IPv4 Padding, 默认值：000000，取值范围：长度0-3字节的十六进制数

        Ipv4HeaderGateway (str): Gateway Address, 默认值：192.168.0.1，取值范围：有效的ipv4地址

        Ipv4HeaderHeaderOption (list): 插入HeaderOption字段，支持传入列表，支持的参数有：

            EndOfOption

            Nop

            Security

            LooseSourceRoute

            StrictSourceRoute

            RouterAlert

            RecordRoute

            TimeStamp

            StreamIdentifier

            General


    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'icmpChecksum',
                'Pointer': 'pointer',
                'Reserve': 'reserve',
                'Data': 'headerData',
                'Ipv4HeaderVersion': 'version',
                'Ipv4HeaderHeadLen': 'headLen',
                'Ipv4HeaderTotalLength': 'totalLength',
                'Ipv4HeaderID': 'id',
                'Ipv4HeaderFlags': 'flags',
                'Ipv4HeaderOffset': 'offset',
                'Ipv4HeaderTTL': 'ttl',
                'Ipv4HeaderProtocol': 'protocol',
                'Ipv4HeaderChecksum': 'checksum',
                'Ipv4HeaderSource': 'source',
                'Ipv4HeaderDestination': 'destination',
                'Ipv4HeaderPadding': 'padding',
                'Ipv4HeaderGateway': 'gateway',
                'Ipv4HeaderTosPrecedence': 'headerData.ipv4Header.tos.tos.precedence',
                'Ipv4HeaderTosDelay': 'headerData.ipv4Header.tos.tos.delay',
                'Ipv4HeaderTosThroughput': 'headerData.ipv4Header.tos.tos.throughput',
                'Ipv4HeaderTosReliability': 'headerData.ipv4Header.tos.tos.reliability',
                'Ipv4HeaderTosMonetaryCost': 'headerData.ipv4Header.tos.tos.monetaryCost',
                'Ipv4HeaderTosReserved': 'headerData.ipv4Header.tos.tos.reserved',
                'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp',
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence',
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence',
                'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop',
                'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine',
                'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting',
                'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Parameter Problem | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmp_parameterproblem(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmp_redirect(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Redirect报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Redirect头部在流量模板中所有Icmp Redirect头部的序列号

    Keyword Args:

        Type (int): Type，默认值：3，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        GatewayAddress (str): GatewayAddress, 默认值：10.0.0.1，取值范围：有效的ipv4地址

        Data (hex): Data，默认值：0000000000000000，范围: 长度为8字节的十六进制数

        Ipv4HeaderVersion (int): Version, 默认值：4，取值范围：0-15

        Ipv4HeaderHeadLen (int): Header Length, 默认值：<AUTO>5，取值范围：0-15

        Ipv4HeaderTosPrecedence (bit): Tos Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderTosDelay (bit): Tos Delay, 默认值：0，取值范围：0-1

        Ipv4HeaderTosThroughput (bit): Tos Throughput, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReliability (bit): Tos Reliability, 默认值：0，取值范围：0-1

        Ipv4HeaderTosMonetaryCost (bit): Tos Monetary Cost, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReserved (bit): Tos Reserved, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffserveCodePointPrecedence (bit): DSCP Codepoint Precedence, 默认值：000000，取值范围：000000-111111

        Ipv4HeaderDiffserveClassSelectorPrecedence (bit): DSCP Class Selector Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderDiffservDscpDrop (bit): DSCP Class Selector Drop Precedence, 默认值：00，取值范围：00-11

        Ipv4HeaderDiffservDscpUndefine (bit): DSCP Class Selector Drop Undefined, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffservEcn (bit): ECN Setting, 默认值：00，取值范围：00-11

        Ipv4HeaderTosByte (hex): Tos Byte Data, 默认值：00，取值范围：00-FF

        Ipv4HeaderTotalLength (int): Total Length, 默认值：<AUTO>20，取值范围：0-65535

        Ipv4HeaderID (int): Identification, 默认值：<AUTO>123，取值范围：0-65535

        Ipv4HeaderFlags (bit): Flags, 默认值：000，取值范围：000-111

        Ipv4HeaderOffset (int): Fragment Offset, 默认值：0，取值范围：0-8191

        Ipv4HeaderTTL (int): TTL, 默认值：128，取值范围：0-255

        Ipv4HeaderProtocol (int): Protocol, 默认值：235，取值范围：0-255

        Ipv4HeaderChecksum (hex): Checksum, 默认值：0000，取值范围：0000-FFFF

        Ipv4HeaderSource (str): Source Address, 默认值：192.168.0.2，取值范围：有效的ipv4地址

        Ipv4HeaderDestination (str): Destination Address, 默认值：192.168.0.10，取值范围：有效的ipv4地址

        Ipv4HeaderPadding (hex): IPv4 Padding, 默认值：000000，取值范围：长度0-3字节的十六进制数

        Ipv4HeaderGateway (str): Gateway Address, 默认值：192.168.0.1，取值范围：有效的ipv4地址

        Ipv4HeaderHeaderOption (list): 插入HeaderOption字段，支持传入列表，支持的参数有：

            EndOfOption

            Nop

            Security

            LooseSourceRoute

            StrictSourceRoute

            RouterAlert

            RecordRoute

            TimeStamp

            StreamIdentifier

            General

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'icmpChecksum',
                'GatewayAddress': 'gatewayAddress',
                'Data': 'headerData',
                'Ipv4HeaderVersion': 'version',
                'Ipv4HeaderHeadLen': 'headLen',
                'Ipv4HeaderTotalLength': 'totalLength',
                'Ipv4HeaderID': 'id',
                'Ipv4HeaderFlags': 'flags',
                'Ipv4HeaderOffset': 'offset',
                'Ipv4HeaderTTL': 'ttl',
                'Ipv4HeaderProtocol': 'protocol',
                'Ipv4HeaderChecksum': 'checksum',
                'Ipv4HeaderSource': 'source',
                'Ipv4HeaderDestination': 'destination',
                'Ipv4HeaderPadding': 'padding',
                'Ipv4HeaderGateway': 'gateway',
                'Ipv4HeaderTosPrecedence': 'headerData.ipv4Header.tos.tos.precedence',
                'Ipv4HeaderTosDelay': 'headerData.ipv4Header.tos.tos.delay',
                'Ipv4HeaderTosThroughput': 'headerData.ipv4Header.tos.tos.throughput',
                'Ipv4HeaderTosReliability': 'headerData.ipv4Header.tos.tos.reliability',
                'Ipv4HeaderTosMonetaryCost': 'headerData.ipv4Header.tos.tos.monetaryCost',
                'Ipv4HeaderTosReserved': 'headerData.ipv4Header.tos.tos.reserved',
                'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp',
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence',
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence',
                'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop',
                'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine',
                'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting',
                'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Redirect | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmp_redirect(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmp_source_quench(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Source Quench报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Source Quench头部在流量模板中所有Icmp Source Quench头部的序列号

    Keyword Args:

        Type (int): Type，默认值：3，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Reserve (int): Unused，默认值：0，范围: 0-4294967295

        Data (hex): Data，默认值：0000000000000000，范围: 长度为8字节的十六进制数

        Ipv4HeaderVersion (int): Version, 默认值：4，取值范围：0-15

        Ipv4HeaderHeadLen (int): Header Length, 默认值：<AUTO>5，取值范围：0-15

        Ipv4HeaderTosPrecedence (bit): Tos Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderTosDelay (bit): Tos Delay, 默认值：0，取值范围：0-1

        Ipv4HeaderTosThroughput (bit): Tos Throughput, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReliability (bit): Tos Reliability, 默认值：0，取值范围：0-1

        Ipv4HeaderTosMonetaryCost (bit): Tos Monetary Cost, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReserved (bit): Tos Reserved, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffserveCodePointPrecedence (bit): DSCP Codepoint Precedence, 默认值：000000，取值范围：000000-111111

        Ipv4HeaderDiffserveClassSelectorPrecedence (bit): DSCP Class Selector Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderDiffservDscpDrop (bit): DSCP Class Selector Drop Precedence, 默认值：00，取值范围：00-11

        Ipv4HeaderDiffservDscpUndefine (bit): DSCP Class Selector Drop Undefined, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffservEcn (bit): ECN Setting, 默认值：00，取值范围：00-11

        Ipv4HeaderTosByte (hex): Tos Byte Data, 默认值：00，取值范围：00-FF

        Ipv4HeaderTotalLength (int): Total Length, 默认值：<AUTO>20，取值范围：0-65535

        Ipv4HeaderID (int): Identification, 默认值：<AUTO>123，取值范围：0-65535

        Ipv4HeaderFlags (bit): Flags, 默认值：000，取值范围：000-111

        Ipv4HeaderOffset (int): Fragment Offset, 默认值：0，取值范围：0-8191

        Ipv4HeaderTTL (int): TTL, 默认值：128，取值范围：0-255

        Ipv4HeaderProtocol (int): Protocol, 默认值：235，取值范围：0-255

        Ipv4HeaderChecksum (hex): Checksum, 默认值：0000，取值范围：0000-FFFF

        Ipv4HeaderSource (str): Source Address, 默认值：192.168.0.2，取值范围：有效的ipv4地址

        Ipv4HeaderDestination (str): Destination Address, 默认值：192.168.0.10，取值范围：有效的ipv4地址

        Ipv4HeaderPadding (hex): IPv4 Padding, 默认值：000000，取值范围：长度0-3字节的十六进制数

        Ipv4HeaderGateway (str): Gateway Address, 默认值：192.168.0.1，取值范围：有效的ipv4地址

        Ipv4HeaderHeaderOption (list): 插入HeaderOption字段，支持传入列表，支持的参数有：

            EndOfOption

            Nop

            Security

            LooseSourceRoute

            StrictSourceRoute

            RouterAlert

            RecordRoute

            TimeStamp

            StreamIdentifier

            General


    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'icmpChecksum',
                'Unused': 'unused',
                'Data': 'headerData',
                'Ipv4HeaderVersion': 'version',
                'Ipv4HeaderHeadLen': 'headLen',
                'Ipv4HeaderTotalLength': 'totalLength',
                'Ipv4HeaderID': 'id',
                'Ipv4HeaderFlags': 'flags',
                'Ipv4HeaderOffset': 'offset',
                'Ipv4HeaderTTL': 'ttl',
                'Ipv4HeaderProtocol': 'protocol',
                'Ipv4HeaderChecksum': 'checksum',
                'Ipv4HeaderSource': 'source',
                'Ipv4HeaderDestination': 'destination',
                'Ipv4HeaderPadding': 'padding',
                'Ipv4HeaderGateway': 'gateway',
                'Ipv4HeaderTosPrecedence': 'headerData.ipv4Header.tos.tos.precedence',
                'Ipv4HeaderTosDelay': 'headerData.ipv4Header.tos.tos.delay',
                'Ipv4HeaderTosThroughput': 'headerData.ipv4Header.tos.tos.throughput',
                'Ipv4HeaderTosReliability': 'headerData.ipv4Header.tos.tos.reliability',
                'Ipv4HeaderTosMonetaryCost': 'headerData.ipv4Header.tos.tos.monetaryCost',
                'Ipv4HeaderTosReserved': 'headerData.ipv4Header.tos.tos.reserved',
                'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp',
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence',
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence',
                'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop',
                'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine',
                'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting',
                'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Source Quench | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmp_sourcequench(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmp_time_exceeded(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Time Exceeded报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Time Exceeded头部在流量模板中所有Icmp Time Exceeded头部的序列号

    Keyword Args:

        Type (int): Type，默认值：3，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Reserve (int): Unused，默认值：0，范围: 0-4294967295

        Data (hex): Data，默认值：0000000000000000，范围: 长度为8字节的十六进制数

        Ipv4HeaderVersion (int): Version, 默认值：4，取值范围：0-15

        Ipv4HeaderHeadLen (int): Header Length, 默认值：<AUTO>5，取值范围：0-15

        Ipv4HeaderTosPrecedence (bit): Tos Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderTosDelay (bit): Tos Delay, 默认值：0，取值范围：0-1

        Ipv4HeaderTosThroughput (bit): Tos Throughput, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReliability (bit): Tos Reliability, 默认值：0，取值范围：0-1

        Ipv4HeaderTosMonetaryCost (bit): Tos Monetary Cost, 默认值：0，取值范围：0-1

        Ipv4HeaderTosReserved (bit): Tos Reserved, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffserveCodePointPrecedence (bit): DSCP Codepoint Precedence, 默认值：000000，取值范围：000000-111111

        Ipv4HeaderDiffserveClassSelectorPrecedence (bit): DSCP Class Selector Precedence, 默认值：000，取值范围：000-111

        Ipv4HeaderDiffservDscpDrop (bit): DSCP Class Selector Drop Precedence, 默认值：00，取值范围：00-11

        Ipv4HeaderDiffservDscpUndefine (bit): DSCP Class Selector Drop Undefined, 默认值：0，取值范围：0-1

        Ipv4HeaderDiffservEcn (bit): ECN Setting, 默认值：00，取值范围：00-11

        Ipv4HeaderTosByte (hex): Tos Byte Data, 默认值：00，取值范围：00-FF

        Ipv4HeaderTotalLength (int): Total Length, 默认值：<AUTO>20，取值范围：0-65535

        Ipv4HeaderID (int): Identification, 默认值：<AUTO>123，取值范围：0-65535

        Ipv4HeaderFlags (bit): Flags, 默认值：000，取值范围：000-111

        Ipv4HeaderOffset (int): Fragment Offset, 默认值：0，取值范围：0-8191

        Ipv4HeaderTTL (int): TTL, 默认值：128，取值范围：0-255

        Ipv4HeaderProtocol (int): Protocol, 默认值：235，取值范围：0-255

        Ipv4HeaderChecksum (hex): Checksum, 默认值：0000，取值范围：0000-FFFF

        Ipv4HeaderSource (str): Source Address, 默认值：192.168.0.2，取值范围：有效的ipv4地址

        Ipv4HeaderDestination (str): Destination Address, 默认值：192.168.0.10，取值范围：有效的ipv4地址

        Ipv4HeaderPadding (hex): IPv4 Padding, 默认值：000000，取值范围：长度0-3字节的十六进制数

        Ipv4HeaderGateway (str): Gateway Address, 默认值：192.168.0.1，取值范围：有效的ipv4地址

        Ipv4HeaderHeaderOption (list): 插入HeaderOption字段，支持传入列表，支持的参数有：

            EndOfOption

            Nop

            Security

            LooseSourceRoute

            StrictSourceRoute

            RouterAlert

            RecordRoute

            TimeStamp

            StreamIdentifier

            General

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'icmpChecksum',
                'Unused': 'unused',
                'Data': 'headerData',
                'Ipv4HeaderVersion': 'version',
                'Ipv4HeaderHeadLen': 'headLen',
                'Ipv4HeaderTotalLength': 'totalLength',
                'Ipv4HeaderID': 'id',
                'Ipv4HeaderFlags': 'flags',
                'Ipv4HeaderOffset': 'offset',
                'Ipv4HeaderTTL': 'ttl',
                'Ipv4HeaderProtocol': 'protocol',
                'Ipv4HeaderChecksum': 'checksum',
                'Ipv4HeaderSource': 'source',
                'Ipv4HeaderDestination': 'destination',
                'Ipv4HeaderPadding': 'padding',
                'Ipv4HeaderGateway': 'gateway',
                'Ipv4HeaderTosPrecedence': 'headerData.ipv4Header.tos.tos.precedence',
                'Ipv4HeaderTosDelay': 'headerData.ipv4Header.tos.tos.delay',
                'Ipv4HeaderTosThroughput': 'headerData.ipv4Header.tos.tos.throughput',
                'Ipv4HeaderTosReliability': 'headerData.ipv4Header.tos.tos.reliability',
                'Ipv4HeaderTosMonetaryCost': 'headerData.ipv4Header.tos.tos.monetaryCost',
                'Ipv4HeaderTosReserved': 'headerData.ipv4Header.tos.tos.reserved',
                'Ipv4HeaderDiffservDscp': 'headerData.ipv4Header.tos.diffServe.dscp',
                'Ipv4HeaderDiffserveCodePointPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.codePoint.precedence',
                'Ipv4HeaderDiffserveClassSelectorPrecedence': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.precedence',
                'Ipv4HeaderDiffservDscpDrop': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.drop',
                'Ipv4HeaderDiffservDscpUndefine': 'headerData.ipv4Header.tos.diffServe.dscp.classSelector.undefine',
                'Ipv4HeaderDiffservEcn': 'headerData.ipv4Header.tos.diffServe.ecnSetting',
                'Ipv4HeaderTosByte': 'headerData.ipv4Header.tos.tosByte.data'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Time Exceeded | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmp_timeexceeded(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmp_time_stamp_reply(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Time Stamp Reply报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Time Stamp Reply头部在流量模板中所有Icmp Time Stamp Reply头部的序列号

    Keyword Args:

        Type (int): Type，默认值：14，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

        OriginateTimestamp (int): Originate Timestamp，默认值：0，范围: 0-4294967295

        ReceiveTimestamp (int): Receive Timestamp，默认值：0，范围: 0-4294967295

        TransmitTimestamp (int): Transmit Timestamp，默认值：0，范围: 0-4294967295

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'Checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber'
                'OriginateTimestamp': 'originateTimestamp',
                'ReceiveTimestamp': 'receiveTimestamp',
                'TransmitTimestamp': 'transmitTimestamp',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Time Stamp Reply | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_time_stamp_reply(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmp_time_stamp_request(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmp Time Stamp Request报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmp Time Stamp Request头部在流量模板中所有Icmp Time Stamp Request头部的序列号

    Keyword Args:

        Type (int): Type，默认值：13，范围: 0-255

        Code (int): Code，默认值：0，范围: 0-255

        Checksum (str): Checksum，默认值：0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Identifier (int): Identifier，默认值：0，范围: 0-65535

        SequenceNumber (int): Sequence Number，默认值：0，范围: 0-65535

        OriginateTimestamp (int): Originate Timestamp，默认值：0，范围: 0-4294967295

        ReceiveTimestamp (int): Receive Timestamp，默认值：0，范围: 0-4294967295

        TransmitTimestamp (int): Transmit Timestamp，默认值：0，范围: 0-4294967295

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmp Time Stamp Request | Stream=${Stream} | Level=0 | Identifier=100 | SequenceNumber=200 |
    """

    result = renix.edit_header_icmp_time_stamp_request(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result

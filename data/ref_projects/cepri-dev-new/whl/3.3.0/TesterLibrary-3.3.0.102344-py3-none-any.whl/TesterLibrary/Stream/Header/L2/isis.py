import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Header ISIS-------------------------------------
def edit_header_isis_csnp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Isis L1/L2 Scnp报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 范围: 0-65535: 要修改的Isis L1/L2 Scnp头部在流量模板中所有Isis L1/L2 Scnp头部的序列号

    Keyword Args:

        InterRoutingProtocolDiscriminator (int): Intradomain Routeing Protocol Discriminator, 默认值：<AUTO>83

        LengthIndicator (int): Length Indicator, 默认值：<AUTO>33

        VersionIdExtend (int): Version/Protocol ID Extension, 默认值：<AUTO>1

        IdLength (int): ID Length, 默认值：<AUTO>6

        Reserved1 (int): 默认值：3, 取值范围：0-7

        PDUType (int): PDU Type, 默认值：<AUTO>24, 取值范围：0-31

        Version (int): 默认值：1, 取值范围：0-255

        Reserved2 (int): 默认值：3, 取值范围：0-255

        MaxAreaAddress (int): Maximum Area Addresses, 默认值：3, 取值范围：0-3

        PDULength (int): PDU Length, 默认值：<AUTO>33

        LspId (hex): Source ID, 默认值：00000000000000, 取值范围：长度为7字节的十六进制数

        StartLspId (hex int): Start LSP-ID, 默认值：0000000000000000, 取值范围：长度为8字节的十六进制数

        EndLspId (hex int): End LSP-ID, 默认值：0000000000000000, 取值范围：长度为8字节的十六进制数

        CsnpDataTlvOptionHeader (list): 可插入的选项，默认无选项，可选值：

            IsIsLspEntries

            AuthentionInfo

    Returns:

        dict: eg::

            {
                'InterRoutingProtocolDiscriminator': 'l1csnpCommonHeader.InterRoutingProtocolDiscriminator',
                'LengthIndicator': 'l1csnpCommonHeader.lengthIndicator',
                'VersionIdExtend': 'l1csnpCommonHeader.versionIdExtend',
                'IdLength': 'l1csnpCommonHeader.idLength',
                'Reserved1': 'l1csnpCommonHeader.reserved1',
                'PDUType': 'l1csnpCommonHeader.pDUType',
                'Version': 'l1csnpCommonHeader.version',
                'Reserved2': 'l1csnpCommonHeader.reserved2',
                'MaxAreaAddress': 'l1csnpCommonHeader.maxAreaAddress',
                'PDULength': 'CsnpDataHeader.pDULength',
                'LspId': 'CsnpDataHeader.lspId',
                'StartLspId': 'CsnpDataHeader.startLspId',
                'EndLspId': 'CsnpDataHeader.endLspId'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis csnp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
    """

    result = renix.edit_header_isis_csnp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_tlv_header(Stream, Option, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1/L2/P2p Csnp/Hello/Lsp/Psnp报文中Tlv头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Option (str):

            ISIS L1/L2 Csnp支持：

                IsIsLspEntries

                AuthentionInfo

            ISIS L1/L2 Hello支持：

                IsIsAreaAddress

                Padding

                AuthentionInfo

                ProtocolSupport

                IpInterfaceAddress

                Neighbor

                RestartSignal

                Ipv6InterfaceAddress

            ISIS L1/L2 Lsp支持：

                IsIsAreaAddress

                IsIsReachability

                ExtendedReachability

                IsIsIpInterReachability

                IsIsProtocolsSupported

                IsIsIPExternalReachability

                IpInterfaceAddress

                Ipv6InterfaceAddress

                IsIsIpv6Reachability

            ISIS P2p Hello支持：

                Padding

                AreaAddress

                AuthentionInfo

                ProtocolSupport

                IpInterfaceAddress

                Ipv6InterfaceAddress

                RestartSignal

                P2pAdjacencyState

        Level (int): 要修改的ISIS L1/L2 Csnp/Hello头部在流量模板中所有ISIS L1/L2 Csnp/Hello头部的序列号, 默认值: 0, 范围: 0-65535

        Index (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        ISIS L1/L2 Csnp/Psnp IsIsLspEntries选项支持：

            TlvCode (int): Type, 默认值：<AUTO>9, 取值范围：0-255

            Length (int): Length, 默认值：<AUTO>0, 取值范围：0-255

            LspEntries (int): lsp entry个数，默认值：0, 取值范围：0-10

        ISIS L1/L2 Csnp/Psnp AuthentionInfo选项支持：

            TlvCode (int): 默认值：<AUTO>10

            Length (int): 默认值：<AUTO>0

            AuthenticationType (int): 默认值：1, 取值范围：0-255

            AuthenticationLength (int): 默认值：1, 取值范围：0-255

            Authentication (hex int): 默认值：01, 取值范围：长度0-255

        ISIS L1/L2 Hello/Lsp IsIsAreaAddress选项支持：

            TlvCode (int): 默认值：<AUTO>9, 取值范围：0-255

            TlvLength (int): 默认值：<AUTO>0, 取值范围：0-255

            AreaAddressEntries (int): area address entry个数，默认值：0

        ISIS L1/L2 Hello Padding选项支持：

            TlvCode (int): 默认值：<AUTO>9, 取值范围：0-255

            TlvLength (int): 默认值：<AUTO>0, 取值范围：0-255

            Padding (hex): 默认值：00, 取值范围：00-FF

        ISIS L1/L2 Hello AuthentionInfo选项支持：

            TlvCode (int): 默认值：<AUTO>10

            Length (int): 默认值：<AUTO>0

            AuthenticationType (int): Authentication Type, 默认值：1, 取值范围：0-255

            AuthenticationLength (int): Authentication Length, 默认值：1, 取值范围：0-255

            Authentication (hex): Authentication, 默认值：00, 最大长度255byte

        ISIS L1/L2 Hello/Lsp ProtocolSupport选项支持：

            TlvCode (int): 默认值：<AUTO>129

            Length (int): 默认值：<AUTO>2

            NlPIDEntriesField (int): NLPID Entries个数

        ISIS L1/L2 Hello/Lsp IpInterfaceAddress选项支持：

            TlvCode (int): 默认值：<AUTO>9, 取值范围：0-255

            TlvLength (int): 默认值：<AUTO>0, 取值范围：0-255

            Ipv4InterfaceAddress (list): IPv4 Interface Address, 列表长度最大1024, 元素默认值：192.168.0.2, 取值范围：有效的ipv4地址

        ISIS L1/L2 Hello Neighbor选项支持：

            TlvCode (int): 默认值：<AUTO>6, 取值范围：0-255

            TlvLength (int): 默认值：<AUTO>2, 取值范围：0-255

            MacAdd (list): IS Neighbors, 列表长度最大10, 元素默认值：00:00:00:13:40:20, 取值范围：有效的mac地址

        ISIS L1/L2 Hello RestartSignal选项支持：

            TlvCode (int): Type, 默认值：<AUTO>211, 取值范围：0-255

            TlvLength (int): Length, 默认值：<AUTO>3, 取值范围：0-255

            Reserved1 (int): Reserved, 默认值：0, 取值范围：0-31

            SuppressAdjacency (int): Suppress Adjacency Advertisement, 默认值：0, 取值范围：0-1

            RestartAck (int): Restart Acknowledgement, 默认值：0, 取值范围：0-1

            RestartReq (int): Restart Request, 默认值：0, 取值范围：0-1

            RemainTime (int): Remaining Time, 默认值：0, 取值范围：0-65535

            RestartNeighborIdField (str): Restarting Neighbor ID, 默认：000000000000, 长度：6byte

        ISIS L1/L2 Hello/Lsp Ipv6InterfaceAddress选项支持：

            TlvCode (int): Type, 默认值：<AUTO>232, 取值范围：0-255

            TlvLength (int): Length, 默认值：<AUTO>16, 取值范围：0-255

            Ipv6InterfaceAddress (list): IPv6 Interface Address, 列表最大长度1024, 元素默认值：2001::2, 取值范围：有效的ipv6地址

        ISIS L1/L2 Lsp IsIsReachability选项支持：

            TlvCode (int): Type, 默认值：<AUTO>2, 取值范围：0-255

            TlvLength (int): Length, 默认值：<AUTO>12, 取值范围：0-255

            VirtualFlag (int): Virtual Flag, 默认值：<AUTO>12, 取值范围：0-255

            MetricEntries (int): Metric Entry个数, 默认值：0, 最大：1024

        ISIS L1/L2 Lsp ExtendedReachability选项支持：

            TlvCode (int): Type, 默认值：<AUTO>2, 取值范围：0-255

            Length (int): Length, 默认值：<AUTO>12, 取值范围：0-255

            NeighborID (hex): Neighbor ID, 默认值：00000000000000, 长度：7 byte

            Metric (hex): metric, 默认值：000000, 长度：3 byte

            TlvLength (int): Sub-TLV Length, 默认值：1, 取值范围：0-255

            IisNeighborSubTlv (list): Sub-TLV类型, 支持类型：

                AdGroupSubtlv

                Ipv4InterfaceAddressSubtlv

                Ipv4NeighborAddressSubtlv

                MaxLinkBandwidthSubtlv

                ReservableLinkBandwidthSubtlv

                UnReservedBandwidthSubtlv

                InterfaceIpv6Subtlv

                NeigbhorIpv6Subtlv

        ISIS L1/L2 Lsp IsIsIpInterReachability选项支持：

            TlvCode (int): Type, 默认值：<AUTO>128, 取值范围：0-255

            Length (int): Length, 默认值：<AUTO>12, 取值范围：0-255

            InternalmetricEntries (int): Internal Metric Entry个数, 默认值：0, 最大：1024

        ISIS L1/L2 Lsp IsIsIPExternalReachability选项支持：

            TlvCode (int): Type, 默认值：<AUTO>130, 取值范围：0-255

            Length (int): Length, 默认值：<AUTO>12, 取值范围：0-255

            ExternalmetricEntries (int): External Metric Entry个数, 默认值：0, 最大：1024

        ISIS L1/L2 Lsp IsIsIpv6Reachability选项支持：

            TlvCode (int): Type, 默认值：<AUTO>236, 取值范围：0-255

            TlvLength (int): Length, 默认值：<AUTO>16, 取值范围：0-255

            Metric (int): metric, 默认值：0, 取值范围：0-4294967295

            Ubit (int): Up/Down Bit, 默认值：0, 取值范围：0-1

            Xbit (int): External Origin Bit, 默认值：0, 取值范围：0-1

            Sbit (int): Sub-TLV Bit, 默认值：0, 取值范围：0-1

            Reserved (int): Reserved Bit, 默认值：0, 取值范围：0-31

            PrefixLength (int): Prefix Length, 默认值：0, 取值范围：0-255

            Prefix (hex): Prefix, 默认值：00, 长度：0-255byte

        ISIS P2p Hello P2pAdjacencyState选项支持：

            IsIsp2pAdjacencyStateType (int): Type, 默认值：240, 取值范围：0-255

            IsIsp2pAdjacencyStateLength (int): Length, 默认值：15, 取值范围：0-255

            AdjacencyStateUp.adjacencyState (int): Adjacency State, 默认值：0, 取值范围：0-255

            AdjacencyStateUp.extendLocalCircuitId (byte): Extended Local Circuit ID, 默认值：00000000, 长度：4byte

            AdjacencyStateUp.neighborSystemId (byte): Neighbor System ID, 默认值：000000000000, 长度：6byte

            AdjacencyStateUp.neighborExtendedCID (byte): Neighbor Extended Local Circuit ID, 默认值：00000000, 长度：4byte

            AdjacencyStateInitializing.adjacencyState (int): Adjacency State, 默认值：1, 取值范围：0-255

            AdjacencyStateInitializing.extendLocalCircuitId (byte): Extended Local Circuit ID, 默认值：00000000, 长度：4byte

            AdjacencyStateInitializing.neighborSystemId (byte): Neighbor System ID, 默认值：000000000000, 长度：6byte

            AdjacencyStateInitializing.neighborExtendedCID (byte): Neighbor Extended Local Circuit ID, 默认值：00000000, 长度：4byte

            AdjacencyStateDown.adjacencyState (int): Adjacency State, 默认值：2, 取值范围：0-255

            AdjacencyStateDown.extendLocalCircuitId (byte): Extended Local Circuit ID, 默认值：00000000, 长度：4byte

    Returns:

        dict: eg::

            {
                'TlvCode': 'CsnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_0.isIsLspEntries.tlvCode'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1csnp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
    """

    result = renix.edit_header_isis_tlv_header(Stream=Stream, Option=Option, Level=Level, Index=Index,
                                               **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_lsp_entry(Stream, Level=0, TlvIndex=0, LspIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1/L2 Csnp报文中Tlv头部Lsp Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ISIS L1/L2 Csnp头部在流量模板中所有ISIS L1/L2 Csnp头部的序列号, 默认值: 0, 范围: 0-65535

        TlvIndex (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

        LspIndex (int): 要修改的Isis Lsp Entry节点在流量模板中所有Isis Lsp Entry节点的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        RemainTime (int): 默认值：1, 取值范围：0-65535

        LspId (hex): 默认值：0000000000000001, 取值范围：0000000000000001-FFFFFFFFFFFFFFFF

        LspSeqcenceNum (hex): 默认值：00000001, 取值范围：00000001-FFFFFFFF

        Checksum (hex): 默认值：<AUTO>0000

    Returns:

        dict: eg::

            {
                'RemainTime': 'CsnpDataHeader.CsnpDataTlvOptionHeader.csnpisIsTlvs_0.isIsLspEntries.lspEntries.LSPEntry_1.remainTime'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1csnp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
            | Edit Header IsisLsp Entry | Stream=${Stream} | TlvIndex=0 | LspIndex=0 | remainTime=10 |
    """

    result = renix.edit_header_isis_lsp_entry(Stream=Stream, Level=Level, TlvIndex=TlvIndex, LspIndex=LspIndex,
                                              **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_l1l2_hello(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Isis L1/L2 Hello报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 范围: 0-65535: 要修改的Isis L1/L2 Hello头部在流量模板中所有Isis L1/L2 Hello头部的序列号

    Keyword Args:

        InterRoutingProtocolDiscriminator (int): Intradomain Routeing Protocol Discriminator, 默认值：<AUTO>83

        LengthIndicator (int): Length Indicator, 默认值：<AUTO>33

        VersionIdExtend (int): Version/Protocol ID Extension, 默认值：<AUTO>1

        IdLength (int): ID Length, 默认值：<AUTO>6

        CommonReserved1 (int): 默认值：3, 取值范围：0-7

        PDUType (int): PDU Type, 默认值：<AUTO>24, 取值范围：0-31

        Version (int): 默认值：1, 取值范围：0-255

        CommonReserved2 (int): 默认值：3, 取值范围：0-255

        MaxAreaAddress (int): Maximum Area Addresses, 默认值：3, 取值范围：0-3

        FixedReserve1 (int): Reserved, 默认值：0, 取值范围：0-63

        CircuitType (int): Circuit Type, 默认值：1, 取值范围：1-3

        SenderSystemID (hex): Source ID, 默认值：000000000001, 长度: 6byte

        HolderTimer (int|hex): Holding Timer, l1默认值：51, 取值范围：0-65535; l2默认值：0033, 长度：2byte

        PDULength (int): PDU Length, 默认值：<AUTO>27, 取值范围：0-65535

        FixedReserve2 (int): Reserved, 默认值：0, 取值范围：0-1

        Priority (int): Priority, 默认值：0, 取值范围：0-127

        DesignatedSystemID (hex): LAN ID, 默认值：00000000010001, 长度为7byte

        IsIsTlv (list): TLV Header, 默认值：'', 取值范围：

            IsIsAreaAddress (l1) / AreaAddress (l2)

            Padding

            AuthentionInfo

            ProtocolSupport

            IpInterfaceAddress

            Neighbor

            RestartSignal

            Ipv6InterfaceAddress

    Returns:

        dict: eg::

            {
                'InterRoutingProtocolDiscriminator': 'InterRoutingProtocolDiscriminator',
                'LengthIndicator': 'lengthIndicator',
                'VersionIdExtend': 'versionIdExtend',
                'IdLength': 'idLength',
                'CommonReserved1': 'commonReserved1',
                'PDUType': 'pDUType',
                'Version': 'version',
                'CommonReserved2': 'commonReserved2',
                'MaxAreaAddress': 'maxAreaAddress',
                'FixedReserve1': 'fixedReserve1',
                'CircuitType': 'circuitType',
                'SenderSystemID': 'senderSystemID',
                'HolderTimer': 'holderTimer',
                'PDULength': 'pDULength',
                'FixedReserve2': 'fixedReserve2',
                'Priority': 'priority',
                'DesignatedSystemID': 'designatedSystemID'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1helloHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis hello | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
    """

    result = renix.edit_header_isis_l1l2_hello(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_area_address_entry(Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1/L2/P2p Hello/Lsp报文中Tlv头部Area Address Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ISIS L1/L2 Hello/Lsp头部在流量模板中所有ISIS L1/L2 Hello/Lsp头部的序列号, 默认值: 0, 范围: 0-65535

        TlvIndex (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

        EntryIndex (int): 要修改的Isis Area Address Entry节点在流量模板中所有Isis Area Address Entry节点的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        TlvLength (hex): Length, 默认值：1, 取值范围：1-255

        AreaAddress (hex): Area Address, 默认值：00, 长度：0-255byte

    Returns:

        dict: eg::

            {
                'AreaAddress': 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_0.isIsAreaAddress.AreaAddressEntries.AreaAddressEntry_1.AreaAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1hello | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
            | Edit Header Isis Area Address Entry | Stream=${Stream} | TlvIndex=0 | EntryIndex=0 | remainTime=10 |
    """

    result = renix.edit_header_isis_area_address_entry(Stream=Stream, Level=Level, TlvIndex=TlvIndex,
                                                       EntryIndex=EntryIndex,
                                                       **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_nlpid_entry(Stream, Level=0, TlvIndex=0, NlpidIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1/L2/P2p Hello/Lsp报文中Tlv头部NLPID Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ISIS L1/L2 Hello/Lsp头部在流量模板中所有ISIS L1/L2 Hello/Lsp头部的序列号, 默认值: 0, 范围: 0-65535

        TlvIndex (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

        NlpidIndex (int): 要修改的Isis NLPID Entry节点在流量模板中所有Isis NLPID Entry节点的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        TlvLength (hex): Length, 默认值：1, 取值范围：1-255

        EntryId (hex): Area Address, 默认值：01, 长度：0-255byte

    Returns:

        dict: eg::

            {
                'TlvLength': 'l1HelloMsg.isIsTlv.l1HelloisIsTlvs_3.protocolSupport.NlPIDEntriesField.nlPIDEntry_0.tlvLength'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1hello | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
            | Edit Header Isis Nlpid Entry | Stream=${Stream} | TlvIndex=0 | NlpidIndex=0 | remainTime=10 |
    """

    result = renix.edit_header_isis_nlpid_entry(Stream=Stream, Level=Level, TlvIndex=TlvIndex, NlpidIndex=NlpidIndex,
                                                **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_lsp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Isis L1/L2 Lsp报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 范围: 0-65535: 要修改的Isis L1/L2 Hello头部在流量模板中所有Isis L1/L2 Hello头部的序列号

    Keyword Args:

        InterRoutingProtocolDiscriminator (int): Intradomain Routeing Protocol Discriminator, 默认值：<AUTO>83, 取值范围：00-FF

        LengthIndicator (int): Length Indicator, 默认值：<AUTO>27, 取值范围：0-255

        VersionIdExtend (int): Version/Protocol ID Extension, 默认值：<AUTO>1, 取值范围：0-255

        IdLength (int): ID Length, 默认值：<AUTO>6, 取值范围：0-255

        Reserved1 (int): Reserved, 默认值：0, 取值范围：0-7

        PDUType (int): PDU Type, 默认值：<AUTO>18, 取值范围：0-31

        Version (int): Version, 默认值：1, 取值范围：0-255

        Reserved2 (int): Reserved, 默认值：0, 取值范围：0-255

        MaxAreaAddress (int): Maximum Area Addresses, 默认值：3, 取值范围：0-3

        PDULength (int): Reserved, 默认值：0, 取值范围：0-63

        RemainTime (int): Circuit Type, 默认值：1, 取值范围：1-3

        LspId (hex): Source ID, 默认值：0000000000000000, 长度: 8byte

        SeqcenceNum (hex): Seqcence Number, 默认值：00000000, 长度: 4byte

        Checksum (hex): Checksum, 默认值：<AUTO>0000, 长度: 2byte

        PartitionRepair (int): Partition Repair Bit, 默认值：0, 取值范围：0-1

        Attchment (int): Attchment, 默认值：0, 取值范围：0-15

        OverloadBit (int): Overload Bit, 默认值：0, 取值范围：0-1

        TypeOfIntermediateSystem (int): Type of Intermediate System, 默认值：0, 取值范围：0-3

        LspisIsTlvOptionSet (list): TLV Header, 默认值：'', 取值范围：

            isIsAreaAddress

            isIsReachability

            extendedReachability

            isIsIpInterReachability

            isIsProtocolsSupported

            isIsIPExternalReachability

            ipInterfaceAddress

            Ipv6InterfaceAddress

            isIsIpv6Reachability

    Returns:

        dict: eg::

            {
                'InterRoutingProtocolDiscriminator': 'InterRoutingProtocolDiscriminator',
                'LengthIndicator': 'lengthIndicator',
                'VersionIdExtend': 'versionIdExtend',
                'IdLength': 'idLength',
                'Reserved1': 'reserved1',
                'PDUType': 'pDUType',
                'Version': 'version',
                'Reserved2': 'reserved2',
                'MaxAreaAddress': 'maxAreaAddress',
                'PDULength': 'pDULength',
                'RemainTime': 'remainTime',
                'LspId': 'lspId',
                'SeqcenceNum': 'seqcenceNum',
                'Checksum': 'checksum',
                'PartitionRepair': 'partitionRepair',
                'Attchment': 'attchment',
                'OverloadBit': 'OverloadBit',
                'TypeOfIntermediateSystem': 'TypeOfIntermediateSystem',
                'LspisIsTlvOptionSet': 'LspisIsTlvOptionSet'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1helloHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis lsp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
    """

    result = renix.edit_header_isis_lsp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_metric_entry(Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1/L2 Lsp报文中Tlv头部Metric Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ISIS L1/L2 Lsp头部在流量模板中所有ISIS L1/L2 Lsp头部的序列号, 默认值: 0, 范围: 0-65535

        TlvIndex (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

        EntryIndex (int): 要修改的Isis Metric Entry节点在流量模板中所有Isis Metric Entry节点的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Reserved (hex): Distribution, 默认值：0, 取值范围：0-1

        DefaultMetricIEbit (int): Default Metric I/E Bit, 默认值：0, 取值范围：0-1

        DefaultMetric (int): Default Metric, 默认值：0, 取值范围：0-63

        DelayMetricsbit (int): Delay Metric S bit, 默认值：0, 取值范围：0-1

        DelayMetricSBit (int): Delay Metric R bit, 默认值：0, 取值范围：0-1

        DelayMetric (int): Delay Metric, 默认值：0, 取值范围：0-63

        ExpenseMetricsBit (int): Expense Metric S Bit, 默认值：0, 取值范围：0-1

        ExpenseMetricIEbit (int): Expense Metric R Bit, 默认值：0, 取值范围：0-1

        ExpenseMetric (int): Expense Metric, 默认值：0, 取值范围：0-63

        ErrorMetricsBit (int): Error Metric S Bit, 默认值：0, 取值范围：0-1

        ErrorMetricIEbit (int): Error Metric R Bit, 默认值：0, 取值范围：0-1

        ErrorMetric (int): Error Metric, 默认值：0, 取值范围：0-63

        IsNeighbor (hex): IS Neighbor, 默认值：00000000000000, 长度：7byte

    Returns:

        dict: eg::

            {
                'Reserved': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.reserved',
                'DefaultMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.defaultMetricIEbit',
                'DefaultMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.defaultMetric',
                'DelayMetricsbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.delayMetricsbit',
                'DelayMetricSBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.delayMetricSBit',
                'DelayMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.delayMetric',
                'ExpenseMetricsBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.expenseMetricsBit',
                'ExpenseMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.expenseMetricIEbit',
                'ExpenseMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.expenseMetric',
                'ErrorMetricsBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.errorMetricsBit',
                'ErrorMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.errorMetricIEbit',
                'ErrorMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.errorMetric',
                'IsNeighbor': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_1.isIsReachability.metricEntries.metricEntry_1.isNeighbor'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1lsp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
            | Edit Header Isis Metric Entry | Stream=${Stream} | TlvIndex=0 | EntryIndex=0 | errorMetricIEbit=1 |
    """

    result = renix.edit_header_isis_metric_entry(Stream=Stream, Level=Level, TlvIndex=TlvIndex, EntryIndex=EntryIndex,
                                                 **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_sub_tlv(Stream, SubTlv, Level=0, TlvIndex=0, SubTlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1/L2 Lsp报文中Tlv头部Sub Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        SubTlv (str): Isis Sub Tlv节点类型，支持：

            adGroupSubtlv

            ipv4InterfaceAddressSubtlv

            ipv4NeighborAddressSubtlv

            maxLinkBandwidthSubtlv

            reservableLinkBandwidthSubtlv

            unReservedBandwidthSubtlv

            interfaceIpv6Subtlv

            neigbhorIpv6Subtlv

        Level (int): 要修改的ISIS L1/L2 Lsp头部在流量模板中所有ISIS L1/L2 Lsp头部的序列号, 默认值: 0, 范围: 0-65535

        TlvIndex (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

        EntryIndex (int): 要修改的Isis Sub Tlv节点在流量模板中所有Isis Sub Tlv节点的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        adGroupSubtlv选项支持：

            TlvCode (int): Type, 默认值：3, 取值范围：0-255

            TlvLength (int): Length, 默认值：4, 取值范围：0-255

            AdminGroupValue (int): Length, 默认值：0, 取值范围：0-4294967245

        ipv4InterfaceAddressSubtlv选项支持：

            TlvCode (int): Type, 默认值：7, 取值范围：0-255

            TlvLength (int): Length, 默认值：4, 取值范围：0-255

            Ipv4InterfaceAddressValue (str): IP Interface Address, 默认值：192.168.0.2, 取值范围：有效的ipv4地址

        ipv4NeighborAddressSubtlv选项支持：

            TlvCode (int): Type, 默认值：8, 取值范围：0-255

            TlvLength (int): Length, 默认值：4, 取值范围：0-255

            Ipv4NeighborAddressValue (str): IP Neighbor Address, 默认值：192.168.0.2, 取值范围：有效的ipv4地址

        maxLinkBandwidthSubtlv选项支持：

            TlvCode (int): Type, 默认值：9, 取值范围：0-255

            TlvLength (int): Length, 默认值：4, 取值范围：0-255

            MaxBandwidthValue (int): Maximum Link Bandwidth, 默认值：0, 取值范围：0-4294967245

        reservableLinkBandwidthSubtlv选项支持：

            TlvCode (int): Type, 默认值：10, 取值范围：0-255

            TlvLength (int): Length, 默认值：4, 取值范围：0-255

            ReservableLinkBandwidthValue (int): Reservable Link Bandwidth, 默认值：0, 取值范围：0-4294967245

        unReservedBandwidthSubtlv选项支持：

            TlvCode (int): Type, 默认值：11, 取值范围：0-255

            TlvLength (int): Length, 默认值：32, 取值范围：0-255

            ResBandwidth0Value (int): Unreserved ResBandwidth Priority0, 默认值：0, 取值范围：0-4294967245

            ResBandwidth1Value (int): Unreserved ResBandwidth Priority1, 默认值：0, 取值范围：0-4294967245

            ResBandwidth2Value (int): Unreserved ResBandwidth Priority2, 默认值：0, 取值范围：0-4294967245

            ResBandwidth3Value (int): Unreserved ResBandwidth Priority3, 默认值：0, 取值范围：0-4294967245

            ResBandwidth4Value (int): Unreserved ResBandwidth Priority4, 默认值：0, 取值范围：0-4294967245

            ResBandwidth5Value (int): Unreserved ResBandwidth Priority5, 默认值：0, 取值范围：0-4294967245

            ResBandwidth6Value (int): Unreserved ResBandwidth Priority6, 默认值：0, 取值范围：0-4294967245

            ResBandwidth7Value (int): Unreserved ResBandwidth Priority7, 默认值：0, 取值范围：0-4294967245

        interfaceIpv6Subtlv选项支持：

            TlvCode (int): Type, 默认值：12, 取值范围：0-255

            TlvLength (int): Length, 默认值：16, 取值范围：0-255

            InterfaceIpv6Value (str): Interface IPv6 Value, 默认值：2001::2, 取值范围：有效的ipv6地址

        neigbhorIpv6Subtlv选项支持：

            TlvCode (int): Type, 默认值：13, 取值范围：0-255

            TlvLength (int): Length, 默认值：16, 取值范围：0-255

            Neighboripv6Value (str): Neighbor IPv6 Value, 默认值：2001::2, 取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'TlvCode': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_2.extendedReachability.iisNeighborSubTlv.iisNeighborSubContainer_0.adGroupSubtlv.tlvCode',
                'TlvLength': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_2.extendedReachability.iisNeighborSubTlv.iisNeighborSubContainer_0.adGroupSubtlv.tlvLength',
                'AdminGroupValue': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_2.extendedReachability.iisNeighborSubTlv.iisNeighborSubContainer_0.adGroupSubtlv.adminGroupValue'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1lsp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
            | Edit Header Isis Metric Entry | Stream=${Stream} | TlvIndex=0 | EntryIndex=0 | errorMetricIEbit=1 |
    """

    result = renix.edit_header_isis_sub_tlv(Stream=Stream, SubTlv=SubTlv, Level=Level, TlvIndex=TlvIndex,
                                            SubTlvIndex=SubTlvIndex,
                                            **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_internal_metric_entry(Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1/L2 Lsp报文中Tlv头部Metric Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ISIS L1/L2 Lsp头部在流量模板中所有ISIS L1/L2 Lsp头部的序列号, 默认值: 0, 范围: 0-65535

        TlvIndex (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

        EntryIndex (int): 要修改的Isis Internal Metric Entry节点在流量模板中所有Isis Internal Metric Entry节点的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Reserved (hex): Distribution, 默认值：0, 取值范围：0-1

        DefaultMetricIEbit (int): Default Metric I/E Bit, 默认值：0, 取值范围：0-1

        DefaultMetric (int): Default Metric, 默认值：0, 取值范围：0-63

        DelayMetricsbit (int): Delay Metric S bit, 默认值：0, 取值范围：0-1

        DelayMetricSBit (int): Delay Metric R bit, 默认值：0, 取值范围：0-1

        DelayMetric (int): Delay Metric, 默认值：0, 取值范围：0-63

        ExpenseMetricsBit (int): Expense Metric S Bit, 默认值：0, 取值范围：0-1

        ExpenseMetricIEbit (int): Expense Metric R Bit, 默认值：0, 取值范围：0-1

        ExpenseMetric (int): Expense Metric, 默认值：0, 取值范围：0-63

        ErrorMetricsBit (int): Error Metric S Bit, 默认值：0, 取值范围：0-1

        ErrorMetricIEbit (int): Error Metric R Bit, 默认值：0, 取值范围：0-1

        ErrorMetric (int): Error Metric, 默认值：0, 取值范围：0-63

        IpAddress (str): IP Address, 默认值：192.168.0.2, 取值范围：有效的ipv4地址

        SubMask (hex): Subnet Mask, 默认值：00000000, 长度：4byte

    Returns:

        dict: eg::

            {
                'Reserved': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.reserved',
                'DefaultMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.defaultMetricIEbit',
                'DefaultMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.defaultMetric',
                'DelayMetricsbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.delayMetricsbit',
                'DelayMetricSBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.delayMetricSBit',
                'DelayMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.delayMetric',
                'ExpenseMetricsBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.expenseMetricsBit',
                'ExpenseMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.expenseMetricIEbit',
                'ExpenseMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.expenseMetric',
                'ErrorMetricsBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.errorMetricsBit',
                'ErrorMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.errorMetricIEbit',
                'ErrorMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.errorMetric',
                'IpAddress': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.ipAddress',
                'SubMask': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_3.isIsIpInterReachability.internalmetricEntries.internalMetricEntry_1.subMask'

            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1lsp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
            | Edit Header Isis Internal Metric Entry | Stream=${Stream} | TlvIndex=0 | EntryIndex=0 | errorMetricIEbit=1 |
    """

    result = renix.edit_header_isis_internal_metric_entry(Stream=Stream, Level=Level, TlvIndex=TlvIndex,
                                                          EntryIndex=EntryIndex,
                                                          **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_external_metric_entry(Stream, Level=0, TlvIndex=0, EntryIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ISIS L1 Lsp报文中Tlv头部Metric Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ISIS L1/L2 Lsp头部在流量模板中所有ISIS L1/L2 Lsp头部的序列号, 默认值: 0, 范围: 0-65535

        TlvIndex (int): 要修改的Isis Tlv头部在流量模板中所有Isis Tlv头部的序列号, 默认值: 0, 范围: 0-65535

        EntryIndex (int): 要修改的Isis External Metric Entry节点在流量模板中所有Isis External Metric Entry节点的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Reserved (hex): Distribution, 默认值：0, 取值范围：0-1

        DefaultMetricIEbit (int): Default Metric I/E Bit, 默认值：0, 取值范围：0-1

        DefaultMetric (int): Default Metric, 默认值：0, 取值范围：0-63

        DelayMetricsbit (int): Delay Metric S bit, 默认值：0, 取值范围：0-1

        DelayMetricSBit (int): Delay Metric R bit, 默认值：0, 取值范围：0-1

        DelayMetric (int): Delay Metric, 默认值：0, 取值范围：0-63

        ExpenseMetricsBit (int): Expense Metric S Bit, 默认值：0, 取值范围：0-1

        ExpenseMetricIEbit (int): Expense Metric R Bit, 默认值：0, 取值范围：0-1

        ExpenseMetric (int): Expense Metric, 默认值：0, 取值范围：0-63

        ErrorMetricsBit (int): Error Metric S Bit, 默认值：0, 取值范围：0-1

        ErrorMetricIEbit (int): Error Metric R Bit, 默认值：0, 取值范围：0-1

        ErrorMetric (int): Error Metric, 默认值：0, 取值范围：0-63

        IpAddress (str): IP Address, 默认值：192.168.0.2, 取值范围：有效的ipv4地址

        SubMask (hex): Subnet Mask, 默认值：00000000, 长度：4byte

    Returns:

        dict: eg::

            {
                'Reserved': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.reserved',
                'DefaultMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.defaultMetricIEbit',
                'DefaultMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.defaultMetric',
                'DelayMetricsbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.delayMetricsbit',
                'DelayMetricSBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.delayMetricSBit',
                'DelayMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.delayMetric',
                'ExpenseMetricsBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.expenseMetricsBit',
                'ExpenseMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.expenseMetricIEbit',
                'ExpenseMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.expenseMetric',
                'ErrorMetricsBit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.errorMetricsBit',
                'ErrorMetricIEbit': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.errorMetricIEbit',
                'ErrorMetric': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.errorMetric',
                'IpAddress': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.ipAddress',
                'SubMask': 'LspDataUnitHeader.LspisIsTlvOptionSet.lspisIsTlvs_5.isIsIPExternalReachability.externalmetricEntries.externalMetricEntry_1.subMask'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis L1lsp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
            | Edit Header Isis Tlv Header | Stream=${Stream} | Option=${Option} | Index=0 | lspEntries=1 |
            | Edit Header Isis External Metric Entry | Stream=${Stream} | TlvIndex=0 | EntryIndex=0 | errorMetricIEbit=1 |
    """

    result = renix.edit_header_isis_external_metric_entry(Stream=Stream, Level=Level, TlvIndex=TlvIndex,
                                                          EntryIndex=EntryIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_psnp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Isis L1/L2 Pcnp报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 范围: 0-65535: 要修改的Isis L1/L2 Pcnp头部在流量模板中所有Isis L1/L2 Pcnp头部的序列号

    Keyword Args:

        InterRoutingProtocolDiscriminator (int): Intradomain Routeing Protocol Discriminator, 默认值：<AUTO>83

        LengthIndicator (int): Length Indicator, 默认值：<AUTO>33

        VersionIdExtend (int): Version/Protocol ID Extension, 默认值：<AUTO>1

        IdLength (int): ID Length, 默认值：<AUTO>6

        Reserved1 (int): 默认值：3, 取值范围：0-7

        PDUType (int): PDU Type, 默认值：<AUTO>24, 取值范围：0-31

        Version (int): 默认值：1, 取值范围：0-255

        Reserved2 (int): 默认值：3, 取值范围：0-255

        MaxAreaAddress (int): Maximum Area Addresses, 默认值：3, 取值范围：0-3

        PDULength (int): PDU Length, 默认值：<AUTO>33

        SourceId (hex): Source ID, 默认值：000000000000, 长度: 6byte

        Reserved (hex): Reserved, 默认值：00, 长度: 1byte

        CsnpDataTlvOptionHeader (list): 可插入的选项，默认无选项，可选值：

            isIsLspEntries

            authentionInfo

    Returns:

        dict: eg::

            {
                'InterRoutingProtocolDiscriminator': 'InterRoutingProtocolDiscriminator',
                'LengthIndicator': 'lengthIndicator',
                'VersionIdExtend': 'versionIdExtend',
                'IdLength': 'idLength',
                'Reserved1': 'reserved1',
                'PDUType': 'pDUType',
                'Version': 'version',
                'Reserved2': 'reserved2',
                'MaxAreaAddress': 'maxAreaAddress',
                'PDULength': 'pDULength',
                'SourceId': 'sourceId',
                'Reserved': 'reserved',
                'CsnpDataTlvOptionHeader': 'CsnpDataTlvOptionHeader'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | l1csnpHeader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis psnp | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
    """

    result = renix.edit_header_isis_psnp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_isis_p2p_hello(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Isis P2p Hello报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 范围: 0-65535: 要修改的Isis P2p Hello头部在流量模板中所有Isis P2p Hello头部的序列号

    Keyword Args:

        InterRoutingProtocolDiscriminator (int): Intradomain Routeing Protocol Discriminator, 默认值：<AUTO>83

        LengthIndicator (int): Length Indicator, 默认值：<AUTO>20

        VersionIdExtend (int): Version/Protocol ID Extension, 默认值：<AUTO>1

        IdLength (int): ID Length, 默认值：<AUTO>6

        CommonReserved1 (int): 默认值：0, 取值范围：0-7

        PDUType (int): PDU Type, 默认值：<AUTO>17, 取值范围：0-31

        Version (int): 默认值：1, 取值范围：0-255

        CommonReserved2 (int): 默认值：0, 取值范围：0-255

        MaxAreaAddress (int): Maximum Area Addresses, 默认值：1, 取值范围：0-3

        FixedReserve1 (int): 默认值：0, 取值范围：0-63

        CircuitType (hex): Circuit Type, 默认值：1, 长度：1byte

        SenderSystemID (hex): System ID{sender}, 默认值：000000000001, 长度：6byte

        HolderTimer (hex): Holding Timer, 默认值：000000000001, 长度：6byte

        PDULength (int): PDU Length, 默认值：<AUTO>20, 取值范围：0-65535

        LocalCircuitId (int): Local Circuit ID, 默认值：1, 取值范围：0-255

        IsIsTlv (list): 可插入的选项，默认无选项，可选值：

            padding

            areaAddress

            authentionInfo

            protocolSupport

            ipInterfaceAddress

            Ipv6InterfaceAddress

            restartSignal

            p2pAdjacencyState

    Returns:

        dict: eg::

            {
                'InterRoutingProtocolDiscriminator': 'InterRoutingProtocolDiscriminator',
                'LengthIndicator': 'lengthIndicator',
                'VersionIdExtend': 'versionIdExtend',
                'IdLength': 'idLength',
                'CommonReserved1': 'commonReserved1',
                'PDUType': 'pDUType',
                'Version': 'version',
                'CommonReserved2': 'commonReserved2',
                'MaxAreaAddress': 'maxAreaAddress',
                'FixedReserve1': 'fixedReserve1',
                'CircuitType': 'circuitType',
                'SenderSystemID': 'senderSystemID',
                'HolderTimer': 'holderTimer',
                'PDULength': 'pDULength',
                'LocalCircuitId': 'localCircuitId',
                'IsIsTlv': 'isIsTlv'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | p2phelloheader |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Isis P2p Hello | Stream=${Stream} | Level=0 | version=10 | maxAreaAddress=3 |
    """

    result = renix.edit_header_isis_p2p_hello(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
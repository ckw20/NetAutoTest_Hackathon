import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def edit_header_sctp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        SourcePort (int): Source Port, 默认值：3001，取值范围：0-65535

        DestPort (int): Destination Port, 默认值：3002，取值范围：0-65535

        VerTag (int): Verification Tag, 默认值：1，取值范围：0-4294967295

        Checksum (hex): Checksum, 默认值：00000000，取值范围：长度为4字节的十六进制数

        ChunkList (int): 要插入的Sctp Chunks数量, 默认值：0，取值范围：0-250

    Returns:

        dict: eg::

            {
                'SourcePort': 'header.sourcePort',
                'DestPort': 'header.destPort',
                'VerTag': 'header.verTag'，
                'Checksum': 'header.checksum'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp | Stream=${Stream} | Level=0 | SeqNum=10 |
    """

    result = renix.edit_header_sctp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_chunk(Stream, ChunkType, Level=0, ChunkIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Chunk Type报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkType (str): Sctp Chunk Type，取值范围：

            DataChunk

            InitChunk

            InitAckChunk

            SAckChunk

            HeartbeatChunk

            HeartbeatAckChunk

            AbortChunk

            ShutdownChunk

            ShutdownAckChunk

            ErrorChunk

            CookieEchoChunk

            CookieAckChunk

            ShutdownCompleteChunk

    Keyword Args:

        DataChunk:

            Type (int): Type, 默认值：0，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            Tsn (int): TSN, 默认值：0，取值范围：0-4294967295

            Sid (int): Stream Identifier, 默认值：0，取值范围：0-65535

            Ssn (int): Stream Sequence Number, 默认值：0，取值范围：0-65535

            Pid (int): Payload Protocol Identifier, 默认值：0，取值范围：0-4294967295

            Data (hex): User Data, 默认值：''，取值范围：长度为0-65535字节的十六进制数

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        InitChunk:

            Type (int): Type, 默认值：1，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            InitTag (int): Initiate Tag, 默认值：0，取值范围：0-4294967295

            Arwc (int): Advertised Receiver Window Credit, 默认值：0，取值范围：0-4294967295

            Nos (int): Number of Outbound Streams, 默认值：0，取值范围：0-65535

            Mis (int): Number of Inbound Streams, 默认值：0，取值范围：0-65535

            Itsn (int): Initial TSN, 默认值：0，取值范围：0-4294967295

            InitOptionalParams (int): 要插入的init optional parameter tlv数量, 默认值：0，取值范围：0-1024

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        InitAckChunk:

            Type (int): Type, 默认值：1，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            InitTag (int): Initiate Tag, 默认值：0，取值范围：0-4294967295

            Arwc (int): Advertised Receiver Window Credit, 默认值：0，取值范围：0-4294967295

            Nos (int): Number of Outbound Streams, 默认值：0，取值范围：0-65535

            Mis (int): Number of Inbound Streams, 默认值：0，取值范围：0-65535

            Itsn (int): Initial TSN, 默认值：0，取值范围：0-4294967295

            StateCookieType (int): Type, 默认值：7，取值范围：0-65535

            StateCookieLength (int): Parameter Length, 默认值：<AUTO>0，取值范围：0-65535

            StateCookieValue (hex): User Data, 默认值：''，取值范围：长度为0-65535字节的十六进制数

            StateCookiePadding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

            InitOptionalParams (int): 要插入的init optional parameter tlv数量, 默认值：0，取值范围：0-1024

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        SAckChunk:

            Type (int): Type, 默认值：1，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            Ctsnack (int): Cumulative TSN Ack, 默认值：0，取值范围：0-4294967295

            Arwc (int): Advertised Receiver Window Credit, 默认值：0，取值范围：0-4294967295

            Nogab (int): Number of Gap Ack Blocks, 默认值：0，取值范围：0-65535

            Nodtsns (int): Number of Duplicate TSNs, 默认值：0，取值范围：0-65535

            GapAckBlocks (int): 要插入的Gap Ack Block数量, 默认值：0，取值范围：0-1024

            DuplicateTSNs (int): 要插入的Duplicate TSN数量, 默认值：0，取值范围：0-1024

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        HeartbeatChunk, HeartbeatAckChunk:

            Type (int): Type, 默认值：4，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            HbInfoType (int): Type, 默认值：1，取值范围：0-65535

            HbInfoLength (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            HbInfoValue (hex): Value, 默认值：0，取值范围：长度为0-65535字节的十六进制数

            HbInfoPadding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        AbortChunk:

            Type (int): Type, 默认值：6，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-128

            T (bit): T, 默认值：0，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            ErrorCauses (list): 要插入的Error Causes List，列表元素取值范围：

                InvalidStreamIdentifier

                MissingMandatoryParameter

                StaleCookieError

                OutOfResource

                UnresolvableAddress

                UnrecognizedChunk

                InvalidMandatoryParameter

                UnrecognizedParameters

                NoUserData

                CookieReceivedWhileShuttingDown

                RestartOfAnAssociationWithNewAddresses

                UserInitiatedAbort

                ProtocolViolation

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        ShutdownChunk:

            Type (int): Type, 默认值：7，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

            Ctsnack (int): Cumulative TSN Ack, 默认值：0，取值范围：0-4294967295

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        ShutdownAckChunk:

            Type (int): Type, 默认值：8，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>4，取值范围：0-65535

        ErrorChunk:

            Type (int): Type, 默认值：9，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>4，取值范围：0-65535

            ErrorCauses (list): 要插入的Error Causes List，列表元素取值范围：

                InvalidStreamIdentifier

                MissingMandatoryParameter

                StaleCookieError

                OutOfResource

                UnresolvableAddress

                UnrecognizedChunk

                InvalidMandatoryParameter

                UnrecognizedParameters

                NoUserData

                CookieReceivedWhileShuttingDown

                RestartOfAnAssociationWithNewAddresses

                UserInitiatedAbort

                ProtocolViolation

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        CookieEchoChunk:

            Type (int): Type, 默认值：10，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>4，取值范围：0-65535

            Cookie (hex): Cookie, 默认值：0，取值范围：长度为0-65535字节的十六进制数

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        CookieAckChunk:

            Type (int): Type, 默认值：11，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-255

            Ubit (bit): U bit, 默认值：0，取值范围：0-1

            Bbit (bit): B bit, 默认值：1，取值范围：0-1

            Ebit (bit): E bit, 默认值：1，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>4，取值范围：0-65535

        ShutdownCompleteChunk:

            Type (int): Type, 默认值：6，取值范围：0-255

            Reserved (int): Reserved, 默认值：0，取值范围：0-128

            T (bit): T, 默认值：0，取值范围：0-1

            Length (int): Length, 默认值：<AUTO>4，取值范围：0-65535

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

    Returns:

        dict: eg::

            {
            'Type': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.type',
            'Reserved': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.flags.reserved',
            'Ubit': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.flags.ubit',
            'Bbit': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.flags.bbit',
            'Ebit': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.flags.ebit',
            'Length': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.length',
            'Tsn': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.tsn',
            'Sid': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.sid',
            'Ssn': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.ssn',
            'Pid': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.pid',
            'Data': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.data',
            'Padding': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.dataChunk.padding'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Chunk | Stream=${Stream} | Level=0 | ChunkType=ShutdownCompleteChunk | Padding=1020 |
    """

    result = renix.edit_header_sctp_chunk(Stream=Stream, Level=Level,
                                          ChunkType=ChunkType,
                                          ChunkIndex=ChunkIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_init_optional_parameters_tlv(Stream, ChunkType, Level=0, ChunkIndex=0, TlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Init/Init Ack Chunk Optional Parameter Tlv报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkType (str): Sctp Chunk Type，取值范围：

            InitChunk

            InitAckChunk

        ChunkIndex (int): 要修改的Sctp Chunk在流量模板中所有Sctp Chunk的序列号, 默认值: 0, 范围: 0-249

        TlvIndex (int): 要修改的Sctp Init Optional Parameter TLV在流量模板中所有Sctp Init Optional Parameter TLV的序列号, 默认值: 0, 范围: 0-1023

    Keyword Args:

        InitOptionalParamType (int): Type (only for InitChunk), 默认值：5，取值范围：0-65535

        InitAckOptionalParamType (int): Type (only for InitAckChunk), 默认值：5，取值范围：0-65535

        Length (int): Parameter Length, 默认值：0，取值范围：0-65535

        Value (hex): User Data, 默认值：0，取值范围：长度为0-65535字节的十六进制数

        Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

    Returns:

        dict: eg::

            {
            'InitOptionalParamType': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.initChunk.initOptionalParams.InitOptionalParameters_1.InitOptionalParamType',
            'Length': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.initChunk.initOptionalParams.InitOptionalParameters_1.length',
            'Value': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.initChunk.initOptionalParams.InitOptionalParameters_1.value',
            'Padding': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.initChunk.initOptionalParams.InitOptionalParameters_1.padding'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Init Optional Parameters Tlv | Stream=${Stream} | ChunkType=InitChunk | Value=10 |
    """

    result = renix.edit_header_sctp_init_optional_parameters_tlv(Stream=Stream, Level=Level,
                                                                 ChunkType=ChunkType,
                                                                 ChunkIndex=ChunkIndex,
                                                                 TlvIndex=TlvIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_sack_chunk_gap_ack_block(Stream, Level=0, ChunkIndex=0, BlockIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Sack Chunk Gap Ack Blocks报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkIndex (int): 要修改的Sctp Chunk在流量模板中所有Sctp Chunk的序列号, 默认值: 0, 范围: 0-249

        BlockIndex (int): 要修改的Sctp Gap Ack Block在流量模板中所有Sctp Gap Ack Block的序列号, 默认值: 0, 范围: 0-1023

    Keyword Args:

        Gabs (int): Gap Ack Block Start, 默认值：0，取值范围：0-65535

        Gabe (int): Gap Ack Block End, 默认值：0，取值范围：0-65535

    Returns:

        dict: eg::

            {
            'Gabs': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.sackChunk.gapackBlocks.GapAckBlock_1.gabs',
            'Gabe': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.sackChunk.gapackBlocks.GapAckBlock_1.gabe'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Sack Chunk Gap Ack Block | Stream=${Stream} | Gabs=10 |
    """

    result = renix.edit_header_sctp_sack_chunk_gap_ack_block(Stream=Stream, Level=Level,
                                                             ChunkIndex=ChunkIndex,
                                                             BlockIndex=BlockIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_sack_chunk_duplicate_tsn(Stream, Level=0, ChunkIndex=0, TsnIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Sack Chunk Duplicate Tsn报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkIndex (int): 要修改的Sctp Chunk在流量模板中所有Sctp Chunk的序列号, 默认值: 0, 范围: 0-249

        TsnIndex (int): 要修改的Sctp Duplicate Tsn在流量模板中所有Sctp Duplicate Tsn的序列号, 默认值: 0, 范围: 0-1023

    Keyword Args:

        Dtsn (int): Value, 默认值：0，取值范围：0-4294967295

    Returns:

        dict: eg::

            {
            'Dtsn': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.sackChunk.duplicateTSNs.DuplicateTSN_2.dtsn'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Sack Chunk Duplicate Tsn | Stream=${Stream} | Dtsn=10 |
    """

    result = renix.edit_header_sctp_sack_chunk_duplicate_tsn(Stream=Stream, Level=Level,
                                                             ChunkIndex=ChunkIndex,
                                                             TsnIndex=TsnIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_chunk_error_cause(Stream, ChunkType, CauseType, Level=0, ChunkIndex=0, CauseIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Abort/Error Chunk的Error Cause报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkType (str): Sctp Chunk Type，取值范围：

            AbortChunk

            ErrorChunk

        CauseType (str): Error Cause，取值范围：

            InvalidStreamIdentifier

            MissingMandatoryParameter

            StaleCookieError

            OutOfResource

            UnresolvableAddress

            UnrecognizedChunk

            InvalidMandatoryParameter

            UnrecognizedParameters

            NoUserData

            CookieReceivedWhileShuttingDown

            RestartOfAnAssociationWithNewAddresses

            UserInitiatedAbort

            ProtocolViolation

        ChunkIndex (int): 要修改的Sctp Chunk在流量模板中所有Sctp Chunk的序列号, 默认值: 0, 范围: 0-249

        CauseIndex (int): 要修改的Sctp Duplicate Tsn在流量模板中所有Sctp Duplicate Tsn的序列号, 默认值: 0, 范围: 0-1023

    Keyword Args:

        InvalidStreamIdentifier:

            CauseCode (int): Cause Code，默认值：1，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            StreamIdentifier (int): Stream Identifier，默认值：0，取值范围：0-65535

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        MissingMandatoryParameter：

            CauseCode (int): Cause Code，默认值：2，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            NumberOfMissingParams (int): Number of Missing Params，默认值：0，取值范围：0-65535

            MissingParamTypes (int): 要插入的Missing Param Types的个数，默认值：0，取值范围：0-65535

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        StaleCookieError:

            CauseCode (int): Cause Code，默认值：3，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            MeasureOfStaleness (int): Measure of Staleness (usec)，默认值：0，取值范围：0-4294967295

        OutOfResource:

            CauseCode (int): Cause Code，默认值：4，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

        UnresolvableAddress:

            CauseCode (int): Cause Code，默认值：5，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            NewAddressTlvs (int): 要插入的New Address TLVs的个数，默认值：0，取值范围：0-1024

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        UnrecognizedChunk:

            CauseCode (int): Cause Code，默认值：6，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            UnrecognizedChunkType (int): Chunk Type，默认值：0，取值范围：0-255

            UnrecognizedChunkFlagReserved (int): Reserved, 默认值：0，取值范围：0-31

            UnrecognizedChunkFlagUbit (bit): U bit, 默认值：0，取值范围：0-1

            UnrecognizedChunkFlagBbit (bit): B bit, 默认值：1，取值范围：0-1

            UnrecognizedChunkFlagEbit (bit): E bit, 默认值：1，取值范围：0-1

            UnrecognizedChunkLength (int): Length, 默认值：<AUTO>4，取值范围：0-65535

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        InvalidMandatoryParameter:

            CauseCode (int): Cause Code，默认值：7，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

        UnrecognizedParameters:

            CauseCode (int): Cause Code，默认值：8，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            UnrecognizedParameters (int): 要插入的Unrecognized Parameter TLVs的个数，默认值：0，取值范围：0-1024

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        NoUserData:

            CauseCode (int): Cause Code，默认值：9，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            TsnValue (int): TSN Value，默认值：0，取值范围：0-4294967295

        CookieReceivedWhileShuttingDown:

            CauseCode (int): Cause Code，默认值：10，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

        RestartOfAnAssociationWithNewAddresses:

            CauseCode (int): Cause Code，默认值：11，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            NewAddressTlvs (int): 要插入的New Address TLVs的个数，默认值：0，取值范围：0-1024

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        UserInitiatedAbort:

            CauseCode (int): Cause Code，默认值：12，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            AdditionalInformation (hex): Upper Layer Abort Reason，默认值：''，取值范围：长度为0-65535字节的十六进制数

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

        ProtocolViolation:

            CauseCode (int): Cause Code，默认值：13，取值范围：0-65535

            CauseLength (int): Cause Length，默认值：0，取值范围：0-65535

            AdditionalInformation (hex): Upper Layer Abort Reason，默认值：''，取值范围：长度为0-65535字节的十六进制数

            Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

    Returns:

        dict: eg::

            {
            'CauseCode': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_0.invalidStreamIdentifier.causeCode',
            'CauseLength': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_0.invalidStreamIdentifier.causeLength',
            'StreamIdentifier': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_0.invalidStreamIdentifier.streamIdentifier',
            'Padding': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_0.invalidStreamIdentifier.padding'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Chunk Error Cause | Stream=${Stream} | ChunkType=AbortChunk | CauseType=ProtocolViolation | AdditionalInformation=FF |
    """

    result = renix.edit_header_sctp_chunk_error_cause(Stream=Stream, Level=Level,
                                                      ChunkType=ChunkType,
                                                      CauseType=CauseType,
                                                      ChunkIndex=ChunkIndex,
                                                      CauseIndex=CauseIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_chunk_error_cause_missing_parameter_type(Stream, ChunkType, Level=0, ChunkIndex=0, CauseIndex=0,
                                                              TypeIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Abort/Error Chunk的Error Cause报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkType (str): Sctp Chunk Type，取值范围：

            AbortChunk

            ErrorChunk

        ChunkIndex (int): 要修改的Sctp Chunk在流量模板中所有Sctp Chunk的序列号, 默认值: 0, 范围: 0-249

        CauseIndex (int): 要修改的Sctp Error Cause在流量模板中所有Sctp Error Cause的序列号, 默认值: 0, 范围: 0-1023

        TypeIndex (int): 要修改的Sctp missing parameter type在流量模板中所有Sctp missing parameter type的序列号, 默认值: 0, 范围: 0-1023

    Keyword Args:

        MissingParamTypeValue (int): Value, 默认值：0，取值范围：0-4294967295

    Returns:

        dict: eg::

            {
            'MissingParamTypeValue': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_1.missingMandatoryParameter.missingParamTypes.MissingParamType_1.missingParamTypeValue'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Chunk Error Cause Missing Parameter Type | Stream=${Stream} | ChunkType=AbortChunk | MissingParamTypeValue=10 |
    """

    result = renix.edit_header_sctp_chunk_error_cause_missing_parameter_type(Stream=Stream, Level=Level,
                                                                             ChunkType=ChunkType,
                                                                             ChunkIndex=ChunkIndex,
                                                                             CauseIndex=CauseIndex,
                                                                             TypeIndex=TypeIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_chunk_error_cause_unrecognized_parameter_tlv(Stream, ChunkType, Level=0, ChunkIndex=0,
                                                                  CauseIndex=0, TlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Abort/Error Chunk的Unrecognized Parameter Error Cause报文头部Unrecognized Parameter TLVs内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkType (str): Sctp Chunk Type，取值范围：

            AbortChunk

            ErrorChunk

        ChunkIndex (int): 要修改的Sctp Chunk在流量模板中所有Sctp Chunk的序列号, 默认值: 0, 范围: 0-249

        CauseIndex (int): 要修改的Sctp Error Cause在流量模板中所有Sctp Error Cause的序列号, 默认值: 0, 范围: 0-1023

        TlvIndex (int): 要修改的Sctp Unrecognized Parameter TLVs在流量模板中所有Sctp Unrecognized Parameter TLVs的序列号, 默认值: 0, 范围: 0-1023

    Keyword Args:

        Type (int): Type, 默认值：0，取值范围：0-65535

        Length (int): Parameter Length, 默认值：0<AUTO>，取值范围：0-65535

        Value (Hex): Type, 默认值：''，取值范围：长度0-65535字节的十六进制数

        Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

    Returns:

        dict: eg::

            {
            'Type': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_7.unrecognizedParameters.unrecognizedParameters.UnrecognizedParameterLTV_1.type',
            'Length': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_7.unrecognizedParameters.unrecognizedParameters.UnrecognizedParameterLTV_1.length',
            'Value': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_7.unrecognizedParameters.unrecognizedParameters.UnrecognizedParameterLTV_1.value',
            'Padding': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_7.unrecognizedParameters.unrecognizedParameters.UnrecognizedParameterLTV_1.padding'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Chunk Error Cause Unrecognized Parameter Tlv | Stream=${Stream} | ChunkType=AbortChunk | Value=10 |
    """

    result = renix.edit_header_sctp_chunk_error_cause_unrecognized_parameter_tlv(Stream=Stream, Level=Level,
                                                                                 ChunkType=ChunkType,
                                                                                 ChunkIndex=ChunkIndex,
                                                                                 CauseIndex=CauseIndex,
                                                                                 TlvIndex=TlvIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_sctp_chunk_error_cause_new_address_tlv(Stream, ChunkType, CauseType, Level=0, ChunkIndex=0,
                                                       CauseIndex=0, TlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中Sctp Abort/Error Chunk的Error Cause报文头部New Address TLVs内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Sctp头部在流量模板中所有Sctp头部的序列号, 默认值: 0, 范围: 0-65535

        ChunkType (str): Sctp Chunk Type，取值范围：

            AbortChunk

            ErrorChunk

        ChunkIndex (int): 要修改的Sctp Chunk在流量模板中所有Sctp Chunk的序列号, 默认值: 0, 范围: 0-249

        CauseType (str): Sctp Error Cause，取值范围：

            UnresolvableAddress

            RestartOfAnAssociationWithNewAddresses

        CauseIndex (int): 要修改的Sctp Error Cause在流量模板中所有Sctp Error Cause的序列号, 默认值: 0, 范围: 0-1023

        TlvIndex (int): 要修改的New Address TLVs在流量模板中所有Sctp Restart of an Association with New Address Error Cause报文头部New Address TLVs的序列号, 默认值: 0, 范围: 0-1023

    Keyword Args:

        Type (int): Type, 默认值：0，取值范围：0-65535

        Length (int): Parameter Length, 默认值：0<AUTO>，取值范围：0-65535

        Value (Hex): Type, 默认值：''，取值范围：长度0-65535字节的十六进制数

        Padding (hex): 4 Byte Alignment Padding, 默认值：0，取值范围：长度为0-3字节的十六进制数

    Returns:

        dict: eg::

            {
            'Type': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_10.restartOfAnAssociationWithNewAddresses.newAddressTLVs.NewAddressTLV_1.type',
            'Length': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_10.restartOfAnAssociationWithNewAddresses.newAddressTLVs.NewAddressTLV_1.length',
            'Value': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_10.restartOfAnAssociationWithNewAddresses.newAddressTLVs.NewAddressTLV_1.value',
            'Padding': 'chunks.sctpChunk_0.chunkType.sctpChunkChoice_0.abortChunk.errorCauses.ErrorCausesTLV_10.restartOfAnAssociationWithNewAddresses.newAddressTLVs.NewAddressTLV_1.padding'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Sctp Chunk Error Cause New Address Tlv | Stream=${Stream} | ChunkType=AbortChunk | CauseType=UnresolvableAddress | Value=10 |
    """

    result = renix.edit_header_sctp_chunk_error_cause_new_address_tlv(Stream=Stream, Level=Level,
                                                                      ChunkType=ChunkType,
                                                                      ChunkIndex=ChunkIndex,
                                                                      CauseType=CauseType,
                                                                      CauseIndex=CauseIndex,
                                                                      TlvIndex=TlvIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

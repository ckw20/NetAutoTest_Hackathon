import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Header Routing OSPFv2-------------------------------------
def edit_header_ospfv2_hello(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Hello报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 Hello头部在流量模板中所有OSPFv2 Hello头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version，默认值：2，取值范围：0-255

        Type (int): Packet Type，默认值：1，取值范围：

            0：Unknown

            1：Hello

            2：Database Description

            3：Link State Request

            4：Link State Update

            5：Link State Acknowledgement

        PacketLength (int): Packet Length，默认值：0，取值范围：0-65535

        RouterID (str): Router ID，默认值：1.1.1.1，取值范围：ipv4地址

        AreaID (str): Area ID，默认值：0.0.0.0，取值范围：ipv4地址

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        AuthType (str): Authentication Type，默认值：NoAuth，取值范围：

            SimplePassword

            MD5

            UserDefined

            NoAuth

        AuthValue1 (int): Authentication Value1，默认值：0，取值范围：0-4294967295

        AuthValue2 (int): Authentication Value2，默认值：0，取值范围：0-4294967295

        PacketOptionsReserved7 (bit): Reserved Bit 7，默认值：0，取值范围：0-1

        PacketOptionsReserved6 (bit): Reserved Bit 6，默认值：0，取值范围：0-1

        PacketOptionsDcBit (bit): DC Bit，默认值：0，取值范围：0-1

        PacketOptionsEaBit (bit): EA Bit，默认值：0，取值范围：0-1

        PacketOptionsNpBit (bit): NP Bit，默认值：0，取值范围：0-1

        PacketOptionsMcBit (bit): MC Bit，默认值：0，取值范围：0-1

        PacketOptionsEBit (bit): E Bit，默认值：0，取值范围：0-1

        PacketOptionsReserved0 (bit): Reserved Bit 0，默认值：0，取值范围：0-1

        NetworkMask (str): Network Mask，默认值：255.255.255.0，取值范围：ipv4地址

        HelloInterval (int): Hello Interval，默认值：10，取值范围：0-65535

        RouterPriority (int): Router Priority，默认值：0，取值范围：0-255

        RouterDeadInterval (int): Router Dead Interval，默认值：40，取值范围：0-4294967295

        DesignatedRouter (str): Designated Router，默认值：1.1.1.1，取值范围：ipv4地址

        BackupDesignatedRouter (str): Backup Designated Router，默认值：2.2.2.2，取值范围：ipv4地址

        Neighbors (list): Neighbor ID，默认值：1.1.1.1，列表长度：0-1024

    Returns:

        dict: eg::

            {
                'RouterID': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.edit_header_ospfv2_hello(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_unknown(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Unknown报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 Unknown头部在流量模板中所有OSPFv2 Unknown头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version，默认值：2，取值范围：0-255

        Type (int): Packet Type，默认值：0，取值范围：

            0：Unknown

            1：Hello

            2：Database Description

            3：Link State Request

            4：Link State Update

            5：Link State Acknowledgement

        PacketLength (int): Packet Length，默认值：0，取值范围：0-65535

        RouterID (str): Router ID，默认值：1.1.1.1，取值范围：ipv4地址

        AreaID (str): Area ID，默认值：0.0.0.0，取值范围：ipv4地址

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        AuthType (str): Authentication Type，默认值：NoAuth，取值范围：

            SimplePassword

            MD5

            UserDefined

            NoAuth

        AuthValue1 (int): Authentication Value1，默认值：0，取值范围：0-4294967295

        AuthValue2 (int): Authentication Value2，默认值：0，取值范围：0-4294967295

    Returns:

        dict: eg::

            {
                'RouterID': 'ospfHeader.routerID'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Unknown |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Unknown | Stream=${Stream} | Level=0 | AuthType=2 | AuthValue1=1 |
    """

    result = renix.edit_header_ospfv2_unknown(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_request(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Link State Request报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 Link State Request头部在流量模板中所有OSPFv2 Link State Request头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version，默认值：2，取值范围：0-255

        Type (int): Packet Type，默认值：3，取值范围：

            0：Unknown

            1：Hello

            2：Database Description

            3：Link State Request

            4：Link State Update

            5：Link State Acknowledgement

        PacketLength (int): Packet Length，默认值：0，取值范围：0-65535

        RouterID (str): Router ID，默认值：1.1.1.1，取值范围：ipv4地址

        AreaID (str): Area ID，默认值：0.0.0.0，取值范围：ipv4地址

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        AuthType (str): Authentication Type，默认值：NoAuth，取值范围：

            SimplePassword

            MD5

            UserDefined

            NoAuth

        AuthValue1 (int): Authentication Value1，默认值：0，取值范围：0-4294967295

        AuthValue2 (int): Authentication Value2，默认值：0，取值范围：0-4294967295

        LsaHeaderCount (int): Requested LSA数量，默认值：0，取值范围：0-1024

    Returns:

        dict: eg::

            {
                'RouterID': 'ospfHeader.routerID'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Unknown |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Request | Stream=${Stream} | Level=0 | AuthType=2 | LsaHeaderCount=2 |
    """

    result = renix.edit_header_ospfv2_request(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_dd(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Database Description报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 Database Description头部在流量模板中所有OSPFv2 Database Description头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version，默认值：2，取值范围：0-255

        Type (int): Packet Type，默认值：2，取值范围：

            0：Unknown

            1：Hello

            2：Database Description

            3：Link State Request

            4：Link State Update

            5：Link State Acknowledgement

        PacketLength (int): Packet Length，默认值：0，取值范围：0-65535

        RouterID (str): Router ID，默认值：1.1.1.1，取值范围：ipv4地址

        AreaID (str): Area ID，默认值：0.0.0.0，取值范围：ipv4地址

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        AuthType (str): Authentication Type，默认值：NoAuth，取值范围：

            SimplePassword

            MD5

            UserDefined

            NoAuth

        AuthValue1 (int): Authentication Value1，默认值：0，取值范围：0-4294967295

        AuthValue2 (int): Authentication Value2，默认值：0，取值范围：0-4294967295

        PacketOptionsReserved7 (bit): Reserved Bit 7，默认值：0，取值范围：0-1

        PacketOptionsReserved6 (bit): Reserved Bit 6，默认值：0，取值范围：0-1

        PacketOptionsDcBit (bit): DC Bit，默认值：0，取值范围：0-1

        PacketOptionsEaBit (bit): EA Bit，默认值：0，取值范围：0-1

        PacketOptionsNpBit (bit): NP Bit，默认值：0，取值范围：0-1

        PacketOptionsMcBit (bit): MC Bit，默认值：0，取值范围：0-1

        PacketOptionsEBit (bit): E Bit，默认值：0，取值范围：0-1

        PacketOptionsReserved0 (bit): Reserved Bit 0，默认值：0，取值范围：0-1

        InterfaceMtu (int): Interface MTU，默认值：4096，取值范围：0-65535

        SequenceNumber (int): DD Sequence Number，默认值：0，取值范围：0-4294967295

        DdOptionsReserved7 (bit): Reserved Bit 7，默认值：0，取值范围：0-1

        DdOptionsReserved6 (bit): Reserved Bit 6，默认值：0，取值范围：0-1

        DdOptionsReserved5 (bit): Reserved Bit 5，默认值：0，取值范围：0-1

        DdOptionsReserved4 (bit): Reserved Bit 4，默认值：0，取值范围：0-1

        DdOptionsReserved3 (bit): Reserved Bit 3，默认值：0，取值范围：0-1

        DdOptionsIBit (bit): I Bit，默认值：0，取值范围：0-1

        DdOptionsMBit (bit): M Bit，默认值：0，取值范围：0-1

        DdOptionsMsBit (bit): MS Bit，默认值：0，取值范围：0-1

        LsaHeaderCount (int): Requested LSA数量，默认值：0，取值范围：0-1024

    Returns:

        dict: eg::

            {
                'RouterID': 'ospfHeader.routerID',
                'AuthValue1': 'ospfHeader.authSelect.hdrAuthSelectPassword.authValue1',
                'AuthValue2': 'ospfHeader.authSelect.hdrAuthSelectPassword.authValue2',
                'PacketOptionsReserved7': 'ddOptions.reserved7',
                'PacketOptionsDcBit': 'ddOptions.dcBit',
                'SequenceNumber': 'sequenceNumber',
                'DdOptionsReserved3': 'ddSpecificOptions.reserved3'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2DatabaseDescription |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Dd | Stream=${Stream} | Level=0 | InterfaceMtu=9000 | LsaHeaderCount=1 |
    """

    result = renix.edit_header_ospfv2_dd(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_ack(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Link State Acknowledge报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 Link State Acknowledge头部在流量模板中所有OSPFv2 Link State Acknowledge头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version，默认值：2，取值范围：0-255

        Type (int): Packet Type，默认值：1，取值范围：

            0：Unknown

            1：Hello

            2：Database Description

            3：Link State Request

            4：Link State Update

            5：Link State Acknowledgement

        PacketLength (int): Packet Length，默认值：0，取值范围：0-65535

        RouterID (str): Router ID，默认值：1.1.1.1，取值范围：ipv4地址

        AreaID (str): Area ID，默认值：0.0.0.0，取值范围：ipv4地址

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        AuthType (str): Authentication Type，默认值：NoAuth，取值范围：

            SimplePassword

            MD5

            UserDefined

            NoAuth

        AuthValue1 (int): Authentication Value1，默认值：0，取值范围：0-4294967295

        AuthValue2 (int): Authentication Value2，默认值：0，取值范围：0-4294967295

        LsaHeaderCount (int): Requested LSA数量，默认值：0，取值范围：0-1024

    Returns:

        dict: eg::

            {
                'RouterID': 'ospfHeader.routerID',
                'AuthValue1': 'ospfHeader.authSelect.hdrAuthSelectPassword.authValue1',
                'AuthValue2': 'ospfHeader.authSelect.hdrAuthSelectPassword.authValue2',
                'PacketOptionsReserved7': 'ddOptions.reserved7',
                'PacketOptionsDcBit': 'ddOptions.dcBit',
                'SequenceNumber': 'sequenceNumber',
                'DdOptionsReserved3': 'ddSpecificOptions.reserved3'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Ospfv2LinkStateAcknowledge |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Ack | Stream=${Stream} | Level=0 | InterfaceMtu=9000 | LsaHeaderCount=1 |
    """

    result = renix.edit_header_ospfv2_ack(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_lsa(Stream, HeaderType, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2报文中Lsa头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        HeaderType (str):: OSPFv2报文类型支持：

            Ospfv2LinkStateUpdate

            Ospfv2LinkStateRequest

            Ospfv2DatabaseDescription

            Ospfv2LinkStateAcknowledge

        Level (int): 要修改的OSPFv2 HeaderType头部在流量模板中所有OSPFv2 HeaderType头部的序列号, 默认值: 0, 范围: 0-65535

        Index (int): 要修改的OSPFv2 HeaderType Lsa头部在流量模板中所有OSPFv2 HeaderType Lsa头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        LsaAge (int): LSA Age，默认值：0，取值范围：0-65535

        Reserved7 (bit): Reserved Bit 7，默认值：0，取值范围：0-1

        Reserved6 (bit): Reserved Bit 7，默认值：0，取值范围：0-1

        DcBit (bit): DC Bit，默认值：0，取值范围：0-1

        EaBit (bit): EA Bit，默认值：0，取值范围：0-1

        NpBit (bit): NP Bit，默认值：0，取值范围：0-1

        McBit (bit): MC Bit，默认值：0，取值范围：0-1

        EBit (bit): E Bit，默认值：0，取值范围：0-1

        Reserved0 (bit): Reserved Bit 0，默认值：0，取值范围：0-1

        LsType (int): LS Type，默认值：1，取值范围：

            1: Router

            2: Network

            3: Summary

            4: Summary-ASBR

            5: AS-External Type-5

            7: AS-External Type-7

        LinkStateId (str): Link State ID，默认值：1.1.1.1，取值范围：ipv4地址

        AdvertisingRouter (str): Advertising Router，默认值：1.1.1.1，取值范围：ipv4地址

        LsSequenceNumber (hex): LS Sequence Number，默认值：80000001，取值范围：长度为4字节的十六进制数

        LsChecksum (hex): LS Checksum，默认值：0000，取值范围：0000-FFFF

        LsaLength (int): LSA Length，默认值：0，取值范围：0-65535

        LsTypeWide (int): OSPFv2 LS TypesWide，默认值：1，取值范围：

            1: Router

            2: Network

            3: Summary

            4: Summary-ASBR

            5: AS-External Type-5

            7: AS-External Type-7

    Returns:

        dict: eg::

            {
                'LsaAge': 'lsaHeaders.ospfv2LsaHeader_0.lsaAge',
                'Reserved7': 'lsaHeaders.ospfv2LsaHeader_0.lsaHdrOptions.reserved7'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2DatabaseDescription |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Dd | Stream=${Stream} | Level=0 | InterfaceMtu=9000 | LsaHeaderCount=2 |
            | Edit Header Ospfv2 Lsa | Stream=${Stream} | Index=0 | LsaAge=10 | LinkStateId=4.4.4.4 |
            | Edit Header Ospfv2 Lsa | Stream=${Stream} | Index=1 | LsaAge=20 | LinkStateId=5.5.5.5 |
    """

    result = renix.edit_header_ospfv2_lsa(Stream=Stream, HeaderType=HeaderType, Level=Level, Index=Index,
                                          **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_update(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Link State Update报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 Link State Update头部在流量模板中所有OSPFv2 Link State Update头部的序列号

    Keyword Args:

        Version (int): Version，默认值：2，取值范围：0-255

        Type (int): Packet Type，默认值：1，取值范围：

            0：Unknown

            1：Hello

            2：Database Description

            3：Link State Request

            4：Link State Update

            5：Link State Acknowledgement

        PacketLength (int): Packet Length，默认值：0，取值范围：0-65535

        RouterID (str): Router ID，默认值：1.1.1.1，取值范围：ipv4地址

        AreaID (str): Area ID，默认值：0.0.0.0，取值范围：ipv4地址

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        AuthType (str): Authentication Type，默认值：NoAuth，取值范围：

            SimplePassword

            MD5

            UserDefined

            NoAuth

        AuthValue1 (int): Authentication Value1，默认值：0，取值范围：0-4294967295

        AuthValue2 (int): Authentication Value2，默认值：0，取值范围：0-4294967295

        NumberOfLsas (int): OSPFv2 LSA数量，默认值：0，取值范围：0-1024

        LsaHeaders (str): OSPFv2 LSA类型，支持的参数有：

            Router

            Network

            Summary

            SummaryAsbr

            AsExternal

    Returns:

        dict: eg::

            {
                'RouterID': 'ospfHeader.routerID'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | ospfv2linkstateupdate |
            | ${LsaHeaders} | Create List | Router | Network | Summary | SummaryAsbr | AsExternal |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Update | Stream=${Stream} | Level=0 | AreaID=2.2.2.2 | LsaHeaders=${LsaHeaders} |
    """

    result = renix.edit_header_ospfv2_update(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_update_lsa(Stream, Type, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Update报文中Lsa头部内容.

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Type (str): OSPFv2报文lsa类型支持：

            Router

            Network

            Summary

            SummaryAsbr

            External

        Level (int): 要修改的OSPFv2 update头部在流量模板中所有OSPFv2 update头部的序列号

        Index (int): 要修改的OSPFv2 update Lsa头部在流量模板中所有OSPFv2 update Lsa头部的序列号

    Keyword Args:

        LsaAge (int): LSA Age，默认值：0，取值范围：0-65535

        Reserved7 (bit): Reserved Bit 7，默认值：0，取值范围：0-1

        Reserved6 (bit): Reserved Bit 6，默认值：0，取值范围：0-1

        DcBit (bit): DC Bit，默认值：0，取值范围：0-1

        EaBit (bit): EA Bit，默认值：0，取值范围：0-1

        NpBit (bit): NP Bit，默认值：0，取值范围：0-1

        McBit (bit): MC Bit，默认值：0，取值范围：0-1

        EBit (bit): E Bit，默认值：0，取值范围：0-1

        Reserved0 (bit): Reserved Bit 0，默认值：0，取值范围：0-1

        LsType (int): LS Type，默认值：1，取值范围：

            1: Router

            2: Network

            3: Summary

            4: Summary-ASBR

            5: AS-External Type-5

            7: AS-External Type-7

        LinkStateId (str): Link State ID，默认值：1.1.1.1，取值范围：ipv4地址

        AdvertisingRouter (str): Advertising Router，默认值：1.1.1.1，取值范围：ipv4地址

        LsSequenceNumber (hex): LS Sequence Number，默认值：80000001，取值范围：长度为4字节的十六进制数

        LsChecksum (hex): LS Checksum，默认值：0000，取值范围：0000-FFFF

        LsaLength (int): LSA Length，默认值：0，取值范围：0-65535

        Router LSA的参数:

            Reserved7Router (bit): Reserved Bit 7，默认值：0，取值范围：0-1

            Reserved6Router (bit): Reserved Bit 6，默认值：0，取值范围：0-1

            Reserved5Router (bit): Reserved Bit 5，默认值：0，取值范围：0-1

            Reserved4Router (bit): Reserved Bit 4，默认值：0，取值范围：0-1

            Reserved3Router (bit): Reserved Bit 3，默认值：0，取值范围：0-1

            VBitRouter (bit): V Bit，默认值：0，取值范围：0-1

            EBitRouter (bit): E Bit，默认值：0，取值范围：0-1

            BBitRouter (bit): B Bit，默认值：0，取值范围：0-1

            RouterLsaReserved1 (int): routerLsaReserved1，默认值：0，取值范围：0-255

            NumberOfLinks (int): Number of Router Links，默认值：0，取值范围：0-65535

            RouterLsaLinkCount (int): 要插入的Router LSA Link数量，默认值：0，取值范围：0-1024

        Network LSA的参数:

            NetworkMask (str): Network Mask，默认值：255.255.255.0，取值范围：ipv4地址

            AttachedRoute1 (str): Attached Router1 ID，默认值：1.1.1.1，取值范围：ipv4地址

            AttachedRouteCount (int): Attached Routers数量，默认值：0，取值范围：0-1024

        Summary LSA / Summary Asbr的参数:

            NetworkMask (str): Attached Router1 ID，默认值：255.255.255.0，取值范围：ipv4地址

            LsaReserved1 (int): Reserved，默认值：0，取值范围：0-255

            LsaMetric (int): Metric，默认值：0，取值范围：0-16777215

            TosMetricsCount (int): Additional Metrics数量，默认值：0，取值范围：0-1024

        External LSA的参数:

            NetworkMask (str): Attached Router1 ID，默认值：255.255.255.0，取值范围：ipv4地址

            ExternalOptionsEBit (bit): E Bit，默认值：0，取值范围：0-1

            ExternalOptionsReserved (bit): Reserved，默认值：0，取值范围：0-15

            ExternalRouteMetric (int): External LSA Route Metric，默认值：0，取值范围：0-16777215

            ForwardingAddress (str): Forwarding Address，默认值：1.1.1.1，取值范围：ipv4地址

            ExternalRouteTag (int): External Route Tag，默认值：0，取值范围：0-4294967295

            TosMetricsCount (int): Additional Metrics数量，默认值：0，取值范围：0-1024

    Returns:

        dict: eg::

            {
                'RouterLsaReserved1': 'updatedLsas.ospfv2Lsa_0.ospfv2RouterLsa.routerLsaReserved1',
                'LsaAge': 'updatedLsas.ospfv2Lsa_0.ospfv2RouterLsa.lsaHeader.lsaAge',
                'Reserved7': 'updatedLsas.ospfv2Lsa_0.ospfv2RouterLsa.lsaHeader.lsaHdrOptions.reserved7',
                'Reserved7Router': 'updatedLsas.ospfv2Lsa_0.ospfv2RouterLsa.routerLsaOptions.reserved7'
             }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Ospfv2LinkStateAcknowledge |
            | ${LsaHeaders} | Create List | Router | Network | Summary | SummaryAsbr | AsExternal |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Update | Stream=${Stream} | Level=0 | AreaID=2.2.2.2 | LsaHeaders=${LsaHeaders} |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=0 | Type=Router | RouterLsaReserved1=1 |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=1 | Type=Network | NetworkMask=255.255.0.0 |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=2 | Type=Summary | LsaReserved1=1 |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=3 | Type=SummaryAsbr | LsaMetric=1 |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=4 | Type=AsExternal | ExternalOptionsEBit=1 |

    """

    result = renix.edit_header_ospfv2_update_lsa(Stream=Stream, Type=Type, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_update_route_lsa_link(Stream, Level=0, LsaIndex=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Update报文中Route Lsa头部Link内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 update头部在流量模板中所有OSPFv2 update头部的序列号

        LsaIndex (int): 要修改的OSPFv2 update Lsa头部在流量模板中所有OSPFv2 update Lsa头部的序列号

        Index (int): 要修改的OSPFv2 update Route Lsa Link头部在流量模板中所有OSPFv2 update Route Lsa Link头部的序列号

    Keyword Args:

        LinkId (str): Router LSA Link ID，默认值：1.1.1.1，取值范围：ipv4地址

        LinkData (int): Router LSA Link Data，默认值：0.0.0.0，取值范围：ipv4地址

        RouterLsaLinkType (int): Link Type，默认值：1，取值范围：

            1: Point-to-Point

            2: Transit

            3: Stub

            4: Virtual

        NumRouterLsaTosMetrics (int): Number of TOS Metrics，默认值：0，取值范围：0-255

        RouterLinkMetrics (int): Router Link Metric，默认值：0，取值范围：0-65535

        RouterLsaTosMetricsCount (int): Router LSA Link Metric数量，默认值：0，取值范围：0-1024

    Returns:

        dict: eg::

            {
                'LinkId': 'updatedLsas.ospfv2Lsa_0.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_0.linkId'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Ospfv2LinkStateAcknowledge |
            | ${LsaHeaders} | Create List | Router | Network | Summary | SummaryAsbr | AsExternal |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Update | Stream=${Stream} | Level=0 | AreaID=2.2.2.2 | LsaHeaders=${LsaHeaders} |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=0 | Type=Router | RouterLsaLinkCount=2 |
            | Edit Header Ospfv2 Update Route Lsa Link | Stream=${Stream} | Level=0 | LsaIndex=0 | Index=0 | LinkId=2.2.2.2 |
    """

    result = renix.edit_header_ospfv2_update_routelsalink(Stream, Level=Level, LsaIndex=LsaIndex, Index=Index,
                                                          **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_update_route_link_tos_metric(Stream, Level=0, LsaIndex=0, MetricIndex=0, Index=0,
                                                 **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Update报文中Route Lsa头部Link内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 update头部在流量模板中所有OSPFv2 update头部的序列号

        LsaIndex (int): 要修改的OSPFv2 update Lsa头部在流量模板中所有OSPFv2 update Lsa头部的序列号

        MetricIndex (int): 要修改的OSPFv2 update Route Lsa Link头部在流量模板中所有OSPFv2 update Route Lsa Link头部的序列号

        Index (int): 要修改的OSPFv2 update Route Lsa Link Tos Metric头部在流量模板中所有OSPFv2 update Route Lsa Link Tos Metric头部的序列号

    Keyword Args:

        RouterLsaLinkType (int): Link Type，默认值：1，取值范围：

            1: Point-to-Point

            2: Transit

            3: Stub

            4: Virtual

        RouterLsaMetricReserved (int): Reserved，默认值：0，取值范围：0-255

        RouterTosLinkMetrics (int): Router TOS Link Metric，默认值：0，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'RouterLsaMetricReserved': 'updatedLsas.ospfv2Lsa_0.ospfv2RouterLsa.routerLsaLinks.ospfv2RouterLsaLink_0.routerLsaTosMetrics.ospfv2RouterLsaTosMetric_0.routerLsaMetricReserved'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Ospfv2LinkStateAcknowledge |
            | ${LsaHeaders} | Create List | Router | Network | Summary | SummaryAsbr | AsExternal |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Update | Stream=${Stream} | Level=0 | AreaID=2.2.2.2 | LsaHeaders=${LsaHeaders} |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=0 | Type=Router | RouterLsaLinkCount=2 |
            | Edit Header Ospfv2 Update Route Lsa Link | Stream=${Stream} | Level=0 | LsaIndex=0 | Index=0 | RouterLsaTosMetricsCount=2 |
            | Edit Header Ospfv2 Update Route Link Tos Metric | Stream=${Stream} | Level=0 | LsaIndex=0 | MetricIndex=0 | Index=0 | RouterLsaMetricReserved=1 |
    """

    result = renix.edit_header_ospfv2_update_routelinktosmetric(Stream, Level=Level, LsaIndex=LsaIndex,
                                                                MetricIndex=MetricIndex, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_update_network_attached_route(Stream, Level=0, LsaIndex=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Update报文中Network Lsa头部Attached Route内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的OSPFv2 update头部在流量模板中所有OSPFv2 update头部的序列号

        LsaIndex (int): 要修改的OSPFv2 update Lsa头部在流量模板中所有OSPFv2 update Lsa头部的序列号

        Index (int): 要修改的OSPFv2 update Network Lsa Attached Route头部在流量模板中所有Network Lsa Attached Route头部的序列号

    Keyword Args:

        RouterID (str): Router ID，默认值：1.1.1.1，取值范围：ipv4地址

    Returns:

        dict: eg::

            {
                'RouterID': 'updatedLsas.ospfv2Lsa_1.ospfv2NetworkLsa.attachedRouters.ospfv2AttachedRouter_0.routerID'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Ospfv2LinkStateAcknowledge |
            | ${LsaHeaders} | Create List | Router | Network | Summary | SummaryAsbr | AsExternal |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Update | Stream=${Stream} | Level=0 | AreaID=2.2.2.2 | LsaHeaders=${LsaHeaders} |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=1 | Type=Network | AttachedRouteCount=2 |
            | Edit Header Ospfv2 Update Network Attached Route | Stream=${Stream} | Level=0 | LsaIndex=1 | Index=0 | RouterID=2.2.2.2 |
    """

    result = renix.edit_header_ospfv2_update_networkattachedroute(Stream, Level=Level, LsaIndex=LsaIndex,
                                                                 Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ospfv2_update_tos_metric(Stream, Type, Level=0, LsaIndex=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中OSPFv2 Update报文中Summary、 SummaryAsbr或AsExternal Lsa头部Tos Metric内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Type (str): OSPFv2 Update报文中Lsa类型，支持:

            Summary

            SummaryAsbr

            AsExternal

        Level (int): 要修改的OSPFv2 update头部在流量模板中所有OSPFv2 update头部的序列号

        LsaIndex (int): 要修改的OSPFv2 update Lsa头部在流量模板中所有OSPFv2 update Lsa头部的序列号

        Index (int): 要修改的Summary、 SummaryAsbr或AsExternal Lsa头部在流量模板中所有Summary、 SummaryAsbr或AsExternal Lsa头部的序列号

    Keyword Args:

        Summary或SummaryAsbr,支持Args:

            MetricReserved (int): Reserved，默认值：0，取值范围：0-255

            LinkMetrics (int): Link Metric，默认值：0，取值范围：0-16777215

        AsExternal,支持Args:

            EBit (bit): E Bit，默认值：0，取值范围：0-1

            RouteTos (int): Route Type of Service，默认值：0，取值范围：0-127

            RouteMetrics (int): Route Metric，默认值：0，取值范围：0-16777215

            ForwardingAddress (str): Forwarding Address，默认值：1.1.1.1，取值范围：ipv4地址

            RouteTag (int): Route Tag，默认值：0，取值范围：0-4294967295

    Returns:

        dict: eg::

            {
                'MetricReserved': 'updatedLsas.ospfv2Lsa_2.ospfv2SummaryLsa.summaryAdditionalMetrics.ospfv2SummaryLsaTosMetric_0.summaryLsaMetricReserved'}
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | Ospfv2LinkStateAcknowledge |
            | ${LsaHeaders} | Create List | Router | Network | Summary | SummaryAsbr | AsExternal |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Update | Stream=${Stream} | Level=0 | AreaID=2.2.2.2 | LsaHeaders=${LsaHeaders} |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=2 | Type=Summary | TosMetricsCount=2 |
            | Edit Header Ospfv2 Update Tos Metric | Stream=${Stream} | Type=Summary | Level=0 | LsaIndex=2 | Index=0 | MetricReserved=1 |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=3 | Type=SummaryAsbr | TosMetricsCount=2 |
            | Edit Header Ospfv2 Update Tos Metric | Stream=${Stream} | Type=SummaryAsbr | Level=0 | LsaIndex=3 | Index=0 | MetricReserved=1 |
            | Edit Header Ospfv2 Update Lsa | Stream=${Stream} | Level=0 | Index=4 | Type=AsExternal | TosMetricsCount=2 |
            | Edit Header Ospfv2 Update Tos Metric | Stream=${Stream} | Type=AsExternal | Level=0 | LsaIndex=4 | Index=0 | EBit=1 |
    """

    result = renix.edit_header_ospfv2_update_tosmetric(Stream, Type, Level=Level, LsaIndex=LsaIndex, Index=Index,
                                                       **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

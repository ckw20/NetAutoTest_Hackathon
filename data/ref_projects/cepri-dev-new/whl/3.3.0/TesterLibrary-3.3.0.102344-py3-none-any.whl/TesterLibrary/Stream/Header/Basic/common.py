import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_custom(Stream, Level=0, Index=None, **kwargs):
    """
    修改测试仪表流量模板中Custom报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Custom头部在流量模板中所有Custom头部的序列号, 默认值: 0, 范围: 0-65535

        Index (int): Custom头部在中需要修改pattern位于所有PatternByte和Checksum的序号，默认值: 空, 范围: 0-2

    Keyword Args:

        Pattern (list): Option Pattern, 默认值：00，列表元素取值范围：长度1-16384字节的十六进制数

        Checksum (str): Option Checksum, 默认值：0000，取值范围：0000-FFFF or AUTO

    Returns:

        dict: eg::

            {
                'Pattern': 'patternByte.customOption_0.customPatternByteOption.patternByteOption',
                'Checksum': 'patternByte.customOption_1.customChecksumOption.checksumOption'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Init Tester |
        | ${Locations} | Create List | //192.168.0.180/1/1 | //192.168.0.180/1/2 |
        | ${Port} | reserve_port | Locations=${Locations} |
        | ${HeaderTypes} | Create List | EthernetII | IPv4 | Custom |
        | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
        | edit_header_custom | Stream=${Stream} | Pattern=1212121212 |
        | edit_header_custom | Stream=${Stream} | Checksum=Auto |
        | edit_header_custom | Stream=${Stream} | Pattern=343434343 |Checksum=Auto |
        | edit_header_custom | Stream=${Stream} | Index=0 |Pattern=565656565 |
        | &{Attribute} | edit_header_custom | Stream=${Stream} | Index=2 |Pattern=787878787 |
        | Edit Modifier | Stream=${Stream} | Level=0 | HeaderType=Custom | Attribute=${Attribute}[Pattern] | Type=Increment | Count=10 | Step=2 |
    """

    result = renix.edit_header_custom(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

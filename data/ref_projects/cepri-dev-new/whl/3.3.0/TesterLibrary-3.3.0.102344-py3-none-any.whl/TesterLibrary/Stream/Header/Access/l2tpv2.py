import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_l2tpv2_data(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2tpv2 Data报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的L2tpv2 Data头部在流量模板中所有L2tpv2 Data头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Type (bit): Type, 默认值：1，取值范围：0-1

        UseLength (bit): UseLength, 默认值：1，取值范围：0-1

        Reserved1 (bit): Reserved, 默认值：00，取值范围：00-11

        UseSequence (bit): UseSequence, 默认值：1，取值范围：0-1

        Reserved2 (bit): Reserved, 默认值：0，取值范围：0-1

        UseOffset (bit): UseOffset, 默认值：0，取值范围：0-1

        UsePriority (bit): UsePriority, 默认值：0，取值范围：0-1

        Reserved3 (bit): Reserved, 默认值：0000，取值范围：0000-1111

        Version (int): Version, 默认值：2，取值范围：0-15

        LengthOption (int): Length, 默认值：0，取值范围：0-65535

        TunnelId (int): Tunnel ID, 默认值：0，取值范围：0-65535

        SessionId (int): Session ID, 默认值：0，取值范围：0-65535

        SeqNum (int): Message Sequence Number节点个数, 默认值：0，取值范围：0-1

        OffsetPadding (int): Offset Padding节点个数, 默认值：0，取值范围：0-1

    Returns:

        dict: eg::

            {
                'Type': 'type'
                'UseLength': 'useLength'
                'Reserved1': 'reserved1'
                'UseSequence': 'useSequence'
                'Reserved2': 'reserved2'
                'UseOffset': 'useOffset'
                'UsePriority': 'usePriority'
                'Reserved3': 'reserved3'
                'Version': 'version'
                'LengthOption': 'lengthOption.length_0.value'
                'TunnelId': 'tunnelId'
                'SessionId': 'sessionId'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header L2tpv2 Data | Stream=${Stream} | Level=0 | TunnelId=1000 |
    """

    result = renix.edit_header_l2tpv2_data(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_l2tpv2_data_option(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv2 Data报文中Option头部内容.

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的L2TPv2 Control头部在流量模板中所有L2TPv2 Control头部的序列号

    Keyword Args:

        Size (int): Offset Padding Size, 默认值：<AUTO>0, 取值范围：0-65535

        Value (hex): Offset Padding Value, 默认值："", 取值范围：长度0-1500字节十六进制数

        Ns (int): Sequence Number Ns Value, 默认值：0, 取值范围：0-65535

        Nr (int): Sequence Number Nr Value, 默认值：0, 取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Size': 'type'
                'Value': 'useLength'
                'Ns': 'reserved1'
                'Nr': 'useSequence'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | l2tpv2Data |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv2 Data | Stream=${Stream} | Level=0 | UsePriority=1 |
            | Edit Header L2tpv2 Data Option | Stream=${Stream} | Level=0 | size=1 | value=FF | ns=1 | nr=2 |
    """

    result = renix.edit_header_l2tpv2_data_option(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_l2tpv2_control(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv2 Control报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的L2TPv2 Control头部在流量模板中所有L2TPv2 Control头部的序列号

    Keyword Args:

        Type (bit): Type, 默认值：1，取值范围：0-1

        UseLength (bit): UseLength, 默认值：1，取值范围：0-1

        Reserved1 (bit): Reserved, 默认值：00，取值范围：00-11

        UseSequence (bit): UseSequence, 默认值：1，取值范围：0-1

        Reserved2 (bit): Reserved, 默认值：0，取值范围：0-1

        UseOffset (bit): UseOffset, 默认值：0，取值范围：0-1

        UsePriority (bit): UsePriority, 默认值：0，取值范围：0-1

        Reserved3 (bit): Reserved, 默认值：0000，取值范围：0000-1111

        Version (int): Version, 默认值：2，取值范围：0-15

        Length (int): Length, 默认值：0，取值范围：0-65535

        TunnelId (int): Tunnel ID, 默认值：0，取值范围：0-65535

        SessionId (int): Session ID, 默认值：0，取值范围：0-65535

        Ns (int): Ns Value, 默认值：0，取值范围：0-65535

        Nr (int): Nr Value, 默认值：0，取值范围：0-65535

        OptionHeaders (list): 支持的参数有：

            generalTLV

            messageType

            resultCode

            protocolVersion

            framingCapabilities

            bearerCapabilities

            tieBreaker

            firmwareRevision

            assignedTunnelId

            receiveWindowSize

            assignedSessionId

            response

            callSerialNumber

            minimumBps

            maximumBps

            bearerType

            framingType

            txConnectSpeed

            rxConnectSpeed

            physicalChannelId

            proxyAuthenType

            proxyAuthenId

    Returns:

        dict: eg::

            {
                'Type': 'type'
                'UseLength': 'useLength'
                'Reserved1': 'reserved1'
                'UseSequence': 'useSequence'
                'Reserved2': 'reserved2'
                'UseOffset': 'useOffset'
                'UsePriority': 'usePriority'
                'Reserved3': 'reserved3'
                'Version': 'version'
                'Length': 'length'
                'TunnelId': 'tunnelId'
                'SessionId': 'sessionId'
                'Ns': 'ns'
                'Nr': 'nr'
                'OptionHeaders': True
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | l2tpv2Control |
            | ${OptionHeaders} | Create List | generalTLV | messageType | resultCode | protocolVersion |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv2 Control | Stream=${Stream} | Level=0 | UsePriority=1 | OptionHeaders=${OptionHeaders} |
    """

    result = renix.edit_header_l2tpv2_control(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_l2tpv2_control_option(Stream, Types, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv2 Control报文中Option头部内容.

    Args:
        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Types (str): L2PTv2 Control报文option类型支持：

            GeneralTLV

            MessageType

            ResultCode

            ProtocolVersion

            FramingCapabilities

            BearerCapabilities

            TieBreaker

            FirmwareRevision

            AssignedTunnelId

            ReceiveWindowSize

            AssignedSessionId

            Response

            CallSerialNumber

            MinimumBps

            MaximumBps

            BearerType

            FramingType

            TxConnectSpeed

            RxConnectSpeed

            PhysicalChannelId

            ProxyAuthenType

            ProxyAuthenId

        Level (int): 要修改的L2TPv2 Control头部在流量模板中所有L2TPv2 Control头部的序列号

        Index (int): 要修改的L2TPv2 Control Option头部在流量模板中所有L2TPv2 Control Option头部的序列号

    Keyword Args:

        GeneralTLV支持：

            Mbit (bit): M Bit, 默认值：0，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：13，取值范围：0-65535

            AttributeValue (hex): Attribute Value, 默认值：00000000000000000000000000000000，取值范围：长度0-1017字节的十六进制数

        MessageType支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：0，取值范围：0-65535

            messageType (int): Message Type, 默认值：1，取值范围：0-65535

        ResultCode支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：0，取值范围：0-65535

            ResultCode (int): Result Code, 默认值：0，取值范围：0-65535

            ErrorCode (int): Error Code, 默认值：0，取值范围：0-65535

            ErrorMessage (hex): Error Message, 默认值：""，取值范围：长度0-1017字节的十六进制数

        ProtocolVersion支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：2，取值范围：0-65535

            Ver (int): ver, 默认值：1，取值范围：0-255

            Rev (int): rev, 默认值：0，取值范围：0-255

        FramingCapabilities支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：3，取值范围：0-65535

            Reserved1 (int): Reserved, 默认值：0，取值范围：0-1073741823

            Abit (bit): A, 默认值：0，取值范围：0-1

            Sbit (bit): S, 默认值：0，取值范围：0-1

        BearerCapabilities支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：4，取值范围：0-65535

            Reserved1 (int): Reserved, 默认值：0，取值范围：0-1073741823

            Abit (bit): A, 默认值：0，取值范围：0-1

            Dbit (bit): D, 默认值：0，取值范围：0-1

        TieBreaker支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：5，取值范围：0-65535

            tieBreakerValue (hex): Tie Breaker Value, 默认值：0000000000000000，取值范围：长度0-8字节的十六进制数

        FirmwareRevision支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：6，取值范围：0-65535

            firmwareRevision (int): Firmware Revision, 默认值：0，取值范围：0-65535

        AssignedTunnelId支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：9，取值范围：0-65535

            tunnelId (int): Assigned Tunnel ID, 默认值：0，取值范围：0-65535

        ReceiveWindowSize支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：10，取值范围：0-65535

            WindowSize (int): Window Size, 默认值：0，取值范围：0-65535

        AssignedSessionId支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：13，取值范围：0-65535

            sessionId (int): Assigned Session ID, 默认值：0，取值范围：0-65535

        Response支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：13，取值范围：0-65535

            responseValue (hex): Response Value, 默认值：00000000000000000000000000000000，取值范围：长度0-16字节的十六进制数

        CallSerialNumber支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：15，取值范围：0-65535

            callSerialNumber (int): Call Serial Number, 默认值：0，取值范围：0-4294967295

        MinimumBps支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：16，取值范围：0-65535

            MinimumBps (int): Minimum BPS, 默认值：0，取值范围：0-65535

        MaximumBps支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：17，取值范围：0-65535

            MaximumBps (int): Maximum BPS, 默认值：0，取值范围：0-4294967295

        BearerType支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：18，取值范围：0-65535

            Reserved1 (int): Reserved, 默认值：0，取值范围：0-1073741823

            Abit (bit): A, 默认值：0，取值范围：0-1

            Dbit (bit): D, 默认值：0，取值范围：0-1

        FramingType支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：19，取值范围：0-65535

            Reserved1 (int): Reserved, 默认值：0，取值范围：0-1073741823

            Abit (bit): A, 默认值：0，取值范围：0-1

            Sbit (bit): S, 默认值：0，取值范围：0-1

        TxConnectSpeed支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：15，取值范围：0-65535

            Bps (int): BPS, 默认值：0，取值范围：0-4294967295

        RxConnectSpeed支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：38，取值范围：0-65535

            HighBPS (int): BPS(H), 默认值：0，取值范围：0-65535

            LowBPS (int): BPS(L), 默认值：0，取值范围：0-65535

        PhysicalChannelId支持：

            Mbit (bit): M Bit, 默认值：0，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：25，取值范围：0-65535

            PhysicalChannelId (int): Physical Channel ID, 默认值：0，取值范围：0-4294967295

        ProxyAuthenType支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：29，取值范围：0-65535

            AuthenType (int): Authen Type, 默认值：0，取值范围：0-65535

        ProxyAuthenId支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：29，取值范围：0-65535

            Reserved1 (int): Reserved, 默认值：0，取值范围：0-255

            AuthenId (int): Authen ID, 默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'Mbit': 'type'
                'Hbit': 'useLength'
                'Reserved': 'reserved1'
                'Length': 'useSequence'
                'VendorId':
                'Type':
                'Reserved1':
                'AuthenId':
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | l2tpv2Control |
            | ${LsaHeaders} | Create List | generalTLV | messageType | resultCode | protocolVersion | FramingCapabilities |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv2 Control | Stream=${Stream} | Level=0 | UsePriority=1 | OptionHeaders=${OptionHeaders} |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=0 | Types=MessageType | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=1 | Types=ResultCode | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=2 | Types=ProtocolVersion | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=3 | Types=FramingCapabilities | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=4 | Types=BearerCapabilities | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=5 | Types=TieBreaker | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=6 | Types=FirmwareRevision | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=7 | Types=AssignedTunnelId | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=8 | Types=ReceiveWindowSize | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=9 | Types=AssignedSessionId | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=10 | Types=Response | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=11 | Types=CallSerialNumber | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=12 | Types=MinimumBps | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=13 | Types=MaximumBps | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=14 | Types=BearerType | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=15 | Types=FramingType | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=16 | Types=TxConnectSpeed | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=17 | Types=RxConnectSpeed | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=18 | Types=PhysicalChannelId | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=19 | Types=ProxyAuthenType | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=20 | Types=ProxyAuthenId | Mbit=1 |
    """

    result = renix.edit_header_l2tpv2_control_option(Stream=Stream, Types=Types, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Header Routing Rip-------------------------------------
def edit_header_ripng(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Ripng报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripng头部在流量模板中所有Ripng头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Command (int): Command，默认值：1，取值范围：1-2

        Version (int): Version，默认值：2，取值范围：0-255

        Reserved (int): Reserved，默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.edit_header_ripng(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def insert_ripng_entries(Stream, Level=0, Count=1):
    """
    修改测试仪表流量模板中Ripng报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripng头部在流量模板中所有Ripng头部的序列号, 默认值: 0, 范围: 0-65535

        Count (int): 插入entry头部数量

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.insert_ripng_entries(Stream=Stream, Level=Level, Count=Count)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ripng_entry(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Ripng报文头部中Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripng头部在流量模板中所有Ripng头部的序列号, 默认值: 0, 范围: 0-65535

        Index (int): 要修改的Ripng头部Entry在Ripng头部中的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Ipaddr (str): 地址

        RouteTag (int):

        PrefixLen (int):

        Metric (int):

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.edit_header_ripng_entry(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ripv1(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Ripv1报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripv1头部在流量模板中所有Ripv1头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Command (int): Command，默认值：1，取值范围：1-2

        Version (int): Version，默认值：2，取值范围：0-255

        Reserved (int): Reserved，默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.edit_header_ripv1(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def insert_ripv1_entries(Stream, Level=0, Count=1):
    """
    插入测试仪表流量模板中Ripv1报文头部Entry

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripv1头部在流量模板中所有Ripv1头部的序列号, 默认值: 0, 范围: 0-65535

        Count (int): 插入entry头部数量

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.insert_ripv1_entries(Stream=Stream, Level=Level, Count=Count)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ripv1_entry(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Ripv1报文头部中Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripng头部在流量模板中所有Ripv1头部的序列号, 默认值: 0, 范围: 0-65535

        Index (int): 要修改的Ripv1头部Entry在Ripv1头部中的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Afi (int):

        Reserved (int):

        Ipaddr (str): 地址

        Reserved1 (int):

        Reserved (int):

        Metric (int):

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.edit_header_ripv1_entry(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ripv2(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Ripv2报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripv1头部在流量模板中所有Ripv2头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Command (int): Command，默认值：1，取值范围：1-2

        Version (int): Version，默认值：2，取值范围：0-255

        Reserved (int): Reserved，默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.edit_header_ripv2(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def insert_ripv2_entries(Stream, Level=0, Count=1):
    """
    插入测试仪表流量模板中Ripv2报文头部Entry

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripv2头部在流量模板中所有Ripv2头部的序列号, 默认值: 0, 范围: 0-65535

        Count (int): 插入entry头部数量

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.insert_ripv2_entries(Stream=Stream, Level=Level, Count=Count)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ripv2_entry(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Ripv1报文头部中Entry内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Ripng头部在流量模板中所有Ripv1头部的序列号, 默认值: 0, 范围: 0-65535

        Index (int): 要修改的Ripv2头部Entry在Ripv2头部中的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Afi (int):

        Reserved (int):

        Ipaddr (str): 地址

        Reserved1 (int):

        Reserved (int):

        Metric (int):

    Returns:

        dict: eg::

            {
                'Command': 'ospfHeader.routerID',
                'NetworkMask': 'networkMask',
                'Neighbors: 1.1.1.1': 'neighbors.ospfv2Neighbor_0.neighborID',
                'Neighbors: 2.2.2.2': 'neighbors.ospfv2Neighbor_1.neighborID'
            }


    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | OSPFv2Hello |
            | ${Neighbors} | Create List | 2.2.2.2 | 3.3.3.3 | 4.4.4.4 |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Ospfv2 Hello | Stream=${Stream} | Level=0 | AuthType=2 | Neighbors=${Neighbors} |
    """

    result = renix.edit_header_ripv2_entry(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

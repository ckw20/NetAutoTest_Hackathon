import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_ethernet(Stream, Level=0, DestMacAdd=None, SourceMacAdd=None, ProtocolType=None):
    """
    修改测试仪表流量模板中Ethernet报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0-65535

        DestMacAdd (str): 目的mac地址，默认值：00:00:00:13:40:20，取值范围：有效的mac地址

        SourceMacAdd (str): 源mac地址，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        ProtocolType (hex): 上层协议类型，默认值：88B5，取值范围：

            0800：IPv4

            0806：ARP

            8100：VLAN

            8863：PPPoE Discovery

            8864：PPPoE

            86DD：IPv6

            8808：Pause

            8847：MPLS

            8926：VNTag

            8914：FIP

            8906：FCoE

            88CC：Chassis ID TLV

            88B8：Goose

    Returns：

        dict: eg::

            {
                'DestMacAdd': 'destMacAdd',
                'SourceMacAdd': 'sourceMacAdd',
                'ProtocolType': 'protocolType'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Init Tester |
        | ${Locations} | Create List | //192.168.0.180/1/1 | //192.168.0.180/1/2 |
        | ${Port} | reserve_port | Locations=${Locations} |
        | ${Stream} | add_stream | Port=${Port[0]} |
        | ${HeaderTypes} | Create List | EthernetII | IPv4 |
        | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
        | &{Attribute} | Edit Header Ethernet | Stream=${Stream} | Level=0 | DestMacAdd=00:01:01:01:01:02 |
        | Edit Modifier | Stream=${Stream} | Level=0 | HeaderType=EthernetII | Attribute=${Attribute}[DestMacAdd] | Type=Increment | Count=10 | Step=2 |
        | ${Pattern} | Create Capture Pdu Pattern | Port=${Port[1]} | HeaderTypes=${HeaderTypes} |  Level=0  | Attribute=${Attribute}[DestMacAdd] | Value=00:01:01:01:01:02 | MaxValue=00:01:01:01:01:02 |
        | Edit Capture Filter | Port=${Port} | Expression=${Pattern} |
    """

    result = renix.edit_header_ethernet(Stream=Stream, Level=Level, DestMacAdd=DestMacAdd,
                                        SourceMacAdd=SourceMacAdd, ProtocolType=ProtocolType)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_raw_8023(Stream, Level=0, DestMacAdd=None, SourceMacAdd=None, PayloadLength=None):
    """
    修改测试仪表流量模板中Ethernet Raw 802.3 报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0-65535

        DestMacAdd (str): 目的mac地址，默认值：00:00:00:13:40:20，取值范围：有效的mac地址

        SourceMacAdd (str): 源mac地址，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        PayloadLength (int): 默认值：AUTO

    Returns：

        dict: eg::

            {
                'DestMacAdd': 'destMacAdd',
                'SourceMacAdd': 'sourceMacAdd',
                'PayloadLength': 'length'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Init Tester |
        | ${Locations} | Create List | //192.168.0.180/1/1 | //192.168.0.180/1/2 |
        | ${Port} | reserve_port | Locations=${Locations} |
        | ${Stream} | add_stream | Port=${Port[0]} |
        | ${HeaderTypes} | Create List | EthernetII | IPv4 |
        | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
        | &{Attribute} | Edit Header Ethernet | Stream=${Stream} | Level=0 | DestMacAdd=00:01:01:01:01:02 |
        | Edit Modifier | Stream=${Stream} | Level=0 | HeaderType=EthernetII | Attribute=${Attribute}[DestMacAdd] | Type=Increment | Count=10 | Step=2 |
        | ${Pattern} | Create Capture Pdu Pattern | Port=${Port[1]} | HeaderTypes=${HeaderTypes} |  Level=0  | Attribute=${Attribute}[DestMacAdd] | Value=00:01:01:01:01:02 | MaxValue=00:01:01:01:01:02 |
        | Edit Capture Filter | Port=${Port} | Expression=${Pattern} |
    """

    result = renix.edit_header_raw_8023(Stream=Stream, Level=Level, DestMacAdd=DestMacAdd,
                                        SourceMacAdd=SourceMacAdd, PayloadLength=PayloadLength)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_8023(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Ethernet Raw 802.3 报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        DestMacAdd (str): 目的mac地址，默认值：00:00:00:13:40:20，取值范围：有效的mac地址

        SourceMacAdd (str): 源mac地址，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        PayloadLength (int): 默认值：<AUTO>46，取值范围：0-65535

        Dsap (hex): LLC dsap，默认值：AA，取值范围：00-FF

        Ssap (hex): LLC ssap，默认值：AA，取值范围：00-FF

        Control (hex): LLC Control，默认值：03，取值范围：00-FF

        Oui (hex): Organization Code，默认值：000000，取值范围：长度为3字节的十六进制数

        Type (hex): Protocol Type，默认值：FFFF，取值范围：长度为2字节的十六进制数

    Returns：

        dict: eg::

            {
                'DestMacAdd': 'destMacAdd',
                'SourceMacAdd': 'sourceMacAdd',
                'PayloadLength': 'length',
                'Dsap': "llcHeaderIns.dsap",
                'Ssap': "llcHeaderIns.ssap",
                'Control': "llcHeaderIns.control",
                'Oui': "snapIns.oui",
                'Type': "snapIns.type"
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Header 8023 | Stream=${Stream} | Level=0 | DestMacAdd=00:01:01:01:01:02 |
    """

    result = renix.edit_header_8023(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_llc(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中LLC Header报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Dsap (hex): LLC DSAP，默认值：AA，取值范围：00-FF

        Ssap (hex): LLC SSAP，默认值：AA，取值范围：00-FF

        Control (int): LLC Control, 默认值：03，取值范围：00-FF

    Returns：

        dict: eg::

            {
                'Dsap': "dsap",
                'Ssap': "ssap",
                'Control': "control"
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Header Llc | Stream=${Stream} | Level=0 | Dsap=FF |
    """

    result = renix.edit_header_llc(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_vlan(Stream, Level=0, ID=None, Priority=None, CFI=None, Protocol=None):
    """
    修改测试仪表流量模板中vlan报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0-65535

        Priority (int): vlan优先级，默认值：0，取值范围：0-7

        CFI (int): vlan cfi值，默认值：0，取值范围：0-1

        ID (int): vlan id，默认值：1，取值范围：1-4095

        Protocol (hex): 上层协议类型，默认值：88B5，取值范围：

            0800：IPv4

            0806：ARP

            8100：VLAN

            8863：PPPoE Discovery

            8864：PPPoE

            86DD：IPv6

            8808：Pause

            8847：MPLS

            8926：VNTag

            8914：FIP

            8906：FCoE

            88CC：Chassis ID TLV

            88B8：Goose

    Returns:

        dict: eg::

            {
                'Priority': 'priority',
                'CFI': 'cfi',
                'ID': 'id',
                'Protocol': 'protocol'
            }


    Examples:
        robotframework:

    .. code:: robotframework

        | Init Tester |
        | ${Locations} | Create List | //192.168.0.180/1/1 | //192.168.0.180/1/2 |
        | ${Port} | reserve_port | Locations=${Locations} |
        | ${Stream} | add_stream | Port=${Port[0]} |
        | ${HeaderTypes} | Create List | EthernetII | VLAN |
        | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
        | &{Attribute} | Edit Header Vlan | Stream=${Stream} | Level=0 | ID=4000 |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[ID] | Type=Increment | Count=10 | Step=2 |
        | ${Pattern} | Create Capture Pdu Pattern | Port=${Port[1]} | HeaderTypes=${HeaderTypes} |  Level=1  | Attribute=${Attribute}[ID] | Value=4000 | MaxValue=4000 |
        | Edit Capture Filter | Port=${Port} | Expression=${Pattern} |
    """

    result = renix.edit_header_vlan(Stream=Stream, Level=Level, ID=ID, Priority=Priority, CFI=CFI, Protocol=Protocol)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_arp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中ARP报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        HardwareType (int): Hardware Type，默认值：1，取值范围：1-65535

        ProtocolType (hex): Protocol Type，默认值：0800，取值范围：0000-FFFF

        HardwareSize (int): Hardware address Size，默认值：6，取值范围：0-255

        ProtocolSize (int): Protocol address Size，默认值：4，取值范围：0-255

        Opcode (int): Opcode，默认值：1，取值范围：0-65535

        SendMac (str): Sender MAC address，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        SendIpv4 (str): Sender IP address，默认值：192.168.0.1，取值范围：有效的ipv4地址

        TargetMac (str): Target MAC address，默认值：00:00:00:00:00:00，取值范围：有效的mac地址

        TargetIpv4 (str): Target IP address，默认值：0.0.0.0，取值范围：有效的ipv4地址

    Returns:

         dict: eg::

            {
                'HardwareType': 'hardwareType',
                'ProtocolType': 'protocolType',
                'HardwareSize': 'hardwareSize',
                'ProtocolSize': 'protocolSize',
                'Opcode': 'opcode',
                'SendMac': 'sendMac',
                'SendIpv4': 'sendIpv4',
                'TargetMac': 'targetMac',
                'TargetIpv4': 'targetIpv4'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Init Tester |
        | ${Locations} | Create List | //192.168.0.180/1/1 | //192.168.0.180/1/2 |
        | ${Port} | reserve_port | Locations=${Locations} |
        | ${Stream} | add_stream | Port=${Port[0]} |
        | ${HeaderTypes} | Create List | EthernetII | ARP |
        | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
        | &{Attribute} | Edit Header Arp | Stream=${Stream} | Level=0 | SendMac=00:00:01:01:01:01 |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[SendMac] | Type=Increment | Count=10 | Step=2 |
        | ${Pattern} | Create Capture Pdu Pattern | Port=${Port[1]} | HeaderTypes=${HeaderTypes} |  Level=1  | Attribute=${Attribute}[SendMac] | Value=00:00:01:01:01:01 | MaxValue=00:00:01:01:01:01 |
        | Edit Capture Filter | Port=${Port} | Expression=${Pattern} |
    """

    result = renix.edit_header_arp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_mpls(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中MPLS报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的MPLS头部在流量模板中所有MPLS头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Label (int): Label，默认值：16，取值范围：0-1048575

        Exp (bit): Experimental Bits，默认值：000，取值范围：000-111

        Bottom (bit): Bottom Of Label Stack，默认值：0，取值范围：0-1

        TTL (int): TTL，默认值：64，取值范围：0-255

    Returns:

         dict: eg::

            {
                'Label': 'label',
                'Exp': 'exp',
                'Bottom': 'bottom',
                'TTL': 'ttl',
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Init Tester |
        | ${Locations} | Create List | //192.168.0.180/1/1 | //192.168.0.180/1/2 |
        | ${Port} | reserve_port | Locations=${Locations} |
        | ${Stream} | add_stream | Port=${Port[0]} |
        | ${HeaderTypes} | Create List | EthernetII | MPLS | IPv4 |
        | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
        | &{Attribute} | Edit Header MPLS | Stream=${Stream} | Level=0 | Label=1000 | TTL=100 |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[Label] | Type=Increment | Count=10 | Step=2 |
        | ${Pattern} | Create Capture Pdu Pattern | Port=${Port[1]} | HeaderTypes=${HeaderTypes} |  Level=1  | Attribute=${Attribute}[Label] | Value=1000 | MaxValue=1000 |
        | Edit Capture Filter | Port=${Port} | Expression=${Pattern} |
    """

    result = renix.edit_header_mpls(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def edit_header_goose(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Goose报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Goose头部在流量模板中所有Goose头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Appid (int): APPID，默认值：0，取值范围：0-65535

        Length (int): Length，默认值：<AUTO>8，取值范围：0-65535

        Reserve (int): Reserve，默认值：0，取值范围：0-65535

        Reserve1 (int): Reserve，默认值：0，取值范围：0-65535

        Apdu (hex): APDU，默认值：''，取值范围：长度为0-1493字节的十六进制数

    Returns:

         dict: eg::

            {
                'Appid': 'appid',
                'Length': 'length',
                'Reserve': 'reserve',
                'Reserve1': 'reserve1',
                'Apdu': 'apdu'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | &{Attribute} | Edit Header Goose | Stream=${Stream} | Level=0 | Appid=1000 |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[Appid] | Type=Increment | Count=10 | Step=2 |
    """

    result = renix.edit_header_goose(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_pause(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Pause报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pause头部在流量模板中所有Pause头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        PauseCode (hex): Pause Opcode，默认值：0001，取值范围：0000-FFFF

        PauseTime (hex): Pause Time，默认值：0000，取值范围：0000-FFFF

    Returns:

         dict: eg::

            {
                'PauseCode': 'pauseCode',
                'PauseTime': 'pauseTime',
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | &{Attribute} | Edit Header Pause | Stream=${Stream} | Level=0 | PauseCode=FFFF |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[PauseCode] | Type=Increment | Count=10 | Step=2 |
    """

    result = renix.edit_header_pause(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_pfc(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Pfc报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Pfc头部在流量模板中所有Pfc头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        OpCode (hex): OpCode，默认值：0101，取值范围：0000-FFFF

        MsOctet (bit): ms octet，默认值：00000000，取值范围：长度为8的二进制数

        P7 (bit): Priority 7，默认值：0，取值范围：0-1

        P6 (bit): Priority 6，默认值：0，取值范围：0-1

        P5 (bit): Priority 5，默认值：0，取值范围：0-1

        P4 (bit): Priority 4，默认值：0，取值范围：0-1

        P3 (bit): Priority 3，默认值：0，取值范围：0-1

        P2 (bit): Priority 2，默认值：0，取值范围：0-1

        P1 (bit): Priority 1，默认值：0，取值范围：0-1

        P0 (bit): Priority 0，默认值：0，取值范围：0-1

        Time0 (hex): Time0，默认值：0，取值范围：0-65535

        Time1 (hex): Time1，默认值：0，取值范围：0-65535

        Time2 (hex): Time2，默认值：0，取值范围：0-65535

        Time3 (hex): Time3，默认值：0，取值范围：0-65535

        Time4 (hex): Time4，默认值：0，取值范围：0-65535

        Time5 (hex): Time5，默认值：0，取值范围：0-65535

        Time6 (hex): Time6，默认值：0，取值范围：0-65535

        Time7 (hex): Time7，默认值：0，取值范围：0-65535

    Returns:

         dict: eg::

            {
                'OpCode': 'opCode',
                'MsOctet': 'priorityEnableVector.msOctet',
                'P7': 'priorityEnableVector.p7',
                'P6': 'priorityEnableVector.p6',
                'P5': 'priorityEnableVector.p5',
                'P4': 'priorityEnableVector.p4',
                'P3': 'priorityEnableVector.p3',
                'P2': 'priorityEnableVector.p2',
                'P1': 'priorityEnableVector.p1',
                'P0': 'priorityEnableVector.p0',
                'Time0': 'time0',
                'Time1': 'time1',
                'Time2': 'time2',
                'Time3': 'time3',
                'Time4': 'time4',
                'Time5': 'time5',
                'Time6': 'time6',
                'Time7': 'time7',
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | &{Attribute} | Edit Header Pfc | Stream=${Stream} | Level=0 | OpCode=FFFF |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[OpCode] | Type=Increment | Count=10 | Step=2 |
    """

    result = renix.edit_header_pfc(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_vntag(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Vntag报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Vntag头部在流量模板中所有Vntag头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Ver (bit): Version，默认值：00，取值范围：00-11

        Res (bit): Reserved，默认值：0，取值范围：0-1

        Dir (bit): Direction，默认值：0，取值范围：0-1

        Pointer (bit): Pointer，默认值：0，取值范围：0-1

        DstVif (int): Dst VIF，默认值：14，取值范围：0-1

        SrcVif (int): Src VIF，默认值：12，取值范围：0-1

        Looped (bit): Looped，默认值：0，取值范围：0-1

        Protocol (hex): protocol，默认值：FFFF，取值范围：

            0800: IPv4

            0806: ARP

            8100: VLAN

            8864: PPPoE

            8863: PPPoE Discovery

            86DD: IPv6

            8808: Pause

            8847: MPLS

            88B8: Goose

            8926: VNTag

    Returns:

         dict: eg::

            {
                'Ver': 'ver',
                'Res': 'res',
                'Dir': 'dir',
                'Pointer': 'pointer',
                'DstVif': 'dstVif',
                'SrcVif': 'srcVif',
                'Looped': 'looped',
                'Protocol': 'protocol'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | &{Attribute} | Edit Header Vntag | Stream=${Stream} | Level=0 | Ver=11 |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[Ver] | Type=Increment | Count=10 | Step=2 |
    """

    result = renix.edit_header_vntag(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_fibre_channel(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Fibre Channel报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Fibre Channel头部在流量模板中所有Fibre Channel头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Rctl (hex): R_CTL，默认值：22，取值范围：00-FF

        DestAddr (hex): Destination ID，默认值：000000，取值范围：长度为3字节的十六进制数

        Csctl (hex): CS_CTL，默认值：00，取值范围：00-FF

        SourceAddr (hex): Source ID，默认值：000000，取值范围：长度为3字节的十六进制数

        Type (hex): Type，默认值：<AUTO>01，取值范围：01

        FrameControl (hex): Frame Control，默认值：380000，取值范围：长度为3字节的十六进制数

        SeqID (hex): Sequence ID，默认值：00，取值范围：00-FF

        DataField (hex): Data Field Control，默认值：00，取值范围：00-FF

        SeqCount (hex): Sequence Count，默认值：0000，取值范围：0000-FFFF

        OriginatorExchangeID (hex): Originator Exchanger ID，默认值：0000，取值范围：0000-FFFF

        ResponseExchangeID (hex): Response Exchanger ID，默认值：0000，取值范围：0000-FFFF

        ParaRelativeOffset (hex): Parameters/Relative Offset，默认值：00000000，取值范围：长度为4字节的十六进制数

    Returns:

         dict: eg::

            {
                'Rctl': 'rctl',
                'DestAddr': 'destAddr',
                'Csctl': 'csctl',
                'SourceAddr': 'sourceAddr',
                'Type': 'type',
                'FrameControl': 'frameControl',
                'SeqID': 'seqID',
                'DataField': 'dataField',
                'SeqCount': 'seqCount',
                'OriginatorExchangeID': 'originatorExchangeID',
                'ResponseExchangeID': 'responseExchangeID',
                'ParaRelativeOffset': 'paraRelativeOffset'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | &{Attribute} | Edit Header Fibre Channel | Stream=${Stream} | Level=0 | Rctl=FF |
        | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=${Attribute}[Rctl] | Type=Increment | Count=10 | Step=2 |
    """

    result = renix.edit_header_fibre_channel(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

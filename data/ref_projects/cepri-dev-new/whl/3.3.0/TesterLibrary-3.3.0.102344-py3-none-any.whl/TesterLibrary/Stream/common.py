import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def add_stream(Type="raw",
               Ports=None,
               Names=None,
               FilePath=None,
               IncludeCrc=True,
               SrcPoints=None,
               DstPoints=None,
               SrcInterface=None,
               DstInterface=None,
               Bidirection=None,
               Direction=None,
               Layer=None,
               TrafficMeshMode=None,
               EndpointMapping=None,
               AutoCreateTunnel=False,
               StreamOnly=None,
               **kwargs
               ):
    """
    测试仪表创建流量

    Args:

        Type (str): 创建绑定流类型，支持raw流、binding流以及pcap文件导入流:

            raw

            binding

            pcap

        Ports (list (:obj:`Port`)): raw流和pcap流参数，端口对象, 测试仪表端口对象object列表

        Names (list): raw流参数，流量名称, 流量名称列表

        FilePath (str): pcap流参数，当Type为pcap需要指定导入pcap文件的路径

        IncludeCrc (bool): pcap流参数，当Type为pcap指定导入方式是否携带CRC, 布尔值Bool (范围：True / False)

        SrcInterface (list): binding流参数，指定源接口

        DstInterface (list): binding流参数，指定目的接口

        SrcPoints (list): binding流参数，指定源端点

        DstPoints (list): binding流参数，指定目的端点

        Bidirection (bool): 是否是能双向流量, 布尔值Bool (范围：True / False)

        Direction (str): binding流参数

        Layer (str): binding流参数，指定接口网络层，默认值：IPV4，支持值：

            ETHERNETII

            VLAN

            GRE

            IPV4

            IPV6

        TrafficMeshMode (str): binding流参数, 默认值：MANY_TO_MANY，支持值：

            ONE_TO_ONE

            MANY_TO_MANY

            FULL_MESH

            CONGESTION

            LEARNING

            BACK_BONE

            PAIR

        EndpointMapping (str): binding流参数, 默认值：ROUND_ROBIN，支持值：

            ROUND_ROBIN

            MANY_TO_MANY

        AutoCreateTunnel (bool): binding流参数, 自动绑定隧道, 默认值：False

        StreamOnly (bool): True为每个flow创建一个stream,  False为多个flow创建一个stream, 默认值：False

    Returns:

        list (:obj:`StreamTemplate`): 创建的流量对象object列表

    Examples:
        .. code:: RobotFramework

            # raw流
            | ${Streams} | add_stream | Port=${Port} |
            # pcap流
            | ${Streams} | add_stream | Type=pcap |  Port=${Port} |  FilePath=${Pcap_File_Path} | IncludeCrc=True |
            # binding流
            | ${Streams} | add_stream | Type=binding |  SrcPoints=${Points_1} | DstPoints=${Points_2} |  Bidirection=True |
    """

    result = renix.add_stream(Type=Type,
                              Ports=Ports,
                              Names=Names,
                              FilePath=FilePath,
                              IncludeCrc=IncludeCrc,
                              SrcPoints=SrcPoints,
                              DstPoints=DstPoints,
                              SrcInterface=SrcInterface,
                              DstInterface=DstInterface,
                              Bidirection=Bidirection,
                              Direction=Direction,
                              Layer=Layer,
                              TrafficMeshMode=TrafficMeshMode,
                              EndpointMapping=EndpointMapping,
                              AutoCreateTunnel=AutoCreateTunnel,
                              StreamOnly=StreamOnly,
                              **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_stream(Stream, **kwargs):
    """
    修改测试仪表流量模板参数

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

    Keyword Args:

        RepeatCount (int): 流模板发送重复次数，默认值：1，支持值：1-4294967295

        EnableSignature (bool): 启用签名，默认值：True

        FrameLengthType (str): 流模板帧长度类型 类型为：string，默认值：FIXED，支持值：

            FIXED

            INCREMENT

            RANDOM

            AUTO

            DECREMENT

            IMIX

        RandomLengthSeed (int): 随机种子, 类型为：number，默认值：10900842，支持值：0-4294967295

        FixedLength (int): 固定帧长, 默认值：128，支持值：12-16383

        MinLength (int): 最小帧长, 默认值：128，支持值：12-16383

        MaxLength (int): 最大帧长, 默认值：256，支持值：12-16383

        StepLength (int): 帧长跳变步长, 默认值：1，支持值：1-8192

        PayloadType (str): 净荷类型, 默认值：CYCLE，支持值：

            CYCLE

            INCREMENT

            RANDOM

        PayloadValue (str): 帧长跳变步长, 默认值：0x0

        PayloadValueType (str): 净荷类型, 默认值：CYCLE，支持值：

            SINGLE_BYTE

            DOUBLE_BYTE

        EnableNDResponse (bool): 使用ARP ND自动回复, 默认值：False

        TopLayerType (str): 流模板报文模板类型, 默认值：IPV4，支持值：

            ETHERNETII

            VLAN

            GRE

            IPV4

            IPV6

        RxPorts (list (:obj:`Port`)): 指定流量收端口

        TrafficMeshMode (str): binding流参数, 默认值：MANY_TO_MANY，支持值：

            ONE_TO_ONE

            MANY_TO_MANY

            FULL_MESH

            CONGESTION

            LEARNING

            BACK_BONE

            PAIR

        HostsMesh (str): binding流参数, 默认值：ROUND_ROBIN，支持值：

            ROUND_ROBIN

            MANY_TO_MANY

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Stream | Stream=${Stream} | TopLayerType=ETHERNETII | TrafficMeshMode=FULL_MESH |
    """

    result = renix.edit_stream(Stream=Stream, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_stream_header(Stream, HeaderTypes, Index=None):
    """
    创建流量报文头部

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Index (int): 报文头部创建在当前流量头部的序号, 类型为：number, 取值范围None或0-16383,当Index为None表示重新创建流量报文类型。绑定流需要指定该参数。

        HeaderTypes (list): 报文头部类型列表,类型为：list,支持的报文头部(不区分大小写):

            ethernetii: EthernetII Instance

            raw: Ethernet802.3 Raw Instance

            vlan: VLAN Instance

            vxlan: VXLAN Header Instance

            arp: ARP Instance

            gre: GRE Instance

            ipv4: IPv4 Instance

            ipv6: IPv6 Instance

            tcp: TCP Instancce

            udp: UDP Instance

            l2tpv2data: L2TPv2 Data Over UDP Instance

            l2tpv2control: L2TPv2 Control Over UDP Instance

            l2tpv3controloverip: L2TPv3 Control Over IP Instance

            l2tpv3controloverudp: L2TPv3 Control Over UDP Instance

            l2tpv3dataoverip: L2TPv3 Data Over IP Instance

            l2tpv3dataoverudp: L2TPv3 Data Over UDP Instance

            dhcpv4server

            dhcpv4client

            dhcpv6client

            dhcpv6server

            ppp: PPP Instance

            pppoe: PPPoE Instance

            pppoediscovery: PPPoE Discovery Instance

            icmpv4echorequest: ICMPv4 EchoRequest Instance

            destunreach: ICMPv4 DestUnreach Instance

            icmpv4echoreply: ICMPv4 EchoReply Instance

            informationreply: ICMPv4 InformationReply Instance

            informationrequest: ICMPv4 InformationRequest Instance

            icmpv4parameterproblem: ICMPv4 ParameterProblem Instance

            icmpv4redirect: ICMPv4 Redirect Instance

            sourcequench: ICMPv4 SourceQuench Instance

            timeexceeded: ICMPv4 TimeExceeded Instance

            timestampreply: ICMPv4 TimestampReply Instance

            timestamprequest: ICMPv4 TimestampRequest Instance

            icmpmaskrequest: ICMPv4 Address Mask Request Instance

            icmpmaskreply: ICMPv4 Address Mask Reply Instance

            destinationunreachable: ICMPv6 DestinationUnreachable Instance

            icmpv6echoreply: ICMPv6 EchoReply Instance

            icmpv6echorequest: ICMPv6 EchoRequest Instance

            packettoobig: ICMPv6 PacketTooBig Instance

            icmpv6parameterproblem: ICMPv6 ParameterProblem Instance

            timeexceed: ICMPv6 TimeExceed Instance

            routersolicit: Router Solicitation Instance

            routeradvertise: Router Advertisement Instance

            icmpv6redirect: Redirect Instance

            neighborsolicit: Neighbor Solicitation Instance

            neighboradvertise: Neighbor Advertisement Instance

            mldv1query: ICMPv6 MLDv1 Query Instance

            mldv1report: ICMPv6 MLDv1 Report Instance

            mldv1done: ICMPv6 MLDv1 Done Instance

            mldv2query: ICMPv6 MLDv2 Query Instance

            mldv2report: ICMPv6 MLDv2 Report Instance

            igmpv1: IGMPv1 Report Instance

            igmpv1query: IGMPv1 Query Instance

            igmpv2: IGMPv2 Report Instance

            igmpv2query: IGMPv2 Query Instance

            igmpv3report: IGMPv3 Report Instance

            igmpv3query: IGMPv3 Query Instance

            custom: Custom Instance

            ospfv2linkstateupdate: OSPFv2 Link State Updata Instance

            ospfv2linkstaterequest: OSPFv2 Link State Request Instance

            ospfv2databasedescription: OSPFv2 Database Description Instance

            ospfv2linkstateacknowledge: OSPFv2 Link State Acknowledge Instance

            ospfv2unknown: OSPFv2 Unknown Instance

            ospfv2hello: OSPFv2 Hello Instance

            mpls: MPLS Instance

            l1csnpheader: ISIS-L1 CSNP Config Instance

            isisl1helloheader: ISIS-L1 Hello Config Instance

            l1lspheader: ISIS-L1 LSP Config Instance

            l1psnpheader: ISIS-L1 PSNP Config Instance

            l2csnpheader: ISIS-L2 CSNP Config Instance

            isisl2helloheader: ISIS-L2 Hello Config Instance

            l2lspheader: ISIS-L2 LSP Config Instance

            l2psnpheader: ISIS-L2 PSNP Config Instance

            p2phelloheader: ISIS P2P Hello Config Instance

            gtpv1: GTPv1 Instance

            gtpv1opt: GTPv1 Optional Fields Instance

            gtpv1exthdr: GTPv1 Extension Header

            gtpv1ext: GTPv1 Optional Fields and Extension Header Instance

            ipv6fragmentheader: IPv6 Fragment Header

            ipv6routingheader: IPv6 Routing Header

            ipv6authenticationheader: IPv6 Authentication Header

            ipv6destinationheader: IPv6 Destination Header

            ipv6encapsulationheader: IPv6 Encapsulation Header

            ipv6hopbyhopheader: IPv6 Hop By Hop Header

            ipv6srheader: IPv6 SR Header

            stag: Customer STag Ethernet

            encapethernetii: Encapsulated Customer EthernetII Instance

            encapbackboneeth: Encapsulated MAC-in-Mac

            itag: iTag Instance

            mac-in-mac: MAC-in-MAC Instance

            encapcustomereth: Encapsulated Customer Ethernet Instance

            portmanagement: ANCP Instance

            bier: BIER Instance

            ccm: Continuty Check Message (CCM)

            chdlc: Cisco HDLC Instance

            cw: Control Word Instance

            elsflogi: ELS FLOGI Instance

            8023: Ethernet802.3 Instance

            goose: Goose Instance

            logiclinkcontrol: LLC Header

            cfg: MSTP Config Instance

            pause: Pause Instance

            pfc: PFC Instance

            vntag: VN Tag Instance

            fc: Fibre Channel Instance

            chassisidtlv: LLDP Chassis ID TLV

            portidtlv: LLDP Port ID TLV

            ttltlv: LLDP Time To Live TLV

            endtlv: LLDP End TLV

            hsrtag: HSR Tag Instance

            prptag: PRP Tag Instance

            rtag: R Tag Instance

            sctp: SCTP Instance

            trill: Thrill Instance

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${HeaderTypes} | Create List | EthernetII | IPv4 | TCP |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
    """

    result = renix.create_stream_header(Stream=Stream, HeaderTypes=HeaderTypes, Index=Index)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_modifier(Stream, Attribute, Level=0, Index=None, **kwargs):
    """
    修改测试仪表流量模板中指定报文字段的跳变域

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Attribute (str): 要修改的报文字段参数名称

        Level (int): 当HeaderType=None表示要修改的报文字段在流量模板中所有报文头部的序列号, 当HeaderType!=None表示要修改的报文字段在流量模板中所有相同类型报文头部的序列号, 默认值：0

        Index (int): 默认是None， 跳变编号, 默认值：0

    Keyword Args:

        Type (str): 跳变类型:

            Increment

            Decrement

            Random

            List

        Start (str): 跳变起始数据

        Count (int): 跳变数量

        Step (int): 跳变步长

        Repeat(int): 重复次数

        Range (int): 随机跳变范围

        Seed (int): 随机跳变种子

        StreamType (str): 流跳变类型, 支持：

            IntraModifier

            InterModifier

        Offset (int): 跳变偏移位

        Mask (str): 跳变掩码

        List (list): list跳变时, 跳变列表

        HeaderType (str): 要跳变的报文头部名称, 默认是None, 如果HeaderType为None, 修改的报文头Level决定(要修改的报文字段在流量模板中所有报文头部的序列号)，支持:

            ethernetii

            vlan

            vxlan

            arp

            ipv4

            ipv6

            tcp

            udp

            l2tpv2data

            ppp

            icmpv4echorequest

            destunreach

            icmpv4echoreply

            informationreply

            informationrequest

            icmpv4parameterproblem

            icmpv4redirect

            sourcequench

            timeexceeded

            timestampreply

            timestamprequest

            icmpmaskrequest

            icmpmaskreply

            destinationunreachable

            icmpv6echoreply

            icmpv6echorequest

            packettoobig

            icmpv6parameterproblem

            timeexceed

            routersolicit

            routeradvertise

            icmpv6redirect

            neighborsolicit

            neighboradvertise

            mldv1query

            mldv1report

            mldv1done

            mldv2query

            mldv2report

            igmpv1

            igmpv1query

            igmpv2

            igmpv2query

            igmpv3report

            igmpv3query

            custom

            ospfv2linkstateupdate

            ospfv2linkstaterequest

            ospfv2databasedescription

            ospfv2linkstateacknowledge

            ospfv2unknown

            ospfv2hello

            mpls

    Returns:

        dict: {
            'Stream': 'StreamTemplate_1',
            'Header': 'IPv4_1',
            'Attribute': 'Source',
            'Index': 0
        }

    Examples:
        .. code:: RobotFramework

            | ${Streams} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | TCP |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            # 不指定HeaderType, Level=1选中IPv4头部
            | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=source | Start=192.168.1.1 | Count=10 | Step=1 |
            # 指定HeaderType=IPv4, Level=0选中IPv4头部
            | Edit Modifier | Stream=${Stream} | Level=0 | HeaderType=IPv4 | Attribute=destination | Start=192.168.1.1 | Count=10 | Step=1 |
    """

    result = renix.edit_modifier(Stream=Stream, Index=Index, Attribute=Attribute, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_modifier_link(Stream, Link, LinkModifierType='MODIFIER_ID', BindingModifier=False):
    """
    修改测试仪表流量模板中指定报文字段的跳变域的link

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object列表

        Link (list): link modifier设置

        LinkModifierType (str): 跳变域link类型支持：MODIFIER_ID 和 LINK_MODIFIER_PATH

        BindingModifier (bool): 是否是绑定跳变

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        ::

            | ${Streams} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | TCP |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            # 不指定HeaderType, Level=1选中IPv4头部
            | ${Modifier_1} | Edit Modifier | Stream=${Stream} | Level=1 | Attribute=source | Start=192.168.1.1 | Count=10 | Step=1 |
            # 指定HeaderType=IPv4, Level=0选中IPv4头部
            | ${Modifier_2} | Edit Modifier | Stream=${Stream} | Level=0 | HeaderType=IPv4 | Attribute=destination | Start=192.168.1.1 | Count=10 | Step=1 |
            | ${LinkModifier} | Create List | ${Modifier_1} | ${Modifier_2} |
            | Edit Modifier Link | Stream=${Stream} | Link=${LinkModifier} |
    """

    result = renix.edit_modifier_link(Stream=Stream, Link=Link, LinkModifierType=LinkModifierType, BindingModifier=BindingModifier)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def select_rx_port(Streams, RxPorts, Mode=1, ExcludeTxPort=True):
    """
    选择流量的收端口

    Args:

        Streams (list (:obj:`StreamTemplate`)): 测试仪表流量对象object列表

        RxPorts (list (:obj:`Port`)): 指定流量收端口对象列表

        Mode: 模式, 默认值：ONE_TO_ONE，支持类型

            ONE_TO_ONE

            ONE_TO_MANY

            MANY_TO_ONE

            PAIR

        ExcludeTxPort (bool): 是否包括流量发送端口

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        ::

        | Select Rx Port | Streams=${Streams} | RxPorts=${Ports} | Mode=ONE_TO_MANY | ExcludeTxPort=True |
    """

    result = renix.select_rx_port(Streams=Streams, RxPorts=RxPorts, Mode=Mode, ExcludeTxPort=ExcludeTxPort)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_stream(Type=None, Objects=None):
    """
    测试仪表开始发送数据流

    Args:

        Type (str): 当值为None时发送所有流量，按指定端口发送数据流或者按指定流模板发送数据流, 类型string("port" 或 "stream"),

        Objects (list): 按指定端口发送数据流或者按指定流模板发送数据流时需要指定端口对象或流模板对象列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Subscribe Result |
            | Start Stream |
            | Sleep | 10 |
            | Stop Stream |
            | Sleep | 3 |
            | @{Objects} | Get Ports |
            | Start Stream | Type=port | Objects=@{Objects} |
            | Sleep | 10 |
            | Stop Stream | Type=port | Objects=@{Objects} |
    """

    result = renix.start_stream(Type=Type, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_stream(Type=None, Objects=None):
    """
    测试仪表停止发送数据流

    Args:

        Type (str): 当值为None时发送所有流量，按指定端口发送数据流或者按指定流模板停止数据流, 类型string("port" 或 "stream"),

        Objects (list): 按指定端口停止数据流或者按指定流模板发送数据流时需要指定端口对象或流模板对象列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Subscribe Result |
            | Start Stream |
            | Sleep | 10 |
            | Stop Stream |
            | Sleep | 3 |
            | @{Objects} | Get Ports |
            | Start Stream | Types=port | Objects=@{Objects} |
            | Sleep | 10 |
            | Stop Stream | Types=port | Objects=@{Objects} |
    """

    result = renix.stop_stream(Type=Type, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_stream_state(Stream=None, State='READY', TimeOut=60):
    """
    等待测试仪表流量达到指定状态

    Args:

        Stream ((:obj:`StreamTemplate`) or list (:obj:`StreamTemplate`)): 测试仪表流模板对象列表

        State (str or list): 流模板状态, 默认值READY, 支持:

            DISABLED

            NOTREADY

            READY

            RUNNING

            STOPPED

            PAUSED

        TimeOut (int): 超时时间,默认值:60

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Stream |
            | Sleep | 10 |
            | Wait Stream State |
            | Sleep | 3 |
    """

    result = renix.wait_stream_state(Stream=Stream, State=State, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_l2_learning(Type=None, Ports=None, Streams=None, WaitLearningDone=True, WaitTime=30):
    """
    启动测试仪表流量二层学习

    Args:

        Type (str): 启动流二层学习的的类型，类型为：string，支持：Tx或Rx

        Ports (list (:obj:`Port`)): 测试仪表端口对象object列表，类型为：list，端口对象object列表

        Streams (list (:obj:`StreamTemplate`)): 测试仪表流量模板对象object列表，类型为：list，目流量模板对象object列表

        WaitLearningDone (bool): 是否等待二层学习完成，类型为：Bool (范围：True / False)

        WaitTime (int): 等待二层学习完成时间，类型为：number，默认值：30 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Subscribe Result |
            | Start L2 Learning |
            | Sleep | 10 |
            | Stop L2 Learning |
            | Sleep | 3 |
    """

    result = renix.start_l2_learning(Type=Type, Ports=Ports, Streams=Streams, WaitLearningDone=WaitLearningDone,
                                        WaitTime=WaitTime)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_l2_learning(Ports=None, Streams=None):
    """
    停止测试仪表流量二层学习

    Args:

        Ports (list (:obj:`Port`)): 测试仪表端口对象object列表，类型为：list，端口对象object列表

        Streams (list (:obj:`StreamTemplate`)): 测试仪表流量模板对象object列表，类型为：list，目流量模板对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Subscribe Result |
            | Start L2 Learning |
            | Sleep | 10 |
            | Stop L2 Learning |
            | Sleep | 3 |
    """

    result = renix.start_l2_learning(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_l3_learning(Ports=None, Streams=None):
    """
    启动测试仪表流量三层ARP ND学习

    Args:

        Ports (list (:obj:`Port`)): 测试仪表端口对象object列表，类型为：list，端口对象object列表

        Streams (list (:obj:`StreamTemplate`)): 测试仪表流量模板对象object列表，类型为：list，目流量模板对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Subscribe Result |
            | Start L3 Learning |
            | Sleep | 10 |
            | Stop L3 Learning |
            | Sleep | 3 |
    """

    result = renix.start_l3_learning(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_l3_learning(self, Ports=None, Streams=None):
    """
    停止测试仪表流量三层ARP ND学习

    Args:

        Ports (list (:obj:`Port`)): 测试仪表端口对象object列表，类型为：list，端口对象object列表

        Streams (list (:obj:`StreamTemplate`)): 测试仪表流量模板对象object列表，类型为：list，目流量模板对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Subscribe Result |
            | Start L3 Learning |
            | Sleep | 10 |
            | Stop L3 Learning |
            | Sleep | 3 |
    """

    result = renix.start_l3_learning(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def del_stream(Ports=None, Streams=None):
    """
    删除测试仪流量

    Args:

        Ports (list (:obj:`Port`)): 测试仪表端口对象列表

        Streams (list (:obj:`StreamTemplate`)): 测试仪表流量对象列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Stream_1} | Add Stream | Ports=${Port_1}
            | ${Stream_2} | Add Stream | Ports=${Port_2}
            | ${Stream_2} | Add Stream | Ports=${Port_3}
            | Del Stream | Streams=${Stream_1} |
            | Del Stream | Ports=${Port_2} |
            | Del Stream |
    """

    result = renix.del_stream(Ports=Ports, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_streams(Ports=None):
    """
    获取测试仪表流量对象

    Args:

        Ports (list (:obj:`Port`)): 测试仪表端口对象列表

    Returns:

        Streams (list (:obj:`StreamTemplate`)): 测试仪表流量对象列表

    Examples:
        .. code:: RobotFramework

            | Get Streams | Ports=${Ports} |
    """

    result = renix.get_streams(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def start_stream_arp(Ports=None, Stream=None):
    """
    测试仪表启动接口ARP功能

    Args:

        Ports (list): 端口对象的列表, 默认值：None

        Stream (list): 接口对象的列表, 默认值：None，当Ports和Stream都为None时，表示启动所有流量的ARP

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Start Stream Arp |
    """

    result = renix.start_stream_arp(Ports=Ports, Stream=Stream)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_stream_arp(Ports=None, Stream=None):
    """
    测试仪表停止接口ARP功能

    Args:

        Ports (list): 端口对象的列表, 默认值：None

        Stream (list): 接口对象的列表, 默认值：None，当Ports和Stream都为None时，表示启动所有流量的ARP

    Returns: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Stop Stream Arp |
    """

    result = renix.stop_stream_arp(Ports=Ports, Stream=Stream)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Header IGMP-------------------------------------
def edit_header_igmpv1_report(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IGMPv1 Report报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的IGMPv1 Report头部在流量模板中所有IGMPv1 Report头部的序列号,范围0-65535

    Keyword Args:

        Type (hex): Type, 范围: 00-FF, 默认值: 12

        Unused (int): Unused, 范围: 0-255, 默认值: 0

        Checksum (hex): Header Checksum, 范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        GroupAddress (str): Group Address, 范围: ipv4地址, 默认值: 225.0.0.1

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Unused': 'unused',
                'Checksum': 'Checksum',
                'GroupAddress': 'groupAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | IGMPv1 |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_igmpv1_report | Stream=${Stream} | Level=0 | GroupAddress=225.0.1.1 |
    """

    result = renix.edit_header_igmpv1_report(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_igmpv1_query(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IGMPv1 Query报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的IGMPv1 Query头部在流量模板中所有IGMPv1 Query头部的序列号

    Keyword Args:

        Type (hex): Type, 范围: 00-FF, 默认值: 11

        Unused (int): Unused, 范围: 0-255, 默认值: 0

        Checksum (hex): Header Checksum, 范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        GroupAddress (str): Group Address, 范围: ipv4地址, 默认值: 225.0.0.1

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Unused': 'unused',
                'Checksum': 'Checksum',
                'GroupAddress': 'groupAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | IGMPv1Query |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_igmpv1_query | Stream=${Stream} | Level=0 | GroupAddress=225.0.1.1 |
    """

    result = renix.edit_header_igmpv1_query(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_igmpv2_report(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IGMPv2 Report报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的IGMPv2 Report头部在流量模板中所有IGMPv2 Report头部的序列号

    Keyword Args:

        Type (hex): Type, 范围: 00-FF, 默认值: 16

        MaxResponseTime (int): Max Response Time, 范围: 0-255, 默认值: 100

        Checksum (hex): Header Checksum, 范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        GroupAddress (str): Group Address, 范围: ipv4地址, 默认值: 225.0.0.1

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'MaxResponseTime': 'maxResponseTime',
                'Checksum': 'Checksum',
                'GroupAddress': 'groupAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | IGMPv2 |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_igmpv2_report | Stream=${Stream} | Level=0 | MaxResponseTime=15 | GroupAddress=225.0.1.1 |
    """

    result = renix.edit_header_igmpv2_report(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_igmpv2_query(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IGMPv2 Query报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的IGMPv2 Query头部在流量模板中所有IGMPv2 Query头部的序列号

    Keyword Args:

        Type (hex): Type, 范围: 00-FF, 默认值: 12

        MaxResponseTime (int): MAX Response Time, 范围: 0-255, 默认值: 0

        Checksum (hex): Header Checksum, 范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        GroupAddress (str): Group Address, 范围: ipv4地址, 默认值: 225.0.0.1

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'MaxResponseTime': 'maxResponseTime',
                'Checksum': 'Checksum',
                'GroupAddress': 'groupAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | IGMPv2Query |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_igmpv2_query | Stream=${Stream} | Level=0 | MaxResponseTime=15 | GroupAddress=225.0.1.1 |
    """

    result = renix.edit_header_igmpv2_query(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_igmpv3_report(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IGMPv2 Report报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的IGMPv3 Report头部在流量模板中所有IGMPv3 Report头部的序列号

    Keyword Args:

        Type (hex): Type, 范围: 00-FF, 默认值: 22

        Reserved1 (hex): Reserved1, 范围: 范围: 00-ff, 默认值: 00

        Checksum (hex): Header Checksum, 范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        Reserved2 (hex): Reserved2, 范围: 范围: 0000-ffff, 默认值: 0000

        NumGroupRecords (int): Num Group Records, 范围: 0-65535、AUTO, AUTO表示自动计算

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Reserved1': 'reserved1',
                'Checksum': 'Checksum',
                'Reserved2': 'reserved2',
                'NumGroupRecords': 'numGroupRecords'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | IGMPv3 |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_igmpv3_report | Stream=${Stream} | Level=0 | NumGroupRecords=15 |
    """

    result = renix.edit_header_igmpv3_report(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_igmpv3_query(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中IGMPv3 Query报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的IGMPv3 Query头部在流量模板中所有IGMPv3 Query头部的序列号

    Keyword Args:

        Type (hex): Type，范围: 00-FF, 默认值: 11

        MaxResponseTime (int): MAX Response Time，范围: 0-255, 默认值: 100

        Checksum (int): Header Checksum，默认值: 0000，范围: 0000-ffff、AUTO, 其中ffff表示产生错误, AUTO表示自动计算Checksum

        GroupAddress (int): Group Address，范围: ipv4地址, 默认值: 225.0.0.1

        Reserved (int): Reserved，范围: 0-15, 默认值: 0

        SuppressFlag (bit): Suppress Flag，范围: 0 or 1, 默认值: 1

        Qrv (bit): QRV，范围: 000-111, 默认值: 000

        Qqic (int): QQIC，范围: 0-255, 默认值: 0

        NumberOfSources (int): Number Of Sources，范围: 0-65535

        SourceAddressList (list): Sources Address List，范围: ipv4 address list，长度0-63，默认值：[]

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'MaxResponseTime': 'maxResponseTime',
                'Checksum': 'Checksum',
                'GroupAddress': 'groupAddress',
                'Reserved': 'reserved',
                'SuppressFlag': 'suppressFlag',
                'Qrv': 'qrv',
                'Qqic': 'qqic',
                'NumberOfSources': 'numberOfSources'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | IGMPv3Query |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_igmpv3_query | Stream=${Stream} | Level=0 | MaxResponseTime=15 | GroupAddress=225.0.1.1 |
    """

    result = renix.edit_header_igmpv3_query(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_igmpv3_group_records(Stream, Level=0, Index=0, Header='igmpv3report', SourceAddressList=[],
                                     ExceedauxDataList=[], **kwargs):
    """
    修改测试仪表流量模板中IGMPv3 Report报文头部Group Records内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的IGMPv3头部在流量模板中所有IGMPv3头部的序列号

        Index (int): 要修改的IGMPv3 Group Records头部在流量模板中所有IGMPv3 Group Records的序列号

        Header (str): 要修改的流量头部，默认修改igmpv3report头部对象，其他对象包括：

            igmpv3report

        SourceAddressList (list): Source Address List, 传入ipv4地址列表, 类型为list

        ExceedauxDataList (list): Exceed Aux Data List, 传入data列表, 类型为list, 列表元素为4字节长度的十六进制数

        Keyword Args:

            RecordType (int): Record Type，默认值：1，范围: 0-255

            AuxDataLen (int): Aux Data Len，默认值：0，范围: 0-255

            NumberOfSources (int): Number Of Sources，默认值：0，范围: 0-65535

            MulticastAddress (str): Multicast Address，默认值：225.0.0.1，范围: ipv4 address

    Returns:

        dict: eg::

            {
                'MulticastAddress': 'groupRecords.groupRecord_1.multicastAddress',
                'SourceAddressList: 1.1.1.1': 'groupRecords.groupRecord_1.sourceAddressList.ipv4AddrContainer_0.ipv4Addr',
                'SourceAddressList: 2.2.2.2': 'groupRecords.groupRecord_1.sourceAddressList.ipv4AddrContainer_1.ipv4Addr',
                'ExceedauxDataList: 10203040': 'groupRecords.groupRecord_1.exceedauxDataList.auxDataContainer_0.auxData',
                'ExceedauxDataList: 50607080': 'groupRecords.groupRecord_1.exceedauxDataList.auxDataContainer_1.auxData'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | IGMPv3 |
            | create_stream_header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | edit_header_igmpv3_report | Stream=${Stream} | Level=0 | NumGroupRecords=15 |
            | Edit Header IPv4 Option | Stream=${Stream} | recordType=10 |
    """

    result = renix.edit_header_igmpv3_group_records(Stream=Stream, Level=Level, Index=Index, Header=Header,
                                                    SourceAddressList=SourceAddressList,
                                                    ExceedauxDataList=ExceedauxDataList, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def edit_header_gtpv1(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Gtpv1报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的gtpv1头部在流量模板中所有gtpv1头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version，默认值：1，取值范围：0-7

        Pt (bit): Protocol Type，默认值：1，取值范围：0-1

        Reserved (bit): Reserved，默认值：0，取值范围：0-1

        Nexthead (bit): Next Extension Header present，默认值：0，取值范围：0-1

        SequenceNumber (bit): Sequence Number present，默认值：0，取值范围：0-1

        PduNumberPresent (bit): N-PDU number present，默认值：0，取值范围：0-1

        MessageType (hex): Message Type，默认值：FF，取值范围：00-FF

        Length (int): Length，默认值：8，取值范围：0-65535

        Teid (int): TEID，默认值：0，取值范围：0-4294967295

    Returns:

        dict: eg::

            {
                'Version': 'version',
                'Pt': 'pt',
                'Reserved': 'reserved',
                'Nexthead': 'nexthead',
                'SequenceNumber': 'sequenceNumber',
                'MessageType': 'messageType',
                'Length': 'length',
                'Teid': 'teid'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Gtpv1 | Stream=${Stream} | Level=0 | Teid=1024 |
    """

    result = renix.edit_header_gtpv1(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_gtpv1_optional(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Gtpv1 Optional报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Gtpv1 Optional头部在流量模板中所有Gtpv1 Optional头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Sequence (int): Sequence Number，默认值：0，取值范围：0-65535

        NPDUNumber (int): N-PDU Number，默认值：0，取值范围：0-255

        NextHeaderType (int): Next Extension Header Type，默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'SourcePort': 'sourcePort',
                'DestPort': 'destPort',
                'SeqNum': 'seqNum',
                'AckNum': 'ackNum',
                'DataOffset': 'dataOffset',
                'Reserved': 'reserved',
                'Flags': 'flags',
                'WindowSize': 'windowSize',
                'Checksum': 'checksum',
                'UrgentPointer': 'urgentPointer',
                'Option': 'option'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Gtpv1 Optional | Stream=${Stream} | Level=0 | NextHeaderType=255 |
    """

    result = renix.edit_header_gtpv1_optional(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_gtpv1_extension(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Gtpv1 Extension报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Gtpv1 Extension头部在流量模板中所有Gtpv1 Extension头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Length (int): Length，默认值：1，取值范围：0-65535

        BytePattern (hex): Byte Pattern，默认值：0000，取值范围：长度为2-1500字节的十六进制数

        NextHeaderType (int): Next Extension Header Type，默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'SourcePort': 'sourcePort',
                'DestPort': 'destPort',
                'SeqNum': 'seqNum',
                'AckNum': 'ackNum',
                'DataOffset': 'dataOffset',
                'Reserved': 'reserved',
                'Flags': 'flags',
                'WindowSize': 'windowSize',
                'Checksum': 'checksum',
                'UrgentPointer': 'urgentPointer',
                'Option': 'option'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Gtpv1 Extension | Stream=${Stream} | Level=0 | NextHeaderType=255 |
    """

    result = renix.edit_header_gtpv1_extension(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_gtpv1_optional_extension(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Gtpv1 Optional Extension报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Gtpv1 Optional Extension头部在流量模板中所有Gtpv1 Optional Extension头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Sequence (int): Sequence Number，默认值：0，取值范围：0-65535

        NPDUNumber (int): N-PDU Number，默认值：0，取值范围：0-255

        NextHeaderType1 (int): Next Extension Header Type，默认值：0，取值范围：0-255

        Length (int): Length，默认值：1，取值范围：0-65535

        BytePattern (hex): Byte Pattern，默认值：0000，取值范围：长度为2-1500字节的十六进制数

        NextHeaderType2 (int): Next Extension Header Type，默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'SourcePort': 'sourcePort',
                'DestPort': 'destPort',
                'SeqNum': 'seqNum',
                'AckNum': 'ackNum',
                'DataOffset': 'dataOffset',
                'Reserved': 'reserved',
                'Flags': 'flags',
                'WindowSize': 'windowSize',
                'Checksum': 'checksum',
                'UrgentPointer': 'urgentPointer',
                'Option': 'option'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Gtpv1 Optional Extension | Stream=${Stream} | Level=0 | NextHeaderType2=255 |
    """

    result = renix.edit_header_gtpv1_optional_extension(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result











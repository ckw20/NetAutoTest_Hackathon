import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_lldp_chassis_id_tlv(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中lldp chassis id tlv报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的lldp chassis id tlv头部在流量模板中所有lldp chassis id tlv头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Type (int): Type，默认值：1，取值范围：0-127

        Length (int): Length，默认值：0，取值范围：0-511

        ChassisIdSubType (hex): Chassis ID Subtype，默认值：05，取值范围：

            05: Network Address IPv4

        IanaAddressFamily (int): IANA Address Family，默认值：1，取值范围：0-255

        ChassisId (str): Chassis ID，默认值：192.168.0.1，取值范围：有效的ipv4地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Length': 'length',
                'ChassisIdSubType': 'chassisId.networkAddress4.chassisIdSubType',
                'IanaAddressFamily': 'chassisId.networkAddress4.ianaAddressFamily',
                'ChassisId': 'chassisId.networkAddress4.chassisId'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Lldp Chassis Id Tlv | Stream=${Stream} | Level=0 | Type=127 |
    """

    result = renix.edit_header_lldp_chassisId(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_lldp_port_id_tlv(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中lldp port id tlv报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的lldp port id tlv头部在流量模板中所有lldp port id tlv头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Type (int): Type，默认值：2，取值范围：0-127

        Length (int): Length，默认值：0，取值范围：0-511

        PortIdSubType (hex): Chassis ID Subtype，默认值：03，取值范围：

            03: MAC Address

        PortId (str): Port ID，默认值：00:00:00:00:00:00，取值范围：有效的mac地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Length': 'length',
                'PortIdSubType': 'portId.macAddr.portIdSubType',
                'PortId': 'portId.macAddr.portId'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Lldp Port Id Tlv | Stream=${Stream} | Level=0 | Type=127 |
    """

    result = renix.edit_header_lldp_portId(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_lldp_ttl_tlv(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中lldp ttl tlv报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的lldp ttl tlv头部在流量模板中所有lldp ttl tlv头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Type (int): Type，默认值：3，取值范围：0-127

        Length (int): Length，默认值：0，取值范围：0-511

        Ttl (int): Time To Live，默认值：120，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Length': 'length',
                'Ttl': 'ttl'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Lldp Ttl Tlv | Stream=${Stream} | Level=0 | Type=127 |
    """

    result = renix.edit_header_lldp_ttl(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_lldp_end_tlv(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中lldp end tlv报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的lldp end tlv头部在流量模板中所有lldp end tlv头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Type (int): Type，默认值：0，取值范围：0-127

        Length (int): Length，默认值：0，取值范围：0-511

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Length': 'length',
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Lldp End Tlv | Stream=${Stream} | Level=0 | Type=127 |
    """

    result = renix.edit_header_lldp_end(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

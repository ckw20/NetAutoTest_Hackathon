import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure

def edit_header_control_word(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Control Word报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Control Word头部在流量模板中所有Control Word头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Reserved (bit): Reserved, 默认值：0000，取值范围：0000-1111

        Flags (bit): Flags, 默认值：00，取值范围：00-11

        Fragment (bit): Fragment, 默认值：00，取值范围：00-11

        Length (int): Length, 默认值：0，取值范围：0-63

        Sn (int): Sequence Number, 默认值：0，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Reserved': 'rsvd',
                'Flags': 'flags',
                'Fragment': 'frg',
                'Length': 'length',
                'Sn': 'sn'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Control Word | Stream=${Stream} | Level=0 | Flags=11 |
    """

    result = renix.edit_header_control_word(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

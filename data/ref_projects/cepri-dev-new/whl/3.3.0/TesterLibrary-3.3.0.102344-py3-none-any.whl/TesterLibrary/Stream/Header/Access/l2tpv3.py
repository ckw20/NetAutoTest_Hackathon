import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_l2tpv3_control_over_ip(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv3 Control Over Ip报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的L2TPv3 Control头部在流量模板中所有L2TPv3 Control Over Ip头部的序列号

    Keyword Args:

        SessionId (int): Session ID，默认值：0, 取值范围：0-4294967295

        Type (bit): Type, 默认值：1, 取值范围：0-1

        UseLength (bit): UseLength, 默认值：0, 取值范围：0-1

        Reserved1 (bit): Reserved, 默认值：00, 取值范围：00-11

        UseSequence (bit): UseSequence, 默认值：<AUTO>0, 取值范围：00-11

        Reserved2 (bit): Reserved, 默认值：0000000, 取值范围：0000000-1111111

        Version (int): Version, 默认值：3, 取值范围：0-15

        ExcludeSessionLength (int): length, 默认值：<AUTO>0, 取值范围：0-65535

        ControlId (int): Control Connection ID，默认值：0, 取值范围：0-4294967295

        SequenceNumberNs (int): Message Sequence Number Ns Value, 默认值：0, 取值范围：0-65535

        SequenceNumberNr (int): Message Sequence Number Nr Value, 默认值：0, 取值范围：0-65535

        OptionHeaders: 支持的参数有：

            generalTLV

            messageType

            resultCode

            tieBreaker

            receiveWindowSize

            callSerialNumber

            physicalChannelId

            circuitError

            routeId

            assignedConnection

            localSessionId

            remoteSessionId

            assignedCookie

            pwType

            l2SpecificSub

            dataSequencing

            txConnectSpeed

            rxConnectSpeed

            circuitStatus

    Returns:

        dict: eg::

            {
                'SessionId': 'sessionId'
                'Type': 'type'
                'UseLength': 'useLength'
                'Reserved1': 'reserved1'
                'UseSequence': 'useSequence'
                'Reserved2': 'reserved2'
                'Version': 'version'
                'ExcludeSessionLength': 'lengthOption.excludeSessionLength_0.value'
                'ControlId': 'controlId'
                'SequenceNumberNs': 'seqNum.sequenceNumber_0.ns'
                'SequenceNumberNr': 'seqNum.sequenceNumber_0.nr'
                'OptionHeaders': True
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | l2tpv3ControlOverIp |
            | ${OptionHeaders} | Create List | generalTLV | messageType | resultCode | tieBreaker |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv3 Control Over Ip | Stream=${Stream} | Level=0 | Type=1 | OptionHeaders=${OptionHeaders} |
    """
    result = renix.edit_header_l2tpv3_control_over_ip(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def edit_header_l2tpv3_control_over_udp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv3 Control Over Udp报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的L2TPv3 Control头部在流量模板中所有L2TPv3 Control Over Udp头部的序列号

    Keyword Args:

        Type (bit): Type, 默认值：1, 取值范围：0-1

        UseLength (bit): UseLength, 默认值：0, 取值范围：0-1

        Reserved1 (bit): Reserved, 默认值：00, 取值范围：00-11

        UseSequence (bit): UseSequence, 默认值：<AUTO>0, 取值范围：00-11

        Reserved2 (bit): Reserved, 默认值：0000000, 取值范围：0000000-1111111

        Version (int): Version, 默认值：3, 取值范围：0-15

        Length (int): length, 默认值：<AUTO>0, 取值范围：0-65535

        ControlId (int): Control Connection ID，默认值：0, 取值范围：0-4294967295

        SequenceNumberNs (int): Message Sequence Number Ns Value, 默认值：0, 取值范围：0-65535

        SequenceNumberNr (int): Message Sequence Number Nr Value, 默认值：0, 取值范围：0-65535

        OptionHeaders: 支持的参数有：

            generalTLV

            messageType

            resultCode

            tieBreaker

            receiveWindowSize

            callSerialNumber

            physicalChannelId

            circuitError

            routeId

            assignedConnection

            localSessionId

            remoteSessionId

            assignedCookie

            pwType

            l2SpecificSub

            dataSequencing

            txConnectSpeed

            rxConnectSpeed

            circuitStatus

    Returns:

        dict: eg::

            {
                'Type': 'type'
                'UseLength': 'useLength'
                'Reserved1': 'reserved1'
                'UseSequence': 'useSequence'
                'Reserved2': 'reserved2'
                'Version': 'version'
                'Length': 'lengthOption.length_0.value'
                'ControlId': 'controlId'
                'SequenceNumberNs': 'sequenceNumber_0.ns'
                'SequenceNumberNr': 'sequenceNumber_0.nr'
                'OptionHeaders': True
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | l2tpv3ControlOverUdp |
            | ${OptionHeaders} | Create List | generalTLV | messageType | resultCode | tieBreaker |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv3 Control Over Udp | Stream=${Stream} | Level=0 | Type=1 | OptionHeaders=${OptionHeaders} |
    """
    result = renix.edit_header_l2tpv3_control_over_udp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_l2tpv3_control_option(Stream, Types, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv3 Control Over Ip/Udp报文中Option头部内容.

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Types (str): L2TPv3 Control Over Ip/Udp报文option类型支持：

            GeneralTLV

            MessageType

            ResultCode

            TieBreaker

            ReceiveWindowSize

            CallSerialNumber

            PhysicalChannelId

            CircuitError

            RouteId

            AssignedConnection

            LocalSessionId

            RemoteSessionId

            AssignedCookie

            PwType

            L2SpecificSub

            DataSequencing

            TxConnectSpeed

            RxConnectSpeed

            CircuitStatus

        Level (int): 要修改的L2TPv3 Control Over Ip/Udp头部在流量模板中所有L2TPv3 Control Over Ip/Udp头部的序列号

        Index (int): 要修改的L2TPv3 Control Over Ip/Udp Option头部在流量模板中所有L2TPv3 Control Over Ip/Udp Option头部的序列号

    Keyword Args:

        GeneralTLV支持：

            Mbit (bit): M Bit, 默认值：0，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：13，取值范围：0-65535

            AttributeValue (hex): Attribute Value, 默认值：00000000000000000000000000000000，取值范围：长度0-1017字节的十六进制数

        MessageType支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：0，取值范围：0-65535

            MessageType (int): Message Type, 默认值：1，取值范围：0-65535

        ResultCode支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：0，取值范围：0-65535

            ResultCode (int): Result Code, 默认值：0，取值范围：0-65535

            ErrorCode (int): Error Code, 默认值：0，取值范围：0-65535

            ErrorMessage (hex): Error Message, 默认值：""，取值范围：长度0-1017字节的十六进制数

        TieBreaker支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：5，取值范围：0-65535

            TieBreakerValue (hex): Tie Breaker Value, 默认值：0000000000000000，取值范围：长度0-8字节的十六进制数

        ReceiveWindowSize支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：10，取值范围：0-65535

            WindowSize (int): Window Size, 默认值：0，取值范围：0-65535

        CallSerialNumber支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：15，取值范围：0-65535

            CallSerialNumber (int): Call Serial Number, 默认值：0，取值范围：0-4294967295

        PhysicalChannelId支持：

            Mbit (bit): M Bit, 默认值：0，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：25，取值范围：0-65535

            PhysicalChannelId (int): Physical Channel ID, 默认值：0，取值范围：0-4294967295

        CircuitError支持：

            Mbit (bit): M Bit, 默认值：0，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：34，取值范围：0-65535

            Reserved1 (int): Reserved, 默认值：0，取值范围：0-65535

            HardwareOverruns (int): Hardware Overruns, 默认值：0，取值范围：0-4294967295

            BufferOverruns (int): Buffer Overruns, 默认值：0，取值范围：0-4294967295

            TimeoutOverruns (int): Timeout Overruns, 默认值：0，取值范围：0-4294967295

            AlignmentOverruns (int): Alignment Overruns, 默认值：0，取值范围：0-4294967295

        RouteId支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：60，取值范围：0-65535

            RouteId (int): Router ID, 默认值：0，取值范围：0-4294967295

        AssignedConnection支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：61，取值范围：0-65535

            ConnectionId (int): Assigned Control Connection ID, 默认值：0，取值范围：0-4294967295

        LocalSessionId支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：63，取值范围：0-65535

            SessionId (int): Local Session ID, 默认值：0，取值范围：0-4294967295

        RemoteSessionId支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：64，取值范围：0-65535

            SessionId (int): Remote Session ID, 默认值：0，取值范围：0-4294967295

        AssignedCookie支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：65，取值范围：0-65535

            Cookie4Byte (hex): Cookie 4Byte, 默认值：00000000，取值范围：00000000-FFFFFFFF

            Cookie8Byte (hex): Cookie 8Byte, 默认值：0000000000000000，取值范围：0000000000000000-FFFFFFFFFFFFFFFF

        PwType支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：68，取值范围：0-65535

            PwType (int): PW Type, 默认值：0，取值范围：0-65535

        L2SpecificSub支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：69，取值范围：0-65535

            L2SpecificSublayer (int): L2-Specific Sublayer, 默认值：0，取值范围：0-65535

        DataSequencing支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：70，取值范围：0-65535

            DataSequencing (int): L2-Specific Sublayer, 默认值：0，取值范围：0-65535

        TxConnectSpeed支持：

            Mbit (bit): M Bit, 默认值：0，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：74，取值范围：0-65535

            SpeedBps (hex): Connect Speed in BPS, 默认值：0000000000000000，取值范围：0000000000000000-FFFFFFFFFFFFFFFF

        RxConnectSpeed支持：

            Mbit (bit): M Bit, 默认值：0，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：75，取值范围：0-65535

            SpeedBps (hex): Connect Speed in BPS, 默认值：0000000000000000，取值范围：0000000000000000-FFFFFFFFFFFFFFFF

        CircuitStatus支持：

            Mbit (bit): M Bit, 默认值：1，取值范围：0-1

            Hbit (bit): H Bit, 默认值：0，取值范围：0-1

            Reserved (bit): Reserved Bits, 默认值：0000，取值范围：0000-1111

            Length (int): Length, 默认值：<AUTO>0，取值范围：0-1023

            VendorId (int): Vendor ID, 默认值：0，取值范围：0-65535

            Type (int): Attribute Type, 默认值：71，取值范围：0-65535

            Reserved1 (int): Reserved, 默认值：71，取值范围：0-16383

            Nbit (bit): N, 默认值：0，取值范围：0-1

            Abit (bit): A, 默认值：0，取值范围：0-1

    Returns:

        dict: eg::

            {
                'Mbit': 'type'
                'Hbit': 'useLength'
                'Reserved': 'reserved1'
                'Length': 'useSequence'
                'VendorId': 'reserved2'
                'Type': 'version'
                'reserved1': 'lengthOption.length_0.value'
                'nbit': 'controlId'
                'abit': 'sequenceNumber_0.ns'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | l2tpv3ControlOverIp |
            | ${LsaHeaders} | Create List | generalTLV | messageType | resultCode | tieBreaker | receiveWindowSize |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv3 Control | Stream=${Stream} | Level=0 | Type=1 | OptionHeaders=${OptionHeaders} |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=0 | Types=GeneralTLV | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=1 | Types=MessageType | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=2 | Types=ResultCode | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=3 | Types=TieBreaker | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=4 | Types=ReceiveWindowSize | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=5 | Types=CallSerialNumber | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=6 | Types=PhysicalChannelId | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=7 | Types=CircuitError | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=8 | Types=RouteId | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=9 | Types=AssignedConnection | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=10 | Types=LocalSessionId | Mbit=1 |
            | Edit Header L2tpv2 Control Option | Stream=${Stream} | Level=0 | Index=11 | Types=RemoteSessionId | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=12 | Types=AssignedCookie | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=13 | Types=PwType | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=14 | Types=L2SpecificSub | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=15 | Types=DataSequencing | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=16 | Types=TxConnectSpeed | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=17 | Types=RxConnectSpeed | Mbit=1 |
            | Edit Header L2tpv3 Control Option | Stream=${Stream} | Level=0 | Index=18 | Types=CircuitStatus | Mbit=1 |
    """

    result = renix.edit_header_l2tpv3_control_option(Stream=Stream, Types=Types, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def edit_header_l2tpv3_data_over_ip(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv3 Data Over Ip报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的L2TPv3 Control头部在流量模板中所有L2TPv3 Data Over Ip头部的序列号

    Keyword Args:

        SessionId (int): Session ID, 默认值：0，取值范围：0-4294967295

        Cookie4Byte (hex): Cookie 4Byte, 默认值：00000000，取值范围：00000000-FFFFFFFF

        Cookie8Byte (hex): Cookie 8Byte, 默认值：0000000000000000，取值范围：0000000000000000-FFFFFFFFFFFFFFFF

        L2specificsublayer (int): L2TPv3 Data L2 Specific Sublayer数量，默认值：0，取值范围：1

        Atmspecificsublayer (int): L2TPv3 Data Atm Specific Sublayer数量，默认值：0，取值范围：1

    Returns:

        dict: eg::

            {
                'SessionId': 'sessionId'
                'Cookie4Byte': 'cookie4Byte'
                'Cookie8Byte': 'cookie8Byte'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | l2tpv3DataOverIp |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv3 Data Over Ip | Stream=${Stream} | Level=0 | SessionId=1 | Cookie4Byte=00000001 |
    """
    result = renix.edit_header_l2tpv3_data_over_ip(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def edit_header_l2tpv3_data_over_udp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv3 Data Over Udp报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的L2TPv3 Control头部在流量模板中所有L2TPv3 Data Over Udp头部的序列号

    Keyword Args:

        Type (bit): Type, 默认值：0，取值范围：0-1

        Reserved1 (bit): Reserved, 默认值：00000000000，取值范围：00000000000-11111111111

        Version (int): Version, 默认值：3，取值范围：0-15

        Reserved2 (int): Reserved, 默认值：0，取值范围：0-65535

        SessionId (int): Session ID, 默认值：0，取值范围：0-4294967295

        cookie4Byte (hex): Cookie 4Byte, 默认值：00000000，取值范围：00000000-FFFFFFFF

        cookie8Byte (hex): Cookie 8Byte, 默认值：0000000000000000，取值范围：0000000000000000-FFFFFFFFFFFFFFFF

        L2specificsublayer (int): L2TPv3 Data L2 Specific Sublayer数量，默认值：0，取值范围：1

        Atmspecificsublayer (int): L2TPv3 Data Atm Specific Sublayer数量，默认值：0，取值范围：1

    Returns:

        dict: eg::

            {
                'Type': 'type'
                'Reserved1': 'reserved1'
                'Version': 'version'
                'Reserved2': 'reserved2'
                'SessionId': 'sessionId'
                'Cookie4Byte': 'cookie4Byte'
                'Cookie8Byte': 'cookie8Byte'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | l2tpv3DataOverUdp |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv3 Data Over Udp | Stream=${Stream} | Level=0 | SessionId=1 | Cookie4Byte=00000001 |
    """
    result = renix.edit_header_l2tpv3_data_over_udp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_l2tpv3_data_sublayer(Stream, Type, Level=0, **kwargs):
    """
    修改测试仪表流量模板中L2TPv3 Data Specific Sublayer报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Type (str): L2TPv3 Data Specific Sublayer类型，默认值：‘’，取值范围：

            L2specificsublayer

            Atmspecificsublayer

        Level (int): 要修改的L2TPv3 Data头部在流量模板中所有L2TPv3 Data Over Udp/Ip头部的序列号

    Keyword Args:

        L2specificsublayer支持：

            Xbit (bit): X Bit, 默认值：0，取值范围：0-1

            Sbit (bit): S Bit, 默认值：1，取值范围：0-1

            Xbits (bit): X Bits, 默认值：000000，取值范围：000000-111111

            Sequence (int): Sequence Number, 默认值：0，取值范围：0-16777215

        Atmspecificsublayer支持：

            Xbit (bit): X Bit, 默认值：0，取值范围：0-1

            Sbit (bit): S Bit, 默认值：1，取值范围：0-1

            Bbit (bit): B Bit, 默认值：0，取值范围：0-1

            Ebit (bit): E Bit, 默认值：0，取值范围：0-1

            Tbit (bit): T Bit, 默认值：0，取值范围：0-1

            Gbit (bit): G Bit, 默认值：0，取值范围：0-1

            Cbit (bit): C Bit, 默认值：0，取值范围：0-1

            Ubit (bit): U Bit, 默认值：0，取值范围：0-1

            Sequence (int): Sequence Number, 默认值：0，取值范围：0-16777215

    Returns:

        dict: eg::

            {
                'Xbit': 'l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.xbit'
                'Sbit': 'l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.sbit'
                'Bbit': 'l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.bbit'
                'Sequence': 'l2SpecificSublayer.l2-SpecificSublayerList_0.atm-SpecificSublayerOption.sequence'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | l2tpv3DataOverUdp |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header L2tpv3 Data Over Udp | Stream=${Stream} | Level=0 | SessionId=1 | Cookie4Byte=00000001 |
    """

    result = renix.edit_header_l2tpv3_data_sublayer(Stream=Stream, Type=Type, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

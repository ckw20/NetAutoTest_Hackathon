import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------IMix-------------------------------------
def create_imix(Name, Seed=None):
    """
    创建流量Imix模板

    Args:

        Name (str): 创建的Imix模板名称

        Seed (int): Imix模板随机种子

    Returns:

        (:obj:`Imix`): Imix模板对象

    Examples:
        .. code:: RobotFramework

            | Create Imix | Name=Imix_1 | Seed=10121112 |
    """

    result = renix.create_imix(Name=Name, Seed=Seed)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_imix_from_name(Name):
    """
    通过Imix模板名称获取流量Imix模板对象

    Args:

        Name (str): 创建的Imix模板名称

    Returns:

        (:obj:`Imix`): Imix模板对象

    Examples:
        .. code:: RobotFramework

            | ${Imix_TCPv4} | Get Imix From Name | Name=TCPv4 |
    """

    result = renix.get_imix_from_name(Name=Name)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bind_stream_imix(Stream, IMix):
    """
    将Imix模板和流量模板绑定

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量模板StreamTemplate对象

        IMix (:obj:`Imix`): 测试仪表Imix模板对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Imix} | Create Imix | Name=Imix_1 | Seed=10121112 |
            | Bind Stream Imix | Stream=${Stream} | Imix=${Imix} |
    """

    result = renix.bind_stream_imix(Stream=Stream, IMix=IMix)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def add_imix_distribution_frame(IMix, Type="fixed", Length=None, Min=None, Max=None, Weight=None):
    """
    在Imix模板添加自定义帧长

    Args:

        IMix (:obj:`Imix`): 测试仪表Imix模板对象

        Type (str): 测试仪表Imix模板自定义帧长类型

            fixed

            random

        Length (int): 测试仪表Imix模板自定义帧长长度

        Min (int): 测试仪表Imix模板自定义帧长最小帧长，random时有效

        Max (int): 测试仪表Imix模板自定义帧长最大帧长，random时有效

        Weight (int): 测试仪表Imix模板自定义帧长权重

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Imix} | Create Imix | Name=Imix_1 | Seed=10121112 |
            | Add IMix Distribution Frame | IMix=${Imix} | Type=random | Min=64 | Max=128 | Weight=50 |
            | Add IMix Distribution Frame | IMix=${Imix} | Type=random | Min=128 | Max=256 | Weight=50 |
            | Bind Stream Imix | Stream=${Stream} | Imix=${Imix} |
    """

    result = renix.add_imix_distribution_frame(IMix=IMix, Type=Type, Length=Length, Min=Min, Max=Max,
                                                  Weight=Weight)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def del_imix_distribution_frame(IMix, Index=None):
    """
    在Imix模板删除指定自定义帧长

    Args:

        IMix (:obj:`Imix`): 测试仪表Imix模板对象

        Index (int): 测试仪表Imix模板自定义帧长序号

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Imix} | Create Imix | Name=Imix_1 | Seed=10121112 |
            | Add IMix Distribution Frame | IMix=${Imix} | Type=random | Min=64 | Max=128 | Weight=50 |
            | Add IMix Distribution Frame | IMix=${Imix} | Type=random | Min=128 | Max=256 | Weight=50 |
            | Bind Stream Imix | Stream=${Stream} | Imix=${Imix} |
            | Del IMix Distribution Frame | IMix=${Imix} | Index=1
    """

    result = renix.del_imix_distribution_frame(IMix=IMix, Index=Index)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
    
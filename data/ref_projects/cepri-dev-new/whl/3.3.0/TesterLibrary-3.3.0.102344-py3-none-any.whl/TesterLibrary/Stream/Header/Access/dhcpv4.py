import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_dhcpv4_server(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv4 Server报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的DHCPv4 Server头部在流量模板中所有DHCPv4 Server头部的序列号

    Keyword Args:

        MessageType (int): Message Type, 默认值：2 ，取值范围：0-255

        HardwareType (int): Hardware Type, 默认值：1 ，取值范围：0-255

        HaddrLen (int): Hardware Addr. Len, 默认值：6 ，取值范围：0-255

        Hops (int): Hops, 默认值：0 ，取值范围：0-255

        Xid (int): XID, 默认值：1 ，取值范围：0-4294967295

        Elapsed (int): Elapsed, 默认值：0 ，取值范围：0-65535

        Bootpflags (hex): Bootp Flags, 默认值：8000 ，取值范围：0000-FFFF

        ClientAddr (str): Client Address, 默认值：0.0.0.0 ，取值范围：有效的ipv4地址

        YourAddr (str): Your Address, 默认值：0.0.0.0 ，取值范围：有效的ipv4地址

        NextServerAddr (str): Next Server Address, 默认值：0.0.0.0 ，取值范围：有效的ipv4地址

        RelayAgentAddr (str): Relay Agent Address, 默认值：0.0.0.0 ，取值范围：有效的ipv4地址

        ClientMac (str): Client HW Addr. MAC, 默认值：00:00:02:00:00:02 ，取值范围：有效的mac地址

        ClientHWPad (hex): Client HW Addr. Pad, 默认值：00000000000000000000 ，取值范围：长度10字节

        ServerHostName (hex): Server Host Name, 默认值：00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 ，取值范围：长度64字节

        BootFileName (hex): Boot File Name, 默认值：0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 ，取值范围：长度128字节

        MagicCookie (hex): Magic Cookie, 默认值：63825363 ，取值范围：长度4字节十六进制数

        Padding (hex): DHCPv4 Padding, 默认值：’‘ ，取值范围：长度1500字节以内的十六进制数

        OptionHeaders (list): Options, 支持的参数有：

            messageType

            serverId

            message

            leaseTime

            endOfOptions

            messageSize

            clientIdHW

            clientIdNoneHW

            hostName

            paramReqList

            reqAddr

            optionOverload

            customOption

            generalTLV

    Returns:

        dict: eg::

            {
                'MessageType': 'messageType',
                'HardwareType': 'hardwareType',
                'HaddrLen': 'haddrLen',
                'Hops': 'hops',
                'Xid': 'xid',
                'Elapsed': 'elapsed',
                'Bootpflags': 'bootpflags',
                'ClientAddr': 'clientAddr',
                'YourAddr': 'yourAddr',
                'NextServerAddr': 'nextServerAddr',
                'RelayAgentAddr': 'relayAgentAddr',
                'ClientMac': 'clientMac',
                'ClientHWPad': 'clientHWPad',
                'ServerHostName': 'serverHostName',
                'BootFileName': 'bootFileName',
                'MagicCookie': 'magicCookie',
                'Padding': 'padding',
                'OptionHeaders': True
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | dhcpv4Server |
            | ${OptionHeaders} | Create List | messageSize | clientIdHW | clientIdNoneHW | hostName |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header DHCPv4 Server | Stream=${Stream} | Level=0 | messageType=1 | OptionHeaders=${OptionHeaders} |
    """

    result = renix.edit_header_dhcpv4_server(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_dhcpv4_client(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv4 Client/Server报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的DHCPv4 Client/Server头部在流量模板中所有DHCPv4 Client/Server头部的序列号

    Keyword Args:

         MessageType (int): Message Type

         HardwareType (int): Hardware Type

         HaddrLen (int): Hardware Addr. Len

         Hops (int): Hops

         Xid (int): XID

         Elapsed (int): Elapsed

         Bootpflags (str): Bootp Flags

         ClientAddr (str): Client Address

         YourAddr (str): Your Address

         NextServerAddr (str): Next Server Address

         RelayAgentAddr (str): Relay Agent Address

         ClientMac (str): Client HW Addr. MAC

         ClientHWPad (str): Client HW Addr. Pad

         ServerHostName (str): Server Host Name

         BootFileName (str): Boot File Name

         MagicCookie (str): Magic Cookie

         Padding (str): DHCPv4 Padding

         OptionHeaders (list): 支持的参数有：

             messageType

             messageSize

             clientIdHW

             clientIdNoneHW

             hostName

             paramReqList

             reqAddr

             optionOverload

             serverId

             message

             leaseTime

             customOption

             endOfOptions

             generalTLV

    Returns:

        dict: eg::

            {
                'MessageType': 'messageType',
                'HardwareType': 'hardwareType',
                'HaddrLen': 'haddrLen',
                'Hops': 'hops',
                'Xid': 'xid',
                'Elapsed': 'elapsed',
                'Bootpflags': 'bootpflags',
                'ClientAddr': 'clientAddr',
                'YourAddr': 'yourAddr',
                'NextServerAddr': 'nextServerAddr',
                'RelayAgentAddr': 'relayAgentAddr',
                'ClientMac': 'clientMac',
                'ClientHWPad': 'clientHWPad',
                'ServerHostName': 'serverHostName',
                'BootFileName': 'bootFileName',
                'MagicCookie': 'magicCookie',
                'Padding': 'padding',
                'OptionHeaders': True
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | dhcpv4Client |
            | ${OptionHeaders} | Create List | messageSize | clientIdHW | clientIdNoneHW | hostName |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header DHCPv4 Client | Stream=${Stream} | Level=0 | messageType=1 | OptionHeaders=${OptionHeaders} |
    """

    result = renix.edit_header_dhcpv4_client(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_dhcpv4_option(Stream, Types, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中DHCPv4 Client/Server报文中Option头部内容.

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Types (str): DHCPv4 Client报文option类型支持：

            MessageType: Message Type

            MessageSize: Message Size

            ClientIdHW: Client Id(Hardware)

            ClientIdNoneHW: Client Id(non-Hardware)

            HostName: Host Name

            ParamReqList: Parameter Request List

            ReqAddr: Requested IP Address

            OptionOverload: Option Overload

            ServerId: Server ID

            Message: Message

            LeaseTime: Lease Time

            CustomOption: Custom Option

            EndOfOptions: End of Options

            GeneralTLV: General Value Option

        Level (int): 要修改的DHCPv4 Client/Server头部在流量模板中所有DHCPv4 Client/Server头部的序列号

        Index (int): 要修改的DHCPv4 Client/Server Option头部在流量模板中所有DHCPv4 Client/Server Option头部的序列号

    Keyword Args:

        MessageType支持：

            Type (hex): Option Type，默认值：35，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>1，取值范围：0-255

            Code (int): Code，默认值：1，取值范围：1-8

        messageSize支持：

            Type (hex): Option Type，默认值：39，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>2，取值范围：0-255

            Value (hex): Option Value，默认值：0240，取值范围：长度0-256字节十六进制数

        clientIdHW支持：

            Type (hex): Option Type，默认值：3D，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>7，取值范围：0-255

            IdType (hex): ID Type，默认值：01，取值范围：00-FF

            ClientHWA (hex): Client HW Address，默认值：00:00:02:01:01:02，取值范围：有效的mac地址

        clientIdNoneHW支持：

            Type (hex): Option Type，默认值：3D，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>7，取值范围：0-255

            IdType (hex): ID Type，默认值：00，取值范围：00-FF

            Value (hex): Option Value，默认值：000102030405，取值范围：长度0-256字节十六进制数

        hostName支持：

            Type (hex): Option Type，默认值：0C，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>6，取值范围：0-255

            Value (hex): Option Value，默认值：636465666768，取值范围：长度0-256字节十六进制数

        paramReqList支持：

            Type (hex): Option Type，默认值：37，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>4，取值范围：0-255

            Value (hex): Option Value，默认值：01060f21，取值范围：长度0-256字节十六进制数

        reqAddr支持：

            Type (hex): Option Type，默认值：32，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>4，取值范围：0-255

            ReqAddr (str): Request Address，默认值：0.0.0.0，取值范围：有效的ipv4地址

        optionOverload支持：

            Type (hex): Option Type，默认值：34，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>4，取值范围：0-255

            Overload (int): Overload，默认值：3，取值范围：1-8

        serverId支持：

            Type (hex): Option Type，默认值：36，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>4，取值范围：0-255

            ReqAddr (str): Request Address，默认值：0.0.0.0，取值范围：有效的ipv4地址

        message支持：

            Type (hex): Option Type，默认值：38，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>4，取值范围：0-255

            Value (hex): Option Value，默认值：00，取值范围：长度0-256字节十六进制数

        leaseTime支持：

            Type (hex): Option Type，默认值：33，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>4，取值范围：0-255

            LeaseTime (int): Lease Time(s)，默认值：0，取值范围：0-4294967295

        customOption支持：

            Type (hex): Option Type，默认值：FE，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>1，取值范围：0-255

            Overload (hex): Overload，默认值：00，取值范围：长度0-256字节十六进制数

        endOfOptions支持：

            Type (hex): Option Type，默认值：FE，取值范围：00-FF

        generalTLV支持：

            Type (hex): Option Type，默认值：00，取值范围：00-FF

            Length (int): Length，默认值：<AUTO>0，取值范围：0-255

            Value (hex): value，默认值：”“，取值范围：长度0-256字节十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'options.Dhcpv4Options_0.serverId.type'
                'Length': 'options.Dhcpv4Options_0.serverId.length'
                'ReqAddr': 'options.Dhcpv4Options_0.serverId.reqAddr'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | UDP | dhcpv4Client |
            | ${LsaHeaders} | Create List | messageSize | clientIdHW | clientIdNoneHW | hostName |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header DHCPv4 Client | Stream=${Stream} | Level=0 | UsePriority=1 | OptionHeaders=${OptionHeaders} |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=0 | Types=MessageSize | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=1 | Types=ClientIdHW | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=2 | Types=ClientIdNoneHW | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=3 | Types=HostName | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=4 | Types=ParamReqList | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=5 | Types=ReqAddr | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=6 | Types=OptionOverload | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=7 | Types=CustomOption | Xid=1 |
            | Edit Header DHCPv4 Client Option | Stream=${Stream} | Level=0 | Index=8 | Types=GeneralTLV | Xid=1 |
    """

    result = renix.edit_header_dhcpv4_option(Stream=Stream, Types=Types, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

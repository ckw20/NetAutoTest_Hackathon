import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def edit_header_trill(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中trill报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的trill头部在流量模板中所有trill头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Version (int): Version, 默认值：1，取值范围：0-3

        Reserved (int): Reserved, 默认值：0，取值范围：0-3

        MultiDestination (int): Multi-Destination, 默认值：1，取值范围：0-1

        OptionLength (int): Option Length, 默认值：0，取值范围：0-31

        HopCount (int): Hop Count, 默认值：1，取值范围：0-63

        EgressRBridge (int): Egress RBridge Nickname, 默认值：0，取值范围：0-65535

        IngressBridge (int): Ingress RBridge Nickname, 默认值：0，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Version': 'version',
                'Reserved': 'reserved',
                'MultiDestination': 'multiDestination',
                'OptionLength': 'optionLength',
                'HopCount': 'hopCount',
                'EgressRBridge': 'egressRBridge',
                'IngressBridge': 'ingressBridge'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Trill | Stream=${Stream} | Level=0 | Version=3 |
    """

    result = renix.edit_header_trill(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

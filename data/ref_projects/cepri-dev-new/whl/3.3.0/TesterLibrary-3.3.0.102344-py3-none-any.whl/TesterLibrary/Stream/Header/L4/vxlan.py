import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_vxlan(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Vxlan报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vxlan头部在流量模板中所有vxlan头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Flags (bit): Flags，默认值：00001000，取值范围：长度为8的二进制数

        Reserved1 (int): Reserved，默认值：0，取值范围：0-16777215

        Vni (int): VXLAN Network Identifier，默认值：0，取值范围：0-16777215

        Reserved2 (int): Reserved，默认值：0，取值范围：0-255

    Returns:

        dict: eg::

            {
                'Flags': 'flags',
                'Reserved1': 'reserved1',
                'Vni': 'VNI',
                'Reserved2': 'reserved2',
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Vxlan | Stream=${Stream} | Level=0 | Vni=1000 |
    """

    result = renix.edit_header_vxlan(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure

def edit_header_els_flogi(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中ELS FLOGI报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ELS FLOGI头部在流量模板中所有ELS FLOGI头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        CommandCode (hex): ELS Command Code, 默认值：04000000，取值范围：长度为4字节的十六进制数

        FcPhVersion (hex): FC-PH Version - obsolete, 默认值：2020，取值范围：长度为2字节的十六进制数

        BtobCredit (int): Buffer-to-buffer Credit, 默认值：1，取值范围：0-65535

        CommonFeatures (hex): Common Features, 默认值：0000，取值范围：长度为2字节的十六进制数

        Bbscn (int): BB_SC_N, 默认值：0，取值范围：0-255

        BtobDataFieldSize (int): Buffer-to-Buffer Receive Data-Field Size, 默认值：0，取值范围：0-255

        Reserved (hex): Reserved, 默认值：0000000000000000，取值范围：长度为8字节的十六进制数

        PortName (hex): Port Name, 默认值：2000000000123010，取值范围：长度为8字节的十六进制数

        NodeName (hex): Node_ or Fabric_Name, 默认值：1000000000123010，取值范围：长度为8字节的十六进制数

        Class1serviceOptions (hex): Service Options, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class1InitatorControl (hex): Initiator Control, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class1recipientControl (hex): Recipient Control, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class1reserved1 (int): Reserved, 默认值：0，取值范围：0-16777215

        Class1totalConcurrentSeq (int): total Concurrent Sequence, 默认值：0，取值范围：0-255

        Class1Nx_Porte2eCredit (int): Nx_Port End-to-end Credit, 默认值：0，取值范围：0-65535

        Class1reserved2 (int): Reserved, 默认值：0，取值范围：0-255

        Class1openSeqPerExchange (int): Open Sequence Per Exchange, 默认值：0，取值范围：0-255

        Class1reserved3 (int): Reserved, 默认值：0，取值范围：0-65535

        Class2serviceOptions (hex): Service Options, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class2InitatorControl (hex): Initiator Control, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class2recipientControl (hex): Recipient Control, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class2reserved1 (int): Reserved, 默认值：0，取值范围：0-16777215

        Class2totalConcurrentSeq (int): total Concurrent Sequence, 默认值：0，取值范围：0-255

        Class2Nx_Porte2eCredit (int): Nx_Port End-to-end Credit, 默认值：0，取值范围：0-65535

        Class2reserved2 (int): Reserved, 默认值：0，取值范围：0-255

        Class2openSeqPerExchange (int): Open Sequence Per Exchange, 默认值：0，取值范围：0-255

        Class2reserved3 (int): Reserved, 默认值：0，取值范围：0-65535

        Class3serviceOptions (hex): Service Options, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class3InitatorControl (hex): Initiator Control, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class3recipientControl (hex): Recipient Control, 默认值：0000，取值范围：长度为2字节的十六进制数

        Class3reserved1 (int): Reserved, 默认值：0，取值范围：0-16777215

        Class3totalConcurrentSeq (int): total Concurrent Sequence, 默认值：0，取值范围：0-255

        Class3Nx_Porte2eCredit (int): Nx_Port End-to-end Credit, 默认值：0，取值范围：0-65535

        Class3reserved2 (int): Reserved, 默认值：0，取值范围：0-255

        Class3openSeqPerExchange (int): Open Sequence Per Exchange, 默认值：0，取值范围：0-255

        Class3reserved3 (int): Reserved, 默认值：0，取值范围：0-65535

        Obsolete (hex): Obsolete, 默认值：00000000000000000000000000000000，取值范围：长度为16字节的十六进制数

        VendorVersionLevel (hex): Vendor Version Level, 默认值：00000000000000000000000000000000，取值范围：长度为16字节的十六进制数

    Returns:

        dict: eg::

            {
                'CommandCode': 'commandCode',
                'FcPhVersion': 'commonSvcPara.fcPhVersion',
                'BtobCredit': 'commonSvcPara.btobCredit',
                'CommonFeatures': 'commonSvcPara.commonFeatures',
                'Bbscn': 'commonSvcPara.bbscn',
                'BtobDataFieldSize': 'commonSvcPara.btobDataFieldSize',
                'Reserved': 'commonSvcPara.reserved',
                'PortName': 'portName',
                'NodeName': 'nodeName',
                'Class1serviceOptions': 'class1SvcPara.serviceOptions',
                'Class1InitatorControl': 'class1SvcPara.Nx_Porte2eCredit',
                'Class1recipientControl': 'class1SvcPara.recipientControl',
                'Class1reserved1': 'class1SvcPara.reserved1',
                'Class1totalConcurrentSeq': 'class1SvcPara.totalConcurrentSeq',
                'Class1Nx_Porte2eCredit': 'class1SvcPara.serviceOptions',
                'Class1reserved2': 'class1SvcPara.reserved2',
                'Class1openSeqPerExchange': 'class1SvcPara.openSeqPerExchange',
                'Class1reserved3': 'class1SvcPara.reserved3',
                'Class2serviceOptions': 'class2SvcPara.serviceOptions',
                'Class2InitatorControl': 'class2SvcPara.Nx_Porte2eCredit',
                'Class2recipientControl': 'class2SvcPara.recipientControl',
                'Class2reserved1': 'class2SvcPara.reserved1,
                'Class2totalConcurrentSeq': 'class2SvcPara.totalConcurrentSeq',
                'Class2Nx_Porte2eCredit': 'class2SvcPara.serviceOptions',
                'Class2reserved2': 'class2SvcPara.reserved2',
                'Class2openSeqPerExchange': 'class2SvcPara.openSeqPerExchange',
                'Class2reserved3': 'class2SvcPara.reserved3',
                'Class3serviceOptions': 'class3SvcPara.serviceOptions',
                'Class3InitatorControl': 'class3SvcPara.Nx_Porte2eCredit',
                'Class3recipientControl': 'class3SvcPara.recipientControl',
                'Class3reserved1': 'class3SvcPara.reserved1',
                'Class3totalConcurrentSeq': 'class3SvcPara.totalConcurrentSeq',
                'Class3Nx_Porte2eCredit': 'class3SvcPara.serviceOptions',
                'Class3reserved2': 'class3SvcPara.reserved2',
                'Class3openSeqPerExchange': 'class3SvcPara.openSeqPerExchange',
                'Class3reserved3': 'class3SvcPara.reserved3',
                'Obsolete': 'obsolete',
                'VendorVersionLevel': 'vendorVersionLevel'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header ELS FLOGI | Stream=${Stream} | Level=0 | commandCode=10203040 |
    """

    result = renix.edit_header_els_flogi(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

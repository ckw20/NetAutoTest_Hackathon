import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Header ICMPv6-------------------------------------
def edit_header_icmpv6_destination_unreachable(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Destination Unreachable报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Destination Unreachable头部在流量模板中所有Icmpv6 Destination Unreachable头部的序列号

    Keyword Args:

        Type (int): Type，默认值：1，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Reserve (int): Unused，默认值：0，取值范围：0-4294967295

        HeaderData (hex): Data，默认值：0000000000000000，取值范围：长度为8字节的十六进制数

        Version (int): Version, 默认值：6，取值范围：0-15

        TrafficClass (int): Traffic Class, 默认值：0，取值范围：0-255

        FlowLabel (int): Flow Label, 默认值：0，取值范围：0-1048575

        PayloadLength (int): Payload Length, 默认值：0，取值范围：0-65535

        NextHeader (int): Next Header, 默认值：59，取值范围：0-255

        HopLimit (int): Hop Limit, 默认值：255，取值范围：0-255

        Source (str): Source Address, 默认值：2001::2，取值范围：有效的ipv6地址

        Destination (str): Destination Address, 默认值：2001::1:f1:11，取值范围：有效的ipv6地址

        Gateway (str): Gateway Address, 默认值：2001::1，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Reserve': 'reserve'
                'HeaderData': 'headerData.data',
                'Version': 'headerData.ipv6Header.version',
                'TrafficClass': 'headerData.ipv6Header.trafficClass',
                'FlowLabel': 'headerData.ipv6Header.FlowLabel',
                'PayloadLength': 'headerData.ipv6Header.payloadLength',
                'NextHeader': 'headerData.ipv6Header.nextHeader',
                'HopLimit': 'headerData.ipv6Header.hopLimit',
                'Source': 'headerData.ipv6Header.source',
                'Destination': 'headerData.ipv6Header.destination',
                'Gateway': 'headerData.ipv6Header.gateway'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | DestinationUnreachable |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Destination Unreachable | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmpv6_destinationunreachable(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_echo_reply(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Echo Reply报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Echo Reply头部在流量模板中所有Icmpv6 Echo Reply头部的序列号

    Keyword Args:

        Type (int): Type，默认值：129，取值范围：0-255

        Code (int): Code，默认值：1，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Identifier (int): Identifier，默认值：0，取值范围：0-65535

        SequenceNumber (int): Sequence Number，默认值：0，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Icmpv6EchoReply |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Echo Reply | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmpv6_echoreply(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_echo_request(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Echo Request报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Echo Request头部在流量模板中所有Icmpv6 Echo Request头部的序列号

    Keyword Args:

        Type (int): Type，默认值：128，取值范围：0-255

        Code (int): Code，默认值：1，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Identifier (int): Identifier，默认值：0，取值范围：0-65535

        SequenceNumber (int): Sequence Number，默认值：0，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Identifier': 'identifier',
                'SequenceNumber': 'sequenceNumber'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Icmpv6EchoRequest |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Echo Request | Stream=${Stream} | Level=0 | Identifier=100 |
    """

    result = renix.edit_header_icmpv6_echorequest(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_mldv1_done(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Mldv1 Done报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Mldv1 Done头部在流量模板中所有Icmpv6 Mldv1 Done头部的序列号

    Keyword Args:

        Type (int): Type，默认值：132，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        MaxRespDelay (int): Maximum Response Delay，默认值：0，取值范围：0-65535

        Reserved (int): Reserved，默认值：0，取值范围：0-65535

        MulticastAddress (str): Multicast Address，默认值：FF1E::1，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'MaxRespDelay': 'maxRespDelay',
                'Reserved': 'reserved',
                'MulticastAddress': 'multicastAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv1Done |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv1 Done | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_mldv1done(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_mldv1_query(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Mldv1 Query报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Mldv1 Query头部在流量模板中所有Icmpv6 Mldv1 Query头部的序列号

    Keyword Args:

        Type (int): Type，默认值：130，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        MaxRespDelay (int): Maximum Response Delay，默认值：0，取值范围：0-65535

        Reserved (int): Reserved，默认值：0，取值范围：0-65535

        MulticastAddress (str): Multicast Address，默认值："::"，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'MaxRespDelay': 'maxRespDelay',
                'Reserved': 'reserved',
                'MulticastAddress': 'multicastAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv1Query |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv1 Query | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_mldv1query(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_mldv1_report(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Mldv1 Report报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Mldv1 Report头部在流量模板中所有Icmpv6 Mldv1 Report头部的序列号

    Keyword Args:

        Type (int): Type，默认值：131，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        MaxRespDelay (int): Maximum Response Delay，默认值：0，取值范围：0-65535

        Reserved (int): Reserved，默认值：0，取值范围：0-65535

        MulticastAddress (str): Multicast Address，默认值：FF1E::1，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'MaxRespDelay': 'maxRespDelay',
                'Reserved': 'reserved',
                'MulticastAddress': 'multicastAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv1Report |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv1 Report | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_mldv1report(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_mldv2_query(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Mldv2 Query报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Mldv2 Query头部在流量模板中所有Icmpv6 Mldv2 Query头部的序列号

    Keyword Args:

        Type (int): Type，默认值：130，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        MaxRespCode (int): Maximum Response Code，默认值：0，取值范围：0-65535

        Reserved (int): Reserved，默认值：0，取值范围：0-65535

        GroupAddress (str): Multicast Address，默认值：FF1E::1，取值范围：有效的ipv6地址

        Resv (int): Reserved，默认值：0，取值范围：0-15

        Sflag (bit): Suppress Flag，默认值：1，取值范围：0-1

        Qrv (bit): QRV，默认值：000，取值范围：000-111

        Qqic (int): QQIC，默认值：0，取值范围：0-255

        NumberOfSources (int): Number of Sources，默认值：0，取值范围：0-65535

        SourceAddressList (list): Source Address List，默认值：2000::1，取值范围：有效的ipv6地址，列表长度0-1000

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'MaxRespDelay': 'maxRespDelay',
                'Reserved': 'reserved',
                'GroupAddress': 'groupAddress',
                'Resv': 'resv',
                'Sflag': 'sFlag',
                'Qrv': 'qrv',
                'Qqic': 'qqic',
                'NumberOfSources': 'numberOfSources',
                'SourceAddressList': 'sourceAddressList'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv2Query |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv2 Query | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_mldv2query(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_mldv2_report(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Mldv2 Report报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Mldv2 Report头部在流量模板中所有Icmpv6 Mldv2 Report头部的序列号

    Keyword Args:

        Type (int): Type，默认值：143，取值范围：0-255

        Unused (int): Unused，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Reserved (int): Reserved，默认值：0，取值范围：0-65535

        NumberOfGroupRecords (int): Number of Group Records，默认值：0，取值范围：0-65535

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Unused': 'unused',
                'Checksum': 'checksum',
                'Reserved': 'reserved',
                'NumberOfGroupRecords': 'numberOfGroupRecords'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv2Report |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv2 Report | Stream=${Stream} | Level=0 | Type=1 |
    """

    result = renix.edit_header_icmpv6_mldv2report(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_group_records(Stream, Level=0, Index=0, Header='mldv2report', **kwargs):
    """
    修改测试仪表流量模板中ICMPv6 Mldv2 Report报文头部Group Records内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的ICMPv6头部在流量模板中所有IGMPv3头部的序列号

        Index: 要修改的ICMPv6 Group Records头部在流量模板中所有ICMPv6 Group Records的序列号

        Header: 要修改的流量头部，默认修改mldv2report头部对象，其他对象包括：

            mldv2report

        Keyword Args:

            RecordType (int): MLDv2RecordType，默认值：1，取值范围：0-255

            AuxDataLen (int): Auxiliary Data Length，默认值：0，取值范围：0-255

            NumberOfSources (int): Number of Sources，默认值：0，取值范围：0-65535

            MulticastAddress (str): Multicast Address，默认值：FF1E::1，取值范围：有效的ipv6地址

            SourceAddressList (list): Source Address List，默认值：2000::1，取值范围：有效的ipv6地址，列表长度0-1000

    Returns:

        dict: eg::

            {
                'RecordType': 'groupRecords.groupRecord_0.recordType',
                'AuxDataLen': 'groupRecords.groupRecord_0.auxDataLen',
                'NumberOfSources': 'groupRecords.groupRecord_0.numberOfSources',
                'MulticastAddress': 'groupRecords.groupRecord_0.multicastAddress',
                'SourceAddressList: 2002::1': 'groupRecords.groupRecord_0.sourceAddressList.ipv6AddrContainer_0.ipv6Addr',
                'SourceAddressList: 2003::1': 'groupRecords.groupRecord_0.sourceAddressList.ipv6AddrContainer_1.ipv6Addr'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv2Report |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv2 Report | Stream=${Stream} | Level=0 | Type=1 |
            | Edit Header Icmpv6 Group Records | Stream=${Stream} | recordType=10 |
    """

    result = renix.edit_header_icmpv6_group_records(Stream=Stream, Level=Level, Index=Index, Header=Header,
                                                       **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_packet_too_big(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Packet Too Big报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Packet Too Big头部在流量模板中所有Icmpv6 Packet Too Big头部的序列号

    Keyword Args:

        Type (int): Type，默认值：1，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Mtu (int): MTU，默认值：0，取值范围：0-4294967295

        HeaderData (hex): Data，默认值：0000000000000000，取值范围：长度为8字节的十六进制数

        Version (int): Version, 默认值：6，取值范围：0-15

        TrafficClass (int): Traffic Class, 默认值：0，取值范围：0-255

        FlowLabel (int): Flow Label, 默认值：0，取值范围：0-1048575

        PayloadLength (int): Payload Length, 默认值：0，取值范围：0-65535

        NextHeader (int): Next Header, 默认值：59，取值范围：0-255

        HopLimit (int): Hop Limit, 默认值：255，取值范围：0-255

        Source (str): Source Address, 默认值：2001::2，取值范围：有效的ipv6地址

        Destination (str): Destination Address, 默认值：2001::1:f1:11，取值范围：有效的ipv6地址

        Gateway (str): Gateway Address, 默认值：2001::1，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Mtu': 'mtu',
                'HeaderData': 'headerData.data',
                'Version': 'headerData.ipv6Header.version',
                'TrafficClass': 'headerData.ipv6Header.trafficClass',
                'FlowLabel': 'headerData.ipv6Header.FlowLabel',
                'PayloadLength': 'headerData.ipv6Header.payloadLength',
                'NextHeader': 'headerData.ipv6Header.nextHeader',
                'HopLimit': 'headerData.ipv6Header.hopLimit',
                'Source': 'headerData.ipv6Header.source',
                'Destination': 'headerData.ipv6Header.destination',
                'Gateway': 'headerData.ipv6Header.gateway'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | PacketTooBig |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Packet Too Big | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_packettoobig(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_parameter_problem(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Parameter Problem报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Parameter Problem头部在流量模板中所有Icmpv6 Parameter Problem头部的序列号

    Keyword Args:

        Type (int): Type，默认值：4，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Pointer (hex): Pointer，默认值：00000000，取值范围：长度为4字节的十六进制数

        HeaderData (hex): Data，默认值：0000000000000000，取值范围：长度为8字节的十六进制数

        Version (int): Version, 默认值：6，取值范围：0-15

        TrafficClass (int): Traffic Class, 默认值：0，取值范围：0-255

        FlowLabel (int): Flow Label, 默认值：0，取值范围：0-1048575

        PayloadLength (int): Payload Length, 默认值：0，取值范围：0-65535

        NextHeader (int): Next Header, 默认值：59，取值范围：0-255

        HopLimit (int): Hop Limit, 默认值：255，取值范围：0-255

        Source (str): Source Address, 默认值：2001::2，取值范围：有效的ipv6地址

        Destination (str): Destination Address, 默认值：2001::1:f1:11，取值范围：有效的ipv6地址

        Gateway (str): Gateway Address, 默认值：2001::1，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Reserve': 'reserve'
                'HeaderData': 'headerData.data',
                'Version': 'headerData.ipv6Header.version',
                'TrafficClass': 'headerData.ipv6Header.trafficClass',
                'FlowLabel': 'headerData.ipv6Header.FlowLabel',
                'PayloadLength': 'headerData.ipv6Header.payloadLength',
                'NextHeader': 'headerData.ipv6Header.nextHeader',
                'HopLimit': 'headerData.ipv6Header.hopLimit',
                'Source': 'headerData.ipv6Header.source',
                'Destination': 'headerData.ipv6Header.destination',
                'Gateway': 'headerData.ipv6Header.gateway'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Icmpv6ParameterProblem |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Parameter Problem | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_parameterproblem(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_time_exceed(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Time Exceed报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Time Exceed头部在流量模板中所有Icmpv6 Time Exceed头部的序列号

    Keyword Args:

        Type (int): Type，默认值：3，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Reserve (int): Unused，默认值：0，取值范围：0-4294967295

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Reserve': 'reserve'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | TimeExceed |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Time Exceed | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_timeexceed(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_router_solicitation(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Router Solicitation报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Router Solicitation头部在流量模板中所有Icmpv6 Router Solicitation头部的序列号

    Keyword Args:

        Type (int): Type，默认值：133，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Reserve (int): Reserved，默认值：0，取值范围：0-4294967295

        HeaderOption (list): Header Option，默认值：""，取值范围：

            OptionSourceLinkLayerAddress

            OptionTargetLinkLayerAddress

            OptionPrefixInformation

            OptionMTU

            GeneralTLV

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Reserve': 'reserve'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | routersolicit |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Router Solicitation | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_routersolicitation(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_header_option(Stream, Option, Level=0, Index=0, Header='routersolicit', **kwargs):
    """
    修改测试仪表流量模板中ICMPv6报文头部Header Option内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Option: ICMPv6报文头部Header Option类型, 类型为：string, 支持的类型包括：

            OptionSourceLinkLayerAddress

            OptionTargetLinkLayerAddress

            OptionPrefixInformation

            OptionMTU

            GeneralTLV

        Level: 要修改的ICMPv6头部在流量模板中所有IGMPv3头部的序列号

        Index: 要修改的ICMPv6 Header Option头部在流量模板中所有ICMPv6 Header Option的序列号

        Header: 要修改的流量头部，默认修改mldv2report头部对象，其他对象包括：

            routersolicit

            routeradvertise

            icmpv6redirect

            neighborsolicit

            neighboradvertise

        Keyword Args:

            OptionSourceLinkLayerAddress支持:

                Type (int): Option Type，默认值：1，取值范围：0-255

                Length (int): Option Length，默认值：<AUTO>1，取值范围：0-255

                Address (str): Link-Layer Address，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

            OptionTargetLinkLayerAddress支持:

                Type (int): Option Type，默认值：2，取值范围：0-255

                Length (int): Option Length，默认值：<AUTO>1，取值范围：0-255

                Address (str): Link-Layer Address，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

            OptionPrefixInformation支持:

                Type (int): Option Type，默认值：3，取值范围：0-255

                Length (int): Option Length，默认值：<AUTO>1，取值范围：0-255

                PrefixLength (int): Prefix Length，默认值：64，取值范围：0-255

                OnLinkFlag (bit): On-Link Flag，默认值：1，取值范围：0-1

                AutonomousFlag (bit): Autonomous Flag，默认值：1，取值范围：0-1

                Reserved (bit): Reserved，默认值：000000，取值范围：000000-111111

                ValidLifetime (int): Valid Lifetime，默认值：1，取值范围：0-4294967295

                PreferredLifetime (int): Valid Lifetime，默认值：1，取值范围：0-4294967295

                Reserved2 (int): Reserved，默认值：1，取值范围：0-4294967295

                PrefixAddress (str): Prefix，默认值：2001::0，取值范围：有效的ipv6地址

            OptionMTU支持:

                Type (int): Option Type，默认值：5，取值范围：0-255

                Length (int): Option Length，默认值：<AUTO>1，取值范围：0-255

                Reserved3 (int): Reserved，默认值：1，取值范围：0-65535

                Mtu (int): MTU，默认值：1000，取值范围：0-4294967295

            GeneralTLV支持:

                Type (int): Option Type，默认值：0，取值范围：0-255

                Length (int): Option Length，默认值：<AUTO>2，取值范围：0-255

                Value (hex): Option Value，默认值：""，取值范围：长度0-40字节的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.type',
                'Length': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.length',
                'PrefixLength': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.prefixLength',
                'OnLinkFlag': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.onLinkFlag',
                'AutonomousFlag': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.autonomousFlag',
                'Reserved': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.reserved',
                'ValidLifetime': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.validLifetime',
                'PreferredLifetime': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.preferredLifetime',
                'Reserved2': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.reserved2',
                'PrefixAddress': 'option.icmpv6HeaderOptionList_2.optionPrefixInformation.prefixAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv2Report |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv2 Report | Stream=${Stream} | Level=0 | Type=1 |
            | Edit Header Icmpv6 Group Records | Stream=${Stream} | recordType=10 |
    """

    result = renix.edit_header_icmpv6_header_option(Stream=Stream, Option=Option, Level=Level, Index=Index,
                                                       Header=Header, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_router_advertise(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Router Advertise报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Router Advertise头部在流量模板中所有Icmpv6 Router Advertise头部的序列号

    Keyword Args:

        Type (int): Type，默认值：134，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        CurHopLimit (int): Current Hop Limit，默认值：0，取值范围：0-255

        ManagedAddrFlag (bit): Managed Address Flag，默认值：0，取值范围：0-1

        OtherConfigFlag (bit): Other Stateful Config Flag，默认值：0，取值范围：0-1

        Reserved (bit): Reserved，默认值：000000，取值范围：00000-11111

        RouterLifetime (int): Router Lifetime，默认值：0，取值范围：0-65535

        ReachableTime (int): Reachable Time，默认值：0，取值范围：0-4294967295

        RetransTime (int): Retrans Time，默认值：0，取值范围：0-4294967295

        HeaderOption (list): Header Option，默认值：""，取值范围：

            OptionSourceLinkLayerAddress

            OptionTargetLinkLayerAddress

            OptionPrefixInformation

            OptionMTU

            GeneralTLV

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'CurHopLimit': 'curHopLimit',
                'ManagedAddrFlag': 'managedAddrFlag',
                'OtherConfigFlag': 'otherConfigFlag',
                'Reserved': 'reserved',
                'RouterLifetime': 'routerLifetime',
                'ReachableTime': 'reachableTime',
                'RetransTime': 'retransTime',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | routeradvertise |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Router Advertise | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_routeradvertise(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_redirect(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Redirect报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Redirect头部在流量模板中所有Icmpv6 Redirect头部的序列号

    Keyword Args:

        Type (int): Type，默认值：137，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Reserve (int): Reserved，默认值：0，取值范围：0-4294967295

        TargetAddress (str): Target Address，默认值：2001::1:f1:11，取值范围：有效的ipv6地址

        DestAddress (str): Destination Address，默认值：2001::1:f1:11，取值范围：有效的ipv6地址

        HeaderOption (list): Target Link-Layer Address，默认值：""，取值范围：

            OptionSourceLinkLayerAddress

            OptionTargetLinkLayerAddress

            OptionPrefixInformation

            OptionMTU

            GeneralTLV

        RedirectedHdrOption (int): Redirect Header数量，默认值：“”，取值范围：0-1

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Reserved': 'reserved',
                'TargetAddress': 'targetAddress',
                'DestAddress': 'destAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Icmpv6Redirect |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Redirect | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_redirect(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_redirected_header(Stream, Level=0, Index=0, Header='icmpv6redirect', **kwargs):
    """
    修改测试仪表流量模板中ICMPv6 Redirected报文头部Header内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的ICMPv6头部在流量模板中所有IGMPv3头部的序列号

        Index: 要修改的ICMPv6 Redirected Header头部在流量模板中所有ICMPv6 Redirected Header的序列号

        Header: 要修改的流量头部，默认修改icmpv6redirect头部对象，支持对象包括：

            icmpv6redirect

        Keyword Args:

            Type (int): Option Type，默认值：4, 取值范围：

                Source Link-Layer Address：1

                Target Link-Layer Address：2

                Prefix Information：3

                Redirected Header：4

                MTU：5

            Length (int): Option Length，默认值：4, 取值范围：0-255

            Reserved1 (int): Reserved1，默认值：0, 取值范围：0-65535

            Reserved2 (int): Reserved2，默认值：0, 取值范围：0-4294967295

            Data (hex): Data，默认值：0000000000000000，取值范围：长度为8字节的十六进制数

            Version (int): Version, 默认值：6，取值范围：0-15

            TrafficClass (int): Traffic Class, 默认值：0，取值范围：0-255

            FlowLabel (int): Flow Label, 默认值：0，取值范围：0-1048575

            PayloadLength (int): Payload Length, 默认值：0，取值范围：0-65535

            NextHeader (int): Next Header, 默认值：59，取值范围：0-255

            HopLimit (int): Hop Limit, 默认值：255，取值范围：0-255

            Source (str): Source Address, 默认值：2001::2，取值范围：有效的ipv6地址

            Destination (str): Destination Address, 默认值：2001::1:f1:11，取值范围：有效的ipv6地址

            Gateway (str): Gateway Address, 默认值：2001::1，取值范围：有效的ipv6地址

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Reserve': 'reserve'
                'HeaderData': 'headerData.data',
                'Version': 'headerData.ipv6Header.version',
                'TrafficClass': 'headerData.ipv6Header.trafficClass',
                'FlowLabel': 'headerData.ipv6Header.FlowLabel',
                'PayloadLength': 'headerData.ipv6Header.payloadLength',
                'NextHeader': 'headerData.ipv6Header.nextHeader',
                'HopLimit': 'headerData.ipv6Header.hopLimit',
                'Source': 'headerData.ipv6Header.source',
                'Destination': 'headerData.ipv6Header.destination',
                'Gateway': 'headerData.ipv6Header.gateway'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | Mldv2Report |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Mldv2 Report | Stream=${Stream} | Level=0 | Type=1 |
            | Edit Header Icmpv6 Redirected Header | Stream=${Stream} | type=1 |
    """

    result = renix.edit_header_icmpv6_redirected_header(Stream=Stream, Level=Level, Index=Index, Header=Header,
                                                           **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_icmpv6_neighbor_advertise(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Neighbor Advertise报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Neighbor Advertise头部在流量模板中所有Icmpv6 Neighbor Advertise头部的序列号

    Keyword Args:

        Type (int): Type，默认值：136，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Rflag (bit): Route Flag，默认值：0，取值范围：0-1

        Sflag (bit): Solicited Flag，默认值：0，取值范围：0-1

        Oflag (bit): Override Flag，默认值：0，取值范围：0-1

        Reserve (int): Reserved，默认值：0，取值范围：0-536870911

        TargetAddress (str): Target Address，默认值：2001::1，取值范围：有效的ipv6地址

        HeaderOption (list): Target Link-Layer Address，默认值：""，取值范围：

            OptionSourceLinkLayerAddress

            OptionTargetLinkLayerAddress

            OptionPrefixInformation

            OptionMTU

            GeneralTLV

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Rflag': 'rFlag',
                'Sflag': 'sFlag',
                'Oflag': 'oFlag',
                'Reserve': 'reserve',
                'TargetAddress': 'targetAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | NeighborAdvertise |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Neighbor Advertise | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_neighboradvertise(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message='{} Failure'.format(sys._getframe().f_code.co_name))
    else:
        return result


def edit_header_icmpv6_neighbor_solicitation(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Icmpv6 Neighbor Solicitation报文头部内容

    Args:

        Stream: 测试仪表流量对象object, 类型为：object

        Level: 要修改的Icmpv6 Neighbor Solicitation头部在流量模板中所有Icmpv6 Neighbor Solicitation头部的序列号

    Keyword Args:

        Type (int): Type，默认值：135，取值范围：0-255

        Code (int): Code，默认值：0，取值范围：0-255

        Checksum (hex): Checksum，默认值：0000，取值范围：0000-FFFF

        Reserve (int): Reserved，默认值：0，取值范围：0-4294967295

        TargetAddress (str): Target Address，默认值：2001::1，取值范围：有效的ipv6地址

        HeaderOption (list): Target Link-Layer Address，默认值：""，取值范围：

            OptionSourceLinkLayerAddress

            OptionTargetLinkLayerAddress

            OptionPrefixInformation

            OptionMTU

            GeneralTLV

    Returns:

        dict: eg::

            {
                'Type': 'type',
                'Code': 'code',
                'Checksum': 'checksum',
                'Reserve': 'reserve',
                'TargetAddress': 'targetAddress'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv6 | NeighborSolicitation |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Icmpv6 Neighbor Solicitation | Stream=${Stream} | Level=0 | Code=1 |
    """

    result = renix.edit_header_icmpv6_neighborsolicitation(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

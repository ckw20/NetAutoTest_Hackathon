import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure

def edit_header_hdlc(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Hdlc报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Hdlc头部在流量模板中所有Hdlc头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        Address (hex): Value, 默认值：0F，取值范围：00-FF

        Value (hex): Value, 默认值：00，取值范围：00-FF

        Protocol (hex): Value, 默认值：0800，取值范围：

            0800: IP

            0281: MPLS

            0: Custom

    Returns:

        dict: eg::

            {
                'Address': 'address',
                'Value': 'value',
                'Protocol': 'protocol'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Hdlc | Stream=${Stream} | Level=0 | Address=FF |
    """

    result = renix.edit_header_hdlc(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

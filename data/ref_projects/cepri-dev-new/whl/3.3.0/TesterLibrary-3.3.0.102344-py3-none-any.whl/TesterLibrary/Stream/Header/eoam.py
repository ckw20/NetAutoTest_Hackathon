import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure

def edit_header_eoam(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        MDlevel (int): RDI Field, 默认值：0，取值范围：0-7

        Version (int): Version, 默认值：00000，取值范围：0-31

        OpCode (hex): OpCode, 默认值：01，取值范围：长度为1byte的十六进制数

        RDIbit (int): RDI Field, 默认值：0，取值范围：

            0: zero

            1: one

        Reserved (bit): Reserved, 默认值：0000，取值范围：0-15

        CCMIntervalField (int): CCM Interval, 默认值：4，取值范围：

            0: invalid

            1: 3 1/3 ms

            2: 10 ms

            3: 100 ms

            4: 1 s

            5: 10 s

            6: 1 min

            7: 10 min

        FirstTLVOffset (hex): First TLV Offset, 默认值：46，取值范围：00-FF

        SequenceNumber (int): Sequence Number, 默认值：0，取值范围：0-4294967295

        MAEPI (int): Maintenance Assoc. End Point Ident, 默认值：0，取值范围：0-8191

        MDNF (hex): Maintenance Domain Name Format, 默认值：01，取值范围：

            00：Reserved for IEEE 802.1 (00)

            01：No Maintenance Domain Name Present

            02：Domain Name Based String

            03：MAC address + 2-octet Integer

            04：Character String

            05：Reserved for IEEE 802.1 (05)

            20：Defined by ITU-T Y.1731

            40：Reserved for IEEE 802.1 (64)

        MDNL (hex): Maintenance Domain Name Length, 默认值：<AUTO>00，取值范围：00-FF

        MDN (hex): Maintenance Domain Name, 默认值：00，取值范围：长度为0-255字节的十六进制数

        SMAF (hex): Short MA Name, 默认值：01，取值范围：00-FF

        SMAL (hex): Short MA Name Length, 默认值：01，取值范围：00-FF

        SMAN (hex): Short MA Name, 默认值：00，取值范围：长度为1-255字节的十六进制数

        Padding (hex): padding, 默认值：00，取值范围：长度为0-48字节的十六进制数

        ITUTY1731 (hex): ITU-T Recommendation Y.1731, 默认值：00000000000000000000000000000000，取值范围：长度为16字节的十六进制数

        Tlvs (list): 要插入的tlv类型，默认值：[], 取值范围：

            SenderIDTLV: SenderID TLV

            PortStatusTLV: Port Status TLV

            InterfaceStatusTLV: Interface Status TLV

            OrgSpecTLV: Organaization-Specific TLV

            EndTLV: End TLV

    Returns:

        dict: eg::

            {
                'MDlevel': 'cfmHeader.MDlevel',
                'Version': 'cfmHeader.Version',
                'OpCode': 'OpCode',
                'RDIbit': 'RDIbit',
                'Reserved': 'Reserved',
                'CCMIntervalField': 'CCMIntervalField',
                'FirstTLVOffset': 'FirstTLVOffset',
                'SequenceNumber': 'SequenceNumber',
                'MAEPI': 'MAEPI',
                'MDNF': 'MAID.MDNF',
                'MDNL': 'MAID.theMDNL.MDNLength_0.MDNL',
                'MDN': 'MAID.theMDN.MaintenanceDomainName_0.MDN',
                'SMAF': 'MAID.SMAF',
                'SMAL': 'MAID.SMAL',
                'SMAN': 'MAID.SMAN',
                'Padding': 'MAID.thePad.Padding_0.Pad',
                'ITUTY1731': 'ITU-TY1731'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Eoam | Stream=${Stream} | Level=0 | MDlevel=7 |
    """

    result = renix.edit_header_eoam(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_eoam_sender_id_tlv(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部的Sender Id Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号

        Index (int): 要修改的Eoam报文头部的Sender Id Tlv在流量模板中所有Eoam报文头部的Sender Id Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：01，取值范围：长度为1byte的十六进制数

        Length (hex): Length, 默认值：0000，取值范围：长度为2byte的十六进制数

        ChassisIDLen (hex): Chassis ID Length, 默认值：00，取值范围：长度为1byte的十六进制数

        TheChassisID (str): Chassis ID, 默认值：“”，取值范围：

            ChassisComponent

            InterfaceAlias

            PortComponent

            MacAddress

            NetworkAddress4

            NetworkAddress6

            InterfaceName

            LocallyAssigned

            Custom

        TheManagementAddressDomain (str): Management Address Domain, 默认值：“”，取值范围：

            MADtDU4

            MADtDU6

            MADtDU4z

            MADtDU6z

            MADtDT4

            MADtDT6

            MADtDT4z

            MADtDT6z

            MADtDS4

            MADtDS6

            MADtDS4z

            MADtDS6z

            MADtDL

            MADtDU

            MADtTU

            MADtSU

            MADsI802

            MADCustom

    Returns:

        dict: eg::

            {
                'Type': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.Type',
                'Length': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.Length',
                'ChassisIDLen': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.ChassisIDLen'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=ccm |
            | Edit Header Eoam | Stream=${Stream} | Level=0 | Tlvs=SenderIDTLV |
            | Edit Header Eoam Sender Id Tlv | Stream=${Stream} | Level=0 | Index=0 | Type=FF |
    """

    result = renix.edit_header_eoam_sender_id_tlv(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_eoam_sender_id_tlv_chassis_id(Stream, Type, Level=0, TlvIndex=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部的Sender Id Tlv中的chassis id内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Type (str): 要修改的Eoam报文头部的Sender Id Tlv的chassis id的类型，取值范围：

            ChassisComponent

            InterfaceAlias

            PortComponent

            MacAddress

            NetworkAddress4

            NetworkAddress6

            InterfaceName

            LocallyAssigned

            Custom

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号

        TlvIndex (int): 要修改的Eoam报文头部的Sender Id Tlv在流量模板中所有Eoam报文头部的Sender Id Tlv的序列号

        Index (int): 要修改的Eoam报文头部的Sender Id Tlv的chassis id在流量模板中所有Eoam报文头部的Sender Id Tlv的chassis id的序列号

    Keyword Args:

        Chassis Component：

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：01，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            ChassisID (str): Chassis ID, 默认值：'XINERTEL'，取值范围：长度为1-64的字符

        Interface Alias：

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：02，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            ChassisID (str): Chassis ID, 默认值：'XINERTEL'，取值范围：长度为1-128的字符

        Port Component：

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：03，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            ChassisID (str): Chassis ID, 默认值：'XINERTEL'，取值范围：长度为1-64的字符

        MAC Address：

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：04，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            ChassisID (str): Chassis ID, 默认值：'00:00:00:00:00:00'，取值范围：有效的mac地址

        Network Address IPv4：

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：04，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            IanaFamilyNumber (hex): IANA Family Number, 默认值：01，取值范围：00-FF

            ChassisID (str): Chassis ID, 默认值：'0.0.0.0'，取值范围：有效的mac地址

        Network Address IPv6：

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：05，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            IanaFamilyNumber (hex): IANA Family Number, 默认值：02，取值范围：00-FF

            ChassisID (str): Chassis ID, 默认值：'::0'，取值范围：有效的mac地址

        Interface Name:

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：06，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            ChassisID (str): Chassis ID, 默认值：'XINERTEL'，取值范围：长度为1-255的字符

        Locally Assigned:

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：07，取值范围：

                01: Chassis Component

                02: Interface Alias

                03: Port Component

                04: MAC Address

                05: Network Address

                06: Interface Name

                07: Locally Assigned

            ChassisID (str): Chassis ID, 默认值：'XINERTEL'，取值范围：长度为1-255的字符

        Custom:

            ChassisIDSubtype (hex): Chassis ID Subtype, 默认值：00，取值范围：00-FF

            ChassisID (hex): Chassis ID, 默认值：00，取值范围：长度为1-255的十六进制

    Returns:

        dict: eg::

            {
                'ChassisIDSubtype': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.theChassisID.ChassisIDList_0.ChassisComponent.ChassisIDSubtype',
                'ChassisID': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.theChassisID.ChassisIDList_0.ChassisComponent.ChassisID',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=ccm |
            | Edit Header Eoam | Stream=${Stream} | Level=0 | Tlvs=SenderIDTLV |
            | Edit Header Eoam Sender Id Tlv | Stream=${Stream} | Level=0 | TlvIndex=0 | Index=0 | ChassisID=FF |
    """

    result = renix.edit_header_eoam_sender_id_tlv_chassis_id(Stream=Stream, Type=Type, Level=Level, TlvIndex=TlvIndex, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_eoam_sender_id_tlv_management_address_domain(Stream, Type, Level=0, TlvIndex=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部的Sender Id Tlv中的management address domain内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Type (str): 要修改的Eoam报文头部的Sender Id Tlv的management address domain的类型，取值范围：

            MADtDU4

            MADtDU6

            MADtDU4z

            MADtDU6z

            MADtDT4

            MADtDT6

            MADtDT4z

            MADtDT6z

            MADtDS4

            MADtDS6

            MADtDS4z

            MADtDS6z

            MADtDL

            MADtDU

            MADtTU

            MADtSU

            MADsI802

            MADCustom

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号

        TlvIndex (int): 要修改的Eoam报文头部的Sender Id Tlv在流量模板中所有Eoam报文头部的Sender Id Tlv的序列号

        Index (int): 要修改的Eoam报文头部的Sender Id Tlv的management address domain在流量模板中所有Eoam报文头部的Sender Id Tlv的management address domain的序列号

    Keyword Args:

        MADtDU4:

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640101，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：06，取值范围：00-FF

            IPv4 (str): IPv4 Address, 默认值：0.0.0.0，取值范围：有效的ipv4地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDU6:

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640102，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：12，取值范围：00-FF

            IPv6 (str): IPv6 Address, 默认值：::0，取值范围：有效的ipv6地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDU4z

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640103，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：0A，取值范围：00-FF

            IPv4 (str): IPv4 Address, 默认值：0.0.0.0，取值范围：有效的ipv4地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDU6z

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640104，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：16，取值范围：00-FF

            IPv6 (str): IPv6 Address, 默认值：::0，取值范围：有效的ipv6地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDT4

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640105，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：06，取值范围：00-FF

            IPv4 (str): IPv4 Address, 默认值：0.0.0.0，取值范围：有效的ipv4地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDT6

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640106，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：12，取值范围：00-FF

            IPv6 (str): IPv6 Address, 默认值：::0，取值范围：有效的ipv6地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDT4z

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640107，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：0A，取值范围：00-FF

            IPv4 (str): IPv4 Address, 默认值：0.0.0.0，取值范围：有效的ipv4地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDT6z

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640108，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：16，取值范围：00-FF

            IPv6 (str): IPv6 Address, 默认值：::0，取值范围：有效的ipv6地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDS4

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640109，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：06，取值范围：00-FF

            IPv4 (str): IPv4 Address, 默认值：0.0.0.0，取值范围：有效的ipv4地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDS6

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b0601020164010A，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：12，取值范围：00-FF

            IPv6 (str): IPv6 Address, 默认值：::0，取值范围：有效的ipv6地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDS4z

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b0601020164010B，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：0A，取值范围：00-FF

            IPv4 (str): IPv4 Address, 默认值：0.0.0.0，取值范围：有效的ipv4地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDS6z

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b0601020164010C，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：16，取值范围：00-FF

            IPv6 (str): IPv6 Address, 默认值：::0，取值范围：有效的ipv6地址

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDL

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b0601020164010D，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：00，取值范围：00-FF

            Name (str): Name, 默认值：XINERTEL，取值范围：1-255长度的字符串

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtDU

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b0601020164010E，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：00，取值范围：00-FF

            Name (str): Name, 默认值：XINERTEL，取值范围：1-255长度的字符串

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtTU

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b0601020164010F，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：00，取值范围：00-FF

            Name (str): Name, 默认值：XINERTEL，取值范围：1-255长度的字符串

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADtSU

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640110，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：00，取值范围：00-FF

            Name (str): Name, 默认值：XINERTEL，取值范围：1-255长度的字符串

            Port (hex): Port, 默认值：0000，取值范围：0000-FFFF

        MADsI802

            MADL (hex): Management Address Domain Length, 默认值：08，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：2b06010201640110，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：00，取值范围：00-FF

            ManAdd (str): Management Address, 默认值：00:00:00:00:00:00，取值范围：有效的mac地址

        MADCustom

            MADL (hex): Management Address Domain Length, 默认值：00，取值范围：00-FF

            MAD (hex): Management Address Domain, 默认值：00，取值范围：长度0-255字节的十六进制数

            MAL (hex): Management Address Length, 默认值：00，取值范围：00-FF

            ManAdd (hex): Management Address, 默认值：00，取值范围：长度0-255字节的十六进制数

    Returns:

        dict: eg::

            {
                'MADL': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.theManagementAddressDomain.MADList_0.MADtDU4.MADL',
                'MAD': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.theManagementAddressDomain.MADList_0.MADtDU4.MAD',
                'MAL': 'theCCMTLVS.CCMTLVList_0.SenderIDTLV.theManagementAddressDomain.MADList_0.MADtDU4.MAL'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=ccm |
            | Edit Header Eoam | Stream=${Stream} | Level=0 | Tlvs=SenderIDTLV |
            | Edit Header Eoam Sender Id Tlv | Stream=${Stream} | Level=0 | TlvIndex=0 | Index=0 | ChassisID=FF |
            | Edit Header Eoam Sender Id Tlv Management Address Domain | Stream=${Stream} | Type=MADCustom | Level=0 | TlvIndex=0 | Index=0 | MADL=FF |
    """

    result = renix.edit_header_eoam_sender_id_tlv_management_address_domain(
        Stream=Stream, Type=Type, Level=Level, TlvIndex=TlvIndex, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_eoam_port_status_tlv(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部的Port Status Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号

        Index (int): 要修改的Eoam报文头部的Port Status Tlv在流量模板中所有Eoam报文头部的Port Status Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：02，取值范围：长度为1byte的十六进制数

        Length (hex): Length, 默认值：<AUTO>，取值范围：长度为2byte的十六进制数

        PortStatusValues (hex): Port Status, 默认值：01，取值范围：

            01: Blocked

            02: Up

    Returns:

        dict: eg::

            {
                'Type': 'theCCMTLVS.CCMTLVList_0.PortStatusTLV.Type',
                'Length': 'theCCMTLVS.CCMTLVList_0.PortStatusTLV.Length',
                'PortStatusValues': 'theCCMTLVS.CCMTLVList_0.PortStatusTLV.PortStatusValues'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=ccm |
            | Edit Header Eoam | Stream=${Stream} | Level=0 | Tlvs=SenderIDTLV |
            | Edit Header Eoam Port Status Tlv | Stream=${Stream} | Level=0 | Index=0 | Type=FF |
    """

    result = renix.edit_header_eoam_port_status_tlv(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_eoam_interface_status_tlv(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部的Interface Status Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号

        Index (int): 要修改的Eoam报文头部的Interface Status Tlv在流量模板中所有Eoam报文头部的Interface Status Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：04，取值范围：长度为1byte的十六进制数

        Length (hex): Length, 默认值：<AUTO>，取值范围：长度为2byte的十六进制数

        IntStatusValues (hex): Port Status, 默认值：01，取值范围：

            01: Up

            02: Down

            03: Testing

            04: Unknown

            05: Dormant

            06: notPresent

            07: lowerLayerDown

    Returns:

        dict: eg::

            {
                'Type': 'theCCMTLVS.CCMTLVList_0.InterfaceStatusTLV.Type',
                'Length': 'theCCMTLVS.CCMTLVList_0.InterfaceStatusTLV.Length',
                'IntStatusValues': 'theCCMTLVS.CCMTLVList_0.InterfaceStatusTLV.IntStatusValues'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=ccm |
            | Edit Header Eoam | Stream=${Stream} | Level=0 | Tlvs=SenderIDTLV |
            | Edit Header Eoam Interface Status Tlv | Stream=${Stream} | Level=0 | Index=0 | Type=FF |
    """

    result = renix.edit_header_eoam_interface_status_tlv(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_eoam_organization_specific_tlv(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部的Organization Specific Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号

        Index (int): 要修改的Eoam报文头部的Organization Specific Tlv在流量模板中所有Eoam报文头部的Organization Specific Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：1F，取值范围：长度为1byte的十六进制数

        Length (hex): Length, 默认值：<AUTO>，取值范围：长度为2byte的十六进制数

        OUI (hex): OUI, 默认值：000000，取值范围：长度为3byte的十六进制数

        SubType (hex): Sub-Type, 默认值：00，取值范围：长度为1byte的十六进制数

        Value (hex): Value, 默认值：""，取值范围：长度为0-65535byte的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'theCCMTLVS.CCMTLVList_0.OrgSpecTLV.Type',
                'Length': 'theCCMTLVS.CCMTLVList_0.OrgSpecTLV.Length',
                'OUI': 'theCCMTLVS.CCMTLVList_0.OrgSpecTLV.OUI',
                'SubType': 'theCCMTLVS.CCMTLVList_0.OrgSpecTLV.SubType',
                'Value': 'theCCMTLVS.CCMTLVList_0.OrgSpecTLV.theValue.Value_0.Value'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=ccm |
            | Edit Header Eoam | Stream=${Stream} | Level=0 | Tlvs=SenderIDTLV |
            | Edit Header Eoam Organization Specific Tlv | Stream=${Stream} | Level=0 | Index=0 | Type=FF |
    """

    result = renix.edit_header_eoam_organization_specific_tlv(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_eoam_end_tlv(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Eoam报文头部的End Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Eoam头部在流量模板中所有Eoam头部的序列号

        Index (int): 要修改的Eoam报文头部的End Tlv在流量模板中所有Eoam报文头部的End Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：01，取值范围：长度为1byte的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'theCCMTLVS.CCMTLVList_0.EndTLV.Type'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=ccm |
            | Edit Header Eoam | Stream=${Stream} | Level=0 | Tlvs=SenderIDTLV |
            | Edit Header Eoam End Tlv | Stream=${Stream} | Level=0 | Index=0 | Type=FF |
    """

    result = renix.edit_header_eoam_end_tlv(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result










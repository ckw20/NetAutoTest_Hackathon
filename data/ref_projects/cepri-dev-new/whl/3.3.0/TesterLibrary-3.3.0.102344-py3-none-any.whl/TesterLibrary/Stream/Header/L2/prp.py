import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure

def edit_header_prp_tag(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中PRP Tag报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的PRP Tag头部在流量模板中所有PRP Tag头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        SequenceNumber (int): SequenceNumber，默认值：0，取值范围：0-65535

        LanId (bit): LanId，默认值：1010，取值范围：0000-1111

        LsduSize (int): LsduSize，默认值：52，取值范围：0-4095

        PrpSuffix (hex): PRPsuffix，默认值：88FB，取值范围：长度为2byte的十六进制数

    Returns:

        dict: eg::

            {
                'SequenceNumber': 'seqnum',
                'LanId': 'lanid',
                'LsduSize': 'lsdusize',
                'PrpSuffix': 'prpsuffix',
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Prp Tag | Stream=${Stream} | Level=0 | SequenceNumber=10 |
    """

    result = renix.edit_header_prp_tag(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

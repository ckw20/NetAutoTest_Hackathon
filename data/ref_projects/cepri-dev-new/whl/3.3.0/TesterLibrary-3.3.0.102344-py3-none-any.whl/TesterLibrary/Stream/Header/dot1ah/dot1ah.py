import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------802.1ah-------------------------------------
def edit_header_8021ah_CustomerStagEthernet(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah Encapsulated Customer Ethernet with Service Tag报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah Encapsulated Customer Ethernet with Service Tag头部在流量模板中所有802.1ah Encapsulated Customer Ethernet with Service Tag头部的序列号

    Keyword Args:

        EtherType (hex): EtherType, 默认值：88B5，取值范围：长度为2的十六进制数

        VlanType (hex): Service Vlan Type, 默认值：88a8，取值范围：长度为2的十六进制数

        VlanPCP (bit): Service VLAN PCP, 默认值：001，取值范围：长度为3的二进制数

        Dei (bit): Service DEI, 默认值：0，取值范围：长度为1的二进制数

        Vid (bit): Service VID, 默认值：000000000100，取值范围：长度为12的二进制数

    Returns:

        dict: eg::

            {
                'EtherType': 'etherType',
                'VlanType': 'tag.sTagOption_0.sTag.vlanType',
                'VlanPCP': 'tag.sTagOption_0.sTag.vlanPCP',
                'Dei': 'tag.sTagOption_0.sTag.dei',
                'Vid': 'tag.sTagOption_0.sTag.vid'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=sTag |
            | Edit Header 8021ah CustomerStagEthernet | Stream=${Stream} | Level=0 | VlanPCP=111 |
    """

    result = renix.edit_header_8021ah_CustomerStagEthernet(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_8021ah_EncapsulatedCustomerEthernetII(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah encapsulated customer ethernetII报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah encapsulated customer ethernetII头部在流量模板中所有802.1ah encapsulated customer ethernetII头部的序列号

    Keyword Args:

        EtherType (hex): EtherType, 默认值：88B5，取值范围：长度为2的十六进制数

        ServiceTag (bool): 是否插入service tag节点，默认值：False

        CustomerTag (bool): 是否插入customer tag节点，默认值：False

    Returns:

        dict: eg::

            {
                'EtherType': 'etherType'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=encapEthernetII |
            | Edit Header 8021ah EncapsulatedCustomerEthernetII | Stream=${Stream} | Level=0 | ServiceTag=True |
    """

    result = renix.edit_header_8021ah_EncapsulatedCustomerEthernetII(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_8021ah_EncapsulatedCustomerEthernetII_serviceTag(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah encapsulated customer ethernetII报文头部service tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah encapsulated customer ethernetII头部在流量模板中所有802.1ah encapsulated customer ethernetII头部的序列号

    Keyword Args:

        VlanType (hex): Service Vlan Type, 默认值：88a8，取值范围：长度为2的十六进制数

        VlanPCP (bit): Service VLAN PCP，默认值：001，取值范围：长度为3的二进制数

        Dei (bit): Service DEI，默认值：1，取值范围：长度为3的二进制数

        Vid (bit): Service VID，默认值：000000000100，取值范围：长度为12的二进制数

    Returns:

        dict: eg::

            {
                'VlanType': 'sTag.serviceTag_0.vlanType',
                'VlanPCP': 'sTag.serviceTag_0.vlanPCP',
                'Dei': 'sTag.serviceTag_0.dei',
                'Vid': 'sTag.serviceTag_0.vid',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=encapEthernetII |
            | Edit Header 8021ah EncapsulatedCustomerEthernetII | Stream=${Stream} | Level=0 | ServiceTag=True |
            | Edit Header 8021ah EncapsulatedCustomerEthernetII ServiceTag | Stream=${Stream} | Level=0 | VlanPCP=111 |
    """

    result = renix.edit_header_8021ah_EncapsulatedCustomerEthernetII_serviceTag(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_8021ah_EncapsulatedCustomerEthernetII_customerTag(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah encapsulated customer ethernetII报文头部customer tag内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah encapsulated customer ethernetII头部在流量模板中所有802.1ah encapsulated customer ethernetII头部的序列号

    Keyword Args:

        Type (hex): Type, 默认值：8100，取值范围：长度为2的十六进制数

        Pcp (bit): PCP，默认值：001，取值范围：长度为3的二进制数

        Cfi (bit): CFI，默认值：1，取值范围：长度为3的二进制数

        Id (bit): ID，默认值：000000000100，取值范围：长度为12的二进制数

    Returns:

        dict: eg::

            {
                'Type': 'cTag.customerTag_0.type',
                'Pcp': 'cTag.customerTag_0.pcp',
                'Cfi': 'cTag.customerTag_0.cfi',
                'Id': 'cTag.customerTag_0.id',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=encapEthernetII |
            | Edit Header 8021ah EncapsulatedCustomerEthernetII | Stream=${Stream} | Level=0 | CustomerTag=True |
            | Edit Header 8021ah EncapsulatedCustomerEthernetII CustomerTag | Stream=${Stream} | Level=0 | Pcp=111 |
    """

    result = renix.edit_header_8021ah_EncapsulatedCustomerEthernetII_customerTag(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_8021ah_EncapsulatedBackboneEthernet(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah Encapsulated Backbone ethernet报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah Encapsulated Backbone ethernet头部在流量模板中所有802.1ah Encapsulated Backbone ethernet头部的序列号

    Keyword Args:

        EtherType (hex): EtherType, 默认值：88B5，取值范围：长度为2的十六进制数

        VlanType (hex): Service Vlan Type, 默认值：88a8，取值范围：长度为2的十六进制数

        VlanPCP (bit): Service VLAN PCP, 默认值：001，取值范围：长度为3的二进制数

        Dei (bit): Service DEI, 默认值：1，取值范围：长度为1的二进制数

        Vid (int): Service VID, 默认值：100，取值范围：0-4095

    Returns:

        dict: eg::

            {
                'EtherType': 'etherType',
                'VlanType': 'bVLANTag.tagOption_0.btag.vlanType',
                'VlanPCP': 'bVLANTag.tagOption_0.btag.vlanPCP',
                'Dei': 'bVLANTag.tagOption_0.btag.dei',
                'Vid': 'bVLANTag.tagOption_0.btag.vid'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=encapbackboneeth |
            | Edit Header 8021ah EncapsulatedBackboneEthernet | Stream=${Stream} | Level=0 | VlanPCP=111 |
    """

    result = renix.edit_header_8021ah_EncapsulatedBackboneEthernet(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_8021ah_iTag(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah Itag报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah Itag头部在流量模板中所有802.1ah Itag头部的序列号

    Keyword Args:

        Pcp (bit): PCP, 默认值：000，取值范围：长度为3的二进制数

        Drop (bit): Drop Eligible, 默认值：1，取值范围：0-1

        Uca (bit): Use Customer Address, 默认值：1，取值范围：0-1

        Res1 (bit): res1, 默认值：0，取值范围：0-1

        Res2 (bit): res2, 默认值：00，取值范围：长度为2的二进制数

        ServiceId (int): Service ID, 默认值：0，取值范围：0-16777215

        EncapCusDstAddr (str): Encapsulated Customer Destination MAC，默认值：00:00:00:13:40:20，取值范围：有效的mac地址

        SourceMacAdd (str): Encapsulated Customer Source MAC，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

    Returns:

        dict: eg::

            {
                'Pcp': 'pcp',
                'Drop': 'drop',
                'Uca': 'uca',
                'Res1': 'res1',
                'Res2': 'res2',
                'ServiceId': 'serviceId',
                'EncapCusDstAddr': 'encapCusDstAddr',
                'SourceMacAdd': 'sourceMacAdd'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=iTag |
            | Edit Header 8021ah Itag | Stream=${Stream} | Level=0 | Pcp=111 |
    """

    result = renix.edit_header_8021ah_iTag(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_8021ah_MacInMac(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah Mac-in-Mac报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah Mac-in-Mac头部在流量模板中所有802.1ah Mac-in-Mac头部的序列号

    Keyword Args:

        DestMacAdd (str): Destination MAC Address，默认值：00:00:00:13:40:20，取值范围：有效的mac地址

        SourceMacAdd (str): Source MAC Address，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        EtherType (hex): EtherType, 默认值：88B5，取值范围：长度为2的十六进制数

        VlanType (hex): Service Vlan Type, 默认值：88a8，取值范围：长度为2的十六进制数

        VlanPCP (bit): Service VLAN PCP, 默认值：001，取值范围：长度为3的二进制数

        Dei (bit): Service DEI, 默认值：1，取值范围：长度为1的二进制数

        Vid (int): Service VID, 默认值：100，取值范围：0-4095

    Returns:

        dict: eg::

            {
                'DestMacAdd': 'destMacAdd',
                'SourceMacAdd': 'sourceMacAdd',
                'EtherType': 'etherType',
                'VlanType': 'bVLANTag.tagOption_0.btag.vlanType',
                'VlanPCP': 'bVLANTag.tagOption_0.btag.vlanPCP',
                'Dei': 'bVLANTag.tagOption_0.btag.dei',
                'Vid': 'bVLANTag.tagOption_0.btag.vid'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=mac-in-mac |
            | Edit Header 8021ah MacInMac | Stream=${Stream} | Level=0 | VlanPCP=111 |
    """

    result = renix.edit_header_8021ah_MacInMac(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_8021ah_EncapsulatedCustomerEthernet(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中802.1ah Encapsulated Customer Ethernet报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的802.1ah Encapsulated Customer Ethernet头部在流量模板中所有802.1ah Encapsulated Customer Ethernet头部的序列号

    Keyword Args:

        EtherType (hex): EtherType, 默认值：88B5，取值范围：长度为2的十六进制数

    Returns:

        dict: eg::

            {
                'EtherType': 'etherType',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=encapCustomerEth |
            | Edit Header 8021ah EncapsulatedCustomerEthernet | Stream=${Stream} | Level=0 | EtherType=1111 |
    """

    result = renix.edit_header_8021ah_EncapsulatedCustomerEthernet(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
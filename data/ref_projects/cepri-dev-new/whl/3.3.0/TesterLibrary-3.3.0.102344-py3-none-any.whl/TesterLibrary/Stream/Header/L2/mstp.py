import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def edit_header_mstp_config(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Ethernet报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的mstp config头部在流量模板中所有mstp config头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword args:

        ProtocolIdentifier (int): Protocol Identifier，默认值：0，取值范围：0-65535

        ProtocolVersionIdentifier (int): Protocol Version Identifier，默认值：3，取值范围：0-255

        BPDUType (hex): BPDU Type，默认值：02，取值范围：00-FF

        TopologyChangeAck (bit): Topology Changed Acknowledgment，默认值：0，取值范围：0-1

        Agreement (bit): Agreement，默认值：1，取值范围：0-1

        Forwarding (bit): Forwarding，默认值：1，取值范围：0-1

        Learning (bit): Learning，默认值：1，取值范围：0-1

        PortRole (bit): Port Role，默认值：11，取值范围：00-11

        Proposal (bit): Proposal，默认值：0，取值范围：0-1

        TopologyChange (bit): Topology Changed，默认值：0，取值范围：0-1

        RootBridgePriority (int): Root Bridge Priority，默认值：8，取值范围：0-15

        RootSystemIdExtension (int): Root Bridge System ID Extension，默认值：0，取值范围：0-4095

        RootBridgeSystemID (str): Root Bridge System ID，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        RootPathCost (int): Root Path Cost，默认值：0，取值范围：0-4294967295

        BridgePriority (int): Bridge Priority，默认值：8，取值范围：0-15

        BridgeSystemIdExtension (int): Bridge System ID Extension，默认值：0，取值范围：0-4095

        BridgeSystemID (str): Bridge System ID，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        PortIdentifier (hex): Port Identifier，默认值：8001，取值范围：0000-FFFF

        MessageAge (int): Message Age，默认值：0，取值范围：0-65535

        MaxAge (int): Max Age，默认值：5120，取值范围：0-65535

        HelloTime (int): Hello Time，默认值：512，取值范围：0-65535

        ForwardDelay (int): Forward Delay，默认值：3840，取值范围：0-65535

        Version1Length (int): Version 1 Length，默认值：0，取值范围：0-255

        Version3Length (int): Version 1 Length，默认值：64，取值范围：0-255

        ConfigId (int): MST Config ID Format Selector，默认值：0，取值范围：0-255

        ConfigName (hex): MST Config Name，默认值：726567696f6e3100000000000000000000000000000000000000000000000000，取值范围：长度为32字节的十六进制

        ConfigRevision (int): MST Config Revision，默认值：0，取值范围：0-65535

        ConfigDigest (hex): MST Config Digest，默认值：90fba5e9774b09524a17ebb75f8d065a，取值范围：长度为16字节的十六进制

        CistRootPathCost (int): CIST Internal Root Path Cost，默认值：0，取值范围：0-4294967295

        CistBridgePriority (int): Bridge Priority，默认值：8，取值范围：0-15

        CistSystemIdExtension (int): Bridge System ID Extension，默认值：0，取值范围：0-4095

        CistBridgeSystemID (str): Bridge System ID，默认值：00:00:00:12:30:10，取值范围：有效的mac地址

        CistRemainingHops (int): CIST Remaining Hops，默认值：20，取值范围：0-255

        MstInstances (int): 要插入的Mst Instance个数，默认值：0，取值范围：0-64

    Returns：

        dict: eg::

            {
                'ProtocolIdentifier': 'protocolIdentifier',
                'ProtocolVersionIdentifier': 'protocolVersionIdentifier',
                'BPDUType': 'BPDUType',
                'TopologyChangeAck': 'BPDUFlags.topologyChangeAck',
                'Agreement': 'BPDUFlags.agreement',
                'Forwarding': 'BPDUFlags.forwarding',
                'Learning': 'BPDUFlags.learning',
                'PortRole': 'BPDUFlags.portRole',
                'Proposal': 'BPDUFlags.proposal',
                'TopologyChange': 'BPDUFlags.topologyChange',
                'RootBridgePriority': 'rootIdentifier.rootBridgePriority',
                'RootSystemIdExtension': 'rootIdentifier.systemIdExtension',
                'RootBridgeSystemID': 'rootIdentifier.rootBridgeSystemID',
                'RootPathCost': 'rootPathCost',
                'BridgePriority': 'bridgeIdentifier.bridgePriority',
                'BridgeSystemIdExtension': 'bridgeIdentifier.systemIdExtension',
                'BridgeSystemID': 'bridgeIdentifier.bridgeSystemID',
                'PortIdentifier': 'portIdentifier',
                'MessageAge': 'messageAge',
                'MaxAge': 'maxAge',
                'HelloTime': 'helloTime',
                'ForwardDelay': 'forwardDelay',
                'Version1Length': 'version1Length',
                'Version3Length': 'version3Length',
                'ConfigId': 'mstExtension.configId',
                'ConfigName': 'mstExtension.configName',
                'ConfigRevision': 'mstExtension.configRevision',
                'ConfigDigest': 'mstExtension.configDigest',
                'CistRootPathCost': 'mstExtension.cistRootPathCost',
                'CistBridgePriority': 'mstExtension.cistRemainingHops.bridgePriority',
                'CistSystemIdExtension': 'mstExtension.cistRemainingHops.systemIdExtension',
                'CistBridgeSystemID': 'mstExtension.cistRemainingHops.bridgeSystemID',
                'CistRemainingHops': 'cistBridgeSystemID'
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Header Mstp Config | Stream=${Stream} | Level=0 | TopologyChangeAck=1 |
    """

    result = renix.edit_header_mstp_config(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_header_mstp_config_mst_instance(Stream, Level=0, Index=0, **kwargs):
    """
    修改测试仪表流量模板中Mstp Config报文中Mst Instance头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的Mstp Config头部在流量模板中所有Mstp Config头部的序列号, 默认值: 0, 范围: 0-65535

        Index (int): 要修改的Mst Instance头部在流量模板中所有Mst Instance头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        TopologyChangeAck (bit): Topology Changed Acknowledgment，默认值：0，取值范围：0-1

        Agreement (bit): Agreement，默认值：1，取值范围：0-1

        Forwarding (bit): Forwarding，默认值：1，取值范围：0-1

        Learning (bit): Learning，默认值：1，取值范围：0-1

        PortRole (bit): Port Role，默认值：11，取值范围：00-11

        Proposal (bit): Proposal，默认值：0，取值范围：0-1

        TopologyChange (bit): Topology Changed，默认值：0，取值范围：0-1

        Priority (int): Priority, 默认值：8, 取值范围：0-15

        MstId (int): MST ID, 默认值：1, 取值范围：0-4095

        RegionalRoot (str): Regional Root, 默认值：00:00:00:12:30:10, 取值范围：有效的mac地址

        InternalRootPathCost (int): Internal Root Path Cost, 默认值：0, 取值范围：0-4294967295

        BridgeIdentifierPriority (int): Bridge Identifier Priority, 默认值：8, 取值范围：0-255

        PortIdentifierPriority (int): Port Identifier Priority, 默认值：8, 取值范围：0-255

        RemainingHops (int): Remaining Hops, 默认值：20, 取值范围：0-255

    Returns:

        dict: eg::

            {
                'TopologyChangeAck': 'mstExtension.mstInstances.mstInstance_0.MSTIFlags.topologyChangeAck',
                'Agreement': 'mstExtension.mstInstances.mstInstance_0.MSTIFlags.agreement',
                'Forwarding': 'mstExtension.mstInstances.mstInstance_0.MSTIFlags.forwarding',
                'Learning': 'mstExtension.mstInstances.mstInstance_0.MSTIFlags.learning',
                'PortRole': 'mstExtension.mstInstances.mstInstance_0.MSTIFlags.portRole',
                'Proposal': 'mstExtension.mstInstances.mstInstance_0.MSTIFlags.proposal',
                'TopologyChange': 'mstExtension.mstInstances.mstInstance_0.MSTIFlags.topologyChange',
                'Priority': 'mstExtension.mstInstances.mstInstance_0.priority',
                'MstId': 'mstExtension.mstInstances.mstInstance_0.mstId',
                'RegionalRoot': 'mstExtension.mstInstances.mstInstance_0.regionalRoot',
                'InternalRootPathCost': 'mstExtension.mstInstances.mstInstance_0.internalRootPathCost',
                'BridgeIdentifierPriority': 'mstExtension.mstInstances.mstInstance_0.bridgeIdentifierPriority',
                'PortIdentifierPriority': 'mstExtension.mstInstances.mstInstance_0.portIdentifierPriority',
                'RemainingHops': 'mstExtension.mstInstances.mstInstance_0.remainingHops',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | cfg |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Mstp Config | Stream=${Stream} | Level=0 | MstInstances=1 |
            | Edit Header Mstp Config Mst Instance | Stream=${Stream} | Index=0 | TopologyChangeAck=1 |
    """

    result = renix.edit_header_mstp_config_mst_instance(Stream=Stream, Level=Level, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


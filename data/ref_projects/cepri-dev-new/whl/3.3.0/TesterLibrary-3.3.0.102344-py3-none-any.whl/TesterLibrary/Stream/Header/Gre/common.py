import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def edit_header_gre(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中Gre报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的vlan头部在流量模板中所有vlan头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        ChecksumPresent (int): Checksum Present，默认值：<AUTO>0，范围：0-1

        Routing (int): Routing Present，默认值：0，范围：0-1

        KeyPresent (int): Key Present，默认值：<AUTO>0，范围：0-1

        SequenceNumberPresent (int): Sequence Number Present，默认值：<AUTO>0，范围：0-1

        Reserved (int): Reserved，默认值：0，范围：0-511

        Version (int): Version，默认值：0，范围：0-7

        Protocol (hex): Protocol，默认值：0800，范围：

            0800：IPv4

            6558：Ethernet II

            8847：MPLS

            86DD：IPv6

        Checksum (int): Checksum，默认值：0，取值范围：0-65535

        ChecksumReserved (int): Checksum Reserved，默认值：0，取值范围：0-65535

        Key (int): Gre Key，默认值：0，取值范围：0-4924967295

        SequenceNumber (int): Sequence Number，默认值：0，取值范围：0-4924967295

        EnableKeepAlive (int): Enable KeepAlive，默认值：0，取值范围：0-1

        KeepAlivePeriod (int): KeepAlive Period (seconds)，默认值：10，取值范围：0-65535

        KeepAliveRetries (int): KeepAlive Retries，默认值：3，取值范围：0-255

    Returns:

        dict: eg::

            {
                'ChecksumPresent': 'checksumPresent',
                'Routing': 'routing',
                'KeyPresent': 'keyPresent.GreKey_0.key',
                'SequenceNumberPresent': 'sequenceNumber.GreSequenceNumber_0.sequenceNumber',
                'Reserved': 'reserved',
                'Version': 'version',
                'Protocol': 'protocol',
                'EnableKeepAlive': 'enableKeepAlive',
                'KeepAlivePeriod': 'keepAlivePeriod',
                'KeepAliveRetries': 'keepAliveRetries',
                'Checksum': 'checksum.GreChecksum_0.checksum',
                'ChecksumReserved': 'checksum.GreChecksum_0.reserved',
                'Key': 'Key.GreKey_0.key'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | ${HeaderTypes} | Create List | EthernetII | IPv4 | GRE |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=${HeaderTypes} |
            | Edit Header Gre | Stream=${Stream} | Level=0 | KeepAlivePeriod=100 | KeepAliveRetries=200 |
    """

    result = renix.edit_header_gre(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


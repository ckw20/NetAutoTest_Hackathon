import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure

def edit_header_hsr_tag(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中HSR Tag报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的HSR Tag头部在流量模板中所有HSR Tag头部的序列号, 默认值: 0, 范围: 0-65535

    Keyword Args:

        PathId (bit): PathId, 默认值：0001，取值范围：0000-1111

        LsduSize (int): LsduSize, 默认值：0，取值范围：0-4095

        SeqNum (int): SequenceNumber, 默认值：0，取值范围：0-65535

        Protocol (hex): Value, 默认值：0800，取值范围：

            0800: IPv4

            0806: ARP

            8100: VLAN

            8864: PPPoE

            8863: PPPoE Discovery

            86DD: IPv6

            8808: Pause

            8847: MPLS

            88B8: Goose

            8926: VNTag

            F1C1: RTag

            892F: HSRTag

            88FB: PRPTag

    Returns:

        dict: eg::

            {
                'PathId': 'pathid',
                'LsduSize': 'lsdusize',
                'SeqNum': 'seqnum',
                'Protocol': 'protocol'
            }

    Examples:
        .. code:: RobotFramework

            | Edit Header Hsr Tag | Stream=${Stream} | Level=0 | SeqNum=10 |
    """

    result = renix.edit_header_hsr_tag(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

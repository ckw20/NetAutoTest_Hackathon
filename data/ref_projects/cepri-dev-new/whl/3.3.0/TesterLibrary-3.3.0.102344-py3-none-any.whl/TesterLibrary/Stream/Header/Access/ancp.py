import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------ancp-------------------------------------
def edit_header_ancp(Stream, Level=0, **kwargs):
    """
    修改测试仪表流量模板中ANCP Port Management报文头部内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ANCP Port Management头部在流量模板中所有ANCP Port Management头部的序列号

    Keyword Args:

        Identifier (hex): Identifier, 默认值：880C，取值范围：长度为2的十六进制数

        Length (int): Length of TCP/IP Encapsulating Header, 默认值：0，取值范围：0-65535

        Version (int): Version, 默认值：50，取值范围：0-255

        MessageType (int): Message Type, 默认值：32，取值范围：0-255

        ResultField (int): Result Field, 默认值：0，取值范围：0-4

        ResultCode (int): Result Code, 默认值：0，取值范围：

            0: 0x0 | No result

            2: 0x2 | Invalid request message

            6: 0x6 | One or more of the specified ports are down

            19: 0x13 | Out of resources

            81: 0x51 | Request message type not implemented

            83: 0x53 | Malformed message

            84: 0x54 | Mandatory TLV missing

            85: 0x55 | Invalid TLV contents

            1280: 0x500 | One or more of the specified ports do not exist

        PartitionId (int): Partition ID, 默认值：0，取值范围：0-255

        TransactionId (int): Partition ID, 默认值：0，取值范围：0-16777215

        Ignore (int): Ignore, 默认值：1，取值范围：0-1

        SubMessageNumber (int): subMessageNumber, 默认值：1，取值范围：0-32767

        Length2 (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Unused (hex): Unused, 默认值：0000000000000000000000000000，取值范围：长度为14的十六进制数

        Function (hex): Function, 默认值：09，取值范围：长度为1的十六进制数

        XFunction (hex): X-Function, 默认值：00，取值范围：长度为1的十六进制数

        Unused2 (hex): Unused2, 默认值：00000000，取值范围：长度为4的十六进制数

        ExtensionFlag (hex): Extension Flag, 默认值：00，取值范围：长度为1的十六进制数

        MessageType2 (int): Message Type, 默认值：32，取值范围：0-255

        Reserved (hex): Reserved, 默认值：0000，取值范围：长度为2的十六进制数

        NumberOfTlvs (int): Number of TLVs, 默认值：0，取值范围：0-65535

        ExtensionBlockLength (int): Extension Block Length, 默认值：0，取值范围：0-65535

        AccessLineIdentifyingTlvs (int): 要插入的Access Line Identifying Tlvs的数量, 默认值：0，取值范围：0-256

        TestingRelatedTlvs (int): 要插入的Testing Related Tlvs的数量, 默认值：0，取值范围：0-256

        StatusInfoTlvs (int): 要插入的Status-Info Tlvs的数量, 默认值：0，取值范围：0-256

    Returns:

        dict: eg::

            {
                'Identifier': 'tcpipEncapHeaderField.id',
                'Length': 'tcpipEncapHeaderField.len',
                'Version': 'ancpPortManagementMsgHeader.version',
                'MessageType': 'ancpPortManagementMsgHeader.messageType1',
                'ResultField': 'ancpPortManagementMsgHeader.resultField',
                'ResultCode': 'ancpPortManagementMsgHeader.resultCode',
                'PartitionId': 'ancpPortManagementMsgHeader.partitionID',
                'TransactionId': 'ancpPortManagementMsgHeader.transactionID',
                'Ignore': 'ancpPortManagementMsgHeader.ignore',
                'SubMessageNumber': 'ancpPortManagementMsgHeader.subMessageNum',
                'Length2': 'ancpPortManagementMsgHeader.len',
                'Unused': 'ancpPortManagementMsgHeader.unused',
                'Function': 'ancpPortManagementMsgHeader.function',
                'XFunction': 'ancpPortManagementMsgHeader.xFunction',
                'Unused2': 'ancpPortManagementMsgHeader.unused2',
                'ExtensionFlag': 'ancpPortManagementMsgHeader.extensionFlag',
                'MessageType2': 'ancpPortManagementMsgHeader.messageType2',
                'Reserved': 'ancpPortManagementMsgHeader.reserved',
                'NumberOfTlvs': 'ancpPortManagementMsgHeader.numberOfTLV',
                'ExtensionBlockLength': 'ancpPortManagementMsgHeader.extBlockLength'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=portManagement |
            | Edit Header Ancp | Stream=${Stream} | Level=0 | Identifier=ffff |
    """

    result = renix.edit_header_ancp(Stream=Stream, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ancp_access_line_identifying_tlv(Stream, Level=0, TlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ANCP Port Management报文头部的Access Line Identifying Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ANCP Port Management头部在流量模板中所有ANCP Port Management头部的序列号

        TlvIndex (int): 要修改的ANCP Port Management头部Access Line Identifying Tlv在流量模板中所有ANCP Port Management头部TAccess Line Identifying Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0001，取值范围：长度为2的十六进制数

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value (hex): Value, 默认值：00，取值范围：长度为0-63的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'accLineIdentifyingTLVs.accessLineIdentifyingTLVs_0.accLoopCircuitIdTLV.type',
                'Length': 'accLineIdentifyingTLVs.accessLineIdentifyingTLVs_0.accLoopCircuitIdTLV.length',
                'Value': 'accLineIdentifyingTLVs.accessLineIdentifyingTLVs_0.accLoopCircuitIdTLV.value',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=portManagement |
            | Edit Header Ancp Access Line Identifying Tlv | Stream=${Stream} | Level=0 | TlvIndex=0 | Type=ffff |
    """

    result = renix.edit_header_ancp_access_line_identifying_tlv(Stream=Stream, Level=Level, TlvIndex=TlvIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ancp_testing_related_tlv(Stream, Level=0, TlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ANCP Port Management报文头部的Testing Related Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ANCP Port Management头部在流量模板中所有ANCP Port Management头部的序列号

        TlvIndex (int): 要修改的ANCP Port Management头部Testing Related Tlv在流量模板中所有ANCP Port Management头部Testing Related Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0008，取值范围：长度为2的十六进制数

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Value1 (int): Value1, 默认值：0，取值范围：0-4294967295

        Value2 (int): Value2, 默认值：0，取值范围：0-4294967295

    Returns:

        dict: eg::

            {
                'Type': 'testRelatedTLVs.testingRelatedTLVs_0.opaqueTLV.type',
                'Length': 'testRelatedTLVs.testingRelatedTLVs_0.opaqueTLV.length',
                'Value1': 'testRelatedTLVs.testingRelatedTLVs_0.opaqueTLV.value1',
                'Value2': 'testRelatedTLVs.testingRelatedTLVs_0.opaqueTLV.value2',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=portManagement |
            | Edit Header Ancp Testing Related Tlv | Stream=${Stream} | Level=0 | TlvIndex=0 | Type=ffff |
    """

    result = renix.edit_header_ancp_testing_related_tlv(Stream=Stream, Level=Level, TlvIndex=TlvIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ancp_status_info_tlv(Stream, Level=0, TlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ANCP Port Management报文头部的Status Info Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ANCP Port Management头部在流量模板中所有ANCP Port Management头部的序列号

        TlvIndex (int): 要修改的ANCP Port Management头部Status Info Tlv在流量模板中所有ANCP Port Management头部Status Info Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0106，取值范围：长度为2的十六进制数

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Reserved (hex): Reserved, 默认值：00，取值范围：长度为1的十六进制数

        MsgType (int): Message Type, 默认值：0，取值范围：0-255

        ErrMsgLength (int): Error Message Length, 默认值：<AUTO>0，取值范围：0-65535

        ErrMsg (hex): Error Message, 默认值：""，取值范围：长度为0-65535的十六进制数

        OptionalSubTLV (int): 要插入的Optional Sub Tlv的数量, 默认值：0，取值范围：0-64

    Returns:

        dict: eg::

            {
                'Type': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.type',
                'Length': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.length',
                'Reserved': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.reserved',
                'MsgType': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.msgType',
                'ErrMsgLength': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.errMsgLength',
                'ErrMsg': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.errMsg'
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=portManagement |
            | Edit Header Ancp Status Info Tlv | Stream=${Stream} | Level=0 | TlvIndex=0 | Type=ffff |
    """

    result = renix.edit_header_ancp_status_info_tlv(Stream=Stream, Level=Level, TlvIndex=TlvIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_header_ancp_status_info_tlv_optional_sub_tlv(Stream, Level=0, TlvIndex=0, SubTlvIndex=0, **kwargs):
    """
    修改测试仪表流量模板中ANCP Port Management报文头部的Status Info Tlv的Optional Sub Tlv内容

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Level (int): 要修改的ANCP Port Management头部在流量模板中所有ANCP Port Management头部的序列号

        TlvIndex (int): 要修改的ANCP Port Management头部Status Info Tlv在流量模板中所有ANCP Port Management头部Status Info Tlv的序列号

        SubTlvIndex (int): 要修改的ANCP Port Management头部Status Info Tlv的Optional Sub Tlv在流量模板中所有ANCP Port Management头部Status Info Tlv的Optional Sub Tlv的序列号

    Keyword Args:

        Type (hex): Type, 默认值：0001，取值范围：长度为2的十六进制数

        Length (int): Length, 默认值：<AUTO>0，取值范围：0-65535

        Data (hex): Data, 默认值：''，取值范围：长度为0-65535的十六进制数

    Returns:

        dict: eg::

            {
                'Type': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.optionalSubTLV.customTLV_0.type',
                'Length': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.optionalSubTLV.customTLV_0.length',
                'Data': 'statusInfoTLVs.status-InfoTLV_0.statusinfoTLV.optionalSubTLV.customTLV_0.data',
            }

    Examples:
        .. code:: RobotFramework

            | ${Stream} | add_stream | Port=${Port} |
            | Create Stream Header | Stream=${Stream} | HeaderTypes=portManagement |
            | Edit Header Ancp Status Info Tlv Optional Sub Tlv | Stream=${Stream} | Level=0 | TlvIndex=0 | SubTlvIndex=0 | Type=ffff |
    """

    result = renix.edit_header_ancp_status_info_tlv_optional_sub_tlv(Stream=Stream, Level=Level,
                                                                     TlvIndex=TlvIndex,
                                                                     SubTlvIndex=SubTlvIndex, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Interface-------------------------------------
def create_interface(Port, Layers=None, Tops=None, **kwargs):
    """
    在指定端口上創建接口

    Args:

        Port (:obj:`Port`): 测试仪仪表端口Port对象

        Layers (list or str): 链路层封装, 默认值: eth, 支持的有:

            eth

            vlan

            pppoe

            l2tp

            ipv4

            ipv6

        Tops (list or str): 网络层封装, 默认值: ipv4, 支持的有:

            None

            ipv4

            ipv6

        Keyword Args:

            Name

            Count

            EnableInterfaceCount

            EnableLearningGatewayMac

            RouterIdMode

            RouterId

            RouterIdStep

            RouterIdList

            Ipv6RouterId

            Ipv6RouterIdList

            EnableVlansAssociation

    Returns:

        (:obj:`Interface`): 接口interface对象

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} | Create List | //192.168.0.1/1/1 |
        | ${Layers} | Create List | eth | ipv4 |
        | ${Port} | Reserve Ports | ${Ports} | ${Location} |
        | ${Interface} | Create Interface | ${Port} | ${Layers} |
    """

    result = renix.create_interface(Port=Port, Layers=Layers, Tops=Tops, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_interface_stack(Interfaces, Layers=None, Tops=None):
    """
    修改测试仪表接口的结构

    Args:

        Interfaces (list (:obj:`Interface`)): 测试仪仪表接口Interface对象列表

        Layers (list or str): 链路层封装, 默认值: eth, 支持的有:

            eth

            vlan

            pppoe

            l2tp

            ipv4

            ipv6

        Tops (list or str): 网络层封装, 默认值: ipv4, 支持的有:

            None

            ipv4

            ipv6

    Returns:

    dict: eg::

            {
                <renix_py_api.api_gen.Interface_Autogen.Interface object at 0x000001B2BE89ACD0>: [<renix_py_api.api_gen.EthIILayer_Autogen.EthIILayer object at 0x000002176CB13430>, <renix_py_api.api_gen.VlanLayer_Autogen.VlanLayer object at 0x000002176CB13580>, <renix_py_api.api_gen.Ipv4Layer_Autogen.Ipv4Layer object at 0x000002176CB13130>, <renix_py_api.api_gen.Ipv4Layer_Autogen.Ipv4Layer object at 0x000002176CB13730>, <renix_py_api.api_gen.L2tpLayer_Autogen.L2tpLayer object at 0x000002176CB130D0>, <renix_py_api.api_gen.PppoeLayer_Autogen.PppoeLayer object at 0x000002176CB137C0>],
            }

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} | Create List | //192.168.0.1/1/1 |
        | ${Layers} | Create List | eth |
        | ${Tops} | Create List | vlan | ipv4 |
        | ${Port} | Reserve Ports | ${Ports} | ${Location} |
        | ${Interface} | Create Interface | ${Port} | ${Layers} |
        | Edit Interface Stack | ${Interface} | ${Layers} | ${Tops} |
    """

    result = renix.edit_interface_stack(Interfaces=Interfaces, Layers=Layers, Tops=Tops)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_interface(Interface, Layer=None, Level=None, **kwargs):
    """
    修改测试仪表接口的参数

    Args:

        Interface (:obj:`Interface`): 测试仪仪表接口Interface对象

        Layer (str): 创建接口类型, 支持的有:

            EthIILayer

            VLANLayer

            IPv4Layer

            IPv6Layer

        Level (int): 要修改的Layer在interface的所有相同Layer的序号，默认值：None, 范围：0-1，为None表示修改所有Layer

    Keyword Args:

        Count

        EnableInterfaceCount

        EnableLearningGatewayMac

        RouterIdMode

        RouterId

        RouterIdStep

        RouterIdList

        Ipv6RouterId

        Ipv6RouterIdList

        EnableVlansAssociation

        EthIILayer:

            AddressMode

            Address

            Step

            AddressList

            EnableRandMac

            RandomSeed

        VLANLayer:

            AddressMode

            VlanId

            Step

            VlanIdList

            Priority

            PriorityStep

            PriorityList

            Cfi

            Tpid

        IPv4Layer:

            AddressMode

            Address

            Step

            AddressList

            PrefixLength

            Gateway

            GatewayStep

            GatewayList

            GatewayCount

            GatewayMac

            ResolvedMacList

            ResolvedState

        IPv6Layer:

            AddressMode

            Address

            Step

            AddressList

            PrefixLength

            Gateway

            GatewayStep

            GatewayList

            GatewayCount

            GatewayMac

            ResolvedMacList

            ResolvedState

            LinkLocalGenType

            LinkLocal

            LinkLocalStep

            LinkLocalList

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} | Create List | //192.168.0.1/1/1 |
        | ${Layers} | Create List | eth | ipv4 |
        | ${Port} | Reserve Ports | ${Ports} | ${Location} |
        | ${Interface} | Create Interface | ${Port} | ${Layers} |
        | Edit Interface | Interfaces=${Interface} | Layer=IPv4Layer | Gateway=192.168.1.1 |
    """

    result = renix.edit_interface(Interface=Interface, Layer=Layer, Level=Level, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_arp(Ports=None, Interfaces=None):
    """
    测试仪表启动接口ARP功能

    Args:

        Ports (list): 端口对象的列表, 默认值：None

        Interfaces (list): 接口对象的列表, 默认值：None，当Ports和Interfaces都为None时，表示启动所有接口的ARP

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Start Arp |
    """

    result = renix.start_arp(Ports=Ports, Interfaces=Interfaces)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_arp(Ports=None, Interfaces=None):
    """
    测试仪表停止接口ARP功能

    Args:

        Ports (list): 端口对象的列表, 默认值：None

        Interfaces (list): 接口对象的列表, 默认值：None，当Ports和Interfaces都为None时，表示启动所有接口的ARP

    Returns: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Stop Arp |
    """

    result = renix.stop_arp(Ports=Ports, Interfaces=Interfaces)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_gateway_mac(Interface, Version=None):
    """
    获取测试仪表学习到的网关Mac地址

    Args:

        Interface (:obj:`Interface`): 测试仪表接口对象

        Version (str): 网关地址ip版本支持：IPv4 和 IPv6

    Returns:

        list: Mac地址列表List

    Examples:
        robotframework:

    .. code:: robotframework

        | Get Gateway Mac | Interface=${Interface} |
    """

    result = renix.get_gateway_mac(Interface=Interface)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_interfaces(Ports=None, Types=None):
    """
    获取测试仪表指定端口下指定类型接口

    Args:

        Ports (list (:obj:`Port`)): 测试仪表接口对象列表
        
        Types (str): 接口类型列表，当取值为：None返回当前所有接口，支持下列类型:

            eth

            vlan

            pppoe

            l2tp

            ipv4

            ipv6
        
    Returns:

        list: 测试仪表接口对象列表List

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Interfaces} | Get Interfaces | Ports=${Ports} | Types=vlan |
    """

    result = renix.get_interfaces(Ports=Ports, Types=Types)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_layer_from_interfaces(Interfaces, Layer='ipv4'):
    """
    获取测试仪表接口的封装层对象

    Args:

        Interface (list): 测试仪表接口对象列表

    Returns:

        list: 测试仪表接口的封装层对象列表List

    Examples:
        robotframework:

    .. code:: robotframework

        | Get Layer From Interfaces | Interfaces=${Interface} | Layer=ipv4 |
    """

    result = renix.get_layer_from_interfaces(Interfaces=Interfaces, Layer=Layer)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ipv4_ping(Interface=None, IpAddr=None, PacketCount=5):
    """
    获取测试仪表接口的封装层对象

    Args:

        Interface ((:obj:`Interface`)): 测试仪表接口对象列表

        IpAddr (str): ipv4地址

        PacketCount (int): ping包数量

    Returns:

        bool: True或False

     Examples:
        robotframework:

    .. code:: robotframework

        | Ipv4 Ping | Interface=${Interface} | IpAddr=192.168.0.2 |
    """

    result = renix.ipv4_ping(Interface=Interface, IpAddr=IpAddr, PacketCount=PacketCount)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ipv6_ping(Interface=None, IpAddr=None, PacketCount=5):
    """
    获取测试仪表接口的封装层对象

    Args:

        Interface ((:obj:`Interface`)): 测试仪表接口对象列表

        IpAddr (str): ipv6地址

        PacketCount (int): ping包数量

    Returns:

        bool: True或False

     Examples:
        robotframework:

    .. code:: robotframework

        | Ipv6 Ping | Interface=${Interface} | IpAddr=2000::2 |
    """

    result = renix.ipv6_ping(Interface=Interface, IpAddr=IpAddr, PacketCount=PacketCount)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def relocate_ports(Ports, Locations, Force=False, Debug=False):
    """
    逻辑端口迁移到执行的测试仪表的物理端口.

    Args:

        Ports (list): 端口对象的列表

        Locations (list): 端口在测试仪表机箱硬件中的位置, //$(机箱IP地址)/$(板卡序号)/$(端口序号) (例如：[//192.168.0.1/1/1, //192.168.0.1/1/2])

        Force (bool): 强制释放端口，默认值False

        Debug (bool): 使用离线端口，默认值False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} == [//192.168.0.1/1/1, //192.168.0.1/1/2] |
        | ${result} | Relocate Ports | ${Ports} | ${Locations} |
    """

    result = renix.relocate_ports(Ports=Ports, Locations=Locations, Force=Force, Debug=False)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def reserve_port(Locations, Force=False, Debug=False, WaitForStatusUp=True):
    """
    预约测试仪表的端口

    Args:

        Locations (list): 端口在测试仪表机箱硬件中的位置, //$(机箱IP地址)/$(板卡序号)/$(端口序号) (例如：[//192.168.0.1/1/1, //192.168.0.1/1/2])

        Force (bool): 强制占用测试仪表端口, 默认值: False

        Debug (bool): 调试模式, 只创建离线端口, 默认值: False

        WaitForStatusUp (bool): 等待端口UP, 默认值: True

    Returns:

        list: 端口对象列表

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} == [//192.168.0.1/1/1, //192.168.0.1/1/2] |
        | ${result} | Reserve Port | ${Locations} |
    """

    result = renix.reserve_port(Locations=Locations, Force=Force, Debug=Debug, WaitForStatusUp=WaitForStatusUp)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def release_port(Locations=None, Ports=None, Force=False, Debug=False):
    """
    释放测试仪表的端口

    Args:

        Locations (list): 端口在测试仪表机箱硬件中的位置, //$(机箱IP地址)/$(板卡序号)/$(端口序号) (例如：[//192.168.0.1/1/1, //192.168.0.1/1/2])

        Ports (list): 端口在测试仪表端口对象列表

        Force (bool): 强制释放测试仪表端口, 默认值: False

        Debug (bool): 使用离线端口, 调用实际不会对端口做任何操作配合reserve_port的Debug模式，默认值: False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} == [//192.168.0.1/1/1, //192.168.0.1/1/2] |
        | ${result} | Release Port | ${Locations} |
    """

    result = renix.release_port(Locations=Locations, Ports=Ports, Force=Force, Debug=Debug)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ports():
    """
    获取当前测试仪表配置中所有的端口对象

    Returns:

        list: Port对象列表

    Examples:
        robotframework:

    .. code:: robotframework

        | ${result} | Get Ports |
    """

    result = renix.get_ports()
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def del_port(Ports=None):
    """
    删除测试仪端口

    Args:

        Ports: 测试仪表端口对象列表, 类型为：list

    Returns:

        bool：布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Del Port | Ports=${Port_1} |
        | Del Port |
    """

    result = renix.del_port(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_port_speed(Ports):
    """
    修改测试仪表端口参数

    Args:

        Ports (list(:obj:`Port`)): 测试仪表端口列表

    Returns:

        list: 端口速率列表

    Examples:
        robotframework:

    .. code:: robotframework

        | Get Port Speed | Ports=${Ports} |
    """

    result = renix.get_port_speed(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_port(Ports, **kwargs):
    """
    修改测试仪表端口参数

    Args:

        Ports (list(:obj:`Port`)): 测试仪表端口列表

    Keyword Args:

        EnableLink (bool): 设置端口link Up和Down, 默认值: True

        AutoNegotiation (bool): 自协商, 默认值: False

        Mtu (int): 端口MTU值, 范围: 128-9600

        FecType (str): Fec类型, 默认值：TYPE_OFF，支持:

            TYPE_OFF

            TYPE_RS_FEC_CLAUSE91

            TYPE_FEC_CLAUSE74

            TYPE_RS_FEC_CLAUSE108

            TYPE_RS_FEC_CONSORTIUM

            TYPE_RS_FEC_CLAUSE119

        LineSpeed (str): 端口速率切换, 默认值：SPEED_1G，支持:

            SPEED_UNKNOWN

            SPEED_10M

            SPEED_100M

            SPEED_1G

            SPEED_2_5G

            SPEED_5G

            SPEED_10G

            SPEED_25G

            SPEED_40G

            SPEED_50G

            SPEED_100G

            SPEED_200G

            SPEED_400G

        Duplex (str): 全双工半双工, 默认值：FULL，支持:

            HALF

            FULL

        FlowControl (str): 流控, 默认值：DISABLE，支持:

            DISABLE

            ENABLE

            AUTO

        Media (str): 媒介, 支持:

            COPPER

            FIBER

            FAKE

        PhyMode (str): Phy Mode, 默认值：None，支持:

            MODE_AUTO

            MODE_1000BASEX

            MODE_SGMII

        PpmAdjust (int): Ppm Adjust, 默认值：None，范围: -300-300

        DataPathMode (str): Data Path模式, 默认值：None，支持:

            NORMAL

            LOOPBACK

        RemoteFault (str): 远端错误, 默认值：None，支持:

            NORMAL

            IGNORE

        Master (str): Master, 默认值：None，支持:

            ADVERTISE_SINGLE_PORT

            ADVERTISE_MULTI_PORT

            MANUAL_MASTER

            MANUAL_SLAVE

        NoParam (bool): 远端错误, 默认值: False

        ArpTimeout (int): ARP/ND超时（秒）范围：1-255, 默认值: 1

        ArpRate (int): ARP/ND速率（包/秒范围：1-1000000, 默认值: 250

        ArpRetryCount (int): ARP/ND重传次数 范围：0-100, 默认值: 3

        ArpSuppressDuplicateGateway (bool): ARP/ND抑制重复网关, 默认值: False

        ArpDelayTime (int): 在ARP/ND前延迟（秒） 范围：0-4294967295, 默认值: 0

        ArpUseLinkLocalForNd (bool): 使用LinkLocal执行ND, 默认值: False

    Returns:

        bool: 布尔值

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Port | Ports=${Ports} | AutoNegotiation=True | FecType=TYPE_OFF |
    """

    result = renix.edit_port(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_port_load_profile(Ports, **kwargs):
    """
    编辑测试仪表负载配置文件参数

    Args:

        Ports (list(:obj:`IsisIpv4Router`): 测试仪表端口对象object列表

    Keyword Args:

        TransmitMode (str): 传输模式, 默认值：CONTINUOUS，取值范围：

            CONTINUOUS: 连续

            BURST: 突发

            TIME: 按时间突发

            STEP: 单步突发

            ONSTREAM: 基于流调速

        BurstSize (int):突发报文数，默认值：1

        InterFrameGap (int):突发间隔，默认值：12.0

        InterFrameGapUnit (str):突发间隔单位，默认值：BYTES，取值范围：

            NS

            MS

            US

            SEC

            BYTES

        BurstCount (int):突发次数，默认值：1

        Seconds (int):发送时间，单位：sec，默认值：100

        Frames (int):发送帧数，默认值：1

        LoadProfileType (str): 负载类型，默认值：PORT_BASE，取值范围：

            PORT_BASE:

            STREAM_BASE

            PRIORITY_BASE

            MANUAL_BASE

        Rate (int):端口负载，默认值：10

        Unit (str): 端口负载单位，默认值：PERCENT，取值范围：

            NS

            PERCENT

            FRAME_PER_SEC

            BYTE_PER_SEC

            DATABIT_PER_SEC

            LINEBIT_PER_SEC

            INTER_FRAME_GAP_BYTE

            KLINEBIT_PER_SEC

            MLINEBIT_PER_SEC

        GenerateError (str): 报文造错，默认值：NO_ERROR，取值范围：

            NO_ERROR

            CRC

        IgnoreLinkState (str): 忽略连接状态，默认值：NO，取值范围：

            NO

            YES

        TimeStampPosTx (str): 发送时间戳位置，默认值：TIMESTAMP_HEAD，取值范围：

            TIMESTAMP_HEAD

            TIMESTAMP_TAIL

        TimeStampPosRx (str): 接收时间戳位置，默认值：TIMESTAMP_HEAD，取值范围：

            TIMESTAMP_HEAD

            TIMESTAMP_TAIL

        LatencyCompensationTx (int): 发送时延补偿，默认值：0

        LatencyCompensationRx (int): 接收时延补偿，默认值：0

        LatencyCompensationOn (bool): 时延补偿开启，默认值：True

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Port Load Profile | Ports=${Ports} | TransmitMode=CONTINUOUS | Unit=PERCENT | Rate=100 |
        | Edit Port Load Profile | Ports=${Ports} | TransmitMode=BURST | BurstSize=10 | InterFrameGap=20 | InterFrameGapUnit=MS | BurstCount=100 |
        | Edit Port Load Profile | Ports=${Ports} | TransmitMode=TIME | Seconds=10 |
        | Edit Port Load Profile | Ports=${Ports} | TransmitMode=STEP | Frames=10 |
        | Edit Port Load Profile | Ports=${Ports} | TransmitMode=ONSTREAM | Rate=50 | Unit=FRAME_PER_SEC |
    """

    result = renix.edit_port_load_profile(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_port_state(Ports=None, State=None, Interval=1, TimeOut=60):
    """
    等待测试仪表端口链路达到指定状态

    Args:

        Ports (list(:obj:`Port`)): 测试仪表端口对象列表

        State (str): 测试仪表连接端口状态, 默认值: UP，取值范围：

            DOWN

            UP

        Interval (int): 状态查询间隔, 默认值:1

        TimeOut (int): 超时时间, 默认值:60

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Port | Ports=${Ports} | EnableLink=False |
        | Wait Port State | Ports=${Ports} | State=DOWN |
    """

    result = renix.wait_port_state(Ports=Ports, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_stream_load_profile(Streams, **kwargs):
    """
    编辑测试仪表负载配置文件参数

    Args:

        Streams (list(:obj:`SreamTemplate`)): 测试仪表流量对象列表, 测试仪表流量对象object列表

    Keyword Args:

        Rate (int): 流量负载，默认值：10

        Unit (str): 流量负载单位，默认值：PERCENT，取值范围：

            PERCENT

            FRAME_PER_SEC

            BYTE_PER_SEC

            LINEBIT_PER_SEC

            KLINEBIT_PER_SEC

            MLINEBIT_PER_SEC

            INTER_FRAME_GAP

        StreamTransmitMode (str): BigTao参数, 默认值：CONTINUOUS，传输模式，支持：

            CONTINUOUS

            BURST

        FramePerBurst (int): BigTao参数, 仅当StreamTransmitMode为BURST有效，突发数量，默认值：100, 范围：1-4294967295

        BurstCount (int): BigTao参数, 仅当StreamTransmitMode为BURST有效，突发次数，默认值：1, 范围：1-4294967295

        BurstGap (int): BigTao参数, 仅当StreamTransmitMode为BURST有效，突发间隙，默认值：1, 范围：1-4294967295

        BurstGapUnit (str): BigTao参数, 仅当StreamTransmitMode为BURST有效，突发间隔单位, 支持：

            NS

            US

            MS

            SEC

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Port Load Profile | Ports=${Ports} | LoadProfileType=STREAM_BASE |
        | Edit Stream Load Profile | Streams=${Streams} | Rate=50 | Unit=FRAME_PER_SEC |
    """

    result = renix.edit_stream_load_profile(Streams=Streams, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Capture-------------------------------------
def start_capture(Ports=None):
    """
    启动测试仪表端口数据抓包

    Args:

        Ports (list): 测试仪仪表端口Port对象列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} | Create List | //192.168.0.1/1/1 | //192.168.0.1/1/2 |
        | ${Ports} | Reserve Ports | ${Ports} | ${Locations} |
        | Start Capture | Ports=${Ports} |
    """

    result = renix.start_capture(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_capture(Ports=None):
    """
    停止测试仪表端口数据抓包

    Args:

        Ports (list): 测试仪仪表端口Port对象列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Locations} | Create List | //192.168.0.1/1/1 | //192.168.0.1/1/2 |
        | ${Ports} | Reserve Ports | ${Ports} | ${Locations} |
        | Start Capture | Ports=${Ports} |
        | Sleep | 30 |
        | Stop Capture | Ports=${Ports} |
    """
    result = renix.stop_capture(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_capture(Ports, **kwargs):
    """
    编辑端口数据捕获参数

    Args:

        Ports: 测试仪表端口对象列表, 类型为：list

    Keyword Args:

        Name (str): 端口捕获名称, 类型为：string

        CaptureMode (str): 捕获模式：, 类型为：string, 默认值：ALL, 支持参数

            ALL

            CTRL_PLANE

            RealTime_All

        CacheCapacity (str): 缓存容量, 类型为：string, 默认值：Cache_Max, 支持参数

            Cache_Max

            Cache_32KB

            Cache_64KB

            Cache_128KB

            Cache_256KB

            Cache_512KB

            Cache_1MB

            Cache_2MB

            Cache_4MB

            Cache_8MB

            Cache_16MB

            Cache_32MB

            Cache_64MB

            Cache_128MB

            Cache_256MB

            Cache_512MB

            Cache_1GB

        FilterMode (str): 筛选模式, 类型为：string, 默认值：BYTE, 支持选项有：

            BYTE

            PDU

        BufferFullAction (str): 缓存区满后执行动作, 类型为：string, 默认值：STOP, 支持选项有：

            STOP

            WRAP

        StartingFrameIndex (int): 下载报文的起始编号, 类型为：number, 默认值：1

        AttemptDownloadPacketCount (int): 下载报文数量, 类型为：number, 默认值：0, 0表示下载所有报文

        FcsError (bool): Fec错误, 类型为：bool, 取值范围：True或False, 默认值：False

        Ipv4ChecksumError (bool): Ipv4 Checksum错误, 类型为：bool, 取值范围：True或False, 默认值：False

        PayloadError (bool): Payload错误, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableRealtimeCapture (bool): 捕获模式为Control Plane (Tx and Rx)或RealTime All(Control Plane tx/rx and data plane rx), 类型为：bool, 取值范围：True或False, 默认值：False

        SliceMode (str): 切片模式, 类类型为：string, 默认值：DISABLE, 支持选项有：

            DISABLE

            ENABLE

        SliceByteSize (int): 切片字节大小, 类型为：number, 取值范围：32-16383, 默认值：128

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Capture | Ports=${Ports} | CaptureMode=CTRL_PLANE |
    """

    result = renix.edit_capture(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_capture_byte_pattern(Port, **kwargs):
    """
    在指定端口上创建Byte Pattern

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        CustomCapturePatternOperator (str): 表达式位运算符, 类型为：string, 默认值：AND, 支持参数

            AND

            OR

            XOR

        CustomCapturePatternNot (bool): 表达式取反, 类型为：bool, 取值范围：True或False, 默认值：False

        UseFrameLength (bool): 使用Frame长度, 类型为：bool, 取值范围：True或False, 默认值：False

        Data (hex): 最小值, 类型为：string, 取值范围：十六进制字符串, 默认值：0x0

        MaxData (hex): 最大值, 类型为：string, 取值范围：十六进制字符串, 默认值：0xff

        Mask (hex): 掩码, 类型为：string, 取值范围：十六进制字符串, 默认值：0xff

        Offset (int): 偏移位, 类型为：number, 取值范围：0-16378, 默认值：0

        MinFrameLength (int): 最小长度,当UseFrameLength为True有效, 类型为：number, 取值范围：64-16383, 默认值：64

        MaxFrameLength (int): 最大长度,当UseFrameLength为True有效, 类型为：number, 取值范围：64-16383, 默认值：16383

    Returns:

        str: Byte Pattern唯一索引字符串string，例如：CaptureBytePattern_1

    Examples:
        robotframework:

    .. code:: robotframework

        | Create Capture Byte Pattern | Port=${Port} | Data=0x0 0x01 | Mask=0xff 0xff | Offset=0 | CustomCapturePatternOperator=OR | CustomCapturePatternNot=True |
    """

    result = renix.create_capture_byte_pattern(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_capture_pdu_pattern(Port, HeaderTypes, **kwargs):
    """
    在指定端口上创建Pdu Pattern

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        HeaderTypes (list): 指定报文结构

            ethernetii

            vlan

            vxlan

            arp

            ipv4

            ipv6

            tcp

            udp

            l2tpv2data

            l2tpv3controloverip

            ppp

            pppoe

            icmpv4echorequest

            destunreach

            icmpv4echoreply

            informationreply

            informationrequest

            icmpv4parameterproblem

            icmpv4redirect

            sourcequench

            timeexceeded

            timestampreply

            timestamprequest

            icmpmaskrequest

            icmpmaskreply

            destinationunreachable

            icmpv6echoreply

            icmpv6echorequest

            packettoobig

            icmpv6parameterproblem

            timeexceed

            routersolicit

            routeradvertise

            icmpv6redirect

            neighborsolicit

            neighboradvertise

            mldv1query

            mldv1report

            mldv1done

            mldv2query

            mldv2report

            igmpv1

            igmpv1query

            igmpv2

            igmpv2query

            igmpv3report

            igmpv3query

            custom

            ospfv2linkstateupdate

            ospfv2linkstaterequest

            ospfv2databasedescription

            ospfv2linkstateacknowledge

            ospfv2unknown

            ospfv2hello

            mpls

    Keyword Args:

        Level (int): 报文字段在流量模板中所有报文头部的序列号, 需要和Attribute字段同时使用

        Attribute (str): 报文字段参数名称, 需要和Level字段同时使用

        FieldName (str): 过滤字段名, 该字段不能与Level和Attribute同时使用

        CustomCapturePatternOperator (str): 表达式位运算符, 类型为：string, 默认值：AND, 支持参数

            AND

            OR

            XOR

        CustomCapturePatternNot (bool): 表达式取反：, 类型为：bool, 取值范围：True或False, 默认值：False

        Value (str): 最小值, 类型为：string

        MaxValue (str): 最大值, 类型为：string

        Mask (str): 掩码, 类型为：string

    Returns:

        str: Pdu Pattern的句柄，例如：CapturePduPattern_1

    Examples:
        robotframework:

    .. code:: robotframework

        | Init Tester |
        | ${Port} | reserve_port | Locations=//192.168.0.180/1/1 |
        | ${HeaderTypes} | Create List | EthernetII | IPv4 |
        | ${Stream} | Add Stream | Ports=${Port} |
        | Create Stream Header |Stream=${Stream} | HeaderTypes=${HeaderTypes} |
        | &{Attribute} | Edit Header Ipv4 |Stream=${Stream} | Level=0 | TTL=200 | Source=10.1.1.2 |
        # 使用Level和Attribute参数设置Pdu Pattern
        | ${Pattern_1} | Create Capture Pdu Pattern | Port=${Port} | HeaderTypes=${HeaderTypes} |  Level=1  | Attribute=${Attribute}[TTL] | Value=200 | MaxValue=200 |
        # 等价于：使用FieldName参数设置Pdu Pattern
        | ${Pattern_2} | Create Capture Pdu Pattern | Port=${Port} | HeaderTypes=${HeaderTypes} | FieldName=ipv4_1.ttl | Value=200 | MaxValue=200 |
    """

    result = renix.create_capture_pdu_pattern(Port=Port, HeaderTypes=HeaderTypes, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_capture_pattern(Pattern, **kwargs):
    """
    修改Capture Pattern参数

    Args:

        Pattern (str): Capture Pattern的标识, 类型为：sting，例如：CaptureBytePattern_1或CapturePduPattern_1

    Keyword Args:

        Byte Pattern支持的Args:

            CustomCapturePatternOperator (str): 表达式位运算符, 类型为：string, 默认值：AND, 支持参数

                AND

                OR

                XOR

            CustomCapturePatternNot (bool): 表达式取反, 类型为：bool, 取值范围：True或False, 默认值：False

            UseFrameLength (bool): 使用Frame长度, 类型为：bool, 取值范围：True或False, 默认值：False

            Data (str): 最小值, 类型为：string, 取值范围：十六进制字符串, 默认值：0x0,

            MaxData (str): 最大值, 类型为：string, 取值范围：十六进制字符串, 默认值：0xff,

            Mask (str): 掩码, 类型为：string, 取值范围：十六进制字符串, 默认值：0xff,

            Offset (int): 偏移位, 类型为：number, 取值范围：0-16378, 默认值：0

            MinFrameLength (int): 最小长度,当UseFrameLength为True有效, 类型为：number, 取值范围：64-16383, 默认值：64

            MaxFrameLength (int): 最大长度,当UseFrameLength为True有效, 类型为：number, 取值范围：64-16383, 默认值：16383

        Pdu Pattern支持的Args:

            Level (int): 报文字段在流量模板中所有报文头部的序列号, 需要和Attribute字段同时使用

            Attribute (str): 报文字段参数名称, 需要和Level字段同时使用

            FieldName (str): 过滤字段名, 该字段不能与Level和Attribute同时使用

            CustomCapturePatternOperator (str): 表达式位运算符, 类型为：string, 默认值：AND, 支持参数

                AND

                OR

                XOR

            CustomCapturePatternNot (bool): 表达式取反, 类型为：bool, 取值范围：True或False, 默认值：False

            Value (str): 最小值, 类型为：string

            MaxValue (str): 最大值, 类型为：string

            Mask (str): 掩码, 类型为：string

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${BytePattern} | Create Capture Byte Pattern | Port=${Port} | CustomCapturePatternOperator=OR | CustomCapturePatternNot=True |
        | ${HeaderTypes} | Create List | EthernetII | IPv4 | Icmpv4EchoReply |
        | ${PduPattern} | Create Capture Pdu Pattern | Port=${Port} | HeaderTypes=${HeaderTypes} | FieldName=Icmpv4EchoReply_1.code | Value=4 | MaxValue=5 | CustomCapturePatternOperator=OR | CustomCapturePatternNot=True |
        | Edit Capture Pattern | Pattern=${BytePattern} | CustomCapturePatternOperator=XOR|
        | Edit Capture Pattern | Pattern=${PduPattern} | CustomCapturePatternOperator=XOR|
    """

    result = renix.edit_capture_pattern(Pattern=Pattern, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_capture_filter(Port, Expression):
    """
    在指定端口上设置报文过滤逻辑表达式

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        Expression (str): 过滤逻辑表达式, 类型为：string

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${BytePattern} | Create Capture Byte Pattern | Port=${Port} | CustomCapturePatternOperator=OR | CustomCapturePatternNot=True |
        | ${HeaderTypes} | Create List | EthernetII | IPv4 | Icmpv4EchoReply |
        | ${PduPattern} | Create Capture Pdu Pattern | Port=${Port} | HeaderTypes=${HeaderTypes} | FieldName=Icmpv4EchoReply_1.code | Value=4 | MaxValue=5 | CustomCapturePatternOperator=OR | CustomCapturePatternNot=True |
        | Edit Capture Filter | Port=${Port} | Expression=${BytePattern} && ${PduPattern} |
    """

    result = renix.edit_capture_filter(Port=Port, Expression=Expression)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_capture_event(Port, EventType='QUALIFY', **kwargs):
    """
    在指定端口上设置帧捕获条件

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        EventType (str): 帧捕获类型, 类型为：string, 支持参数：

            QUALIFY

            START

            START

    Keyword Args:

        LogicRelation (str): 指定捕获事件之间的逻辑关系And或Or

        PatternMatch (str): 指定捕获事件之间的逻辑关系And或Or

        FcsError (str): FCS错误，支持IGNORE、INCLUDE或EXCLUDE

        PrbsError (str): FCS错误，支持IGNORE、INCLUDE或EXCLUDE

        Ipv4ChecksumError (str): IPv4校验和错误帧，支持IGNORE、INCLUDE或EXCLUDE

        TcpChecksumError (str): TCP校验和错误帧，支持IGNORE、INCLUDE或EXCLUDE

        UdpChecksumError (str): UDP校验和错误帧，支持IGNORE、INCLUDE或EXCLUDE

        IgmpChecksumError (str): Igmp校验和错误帧，支持IGNORE、INCLUDE或EXCLUDE

        IcmpChecksumError (str): Icmp校验和错误帧，支持IGNORE、INCLUDE或EXCLUDE

        SequenceError (str): 序列号错误帧，支持IGNORE、INCLUDE或EXCLUDE

        UndersizedFrame (str): 超短帧，支持IGNORE、INCLUDE或EXCLUDE

        OversizedFrame (str): 超长帧，支持IGNORE、INCLUDE或EXCLUDE

        JumboFrame (str): Jumbo帧，支持IGNORE、INCLUDE或EXCLUDE

        FrameLength (str): 特定长度帧，支持IGNORE、INCLUDE或EXCLUDE

        FrameLengthValue (int): 特定帧长度，默认值：0

        SignaturePresent (str): 带有签名的流帧 ，支持IGNORE、INCLUDE或EXCLUDE

        StreamIdMatch (str): 特定流号的流帧，支持IGNORE、INCLUDE或EXCLUDE

        StreamId (int): 特定流号，默认值：0

        Ipv4Packets (str): IPv4报文 ，支持IGNORE、INCLUDE或EXCLUDE

        TcpPackets (str): TCP报文，支持IGNORE、INCLUDE或EXCLUDE

        UdpPackets (str): UDP报文，支持IGNORE、INCLUDE或EXCLUDE

        Ipv6Packets (str): IPv6报文，支持IGNORE、INCLUDE或EXCLUDE

        IgmpPackets (str): IGMP报文，支持IGNORE、INCLUDE或EXCLUDE

        PayloadError (str): PRBS错误帧，支持IGNORE、INCLUDE或EXCLUDE

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Capture Event | Port=${Port} | EventType=QUALIFY | LogicRelation=Or | PrbsError=INCLUDE | FrameLength=INCLUDE | FrameLengthValue=128 |
    """

    result = renix.edit_capture_event(Port=Port, EventType=EventType, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def download_packages(Port, FileDir, FileName, MaxCount=0, TimeOut=30, AppendPortHandle=True):
    """
    下载指定端口捕获到的数据包

    Args:

        Port (:obj:`Port`): 测试仪表端口对象object

        FileDir (str): 报文保存的路径, ("D:/test")

        FileName (str): 报文保存的文件的名称

        MaxCount (int): 下载报文最大数量，默认值0, 表示下载端口上捕获到的所有报文

        TimeOut (int): 下载报文的超时时间单位秒，超时时间内为下载完成则下载失败, 默认值30

        AppendPortHandle (bool): 下载报文保存路径是否自动添加端口句柄

    Returns:

        str: 下载数据包文件的绝对路径(例如："D:\\test\\10.0.5.10_1_1\\dowload.pcap")

    Examples:
        robotframework:

    .. code:: robotframework

         | ${Port} | Get Ports |
         | &{File} | Download Packages | Port=${Port} | FileDir=D:/test | FileName=download |
    """

    result = renix.download_packages(Port=Port, FileDir=FileDir, FileName=FileName, MaxCount=MaxCount,
                                     TimeOut=TimeOut, AppendPortHandle=AppendPortHandle)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_capture_info(Port, Items=None):
    """
    在指定端口报文捕获信息

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        Items (list): 端口报文捕获信息, 支持参数：

            CaptureState

            ElapsedTime

            CapturedPacketCount

            BufferFull

            DownloadedPacketCount

            CurrentDataFile

    Returns:

        dict:

    Examples:
        robotframework:

    .. code:: robotframework

        | Get Capture Info | Port=${Port} |
    """

    result = renix.get_capture_info(Port=Port, Items=Items)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_capture_data(Port, Index=1):
    """
    在指定端口报文捕获信息

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        Index (int): 报文序号：


    Returns:

        dict:

    Examples:
        robotframework:

    .. code:: robotframework

        | Get Capture Data | Port=${Port} |
    """

    result = renix.get_capture_data(Port=Port, Index=Index)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

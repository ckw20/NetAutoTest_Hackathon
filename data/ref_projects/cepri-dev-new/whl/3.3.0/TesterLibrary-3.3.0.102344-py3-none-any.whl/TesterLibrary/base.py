import os
import re
from functools import wraps
from robot.api.deco import keyword, library
from TesterLibrary.Encryption.data import *
from TesterLibrary.Overall.common import *
from TesterLibrary.Port.capture import *
from TesterLibrary.Port.interface import *
from TesterLibrary.Port.common import *
from TesterLibrary.Port.interface import *
from TesterLibrary.Protocol.bfd import *
from TesterLibrary.Protocol.bgp import *
from TesterLibrary.Protocol.common import *
from TesterLibrary.Protocol.dhcpv4 import *
from TesterLibrary.Protocol.dhcpv6 import *
from TesterLibrary.Protocol.igmp import *
from TesterLibrary.Protocol.isis import *
from TesterLibrary.Protocol.l2tp import *
from TesterLibrary.Protocol.ldp import *
from TesterLibrary.Protocol.mld import *
from TesterLibrary.Protocol.multicast import *
from TesterLibrary.Protocol.ospfv2 import *
from TesterLibrary.Protocol.ospfv3 import *
from TesterLibrary.Protocol.pcep import *
from TesterLibrary.Protocol.lsp_ping import *
from TesterLibrary.Protocol.pim import *
from TesterLibrary.Protocol.pppoe import *
from TesterLibrary.Protocol.rip import *
from TesterLibrary.Protocol.vxlan import *
from TesterLibrary.Protocol.dot1x import *
from TesterLibrary.Protocol.dot3ah import *
from TesterLibrary.Protocol.dot1ag import *
from TesterLibrary.Protocol.saa import *
from TesterLibrary.Protocol.y1731 import *
from TesterLibrary.Protocol.lacp import *
from TesterLibrary.Protocol.openflow import *
from TesterLibrary.Protocol.ovsdb import *
from TesterLibrary.Protocol.twamp import *
from TesterLibrary.Protocol.ieee8021as import *
from TesterLibrary.Statistic.common import *
from TesterLibrary.Stream.common import *
from TesterLibrary.Stream.imix import *
from TesterLibrary.Stream.Header.Access.common import *
from TesterLibrary.Stream.Header.Access.l2tpv2 import *
from TesterLibrary.Stream.Header.Access.l2tpv3 import *
from TesterLibrary.Stream.Header.Access.dhcpv4 import *
from TesterLibrary.Stream.Header.Access.dhcpv6 import *
from TesterLibrary.Stream.Header.Basic.common import *
from TesterLibrary.Stream.Header.Gre.common import *
from TesterLibrary.Stream.Header.L2.common import *
from TesterLibrary.Stream.Header.L2.isis import *
from TesterLibrary.Stream.Header.L3.common import *
from TesterLibrary.Stream.Header.L3.icmpv4 import *
from TesterLibrary.Stream.Header.L3.icmpv6 import *
from TesterLibrary.Stream.Header.L3.igmp import *
from TesterLibrary.Stream.Header.L4.common import *
from TesterLibrary.Stream.Header.L4.gtpv1 import *
from TesterLibrary.Stream.Header.L4.vxlan import *
from TesterLibrary.Stream.Header.Routing.ospfv2 import *
from TesterLibrary.Stream.Header.Routing.rip import *
from TesterLibrary.Stream.Header.dot1ah.dot1ah import *
from TesterLibrary.Stream.Header.Access.ancp import *
from TesterLibrary.Stream.Header.bier import *
from TesterLibrary.Stream.Header.eoam import *
from TesterLibrary.Stream.Header.L2.hdlc import *
from TesterLibrary.Stream.Header.L2.control_word import *
from TesterLibrary.Stream.Header.L2.fcoe import *
from TesterLibrary.Stream.Header.L2.mstp import *
from TesterLibrary.Stream.Header.LldpTlv.lldp import *
from TesterLibrary.Stream.Header.L2.hsr import *
# TODO prp报文头在3.3.0未发布
# from TesterLibrary.Stream.Header.L2.prp import *
from TesterLibrary.Stream.Header.L2.rtag import *
from TesterLibrary.Stream.Header.L4.sctp import *
from TesterLibrary.Stream.Header.trill import *
from TesterLibrary.Wizard.benchmark import *
from TesterLibrary.Wizard.mpls import *
from TesterLibrary.Wizard.bgp_route import *
from TesterLibrary.Wizard.isis_lsp import *
from TesterLibrary.Wizard.ospfv2_lsa import *
from TesterLibrary.Wizard.ospfv3_lsa import *
from TesterLibrary.Wizard.rip_route import *
from TesterLibrary.Wizard.tsn import *

module_fun_name = []

dirname, tempfilename = os.path.split(os.path.abspath(__file__))
pattern = re.compile("def (.*)\(")
for root, dirs, files in os.walk(dirname):
    for f in files:
        filename, extension = os.path.splitext(f)
        # TODO prp报文头在3.3.0未发布
        if f not in ('base.py', 'data.py', 'prp.py', '__init__.py') and extension == '.py':
            for i, line in enumerate(open(os.path.join(root, f), encoding='utf-8')):
                for match in re.finditer(pattern, line):
                    module_fun_name.append(match.groups()[0])

module_fun = [globals()[x] for x in module_fun_name]


class Meta(type):
    def __new__(mcs, name, bases, attrs):
        for attr in module_fun:
            attrs[attr.__name__] = staticmethod(keyword()(attr))
        return type.__new__(mcs, name, bases, attrs)


@library
class TesterLibrary(metaclass=Meta):
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    # ROBOT_LIBRARY_DOC_FORMAT = 'reST'

    def __init__(self, logLevel=logging.INFO, logHandle=LogHandle.LOG_FILE):
        renix.edit_log(logLevel=logLevel, logHandle=logHandle)
        self.__API = renix

    @property
    def API(self):
        return self.__API

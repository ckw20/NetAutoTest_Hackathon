import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_ospfv2_lsa_wizard(Sessions, **kwargs):
    """
    测试仪表创建Ospfv2 Lsa向导

    Args:

        Sessions (list): 所属的OSPFv2协议会话对象

    Returns:

        Wizard (:obj:`Ospfv2LsaWizardConfig`): Ospfv2 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Create Ospfv2 Lsa Wizard | Sessions=@{sessions} |
    """

    result = renix.create_ospfv2_lsa_wizard(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv2_lsa_wizard_ospfv2_topo(Wizards, Type, **kwargs):
    """
    Ospfv2 Lsa向导配置Ospfv2拓扑

    Args:

        Wizards (list): Ospfv2 Lsa wizard

        Type (str): 拓扑类型，默认值：TREE，取值范围：

            NONE

            TREE

            GRID

            FULLMESH

            RING

            HUBSPOKE

    Keyword Args:

        树型拓扑参数：

            SimulatedRoutersCount (int): Simulated Router的数量，默认值：50，取值范围：1-10000

            InterfaceType (str): 接口类型，默认值：P2P，取值范围：

                BROADCAST

                P2P

            RouterMaxInterfaceCount (int): 每个路由器的最大接口数量，默认值：4，取值范围：1-100

            TransitNetworkMaxRouterCount (int): 每个传输网络的最大路由器数量，默认值：5，取值范围：2-10000

        网络拓扑参数：

            UneditableSimulatedRoutersCount (int): Simulated Router的数量，默认值：16，取值范围：0-10000

            EmulatedRouterPossessSimulatedRouterCount (int): 每个Emulated Router上的Simulated Routers数量，默认值：16，取值范围：0-10000

            RowCount (int): 行数，默认值：4，取值范围：1-10000

            ColumnCount (int): 列数，默认值：4，取值范围：1-10000

            GridEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTOGRID，取值范围：

                ATTACHEDTOGRID

                MEMBEROFGRID

            EmulatedRouterAttachRowIndex (int): Emulated Router所属行，默认值：1，取值范围：1-10000

            EmulatedRouterAttachColumnIndex (int): Emulated Router所属列，默认值：1，取值范围：1-10000

        全连接拓扑参数：

            MeshRouterCount (int): 全网状网络中所有路由器数量，默认值：10，取值范围：1-100

            MeshEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTOMESH，取值范围：

                ATTACHEDTOMESH

                MEMBEROFMESH

        环型拓扑参数：

            RingRouterCount (int): 环型网络中所有路由器数量，默认值：10，取值范围：1-10000

            RingEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTORING，取值范围：

                ATTACHEDTORING

                MEMBEROFRING

        星型拓扑参数：

            HubSpokeRouterCount (int): 星型网络中所有路由器数量，默认值：10，取值范围：1-100

            HubSpokeEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTOHUB，取值范围：

                ATTACHEDTOHUB

                ATTACHEDTOSPOKE

                MEMBERASHUB

                MEMBERASSPOKE

    Returns:

        Wizard (:obj:`Ospfv2LsaWizardConfig`): Ospfv2 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv2 Lsa Wizard Ospfv2 Topo | Wizards=@{wizard} | Type=TREE |
    """

    result = renix.config_ospfv2_lsa_wizard_ospfv2_topo(Wizards=Wizards, Type=Type, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv2_lsa_wizard_ospfv2(Wizards, **kwargs):
    """
    Ospfv2 Lsa向导配置Ospfv2

    Args:

        Wizards (list): Ospfv2 Lsa wizard

    Keyword Args:

        StartingPrefixRange (str): 起始前缀，默认值：1.0.0.0，取值范围：有效的ipv4地址

        EndingPrefixRange (str): 结束前缀，默认值：235.255.255.255，取值范围：有效的ipv4地址

        EnableP2pLinks (bool): 使能创建P2P链接，默认值：False

        EnableTeOption (bool): 使能流量工程选项，默认值：False

        EnableSegmentRouting (bool): 使能段路由，默认值：False

        AreaType (str): 区域类型，默认值：REGULAR，取值范围：

            REGULAR

            STUB

            STUBNOSUMMARY

            NSSA

            NSSANOSUMMARY

        StartingInterfaceIp (str): 接口的起始地址，默认值：1.0.0.0，取值范围：有效的ipv4地址

        InterfacePrefixLength (int): 接口的前缀长度，默认值：24，取值范围：1-32

        InterfaceOverride (bool): 使能覆盖，默认值：False

        StartingRouterId (str): 起始路由器ID，默认值：1.0.0.1，取值范围：有效的ipv4地址

        EnableAdvertiseRouterId (bool): 使能为环回地址通告路由器ID，默认值：False

        RouterIdStep (str): 路由器ID步长，默认值：0.0.0.1，取值范围：有效的ipv4地址

    Returns:

        Wizard (:obj:`Ospfv2LsaWizardConfig`): Ospfv2 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv2 Lsa Wizard Ospfv2 | Wizards=@{wizard} |
    """

    result = renix.config_ospfv2_lsa_wizard_ospfv2(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv2_lsa_wizard_ospfv2_te_option(Wizards, **kwargs):
    """
    Ospfv2 Lsa向导配置Ospfv2中的TE选项

    Args:

        Wizards (list): Ospfv2 Lsa wizard

    Keyword Args:

        EnableLocalIp (bool): 是否包含本地IPv4地址, 默认值：False

        LocalIp (str): 本地IPv4地址, 取值范围：有效的ip地址, 默认值：'0.0.0.0'

        EnableRemoteIp (bool): 是否包含邻居IPv4地址, 默认值：False

        RemoteIp (int): 邻居IPv4地址, 取值范围：有效的ip地址, 默认值：10

        EnableLocalIpv6 (bool): 是否包含本地IPv6地址, 默认值：False

        LocalIpv6 (str): 本地IPv6地址, 取值范围：有效的ipv6地址, 默认值：'2000::1'

        EnableRemoteIpv6 (bool): 是否包含邻居IPv6地址, 默认值：False

        RemoteIpv6 (str): 邻居IPv6地址, 取值范围：有效的ipv6地址, 默认值：'2000::1'

        EnableGroup (bool): 启用组, 默认值：False

        Group (int): 组, 取值范围：0-4294967295, 默认值：1

        EnableMaxBandwidth (bool): 是否包含最大带宽值, 默认值：False

        MaximunLink (int): 最大带宽值(字节/秒), 取值范围：0-4294967295, 默认值：1000

        EnableResBandwidth (bool): 是否包含预留带宽值, 默认值：False

        MaximumReservableLink (int): 最大预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：1000

        EnableUnresBandwidth (bool): 是否包含未预留带宽优先级, 默认值：False

        UnreservedBandwidth0 (int): 优先级0的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth1 (int): 优先级1的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth2 (int): 优先级2的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth3 (int): 优先级3的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth4 (int): 优先级4的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth5 (int): 优先级5的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth6 (int): 优先级6的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth7 (int): 优先级7的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`TrafficEngineeringConfig`): Ospfv2 Te对象

    Examples:
        .. code:: RobotFramework

            | Config Ospfv2 Lsa Wizard Ospfv2 Te Option | Wizards=@{wizard} |
    """

    result = renix.config_ospfv2_lsa_wizard_ospfv2_te_option(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv2_lsa_wizard_ospfv2_sr(Wizards, **kwargs):
    """
    Ospfv2 Lsa向导配置Ospfv2中的SR

    Args:

        Wizards (list): Ospfv2 Lsa wizard

    Keyword Args:

        配置能力：

            SidLabelType (str): 值类型, 默认值：BIT20, 取值范围：

                BIT20

                BIT32

            SidLabelBase (list): SID/Label Bases，默认值：[800000]，取值范围：

            SidLabelRange (list): SID/Label Ranges，默认值：[80000]，取值范围：

            Algorithms (int): Algorithms List，默认值：0

        配置节点：

            NodeSidIndexLabel (int): SID/Index/Label，默认值：101

            NodeSidStep (int): 步长，默认值：1

            NodeAlgorithm (int): Algorithm，默认值：0

            NodeFlags (list): Flags，默认值：['NoPhp']，取值范围：

                NoPhp

                MappingServer

                ExplicitNull

                ValueIndex

                LocalGlobal

        邻接：

            GenerateSidForLink (bool): 使能获取邻接SID，默认值：False

            AdjacencySid (int): 邻接SID，默认值：24001

            AdjacencyStep (int): 步长，默认值：1

        前缀：

            GenerateSidForPrefix (bool): 使能获取前缀SID，默认值：False

            PrefixSidIndexLabel (int): SID/Index/Label，默认值：11000

            PrefixSidStep (int): 步长，默认值：1

            PrefixFlags (list): Flags，默认值：['NoPhp']，取值范围：

                NoPhp

                MappingServer

                ExplicitNull

                ValueIndex

                LocalGlobal

            PrefixExtTLV (int): % Ext Prefix TLV，默认值：100

            PrefixExtRangeTLV (int): % Ext PRefix Range TLV，默认值：0

        选播：

            EnableAnycast (bool): 使能选播，默认值：False

            AnycastRangeSize (int): Range Size，默认值：8000

            AnycastSidLabelBase (int): Base SID/Label，默认值：16000

            AnycastSidIndex (int): SID/Index，默认值：100

            AnycastIpv4Address (str): ipv4地址，默认值：192.0.0.1

            AnycastFlags (list): Prefix SID Flags, 默认值：['NoPhp']，取值范围：

                NoPhp

                MappingServer

                ExplicitNull

                ValueIndex

                LocalGlobal

    Returns:

        (:obj:`Ospfv2SrConfig`): Ospfv2 sr对象

    Examples:
        .. code:: RobotFramework

            | Config Ospfv2 Lsa Wizard Ospfv2 Sr | Wizards=@{wizard} |
    """

    result = renix.config_ospfv2_lsa_wizard_ospfv2_sr(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv2_lsa_wizard_ospfv2_stub_network(Wizards, **kwargs):
    """
    Ospfv2 Lsa向导配置Ospfv2 stub网络

    Args:

        Wizards (list): Ospfv2 Lsa wizard

    Keyword Args:

        StubEmulated (str): Emulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        StubSimulated (str): Simulated Routers, 默认值：NONE，取值范围：

            NONE

            ALL

            EDGE

        StubRoutesCount (int): 要创建的路由的数量，默认值：0

        StubOverride (bool): 使能覆盖，默认值：False

        StubStartingIpPrefix (str): 起始前缀，默认值：1.0.0.0，取值范围：有效的ipv4地址

        StubEndingIpPrefix (str): 结束前缀，默认值：223.255.255.255，取值范围：有效的ipv4地址

        StubDistributionType (str): 前缀分布类型，默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        StubStartPrefixLength (int): 起始前缀长度，默认值：24，取值范围：1-32

        StubEndPrefixLength (int): 结束前缀长度，默认值：24，取值范围：1-32

        StubInternetPrefixLength (list): internet类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        StubCustomPrefixLength (list): custom类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        StubPrimaryMetric (int): 度量值，默认值：1，取值范围：1-16777215

    Returns:

        Wizard (:obj:`Ospfv2LsaWizardConfig`): Ospfv2 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv2 Lsa Wizard Ospfv2 Stub Network | Wizards=@{wizard} |
    """

    result = renix.config_ospfv2_lsa_wizard_ospfv2_stub_network(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv2_lsa_wizard_ospfv2_summary_route(Wizards, **kwargs):
    """
    Ospfv2 Lsa向导配置Ospfv2 Summary路由

    Args:

        Wizards (list): Ospfv2 Lsa wizard

    Keyword Args:

        SummaryEmulated (str): Emulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        SummarySimulated (str): Simulated Routers, 默认值：NONE，取值范围：

            NONE

            ALL

            EDGE

        SummaryRoutesCount (int): 要创建的路由的数量，默认值：0

        SummaryOverride (bool): 使能覆盖，默认值：False

        SummaryStartingIpPrefix (str): 起始前缀，默认值：1.0.0.0，取值范围：有效的ipv4地址

        SummaryEndingIpPrefix (str): 结束前缀，默认值：223.255.255.255，取值范围：有效的ipv4地址

        SummaryDistributionType (str): 前缀分布类型，默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        SummaryStartPrefixLength (int): 起始前缀长度，默认值：24，取值范围：1-32

        SummaryEndPrefixLength (int): 结束前缀长度，默认值：24，取值范围：1-32

        SummaryInternetPrefixLength (list): internet类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        SummaryCustomPrefixLength (list): custom类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        SummaryPrimaryMetric (int): 度量值，默认值：1，取值范围：1-16777215

    Returns:

        Wizard (:obj:`Ospfv2LsaWizardConfig`): Ospfv2 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv2 Lsa Wizard Ospfv2 Summary Route | Wizards=@{wizard} |
    """

    result = renix.config_ospfv2_lsa_wizard_ospfv2_summary_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def config_ospfv2_lsa_wizard_ospfv2_external_route(Wizards, **kwargs):
    """
    Ospfv2 Lsa向导配置Ospfv2 External路由

    Args:

        Wizards (list): Ospfv2 Lsa wizard

    Keyword Args:

        ExternalEmulated (str): Emulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        ExternalSimulated (str): Simulated Routers, 默认值：NONE，取值范围：

            NONE

            ALL

            EDGE

        ExternalRoutesCount (int): 要创建的路由的数量，默认值：0

        ExternalOverride (bool): 使能覆盖，默认值：False

        ExternalStartingIpPrefix (str): 起始前缀，默认值：1.0.0.0，取值范围：有效的ipv4地址

        ExternalEndingIpPrefix (str): 结束前缀，默认值：223.255.255.255，取值范围：有效的ipv4地址

        ExternalDistributionType (str): 前缀分布类型，默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        ExternalStartPrefixLength (int): 起始前缀长度，默认值：24，取值范围：1-32

        ExternalEndPrefixLength (int): 结束前缀长度，默认值：24，取值范围：1-32

        ExternalInternetPrefixLength (list): internet类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        ExternalCustomPrefixLength (list): custom类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        ExternalPrimaryMetric (int): 度量值，默认值：1，取值范围：1-16777215

    Returns:

        Wizard (:obj:`Ospfv2LsaWizardConfig`): Ospfv2 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv2 Lsa Wizard Ospfv2 External Route | Wizards=@{wizard} |
    """

    result = renix.config_ospfv2_lsa_wizard_ospfv2_external_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def expand_ospfv2_lsa_wizard(Wizards):
    """
    生成Ospfv2 Lsa向导配置

    Args:

        Wizards (list): Ospfv2 Lsa wizard对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Expand Ospfv2 Lsa Wizard | Wizards=@{Wizards} |
    """

    result = renix.expand_ospfv2_lsa_wizard(Wizards=Wizards)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

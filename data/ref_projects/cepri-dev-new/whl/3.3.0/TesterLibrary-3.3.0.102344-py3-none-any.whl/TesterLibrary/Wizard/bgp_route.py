import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_bgp_route_wizard(Sessions, **kwargs):
    """
    测试仪表创建BGP route向导

    Args:

        Sessions (list): 所属的BGP协议会话对象

    Keyword Args:

        BgpRouteType (str): 路由类型，默认值：NO_ROUTES，取值范围：

            IPV4_ROUTES

            IPV6_ROUTES

            IPV4_IPV6

            NO_ROUTES

        EnableLinkState (bool): 使能link state route，默认值：False

    Returns:

        Wizard (:obj:`BgpRouteWizardConfig`): BGP route wizard

    Examples:
        .. code:: RobotFramework

            | Create Bgp Route Wizard | Sessions=@{sessions} |
    """

    result = renix.create_bgp_route_wizard(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def config_bgp_route_wizard_ipv4(Wizards, **kwargs):
    """
    配置BGP route ipv4向导

    Args:

        Wizards (list): BGP route wizard对象

    Keyword Args:

        TotalIpv4RouteCount (int): 路由数量（若要生成多条会话的路由，数量需大于会话数量），默认值：1, 取值范围：1-4294967295

        DuplicateIpv4Route (str): 复制，默认值：0.0, 取值范围：0.0-100.0

        FirstRoute (str): 起始ipv4路由，默认值：“192.0.1.0”, 取值范围：有效的ipv4地址

        LastRoute (str): 结束ipv4路由，默认值：“233.255.255.255”, 取值范围：有效的ipv4地址

        IPv4DistributionType (str): 前缀分布类型，默认值：“FIXED”, 取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        PrefixLength (int): ipv4地址前缀长度，默认值：24, 取值范围：1-32

        EndPrefixLength (int): ipv4地址结束前缀长度，默认值：24, 取值范围：1-32

        CustomPrefixLength (list): custom类型的as path，取值范围：长度为32的列表，总和为100.0

        InternetPrefixLength (list): internet类型的as path，取值范围：长度为32的列表，总和为100.0

        UseSessionAddressAsNextHop (bool): 是否使能BGP会话地址作为下一跳地址，默认值：True

        NextHop (str): 下一跳，默认值："192.0.0.1", 取值范围：有效的ipv4地址

        NextHopStep (str): 下一跳跳变，默认值："0.0.0.1", 取值范围：有效的ipv4地址

        LocalPref (int): Local Pref路径属性，默认值：10, 取值范围：1-4294967295

        LocalPrefStep (int): Local Pref路径属性跳变，默认值：0, 取值范围：1-4294967295

        EnableMed (bool): 使用MULTI_EXIT_DISC路径属性，默认值：False

        MultExitDisc (int): MULTI_EXIT_DISC路径属性，默认值：0, 取值范围：1-4294967295

        MultExitDiscStep (int): MULTI_EXIT_DISC路径属性跳变，默认值：0, 取值范围：1-4294967295

        Ipv4AsPathDistributionType (str): AS path长度分布类型，默认值：FIXED, 取值范围：

            FIXED

            INTERNET

            CUSTOM

        CustomAsPath (list): custom类型的as path，取值范围：长度为32的列表，总和为100.0

        InternetAsPath (list): internet类型的as path，取值范围：长度为32的列表，总和为100.0

        Ipv4AsPathSuffix (str): 主AS path后缀，默认值：""

        Ipv4AsPathIncrement (str): 主AS path后缀跳变，默认值：""

        Ipv4SecondaryAsPathSuffix (str): 从属AS path后缀，默认值：""

        Ipv4SecondaryAsPathIncrement (str): 从属AS path后缀跳变，默认值：""

    Returns:

        Wizard (:obj:`BgpRouteWizardConfig`): BGP route wizard

    Examples:
        .. code:: RobotFramework

            | Config Bgp Route Wizard Ipv4 | Wizards=@{wizard} |
    """

    result = renix.config_bgp_route_wizard_ipv4(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_bgp_route_wizard_ipv6(Wizards, **kwargs):
    """
    配置BGP route ipv6向导

    Args:

        Wizards (list): BGP route wizard对象

    Keyword Args:

        TotalIpv6RouteCount (int): 路由数量，默认值：1, 取值范围：1-4294967295

        DuplicateIpv6Route (str): 复制，默认值：0.0, 取值范围：0.0-100.0

        IPv6DistributionType (str): 前缀分布类型，默认值：“FIXED”, 取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        FirstIpv6Route (str): 起始ipv4路由，默认值：“2000::", 取值范围：有效的ipv6地址

        LastIpv6Route (str): 结束ipv6路由，默认值：“3ffe::”, 取值范围：有效的ipv6地址

        Ipv6PrefixLength (int): ipv6地址前缀长度，默认值：64, 取值范围：1-128

        EndIpv6PrefixLength (int): ipv6地址结束前缀长度，默认值：64, 取值范围：1-128

        CustomPrefixLength (list): custom类型的as path，取值范围：长度为128的列表，总和为100.0

        InternetPrefixLength (list): internet类型的as path，取值范围：长度为128的列表，总和为100.0

        Ipv6RouteUseSessionAddressAsNextHop (bool): 是否使能BGP会话地址作为下一跳地址，默认值：True

        Ipv6NextHop (str): 下一跳，默认值："2001::1", 取值范围：有效的ipv6地址

        Ipv6NextHopStep (str): 下一跳跳变，默认值："::1", 取值范围：有效的ipv6地址

        Ipv6RouteLocalPref (int): Local Pref路径属性，默认值：10, 取值范围：1-4294967295

        Ipv6RouteLocalPrefStep (int): Local Pref路径属性跳变，默认值：0, 取值范围：1-4294967295

        Ipv6RouteEnableMed (bool): 使用MULTI_EXIT_DISC路径属性，默认值：False

        Ipv6RouteMultExitDisc (int): MULTI_EXIT_DISC路径属性，默认值：0, 取值范围：1-4294967295

        Ipv6RouteMultExitDiscStep (int): MULTI_EXIT_DISC路径属性跳变，默认值：0, 取值范围：1-4294967295

        Ipv6AsPathDistributionType (str): AS path长度分布类型，默认值：FIXED, 取值范围：

            FIXED

            INTERNET

            CUSTOM

        CustomAsPath (list): custom类型的as path，取值范围：长度为128的列表，总和为100.0

        InternetAsPath (list): internet类型的as path，取值范围：长度为128的列表，总和为100.0

        Ipv6AsPathSuffix (str): 主AS path后缀，默认值：""

        Ipv6AsPathIncrement (str): 主AS path后缀跳变，默认值：""

        Ipv6SecondaryAsPathSuffix (str): 从属AS path后缀，默认值：""

        Ipv6SecondaryAsPathIncrement (str): 从属AS path后缀跳变，默认值：""

    Returns:

        Wizard (:obj:`BgpRouteWizardConfig`): BGP route wizard

    Examples:
        .. code:: RobotFramework

            | Config Bgp Route Wizard Ipv6 | Wizards=@{wizard} |
    """

    result = renix.config_bgp_route_wizard_ipv6(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_bgp_route_wizard_igp_topo(Wizards, **kwargs):
    """
    BGP route向导配置IGP拓扑

    Args:

        Wizards (list): BGP route wizard对象

    Keyword Args:

        ProtocolType (str): IGP Protocol, 默认值：OSPFV2, 取值范围：

            OSPFV2

            ISIS_IPV4

        NumberOfArea (int): Number of areas, 默认值：2, 取值范围：1-100

        Topology (str): Topology, 默认值：FULL_MESH, 取值范围：

            FULL_MESH

            GRID

        BackboneHeadendRouters (int): Headend routers, 默认值：2, 取值范围：1-1000

        CoreRouterNum (int): Core routers, 默认值：4, 取值范围：1-100

        BackboneRows (int): Number of rows, 默认值：2, 取值范围：2-10000

        BackboneColumns (int): Number of columns, 默认值：2, 取值范围：2-10000

        ABRNumber (str): Number of ABRs, 默认值：CONFIG_1, 取值范围：

            CONFIG_1

            CONFIG_2

        IntraTopology (str): Intra Topology, 默认值：TREE, 取值范围：

            GRID

            TREE

        NonBackboneHeadendRouters (int): Headend routers per area, 默认值：2, 取值范围：1-1000

        NonBackboneRows (int): Number of grid rows, 默认值：2, 取值范围：2-10000

        NonBackboneColumns (int): Number of grid columns, 默认值：2, 取值范围：2-10000

        TotalIntraRouters (int): Total number of intra area routers, 默认值：6, 取值范围：1-10000

        InterfaceType (str): Intra Topology, 默认值：POINT_TO_POINT, 取值范围：

            POINT_TO_POINT

            BROADCAST

        MaxInterfacePerRouter (int): Max interface per router, 默认值：3, 取值范围：1-1000

        MaxRouterPerTransit (int): Max routers per transit network, 默认值：3, 取值范围：2-1000

    Returns:

        Wizard (:obj:`BgpLinkStateRouteWizardConfig`): BGP route link state wizard

    Examples:
        .. code:: RobotFramework

            | Config Bgp Route Wizard Igp Topo | Wizards=@{wizard} |
    """

    result = renix.config_bgp_route_wizard_igp_topo(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_bgp_route_wizard_igp(Wizards, **kwargs):
    """
    BGP route向导配置IGP

    Args:

        Wizards (list): BGP route wizard对象

    Keyword Args:

        Ipv4Prefix (str): Starting IPv4 prefix, 默认值："1.0.0.0", 取值范围：有效的ipv4地址

        EndIpv4Prefix (str): Ending IPv4 prefix, 默认值："223.225.255.255", 取值范围：有效的ipv4地址

        Ipv4PrefixLength (int): IPv4 Prefix Length, 默认值：24, 取值范围：1-32

        StartSystemId (str): Starting System ID, 默认值："10:00:00:00:00:01", 取值范围：有效的mac地址

        SystemIdStep (str): System ID Step, 默认值："00:00:00:00:00:01", 取值范围：有效的mac地址

        EnableAdvLoopback (bool): Advertise router ID for loopback address, 默认值：False

        RouterId (str): Router ID, 默认值："1.0.0.1", 取值范围：有效的ipv4地址

        RouterIdStep (str): Router ID Step, 默认值："0.0.0.1", 取值范围：有效的ipv4地址

        EnableIGPmetric (bool): Enable IGP metric, 默认值：False

        IgpMetricTypeIsis (str): IGP Metric TLV Type, 默认值：ISIS_SMALL, 取值范围：

            ISIS_SMALL

            ISIS_WIDE

        IgpMetricTypeOspf (str): IGP Metric TLV Type, 默认值：OSPF_LINK, 取值范围：

            OSPF_LINK

        EnableSegmentRouting (bool): Enable segment routing, 默认值：False

        Algorithm (str): Algorithms, 默认值："0"

        SidLabelType (str): SID/Label Type, 默认值：BIT20_LABEL, 取值范围：

            BIT20_LABEL

            BIT32_SID

        SidLabelBase (int): SID/Label Base, 默认值：100, 取值范围：0-4294967295

        SidLabelRange (int): SID/Label Range, 默认值：100, 取值范围：1-16777215

        LinkAdjSidLabel (int): Link SID/Label, 默认值：9001, 取值范围：0-4294967295

        PrefixAdjSidLabel (int): Prefix SID/Label, 默认值：0, 取值范围：0-4294967295

        SidLabelStep (int): Link SID/Label Step, 默认值：1, 取值范围：0-4294967295

        EnableTeOptions (bool): Enable traffic engineering options, 默认值：False

        EnableVaryheaderendMetric (bool): Vary headerend router metric, 默认值：True

        HeaderendMetricEnableIGPMetric (bool): IGP metric, 默认值：False

        HeaderendMetricEnableSegmentRoutingWeight (bool): Segment Routing weight, 默认值：False

        HeaderendMetricEnablePrefixMetric (bool): Prefix metric, 默认值：True

        EnableReservableStep (bool): Enable Reservable step, 默认值：False

        ReservableStep (int): Reservable step, 默认值：10000, 取值范围：1-4294967295

        EnableUnreserved (bool): Enable Unreserved(Priority 0-7), 默认值：False

        UnreservedBandwidth0 (int): Unreserved Bandwidth Priority0 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

        UnreservedBandwidth1 (int): Unreserved Bandwidth Priority1 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

        UnreservedBandwidth2 (int): Unreserved Bandwidth Priority2 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

        UnreservedBandwidth3 (int): Unreserved Bandwidth Priority3 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

        UnreservedBandwidth4 (int): Unreserved Bandwidth Priority4 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

        UnreservedBandwidth5 (int): Unreserved Bandwidth Priority5 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

        UnreservedBandwidth6 (int): Unreserved Bandwidth Priority6 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

        UnreservedBandwidth7 (int): Unreserved Bandwidth Priority7 (bytes/sec), 默认值：100000, 取值范围：1-4294967295

    Returns:

        Wizard (:obj:`BgpLinkStateRouteWizardConfig`): BGP route link state wizard

    Examples:
        .. code:: RobotFramework

            | Config Bgp Route Wizard Igp | Wizards=@{wizard} |
    """

    result = renix.config_bgp_route_wizard_igp(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_bgp_route_wizard_igp_te_option(Wizards, **kwargs):
    """
    BGP route向导配置IGP中的TE选项

    Args:

        Wizards (list): BGP route wizard对象

    Keyword Args:

        EnableInterfaceIp (bool): 启用本端IPv4地址, 类型为：bool, 取值范围：True或False, 默认值：False

        InterfaceIp (str): 本端IPv4地址, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        EnableNeighborIp (bool): 启用远端IPv4地址, 类型为：bool, 取值范围：True或False, 默认值：False

        NeighborIp (str): 远端IPv4地址, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        EnableInterfaceIpv6 (bool): 启用本端IPv6地址, 类型为：bool, 取值范围：True或False, 默认值：False

        InterfaceIpv6 (str): 本端IPv6地址, 类型为：有效的ipv4地址, 默认值：2000::1

        EnableNeighborIpv6 (bool): 启用远端IPv6地址, 类型为：bool, 取值范围：True或False, 默认值：False

        NeighborIpv6 (str): 启用远端IPv6地址, 类型为：有效的ipv6地址, 默认值：2000::1

        EnableGroup (bool): 启用组, 类型为：bool, 取值范围：True或False, 默认值：False

        Group (int): 组, 类型为：number, 取值范围：1-4294967295, 默认值：1

        EnableUniLinkLoss (bool): 启用单向链路损耗, 类型为：bool, 取值范围：True或False, 默认值：False

        LinkLoss (int): 链路损耗, 类型为：number, 取值范围：1-100, 默认值：3

        LinkLossAflag (bool): 链路损耗的A-flag, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableUniDelay (bool): 启用单向延迟, 类型为：bool, 取值范围：True或False, 默认值：False

        UniDelay (int): 单向延迟, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UniAflag (bool): 单向延迟的A-flag, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableUniMinMaxDelay (bool): 启用单向延迟最小/最大值, 类型为：bool, 取值范围：True或False, 默认值：False

        UniMinMaxAflag (bool): 启用单向延迟最小/最大值的A-flag类型为：bool, 取值范围：True或False, 默认值：False

        UniMinDelay (int): 单向最小延迟, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UniMaxDelay (int): 单向最大延迟, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniDelayVariation (bool): 启用单向延迟变化, 类型为：bool, 取值范围：True或False, 默认值：False

        UniVarDelay (int): 单向延迟变化, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniResidual (bool): 启用单向剩余带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        UniResBandwidth (int): 单向剩余带宽, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniAva (bool): 启用单向可用带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        UniAvaBandwidth (int): 单向可用带宽, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniUtilized (bool): 启用单向已用带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        UniUtilized (int): 单向已用带宽, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableMaximum (bool): 启用最大带宽(字节/秒), 类型为：bool, 取值范围：True或False, 默认值：False

        Maximum (int): 最大带宽(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableReservable (bool): 启用预留带宽(字节/秒), 类型为：bool, 取值范围：True或False, 默认值：False

        Reservable (int): 预留带宽(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUnreserved (bool): 启用未预留带宽优先级(字节/秒), 类型为：bool, 取值范围：True或False, 默认值：False

        UnreservedBandwidth0 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth1 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth2 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth3 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth4 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth5 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth6 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth7 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableTeDefaultMetric (bool): 启用TE默认度量, 类型为：bool, 取值范围：True或False, 默认值：False

        TeDefaultValue (int): TE默认度量, 类型为：number, 取值范围：1-4294967295, 默认值：0

    Returns:

        Wizard (:obj:`BgpLsTeLinkConfig`): BGP link state te link

    Examples:
        .. code:: RobotFramework

            | Create Bgp Route Wizard Igp Te Option | Wizards=@{Wizards} |
    """

    result = renix.config_bgp_route_wizard_igp_te_option(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def expand_bgp_route_wizard(Wizards):
    """
    生成BGP route向导配置

    Args:

        Wizards (list): BGP route wizard对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Expand Bgp Route Wizard | Wizards=@{Wizards} |
    """

    result = renix.expand_bgp_route_wizard(Wizards=Wizards)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_ospfv3_lsa_wizard(Sessions, **kwargs):
    """
    测试仪表创建Ospfv3 Lsa向导

    Args:

        Sessions (list): 所属的Ospfv3协议会话对象

    Returns:

        Wizard (:obj:`Ospfv3LsaWizardConfig`): Ospfv3 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Create Ospfv3 Lsa Wizard | Sessions=@{sessions} |
    """

    result = renix.create_ospfv3_lsa_wizard(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv3_lsa_wizard_ospfv3_topo(Wizards, Type, **kwargs):
    """
    Ospfv3 Lsa向导配置Ospfv3拓扑

    Args:

        Wizards (list): Ospfv3 Lsa wizard

        Type (str): 拓扑类型，默认值：TREE，取值范围：

            NONE

            TREE

            GRID

            FULLMESH

            RING

            HUBSPOKE

    Keyword Args:

        树型拓扑参数：

            SimulatedRoutersCount (int): Simulated Router的数量，默认值：50，取值范围：1-10000

            InterfaceType (str): 接口类型，默认值：P2P，取值范围：

                BROADCAST

                P2P

            RouterMaxInterfaceCount (int): 每个路由器的最大接口数量，默认值：4，取值范围：1-100

            TransitNetworkMaxRouterCount (int): 每个传输网络的最大路由器数量，默认值：5，取值范围：2-10000

        网络拓扑参数：

            UneditableSimulatedRoutersCount (int): Simulated Router的数量，默认值：16，取值范围：0-10000

            EmulatedRouterPossessSimulatedRouterCount (int): 每个Emulated Router上的Simulated Routers数量，默认值：16，取值范围：0-10000

            RowCount (int): 行数，默认值：4，取值范围：1-10000

            ColumnCount (int): 列数，默认值：4，取值范围：1-10000

            GridEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTOGRID，取值范围：

                ATTACHEDTOGRID

                MEMBEROFGRID

            EmulatedRouterAttachRowIndex (int): Emulated Router所属行，默认值：1，取值范围：1-10000

            EmulatedRouterAttachColumnIndex (int): Emulated Router所属列，默认值：1，取值范围：1-10000

        全连接拓扑参数：

            MeshRouterCount (int): 全网状网络中所有路由器数量，默认值：10，取值范围：1-100

            MeshEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTOMESH，取值范围：

                ATTACHEDTOMESH

                MEMBEROFMESH

        环型拓扑参数：

            RingRouterCount (int): 环型网络中所有路由器数量，默认值：10，取值范围：1-10000

            RingEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTORING，取值范围：

                ATTACHEDTORING

                MEMBEROFRING

        星型拓扑参数：

            HubSpokeRouterCount (int): 星型网络中所有路由器数量，默认值：10，取值范围：1-100

            HubSpokeEmulatedRouterPosition (str): Emulated Router的位置，默认值：ATTACHEDTOHUB，取值范围：

                ATTACHEDTOHUB

                ATTACHEDTOSPOKE

                MEMBERASHUB

                MEMBERASSPOKE

    Returns:

        Wizard (:obj:`Ospfv3LsaWizardConfig`): Ospfv3 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv3 Lsa Wizard Ospfv3 Topo | Wizards=@{wizard} | Type=TREE |
    """

    result = renix.config_ospfv3_lsa_wizard_ospfv3_topo(Wizards=Wizards, Type=Type, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv3_lsa_wizard_ospfv3(Wizards, **kwargs):
    """
    Ospfv3 Lsa向导配置Ospfv3

    Args:

        Wizards (list): Ospfv3 Lsa wizard

    Keyword Args:

        StartingPrefixRange (str): 起始前缀，默认值：2000::1，取值范围：有效的ipv6地址

        EndingPrefixRange (str): 结束前缀，默认值：3ffe::1，取值范围：有效的ipv6地址

        AreaType (str): 区域类型，默认值：REGULAR，取值范围：

            REGULAR

            STUB

            STUBNOSUMMARY

            NSSA

            NSSANOSUMMARY

        StartingRouterId (str): 起始路由器ID，默认值：1.0.0.1，取值范围：有效的ipv4地址

        RouterIdStep (str): 路由器ID步长，默认值：0.0.0.1，取值范围：有效的ipv4地址

    Returns:

        Wizard (:obj:`Ospfv3LsaWizardConfig`): Ospfv3 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv3 Lsa Wizard Ospfv3 | Wizards=@{wizard} |
    """

    result = renix.config_ospfv3_lsa_wizard_ospfv3(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def config_ospfv3_lsa_wizard_ospfv3_intra_area_route(Wizards, **kwargs):
    """
    ospfv3 Lsa向导配置Ospfv3 intra area路由

    Args:

        Wizards (list): Ospfv3 Lsa wizard

    Keyword Args:

        IntraAreaEmulated (str): Emulated Routers, 默认值：NONE，取值范围：

            NONE

            ALL

            EDGE

        IntraAreaSimulated (str): Simulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        IntraAreaRoutesCount (int): 要创建的路由的数量，默认值：0

        IntraAreaOverride (bool): 使能覆盖，默认值：False

        IntraAreaStartingIpPrefix (str): 起始前缀，默认值：2000::，取值范围：有效的ipv6地址

        IntraAreaEndingIpPrefix (str): 结束前缀，默认值：3ffe::1，取值范围：有效的ipv6地址

        IntraAreaDistributionType (str): 前缀分布类型，默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        IntraAreaStartPrefixLength (int): 起始前缀长度，默认值：64，取值范围：1-128

        IntraAreaEndPrefixLength (int): 结束前缀长度，默认值：64，取值范围：1-128

        IntraAreaInternetPrefixLength (list): internet类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        IntraAreaCustomPrefixLength (list): custom类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        IntraAreaPrimaryMetric (int): 度量值，默认值：1，取值范围：1-65535

    Returns:

        Wizard (:obj:`Ospfv3LsaWizardConfig`): Ospfv3 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv3 Lsa Wizard Ospfv3 Intra Area Route | Wizards=@{wizard} |
    """

    result = renix.config_ospfv3_lsa_wizard_ospfv3_intra_area_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_ospfv3_lsa_wizard_ospfv3_inter_area_route(Wizards, **kwargs):
    """
    Ospfv3 Lsa向导配置Ospfv3 inter area路由

    Args:

        Wizards (list): Ospfv3 Lsa wizard

    Keyword Args:

        InterAreaEmulated (str): Emulated Routers, 默认值：NONE，取值范围：

            NONE

            ALL

            EDGE

        InterAreaSimulated (str): Simulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        InterAreaRoutesCount (int): 要创建的路由的数量，默认值：0

        InterAreaOverride (bool): 使能覆盖，默认值：False

        InterAreaStartingIpPrefix (str): 起始前缀，默认值：2000::，取值范围：有效的ipv6地址

        InterAreaEndingIpPrefix (str): 结束前缀，默认值：3ffe::1，取值范围：有效的ipv6地址

        InterAreaDistributionType (str): 前缀分布类型，默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        InterAreaStartPrefixLength (int): 起始前缀长度，默认值：64，取值范围：1-128

        InterAreaEndPrefixLength (int): 结束前缀长度，默认值：64，取值范围：1-128

        InterAreaInternetPrefixLength (list): internet类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        InterAreaCustomPrefixLength (list): custom类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        InterAreaPrimaryMetric (int): 度量值，默认值：100，取值范围：1-65535

    Returns:

        Wizard (:obj:`Ospfv3LsaWizardConfig`): Ospfv3 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv3 Lsa Wizard Ospfv3 Inter Area Route | Wizards=@{wizard} |
    """

    result = renix.config_ospfv3_lsa_wizard_ospfv3_inter_area_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def config_ospfv3_lsa_wizard_ospfv3_external_route(Wizards, **kwargs):
    """
    Ospfv3 Lsa向导配置Ospfv3 External路由

    Args:

        Wizards (list): Ospfv3 Lsa wizard

    Keyword Args:

        ExternalEmulated (str): Emulated Routers, 默认值：NONE，取值范围：

            NONE

            ALL

            EDGE

        ExternalSimulated (str): Simulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        ExternalRoutesCount (int): 要创建的路由的数量，默认值：0

        ExternalOverride (bool): 使能覆盖，默认值：False

        ExternalStartingIpPrefix (str): 起始前缀，默认值：2000::，取值范围：有效的ipv6地址

        ExternalEndingIpPrefix (str): 结束前缀，默认值：3ffe::1，取值范围：有效的ipv6地址

        ExternalDistributionType (str): 前缀分布类型，默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        ExternalStartPrefixLength (int): 起始前缀长度，默认值：64，取值范围：1-128

        ExternalEndPrefixLength (int): 结束前缀长度，默认值：64，取值范围：1-128

        ExternalInternetPrefixLength (list): internet类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        ExternalCustomPrefixLength (list): custom类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        ExternalPrimaryMetric (int): 度量值，默认值：1000，取值范围：1-65535

    Returns:

        Wizard (:obj:`Ospfv3LsaWizardConfig`): Ospfv3 Lsa wizard

    Examples:
        .. code:: RobotFramework

            | Config Ospfv3 Lsa Wizard Ospfv3 External Route | Wizards=@{wizard} |
    """

    result = renix.config_ospfv3_lsa_wizard_ospfv3_external_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def expand_ospfv3_lsa_wizard(Wizards):
    """
    生成Ospfv3 Lsa向导配置

    Args:

        Wizards (list): Ospfv3 Lsa wizard对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Expand Ospfv3 Lsa Wizard | Wizards=@{Wizards} |
    """

    result = renix.expand_ospfv3_lsa_wizard(Wizards=Wizards)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------MPLS-------------------------------------
def create_mpls_wizard(Type, **kwargs):
    """
    测试仪表创建MPLS向导

    Args:

        Type (str): mpls向导类型, 支持:

            mpls_ip_vpn

            mpls_6vpe

            bgp_vpls

            ldp_vpls

            pwe

    Keyword Args:

        enable_vpls_scalability (boot): 使能VPLS可扩展性，默认值：False

    Returns:

        Wizard (:obj:`WizardConfig`): wizard config

    Examples:
        .. code:: RobotFramework

            | Create Mpls Wizard | Type=mpls_ip_vpn |
    """

    result = renix.create_mpls_wizard(Type=Type, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def expand_mpls_wizard(Wizard):
    """
    生成测试仪表MPLS向导配置

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Returns:

        bool：布尔值 (范围：True / False)

    Examples:
        ::

        | Expand Mpls Wizard | Wizard=${Wizard} |
    """

    result = renix.expand_mpls_wizard(Wizard=Wizard)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_provider_port(Wizard, Port, **kwargs):
    """
    配置MPLS向导提供商侧端口

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

        Port (list(`(:obj:`Port`))): 测试仪表端口对象列表

    Keyword Args:

        PortIndex (int): 默认值: 0,

        EnableSubInterface (bool): 使能子接口，默认值: False,

        SubInterfaceCount (int): 子接口个数，默认值: 1,

        DutIpv4Address (str): DUT IPV4地址，默认值: '192.85.1.1',

        DutIpv4AddressStep (str): DUT IPV4地址步长，默认值: '0.0.1.0',

        Ipv4PrefixLength (int): 前缀长度，默认值: 24,

        VlanId (int): VLAN ID，默认值: 1,

        VlanIdStep (int): VLAN ID步长，默认值: 1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Provider Port | Wizard=${Wizard} | Port=${Port} | EnableSubInterface=True |
    """

    result = renix.edit_mpls_provider_port(Wizard=Wizard, Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_customer_port(Wizard, Port, **kwargs):
    """
    配置MPLS向导客户侧端口

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

        Port (list(`(:obj:`Port`))): 测试仪表端口对象列表

    Keyword Args:

        PortIndex (int): 默认值: 0,

        EnableSubInterface (bool): 使能子接口，默认值: False,

        SubInterfaceCount (int): 子接口个数，默认值: 1,

        DutIpv4Address (str): DUT IPV4地址，默认值: '192.85.1.1',

        DutIpv4AddressStep (str): DUT IPV4地址步长，默认值: '0.0.1.0',

        Ipv4PrefixLength (int): 前缀长度，默认值: 24,

        DutIpv6Address (str): DUT IPv6地址，默认值: '::',

        DutIpv6AddressStep (str):  DUT IPv6地址步长，默认值: '0:0:0:1::',

        Ipv6PrefixLength (int): IPV6地址前缀，默认值: 64,

        VlanId (int): VLAN ID，默认值: 1,

        VlanIdStep (int): VLAN ID步长，默认值: 1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Customer Port | Wizard=${Wizard} | Port=${Port} | EnableSubInterface=True |
    """

    result = renix.edit_mpls_customer_port(Wizard=Wizard, Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_provider_router_basic_parameters(Wizard, **kwargs):
    """
    配置MPLS提供商侧路由

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        DutRouterId (str): DUT路由ID，默认值：'10.0.0.1'，取值范围：有效的ipv4地址

        DutAsNumber (int): DUT自治域，默认值：1

        Enable4ByteDutAs (bool): 使能4字节DUT自治域，默认值：False

        FourByteDutAsNumber (int): DUT自治域，默认值：'1:1',

        IgpProtocol (str): IGP协议，默认值：OSPF，取值范围：

            OSPF

            ISIS

            RIP

        MplsProtocol (str): MPLS协议，默认值：LDP，取值范围：

            LDP

            OSPF_SR

            ISIS_SR

        EnablePRouter (bool): 使能P路由器，默认值：True

        PRoutersPerInterface (int): 每个端口/子接口中P路由器个数，默认值：1

        TopologyType (str): 拓扑类型，默认值：Tree，取值范围：

            Tree

            Grid

        PRouterStartIp (str): P接口地址起始IP，默认值：'1.0.0.1'，取值范围：有效的ipv4地址

        PRouterPrefixLength (int): P接口地址前缀长度，默认值：24,

        PRouterIdStart (str): P路由ID起始地址，默认值：'192.0.1.1',

        PRouterIdStep (str): P路由ID起始地址步长，默认值：'0.0.1.0',

        PeRoutersPerInterface (int): PE路由器每个端口/子接口中PE个数，默认值：1,

        PeRouterIdStart (str): PE路由器ID起始地址，默认值：'10.0.0.2',

        PeRouterIdStep (str): PE路由器ID步长，默认值：'0.0.0.1',

        EnableRouteReflectors (bool): 使能路由器反射，默认值： False

        Enable6Vpe (bool): 使能6VPE，默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Provider Router Basic Parameters | Wizard=${Wizard} | Port=${Port} | EnableSubInterface=True |
    """

    result = renix.edit_mpls_provider_router_basic_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_provider_router_ldp(Wizard, **kwargs):
    """
    配置MPLS提供商侧路由路由器LDP协议

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        HelloType (str): Hello类型，默认值：DIRECT，取值范围:

            DIRECT

            TARGETED

            DIRECT_TARGETED

        TransportAddressTlvMode (str): Transport address TLV模式，默认值：TESTER_IP，取值范围：

            TESTER_IP

            ROUTER_ID

            NONE

        LabelAdvertisementMode (str): 标签分配方式，默认值：DU，取值范围:

            DU

            DOD

        EgressLabelMode (str): 出标签方式，默认值：NEXT_AVAILABLE，取值范围:

            NEXT_AVAILABLE

            IMPLICIT

            EXPLICIT

        MinLabel (int): 最小标签值，默认值：16

        AuthenticationMode (str): 鉴权类型，默认值：None，取值范围:

            NONE

            MD5

        Password (str): 密码，默认值：xinertel

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Provider Router Ldp | Wizard=${Wizard} | HelloType=DIRECT |
    """

    result = renix.edit_mpls_provider_router_ldp(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_provider_router_ospf(Wizard, **kwargs):
    """
    配置MPLS提供商侧路由路由器OSPF协议

    Args:
        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        AreaId (str): 区域ID，默认值：0.0.0.0，取值范围：有效的ip地址

        NetworkType (str): 网络类型，默认值：BROADCAST，取值范围：

            BROADCAST

            P2P

        RouterPriority (int): 路由器优先级，默认值：0

        AuthenticationType (str): 认证类型，默认值：NONE，取值范围：

            NONE

            SIMPLE

            MD5

        Password (str): 密码，默认值：Xinertel

        Md5Key (int): MD5 key，默认值：1

        Options (list): 选项，默认值：EBIT，取值范围:

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        EnableGracefulRestart (bool): 使能平滑重启，默认值：False

        GracefulRestartReason (str): 平滑重启原因，默认值：UNKNOWN，取值范围:

            UNKNOWN

            SOFTWARE

            RELOADORUPGRADE

            SWITCH

        EnableBfd (bool): 使能BFD，默认值：False

        Algorithm (int): SR算法，默认值：0

        SidLabelBase (int): SR SID/Label基数，默认值：100

        SidLabelRange (int): SR SID/Label范围，默认值：100

        NodeSidIndex (int): SR node SID索引，默认值：0

        NodeSidIdnexStep (int): SR node SID索引步长，默认值：1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Provider Router Ospf | Wizard=${Wizard} | HelloType=DIRECT |
    """

    result = renix.edit_mpls_provider_router_ospf(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_provider_router_isis(Wizard, **kwargs):
    """
    配置MPLS提供商侧路由路由器ISIS协议

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        UseSrcMacAsSystemId (bool): 使用源MAC地址作为系统标识，默认值：True

        SystemId (str): 系统标识，默认值：00:00:00:00:00:01

        SystemIdStep (str): System ID步长，默认值：00:00:00:00:00:01

        Level (str): 区域类型，默认值：L2，取值范围:

            L1

            L2

            L1L2

        NetworkType (str): 网络类型，默认值：BROADCAST，取值范围：

            BROADCAST

            P2P

        RouterPriority (int): 路由器优先级，默认值：0

        MetricMode (str): 度量模式，默认值：NARROWWIDE，取值范围：

            NARROW

            WIDE

            NARROWWIDE

        AuthenticationMode (str): 校验模式，默认值：None，取值范围：

            NONE

            SIMPLE

            MD5
        Password (str): 密码，默认值：Xinertel

        AreaId (int): 区域，默认值：10

        EnableGracefulRestart (bool): 使能平滑重启，默认值：False

        MultiTopologyId (list): 多拓扑ID，默认值：None，取值范围：

            NOSHOW

            IPV4

            IPV6

        EnableBfd (bool): 使能BFD，默认值：False

        HelloPadding (bool): Hello报文补充，默认值：True

        Algorithm (int): SR算法，默认值：0

        SidLabelBase (int): SR SID/Label基数，默认值：100

        SidLabelRange (int): SR SID/Label范围，默认值：100

        NodeSidIndex (int): SR node SID索引，默认值：0

        NodeSidIdnexStep (int): SR node SID索引步长，默认值：1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Provider Router Isis | Wizard=${Wizard} | Level=L2 |
    """

    result = renix.edit_mpls_provider_router_isis(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_provider_router_rip(Wizard, **kwargs):
    """
    配置MPLS提供商侧路由路由器Rip协议

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        RipVersion (str): RIP版本，默认值：RIPV2，取值范围:

            RIPV1

            RIPV2

            RIPNG

        UpdateType (str): 更新类型，默认值：MULTICAST，取值范围:

            BROADCAST

            MULTICAST

            UNICAST

        UpdateInterval (int): 更新间隔(秒)，默认值：30

        UpdateJitter (int): Update抖动，默认值：0，取值范围：0-5

        MaxRouteNumPerUpdate (int): 每次更新最大路由数，默认值：25

        AuthenticationMode (str): 认证方式，默认值：None，取值范围:

            NONE

            SIMPLE

            MD5

        Password (str): 密码，默认值：Xinertel

        Md5KeyId (int): MD5密钥标识，默认值：1

        SplitHorizon (bool): 使能水平分割，默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Provider Router Rip | Wizard=${Wizard} | RipVersion=RIPNG |
    """

    result = renix.edit_mpls_provider_router_rip(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_provider_route_reflector(Wizard, **kwargs):
    """
    配置MPLS提供商侧路由路由器路由反射器

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        RouteReflectorSource (str): DUT作为路由反射器，默认值：RenixAsRouteReflector，取值范围：

            RenixAsRouteReflector

            DutAsRouteReflector

        TotalBgpSessions (int): 全部BGP会话，默认值：1

        RrRouterIds (list): RR路由器标识，默认值：[]

        RrsPerPortOrSubInterface (int): 每个端口/子接口中RR个数，默认值：1

        RrsPerPe (int): 每个PE中RR个数，默认值：1

        RrRouterIdStart (str): RR路由器标识起始值，默认值：7.7.7.7

        RrRouterIdStep (str): RR路由器标识步长，默认值：0.0.0.1

        ClusterIdStart (str): 簇ID起始值，默认值：0.0.0.0

        ClusterIdStep (str): 簇ID步长，默认值：0.0.0.1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Provider Router Reflectior | Wizard=${Wizard} |
    """

    result = renix.edit_mpls_provider_route_reflector(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_traffic_parameters(Wizard, **kwargs):
    """
    配置MPLS流量

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        TrafficFlow (str): 流量类型，默认值：FullyMeshedInVpn，取值范围:

            None

            FullyMeshedInVpn

            FullyMeshedInVpls

            Customer2Provider

            Provider2Customer

            CustomerProviderBoth

        StreamBlockGrouping (str): 流分组，默认值：Aggregate，取值范围:

            Aggregate

            VPNAggregate

            NotAggregate

        UseSingleStreamNumber (bool): 每对端口使用单一流号，默认值：False

        TrafficLoadPercentProvider (int): 从提供商侧端口加载（%），默认值：10

        TrafficLoadPercentCustomer (int): 从客户侧端口加载（%），默认值：10

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Traffic Parameters | Wizard=${Wizard} | TrafficFlow=FullyMeshedInVpls |
    """

    result = renix.edit_traffic_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_lsp_ping(Wizard, **kwargs):
    """
    配置MPLS流量LSP Ping参数

    Args:
        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        EnableLspPing (bool): 使能Lsp Ping，默认值：False

        DestinationIpv4Address (str): 目的地址，默认值：'127.0.0.1',

        PingInterval (int): 发送测试包的时间间隔，默认值：4,

        PingTimeout (int): 探测的超时时间，默认值：2,

        TimeToLive (int): 生存时间，默认值：255,

        LspExpValue (int): Lsp Exp值，默认值：0,

        ValidateFecStack (bool): 校验FEC Stack，默认值：False,

        PadMode (str): 填充模式，默认值：TransmitWithoutPadTlv，取值范围:

            TransmitWithoutPadTlv

            RequestPeerToDropPadTlv

            RequestPeerToCopyPadTlv

        PadData (list): 填充数据，默认值：[],

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Lsp Ping | Wizard=${Wizard} | EnableLspPing=True |
    """

    result = renix.edit_lsp_ping(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------MPLS VPN----------------------------------
def edit_mpls_vpn_parameters(Wizard, **kwargs):
    """
    配置MPLS VPN基本参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        NumberOfVpns (int): VPN个数，默认值：1

        RdAssignment (str): RD分配，默认值：UseRT，取值范围：

            UseRT

            Manual

        RouteTargetStart (str): RT起始值，默认值：‘1：0’

        RouteTargetStep (str): RT步长，默认值：‘1：0’

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn Parameters | Wizard=${Wizard} | NumberOfVpns=10 |
    """

    result = renix.edit_mpls_vpn_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_vpn_customer_parameters(Wizard, **kwargs):
    """
    配置MPLS VPN客户侧参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        VpnAssignment (int): VPN分配，默认值：RoundRobin，取值范围：

            RoundRobin

            Sequential

        CeProtocol (str): CE协议，默认值：BGP，取值范围:

            BGP

            RIP

            ISIS

            OSPF

            Static

            Mixed

        CeProAssignment (str): CE protocol assignment，默认值：'BGP=100%'

        CustomerRdStart (str): customer RD start，默认值：'1:0'

        CustomerRdStepPerVpnEnabled (bool): 使能设置每个VPN步长，默认值：True

        CustomerRdStepPerVpn (str): 设置每个VPN步长，默认值：'1:0'

        CustomerRdStepPerCeEnabled (bool): 使能设置每个CE步长，默认值：False

        CustomerRdStepPerCe (str): 设置每个CE步长，默认值：'0:0'

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn Customer Parameters | Wizard=${Wizard} | CeProtocol=RIP |
    """

    result = renix.edit_mpls_vpn_customer_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_vpn_provider_parameters(Wizard, **kwargs):
    """
    配置MPLS VPN提供商侧参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        ProviderDisSel (str): provider distribution selector, 默认值：VPNsPerPE，取值范围:

            VPNsPerPE

            PEsPerVPN

        ProviderDisSelCount (int): provider distribution selector count，默认值：1

        ProviderMeshed (bool): provider meshed，默认值：False

        ProviderRdStart (str): provider RD start，默认值：'1:0'

        ProviderRdStepPerVpnEnabled (bool): provider Rd step PerVpn enabled，默认值：True

        ProviderRdStepPerVpn (str): route target start，默认值：'1:0'

        ProviderRdStepPerCeEnabled (bool): provider Rd step PerCe enabled，默认值：False

        ProviderRdStepPerCe (str): provider Rd step PerCe，默认值：'0:0'

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn Provider Parameters | Wizard=${Wizard} | ProviderMeshed=True |
    """

    result = renix.edit_mpls_vpn_provider_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_vpn_as_number(Wizard, **kwargs):
    """
    配置MPLS VPN自治域

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        CustomerEnable4ByteAsNumber (bool): 客户侧使能4字节自治域，默认值：False

        CustomerCeAsNumberStart (int): 客户侧起始自治域，默认值：1

        CustomerCeAsNumberStepPerVpnEnabled (bool): 客户侧使能每个VPN步长，默认值：True

        CustomerCeAsNumberStepPerVpn (str): 客户侧每个VPN步长，默认：1

        CustomerCeAsNumberStepPerCeEnabled (bool): 客户侧使能每个CE步长，默认值：False

        CustomerCeAsNumberStepPerCe (int): 客户侧每个CE步长，默认值：1

        CustomerCe4ByteAsNumberStart (int): 客户侧CE4字节自治域起始值，默认值：1：1

        CustomerCe4ByteAsNumberStepPerVpnEnabled (bool): 客户侧使能4字节每个VPN步长，默认值：True

        CustomerCe4ByteAsNumberStepPerVpn (str): 客户侧4字节每个VPN步长，默认值：1

        CustomerCe4ByteAsNumberStepPerCeEnabled (bool): 客户侧使能4字节每个CE步长，默认值：False

        CustomerCe4ByteAsNumberStepPerCe (str): 客户侧4字节每个CE步长，默认值：1

        ProviderAppendCeAsToPath (str): 提供商侧使能添加CE自治域到路径，默认值：False

        ProviderEnable4ByteAsNumber (int): 提供商侧使能4字节自治域，默认值：False

        ProviderCeAsNumberStart (int): 提供商侧CE自治域起始值，默认值：1

        ProviderCeAsNumberStepPerVpnEnabled (bool): 提供商侧CE自治域使能每个VPN步长，默认值：False

        ProviderCeAsNumberStepPerVpn (int): 提供商侧CE自治域每个VPN步长，默认值：1

        ProviderCeAsNumberStepPerCeEnabled (bool): 提供商侧CE自治域使能每个CE步长，默认值：False

        ProviderCeAsNumberStepPerCe (int): 提供商侧CE自治域每个CE步长，默认值：1

        ProviderCe4ByteAsNumberStart (int): 提供商侧CE4字节自治域起始值，默认值：‘1：1’

        ProviderCe4ByteAsNumberStepPerVpnEnabled (bool): 提供商侧CE4字节自治域使能每个VPN步长，默认值：False

        ProviderCe4ByteAsNumberStepPerVpn (int): 提供商侧CE4字节自治域每个VPN步长，默认值：1

        ProviderCe4ByteAsNumberStepPerCeEnabled (bool): 提供商侧CE4字节自治域使能每个CE步长，默认值：False

        ProviderCe4ByteAsNumberStepPerCe (int): 提供商侧CE4字节自治域每个CE步长，默认值：1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn As Number | Wizard=${Wizard} | CustomerEnable4ByteAsNumber=True |
    """

    result = renix.edit_mpls_vpn_as_number(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------MPLS IP VPN-------------------------------
def edit_mpls_vpn_ipv4_route_customer_parameters(Wizard, **kwargs):
    """
    配置MPLS VPN路由客户端侧参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        CustomerStartRoute (str): 客户侧开始路由，默认值：10.1.1.0

        CustomerRouteStep (str): 客户侧路由步长，默认值：0.0.1.0

        CustomerPrefixLength (int): 客户侧前缀长度，默认值：24

        CustomerRoutesPerCe: (int) 客户侧每个CE中路由器个数，默认值：1

        CustomerOverlapRoutes (bool): 客户侧使能重叠路由，默认值：False

        CustomerRouteType (str): 客户侧路由器类型，默认值：Internal，取值范围：

            Internal

            External

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn Ipv4 Route Customer Parameters | Wizard=${Wizard} | CustomerStartRoute=1.1.1.1 |
    """

    result = renix.edit_mpls_vpn_ipv4_route_customer_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_vpn_ipv4_route_provider_parameters(Wizard, **kwargs):
    """
    配置MPLS VPN路由提供商端侧参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        ProviderStartRoute (str): 提供商侧开始路由，默认值：110.1.1.0

        ProviderRouteStep (str): 提供商侧路由步长，默认值：0.0.1.0

        ProviderPrefixLength (int): 提供商侧前缀长度，默认值：24

        ProviderRoutesPerCe (int): 每个CE中路由器个数，默认值：1

        ProviderOverlapRoutes (bool): 使能重叠路由，默认值：False

        ProviderLabelType (str): MPLS标签类型，默认值：LabelPerSite，取值范围：

            LabelPerSite

            LabelPerRoute

        ProviderStartLabel (int): MPLS起始标签，默认值：16

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn Ipv4 Route Provider Parameters | Wizard=${Wizard} | ProviderStartRoute=1.1.1.1 |
    """

    result = renix.edit_mpls_vpn_ipv4_route_provider_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------MPLS 6VPE-------------------------------
def edit_mpls_vpn_ipv6_route_customer_parameters(Wizard, **kwargs):
    """
    配置MPLS VPN路由客户端侧IPv6参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        CustomerStartRoute (str): 客户侧开始路由，默认值：‘2000：：’

        CustomerRouteStep (str): 路由步长，默认值：‘0:0:0:1::’

        CustomerPrefixLength (int): 前缀长度，默认值：64

        CustomerRoutesPerCe (int): 每个CE中路由个数，默认值：1

        CustomerOverlapRoutes (bool): 使能重叠路由，默认值：False

        CustomerRouteType (str): 路由类型，默认值：Internal，取值范围：

            Internal

            External

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn Ipv6 Route Customer Parameters | Wizard=${Wizard} | ProviderStartRoute=1.1.1.1 |
    """

    result = renix.edit_mpls_vpn_ipv6_route_customer_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_vpn_ipv6_route_provider_parameters(Wizard, **kwargs):
    """
    配置MPLS VPN路由提供商端侧IPv6参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        ProviderStartRoute (str): 起始路由，默认值：‘2001::’

        ProviderRouteStep (str): 路由步长，默认值：'0:0:0:1::'

        ProviderPrefixLength (int): 前缀长度，默认值：64

        ProviderRoutesPerCe (int): 每个CE中路由个数，默认值：1

        ProviderOverlapRoutes (bool): 使能重叠路由，默认值：False

        ProviderLabelType (str): MPLS标签类型，默认值：LabelPerSite，取值范围：

            LabelPerSite

            LabelPerRoute

        ProviderStartLabel (int): MPLS起始标签，默认值：16

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpn Ipv6 Route Provider Parameters | Wizard=${Wizard} | ProviderStartRoute=1.1.1.1 |
    """

    result = renix.edit_mpls_vpn_ipv6_route_provider_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------MPLS VPLS-------------------------------
def edit_mpls_host(Wizard, **kwargs):
    """
    配置MPLS向导Host参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        HostMacStart (str): Host MAC start，默认值：00:00:01:00:00:01

        HostMacStep (str): Host MAC step，默认值：00:00:00:00:00:01

        EnableOverlapHosts (bool): 使能重叠路由，默认值：True

        EnableHostVlan (bool): 使能host VLAN，默认值：True

        NumberOfCustomerSideVlanHeaders (int): 客户侧VLAN头个数，默认值：1，取值范围：0-2

        NumberOfProviderSideVlanHeaders (int): 提供商侧VLAN头个数，默认值：1，取值范围：0-2

        VlanIdStart (int): VLAN ID start，默认值：100

        VlanIdStepPerVpls (int): 每个VPLS步长，默认值：1

        VlanIdStepPerHost (int): 每个Host步长，默认值：1

        HostAssignmentVpls (int): Host分配，默认值：HostsOrMacsPerCe，取值范围:

            HostsOrMacsPerCe

            HostsOrMacsPerVpls

            TotalHostsOrMacs

        HostsPerCustomerCe (int): Host per customer CE，默认值：1

        HostsPerProviderCe (int): Host per provider CE，默认值：1

        HostsPerVpls (int): Host per VPLS，默认值：100

        CustomerHostPercent (int): Customer host percent，默认值：50

        ProviderHostPercent (int): Providier host percent，默认值：50

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Host | Wizard=${Wizard} | VlanIdStart=10 |
    """

    result = renix.edit_mpls_host(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_fec128(Wizard, **kwargs):
    """
    配置MPLS fec128参数

    Args:
        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        StartVcId (int): VC ID起始值，默认值：1

        StepVcId (int): VC ID步长，默认值：1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Fec128 | Wizard=${Wizard} | StartVcId=10 |
    """

    result = renix.edit_mpls_fec128(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mpls_fec129(Wizard, **kwargs):
    """
    配置MPLS fec129参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        Agi (str): AGI，默认值：100:1

        AgiIncrement (str): AGI递增，默认值：0：1

        Saii (str): SAII，默认值：10.0.0.2

        SaiiIncrement (str): SAII递增，默认值：0.0.0.1

        Taii (str): TAII，默认值：10.0.0.1

        TaiiIncrement (str): TAII递增，默认值：0.0.0.0

        EnableBgpAutoDiscovery (bool): 使能BGP自动发现，默认值：False

        DutAsNumber (int): DUT自治域，默认值：1

        RdAssignment (str): RD分配，默认值：UseRT，取值范围:

            UseRT

            Manual

        AgiAssignment (str): AGI分配，默认值：UseRT，取值范围：

            UseRT

            Manual

        Rt (str): RT，默认值：‘1：0’

        RtIncrement (str): RT递增，默认值：‘0：1’

        Rd (str): RD，默认值：‘1：0’

        RdIncrement (str): RD递增，默认值：‘0：1’

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Fec129 | Wizard=${Wizard} | Saii=1.1.1.1 |
    """

    result = renix.edit_mpls_fec129(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

# -------------------------MPLS BGP VPLS-------------------------------
def edit_bgp_vpls(Wizard, **kwargs):
    """
    配置MPLS BGP VPLS参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        NumberOfVpls (int): VPLS个数，默认值：1,

        RdAssignment (str): RD分配方式，默认值：UseRT, 取值范围：

            UseRT

            Manual

        RouteTargetStart (str): RT开始值， 默认值：'1:0',

        RouteTartStep (str): RT步长，默认值：'1:0',

        Mtu (int): VPLS MTU，默认值：1500,

        VplsAssignment (str): VPLS分配方式，默认值：RoundRobin, 取值范围：

            RoundRobin

            Sequential

        CustomerRdStart (str): 客户侧路由标识开始值，默认值：'1:0',

        CustomerVeIdStart (int): 客户侧VE ID开始值，默认值：0,

        CustomerStepPerVplsEnabled (bool): 客户侧路由标识使能每个VPLS步长，默认值：True,

        CustomerRdStepPerVpls (str): 客户侧路由标识每个VPLS步长，默认值：'1:0',

        CustomerStepPerCeEnabled (bool): 客户侧路由标识使能每个CE步长，默认值：False,

        CustomerRdStepPerCe (str): 客户侧路由标识每个CE步长，默认值：'0:0',

        CustomerVeIdStepPerCe (int): 客户侧VE ID每个CE步长，默认值：1,

        CustomerOverlapEnabled (bool): 客户侧在不同的VPLS上重叠VE ID，默认值：False,

        ProviderDistributionSelector (bool): 提供商侧设置项，默认值：VPLSsPerPE, 取值范围：

            VPLSsPerPE

            PEsPerVPLS

        ProviderDistributionSelectorCount (int): 提供商侧设置项数量，默认值：1,

        ProviderMeshed (bool): 提供商侧使能所有，默认值：True,

        ProviderRdStart (str): 提供商侧路由标识开始值，默认值：'1:0',

        ProviderVeIdStart (int): 提供商侧VE ID开始值，默认值：1,

        ProviderStepPerVplsEnabled (bool): 提供商侧路由标识使能每个VPLS步长，默认值：True,

        ProviderRdStepPerVpls (str): 提供商侧路由标识每个VPLS步长，默认值：'1:0',

        ProviderStepPerCeEnabled (bool): 提供商侧路由标识使能每个CE步长，默认值：False,

        ProviderRdStepPerCe (str): 提供商侧路由标识每个CE步长，默认值：'1:0',

        ProviderVeIdStepPerCe (int): 提供商侧VE ID每个CE步长，默认值：1,

        ProviderOverlapEnabled (bool): 提供商侧在不同的VPLS上重叠CE ID，默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpls Basic Parameters | Wizard=${Wizard} | Mtu=1518 |
    """

    result = renix.edit_bgp_vpls(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------MPLS LDP VPLS-------------------------------
def edit_mpls_vpls_basic_parameters(Wizard, **kwargs):
    """
    配置MPLS VPLS参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        NumberOfVpls (int): VPLS个数，默认值：1

        Mtu (int): MTU，默认值：1500

        GroupId (int): Group ID，默认值：0

        EnableCBit (bool): Enable C-Bit，默认值：False

        IncludeStatusTlv (bool): 包含TLV状态，默认值：False

        StatusCode (list): 状态码，默认值：PseudowireNotForwarding，取值范围:

            PseudowireNotForwarding

            LocalAttachmentCircuitReceiveFault

            LocalAttachmentCircuitTransmitFault

            LocalPsnFacingPwIngressReceiveFault

            LocalPsnFacingPwEgressTransmitFault

        EnableOverrideEncapsulation (bool): 使能覆盖封装，默认值：False

        Encapsulation (str): 封装类型，默认值：EthernetVlan，取值范围：

            EthernetVlan

            Ethernet

            EthernetVpls

        VplsAssignment (str): Vpls分配，默认值：RoundRobin，取值范围:

            RoundRobin

            Sequential

        ProviderDistributionSelector (str): 提供商侧配置选项，默认值：VPLSsPerPE，取值范围：

            VPLSsPerPE

            PEsPerVPLS

        ProviderDistributionSelectorCount (int): 提供商侧配置选项数量，默认值：1

        ProviderEnableAll (bool): 供应商侧使能所有，默认值：True

        EnableCreateProviderHostsForUnusedVpls (bool): 使能为未使用的VPLS创建提供商侧Host，默认值：False

        FecType (str): FEC类型，默认值：FEC128，取值范围:

            FEC128

            FEC129

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Vpls Basic Parameters | Wizard=${Wizard} | Mtu=1518 |
    """

    result = renix.edit_mpls_vpls_basic_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------MPLS PWE-------------------------------
def edit_mpls_pwe_basic_parameters(Wizard, **kwargs):
    """
    配置MPLS pwe参数

    Args:

        Wizard (:obj:`WizardConfig`): wizard config

    Keyword Args:

        NumberOfPseudoWire (int): 伪线个数，默认值：1

        Mtu (int): MTU，默认值：1500

        GroupId (int): Group ID， 默认值：0

        EnableCBit (bool): Enable C-Bit，默认值：False

        IncludeStatusTlv (bool): Include status TLV，默认值：False

        StatusCode (list): Status code，默认值：PseudowireNotForwarding，取值范围:

            PseudowireNotForwarding

            LocalAttachmentCircuitReceiveFault

            LocalAttachmentCircuitTransmitFault

            LocalPsnFacingPwIngressReceiveFault

            LocalPsnFacingPwEgressTransmitFault

        EnableOverrideEncapsulation (bool): Enable override encapsulation，默认值：False

        Encapsulation (str): 封装类型，默认值：EthernetVlan，取值范围：

            EthernetVlan

            Ethernet

            EthernetVpls

        EnableOverlapVcidsOnDifferentPes (bool): 再不同的PE上重叠VC ID，默认值：False

        EnableCreateProviderHostsForUnusedVpls (bool): 为未使用的VPLS创建提供商侧Host，默认值：False

        FecType (str): FEC type，默认值：FEC128，取值范围:

            FEC128

            FEC129

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mpls Pwe Basic Parameters | Wizard=${Wizard} | Mtu=1518 |
    """

    result = renix.edit_mpls_pwe_basic_parameters(Wizard=Wizard, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

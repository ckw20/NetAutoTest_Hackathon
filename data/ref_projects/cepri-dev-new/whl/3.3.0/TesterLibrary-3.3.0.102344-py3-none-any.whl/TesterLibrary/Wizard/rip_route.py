import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_rip_route_wizard(Sessions, **kwargs):
    """
    测试仪表创建Rip Route向导

    Args:

        Sessions (list): 所属的Rip协议会话对象

    Returns:

        Wizard (:obj:`RipRouteWizardConfig`): Rip Route wizard

    Examples:
        .. code:: RobotFramework

            | Create Rip Route Wizard | Sessions=@{sessions} |
    """

    result = renix.create_rip_route_wizard(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_rip_route_wizard_ipv4(Wizards, **kwargs):
    """
    Rip Route向导配置Ipv4路由

    Args:

        Wizards (list): Rip Route wizard

    Keyword Args:

        Ipv4TotalNumberOfRoutes (int):  创建路由总个数, 默认值：20，取值范围：0-10000000

        Ipv4StartRoutesPrefix (str): 起始路由前缀, 默认值：2.0.0.0，取值范围：有效的ipv4地址

        Ipv4EndRoutesPrefix (str): 结束路由前缀, 默认值：255.255.255.255，取值范围：有效的ipv4地址

        Ipv4RoutesNoneSeq (bool): 防止路由聚合, 默认值：False，取值范围：True | False

        Ipv4RoutesPrefixLenType (str):  路由前缀分布类型, 默认值：FIXED，取值范围：

            FIXED

            LINEAR

        Ipv4RoutesPrefixLenStart (int): 起始路由前缀长度, 默认值：16，取值范围：1-32

        Ipv4RoutesPrefixLenEnd (int): 结束路由前缀长度, 默认值：16，取值范围：1-32

        Ipv4Metric (int): 路由度量, 默认值：1，取值范围：1-16

    Returns:

        Wizard (:obj:`RipRouteWizardConfig`): Rip Route wizard

    Examples:
        .. code:: RobotFramework

            | Config Rip Route Wizard Ipv4 | Wizards=@{wizard} |
    """

    result = renix.config_rip_route_wizard_ipv4(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_rip_route_wizard_ipv6(Wizards, **kwargs):
    """
    Rip Route向导配置Ipv6路由

    Args:

        Wizards (list): Rip Route wizard

    Keyword Args:

        Ipv6TotalNumberOfRoutes (int): 创建路由总个数, 默认值：20，取值范围：0-10000000

        Ipv6StartRoutesPrefix (str): 起始路由前缀, 默认值："3000::"，取值范围：有效的ipv6地址

        Ipv6EndRoutesPrefix (str): 起始路由前缀, 默认值："3ffe::"，取值范围：有效的ipv6地址

        Ipv6RoutesNoneSeq (bool): 防止路由聚合, 默认值：False，取值范围：True | False

        Ipv6RoutesPrefixLenType (str): 路由前缀分布类型, 默认值：FIXED，取值范围：

            FIXED

            LINEAR

        Ipv6RoutesPrefixLenStart (int): 起始路由前缀长度, 默认值：64，取值范围：1-128

        Ipv6RoutesPrefixLenEnd (int): 结束路由前缀长度, 默认值：64，取值范围：1-128

        Ipv6Metric (int): 路由度量, 默认值：1，取值范围：1-16


    Returns:

        Wizard (:obj:`RipRouteWizardConfig`): Rip Route wizard

    Examples:
        .. code:: RobotFramework

            | Config Rip Route Wizard Ipv6 | Wizards=@{wizard} |
    """

    result = renix.config_rip_route_wizard_ipv6(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def expand_rip_route_wizard(Wizards):
    """
    生成Rip Route向导配置

    Args:

        Wizards (list): Rip Route wizard对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Expand Rip Route Wizard | Wizards=@{Wizards} |
    """

    result = renix.expand_rip_route_wizard(Wizards=Wizards)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

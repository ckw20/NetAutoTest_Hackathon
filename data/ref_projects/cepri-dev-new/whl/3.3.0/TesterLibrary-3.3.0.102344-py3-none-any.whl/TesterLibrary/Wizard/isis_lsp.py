import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_isis_lsp_wizard(Sessions, **kwargs):
    """
    测试仪表创建Isis Lsp向导对象

    Args:

        Sessions (list): 所属的Isis协议会话对象

    Keyword Args:

        CreateLspLevel (str): 创建LSP级别，默认值：CREATE_L2_LSP，取值范围：

            CREATE_L1_LSP

            CREATE_L2_LSP

            CREATE_L1_L2_LSP

    Returns:

        Wizard (:obj:`IsisLspWizardConfig`): Isis Lsp wizard

    Examples:
        .. code:: RobotFramework

            | Create Isis Lsp Wizard | Sessions=@{sessions} |
    """

    result = renix.create_isis_lsp_wizard(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_network_topo(Wizards, Type, **kwargs):
    """
    Isis Lsp向导配置网络拓扑

    Args:

        Wizards (list): Isis Lsp wizard

        Type (str): 拓扑类型，默认值：TREE，取值范围：

            NONE

            TREE

            GRID

            FULL_MESH

            RING

            HUB_SPOKE

    Keyword Args:

        树型拓扑参数：

            TreeSimulatedRoutersCount (int): Simulated Router的数量，默认值：10，取值范围：1-10000

            TreeInterfaceType (str): 接口类型，默认值：BROADCAST，取值范围：

                BROADCAST

                P2P

            TreeMaxInterfacesPerRouter (int): 每个路由器的最大接口数，默认值：4，取值范围：2-100

            TreeMaxRoutersPerTransitNetwork (int): 传输网格的最大路由器数量，默认值：5，取值范围：2-10000

        网格拓扑参数：

            GridSimulatedRoutersCount (int): Simulated Router的数量，默认值：16，取值范围：0-10000

            GridSimulatedRoutersPerEmulatedRouter (int): 每个Emulated Router中的Simulated Router数量，默认值：16，取值范围：0-10000

            GridNumberOfRows (int): 行数，默认值：4，取值范围：1-10000

            GridNumberOfColumns (int): 列数，默认值：4，取值范围：1-10000

            GridEmulatedRouterPosition (str): Emulated Router位置，默认值：ATTACHED，取值范围：

                ATTACHED

                MEMBER

            GridEmulatedRouterRowIndex (int): Emulated Router所在行，默认值：1，取值范围：1-10000

            GridEmulatedRouterColumnIndex (int): Emulated Router所在列，默认值：1，取值范围：1-10000

        全连接拓扑参数：

            MeshSimulatedRoutersCount (int): Simulated Router的数量，默认值：10，取值范围：

            MeshSimulatedRoutersPerEmulatedRouter (int): 每个Emulated Router中的Simulated Router数量，默认值：10，取值范围：

            MeshNumberOfRouters (int): 全连接中路由器数量，默认值：10，取值范围：1-100

            MeshEmulatedRouterPosition (str): Emulated Router位置，默认值：ATTACHED，取值范围：

                ATTACHED

                MEMBER

        环型拓扑参数：

            RingSimulatedRoutersCount (int): Simulated Router的数量，默认值：10，取值范围：

            RingSimulatedRoutersPerEmulatedRouter (int): 每个Emulated Router中的Simulated Router数量，默认值：10，取值范围：

            RingNumberOfRouters (int): 环网中路由器数量，默认值：10，取值范围：1-10000

            RingEmulatedRouterPosition (int): Emulated Router位置，默认值：ATTACHED，取值范围：

                ATTACHED

                MEMBER

        星型拓扑参数：

            HubSimulatedRoutersCount (int): Simulated Router的数量，默认值：10，取值范围：

            HubSimulatedRoutersPerEmulatedRouter (int): 每个Emulated Router中的Simulated Router数量，默认值：10，取值范围：

            HubNumberOfRouters (int): 星型中路由器数量，默认值：10，取值范围：1-100

            HubEmulatedRouterPosition (str): Emulated Router位置，默认值：ATTACHED_TO_HUB，取值范围：

                ATTACHED_TO_HUB

                ATTACHED_TO_SPOKE

                MEMBERAS_HUB

                MEMBERAS_SPOKE

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Network Topo | Wizards=@{wizard} | Type=TREE |
    """

    result = renix.config_isis_lsp_wizard_network_topo(Wizards=Wizards, Type=Type, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_isis(Wizards, **kwargs):
    """
    Isis Lsp向导配置IS-IS

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        InterfaceStartIpv4Prefix (str): 路由/接口起始ipv4前缀，默认值：1.0.0.0，取值范围：有效的ipv4地址

        InterfaceEndIpv4Prefix (str): 路由/接口结束ipv4前缀，默认值：223.255.255.255，取值范围：有效的ipv4地址

        InterfaceStartIpv6Prefix (str): 路由/接口起始ipv6前缀，默认值：2000::，取值范围：有效的ipv6地址

        InterfaceEndIpv6Prefix (str): 路由/接口结束ipv6前缀，默认值：3ffe::，取值范围：有效的ipv6地址

        AdvertiseLoopbackAddress (bool): 默认值：False

        EnableTrafficEngine (bool): 使能TE配置，默认值：False

        EnableSegmentRouting (bool): 使能SR配置，默认值：False

        EnableSegmentRoutingIPv6 (bool): 使能SRv6配置，默认值：False

        EnableFlexAlgo (bool): 使能Flex Algorithm配置，默认值：False

        StartSystemId (str): 起始系统ID，默认值：10:00:00:00:00:01，取值范围：有效的mac地址

        SystemIdStep (str): 系统ID步长，默认值：00:00:00:00:00:01，取值范围：有效的mac地址

        StartRouterId (str): 起始路由器ID，默认值：1.0.0.1，取值范围：有效的ipv4地址

        RouterIdStep (str):　路由器ID步长，默认值：0.0.0.1，取值范围：有效的ipv4地址

        StartIPv6RouterId (str): IPv6起始路由器ID，默认值：2000::2，取值范围：有效的ipv6地址

        RouterIdIPv6Step (int): IPv6路由器ID步长，默认值：1，取值范围：

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Isis | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_isis(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_isis_te(Wizards, **kwargs):
    """
    Isis Lsp向导配置IS-IS中的TE

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        EnableInterfaceIp (bool): 是否包含本地IPv4地址, 默认值：False

        InterfaceIp (str): 本地IPv4地址, 取值范围：有效的ip地址, 默认值：'0.0.0.0'

        EnableNeighborIp (bool): 是否包含邻居IPv4地址, 默认值：False

        NeighborIp (int): 邻居IPv4地址, 取值范围：有效的ip地址, 默认值：10

        EnableInterfaceIpv6 (bool): 是否包含本地IPv6地址, 默认值：False

        InterfaceIpv6 (str): 本地IPv6地址, 取值范围：有效的ipv6地址, 默认值：'2000::1'

        EnableNeighborIpv6 (bool): 是否包含邻居IPv6地址, 默认值：False

        NeighborIpv6 (str): 邻居IPv6地址, 取值范围：有效的ipv6地址, 默认值：'2000::1'

        EnableTeGroup (bool): 是否包含TE组, 默认值：False

        TeGroup (int): TE组, 取值范围：0-4294967295, 默认值：1

        EnableMaxBandwidth (bool): 是否包含最大带宽值, 默认值：False

        MaximunLink (int): 最大带宽值(字节/秒), 取值范围：0-4294967295, 默认值：1000

        EnableResBandwidth (bool): 是否包含预留带宽值, 默认值：False

        MaximumReservableLink (int): 最大预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：1000

        EnableUnresBandwidth (bool): 是否包含未预留带宽优先级, 默认值：False

        UnreservedBandwidth0 (int): 优先级0的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth1 (int): 优先级1的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth2 (int): 优先级2的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth3 (int): 优先级3的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth4 (int): 优先级4的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth5 (int): 优先级5的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth6 (int): 优先级6的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth7 (int): 优先级7的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`IsisTeWizardConfig`): ISIS Te Wizard对象

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Isis Te | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_isis_te(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_isis_sr(Wizards, **kwargs):
    """
    Isis Lsp向导配置IS-IS中的SR

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        配置能力：SR能力Sub-TLV

            ValueType (str): 值类型, 默认值：BIT20, 取值范围：

                BIT20

                BIT32

            CapabilityFlags (list): Flags, 默认值：['IPv4_CAPABLE'], 取值范围：

                IPv4_CAPABLE

                IPv6_CAPABLE

            SidLabelBase (list): SID/Label Bases，默认值：[800000]，取值范围：

            SidLabelRange (list): SID/Label Ranges，默认值：[80000]，取值范围：

        配置SID：

            EnableMappingServer (bool): 使能Mapping Server，默认值：False

            NodeSidStart (int): SID/Index，默认值：101

            NodeSidStep (int): SID/Index步长，默认值：1

            NodeSidAlgorithm (int): 算法，默认值：0

            NodeSidFlags (list): Flags, 默认值：['NODESID', 'NOPHP'], 取值范围：

                NOSHOW

                ADVERTISEMENT

                NODESID

                NOPHP

                EXPLICIT

                VALUE

                LOCAL

            EnablePrefixSid (bool): 使能前缀，默认值：False

            PrefixSidStart (int): SID/Index，默认值：11000

            PrefixSidStep (int): SID/Index步长，默认值：1

            EnableNeighborSid (bool): 使能邻居，默认值：False

            NeighborSidStart (int): SID/Index，默认值：9001

            NeighborSidStep (int): SID/Index步长，默认值：1

            NeighborSidWeight (int): 权重，默认值：100

            NeighborSidFlags (list): Flags, 默认值：['VALUE', 'LOCAL'], 取值范围：

                NOSHOW

                ADDRESS

                BACKUP

                VALUE

                LOCAL

                SET

                PERSISTENT

        配置Anycast：

            EnableAnycastSid (bool): 使能Anycast，默认值：False

            AnycastRangeSize (int): 范围，默认值：80000

            AnycastBaseSid (int): 基本SID，默认值：800000

            AnycastSidStart (int): SID/Index，默认值：100

            AnycastSidFlags (list): Flags, 默认值：['NODESID', 'NOPHP'], 取值范围：

                NOSHOW

                ADVERTISEMENT

                NODESID

                NOPHP

                EXPLICIT

                VALUE

                LOCAL

            AnycastIpv4Address (str): ipv4地址，默认值：192.0.0.1，取值范围：有效的ipv4地址

            AnycastIpv6Address (str): ipv6地址，默认值：2000::1，取值范围：有效的ipv6地址

    Returns:

        (:obj:`IsisSrWizardConfig`): ISIS Sr Wizard对象

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Isis Sr | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_isis_sr(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_isis_srv6(Wizards, **kwargs):
    """
    Isis Lsp向导配置IS-IS中的SRv6

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        MtId (int): 多拓扑ID，默认值：2

        Metric (int): 度量，默认值：10

        Flags (list): Flags，默认值：UNKNOWN，取值范围：

            UNKNOWN

            D_BIT

            A_BIT

            UNUSED2

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

        Algorithm (int): 算法，默认值：0

        NumLocator (int): Locator数量，默认值：1

        LocatorSize (int): Locator大小，默认值：64

        Locator (str): Locator，默认值：'aaaa:1:1:1::'

        LocatorStep (int): Locator步长，默认值：1

        EndFlags (list): Flags，默认值：UNKNOWN，取值范围：

            UNKNOWN

            UNUSED0

            UNUSED1

            UNUSED2

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

        EndpointFunc (str): 端点行为，默认值：END_NO，取值范围：

            END_NO

            END_PSP

            END_USP

            END_PSP_USP

            END_X_NO

            END_X_PSP

            END_X_USP

            END_X_PSP_USP

            END_T_NO

            END_T_PSP

            END_T_USP

            END_T_PSPS_USP

            END_B6

            END_B6_ENCAPS

            END_BM

            END_DX6

            END_DX4

            EDN_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DX2U

            END_DX2M

            END_S

            END_B6_RED

            END_B6_ENCAPS_RED

            END_WITH_USD

            END_PSP_USD

            END_USP_USD

            END_PSP_USP_USD

            END_X_USD

            END_X_PSP_USD

            END_X_USP_USD

            END_X_PSP_USP_USD

            END_T_USD

            END_T_PSP_USD

            END_T_USP_USD

            END_T_PSP_USP_USD

        EnableCustom (bool): 使能自定义端点行为，默认值：False

        CustomFunc (int): 自定义端点行为，默认值：0

        NumOfSid (int): SID数量，默认值：1

        SID (str): SID，默认值：'::1'

        SIDStep (str): SID步长，默认值：'::1'

    Returns:

        (:obj:`IsisSrv6WizardConfig`): ISIS Srv6 Wizard对象

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Isis Srv6 | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_isis_srv6(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_isis_flex_algo(Wizards, **kwargs):
    """
    Isis Lsp向导配置IS-IS中的Flex Algorithm

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        FlexAlgo (int): Flex Algorithm, 默认值：128，取值范围：128-255

        Count (int): 配置FAD sub-TLV个数，默认值：1

        AlgorithmStep (int): Flex Algorithm Step，默认值：1

        MetricType (str): 度量类型，默认值：IGP_METRIC，取值范围：

            IGP_METRIC

            MIN_LINK_DELAY

            TE_METRIC

        CalType (int): 计算类型，默认值：0

        Priority (int): 优先级，默认值：0

        EnableExcludeAdmin (bool): Exclude Admin Group, 默认值：False

        ExcludeAdmin (list): Exclude Admin Group, 默认值：[0]

        EnableIncludeAnyAdmin (bool): Include-Any Admin Group, 默认值：False

        IncludeAnyAdmin (list): Include-Any Admin Group, 默认值：[0]

        EnableIncludeAllAdmin (bool): Include-All Admin Group, 默认值：False

        IncludeAllAdmin (list): Include-All Admin Group, 默认值：[0]

        EnableDefinitionFlags (bool): Definition Flags, 默认值：False

        DefinitionFlags (list): Definition Flags, 默认值：[80]

        EnableExcludeSRLG (bool): Exclude SRLG, 默认值：False

        ExcludeSRLG (list): Exclude SRLG, 默认值：[0]

    Returns:

        (:obj:`IsisFlexAlgoWizardConfig`): ISIS Flex Algorithm Wizard对象

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Isis Flex Algo | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_isis_flex_algo(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_ipv4_internal_route(Wizards, **kwargs):
    """
    Isis Lsp向导配置Ipv4内部路由

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        Ipv4InternalAdvEmulatedRouters (bool): Emulated Routers, 默认值：False, 取值范围：True：ALL；False：None

        Ipv4InternalAdvSimulatedRouter (str): Simulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        Ipv4InternalTotalNumberOfRoutes (int): 创建的路由数量，默认值：20，取值范围：0-10000000

        Ipv4InternalRoutesOverride (bool): 使能覆盖默认IPv4前缀范围, 默认值：False

        Ipv4InternalStartRoutesPrefix (str): 起始IP前缀，默认值：2.0.0.0，取值范围：有效的ipv4地址

        Ipv4InternalEndRoutesPrefix (str): 结束IP前缀，默认值：255.255.255.255，取值范围：有效的ipv4地址

        Ipv4InternalRoutesNoneSeq (bool): 使能防止路由聚合, 默认值：False

        Ipv4InternalRoutesPrefixLenType (str): 前缀长度分布类型, 默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        Ipv4InternalRoutesPrefixLenStart (int): 起始前缀长度，默认值：16，取值范围：1-32

        Ipv4InternalRoutesPrefixLenEnd (int): 结束前缀长度，默认值：16，取值范围：1-32

        Ipv4InternalRoutesPrefixLenInternet (list): internet类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        Ipv4InternalRoutesPrefixLenCustom (list): custom类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        Ipv4InternalNarrowMetric (int): isis默认度量值，默认值：10，取值范围：0-63

        Ipv4InternalWideMetric (int): isis扩展度量值，默认值：10，取值范围：0-16777214

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Ipv4 Internal Route | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_ipv4_internal_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_ipv4_external_route(Wizards, **kwargs):
    """
    Isis Lsp向导配置Ipv4外部路由

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        Ipv4ExternalAdvEmulatedRouters (bool): Emulated Routers, 默认值：False, 取值范围：True：ALL；False：None

        Ipv4ExternalAdvSimulatedRouter (str): Simulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        Ipv4ExternalTotalNumberOfRoutes (int): 创建的路由数量，默认值：0，取值范围：0-10000000

        Ipv4ExternalRoutesOverride (bool): 使能覆盖默认IPv4前缀范围, 默认值：False

        Ipv4ExternalStartRoutesPrefix (str): 起始IP前缀，默认值：3.0.0.0，取值范围：有效的ipv4地址

        Ipv4ExternalEndRoutesPrefix (str): 结束IP前缀，默认值：255.255.255.255，取值范围：有效的ipv4地址

        Ipv4ExternalRoutesNoneSeq (bool): 使能防止路由聚合, 默认值：False

        Ipv4ExternalRoutesPrefixLenType (str): 前缀长度分布类型, 默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        Ipv4ExternalRoutesPrefixLenStart (int): 起始前缀长度，默认值：16，取值范围：1-32

        Ipv4ExternalRoutesPrefixLenEnd (int): 结束前缀长度，默认值：16，取值范围：1-32

        Ipv4ExternalRoutesPrefixLenInternet (list): internet类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        Ipv4ExternalRoutesPrefixLenCustom (list): custom类型的前缀长度，取值范围：长度为32的列表，总和为100.0

        Ipv4ExternalNarrowMetric (int): isis默认度量值，默认值：10，取值范围：0-63

        Ipv4ExternalWideMetric (int): isis扩展度量值，默认值：10，取值范围：0-16777214

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Ipv4 External Route | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_ipv4_external_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_ipv6_internal_route(Wizards, **kwargs):
    """
    Isis Lsp向导配置Ipv6内部路由

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        Ipv6InternalAdvEmulatedRouters (bool): Emulated Routers, 默认值：False, 取值范围：True：ALL；False：None

        Ipv4InternalAdvSimulatedRouter (str): Simulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        Ipv6InternalTotalNumberOfRoutes (int): 创建的路由数量，默认值：0，取值范围：0-10000000

        Ipv6InternalRoutesOverride (bool): 使能覆盖默认IPv6前缀范围, 默认值：False

        Ipv6InternalStartRoutesPrefix (str): 起始IP前缀，默认值：3000::，取值范围：有效的ipv6地址

        Ipv6InternalEndRoutesPrefix (str): 结束IP前缀，默认值：3ffe::，取值范围：有效的ipv6地址

        Ipv6InternalRoutesNoneSeq (bool): 使能防止路由聚合, 默认值：False

        Ipv6InternalRoutesPrefixLenType (str): 前缀长度分布类型, 默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        Ipv6InternalRoutesPrefixLenStart (int): 起始前缀长度，默认值：64，取值范围：1-128

        Ipv6InternalRoutesPrefixLenEnd (int): 结束前缀长度，默认值：64,取值范围：1-128

        Ipv6InternalRoutesPrefixLenInternet (list): internet类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        Ipv6InternalRoutesPrefixLenCustom (list): custom类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        Ipv6InternalWideMetric (int): isis扩展度量值，默认值：10，取值范围：0-16777214

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Ipv6 Internal Route | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_ipv6_internal_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_isis_lsp_wizard_ipv6_external_route(Wizards, **kwargs):
    """
    Isis Lsp向导配置Ipv6外部路由

    Args:

        Wizards (list): Isis Lsp wizard

    Keyword Args:

        Ipv6ExternalAdvEmulatedRouters (bool): Emulated Routers, 默认值：False, 取值范围：True：ALL；False：None

        Ipv6ExternalAdvSimulatedRouter (str): Simulated Routers, 默认值：ALL，取值范围：

            NONE

            ALL

            EDGE

        Ipv6ExternalTotalNumberOfRoutes (int): 创建的路由数量，默认值：0，取值范围：0-10000000

        Ipv6ExternalRoutesOverride (bool): 使能覆盖默认IPv6前缀范围, 默认值：False

        Ipv6ExternalStartRoutesPrefix (str): 起始IP前缀，默认值：3001::，取值范围：有效的ipv6地址

        Ipv6ExternalEndRoutesPrefix (str): 结束IP前缀，默认值：3ffe::，取值范围：有效的ipv6地址

        Ipv6ExternalRoutesNoneSeq (bool): 使能防止路由聚合, 默认值：False

        Ipv6ExternalRoutesPrefixLenType (str): 前缀长度分布类型, 默认值：FIXED，取值范围：

            FIXED

            LINEAR

            INTERNET

            CUSTOM

        Ipv6ExternalRoutesPrefixLenStart (int): 起始前缀长度，默认值：64，取值范围：1-128

        Ipv6ExternalRoutesPrefixLenEnd (int): 结束前缀长度，默认值：64，取值范围：1-128

        Ipv6ExternalRoutesPrefixLenInternet (list): internet类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        Ipv6ExternalRoutesPrefixLenCustom (list): custom类型的前缀长度，取值范围：长度为128的列表，总和为100.0

        Ipv6ExternalWideMetric (int): isis扩展度量值，默认值：10，取值范围：0-16777214

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Config Isis Lsp Wizard Ipv6 External Route | Wizards=@{wizard} |
    """

    result = renix.config_isis_lsp_wizard_ipv6_external_route(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def expand_isis_lsp_wizard(Wizards):
    """
    生成Isis Lsp向导配置

    Args:

        Wizards (list): Isis Lsp wizard对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Expand Isis Lsp Wizard | Wizards=@{Wizards} |
    """

    result = renix.expand_isis_lsp_wizard(Wizards=Wizards)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result






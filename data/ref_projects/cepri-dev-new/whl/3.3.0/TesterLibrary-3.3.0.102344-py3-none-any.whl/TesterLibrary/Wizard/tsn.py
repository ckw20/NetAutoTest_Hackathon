import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------MPLS-------------------------------------
def create_tsn_wizard(Type, **kwargs):
    """
    测试仪表创建MPLS向导

    Args:

        Type (str): mpls向导类型, 支持:

            avb

            qcr

            frame_pre_emption

            cb

    Keyword Args:

        avb参数:

            TalkerPort (:obj:`Port`): avb参数,

            ListenerPort (:obj:`Port`): avb参数,

            NonAvbPort (:obj:`Port`): avb参数,

            IsAppended (bool): avb参数,

    Returns:

        Wizard (:obj:`WizardConfig`): wizard config

    Examples:
        .. code:: RobotFramework

            | Create Tsn Wizard | Type=avb |
    """

    result = renix.create_tsn_wizard(Type=Type, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_tsn_avb_qav(Wizards, **kwargs):
    """
    测试仪表创建MPLS向导

    Args:

        Wizards (list): TSN Wizard

    Keyword Args:

        FrameSize (int): 帧长，范围：60-16383

        SrClassVid (int): 帧长，范围：1-4093

        EnableClassA (bool): 帧长

        ClassABwRsvPct (int): 帧长，范围：0-100

        ClassAStreamNum (:obj:`Port`): 帧长，范围：0-256

        ClassAStreamsBwRsvPct (list): 帧长，范围：60-16383

        EnableClassB (bool): 帧长

        ClassBBwRsvPct (int): 帧长，范围：0-100

        ClassBStreamNum (int): 帧长，范围：0-256

        ClassBStreamsBwRsvPct (list): 帧长


    Returns:

        Wizard (:obj:`WizardConfig`): wizard config

    Examples:
        .. code:: RobotFramework

            | Config Tsn Avb Qav | FrameSize=128 |
    """

    result = renix.config_tsn_avb_qav(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_tsn_avb_gptp(Wizards, **kwargs):
    """
    测试仪表创建MPLS向导

    Args:

        Wizards (list): TSN Wizard

    Keyword Args:

        Priority1 (int): 帧长，

        Priority2 (int): 帧长

        ClockAccuracy (str): Clock Accuracy类型：
            CLOCK_ACCURACY_0
            CLOCK_ACCURACY_20
            CLOCK_ACCURACY_21
            CLOCK_ACCURACY_22
            CLOCK_ACCURACY_23
            CLOCK_ACCURACY_24
            CLOCK_ACCURACY_25
            CLOCK_ACCURACY_26
            CLOCK_ACCURACY_27
            CLOCK_ACCURACY_28
            CLOCK_ACCURACY_29
            CLOCK_ACCURACY_2A
            CLOCK_ACCURACY_2B
            CLOCK_ACCURACY_2C
            CLOCK_ACCURACY_2D
            CLOCK_ACCURACY_2E
            CLOCK_ACCURACY_2F
            CLOCK_ACCURACY_30
            CLOCK_ACCURACY_31

        LogAnnounceInterval (int): 帧长，范围：-10-10

        LogSyncInterval (int): 帧长，范围：-10-10

        AnnounceReceiptTimeout (int): 帧长，范围：3-255

        PropogationDelay (int): 帧长


    Returns:

        Wizard (:obj:`WizardConfig`): wizard config

    Examples:
        .. code:: RobotFramework

            | Create Tsn Wizard | Type=avb |
    """

    result = renix.config_tsn_avb_gptp(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_tsn_avb_non_stream(Wizards, **kwargs):
    """
    测试仪表创建MPLS向导

    Args:

        Wizards (list): TSN Wizard

    Keyword Args:

        NonAvbFrameSize (int): 帧长，范围：60-16383

        LoadRate (int): 帧长，范围：0-100

        StreamNumber (int): 帧长，范围：0-256

    Returns:

        Wizard (:obj:`WizardConfig`): wizard config

    Examples:
        .. code:: RobotFramework

            | Create Tsn Wizard | Type=avb |
    """

    result = renix.config_tsn_avb_non_stream(Wizards=Wizards, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_tsn_qcr_stream(Wizard, TalkerPort=None,
                          ListenerPortList=None, Priority=None, LoadUnit=None, Load=None, FrameLengthType=None,
                          FixedFrameSize=None, MinFrameSize=None, MaxFrameSize=None, StepFrameSize=None, **kwargs):
    """
    测试仪表创建MPLS向导

    Args:

        Type (str): mpls向导类型, 支持:

            avb

            qcr

            frame_pre_emption

            cb

    Keyword Args:

        avb参数:

            TalkerPort (:obj:`Port`): avb参数,

            ListenerPort (:obj:`Port`): avb参数,

            NonAvbPort (:obj:`Port`): avb参数,

            IsAppended (bool): avb参数,

    Returns:

        Wizard (:obj:`WizardConfig`): wizard config

    Examples:
        .. code:: RobotFramework

            | Create Tsn Wizard | Type=avb |
    """

    result = renix.create_tsn_qcr_stream(Wizard=Wizard, TalkerPort=TalkerPort,
                                         ListenerPortList=ListenerPortList, Priority=Priority, LoadUnit=LoadUnit,
                                         Load=Load, FrameLengthType=FrameLengthType,
                                         FixedFrameSize=FixedFrameSize, MinFrameSize=MinFrameSize,
                                         MaxFrameSize=MaxFrameSize, StepFrameSize=StepFrameSize, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def config_tsn_qcr_stream_identification_function(Configs=None,
                                                  StreamIdentificationFunction=None, SourceMacAddress=None,
                                                  DestinationMacAddress=None, VlanId=None, AddUdpHeader=None,
                                                  SourcePort=None, DestinationPort=None, AddIpHeader=None,
                                                  SourceIpAddress=None, DestinationIpAddress=None, IpDscp=None,
                                                  IpNextProtocol=None, **kwargs):
    """
    测试仪表创建MPLS向导

    Args:

        Type (str): mpls向导类型, 支持:

            avb

            qcr

            frame_pre_emption

            cb

    Keyword Args:

        avb参数:

            TalkerPort (:obj:`Port`): avb参数,

            ListenerPort (:obj:`Port`): avb参数,

            NonAvbPort (:obj:`Port`): avb参数,

            IsAppended (bool): avb参数,

    Returns:

        Wizard (:obj:`WizardConfig`): wizard config

    Examples:
        .. code:: RobotFramework

            | Create Tsn Wizard | Type=avb |
    """

    result = renix.config_tsn_qcr_stream_identification_function(Configs=Configs,
                                                                 StreamIdentificationFunction=StreamIdentificationFunction,
                                                                 SourceMacAddress=SourceMacAddress,
                                                                 DestinationMacAddress=DestinationMacAddress,
                                                                 VlanId=VlanId, AddUdpHeader=AddUdpHeader,
                                                                 SourcePort=SourcePort, DestinationPort=DestinationPort,
                                                                 AddIpHeader=AddIpHeader,
                                                                 SourceIpAddress=SourceIpAddress,
                                                                 DestinationIpAddress=DestinationIpAddress,
                                                                 IpDscp=IpDscp,
                                                                 IpNextProtocol=IpNextProtocol, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def expand_tsn_wizard(Wizard):
    """
    生成Isis Lsp向导配置

    Args:

        Wizard (list): TSN Wizard

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Expand Isis Lsp Wizard | Wizards=@{Wizards} |
    """

    result = renix.expand_wizard(Wizard=Wizard)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

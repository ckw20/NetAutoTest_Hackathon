import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Wizard-------------------------------------
def create_benchmark(Type='rfc2544', Items=None):
    """
    创建测试仪表测试套件

    Args:

        Type (str): 测试仪表测试套件类型, 默认值: rfc2544, 支持的类型:

            rfc2544

            rfc2889

            rfc3918

            Asymmetric

        Items (list): 测试仪表测试套件中的测试项, 测试套件中的测试项列表, 支持测试项目如下:

            throughput: rfc2544吞吐量测试

            backtoback: rfc2544背靠背测试

            frameloss: rfc2544丢包率测试

            latency: rfc2544时延测试

            addressCachingCapacity: rfc2889地址缓存容量测试

            addressLearningRate: rfc2889地址学习速率测试

            broadcastLatency: rfc2889广播帧转发测试

            broadcastForwarding: rfc2889广播帧时延测试

            congestionControl: rfc2889拥塞控制测试

            erroredFrameFilter: rfc2889错误帧过滤测试

            forwarding: rfc2889转发测试

            mixedThroughput: rfc3918混合吞吐量测试

            scaledGroupForwarding: rfc3918组转发矩阵测试

            multicastThroughput: rfc3918聚合组播吞吐量测试

            multicastGroupCapacity: rfc3918组播组容量测试

            multicastLatency: rfc3918组播转发时延测试

            multicastJoinLeaveLatency: rfc3918加入离开时延测试

    Returns:

         (:obj:`wizard_config`): 仪表测试测试套件对象object

         (list (:obj:`test_config`)): 仪表测试测试套件测试项对象object列表

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Items} | Create List | throughput | frameloss |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Create Benchmark Streams | Config=${Wizard} | Items=@{RFC2544Items} | Type=eth | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} | Mode=meshed | Mapping=roundrobin |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Duration | Config=${Config} | Count=${L2_TestTime} |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{L2_FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |
    """

    result = renix.create_benchmark(Type=Type, Items=Items)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def relate_benchmark_ports(Config, Ports):
    """
    指定测试仪表测试套件使用的端口

    Args:

        Config (:obj:`wizard_config`): 仪表测试测试套件对象object

        Ports (list (:obj:`Port`)): 测试仪表端口对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Items} | Create List | throughput | frameloss |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Create Benchmark Streams | Config=${Wizard} | Items=@{RFC2544Items} | Type=eth | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} | Mode=meshed | Mapping=roundrobin |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Duration | Config=${Config} | Count=${L2_TestTime} |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{L2_FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |
    """

    result = renix.relate_benchmark_ports(Config=Config, Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_benchmark_streams(Config,
                             Items,
                             Type,
                             SrcPoints,
                             DstPoints,
                             Bidirectional=False,
                             Mode='1v1',
                             Mapping='roundrobin',
                             Monitors=()
                             ):
    """
    创建测试仪表测试套件流量

    Args:

        Config (:obj:`wizard_config`): 仪表测试测试套件对象object

        Items (list): 测试仪表测试套件中的测试项, 测试套件中的测试项列表, 支持测试项目如下:

            throughput

            backtoback

            frameloss

            latency

            addressCachingCapacity

            addressCachingRate

            broadcastLatency

            broadcastForwarding

            congestionControl

            erroredFrameFilter

            forwarding

            forwardPressure

            maxForwarding

            mixedThroughput

            scaledGroupForwarding

            multicastThroughput

            multicastGroupCapacity

            multicastLatency

            multicastJoinLeaveLatency

        Type (str): 创建绑定流类型, 支持类型有:

            eth

            ipv4

            ipv6

        SrcPoints (list): 创建绑定流类型源端点对象object列表

        DstPoints (list): 创建绑定流类型目的端点, 目的端点对象object列表

        Bidirectional (bool): 是否使能双向流量, 默认值: False

        Mode (str): 创建绑定流topo类型, 默认值：1v1, 支持类型：

            1v1

            m2m

            meshed

            congestion

        Mapping (str): 创建绑定流端点模式, 默认值：roundrobin, 支持类型：

            roundrobin

            manytomany

        Monitors (list): 作为镜像端口的测试仪表端点对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Items} | Create List | throughput | frameloss |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Create Benchmark Streams | Config=${Wizard} | Items=@{RFC2544Items} | Type=eth | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} | Mode=meshed | Mapping=roundrobin |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Duration | Config=${Config} | Count=${L2_TestTime} |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{L2_FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |
    """

    result = renix.create_benchmark_streams(
        Config=Config,
        Items=Items,
        Type=Type,
        SrcPoints=SrcPoints,
        DstPoints=DstPoints,
        Bidirectional=Bidirectional,
        Mode=Mode,
        Mapping=Mapping,
        Monitors=Monitors
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def benchmark_stream_use_exist(Config, Streams):
    """
    编辑测试套件使用已存在流量

    Args:

        Config (:obj:`wizard`): 仪表测试测试套件对象object

        Streams (list (:obj:`StreamTemplate`)): 仪表测试流模板对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | @{Items} | Create List | throughput | frameloss |
        | @{FrameSize} | Create List | 256 | 1024 | 16383 |
        | ${Streams} | Add Stream | Type=binding | | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Edit Benchmark Path | Configs=${Config} | Path=C:/test |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Benchmark Stream Use Exist | Config=${Wizard} | Streams=${Streams} |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Duration | Config=${Config} | Count=1000 |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |
    """

    result = renix.benchmark_stream_use_exist(Config=Config, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def expand_benchmark(Config):
    """
    测试仪表生成测试仪表测试套件

    Args:

        Config (:obj:`wizard_config`): 仪表测试测试套件对象object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Items} | Create List | throughput | frameloss |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Create Benchmark Streams | Config=${Wizard} | Items=@{RFC2544Items} | Type=eth | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} | Mode=meshed | Mapping=roundrobin |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Duration | Config=${Config} | Count=${L2_TestTime} |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{L2_FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |
    """

    result = renix.expand_benchmark(Config=Config)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def del_benchmark():
    """
    删除测试仪表测试套件

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Items} | Create List | throughput | frameloss |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Create Benchmark Streams | Config=${Wizard} | Items=@{RFC2544Items} | Type=eth | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} | Mode=meshed | Mapping=roundrobin |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Duration | Config=${Config} | Count=${L2_TestTime} |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{L2_FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |
        | Del Benchmark |
    """

    result = renix.del_benchmark()
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------TestItem-------------------------------------
def edit_benchmark_frame(Config, Type='custom', Length=128, Min=128, Max=256, Start=128, End=256, Step=128, Custom=None,
                         ImixTemplates=None):
    """
    编辑测试套件帧长度设置

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        Type (str): 帧长度类型, 默认值: custom, 支持类型:

            fixed

            random

            step

            custom

            imix

        Length (int): 固定帧长值, 默认值: 128, 范围: 58-16383

        Min (int): 最小帧长值, 默认值: 128, 范围: 58-16383

        Max (int): 最大帧长值, 默认值: 256, 范围: 58-16383

        Start (int): 开始帧长值, 默认值: 128, 范围: 58-16383

        End (int): 结束帧长值, 默认值: 256, 范围: 58-16383

        Step (int): 跳变帧步长值, 默认值: 128, 范围: 58-16383

        Custom (list): 自定义帧长列表, 默认值: [64, 128, 256, 512, 1024, 1280, 1518], 范围: 58-16383

        ImixTemplates (list): IMix模板列表, 默认值: None

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | @{Items} | Create List | throughput | frameloss |
        | @{FrameSize} | Create List | 256 | 1024 | 16383 |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Edit Benchmark Path | Configs=${Config} | Path=C:/test |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Create Benchmark Streams | Config=${Wizard} | Items=@{RFC2544Items} | Type=eth | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} | Mode=meshed | Mapping=roundrobin |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Duration | Config=${Config} | Count=1000 |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |
    """

    if ImixTemplates is None:
        ImixTemplates = []
    result = renix.edit_benchmark_frame(Config=Config,
                                        Type=Type,
                                        Length=Length,
                                        Min=Min,
                                        Max=Max,
                                        Start=Start,
                                        End=End,
                                        Step=Step,
                                        Custom=Custom,
                                        ImixTemplates=ImixTemplates
                                        )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_latency(Configs, *, Type='FIFO', DelayBefore=2, DelayAfter=10):
    """
    编辑测试套件时间参数

    Args:

        Configs (list (:obj:`config`)): 仪表测试测试套件测试项对象object列表

        Type (str): 时延类型, 默认值：FIFO, 支持以下类型:

            LIFO

            FIFO

            LILO

            FILO

        DelayBefore (int): 启动流前延迟时间，单位: 秒, 默认值: 2, 范围: 1-3600

        DelayAfter (int): 停止流后延迟时间，单位: 秒, 默认值: 10, 范围: 1-3600

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | @{Items} | Create List | throughput | frameloss |
        | @{FrameSize} | Create List | 256 | 1024 | 16383 |
        | ${Wizard} | ${Config} | Create Benchmark | Type=rfc2544 | Items=${Items} |
        | Edit Benchmark Path | Configs=${Config} | Path=C:/test |
        | Relate Benchmark Ports | Config=${Wizard} | Ports=${Ports} |
        | Create Benchmark Streams | Config=${Wizard} | Items=@{RFC2544Items} | Type=eth | SrcPoints=@{SrcPoints} | DstPoints=@{SrcPoints} | Mode=meshed | Mapping=roundrobin |
        | Edit Benchmark Learning | Configs=${Config} | Frequency=once |
        | Edit Benchmark Latency | Config=${Config} | Type=LIFO |
        | Edit Benchmark Frame | Config=${Config} | Type=custom | Custom=@{FrameSize} |
        | Edit Benchmark Search | Config=${Config} | Init=100 |
        | Expand Benchmark | Config=${Wizard} |

    """

    result = renix.edit_benchmark_latency(Configs=Configs, Type=Type, DelayBefore=DelayBefore,
                                          DelayAfter=DelayAfter)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_learning(Configs, Frequency, *, EnableLearning=True,
                            LearningRate=1000, LearningRepeat=5, DelayBefore=2,
                            EnableArp=False, ArpRate=1000, ArpRepeat=5):
    """
    编辑测试套件地址学习设置

    Args:

        Configs (list (:obj:`config`)): 仪表测试测试套件测试项对象object列表

        Frequency (str): 学习频率, 默认值：once, 支持以下类型:

            once

            trial

            frame

            iter

        EnableLearning (bool): 使能地址学习, 默认值: True

        LearningRate (int): 地址学习速率，单位: 帧/秒, 默认值: 1000, 范围: 1-14880952

        LearningRepeat (int): 学习重复次数, 默认值: 5, 范围: 1-65536

        DelayBefore (int): 学习延迟时间，单位: 秒, 默认值: 2, 范围: 1-65536

        EnableArp (bool): 使能三层ARP学习, 默认值: True

        ArpRate (int): ARP学习速率，单位: 秒, 默认值: 1000, 范围: 1-14880952

        ArpRepeat (int): ARP学习重复次数, 默认值: 5, 范围: 1-65536

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Learning | Config=${Config} | Frequency=trial | EnableLearning=True |

    """

    result = renix.edit_benchmark_learning(Configs=Configs, Frequency=Frequency, EnableLearning=EnableLearning,
                                           LearningRate=LearningRate, LearningRepeat=LearningRepeat,
                                           DelayBefore=DelayBefore,
                                           EnableArp=EnableArp, ArpRate=ArpRate, ArpRepeat=ArpRepeat)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_duration(Config, Trial=1, Mode='second', Count=100):
    """
    编辑测试套件测试时长设置

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        Trial (int): 测试验次数, 默认值: 1

        Mode (str): 模式, 默认值: second, 支持second和burst

        Count (int): 突发包个数(帧)或时长(秒), 默认值: 100, 范围: 1-80000000

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Duration | Config=${Config} | Trial=10 | Mode=burst |

    """

    result = renix.edit_benchmark_duration(Config=Config, Trial=Trial, Mode=Mode, Count=Count)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_transport_layer(Configs, HeaderType=None, EnableRandomPort=True, SrcPortBase=7, SrcPortStep=1,
                                   SrcPortCount=0, DstPortBase=7, DstPortStep=1, DstPortCount=0):
    """
    编辑测试套件使用已存在流量

    Args:

        Configs (list (:obj:`config`)): 仪表测试测试套件测试项对象object列表

        HeaderType (str): 报文头类型, 默认值: none, 支持: none tcp udp

        EnableRandomPort (bool): 使能随机端口, 默认值: True

        SrcPortBase (int): 源端口起始值, 默认值: 7, 范围: 0-65535

        SrcPortStep (int): 源端口步长, 默认值: 1, 范围: 0-65535

        SrcPortCount (int): 源端口数量, 默认值: 0, 范围: 0-65535

        DstPortBase (int): 目的端口起始值, 默认值: 7, 范围: 0-65535

        DstPortStep (int) 目的端口步长, 默认值: 1, 范围: 0-65535

        DstPortCount (int): 目的端口数量, 默认值: 0, 范围: 0-65535

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Transport Layer | Configs=${Configs} | SrcPortBase=1000 | DstPortBase=2000 |

    """

    result = renix.edit_benchmark_transport_layer(Configs=Configs, HeaderType=HeaderType,
                                                  EnableRandomPort=EnableRandomPort,
                                                  SrcPortBase=SrcPortBase, SrcPortStep=SrcPortStep,
                                                  SrcPortCount=SrcPortCount,
                                                  DstPortBase=DstPortBase, DstPortStep=DstPortStep,
                                                  DstPortCount=DstPortCount)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_path(Configs, Path):
    """
    编辑测试套件地址学习设置

    Args:

        Configs (list (:obj:`config`)): 仪表测试测试套件测试项对象object列表

        Path (str): 测试结果DB文件保存的绝对路径, 路径不存在会报错

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Path | Configs=${Configs} | Path=${Path} |

    """

    result = renix.edit_benchmark_path(Configs=Configs, Path=Path)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_result_file_name(Config, EnableCustomResult=False, ResultFileName=None, AddTimeStamp=True):
    """
    配置自定义测试结果名称

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object列表

        EnableCustomResult (bool): 使用自定义测试结果名称, 默认值: False

        ResultFileName (str): 结果名称

        AddTimeStamp (bool): 添加时间戳, 默认值: False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Result File Name | Config=${Config} | ResultFileName=${FileName} |

    """

    result = renix.edit_benchmark_result_file_name(Config=Config, EnableCustomResult=EnableCustomResult,
                                                   ResultFileName=ResultFileName, AddTimeStamp=AddTimeStamp)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------Other1Item-------------------------------------
def edit_benchmark_search(Config, Mode='binary', Lower=1, Upper=100, Init=10, Step=10, Resolution=1, Ratio=50,
                          Acceptance=0, Ignore=False, EnableLatency=False, Maxlatency=30):
    """
    编辑测试套件测试负载设置

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        Mode (str): 负载类型, 默认值: binary, 支持类型:

            binary

            step

            combo

        Lower (int): 速率下限(%), 默认值: 1, 范围: 0.001-100

        Upper (int): 速率上限(%), 默认值: 100, 范围: 0.001-100

        Init (int) 初始速率(%), 默认值: 10, 范围: 0.001-100

        Step (int): 步长(%), 默认值: 10, 范围: 0.001-100

        Resolution (int): 精度(%), 默认值: 1, 范围: 0.001-100

        Ratio (int): 二分法查找百分比(%), 默认值: 50, 范围: 0.001-99.9999

        Acceptance (int): 可接受的丢包率, 默认值: 0, 范围: 0-100

        Ignore (bool): 忽略上下限, 默认值: False

        EnableLatency (bool): 使能时延吞吐量, 默认值: False

        Maxlatency (int): 最大允许时延, 默认值: 30

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Search | Config=${Config} | Mode=step | Init=1 | Step=10 |

    """

    result = renix.edit_benchmark_search(Config=Config,
                                         Mode=Mode,
                                         Lower=Lower,
                                         Upper=Upper,
                                         Init=Init,
                                         Step=Step,
                                         Resolution=Resolution,
                                         Ratio=Ratio,
                                         Acceptance=Acceptance,
                                         Ignore=Ignore,
                                         EnableLatency=EnableLatency,
                                         Maxlatency=Maxlatency)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------Other2Item-------------------------------------
def edit_benchmark_traffic_load_loop(Config, LoadUnit='percent', LoadMode='custom', FixedLoad=10, LoadMin=10,
                                     LoadMax=50, LoadStart=10, LoadEnd=50, LoadStep=10, LoadCustom=(10, 20, 50),
                                     ):
    """
    编辑测试套件负载设置

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        LoadUnit (str): 负载单位, 默认值: percent, 支持类型:

            percent

            fps

            mbps

            kbps

            bps

            Bps

            ifg

        LoadMode (str): 负载类型, 默认值: custom, 支持类型:

            fixed

            random

            step

            custom

        FixedLoad (int): 固定负载, 默认值: 10, 范围: 0.001-100

        LoadMin (int) 最小负载, 默认值: 10, 范围: 0.001-100

        LoadMax (int): 最大负载, 默认值: 50, 范围: 0.001-100

        LoadStart (int): 开始负载, 默认值: 10, 范围: 0.001-100

        LoadEnd (int): 结束负载, 默认值: 50, 范围: 0.001-100

        LoadStep (int): 负载步长, 默认值: 10, 范围: 0.001-100

        LoadCustom (list[int]): 自定义负载, 默认值: [10, 20, 50]

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Traffic Load Loop | Config=${Config} | LoadUnit=step | FixedLoad=20 |

    """

    result = renix.edit_benchmark_traffic_load_loop(
        Config=Config,
        LoadUnit=LoadUnit,
        LoadMode=LoadMode,
        FixedLoad=FixedLoad,
        LoadMin=LoadMin,
        LoadMax=LoadMax,
        LoadStart=LoadStart,
        LoadEnd=LoadEnd,
        LoadStep=LoadStep,
        LoadCustom=LoadCustom,
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------Rfc2544Item-------------------------------------
def edit_benchmark_backtoback_binary_search(Config,
                                            MinDuration=0.000064,
                                            MinFrameCount=1,
                                            DurationResolution=0.0001,
                                            FrameCountResolution=100,
                                            AcceptFrameLoss=0):
    """
    编辑RFC2544测试套件背靠背测试时间阈值

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        MinDuration (float): 最小时长，默认值：0.000064

        MinFrameCount (int): 最小帧数，默认值：1

        DurationResolution (float): 精度（秒），默认值：0.0001

        FrameCountResolution (int): 精度（帧），默认值：100

        AcceptFrameLoss (int): 可接受的丢包率（%），默认值：0

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        Edit Benchmark Backtoback Binary Search | Config=${Config} | MinDuration=1 | MinFrameCount=10} |

    """

    result = renix.edit_benchmark_backtoback_binary_search(Config=Config,
                                                           MinDuration=MinDuration,
                                                           MinFrameCount=MinFrameCount,
                                                           DurationResolution=DurationResolution,
                                                           FrameCountResolution=FrameCountResolution,
                                                           AcceptFrameLoss=AcceptFrameLoss
                                                           )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------Rfc2889Item-------------------------------------
def edit_benchmark_burst_count_loop(Config, Mode='step', Start=1, End=1, Step=1,
                                    Custom=[1, 2]):
    """
    编辑RFC2889测试套件突发帧数，设置测试项: 广播帧转发测试、拥塞控制测试、错误帧过滤测试、转发测试

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        Mode (str): 负载单位, 默认值: step, 支持类型:

            step

            custom

        Start (int): 开始帧数, 默认值: 1, 范围: 1-65535

        End (int): 结束帧数, 默认值: 1, 范围: 1-65535

        Step (int) 帧数步长, 默认值: 1, 范围: 1-65535

        Custom (list[int]): 自定义帧数, 默认值: [1, 2]

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        Edit Benchmark Burst Count Loop | Config=${Config} | Mode=custom | Custom=${custom} |

    """

    result = renix.edit_benchmark_burst_count_loop(Config=Config, Mode=Mode, Start=Start, End=End, Step=Step,
                                                   Custom=Custom)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_address_learning_capacity(Config, MinAddressCount=1, MaxAddressCount=65536, InitAddressCount=20480,
                                             Resolution=2, AgingTime=15, LearningRate=10000):
    """
    编辑RFC2889测试套件地址容量测试项参数

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        MinAddressCount (int): 学习地址最小值, 默认值: 1, 范围: 1-16777216

        MaxAddressCount (int): 习地址最小值 默认值: 65536, 范围: 1-16777216

        InitAddressCount (int) 习地址最小值, 默认值: 20480, 范围: 1-16777216

        Resolution (int): 精度(%), 默认值: 2, 范围: 1-100

        AgingTime (int): 老化时间(秒), 默认值: 50, 范围: 1-3600

        LearningRate (int): 地址学习速率(帧/秒), 默认值: 10000, 范围: 1-148809523

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Address Learning Capacity | Config=${Config} | LearningRate=100 |

    """

    result = renix.edit_benchmark_address_learning_capacity(
        Config=Config,
        MinAddressCount=MinAddressCount,
        MaxAddressCount=MaxAddressCount,
        InitAddressCount=InitAddressCount,
        Resolution=Resolution,
        AgingTime=AgingTime,
        LearningRate=LearningRate,
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_address_learning_rate(Config, MinRateCount=1488, MaxRateCount=1488, InitRateCount=1488,
                                         Resolution=2, AgingTime=15, AddressCount=1000):
    """
    编辑RFC2889测试套件地址容量测试项参数

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        MinRateCount (int): 学习地址最小值, 默认值: 1488, 范围: 1-148809523

        MaxRateCount (int): 习地址最小值 默认值: 1488, 范围: 1-148809523

        InitRateCount (int) 习地址最小值, 默认值: 1488, 范围: 1-148809523

        Resolution (int): 精度(%), 默认值: 2, 范围: 1-100

        AgingTime (int): 老化时间(秒), 默认值: 50, 范围: 1-3600

        AddressCount (int): 地址数量, 默认值: 1000, 范围: 1-4294967295

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Address Learning Rate | Config=${Config} | AddressCount=100 |

    """

    result = renix.edit_benchmark_address_learning_rate(
        Config=Config,
        MinRateCount=MinRateCount,
        MaxRateCount=MaxRateCount,
        InitRateCount=InitRateCount,
        Resolution=Resolution,
        AgingTime=AgingTime,
        AddressCount=AddressCount,
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_errored_frame_filtering(Config, CrcTested=True, CrcFrameLength=64, UndersizedTested=True,
                                           UndersizedFrameLength=60, OversizedTested=True, OversizedFrameLength=1519,
                                           MaxLegalFrameLength=1518, BurstSize=1):
    """
    编辑RFC2889测试套件错误帧过滤测试项参数

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        CrcTested (bool): 使能错误类型CRC, 默认值: True

        CrcFrameLength (int): CRC帧长度, 默认值: 64, 范围: 64-10000

        UndersizedTested (bool): 使能超短帧长度, 默认值: True

        UndersizedFrameLength (int) 超短帧长度, 默认值: 60, 范围: 58-63

        OversizedTested (int): 使能超长帧长度, 默认值: True

        OversizedFrameLength (int): 超长帧长度, 默认值: 1519, 范围: 1519-16383

        MaxLegalFrameLength (int): 最大合法帧长, 默认值: 1518, 范围: 1-4294967295

        BurstSize (int): 地址数量, 默认值: 1000, 范围: 1-4294967295

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Errored Frame Filtering | Config=${Config} | BurstSize=100 |

    """

    result = renix.edit_benchmark_errored_frame_filtering(Config=Config, CrcTested=CrcTested,
                                                          CrcFrameLength=CrcFrameLength,
                                                          UndersizedTested=UndersizedTested,
                                                          UndersizedFrameLength=UndersizedFrameLength,
                                                          OversizedTested=OversizedTested,
                                                          OversizedFrameLength=OversizedFrameLength,
                                                          MaxLegalFrameLength=MaxLegalFrameLength, BurstSize=BurstSize)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------Rfc3918Item-------------------------------------
def edit_benchmark_multicast_base_parameters(Configs,
                                             Version='igmpv2',
                                             Ipv4GroupAddressStart='225.0.0.1',
                                             Ipv4GroupAddressStep='0.1.0.0',
                                             Ipv4PrefixLength=32,
                                             Ipv6GroupAddressStart='ff1e::1',
                                             Ipv6GroupAddressStep='0:0:0:1::',
                                             Ipv6PrefixLength=128,
                                             GroupIncrement=1,
                                             JoinGroupDelay=15,
                                             LeaveGroupDelay=15,
                                             JoinLeaveSendRate=1000,
                                             GroupDistributeMode='even',
                                             ):
    """
    编辑RFC3918测试套件-组播参数

    Args:

        Configs (list (:obj:`config`)): 仪表测试测试套件测试项对象object列表

        Version (str): 负载单位, 默认值: igmpv2, 支持类型:

            igmpv1

            igmpv2

            igmpv3

            mldv1

            mldv2

        Ipv4GroupAddressStart (str): 起始IP地址, 默认值: 225.0.0.1

        Ipv4GroupAddressStep (str): 起始IP步长, 默认值: 0.1.0.0

        Ipv4PrefixLength (int): IP前缀长度, 默认值: 32, 范围: 1-32

        Ipv6GroupAddressStart (str): 起始IPv6地址, 默认值: 'ffle::'

        Ipv6GroupAddressStep (str): 起始IPv6步长, 默认值: '0:0:0:1::'

        Ipv6PrefixLength (int): IPv6前缀长度, 默认值: 128, 范围: 1-128

        GroupIncrement (int): 组跳变步长, 默认值: 1, 范围: 1-4294967295

        JoinGroupDelay (int): 加入组延迟(秒), 默认值: 15, 范围: 0-4294967295

        LeaveGroupDelay (int): 离开组延迟(秒), 默认值: 15, 范围: 0-4294967295

        JoinLeaveSendRate (int): 组播发消息速率(包/秒), 默认值: 1000, 范围: 0-1000000000

        GroupDistributeMode (str): 组播组分布模式, 默认值: even, 范围:

            even: 平均

            weighted: 权重

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Multicast Base Parameters | Configs=${Configs} | GroupDistributeMode=weigh |

    """

    result = renix.edit_benchmark_multicast_base_parameters(
        Configs=Configs,
        Version=Version,
        Ipv4GroupAddressStart=Ipv4GroupAddressStart,
        Ipv4GroupAddressStep=Ipv4GroupAddressStep,
        Ipv4PrefixLength=Ipv4PrefixLength,
        Ipv6GroupAddressStart=Ipv6GroupAddressStart,
        Ipv6GroupAddressStep=Ipv6GroupAddressStep,
        Ipv6PrefixLength=Ipv6PrefixLength,
        GroupIncrement=GroupIncrement,
        JoinGroupDelay=JoinGroupDelay,
        LeaveGroupDelay=LeaveGroupDelay,
        JoinLeaveSendRate=JoinLeaveSendRate,
        GroupDistributeMode=GroupDistributeMode,
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_multicast_stream_tos(Configs, Tos=0, FlowLabel=0, TTL=7, Priority=0):
    """
    编辑RFC3918测试套件-组播参数-流配置

    Args:

        Configs (list (:obj:`config`)): 仪表测试测试套件测试项对象object列表

        Tos (int): IPv4 TOS值, 默认值: 0

        FlowLabel (int): IPv6 Flow Label值, 默认值: 0

        TTL (int): IPv4 TTL值, 默认值: 10

        Priority (int): VLAN优先级, 默认值: 0

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Multicast Stream Tos | Configs=${Configs} | Tos=7 |

    """

    result = renix.edit_benchmark_multicast_stream_tos(Configs=Configs, Tos=Tos, FlowLabel=FlowLabel, TTL=TTL,
                                                       Priority=Priority)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_multicast_other(Configs, StopTestWhenFailed=True, VerifyFreq='topo_changed', DurationMode='second',
                                   TimeDurationCount=1, BurstDurationCount=100, TxFrameRate=1000):
    """
    编辑RFC3918测试套件-组播参数-其他

    Args:

        Configs (list (:obj:`config`)): 仪表测试测试套件测试项对象object列表

        StopTestWhenFailed (bool): 如果流验证失败停止测试, 默认值: True

        VerifyFreq (str): 验证频率, 默认值: topo_changed, 支持:

            none

            topo_changed

            frame_size

            iteration

        DurationMode (str): 时长模式, 默认值: second, 支持:

            second

            burst

        TimeDurationCount (int): 发送秒速, 默认值: 1000

        BurstDurationCount (int): 帧发送数量, 默认值: 100

        TxFrameRate (int): 帧发送速率(帧/秒), 默认值: 1000

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Multicast Other | Configs=${Configs} | TimeDurationCount=100 |

    """

    result = renix.edit_benchmark_multicast_other(Configs=Configs, StopTestWhenFailed=StopTestWhenFailed,
                                                  VerifyFreq=VerifyFreq, DurationMode=DurationMode,
                                                  TimeDurationCount=TimeDurationCount,
                                                  BurstDurationCount=BurstDurationCount,
                                                  TxFrameRate=TxFrameRate)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_multicast_traffic_ratio_loop(Config,
                                                LoopMode='step',
                                                FixedRatio=10,
                                                MinRatio=10,
                                                MaxRatio=50,
                                                StartRatio=10,
                                                EndRatio=50,
                                                StepRatio=10,
                                                CustomRatio=(10, 20, 100),
                                                ):
    """
    RFC3918测试套件配置组播混合吞吐量-组播百分比设置

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        LoopMode (str): 模式, 默认值: step, 支持:

            fixed

            random

            step

            custom

        FixedRatio (int): 固定比例, 默认值: 10

        MinRatio (int): 最小比例, 默认值: 10

        MaxRatio (int): 最大比例, 默认值: 50

        StartRatio (int): 开始比例, 默认值: 10

        EndRatio (int): 结束比例, 默认值: 50

        StepRatio (int): 步长, 默认值: 10

        CustomRatio (list[int]): 自定义比例, 默认值: (10, 20, 100)

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Multicast Traffic Ratio Loop | Config=${Config} | LoopMode=step |

    """

    result = renix.edit_benchmark_multicast_traffic_ratio_loop(
        Config=Config,
        LoopMode=LoopMode,
        FixedRatio=FixedRatio,
        MinRatio=MinRatio,
        MaxRatio=MaxRatio,
        StartRatio=StartRatio,
        EndRatio=EndRatio,
        StepRatio=StepRatio,
        CustomRatio=CustomRatio,
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_multicast_group_count_loop(Config,
                                              LoopMode='step',
                                              FixedGroup=10,
                                              MinGroup=10,
                                              MaxGroup=50,
                                              StartGroup=10,
                                              EndGroup=50,
                                              StepGroup=10,
                                              CustomGroup=(10, 20, 100),
                                              ):
    """
    RFC3918测试套件-组播组

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        LoopMode (str): 模式, 默认值: step, 支持:

            fixed

            random

            step

            custom

        FixedGroup (int): 固定, 默认值: 10

        MinGroup (int): 最小, 默认值: 10

        MaxGroup (int): 最大, 默认值: 50

        StartGroup (int): 开始, 默认值: 10

        EndGroup (int): 结束, 默认值: 50

        StepGroup (int): 步长, 默认值: 10

        CustomGroup (list[int]): 自定义比例, 默认值: (10, 20, 100)

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Multicast Group Count Loop | Config=${Config} | LoopMode=fixed |

    """

    result = renix.edit_benchmark_multicast_group_count_loop(
        Config=Config,
        LoopMode=LoopMode,
        FixedGroup=FixedGroup,
        MinGroup=MinGroup,
        MaxGroup=MaxGroup,
        StartGroup=StartGroup,
        EndGroup=EndGroup,
        StepGroup=StepGroup,
        CustomGroup=CustomGroup,
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_multicast_mixed_throughput_unicast_streams(Config, Streams):
    """
    RFC3918测试套件组播混合吞吐量-配置单播流量

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        Streams (list[(:obj:`StreamTemplate`)]): 仪表测试流模板对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Multicast Mixed Throughput Unicast Streams | Config=${Config} | Streams=${Streams} |

    """

    result = renix.edit_benchmark_multicast_mixed_throughput_unicast_streams(Config=Config, Streams=Streams)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_benchmark_multicast_join_leave_delay(Config,
                                              DelayBetweenJoinAndStartStream=10,
                                              DelayBetweenJoinAndLeave=10,
                                              ):
    """
    RFC3918测试套件-配置加入离开组时延

    Args:

        Config (:obj:`config`): 仪表测试测试套件测试项对象object

        DelayBetweenJoinAndStartStream (int): 从启动流量开始到发送加入组报文之间的时间间隔。单位是秒, 默认值: 10, 范围: 0-3600

        DelayBetweenJoinAndLeave (int): 发送加入组报文和发送离开组报文之间的时间间隔。单位是秒, 默认值: 10, 范围: 0-3600

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Edit Benchmark Multicast Join Leave Delay | Config=${Config} | DelayBetweenJoinAndStartStream=100 |
    """

    result = renix.edit_benchmark_multicast_join_leave_delay(
        Config=Config,
        DelayBetweenJoinAndStartStream=DelayBetweenJoinAndStartStream,
        DelayBetweenJoinAndLeave=DelayBetweenJoinAndLeave,
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def run_benchmark(Mode=0, Timer=1800, Analyzer=False):
    """
    执行测试仪表配置中的测试套件

    Args:

        Mode (int): 智能脚本的执行模式, (取值, 0 / 1) 0: 连续执行, 1: 单步执行

        Timer (int): 测试套件执行超时时间, (单位, 秒), 默认值: 1800 秒

        Analyzer (bool): 结果分析器开关, 布尔值Bool (范围：True / False), 默认值: False

    Returns:

        str: 测试结果DB文件的绝对路径

    Examples:
        robotframework:

    .. code:: robotframework

        | ${result} | Run Benchmark |
        | ${result} | Run Benchmark | Mode==1 |
        | ${result} | Run Benchmark | Timer==3600 |
        | ${result} | Run Benchmark | Analyzer==True |
        | ${result} | Run Benchmark | Mode==1 | Timer==3600 | Analyzer==True |
    """

    result = renix.run_benchmark(Mode=Mode, Timer=Timer, Analyzer=Analyzer)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_benchmark_result(DB, Type, ReturnType='dict', *args, **kwargs):
    """
    从测试套件执行结果DB文件中获取指定测试结果数据

    Args:

        DB (str): 测试结果DB文件的绝对路径, (例如："C:/TestSuite/Benchmark/2021_07_29_21_10_36/Asymmetric_throughput_summary2021-07-29_21-11-08/Asymmetric_throughput_summary_2021-07-29_21-11-08.db")

        Type (str): 测试套件类型, (取值范围：RFC2544 / Asymmetric / RFC2889 / RFC3918)

    Returns:

        list: 测试套件直接结果DB文件中获取指定测试结果数据列表

    Examples:
        robotframework:

    .. code:: robotframework

        | ${DB}  == "C:/TestSuite/Benchmark/2021_07_29_21_10_36/Asymmetric_throughput_summary2021-07-29_21-11-08/Asymmetric_throughput_summary_2021-07-29_21-11-08.db") |
        | ${Type} == "Asymmetric" |
        | ${Item} == "Throughput" |
        | ${FrameSize} == [64, 128, 256, 512, 1024. 1280, 1518] |
        | ${result} | Get Benchmark Result | ${DB} | ${Type} |
    """

    result = renix.get_benchmark_result(DB=DB, Type=Type, ReturnType=ReturnType, args=args, kwargs=kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def format_benchmark_result(Result):
    """
    格式化列表为二维表格形式

    Args:

        Result (list): 测试套件直接结果DB文件中获取指定测试结果数据列表

    Returns:

        (:obj:`PrettyTable`): PrettyTable对象

    Examples:
        robotframework:

    .. code:: robotframework

        | ${result} | Format Benchmark Result | ${Result} |
    """

    result = renix.format_benchmark_result(Result=Result)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def export_benchmark_result(Result, Path, Sheet):
    """
    将测试套件的结果导出到excel表格

    Args:

        Result (list): 测试套件直接结果DB文件中获取指定测试结果数据列表

        Path (str): 导出文件的路径, (例如："C:/Report.xls")

        Sheet: (str) 导入的excel文件的sheet页名称, (例如："ipv4 natp")

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${result} | Export Benchmark Result | ${Result} | ${Path} | ${Sheet} |
    """

    result = renix.export_benchmark_result(Result=Result, Path=Path, Sheet=Sheet)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

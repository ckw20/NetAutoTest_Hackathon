"""测试仪表全局配置公共参数模块

测试仪表全局配置和常用功能：
reset_tester:清空测试仪表所有配置；
init_tester:初始化测试仪表；
shutdown_tester:关闭测试仪表测试进程；
load_case:测试仪表加载配置文件；
save_case:测试仪表保存配置文件；
connect_chassis:连接测试仪表机箱后台；
del_objects:删除测试仪表相关对象；
edit_overall_setting:编辑测试仪表全局参数；
smart_scripter_global_group:获取智能脚本的全局组对象；
smart_scripter_command:生成智能脚本命令；
"""

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def reset_tester():
    """
    清空测试仪表所有配置

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Reset Tester |
    """

    result = renix.reset_tester()
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def init_tester(Product='BIGTAO', Mode='performance', Log=True, **kwargs):
    """
    初始化测试仪表

    Args:

        Product (str): 测试产品类型, 支持BIGTAO和DARYU

        Mode (str): 统计模式, 支持Performance和DB

        Log (bool): 是否打印日志

    Keyword Args:

        Rtsm (str): 使用远端RTSM服务器上的cl进行测试

        RtsmPort (int): 远端RTSM服务器端口号，默认值：10001

        CL (str): 使用已存在cl测试，已存在cl地址

        CLPort (int): 远端RTSM服务器端口号，默认值：9001

        TimeOut (int): 连接远端RTSM服务器或cl实例超时时间，单位：sec，默认值：30

        StartApp (bool): 使用远端RTSM功能时是否自动启动Renix界面程序

        Show (bool): 在Log使能打印日志情况下，Show=True打印函数执行时间，默认值：False

        Check (bool): 函数使能异常检测，函数内部出现异常不退出程序，，默认值：True

    Returns:

        (:obj:`sys_entry`): sys_entry测试仪表根节点对象

    Examples:
        robotframework:

    .. code:: robotframework

        | ${result} | init tester | Product=DARYU | Mode=Performance |
    """

    result = renix.init_tester(Product=Product, Mode=Mode, Log=Log, **kwargs)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def shutdown_tester():
    """
    关闭测试仪表测试进程

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Shutdown Tester |
    """

    result = renix.shutdown_tester()
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_app():
    """
    启动Renix客户端界面程序并连接RTSM的CL

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Shutdown Tester |
    """

    result = renix.start_app()
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def load_case(Path):
    """
    测试仪表加载配置文件

    Args:

        Path (str): 配置文件路径, 类型 string (例如："C:/test.xcfg")

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${result} | Load Case | Path=='C:/test.xcfg' |
    """

    result = renix.load_case(Path=Path)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def save_case(Path):
    """
    测试仪表保存配置文件

    Args:

        Path (str): 配置文件路径, 例如："C:/test.xcfg"

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${result} | Save Case | Path=='C:/test.xcfg' |
    """

    result = renix.save_case(Path=Path)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def connect_chassis(Chassis):
    """
    连接测试仪表机箱后台.

    Args:

        Chassis (str): 机箱主机IP地址列表

    Returns:

        list: Chassis对象列表

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Hosts} | Create List | 192.168.0.10 | 192.168.0.10 |
        | ${Chassis} | Connect Chassis | Chassis=${Hosts} |
    """

    result = renix.connect_chassis(Chassis=Chassis)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def del_objects(Objects):
    """
    删除测试仪表相关对象

    Args:

        Objects (list): 测试仪表相关对象object列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Port} | Get Ports |
        | Del Objects | Port=${Port} |
    """

    result = renix.del_objects(Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_configs(Configs=None, KeyType='handle', Upper=None):
    """
    获取测试仪表指定对象

    Args:

        Configs (list): 测试仪表端口对象类型列表, 类型为：list

        KeyType (str): 返回字典使用指定类型作为字典的key，默认值： handle，支持：

            handle

            name

        Upper (object): 指定上层节点获取对象

    Returns:

        dict: {'handle': object}或者{'name': object}

    Examples:
        robotframework:

    .. code:: robotframework

        | ${Result} | Get Configs | KeyType=name |
        | ${Result} | Get Configs | Configs=StreamTemplate | KeyType=handle |
        | ${Result} | Get Configs | Configs=BgpProtocolConfig | KeyType=name |
        | ${Result} | Get Configs | Configs=StreamTemplate | KeyType=handle | Upper=${Port_1} |
        | ${Result} | Get Configs | Configs=BgpProtocolConfig | KeyType=name | Upper=${Port_1} |
    """

    result = renix.get_configs(Configs=Configs, KeyType=KeyType, Upper=Upper)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_configs(Configs, **kwargs):
    result = renix.edit_configs(Configs=Configs, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_config_children(Configs, Children):
    result = renix.get_config_children(Configs=Configs, Children=Children)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_object_attrs(Objects, Attr='handle'):
    if not isinstance(Objects, list):
        Objects = [Objects]
    result = []
    for object in Objects:
        if hasattr(object, Attr):
            result.append(getattr(object, Attr))
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result[0] if len(result) == 1 else result


def edit_overall_setting(**kwargs):
    """
    编辑测试仪表全局参数

    Keyword Args:

        流全局配置，参数支持：

            PortSendMode (str): 端口发送模式，默认值：SYNCHRONOUS，取值范围：

                SYNCHRONOUS

                ASYNCHRONOUS

            MeshCreationMode (str): 拓扑创建模式，默认值：PortBased，取值范围：

                PortBased

                EndpointBased

        二层学习，参数支持：

            Rate (int): 速率（帧/秒）, 类型：number，取值范围：1-4294967295, 默认值：100

            RepeatCount (int): 重复次数, 类型：number，取值范围：0-4294967295, 默认值：3

            DelayTime (int): 学习前延迟时间, 类型：number，取值范围：0-4294967295, 默认值：1

            RxLearningEncapsulation (str): 封装类型，默认值：TX_ENCAPSULATION，取值范围：

                NO_ENCAPSULATION

                TX_ENCAPSULATION

        ARP/ND选项，参数支持：

            EnableAutoArp (bool): 使能自动ARP/ND, 类型: bool, 默认值：True

            StopOnArpFail (bool): ARP/ND失败自动停止测试, 类型: bool, 默认值：False

            AutoArpWaitTime (int): 自动ARP/ND等待时间（秒）, 类型：number，取值范围：0-4294967295, 默认值：30

        Y.1731 LM全局配置，参数支持：

            TestModeType (str): 测试模式, 类型：string, 默认值：TYPE_NORMAL，取值范围：

                TYPE_NORMAL

                TYPE_CC_SCALE_MODE

                TYPE_CC_SCALE_MODE_WITHOUT_RX

            LmrRxFCfStart (int): LMR帧的RxFCF初始值, 类型：number，取值范围：0-4294967295, 默认值：1

            LmrRxFCfStep (int): LMR帧的RxFCF更新步长, 类型：number，取值范围：0-65535, 默认值：1

            LmrTxFCbStart (int): LMR帧的TxFCF初始值, 类型：number，取值范围：0-4294967295, 默认值：1

            LmrTxFCbStep (int): LMR帧的TxFCF更新步长, 类型：number，取值范围：1-65535, 默认值：9

            LmmTxFCfOffset (int): LMM帧的TxFCF的偏移值, 类型：number，取值范围：0-32767, 默认值：0

            LmrRxFCfOffset (int): LMR帧的RxFCF的偏移值, 类型：number，取值范围：0-32767, 默认值：0

            LmrTxFCbOffset (int): LMR帧的TxFCF的偏移值, 类型：number，取值范围：0-32767, 默认值：0

            DmTimeUnit (str): DM时间统计单位, 类型：string, 默认值：TYPE_NORMAL，取值范围：

                TIME_MS

                TIME_NS

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | edit_overall_setting | PortSendMode=ASYNCHRONOUS | RxLearningEncapsulation=TX_ENCAPSULATION | EnableAutoArp=False | TestModeType=TYPE_CC_SCALE_MODE |
    """

    result = renix.edit_overall_setting(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_peclsp_for_srte(Excel, Session, TunnelCount=16000, PcelspCount=4000,
                           SymbolicNameIdentification='Tunnel'):
    """
    从Excel表格创建SRTE性能测试PCE LSP

    Args:

        Excel (str): Excel文件完整路径

        Session (object): PceLspConfig对象

        TunnelCount (int): 隧道数量

        PcelspCount (int): pcelsp数量

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
    """

    result = renix.create_peclsp_for_srte(Excel=Excel, Session=Session, TunnelCount=TunnelCount,
                                             PcelspCount=PcelspCount,
                                             SymbolicNameIdentification=SymbolicNameIdentification)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv4_flowspec_performance(Session, MaxRouteCount, SourcePrefix, DestPrefix):
    """
    创建bgpflowspec性能条目

    Args:

        Session (object): bgp session

        MaxRouteCount (int): 支持最大bgpls数量

        SourcePrefix (list): 接口列表

        DestPrefix (list): BGP ipv4路由列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
    """

    result = renix.create_bgp_ipv4_flowspec_performance(Session=Session, MaxRouteCount=MaxRouteCount,
                                                           SourcePrefix=SourcePrefix, DestPrefix=DestPrefix)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def smart_scripter_global_group():
    """
    获取智能脚本的全局组对象

    Returns:

        (:obj:`GroupCommand`): 智能脚本的全局组对象

    Examples:
        robotframework:

    .. code:: robotframework

        | Smart Scripter Global Group |

    """

    result = renix.smart_scripter_global_group()
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def smart_scripter_command(ParentGroup, Command, Rename='', **kwargs):
    """
    创建智能脚本命令

    Args:

        ParentGroup (:obj:`GroupCommand`): 智能脚本命令所在的组对象

        Command (str): 要创建的智能脚本命令名，支持的命令名可参照renix英文手册, e.g.GroupCommand

        Rename (str): 对创建的智能脚本重命名，默认值：“”

    Keyword Args:

        命令支持的参数和值，具体参照renix英文手册各command命令的参数和值, e.g.ProtocolList=[BgpSession1.handle]

    Returns:

        智能脚本的命令对象

    Examples:
        robotframework:

    .. code:: robotframework

        | Smart Scripter Command | ParentGroup=${GlobalGroup} | Command=StartProtocolCommand | ProtocolList=${bgp} |

    """

    result = renix.smart_scripter_command(ParentGroup=ParentGroup,
                                          Command=Command, Rename=Rename, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def smart_scripter_control_condition(ControlCommand, ControlConditionName, ConditionResult='PASS', **kwargs):
    """
    创建智能脚本控制命令的条件对象

    Args:

        ControlCommand (obj): 智能脚本命令对象，当前支持的命令名有：

            IfCommand

            ElseIfCommand

            ElseCommand

            LoopCommand

            ContinueCommand

            BreakCommand

            GotoCommand

            WhileCommand

        ControlConditionName (str): 要创建的智能脚本控制命令的条件名称，支持的条件名可参照renix英文手册, e.g.StartStreamCommand

        ConditionResult (str): 要创建的智能脚本控制命令条件的判断结果，适用于IfCommand、ElseIfCommand、WhileCommand，默认值：“PASS”，取值范围：

            PASS

            FALSE

    Keyword Args:

        条件对象支持的参数和值，具体参照renix英文手册各command命令的参数和值, e.g.ProtocolList=[BgpSession1.handle]

    Returns:

        智能脚本的控制命令的条件对象

    Examples:
        robotframework:

    .. code:: robotframework

        | ${IfCommand} | Smart Scripter Command | ParentGroup=${GlobalGroup} | Command=IfCommand |
        | Smart Scripter Control Condition | ControlCommand=${IfCommand} | ControlConditionName=StartStreamCommand | ConditionResult=FALSE | ProtocolList=${bgps} |
    """

    result = renix.smart_scripter_control_condition(ControlCommand=ControlCommand,
                                                    ControlConditionName=ControlConditionName,
                                                    ConditionResult=ConditionResult, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

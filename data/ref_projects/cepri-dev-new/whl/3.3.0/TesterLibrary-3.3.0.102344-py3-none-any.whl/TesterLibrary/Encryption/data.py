from RenixLibrary.common.base import *

# renix = RenixAPI(License=['HL-API'])
# renix = RenixAPI(License=['Conformance-IPv4'])
renix = RenixAPI()

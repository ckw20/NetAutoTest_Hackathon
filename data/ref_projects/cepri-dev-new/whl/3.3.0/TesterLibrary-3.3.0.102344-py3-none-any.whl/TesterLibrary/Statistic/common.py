import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Statistic-------------------------------------
def subscribe_result(Types=None):
    """
    订阅测试仪表统计视图

    Args:

        Types (list): 需要订阅测试仪表统计视图列表，当传入为None时，订阅当前配置的所有视图，目前支持的统计视图：

            PortStats
            PortAvgLatencyStats
            StreamStats
            StreamTxStats
            StreamRxStats
            StreamBlockStats
            StreamBlockTxStats
            StreamBlockRxStats

            BfdIpv4SessionResult
            BfdIpv6SessionResult
            BfdSessionResult
            IsisBfdSessionResult
            IsisBfdIpv6SessionResult
            Ospfv2BfdSessionResult
            Ospfv3BfdSessionResult

            EvpnRoutesStatistic
            BgpLinkStateStatistic
            BgpSessionStatistic
            BgpSessionBlockStatistic

            IsisSessionStats
            IsisTlvStats

            Ospfv2SessionResultPropertySet

            Ospfv3SessionResultPropertySet

            PimSessionStats
            PimGroupStats

            RipSessionBlockStats
            RipSessionStats

            IgmpHostResults
            IgmpPortAggregatedResults

            IgmpQuerierResults

            MldHostResults
            MldPortAggregatedResults

            MldQuerierResults

            PppoePortStatistic
            PppoeServerBlockStatistic
            PppoeServerStatistic
            PppoeClientBlockStatistic
            PppoeClientStatistic

            Dhcpv4ServerStats
            Dhcpv4ClientBlockStats
            Dhcpv4ClientStats
            Dhcpv4PortStats

            Dhcpv6PortStatistics
            Dhcpv6ServerStatistics
            Dhcpv6ClientStatistics
            Dhcpv6ClientBlockStatistics
            Dhcpv6PdClientStatistics

            L2tpPortStatistic
            L2tpBlockStatistic
            L2tpSessionStatistic
            L2tpTunnelStatistic

            Dot1xBlockStatistics
            Dot1xPortStatistics
            Dot1xStatistics

            LdpSessionStatistic
            LdpLspStatistic

            PcepLspStatistic
            PcepLspBlockStatistic
            PcepPortStatistic
            PcepSessionStatistic
            PcepSessionBlockStatistic

            LspPingSessionStats
            LspPingEchoRequestStats
            LspTraceEchoRequestStats

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | @{Types} | Create List | PortStats | StreamBlockStats |
        | Subscribe Result | Types=${Types} |
    """

    result = renix.subscribe_result(Types=Types)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def clear_result(All=True, Objects=None):
    """
    清除测试仪表统计

    Args:

        All (bool): 是否清除所有已经订阅的统计视图的数据, 默认位: True

        Objects (list): 指定需要清空视图的对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | Clear Result |
    """

    result = renix.clear_result(All=All, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def reset_statistic():
    """
    重置测试仪表已缓存统计

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        robotframework:

    .. code:: robotframework

        | Reset Statistic |
    """

    result = renix.reset_statistic()
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def save_result(Path, FileName):
    """
    保存测试仪表统计结果到DB文件

    Args:

        Path (str): 保存文件的路径

        FileName (str): 保存文件名称

    Returns:

        str: 返回保存的DB文件的绝对路径字符串

    Examples:
        robotframework:

    .. code:: robotframework

        | @{Subscribe} | Create List | PortStats | StreamBlockStats |
        | Subscribe Result | Types=@{Subscribe} |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${DB} | Save Result | Path=D:\test | FileName=test |
    """

    result = renix.save_result(Path=Path, FileName=FileName)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_port_statistic(Port=None, StaItems=None, Mode=True):
    """
    获取测试仪表端口统计结果

    Args:

        Port (:obj:`Port`): 指定需要获取结果的端口对象object

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取端口统计项目, 目前支持的统计项

            TxTotalFrames：发送报文总数

            RxTotalFrames：接收报文总数

            TxStreamFrames：发送流报文总数

            TxSignatureStreamFrames：发送带标签流报文总数(仅DarYu支持)

            RxSignatureStreamFrames：接收带标签流报文总数

            TxFrameRate：发送报文速率(fps)

            RxFrameRate：接收报文速率(fps)

            TxL1Rate：发送线速(bps)

            RxL1Rate：接收线速(bps)

            TxUtil：发送百分比(%)

            RxUtil：接收百分比(%)

            TxByteRate：发送字节速率(Bps)

            RxByteRate：接收字节速率(Bps)

            TxBitRate：发送比特速率(bps)

            RxBitRate：接收比特速率(bps)

            TxTotalBytes：发送字节总数(仅DarYu支持)

            RxTotalBytes：接收字节总数(仅DarYu支持)

            RxFCSErr：接收FCS错误数

            RxIpv4ChecksumError：接收IPv4 Checksum Error报文数

            RxTcpChecksumError：接收TCP Checksum Error报文数

            RxUdpChecksumError：接收UDP Checksum Error报文数

            RxPrbsFillBytes：接收PRBS填充字节数

            RxPrbsErrorBits：接收PRBS错误位数

            RxPrbsErrorFrames：接收PRBS错误报文数

            RxIpv4Frames：接收IPv4帧数

            RxIpv6Frames：接收IPv6帧数

            RxTcpFrames：接收TCP帧数

            RxUdpFrames：接收UDP帧数

            RxMplsCount：接收MPLS帧数

            RxIcmpFrames：接收ICMP帧数

            RxVlanFrames：接收VLAN帧数

            RxFCoEFrames：接收FCoE帧数

            RxPauseFrames：接收Pause帧数

            RxUndersizeFrames：接收超短帧数

            RxOversizeFrames：接收超长帧数

            RxJumboFrames：接收巨型帧数

            RxOutofSequenceCount：接收乱序帧数

            RxFilter0Count：接收过滤帧数_0

            RxFilter1Count：接收过滤帧数_1

            RxFilter2Count：接收过滤帧数_2

            RxFilter3Count：接收过滤帧数_3

            RxFilter4Count：接收过滤帧数_4

            RxFilter5Count：接收过滤帧数_5

            RxFilter6Count：接收过滤帧数_6

            RxFilter7Count：接收过滤帧数_7

            RxPktLossCount：接收丢包帧数

            RxInOrderCount：接收有序帧数

            RxReorderCount：接收重排序帧数

            RxRepeatFrameCount：接收重复帧数

            RxPortLateCount：接收端口延迟帧数

            RxCorrectedRSFECErrorsFramesCodewords：接收Corrected RS FEC Error帧数（codewords）

            RxUncorrectedRSFECErrorsFramesCodewords：接收Uncorrected RS FEC Error帧数（codewords）

            RxCorrectedBaseRFECErrorsFramesCodewords：接收Corrected BaseR FEC Error帧数（codewords）

            RxUncorrectedBaseRFECErrorsFramesCodewords：接收Uncorrected BaseR FEC Error帧数（codewords）

            TxCrcFrameCount：发送CRC帧数

            TxErr3CheckFrameCount：发送IP Checksum Error报文数

            TxErr4CheckFrameCount：发送L4 Checksum Error报文数

            TxIpv4Count：发送IPv4帧数

            TxIpv6Count：发送IPv6帧数

            TxMplsCount：发送MPLS帧数

            TxIpv4FrameCount：发送IPv4流帧数

            TxIpv6FrameCount：发送IPv6流帧数

            TxVlanFrameCount：发送VLAN流帧数

            TxMplsFrameCount：发送MPLS流帧数

            TxOversizeFrames：发送超长帧数

            TxUndersizeFrames：发送超短帧数

            TxJumboFrames：发送巨型帧数

            RxPFCFrames：接收PFC帧数

            RxPFCRate：接收PFC速率

            RxPFCPriority0Frames：接收PFC优先级是0的帧数

            RxPFCPriority1Frames：接收PFC优先级是1的帧数

            RxPFCPriority2Frames：接收PFC优先级是2的帧数

            RxPFCPriority3Frames：接收PFC优先级是3的帧数

            RxPFCPriority4Frames：接收PFC优先级是4的帧数

            RxPFCPriority5Frames：接收PFC优先级是5的帧数

            RxPFCPriority6Frames：接收PFC优先级是6的帧数

            RxPFCPriority7Frames：接收PFC优先级是7的帧数

            TxPFCFrames：发送PFC帧数

            TxPFCRate：发送PFC速率

            TxPFCPriority0Frames：发送PFC优先级是0的帧数

            TxPFCPriority1Frames：发送PFC优先级是1的帧数

            TxPFCPriority2Frames：发送PFC优先级是2的帧数

            TxPFCPriority3Frames：发送PFC优先级是3的帧数

            TxPFCPriority4Frames：发送PFC优先级是4的帧数

            TxPFCPriority5Frames：发送PFC优先级是5的帧数

            TxPFCPriority6Frames：发送PFC优先级是6的帧数

            TxPFCPriority7Frames：发送PFC优先级是7的帧数

            RxARPFrames：接收ARP报文数

            TxARPFrames：发送ARP报文数

            RxBroadcastFrames：接收广播报文数

            TxBroadcastFrames：发送广播报文数

            RxIpv4LengthErrorFrames：接收IPv4长度错误帧数

            RxUserDefinedCapture0Frames：接收自定义统计0报文数

            RxUserDefinedCapture0Rate：接收自定义统计0报文速率(fps)

            RxUserDefinedCapture1Frames：接收自定义统计1报文数

            RxUserDefinedCapture1Rate：接收自定义统计1报文速率(fps)

            RxUserDefinedCapture2Frames：接收自定义统计2报文数

            RxUserDefinedCapture2Rate：接收自定义统计2报文速率(fps)

            RxUserDefinedCapture3Frames：接收自定义统计3报文数

            RxUserDefinedCapture3Rate：接收自定义统计3报文速率(fps)

            RxUserDefinedCapture4Frames：接收自定义统计4报文数

            RxUserDefinedCapture4Rate：接收自定义统计4报文速率(fps)

            RxUserDefinedCapture5Frames：接收自定义统计5报文数

            RxUserDefinedCapture5Rate：接收自定义统计5报文速率(fps)

            RxFirstFrameArrivalTime：接收第一个帧的时间

            RxLastFrameArrivalTime：接收最后一个帧的时间

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/

            eg::

                {
                    'RxFirstFrameArrivalTime': 1000,
                    'RxLastFrameArrivalTime': 1000,
                }

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | TxTotalFrames | RxTotalFrames |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Port} | Get Ports |
        | &{Result} | Get Port Statistic | Port=${Port} | StaItems=@{StaItems} |
        | ${DataFrame} | Get Port Statistic | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_port_statistic(Port=Port, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_port_latency_statistic(Port=None, StaItems=None, Mode=True):
    """
    获取测试仪表端口时延统计结果

    Args:

        Port (:obj:`Port`): 指定需要获取结果的端口对象object

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取端口统计项目, 目前支持的统计项

            PortID：端口名称

            MinLatency：最小时延

            MaxLatency：最大时延

            AvaLatency：平均时延

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/

            eg::

                {
                    'MinLatency': 1.2311,
                    'MaxLatency': 5.123,
                }

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | MinLatency | MaxLatency |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Port} | Get Ports |
        | &{Result} | Get Port Latency Statistic | Port=${Port} | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_port_latency_statistic(Port=Port, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_streamblock_statistic(Stream=None, StaItems=None, Mode=True):
    """
    获取测试仪表流模板块统计结果

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取流模板统计项目, 目前支持的统计项: 需要获取流模板统计项目

            TxPortID：发送端口

            RxPortID：接收端口

            TxStreamFrames：发送带标签流报文总数

            RxStreamFrames：接收带标签流报文总数

            TxFrameRate：发送报文速率(fps)

            RxFrameRate：接收报文速率(fps)

            TxL1Rate：发送线速(bps)

            RxL1Rate：接收线速(bps)

            TxUtil：发送百分比(%)

            RxUtil：接收百分比(%)

            RxLossStreamFrames：实时丢包数

            RealtimeLossRate：实时丢包率(%)

            ResumeTime：恢复时间(s)

            StartTime：流启动时间

            MinLatency：最小延迟(us)

            MaxLatency：最大延迟(us)

            AvaLatency：平均延迟(us)

            MinJitter：最小延迟抖动(us)

            MaxJitter：最大延迟抖动(us)

            AvaJitter：平均延迟抖动(us)

            TxByteRate：发送字节速率(Bps)

            RxByteRate：接收字节速率(Bps)

            TxBitRate：发送比特速率(bps)

            RxBitRate：接收比特速率(bps)

            TxTotalBytes：发送字节总数

            RxTotalBytes：接收字节总数

            RxPayloadErr：接收Payload Error报文数

            RxInSequenceCount：接收Sequence Error报文数

            RxFCSErr：接收FCS错误数

            RxIpv4ChecksumError：接收IPv4 Checksum Error报文数

            RxTcpChecksumError：接收TCP Checksum Error报文数

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/
            eg::

                {"TxTotalFrames": 1000, "RxTotalFrames": 1000}

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | MinLatency | RxIpv4ChecksumError |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Stream} | Get Streams |
        | &{Result} | Get Streamblock Statistic | Stream=${Stream} | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_streamblock_statistic(Stream=Stream, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_streamblock_tx_statistic(Stream=None, Port=None, StaItems=None, Mode=True):
    """
    获取测试仪表流模板块统计结果

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Port (:obj:`Port`): 发送端口对象object, 类型为：object

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取流模板统计项目, 目前支持的统计项: 需要获取流模板统计项目

            StreamBlockID

            PortID

            ChannelCount

            TxStreamFrames：发送报文数

            TxFrameRate：发送报文速率(fps)

            TxByteRate：发送字节速率(Bps)

            TxBitRate：发送比特速率(bps)

            TxL1Rate：发送线速(bps)

            TxUtil：发送百分比(%)

            TxTotalBytes：发送字节数

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/
            eg::

                {"TxUtil": 1000, "TxTotalBytes": 1000}

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | MinLatency | RxIpv4ChecksumError |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Stream} | Get Streams |
        | &{Result} | Get Streamblock Tx Statistic | Stream=${Stream} | Port=${Port} | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_streamblock_tx_statistic(Stream=Stream, Port=Port, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_streamblock_rx_statistic(Stream=None, Port=None, StaItems=None, Mode=True):
    """
    获取测试仪表流模板块统计结果

    Args:

        Stream (:obj:`StreamTemplate`): 测试仪表流量对象object, 类型为：object

        Port (:obj:`Port`): 接收端口对象object, 类型为：object

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取流模板统计项目, 目前支持的统计项: 需要获取流模板统计项目

            StreamBlockID

            PortID

            LoadBalance

            RxStreamFrames：接收报文数

            RxFrameRate：接收报文速率(fps)

            RxByteRate：接收字节速率(Bps)

            RxSeqErr

            RxPayloadErr

            MinLatency：最小时延(us)

            MaxLatency：最大时延(us)

            AvaLatency：平均时延(us)

            ShortTermAvgLatency：短期平均时延(us)

            RxBitRate：接收比特速率(bps)

            RxUtil：接收线速(bps)

            MinJitter：最小延迟抖动(us)

            MaxJitter：最大延迟抖动(us)

            AvaJitter：平均延迟抖动(us)

            ShortTermAvgJitter：短期平均延迟抖动(us)

            RxLossStreamFrames

            RxIpLengthErrorCount

            RxL1Rate

            RxIpv4ChecksumErrorFrames：接收IPv4 Checksum Error报文数

            PrbsFillBytes：接收PRBS填充字节

            DuplicateFrames：接收重复帧

            InOrderFrames：接收有序帧

            ReOrderFrames：接收重排序帧

            PrbsErrorBits：接收PRBS错误位数

            PrbsErrorFrames：接收PRBS错误帧数

            RxFcsErrorFrames：接收FCS错误帧

            RxFcsErrorFrameRate：接收FCS错误帧速率(fps)

            TcpChecksumErrorFrames：接收TCP/UDP校验错误帧

            RxAvgRate

            RxAvgFps

            RxMaxRate

            RxMaxFps

            RxTotalBytes：接收总字节数

            RxLateCount：接收延迟计数

            RxInSequenceCount：接收按顺序计数

            RxOutofSequenceCount：接收未按顺序计数

            RxMinInterArrivalTime：接收最小到达时间(us)

            RxMaxInterArrivalTime：接收最大到达时间(us)

            RxAvgInterArrivalTime：接收平均到达时间(us)

            RxShortTermAvgInterArrivalTime：接收短期平均到达时间(us)

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/
            eg::

                {"TxUtil": 1000, "TxTotalBytes": 1000}

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | MinLatency | RxIpv4ChecksumError |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Stream} | Get Streams |
        | &{Result} | Get Streamblock Rx Statistic | Stream=${Stream} | Port=${Port} | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_streamblock_rx_statistic(Stream=Stream, Port=Port, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_stream_statistic(Stream=None, StreamID=None, StaItems=None, Mode=True):
    """
    获取测试仪表流模板统计结果

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        StreamID (int): 指定需要获取结果的流模板中流的Id, 默认值：None, 范围: 1-4294967295

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取流模板统计项目, 目前支持的统计项: 需要获取流模板统计项目

            StreamBlockID：流量模板名称

            StreamID：流量ID

            TxPortID：发送端口

            RxPortID：接收端口

            LoadBalance：接收端口

            TxStreamFrames：发送报文数

            RxStreamFrames：接收报文数

            TxFrameRate：发送报文速率(fps)

            RxFrameRate：接收报文速率(fps)

            TxL1Rate：发送线速(bps)

            RxL1Rate：接收线速(bps)

            RxLossStreamFrames：实时丢包数

            RealtimeLossRate：实时丢包率(%)

            ResumeTime：恢复时间(s)

            StartTime：流启动时间

            TxUtil：发送百分比(%)

            RxUtil：接收百分比(%)

            RxPayloadErr：接收Payload Error报文数

            RxSeqErr：接收Sequence Error报文数

            RxIpLengthErrorCount：接收IP长度错误计数

            TxByteRate：发送字节速率(Bps)

            RxByteRate：接收字节速率(Bps)

            TxBitRate：发送比特速率(bps)

            RxBitRate：接收比特速率(bps)

            MinLatency：最小延迟(us)

            MaxLatency：最大延迟(us)

            AvaLatency：平均延迟抖动(us)

            MinJitter：最小延迟抖动(us)

            MaxJitter：最大延迟抖动(us)

            AvaJitter：平均延迟抖动(us)

            RxIpv4ChecksumErrorFrames：接收Ipv4 Checksum错误

            PrbsFillBytes：接收端口

            DuplicateFrames：接收端口

            InOrderFrames：接收端口

            ReOrderFrames：接收端口

            PrbsErrorBits：接收端口

            PrbsErrorFrames：接收端口

            RxFcsErrorFrames：接收FCS Checksum错误

            RxFcsErrorFrameRate：接收FCS Checksum错误速率

            TcpChecksumErrorFrames：接收TCP Checksum错误

            LostStreamFrames：丢包数

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/
            eg::

                {"RxFcsErrorFrames": 1000, "LostStreamFrames": 1000}

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | MinLatency | RxIpv4ChecksumError |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Stream} | Get Streams |
        | &{Result} | Get Stream Statistic | Stream=${Stream} | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_stream_statistic(Stream=Stream, StreamID=StreamID, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_stream_tx_statistic(Stream=None, Port=None, StreamID=None, StaItems=None, Mode=True):
    """
    获取测试仪表流模板统计结果

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Port (:obj:`Port`): 发送端口对象object, 类型为：object

        StreamID (int): 指定需要获取结果的流模板中流的Id, 默认值：None, 范围: 1-4294967295

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取流模板统计项目, 目前支持的统计项: 需要获取流模板统计项目

            StreamID

            StreamBlockID

            ChannelId

            PortID

            TxStreamFrames：发送报文数

            TxFrameRate：发送报文速率(fps)

            TxByteRate：发送字节速率(Bps)

            TxBitRate：发送比特速率(bps)

            TxL1Rate：发送线速(bps)

            TxUtil：发送百分比(%)

            TxTotalBytes：发送总字节数

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/
            eg::

                {"TxL1Rate": 1000, "TxTotalBytes": 1000}

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | TxUtil | TxTotalBytes |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Stream} | Get Streams |
        | &{Result} | Get Stream Tx Statistic | Stream=${Stream} | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_stream_tx_statistic(Stream=Stream, Port=Port, StreamID=StreamID, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_stream_rx_statistic(Stream=None, Port=None, StreamID=None, StaItems=None, Mode=True):
    """
    获取测试仪表流模板统计结果

    Args:

        Stream (:obj:`StreamTemplate`):: 测试仪表流量对象object, 类型为：object

        Port (:obj:`Port`): 接收端口对象object, 类型为：object

        StreamID (int): 指定需要获取结果的流模板中流的Id, 默认值：None, 范围: 1-4294967295

        Mode (bool): 是否从仪表后台读取统计, 默认: True

        StaItems (list): 需要获取流模板统计项目, 目前支持的统计项: 需要获取流模板统计项目

            StreamID

            StreamBlockID

            ChannelId

            PortID

            LoadBalance

            RxStreamFrames：接收报文数

            RxFrameRate：接收报文速率(fps)

            RxByteRate：接收字节速率(Bps)

            RxSeqErr

            RxPayloadErr

            MinLatency：最小时延(us)

            MaxLatency：最大时延(us)

            AvaLatency：平均时延(us)

            ShortTermAvgLatency：短期平均时延(us)

            RxBitRate：接收比特速率(bps)

            RxUtil：接收百分比(%)

            MinJitter：最小延迟抖动(us)

            MaxJitter：最大延迟抖动(us)

            AvaJitter：平均延迟抖动(us)

            ShortTermAvgJitter：短期平均延迟抖动(us)

            RxLossStreamFrames：实时丢包数

            RxIpLengthErrorCount

            RxIpv4ChecksumErrorFrames：接收IPv4 Checksum Error报文数

            PrbsFillBytes：接收PRBS填充字节

            DuplicateFrames：接收重复帧

            InOrderFrames：接收有序帧

            ReOrderFrames：接收重排序帧

            PrbsErrorBits：接收PRBS错误位数

            PrbsErrorFrames：接收PRBS错误帧数

            RxFcsErrorFrames：接收FCS错误帧

            RxFcsErrorFrameRate：接收FCS错误帧速率(fps)

            TcpChecksumErrorFrames：接收TCP/UDP校验错误帧

            RxL1Rate：接收线速(bps)

            RxTotalBytes：接收总字节数

            RxLateCount：接收延迟计数

            RxInSequenceCount：接收按顺序计数

            RxOutofSequenceCount：接收未按顺序计数

            RxMinInterArrivalTime：接收最小到达时间(us)

            RxMaxInterArrivalTime：接收最大到达时间(us)

            RxAvgInterArrivalTime：接收平均到达时间(us)

            RxShortTermAvgInterArrivalTime：接收短期平均到达时间(us)

    Returns:

        dict or (:obj:`DataFrame`): 数据返回基本原则，当获取到单行数据时返回dict类型数据，当获取到多行数据时返回Pandas的(:obj:`DataFrame`)数据，Pandas详细请参考: https://www.pypandas.cn/
            eg::

                {"RxAvgInterArrivalTime": 1000, "RxShortTermAvgInterArrivalTime": 1000}

    Examples:
        robotframework:

    .. code:: robotframework

        | @{StaItems} | Create List | RxAvgInterArrivalTime | RxShortTermAvgInterArrivalTime |
        | Subscribe Result |
        | Start Stream |
        | Sleep | 10 |
        | Stop Stream |
        | Sleep | 3 |
        | ${Stream} | Get Streams |
        | &{Result} | Get Stream Rx Statistic | Stream=${Stream} | StaItems=@{StaItems} |
        | Clear Result |
    """

    result = renix.get_stream_rx_statistic(Stream=Stream, Port=Port, StreamID=StreamID, StaItems=StaItems, Mode=Mode)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

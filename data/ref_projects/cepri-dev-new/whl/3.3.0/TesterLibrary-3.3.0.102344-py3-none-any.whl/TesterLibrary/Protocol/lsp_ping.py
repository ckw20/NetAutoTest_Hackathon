import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------client-------------------------------------
def create_lsp_ping(Port, **kwargs):
    """
    创建Lsp Ping会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): Lsp Ping会话名称, 类型为：string

        Enable (bool): 使能Lsp Ping会话, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`LspPing`): Lsp Ping会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Lsp Ping | Port=${Port} |
    """

    result = renix.create_lsp_ping(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_lsp_ping_echo_request(Sessions, **kwargs):
    """
    创建Lsp Ping Echo Request对象

    Args：

        Session (:obj:`LspPing`): Lsp Ping会话对象, 类型为：object / list

    Keyword Args:

        OperationMode (list): Operation模式, 默认值：['PING'], 取值范围：

            PING

            TRACE

        ReplyMode (str): Echo Reply模式, 默认值：REPLYVIAUDP, 取值范围：

            NOTREPLY

            REPLYVIAUDP

        PingInterval (int): Ping发送测试包的时间间隔（秒）, 默认值：4, 取值范围：1-65535

        PingTimeOut (int): Ping探测超时时间（秒）, 默认值：2, 取值范围：1-60

        TraceInterval (int): Trace发送测试包的时间间隔（秒）, 默认值：120, 取值范围：1-65535

        TraceTimeOut (int): Trace探测超时时间（秒）, 默认值：2, 取值范围：1-60

        InnerLabel (str): 标签, 默认值：NONE, 取值范围：

            NONE

            LDPIPv4

            VPNIPv4

            SEGMENT_ROUTING

        OuterLabel (str): 标签, 默认值：NONE, 取值范围：

            NONE

            LDPIPv4

            VPNIPv4

            SEGMENT_ROUTING

        TimeToLive (int): 生存时间, 默认值：255, 取值范围：1-255

        ExpBits (int): 实验比特位的值, 默认值：0, 取值范围：0-7

        PadMode (str): 填充模式, 默认值：WITHOUT_PAD, 取值范围：

            WITHOUT_PAD

            DROP_PAD

            COPY_PAD

        Data (int): 填充数据, 默认值：'', 取值范围：0-255

        DesIpv4Addr (str): 目的地址, 默认值："127.0.0.1"，取值范围：有效的ipv4地址

        ValidateFecStack (bool): 校验FEC Stack, 默认值：False, 取值范围：True或False

        DownstreamMappingTlvType (str): Downstream Mapping TLV类型, 默认值：DOWNSTREAM_DETAILED_MAPPING_TLV, 取值范围：

            DOWNSTREAM_MAPPING_TLV

            DOWNSTREAM_DETAILED_MAPPING_TLV

    Returns:

        (:obj:`LspPingEchoRequestConfig`): Lsp Ping Echo Request对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${LspPing} | Create Lsp Ping | Port=${Port} |
            | Create Lsp Ping Echo Request | Sessions=${LspPing} |
    """

    result = renix.create_lsp_ping_echo_request(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_lsp_ping_fec_ldp_ipv4(EchoRequests, **kwargs):
    """
    创建Lsp Ping Fec Ldp Ipv4对象

    Args：

        EchoRequests (:obj:`LspPingEchoRequestConfig`): Lsp Ping Echo Request对象, 类型为：object / list

    Keyword Args:

        Count (int): 数量, 默认值：1, 取值范围：1-65535

        StartAddr (str): IPv4地址, 默认值："172.0.0.1"，取值范围：有效的ipv4地址

        PrefixLength (int): 前缀长度, 默认值：24, 取值范围：1-32

        Step (int): 步长, 默认值：1, 取值范围：1-255

    Returns:

        (:obj:`LspPingFecLdpIpv4PrefixConfig`): Lsp Ping Fec Ldp Ipv4对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${LspPing} | Create Lsp Ping | Port=${Port} |
            | ${EchoRequest} | Create Lsp Ping Echo Request | Sessions=${LspPing} |
            | Create Lsp Ping Fec Ldp Ipv4 | EchoRequests=${EchoRequest} |
    """

    result = renix.create_lsp_ping_fec_ldp_ipv4(EchoRequests=EchoRequests, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_lsp_ping_fec_vpn_ipv4(EchoRequests, **kwargs):
    """
    创建Lsp Ping Fec Vpn Ipv4对象

    Args：

        EchoRequests (:obj:`LspPingEchoRequestConfig`): Lsp Ping Echo Request对象, 类型为：object / list

    Keyword Args:

        Count (int): 数量, 默认值：1, 取值范围：1-65535

        StartAddr (str): IPv4地址, 默认值："172.0.0.1"，取值范围：有效的ipv4地址

        PrefixLength (int): 前缀长度, 默认值：24, 取值范围：1-32

        Step (int): 步长, 默认值：1, 取值范围：1-255

        RouteDistinguisher (str): 路由标识, 默认值："100:1", 取值范围：匹配格式"uint16:uint32 | ipv4:uint16 | uint32:uint16 | uint16.uint16:uint16"

    Returns:

        (:obj:`LspPingFecVPNIpv4PrefixConfig`): Lsp Ping Fec Vpn Ipv4对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${LspPing} | Create Lsp Ping | Port=${Port} |
            | ${EchoRequest} | Create Lsp Ping Echo Request | Sessions=${LspPing} |
            | Create Lsp Ping Fec Vpn Ipv4 | EchoRequests=${EchoRequest} |
    """

    result = renix.create_lsp_ping_fec_vpn_ipv4(EchoRequests=EchoRequests, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_lsp_ping_fec_segment_routing(EchoRequests, **kwargs):
    """
    创建Lsp Ping Fec Segment Routing对象

    Args：

        EchoRequests (:obj:`LspPingEchoRequestConfig`): Lsp Ping Echo Request对象, 类型为：object / list

    Keyword Args:

        IgpProtocol (str): FEC校验使用的IGP协议, 默认值：ISIS, 取值范围：

            OSPF

            ISIS

        PrefixCount (int): 前缀数量, 默认值：1, 取值范围：1-4294967295

        PrefixAddrIncrement (int): 地址步长, 默认值：1, 取值范围：1-4294967295

    Returns:

        (:obj:`LspPingFecSrConfig`): Lsp Ping Fec Segment Routing对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${LspPing} | Create Lsp Ping | Port=${Port} |
            | ${EchoRequest} | Create Lsp Ping Echo Request | Sessions=${LspPing} |
            | Create Lsp Ping Fec Segment Routing | EchoRequests=${EchoRequest} |
    """

    result = renix.create_lsp_ping_fec_segment_routing(EchoRequests=EchoRequests, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_lsp_ping_fec_sr_prefix(Srs, **kwargs):
    """
    创建Lsp Ping Fec Sr Prefix对象

    Args：

        Srs (:obj:`LspPingFecSrConfig`): Lsp Ping Fec Segment Routing对象, 类型为：object / list

    Keyword Args:

        Prefix (str): 前缀地址, 默认值："192.0.0.1"，取值范围：有效的ipv4地址

        Length (int): 前缀地址长度, 默认值：24, 取值范围：1-32

        Algorithm (int): 算法, 默认值：0, 取值范围：uint8

    Returns:

        (:obj:`LspPingFecSrDetailConfig`): Lsp Ping Fec Sr Detail对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${LspPing} | Create Lsp Ping | Port=${Port} |
            | ${EchoRequest} | Create Lsp Ping Echo Request | Sessions=${LspPing} |
            | ${Sr} | Create Lsp Ping Fec Segment Routing | EchoRequests=${EchoRequest} |
            | Create Lsp Ping Fec Sr Prefix | Srs=${Sr} |
    """

    result = renix.create_lsp_ping_fec_sr_prefix(Srs=Srs, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_lsp_ping_fec_sr_adjacency(Srs, **kwargs):
    """
    创建Lsp Ping Fec Sr Adjacency对象

    Args：

        Srs (:obj:`LspPingFecSrConfig`): Lsp Ping Fec Segment Routing对象, 类型为：object / list

    Keyword Args:

        IsisSystemId (str): ISIS系统ID, 默认值："00:00:94:00:00:01"，取值范围：有效的mac地址

        IsisLanSystemId (str): ISIS LAN系统ID, 默认值："00:00:00:00:00:00"，取值范围：有效的mac地址

        IsisNeighborId (str): ISIS邻居ID, 默认值："00:00:94:00:00:01"，取值范围：有效的mac地址

        IsisNodeId (int): ISIS节点ID, 默认值：0, 取值范围：uint8

        OspfLinkType (str): OSPF链路类型, 默认值：P2P, 取值范围：

            P2P

            TRANSITNETWORK

            STUBNETWORK

            VIRTUALLINK

        OspfLinkId (str): OSPF链路ID, 默认值："0.0.0.0"，取值范围：有效的ipv4地址

        OspfLinkData (str): OSPF链路数据, 默认值："0.0.0.0"，取值范围：有效的ipv4地址

        LocalRouterId (str): 本地路由器ID, 默认值："192.168.1.1"，取值范围：有效的ipv4地址

        RemoteRouterId (str): 远端路由器ID, 默认值："192.168.1.1"，取值范围：有效的ipv4地址

        LocalInterfaceId (str): 本地接口ID, 默认值："0.0.0.0"，取值范围：有效的ipv4地址

        RemoteInterfaceId (str): 远端接口ID, 默认值："0.0.0.0"，取值范围：有效的ipv4地址

    Returns:

        (:obj:`LspPingFecSrDetailConfig`): Lsp Ping Fec Sr Detail对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${LspPing} | Create Lsp Ping | Port=${Port} |
            | ${EchoRequest} | Create Lsp Ping Echo Request | Sessions=${LspPing} |
            | ${Sr} | Create Lsp Ping Fec Segment Routing | EchoRequests=${EchoRequest} |
            | Create Lsp Ping Fec Sr Ajacency | Srs=${Sr} |
    """

    result = renix.create_lsp_ping_fec_sr_adjacency(Srs=Srs, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_lsp_ping_port_config(Ports, **kwargs):
    """
    修改Lsp Ping端口配置对象

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        UpdateTransmitRate (int): 默认值：1000, 取值范围：1-10000

        FrequencyPing (int): 执行Ping测试时间间隔（秒）, 默认值：60, 取值范围：1-2147483647

        FrequencyTrace (int): 执行Trace测试时间间隔（秒）, 默认值：60, 取值范围：60-2147483647

    Returns:

        (:obj:`LspPingPortConfig`): Lsp Ping协议端口对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Lsp Ping Port Config | Ports=${Port} | FrequencyTrace=10 |
    """

    result = renix.edit_lsp_ping_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_lsp_ping(Sessions):
    """
    开始发送LSP Ping消息

    Args:

        Sessions (:obj:`LspPing`): LspPing会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Lsp Ping | Sessions=${Sessions} |
    """

    result = renix.start_lsp_ping(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_lsp_ping(Sessions):
    """
    停止发送LSP Ping消息

    Args:

        Sessions (:obj:`LspPing`): LspPing会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Lsp Ping | Sessions=${Sessions} |
    """

    result = renix.stop_lsp_ping(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pause_lsp_ping(Sessions):
    """
    暂停发送LSP Ping消息

    Args:

        Sessions (:obj:`LspPing`): LspPing会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pause Lsp Ping | Sessions=${Sessions} |
    """

    result = renix.pause_lsp_ping(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def resume_lsp_ping(Sessions):
    """
    继续发送LSP Ping消息

    Args:

        Sessions (:obj:`LspPing`): LspPing会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Resume Lsp Ping | Sessions=${Sessions} |
    """

    result = renix.resume_lsp_ping(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pause_lsp_trace(Sessions):
    """
    暂停发送LSP Trace消息

    Args:

        Sessions (:obj:`LspPing`): LspPing会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pause Lsp Trace | Sessions=${Sessions} |
    """

    result = renix.pause_lsp_trace(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def resume_lsp_trace(Sessions):
    """
    继续发送LSP Trace消息

    Args:

        Sessions (:obj:`LspPing`): LspPing会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Resume Lsp Trace | Sessions=${Sessions} |
    """

    result = renix.resume_lsp_trace(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_lsp_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待Lsp Ping会话达到指定状态

    Args:

        Session (:obj:`LspPing`): Lsp Ping会话对象, 类型为：object / list

        State (list): 等待Lsp Ping会话组达到的状态, 类型为：string, 默认值：UP, 支持下列状态：

            DISABLE

            NOTSTART

            UP

            DOWN

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Lsp State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_lsp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_lsp_ping_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待Lsp Ping会话的Ping消息达到指定状态

    Args:

        Session (:obj:`LspPing`): Lsp Ping会话对象, 类型为：object / list

        State (list): 等待Lsp Ping会话组的Ping消息达到的状态, 类型为：string, 默认值：PAUSE_SEND, 支持下列状态：

            IDLE

            PAUSE_SEND

            RESUME_SEND

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Lsp Ping State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_lsp_ping_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_lsp_trace_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待Lsp Ping会话的Trace消息达到指定状态

    Args:

        Session (:obj:`LspPing`): Lsp Ping会话对象, 类型为：object / list

        State (list): 等待Lsp Ping会话组的Trace消息达到的状态, 类型为：string, 默认值：PAUSE_SEND, 支持下列状态：

            IDLE

            PAUSE_SEND

            RESUME_SEND

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Lsp Trace State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_lsp_trace_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def get_lsp_ping_session_statistic(Session=None, StaItems: list = None):
    """
    获取Dhcpv6 Port Statistic统计结果

    Args:

        Session (:obj:`LspPing`): Lsp Ping会话对象, 类型为：object / list

        StaItems (list): 需要获取的统计项目，类型为：list，目前支持的统计项

            TxEchoRequest

            RxEchoRequest

            TxEchoReply

            RxEchoReply

    Returns:

        dict: eg::

            {
                'TxEchoReply': 10,
                'RxEchoReply': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=LspPingSessionStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Lsp Ping Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_lsp_ping_session_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_lsp_ping_echo_request_statistic(Session=None, EchoRequest=None, StaItems: list = None):
    """
    获取Dhcpv6 Port Statistic统计结果

    Args:

        Session (:obj:`LspPing`): Lsp Ping会话对象, 类型为：object

        EchoRequest (:obj:`LspPingEchoRequestConfig`): Lsp Ping Echo Request对象, 类型为：object

        StaItems (list): 需要获取的统计项目，类型为：list，目前支持的统计项

            FailCount

            SuccessCount

            FecInfo

            MaxPingLatency

            AvgPingLatency

            MinPingLatency

            RxReturnCode

    Returns:

        dict: eg::

            {
                'MinPingLatency': 10,
                'RxReturnCode': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=LspPingEchoRequestStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Lsp Ping Echo Request Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_lsp_ping_echo_request_statistic(Session=Session, EchoRequest=EchoRequest, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_lsp_trace_echo_request_statistic(Session=None, EchoRequest=None, StaItems: list = None):
    """
    获取Dhcpv6 Port Statistic统计结果

    Args:

        Session (:obj:`LspPing`): Lsp Ping会话对象, 类型为：object

        EchoRequest (:obj:`LspPingEchoRequestConfig`): Lsp Ping Echo Request对象, 类型为：object

        StaItems (list): 需要获取的统计项目，类型为：list，目前支持的统计项

            FailCount

            SuccessCount

            FecInfo

            MaxPingLatency

            AvgPingLatency

            MinPingLatency

            RxReturnCode

    Returns:

        dict: eg::

            {
                'MinPingLatency': 10,
                'RxReturnCode': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=LspPingEchoRequestStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Lsp Trace Echo Request Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_lsp_trace_echo_request_statistic(Session=Session, EchoRequest=EchoRequest, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result






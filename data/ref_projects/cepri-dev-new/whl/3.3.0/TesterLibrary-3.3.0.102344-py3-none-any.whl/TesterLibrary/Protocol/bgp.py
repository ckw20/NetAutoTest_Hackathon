import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------BGP-------------------------------------
def create_bgp(Port, **kwargs):
    """
    创建BGP协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): BGP协会话名称, 类型为：string

        Enable (bool): 使能BGP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        IpVersion (str): IP版本, 类型为：string, 默认值：BOTH, 支持版本：

            BOTH

            IPV4

            IPV6

        BgpInitiator (bool): BGP会话发起者, 类型为：bool, 取值范围：True或False, 默认值：True

        AsNumber (int): 自治域, 类型为：number, 取值范围：1-65535, 默认值：1

        AsNumberStep (int): 自治域跳变, 类型为：number, 取值范围：0-65535, 默认值：1

        Enable4ByteAs (bool): 使能4字节自治域, 类型为：bool, 取值范围：True或False, 默认值：False

        AsNumber4Byte (int): 4字节自治域, 类型为：number, 取值范围：0.1-65535.65535, 默认值：1.1

        AsNumber4ByteStep (int): 4字节自治域跳变, 类型为：number, 取值范围：0.1-65535.65535, 默认值：0.1

        DutAsNumber (int): DUT自治域, 类型为：number, 取值范围：1-65535, 默认值：1

        DutAsNumberStep (int): DUT自治域跳变, 类型为：number, 取值范围：1-65535, 默认值：1

        Enable4ByteDutAs (bool): 使能DUT4字节自治域, 类型为：bool, 取值范围：True或False, 默认值：False

        Dut4ByteAsNumber (int): DUT4字节自治域, 类型为：number, 取值范围：0.1-65535.65535, 默认值：1.1

        Dut4ByteAsNumberStep (int): DUT4字节自治域跳变, 类型为：number, 取值范围：0.1-65535.65535, 默认值：0.1

        BgpType (str): BGP类型, 类型为：string, 取值范围：EBGP, IBGP, 默认值：IBGP

        UseGatewayAsDutIp (bool): 使用网关地址作为DUT地址, 类型为：bool, 取值范围：True或False, 默认值：True

        BgpSessionIpAddressType (str): 会话IP类型, 类型为：string, 取值范围：INTERFACE_IP, ROUTE_ID, 默认值：INTERFACE_IP

        DutIpv4Address (str): DUT IPv4地址, 当IP版本为IPv4，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID, 类型为：string, 取值范围：IPv4地址, 默认值：2.1.1.1

        DutIpv4AddressStep (str): DUT IPv4地址跳变, 当IP版本为IPv4，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID增量步长, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.0.1

        DutIpv6Address (str): DUT IPv4地址, 当IP版本为IPv6，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        DutIpv6AddressStep (str): DUT IPv4地址跳变, 当IP版本为IPv6，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID增量步长, 类型为：string, 取值范围：IPv6地址, 默认值：::1

        HoldTime (int): Hold Time间隔 (sec), 类型为：number, 取值范围：3-65535, 默认值：90

        KeepaliveTime (int): Keep Alive间隔 (sec), 类型为：number, 取值范围：1-65535, 默认值：30

        ConnectRetryCount (int): 重连次数, 取值范围：0-65535, 默认值：0

        ConnectRetryInterval (int): 重连间隔 (sec), 取值范围：10-300, 默认值：30

        MaxRoutesPerUpdateMessage (int): Update报文中最大路由数量, 取值范围：10-300, 默认值：2000

        RouteRefreshMode (str): Route Refresh模式, 类型为：string, 取值范围：None; Route Refresh, 默认值：None

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        RestartTime (int): 平滑重启时间（秒）, 取值范围：3-4095, 默认值：90

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        Authentication (str): 使用的认证类型, 类型为：string, 取值范围：None或MD5, 默认值：None

        Password (str): 认证密码, 类型为：类型为：string, 取值范围：字符串，由1-255个数字、字母或特殊字符组成, 默认值：xinertel

        EnableBfd (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableSr (bool): 使能SR, 类型为：bool, 取值范围：True或False, 默认值：False

        MiniLabel (int): 最小标签, 取值范围：0-1048575, 默认值：16

        EnableExMsg (bool): 使能扩展消息, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableCustomize (bool): 使能Customize, 类型为：bool, 取值范围：True或False, 默认值：False

        AfiSubAfi (str): Afi/SubAfi, 类型为：类型为：string, 默认值：""

        EnableParseRxUpdateMsg (bool): 使能ParseRxUpdateMsg, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`BgpRouter`): BGP协议会话对, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Bgp | Port=${Port} |
    """

    result = renix.create_bgp(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_bgp(Session, **kwargs):
    """
    编辑Bgp协议会话对象参数

    Args:

        Session (:obj:`BgpRouter`): Bgp协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BGP协会话名称, 类型为：string

        Enable (bool): 使能BGP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        IpVersion (str): IP版本, 类型为：string, 默认值：BOTH, 支持版本：

            BOTH

            IPV4

            IPV6

        BgpInitiator (bool): BGP会话发起者, 类型为：bool, 取值范围：True或False, 默认值：True

        AsNumber (int): 自治域, 类型为：number, 取值范围：1-65535, 默认值：1

        AsNumberStep (int): 自治域跳变, 类型为：number, 取值范围：0-65535, 默认值：1

        Enable4ByteAs (bool): 使能4字节自治域, 类型为：bool, 取值范围：True或False, 默认值：False

        AsNumber4Byte (int): 4字节自治域, 类型为：number, 取值范围：0.1-65535.65535, 默认值：1.1

        AsNumber4ByteStep (int): 4字节自治域跳变, 类型为：number, 取值范围：0.1-65535.65535, 默认值：0.1

        DutAsNumber (int): DUT自治域, 类型为：number, 取值范围：1-65535, 默认值：1

        DutAsNumberStep (int): DUT自治域跳变, 类型为：number, 取值范围：1-65535, 默认值：1

        Enable4ByteDutAs (bool): 使能DUT4字节自治域, 类型为：bool, 取值范围：True或False, 默认值：False

        Dut4ByteAsNumber (int): DUT4字节自治域, 类型为：number, 取值范围：0.1-65535.65535, 默认值：1.1

        Dut4ByteAsNumberStep (int): DUT4字节自治域跳变, 类型为：number, 取值范围：0.1-65535.65535, 默认值：0.1

        BgpType (str): BGP类型, 类型为：string, 取值范围：EBGP, IBGP, 默认值：IBGP

        UseGatewayAsDutIp (bool): 使用网关地址作为DUT地址, 类型为：bool, 取值范围：True或False, 默认值：True

        BgpSessionIpAddressType (str): 会话IP类型, 类型为：string, 取值范围：INTERFACE_IP, ROUTE_ID, 默认值：INTERFACE_IP

        DutIpv4Address (str): DUT IPv4地址, 当IP版本为IPv4，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID, 类型为：string, 取值范围：IPv4地址, 默认值：2.1.1.1

        DutIpv4AddressStep (str): DUT IPv4地址跳变, 当IP版本为IPv4，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID增量步长, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.0.1

        DutIpv6Address (str): DUT IPv4地址, 当IP版本为IPv6，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        DutIpv6AddressStep (str): DUT IPv4地址跳变, 当IP版本为IPv6，并且使用网关地址作为DUT地址未选中时，需配置该选项指定DUT的Router ID增量步长, 类型为：string, 取值范围：IPv6地址, 默认值：::1

        HoldTime (int): Hold Time间隔 (sec), 类型为：number, 取值范围：3-65535, 默认值：90

        KeepaliveTime (int): Keep Alive间隔 (sec), 类型为：number, 取值范围：1-65535, 默认值：30

        ConnectRetryCount (int): 重连次数, 取值范围：0-65535, 默认值：0

        ConnectRetryInterval (int): 重连间隔 (sec), 取值范围：10-300, 默认值：30

        MaxRoutesPerUpdateMessage (int): Update报文中最大路由数量, 取值范围：10-300, 默认值：2000

        RouteRefreshMode (str): Route Refresh模式, 类型为：string, 取值范围：None; Route Refresh, 默认值：None

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        RestartTime (int): 平滑重启时间（秒）, 取值范围：3-4095, 默认值：90

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        Authentication (str): 使用的认证类型, 类型为：string, 取值范围：None或MD5, 默认值：None

        Password (str): 认证密码, 类型为：类型为：string, 取值范围：字符串，由1-255个数字、字母或特殊字符组成, 默认值：xinertel

        EnableBfd (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableSr (bool): 使能SR, 类型为：bool, 取值范围：True或False, 默认值：False

        MiniLabel (int): 最小标签, 取值范围：0-1048575, 默认值：16

        EnableExMsg (bool): 使能扩展消息, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableCustomize (bool): 使能Customize, 类型为：bool, 取值范围：True或False, 默认值：False

        AfiSubAfi (str): Afi/SubAfi, 类型为：类型为：string, 默认值：""

        EnableParseRxUpdateMsg (bool): 使能ParseRxUpdateMsg, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Bgp | Session=${Session} |
    """

    result = renix.edit_bgp(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv4_route_pool(Session, **kwargs):
    """
    创建BGP IPv4路由对象

    Args:

        Session (:obj:`BgpRouter`): Bgp协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BGP IPv4路由名称, 类型为：string

        Enable (bool): 使能BGP IPv4路由, 类型为：bool, 取值范围：True或False, 默认值：True

        SubAfi (str): Sub-AFI, 类型为：string, 默认值：UNICAST, 支持类型：

            UNICAST

            MULTICAST

            VPN

            LABELED

        Origin (str): 路由属性中的ORIGIN值, 类型为：string, 取值范围：Incomplete; IGP; EGP, 默认值：IGP

        AsPath (int): AS Path, 类型为：number, 取值范围：1-255,

        AsPathType (str): AS Path类型, 类型为：string, 默认值：SEQUENCE, 取值范围：

            SET

            SEQUENCE

            CONFED_SEQUENCE

            CONFED_SET

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableLocalPref (bool): 使能Local Preference, 类型为：bool, 取值范围：True或False, 默认值：True

        LocalPref (int): LocalPref, 当使能Local Preference为选中状态时配置该选项, 类型为：number, 取值范围：0-4294967295, 默认值：10

        EnableMed (bool): 使能Multi Exit Discriminator, 类型为：bool, 取值范围：True或False, 默认值：False

        MultExitDisc (int): Multi Exit Discriminator, 当使能Multi Exit Discriminator为选中状态时配置该选项, 类型为：number, 取值范围：0-4294967295, 默认值：0

        AtomicAggregate (bool): 使能Atomic Aggregate, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableAggregator (bool): 使能Aggregator, 类型为：bool, 取值范围：True或False, 默认值：False

        AggregatorAsNumber (int): Aggregator自治域, 类型为：number, 取值范围：1-4294967295, 默认值：1

        AggregatorIp (str): Aggregator IP, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.1.0

        EnableOriginatorId (bool): 使能Originator ID, 类型为：bool, 取值范围：True或False, 默认值：False

        OriginatorId (str): Originator ID, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.1.0

        EnableClusterIdList (bool): 使能Cluster ID List, 类型为：bool, 取值范围：True或False, 默认值：False

        ClusterIdList (str): Cluster ID List, 类型为：string, 取值范围：IPv4地址, 默认值：空

        EnableCommunity (bool): 使能团体, 类型为：bool, 取值范围：True或False, 默认值：False

        CommunityType (str): 团体类型, 类型为：string默认值：AA:NN, 取值范围：

            AA_NN

            NO_EXPORT

            NO_ADVERTISE

            LOCAL_AS

        CommunityAsNumber (int): 团体自治域, 当Type为AA:NN时，指定团体的AS号, 类型为：number, 取值范围：1-65535, 默认值：1

        CommunityId (int): 团体ID, 当Type为AA:NN时，指定团体的ID值, 类型为：number, 取值范围：1-65535, 默认值：1

        Community (str): 团体, 类型为：list, 默认值：[]

        CommunityIncrement (str): 团体跳变, 类型为：list, 默认值：[]

        CommunityPerBlockCount (int): 每个路由组团体数量, 类型为：number, 取值范围：1-65535, 默认值：1

        ExtendedCommunity (str): 扩展团体, 类型为：list, 默认值：[], 例如：['0x00:0x02:1:1', '0x01:0x02:1:2', '0x02:0x02:1:3']

        VrfRd (str): VRF路由标识, 类型为：string, 取值范围：AS:Number或IPv4:Number, 默认值：1:1

        VrfRdStep (str): VRF路由标识跳变, 类型为：string, 取值范围：AS:Number或IPv4:Number, 默认值：0:1

        VrfRt (str): VRF路由目标, 类型为：string, 取值范围：AS:Number, 默认值：100:1

        VrfRtStep (str): VRF路由目标跳变, 类型为：string, 取值范围：AS:Number, 默认值：0:1

        VrfCount (int) (int): VRF数量, 类型为：number, 取值范围：1-65535, 默认值：1

        StartingLabel (int): 起始标签, 类型为：number, 取值范围：0-1048575, 默认值：16

        LabelType (str): 路由标签类型, 类型为：类型为：string, 取值范围：Fixed; Incrementa; Explicit Nul; Implicit Null, 默认值：Fixed

        FirstRoute (str): IPv4路由起始值, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.1.0

        RandomRoute (bool): 随机路由, 类型为：bool, 取值范围：True或False, 默认值：False

        RouteCount (int): 每个会话路由数量, 类型为：number, 取值范围：1-8000000, 默认值：1

        RouteStep (str): IPv4路由跳变步长, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.1.0

        Ipv4RouteStep (int): IPv4路由跳变步长, 类型为：number, 取值范围：1-4294967295, 默认值：1

        PrefixLength (int): IPv4路由前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

        NextHopAddrType (str): 下一跳地址类型, 类型为：string, 取值范围：IPv4; IPv6, 默认值：IPv4

        NextHop (str): 下一跳地址, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.1.0

        NextHopStep (str): 下一跳步长, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.0.1

        IPv6NextHop (str): IPv6下一跳地址, 类型为：string, 取值范围：IPv4地址, 默认值：2000::1

        IPv6NextHopStep (str): IPv6下一跳步长, 类型为：string, 取值范围：IPv6地址, 默认值：::1

        EnableLinkLocalNextHop (bool): 使能Link Local地址作为下一跳, 类型为：bool, 取值范围：True或False, 默认值：False

        Ipv6LinkLocalNextHop (str): IPv6 Link Local下一跳地址, 类型为：string, 取值范围：IPv4地址, 默认值：2000::1

        Ipv6LinkLocalNextHopStep (str): IPv6 Link Local下一跳步长, 类型为：string, 取值范围：IPv6地址, 默认值：::1

        EncodeSrTlvs (list): 编码SR TLV, 类型为：list, 默认值：0, 取值范围：

            LABEL_INDEX

            SRGB

            SRV6_VPN_SID

            SRV6_SERVICES

        OverrideGlobalSrgb (bool): 覆盖全局SRGB, 类型为：bool, 取值范围：True或False, 默认值：False

        SrgbBase (int): SRGB起始值, 类型为：number, 取值范围：0-16777215, 默认值：16000

        SrgbRange (int): SRGB范围, 类型为：number, 取值范围：0-16777215, 默认值：1000

        LabelIndex (int): 标签序号, 类型为：number, 取值范围：0-4294967295, 默认值：0

        LabelStep (int): 标签步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        Srv6SidInfoSubTlvType (int): SRv6 SID Information Sub TLV类型, 类型为：number, 取值范围：1-255, 默认值：1

        Srv6LocatorBlockLength (int): SRv6 Locator Block长度, 类型为：number, 取值范围：0-128, 默认值：32

        Srv6LocatorNodeLength (int): SRv6 Locator Node长度, 类型为：number, 取值范围：1-128, 默认值：32

        Srv6FuncLength (int): SRv6 Function长度, 类型为：number, 取值范围：0-128, 默认值：32

        Srv6FuncOpcode (str): SRv6 Function Opcode, 类型为：string, 取值范围：格式：ff:ff:ff, 默认值：0

        Srv6ArguLength (int): SRv6 Argument长度, 类型为：number, 取值范围：1-128, 默认值：32

        Srv6Argument (str): SRv6 Argument, 类型为：string, 取值范围：格式：ff:ff:ff, 默认值：0

        EncodedSrv6ServiceDataSubTlvs (list): 编码SRv6 Service Data Sub TLVs, 类型为：list, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            SRV6_ID_STRUCTURE

        Srv6TranspositionLength (int): SRv6 Transposition长度, 类型为：number, 取值范围：0-24, 默认值：0

        Srv6TranspositionOffset (int): SRv6 Transposition偏移, 类型为：number, 取值范围：0-15, 默认值：0

        Srv6Locator (str): 使用的认证类型, 类型为：string, 取值范围：None或MD5, 默认值：None

        Srv6LocatorStep (str): 认证密码, 类型为：类型为：string, 取值范围：字符串，由1-255个数字、字母或特殊字符组成, 默认值：xinertel

        Srv6EndpointBehavior (str): SRv6 Endpoint Behavior, 类型为：string, 默认值：CUSTOM, 支持的值：

            END_DX6

            END_DX4

            END_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DT2U

            END_DT2M

            CUSTOM

        Srv6CustomEndpointBehavior (int): 自定义SRv6 Endpoint Behavior, 类型为：hex number, 取值范围：0x0-0xFFFF, 默认值：0xFFFF

    Returns:

        (:obj:`BgpIpv4RoutepoolConfig`): BGP IPv4路由对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${Community} | Create List | AA_NN | NO_EXPORT | NO_ADVERTISE | LOCAL_AS |
            | ${CommunityIncrement} | Create List | 1:1 | 1:2 | 1:3 | 1:4 |
            | ${ExtendedCommunity} | Create List | 0x00:0x02:1:1 | 0x01:0x02:1:2 | 0x02:0x02:1:3 |
            | ${RoutePool} | Create Bgp Ipv4 Route Pool | Session=${Session} | Community=${Community} | CommunityIncrement=${CommunityIncrement} | ExtendedCommunity=${ExtendedCommunity} |
            | ${Community} | Create List | AA_NN | NO_EXPORT |
            | ${CommunityIncrement} | Create List | 2:1 | 2:2 |
            | Edit Configs | Configs=${RoutePool} | Community=${Community} | CommunityIncrement=${CommunityIncrement} | CommunityPerBlockCount=2 |
    """

    result = renix.create_bgp_ipv4_route_pool(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv6_route_pool(Session, **kwargs):
    """
    创建BGP IPv6路由对象

    Args:

        Session (:obj:`BgpRouter`): Bgp协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BGP IPv6路由名称, 类型为：string

        Enable (bool): 使能BGP IPv6路由, 类型为：bool, 取值范围：True或False, 默认值：True

        SubAfi (str): Sub-AFI, 类型为：string, 默认值：UNICAST, 支持类型：

            UNICAST

            MULTICAST

            VPN

            LABELED

        Origin (str): 路由属性中的ORIGIN值, 类型为：string, 取值范围：Incomplete; IGP; EGP, 默认值：IGP

        AsPath (int): AS Path, 类型为：number, 取值范围：0-255,

        AsPathType (str): AS Path类型, 类型为：string, 默认值：SEQUENCE, 取值范围：

            SET

            SEQUENCE

            CONFED_SEQUENCE

            CONFED_SET

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableLocalPref (bool): 使能Local Preference, 类型为：bool, 取值范围：True或False, 默认值：True

        LocalPref (int): LocalPref, 当使能Local Preference为选中状态时配置该选项, 类型为：number, 取值范围：0-4294967295, 默认值：10

        EnableMed (bool): 使能Multi Exit Discriminator, 类型为：bool, 取值范围：True或False, 默认值：False

        MultExitDisc (int): Multi Exit Discriminator, 当使能Multi Exit Discriminator为选中状态时配置该选项, 类型为：number, 取值范围：0-4294967295, 默认值：0

        AtomicAggregate (bool): 使能Atomic Aggregate, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableAggregator (bool): 使能Aggregator, 类型为：bool, 取值范围：True或False, 默认值：False

        AggregatorAsNumber (int): Aggregator自治域, 类型为：number, 取值范围：1-4294967295, 默认值：1

        AggregatorIp (str): Aggregator IP, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.1.0

        EnableOriginatorId (bool): 使能Originator ID, 类型为：bool, 取值范围：True或False, 默认值：False

        OriginatorId (str): Originator ID, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.1.0

        EnableClusterIdList (bool): 使能Cluster ID List, 类型为：bool, 取值范围：True或False, 默认值：False

        ClusterIdList (str): Cluster ID List, 类型为：string, 取值范围：IPv4地址, 默认值：空

        EnableCommunity (bool): 使能团体, 类型为：bool, 取值范围：True或False, 默认值：False

        CommunityType (str): 团体类型, 类型为：string, 取值范围：AA:NN; NO_EXPORT; NO_ADVERTISE; LOCAL_AS, 默认值：AA:NN

        CommunityAsNumber (int): 当Type为AA:NN时，指定团体的AS号, 类型为：number, 取值范围：1-65535, 默认值：1

        Community (str): 团体, 类型为：list, 默认值：[], 取值范围：

            AA_NN

            NO_EXPORT

            NO_ADVERTISE

            LOCAL_AS

        CommunityIncrement (str): 团体跳变, 类型为：list, 默认值：[], 取值范围：AA:NN

        CommunityPerBlockCount (int): 每个路由组团体数量, 类型为：number, 取值范围：1-65535, 默认值：1

        ExtendedCommunity (str): 扩展团体, 类型为：list, 默认值：[], 例如：['0x00:0x02:1:1', '0x01:0x02:1:2', '0x02:0x02:1:3']

        VrfRd (str): VRF路由标识, 类型为：string, 取值范围：AS:Number或IPv4:Number, 默认值：1:1

        VrfRdStep (str): VRF路由标识跳变, 类型为：string, 取值范围：AS:Number或IPv4:Number, 默认值：0:1

        VrfRt (str): VRF路由目标, 类型为：string, 取值范围：AS:Number, 默认值：100:1

        VrfRtStep (str): VRF路由目标跳变, 类型为：string, 取值范围：AS:Number, 默认值：0:1

        VrfCount (int): VRF数量, 类型为：number, 取值范围：1-65535, 默认值：1

        StartingLabel (int): 起始标签, 类型为：number, 取值范围：0-1048575, 默认值：16

        LabelType (str): 路由标签类型, 类型为：类型为：string, 取值范围：Fixed; Incrementa; Explicit Nul; Implicit Null, 默认值：Fixed

        FirstIpv6Route (str): IPv6路由起始值, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        RouteCount (int): 每个会话路由数量, 类型为：number, 取值范围：1-8000000, 默认值：1

        RouteStep (str): IPv6路由跳变步长, 类型为：string, 取值范围：IPv6地址, 默认值：'0:0:0:1::'

        Ipv6RouteStep (int): IPv6路由跳变步长, 类型为：number, 取值范围：1-4294967295, 默认值：1

        PrefixLength (int): IPv4路由前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

        NextHopAddrType (str): 下一跳地址类型, 类型为：string, 取值范围：IPv4; IPv6, 默认值：IPv4

        NextHop (str): 下一跳地址, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.1.0

        NextHopStep (str): 下一跳步长, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.0.1

        IPv6NextHop (str): IPv6下一跳地址, 类型为：string, 取值范围：IPv4地址, 默认值：2000::1

        IPv6NextHopStep (str): IPv6下一跳步长, 类型为：string, 取值范围：IPv6地址, 默认值：::1

        EnableLinkLocalNextHop (bool): 使能Link Local地址作为下一跳, 类型为：bool, 取值范围：True或False, 默认值：False

        Ipv6LinkLocalNextHop (str): IPv6 Link Local下一跳地址, 类型为：string, 取值范围：IPv4地址, 默认值：2000::1

        Ipv6LinkLocalNextHopStep (str): IPv6 Link Local下一跳步长, 类型为：string, 取值范围：IPv6地址, 默认值：::1

        EncodeSrTlvs (list): 编码SR TLV, 类型为：list, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            SRV6_VPN_SID

            SRV6_SERVICES

        OverrideGlobalSrgb (bool): 覆盖全局SRGB, 类型为：bool, 取值范围：True或False, 默认值：False

        SrgbBase (int): SRGB起始值, 类型为：number, 取值范围：0-16777215, 默认值：16000

        SrgbRange (int): SRGB范围, 类型为：number, 取值范围：0-16777215, 默认值：1000

        LabelIndex (int): 标签序号, 类型为：number, 取值范围：0-4294967295, 默认值：0

        LabelStep (int): 标签步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        Srv6SidInfoSubTlvType (int): SRv6 SID Information Sub TLV类型, 类型为：number, 取值范围：1-255, 默认值：1

        Srv6LocatorBlockLength (int): SRv6 Locator Block长度, 类型为：number, 取值范围：0-128, 默认值：32

        Srv6LocatorNodeLength (int): SRv6 Locator Node长度, 类型为：number, 取值范围：1-128, 默认值：32

        Srv6FuncLength (int): SRv6 Function长度, 类型为：number, 取值范围：0-128, 默认值：32

        Srv6FuncOpcode (str): SRv6 Function Opcode, 类型为：string, 取值范围：格式：ff:ff:ff, 默认值：0

        Srv6ArguLength (int): SRv6 Argument长度, 类型为：number, 取值范围：1-128, 默认值：32

        Srv6Argument (str): SRv6 Argument, 类型为：string, 取值范围：格式：ff:ff:ff, 默认值：0

        EncodedSrv6ServiceDataSubTlvs (list): 编码SRv6 Service Data Sub TLVs, 类型为：list, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            SRV6_ID_STRUCTURE

        Srv6TranspositionLength (int): SRv6 Transposition长度, 类型为：number, 取值范围：0-24, 默认值：0

        Srv6TranspositionOffset (int): SRv6 Transposition偏移, 类型为：number, 取值范围：0-15, 默认值：0

        Srv6Locator (str): 使用的认证类型, 类型为：string, 取值范围：None或MD5, 默认值：None

        Srv6LocatorStep (str): 认证密码, 类型为：类型为：string, 取值范围：字符串，由1-255个数字、字母或特殊字符组成, 默认值：xinertel

        Srv6EndpointBehavior (str): SRv6 Endpoint Behavior, 类型为：string, 默认值：CUSTOM, 支持的值：

            END_DX6

            END_DX4

            END_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DT2U

            END_DT2M

            CUSTOM

        Srv6CustomEndpointBehavior (int): 自定义SRv6 Endpoint Behavior, 类型为：hex number, 取值范围：0x0-0xFFFF, 默认值：0xFFFF

    Returns:

        (:obj:`BgpIpv6RoutepoolConfig`): BGP IPv6路由对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${Community} | Create List | AA_NN | NO_EXPORT | NO_ADVERTISE | LOCAL_AS |
            | ${CommunityIncrement} | Create List | 1:1 | 1:2 | 1:3 | 1:4 |
            | ${ExtendedCommunity} | Create List | 0x00:0x02:1:1 | 0x01:0x02:1:2 | 0x02:0x02:1:3 |
            | ${RoutePool} | Create Bgp Ipv6 Route Pool | Session=${Session} | Community=${Community} | CommunityIncrement=${CommunityIncrement} | ExtendedCommunity=${ExtendedCommunity} |
            | ${Community} | Create List | AA_NN | NO_EXPORT |
            | ${CommunityIncrement} | Create List | 2:1 | 2:2 |
            | Edit Configs | Configs=${RoutePool} | Community=${Community} | CommunityIncrement=${CommunityIncrement} | CommunityPerBlockCount=2 |
    """

    result = renix.create_bgp_ipv6_route_pool(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bgp_router_from_route_pool(Configs, Type='ipv4'):
    """
    获取BGP Route Pool对应的绑定流源或目的端点对象

    Args:

        Configs (list(:obj:`BgpIpv4RoutepoolConfig`)): 测试仪表BGP Route Pool对象列表

        Type (str): Route Pool类型支持ipv4和ipv6

    Returns:

        (list(:obj:`BgpIpv4RoutepoolConfig`)): BGP Route Pool对应的绑定流源或目的端点对象列表

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${RouterPool} | Create Bgp Ipv4 Route Pool | Session=${Session} |
            | ${Point} | Get Router From Route Pool | Configs=${RouterPool} |
    """

    result = renix.get_bgp_router_from_route_pool(Configs=Configs, Type=Type)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_capability(Session, **kwargs):
    """
    创建BGP Capability对象

    Args:

        Session (:obj:`BgpRouter`): Bgp协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BGP Capability名称, 类型为：string

        Enable (bool): 使能BGP Capability, 类型为：bool, 取值范围：True或False, 默认值：True

        CapabilityCode (int): Capability Code, 类型为：number, 默认值：1, 取值范围：1-255

        CapabilityValue (str): Capability 值 类型为：list

    Returns:

        (:obj:`BgpCapabilityConfig`): BGP Capability对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${CapabilityValue} | Create List | 1 | 2 | 3 | 4 | 5 |
            | Create Bgp Capability | Session=${Session} | CapabilityCode=5 | CapabilityValue=${CapabilityValue} |
    """

    result = renix.create_bgp_capability(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_evpn_route_ad(Session, **kwargs):
    """
    创建BGP EVPN以太自动发现路由对象

    Args:

        Session (:obj:`BgpRouter`): Bgp协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BGP EVPN以太自动发现路由名称, 类型为：string

        Enable (bool): 使能BGP EVPN以太自动发现路由, 类型为：bool, 默认值：True, 取值范围：True或False,

        Origin (str): ORIGIN, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): AS路径的值, 类型为：list

        AdRouteType (str): 以太自动发现路由类型, 类型为：string, 默认值：ESI, 取值范围：

            EVI

            ESI

            VPWS

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True, 取值范围：True或False

        NextHop (str): 下一跳, 类型为：string, 默认值：100.0.0.1, 取值范围：IPv4地址

        NextHopIpv6 (str): IPv6下一跳, 类型为：string, 默认值：2001::1, 取值范围：IPv6地址

        EnableLinkLocalNextHop (bool): 使能IPv6 Link Local下一跳, 类型为：bool, 默认值：False, 取值范围：True或False

        LinkLocalNextHop (str): IPv6 Link Local下一跳, 类型为：string, 默认值：fe80::1, 取值范围：IPv6地址

        EnableOriginatorId (bool): 使能Originator ID, 类型为：bool, 默认值：False, 取值范围：True或False

        OriginatorId (str): Originator ID, 类型为：string, 默认值：192.0.0.1, 取值范围：IPv4地址

        VrfRouteTarget (str): VRF路由目标, 类型为：string, 默认值：100:1, 取值范围：AS:Number

        VrfRouteTargetStep (str): VRF路由目标跳变, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：10.0.0.2:1, 取值范围：AS:Number或IPv4:Number

        VrfRouteDistinguisherStep (str): VRF路由标识跳变, 类型为：string, 默认值：0:1

        EthernetSegmentType (str):以太网段类型, 类型为：string, 默认值：OPERATOR, 取值范围：

            OPERATOR

            IEEE802

            BRIDGEDLAN

            MACBASED

            ROUTEID

            AS

        EthernetSegmentIdentifier (str): 以太网段标识, 类型为：string, 默认值：OPERATOR

        EthernetTagId (str): 以太网标签ID, 类型为：string, 默认值：00:00:00:00:00:00:00:00:00

        EthernetTagIdStep (int): 太网标签ID跳变, 类型为：number, 默认值：1, 取值范围：0-4294967295

        EthernetTagCountPerEvi (int): 每个EVI下以太网标签数, 类型为：number, 默认值：1, 取值范围：1-4294967295

        ActiveStandbyMode (str): 主备方式, 类型为：string, 默认值：SINGLE, 取值范围：

            ALL

            SINGLE

        EviCount (int): EVI数, 类型为：number, 默认值：1, 取值范围：1-4294967295

        DataPlanEncapsulation (str): 数据平面封装,  类型为：string, 默认值：NONE, 取值范围：

            NONE

            VXLAN

            MPLS

            SRv6

        Label1 (int):封装标签（VNI/VSID）, 类型为：number, 默认值：100, 取值范围：0-16777215

        Label1Step (int): 封装标签跳变（VNI/VSID Step）, 类型为：number, 默认值：1, 取值范围：0-16777215

        IncludeLayer2AttributeExtendedCommunity (bool): 以太自动发现路由类型为VPWS时可见, 类型为：bool, 默认值：False, 取值范围：True或False

        PBit (bool): P Bit 多归单活场景中，该标志位置1表示该PE为主PE, 类型为：bool, 默认值：False, 取值范围：True或False

        BBit (bool): B Bit 多归单活场景中，该标志位置1表示该PE为备PE, 类型为：bool, 默认值：False, 取值范围：True或False

        CBit (bool): C Bit 置1时发送给该PE的EVPN报文必须携带控制字, 类型为：bool, 默认值：False, 取值范围：True或False

        L2Mtu (bool): 指定最大传输单元，单位是字节, 类型为：bool, 默认值：False, 取值范围：True或False

        EnableCustomMplsLabel (bool): 使能自定义MPLS标签, 类型为：bool, 默认值：False, 取值范围：True或False

        MplsLabel (int): MPLS标签值, 类型为：number, 默认值：0, 取值范围：0-1048575

        MplsLabelStep (int): MPLS标签步长, 类型为：number, 默认值：0, 取值范围：0-1048575

    Returns:

        (:obj:`EvpnRouteAdConfig`): BGP EVPN以太自动发现路由对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Evpn Route Ad | Session=${Session} | EnableCustomMplsLabel=True | MplsLabel=1000 | MplsLabelStep=2 |
    """

    result = renix.create_bgp_evpn_route_ad(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def establish_bgp(Sessions):
    """
    建立BGP协议会话

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Establish Bgp | Sessions=${Sessions} |
    """

    result = renix.establish_bgp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def connect_bgp(Sessions):
    """
    连接BGP协议会话

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Connect Bgp | Sessions=${Sessions} |
    """

    result = renix.connect_bgp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def disconnect_bgp(Sessions):
    """
    断开BGP协议会话连接

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Disconnect Bgp | Sessions=${Sessions} |
    """

    result = renix.disconnect_bgp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def advertise_bgp(Sessions):
    """
    通告BGP协议会话lsa

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Advertise Bgp | Sessions=${Sessions} |
    """

    result = renix.advertise_bgp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def withdraw_bgp(Sessions):
    """
    撤销BGP协议会话lsa

    Args:

        Sessions (:obj:`BgpRouter`): OSPFv3协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Withdraw Bgp | Sessions=${Sessions} |
    """

    result = renix.withdraw_bgp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def advertise_bgp_route(Routes):
    """
    通告BGP协议指定lsa

    Args:

        Routes (list): BGP协议路由对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Advertise Bgp Route | Routes=${Routes} |
    """

    result = renix.advertise_bgp_route(Routes=Routes)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def withdraw_bgp_route(Routes):
    """
    撤销BGP协议指定lsa

    Args:

        Routes (list): BGP协议路由对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Withdraw Bgp Route | Routes=${Routes} |
    """

    result = renix.withdraw_bgp_route(Routes=Routes)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def graceful_restart_bgp(Sessions):
    """
    平滑重启

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Graceful Restart Bgp | Sessions=${Sessions} |
    """

    result = renix.graceful_restart_bgp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def refresh_bgp(Sessions):
    """
    刷新

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Refresh Bgp | Sessions=${Sessions} |
    """

    result = renix.refresh_bgp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_bgp_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待BGP协议会话达到指定状态

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

        State (list): 等待BGP协议会话达到的状态, 类型为：string, 默认值：达到RUNNING, 支持下列状态：

            DISABLED

            NOT_START

            RUNNING

            STARTING

            STOPPING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Bgp State | Sessions=${Sessions} | State=DR | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_bgp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_bgp_router_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待BGP会话组达到指定状态

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

        State (list): 等待BGP IPv4会话组达到的状态, 类型为：string, 默认值：达到ESTABLISHED, 支持下列状态：

            NOT_START

            IDLE

            CONNECT

            ACTIVE

            OPEN_SENT

            OPEN_CONFIRM

            ESTABLISHED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Bgp Router State | Sessions=${Sessions} | State=ESTABLISHED | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_bgp_router_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_bgp_ipv4_router_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待BGP IPv4会话组达到指定状态

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

        State (list): 等待BGP IPv4会话组达到的状态, 类型为：string, 默认值：达到ESTABLISHED, 支持下列状态：

            NOT_START

            IDLE

            CONNECT

            ACTIVE

            OPEN_SENT

            OPEN_CONFIRM

            ESTABLISHED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Bgp IPv4 Router State | Sessions=${Sessions} | State=ESTABLISHED | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_bgp_ipv4_router_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_bgp_ipv6_router_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待BGP IPv6会话组达到指定状态

    Args:

        Sessions (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

        State (list): 等待BGP IPv6会话组达到的状态, 类型为：string, 默认值：达到ESTABLISHED, 支持下列状态：

            NOT_START

            IDLE

            CONNECT

            ACTIVE

            OPEN_SENT

            OPEN_CONFIRM

            ESTABLISHED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Bgp IPv6 Router State | Sessions=${Sessions} | State=ESTABLISHED | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_bgp_ipv6_router_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_random_route(PortNumber,
                            Type=None,
                            Ipv4RouteNumber=300000,
                            Ipv6RouteNumber=100000,
                            Ipv4StartMask=23,
                            Ipv6StartMask=32,
                            Ipv4StartRoute="60.0.0.0",
                            Ipv6StartRoute="60::",
                            **kwargs
                            ):
    result = renix.create_bgp_random_route(
        PortNumber=PortNumber,
        Type=Type,
        Ipv4RouteNumber=Ipv4RouteNumber,
        Ipv6RouteNumber=Ipv6RouteNumber,
        Ipv4StartMask=Ipv4StartMask,
        Ipv6StartMask=Ipv6StartMask,
        Ipv4StartRoute=Ipv4StartRoute,
        Ipv6StartRoute=Ipv6StartRoute,
        **kwargs
    )
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_route_pool_custom_path_attribute(RoutePool, **kwargs):
    """
    创建BGP Route Pool Custom Path Attribute对象, 类型为：object / list

    Args:

        RoutePool(:obj:`BgpIpv4RoutepoolConfig`): 所属的Bgp Route Pool对象, 类型为：object / list

    Keyword Args:

        PathAttributeType (int): 路径属性的类型, 类型为：number, 取值范围：1-255, 默认值：1

        OptionalFlag (str): 指定Optional Flag的值, 类型为：string, 默认值：OPTION, 取值范围：

            WELL_KNOWN

            OPTION

        TransitiveFlag (str): 指定Transitive Flag的值, 类型为：string, 默认值：NONTRANSITIVE, 取值范围：

            NONTRANSITIVE

            TRANSITIVE

        PartialFlag (str): 指定Partial Flag的值, 类型为：string, 默认值：PARTIAL, 取值范围：

            COMPLETE

            PARTIAL

        ExtendedLengthFlag (bool): 是否启用Extended Length Flag, 类型为：bool, 默认值：False

        AttributeExtendedLength (int): 指定路径属性的长度, 类型为：number, 默认值：0

        AttributeValue (str): 指定路径属性的值, 类型为：string, 默认值：""

    Returns:

        (:obj:`BgpPathAttributeConfig`): Bgp Route Pool Custom Path Attribute对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${RoutePool} | Create Bgp Ipv4 Route Pool | Session=${Session} |
            | ${AttributeValue} | Set Variable | 0500220001001E00AAAA000100010001000000000000000100001300010006301014000000 |
            | Create Bgp Route Pool Custom Path Attribute | RoutePool=${RoutePool} | AttributeValue=${AttributeValue} |
    """

    result = renix.create_bgp_route_pool_custom_path_attribute(RoutePool=RoutePool, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_evpn_mac_ip_routes(Session, **kwargs):
    """
    创建Bgp Evpn Mac Ip Routes对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        Origin (str): 指定路由属性中的ORIGIN值, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True

        NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv4地址, 默认值：100.0.0.1

        NextHopIpv6 (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv6地址, 默认值：2001::1

        EnableLinkLocalNextHop (bool): 使能IPv6 Link Local下一跳, 类型为：bool, 默认值：False

        LinkLocalNextHop (str): IPv6 Link Local下一跳地址, 类型为：有效的ipv6地址, 默认值：fe80::1

        EnableOriginatorId (bool): 是否启用Originator ID, 当仿真路由器作为BGP路由反射器时使用该属性, 类型为：bool, 默认值：False

        OriginatorId (str): 指定originator ID的值。该值用于标识路由发起者的router id, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：10.0.0.2:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

        EthernetSegmentType (str): 指定以太网段标识的类型，用于确定以太网段标识的格式 , 类型为：string, 默认值：OPERATOR, 取值范围：

            OPERATOR

            IEEE802

            BRIDGEDLAN

            MACBASED

            ROUTEID

            AS

        EthernetSegmentIdentifier (str): 指定CE和PE之间连接的标识, 类型为：string, 默认值：00:00:00:00:00:00:00:00:00

        EthernetTagId (int): 指定广播域（例如VLAN）的标识, 类型为：number, 取值范围：1-4294967295, 默认值：0

        NetWorkCount (int): 指定要创建的网络数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        StartMacAddress (str): 指定路由块中的起始MAC地址, 类型为：有效的mac地址, 默认值：00:10:01:00:00:01

        MacIncrement (str): 指定路由块中MAC地址的跳变步长, 类型为：有效的mac地址, 默认值：00:00:00:00:00:01

        EviCount (int): 创建的EVI （EVPN instance，EVPN实例）数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        VpnDistributionType (str): RT、RD以及VNI值在VPN之间的分配方式, 类型为：string, 默认值：ROUNDROBIN, 取值范围：

            ROUNDROBIN

            LINEAR

        AssociatedIpType (str): 指定通告路由中所携带主机IP路由的版本 , 类型为：string, 默认值：IPV4, 取值范围：

            NONE

            IPV4

            IPV6

        DataPlanEncapsulation (str): 封装有效负载所使用的头部类型, 类型为：string, 默认值：NONE, 取值范围：

            NONE

            VXLAN

            MPLS

            SRv6

        EnableMacMobility (bool): 使能MAC地址迁移, 类型为：bool, 默认值：False

        StickyStatic (bool): MAC地址是静态MAC地址, 类型为：bool, 默认值：False

        SequenceNumber (int): 指定MAC迁移扩展团体属性TLV中的序列号起始值, 类型为：number, 取值范围：1-4294967295, 默认值：0

        Label1 (int): 封装标签（VNI/VSID）, 数据平面封装为VXLAN时可见, 指定转发二层业务流量所使用封装标签的起始值, 类型为：number, 取值范围：1-16777215, 默认值：0

        Label1Step (int): 指定转发二层业务流量所使用封装标签的跳变步长, 类型为：number, 取值范围：1-16777215, 默认值：1

        StartIpv4Address (str): 起始IPv4地址, 类型为：有效的ipv4地址, 默认值：100.0.0.2

        Ipv4Increment (str): IPv4地址跳变, 类型为：有效的ipv4地址, 默认值：0.0.0.1

        Ipv4PrefixLength (int): IPv4地址前缀, 类型为：number, 取值范围：1-32, 默认值：24

        StartIpv6Address (str): 起始IPv6地址, 类型为：有效的ipv6地址, 默认值：2001::1

        Ipv6Increment (str): IPv6地址跳变, 类型为：有效的ipv6地址, 默认值：::1

        Ipv6PrefixLength (int): IPv6地址前缀, 类型为：number, 取值范围：1-128, 默认值：64

        EnableLabel2 (bool): 使能MPLS Label2, 类型为：bool, 默认值：False

        Label2 (int): 封装2标签(L3 VNI), 类型为：number, 取值范围：1-16777215, 默认值：2000

        Label2Step (int): 封装2标签跳变(L3 VNI Step), 类型为：number, 取值范围：1-16777215, 默认值：1

        EnableIncludeRouterMac (bool): 是否包含路由MAC, 类型为：bool, 默认值：False

        RouterMac (str): 路由MAC地址, 类型为：有效的mac地址, 默认值：00:00:00:00:00:00

        EnableIncludeDefaultGateway (bool): 指定默认网关, 类型为：bool, 默认值：False

        EnableCustomMplsLabel (bool): 使能自定义MPLS标签, 类型为：bool, 默认值：False

        MplsLabel (int): MPLS标签, 类型为：number, 取值范围：1-1048575, 默认值：0

        MplsLabelStep (int): MPLS标签跳变, 类型为：number, 取值范围：1-1048575, 默认值：0

        EnableCustomMplsLabel2 (bool): 使能自定义MPLS Label2, 类型为：bool, 默认值：False

        MplsLabel2 (int): MPLS标签2, 类型为：number, 取值范围：1-1048575, 默认值：0

        MplsLabel2Step (int): MPLS标签2跳变, 类型为：number, 取值范围：1-1048575, 默认值：0


    Returns:

        (:obj:`EvpnRouteMacIpConfig`): Bgp Evpn Mac Ip Routes对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Evpn Mac Ip Routes | Session=${Session} |
    """

    result = renix.create_bgp_evpn_mac_ip_routes(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_evpn_inclusive_multicast_routes(Session, **kwargs):
    """
    创建Bgp Evpn Inclusive Multicast Routes对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        Origin (str): 指定路由属性中的ORIGIN值, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True

        NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv4地址, 默认值：100.0.0.1

        NextHopIpv6 (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv6地址, 默认值：2001::1

        EnableLinkLocalNextHop (bool): 使能IPv6 Link Local下一跳, 类型为：bool, 默认值：False

        LinkLocalNextHop (str): IPv6 Link Local下一跳地址, 类型为：有效的ipv6地址, 默认值：fe80::1

        EnableOriginatorId (bool): 是否启用Originator ID, 当仿真路由器作为BGP路由反射器时使用该属性, 类型为：bool, 默认值：False

        OriginatorId (str): 指定originator ID的值。该值用于标识路由发起者的router id, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：10.0.0.2:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

        EviCount (int): 创建的EVI （EVPN instance，EVPN实例）数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        EthernetTagId (int): 类型为：number, 取值范围：1-4294967295, 默认值：1

        PmsiTunnelType (str): 指定多播报文传输所使用隧道的类型。只支持INGRESS_REPLICATION（头端复制隧道。隧道标识携带本地PE的单播隧道目的端IP地址）。类型为：string, 默认值：INGRESS_REPLICATION

        DataPlanEncapsulation (str): 指定路由属性中的ORIGIN值, 类型为：string, 默认值：NONE, 取值范围：

            NONE

            VXLAN

            MPLS

            SRv6

        Label1 (int): 封装标签（VNI/VSID）, 数据平面封装为VXLAN时可见, 指定转发二层业务流量所使用封装标签的起始值, 类型为：number, 取值范围：1-16777215, 默认值：0

        Label1Step (int): 指定转发二层业务流量所使用封装标签的跳变步长, 类型为：number, 取值范围：1-16777215, 默认值：1

        EnableCustomMplsLabel (bool): 使能自定义MPLS标签, 类型为：bool, 默认值：False

        MplsLabel (int): MPLS标签, 类型为：number, 取值范围：1-1048575, 默认值：0

        MplsLabelStep (int): MPLS标签跳变, 类型为：number, 取值范围：1-1048575, 默认值：0

    Returns:

        (:obj:`EvpnRouteInclusiveMulticastConfig`): Bgp Evpn Inclusive Multicast Routes对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

             | ${Session} | Create Bgp | Port=${Port} |
             | Create Bgp Evpn Inclusive Multicast Routes | Session=${Session} |
    """

    result = renix.create_bgp_evpn_inclusive_multicast_routes(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_evpn_ethernet_segment_routes(Session, **kwargs):
    """
    创建Bgp Evpn Ethernet Segment Routes对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        Origin (str): 指定路由属性中的ORIGIN值, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True

        NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv4地址, 默认值：100.0.0.1

        NextHopIpv6 (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv6地址, 默认值：2001::1

        EnableLinkLocalNextHop (bool): 使能IPv6 Link Local下一跳, 类型为：bool, 默认值：False

        LinkLocalNextHop (str): IPv6 Link Local下一跳地址, 类型为：有效的ipv6地址, 默认值：fe80::1

        EnableOriginatorId (bool): 是否启用Originator ID, 当仿真路由器作为BGP路由反射器时使用该属性, 类型为：bool, 默认值：False

        OriginatorId (str): 指定originator ID的值。该值用于标识路由发起者的router id, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：10.0.0.2:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

        EthernetSegmentType (str): 类型为：string, 默认值：OPERATOR, 取值范围：

            OPERATOR

            IEEE802

            BRIDGEDLAN

            MACBASED

            ROUTEID

            AS

        EthernetSegmentIdentifier (str): 类型为：string, 默认值：00:00:00:00:00:00:00:00:00

        EviCount (int): 创建的EVI （EVPN instance，EVPN实例）数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        DataPlanEncapsulation (str): 指定路由属性中的ORIGIN值, 类型为：string, 默认值：NONE, 取值范围：

            NONE

            VXLAN

            MPLS

            SRv6

        EsImportRoute (str): 类型为：有效的mac地址, 默认值：00:00:00:00:00:00

    Returns:

        (:obj:`EvpnRouteEthernetSegmentConfig`): Bgp Evpn Ethernet Segment Routes对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Evpn Ethernet Segment Routes | Session=${Session} |
    """

    result = renix.create_bgp_evpn_ethernet_segment_routes(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_evpn_ip_prefix_routes(Session, **kwargs):
    """
    创建Bgp Evpn Ip Prefix Routes对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        Origin (str): 指定路由属性中的ORIGIN值, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True

        NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv4地址, 默认值：100.0.0.1

        NextHopIpv6 (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv6地址, 默认值：2001::1

        EnableLinkLocalNextHop (bool): 使能IPv6 Link Local下一跳, 类型为：bool, 默认值：False

        LinkLocalNextHop (str): IPv6 Link Local下一跳地址, 类型为：有效的ipv6地址, 默认值：fe80::1

        EnableOriginatorId (bool): 是否启用Originator ID, 当仿真路由器作为BGP路由反射器时使用该属性, 类型为：bool, 默认值：False

        OriginatorId (str): 指定originator ID的值。该值用于标识路由发起者的router id, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：10.0.0.2:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

        EthernetSegmentType (str): 指定以太网段标识的类型，用于确定以太网段标识的格式 , 类型为：string, 默认值：OPERATOR, 取值范围：

            OPERATOR

            IEEE802

            BRIDGEDLAN

            MACBASED

            ROUTEID

            AS

        EthernetSegmentIdentifier (str): 指定CE和PE之间连接的标识, 类型为：string, 默认值：00:00:00:00:00:00:00:00:00

        EthernetTagId (int): 指定广播域（例如VLAN）的标识, 类型为：number, 取值范围：1-4294967295, 默认值：0

        NetWorkCount (int): 指定要创建的网络数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        EviCount (int): 创建的EVI （EVPN instance，EVPN实例）数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        VpnDistributionType (str): RT、RD以及VNI值在VPN之间的分配方式, 类型为：string, 默认值：ROUNDROBIN, 取值范围：

            ROUNDROBIN

            LINEAR

        DataPlanEncapsulation (str): 封装有效负载所使用的头部类型, 类型为：string, 默认值：NONE, 取值范围：

            NONE

            VXLAN

            MPLS

            SRv6

        EnableCustomMplsLabel (bool): 使能自定义MPLS标签, 类型为：bool, 默认值：False

        Label1 (int): 封装标签（VNI/VSID）, 数据平面封装为VXLAN时可见, 指定转发二层业务流量所使用封装标签的起始值, 类型为：number, 取值范围：1-16777215, 默认值：0

        Label1Step (int): 指定转发二层业务流量所使用封装标签的跳变步长, 类型为：number, 取值范围：1-16777215, 默认值：1

        IpType (str): 类型为：string, 默认值：IPV4, 取值范围：

            IPV4

            IPV6

        StartIpv4Address (str): 起始IPv4地址, 类型为：有效的ipv4地址, 默认值：100.0.0.2

        Ipv4Increment (str): IPv4地址跳变, 类型为：有效的ipv4地址, 默认值：0.0.0.1

        Ipv4PrefixLength (int): IPv4地址前缀, 类型为：number, 取值范围：1-32, 默认值：24

        GatewayIp (str): 类型为：有效的ipv4地址, 默认值：0.0.0.0

        StartIpv6Address (str): 起始IPv6地址, 类型为：有效的ipv6地址, 默认值：2001::1

        Ipv6Increment (str): IPv6地址跳变, 类型为：有效的ipv6地址, 默认值：::1

        Ipv6PrefixLength (int): IPv6地址前缀, 类型为：number, 取值范围：1-128, 默认值：64

        GatewayIpv6 (str): 类型为：有效的ipv6地址, 默认值：'::'

        EnableIncludeRouterMac (bool): 是否包含路由MAC, 类型为：bool, 默认值：False

        RouterMac (str): 路由MAC地址, 类型为：有效的mac地址, 默认值：00:00:00:00:00:00

        MplsLabel (int): MPLS标签, 类型为：number, 取值范围：1-1048575, 默认值：0

        MplsLabelStep (int): MPLS标签跳变, 类型为：number, 取值范围：1-1048575, 默认值：0

    Returns:

        (:obj:`EvpnRouteIpPrefixConfig`): Bgp Evpn Ip Prefix Routes对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Evpn Ip Prefix Routes | Session=${Session} |
    """

    result = renix.create_bgp_evpn_ip_prefix_routes(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv4_vpls(Session, **kwargs):
    """
    创建Bgp Ipv4 Vpls对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        AsPathType (str): AS Path类型, 类型为：string, 默认值：SEQUENCE, 取值范围：

            SET

            SEQUENCE

            CONFED_SEQUENCE

            CONFED_SET

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True

        NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv4地址, 默认值：100.0.0.1

        MultExitDisc (int): 类型为：number, 取值范围：1-4294967295, 默认值：0

        LocalPreference (int): Local优先级, 类型为：number, 取值范围：1-4294967295, 默认值：10

        VeId (int): 类型为：number, 取值范围：1-65535, 默认值：0

        VeIdStep (int): 类型为：number, 取值范围：1-65535, 默认值：1

        BlockOffset (int): 类型为：number, 取值范围：1-65535, 默认值：0

        BlockOffsetStep (int): 类型为：number, 取值范围：1-65535, 默认值：0

        BlockSize (int): 类型为：number, 取值范围：1-65535, 默认值：5

        MtuSize (int): 类型为：number, 取值范围：64-9000, 默认值：1500

        EncapType (str): 封装类型, 类型为：string, 默认值：VLAN, 取值范围：

            VLAN

            ETHERNET

            VPLS

        ControlFlag (int): 控制标识。以十进制表示。类型为：number, 取值范围：1-255, 默认值：0

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：10.0.0.2:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

        VrfCount (int): 类型为：number, 取值范围：1-65535, 默认值：1

    Returns:

        (:obj:`BgpIpv4VplsConfig`): Bgp Ipv4 Vpls对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Ipv4 Vpls | Session=${Session} |
    """

    result = renix.create_bgp_ipv4_vpls(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv6_vpls(Session, **kwargs):
    """
    创建Bgp Ipv6 Vpls对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True

        NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv6地址, 默认值：2000::1

        LinkLocalNextHop (str): 类型为：有效的ipv6地址, 默认值：fe80::1

        MultExitDisc (int): 类型为：number, 取值范围：1-4294967295, 默认值：0

        LocalPreference (int): Local优先级, 类型为：number, 取值范围：1-4294967295, 默认值：10

        VeId (int): 类型为：number, 取值范围：1-65535, 默认值：1

        VeIdStep (int): 类型为：number, 取值范围：1-65535, 默认值：0

        BlockOffset (int): 类型为：number, 取值范围：1-65535, 默认值：0

        BlockOffsetStep (int): 类型为：number, 取值范围：1-65535, 默认值：0

        BlockSize (int): 类型为：number, 取值范围：1-65535, 默认值：5

        MtuSize (int): 类型为：number, 取值范围：64-65535, 默认值：1500

        EncapType (str): 封装类型, 类型为：string, 默认值：VLAN, 取值范围：

            VLAN

            ETHERNET

            VPLS

        EnableRfc4761 (bool): 类型为：bool, 默认值：True

        ControlFlag (int): 控制标识。以十进制表示。类型为：number, 默认值：0

        StripVlan (bool): 类型为：bool, 默认值：False

        VeFlooding (bool): 类型为：bool, 默认值：False

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：10.0.0.2:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

        VrfCount (int): 类型为：number, 取值范围：1-65535, 默认值：1

    Returns:

        (:obj:`BgpIpv6VplsConfig`): Bgp Ipv6 Vpls对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Ipv6 Vpls | Session=${Session} |
    """

    result = renix.create_bgp_ipv6_vpls(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv4_flow_specs(Session, **kwargs):
    """
    创建Bgp Ipv4 Flow Specs对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        RouteCount (int): 类型为：number, 取值范围：1-8000000, 默认值：1

        FlowSpecSubAfi (str): 指定SubAFI的值, 类型为：string, 默认值：FlowSpec, 取值范围：

            FlowSpec

            FlowSpecVpn

        Origin (str): 指定ORIGIN的值, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        AsPathType (str): AS Path类型, 类型为：string, 默认值：SEQUENCE, 取值范围：

            SET

            SEQUENCE

        EnableLocalPref (bool): 类型为：bool, 取值范围：True或False, 默认值：True

        LocalPref (int): 类型为：number, 默认值：10

        EnableMed (bool): 类型为：bool, 取值范围：True或False, 默认值：False

        MultExitDisc (int): 类型为：number, 取值范围：1-4294967295, 默认值：0

        EnableClusterIdList (bool): 是否启用Cluster ID List, 类型为：bool, 取值范围：True或False, 默认值：False

        ClusterIdList (str): 指定cluster ID list的值, 类型为：有效的ipv4地址, 默认值：""

        EnableCommunity (bool): 类型为：bool, 取值范围：True或False, 默认值：False

        CommunityType (str): 团体类型, 类型为：string, 默认值：AA_NN, 取值范围：

            AA_NN

            NO_EXPORT

            NO_ADVERTISE

            LOCAL_AS

        CommunityAsNumber (int): 当Type为AA:NN时，指定团体的AS号, 类型为：number, 取值范围：1-65535, 默认值：1

        CommunityId (int): 当Type为AA:NN时，指定团体的ID值, 类型为：number, 取值范围：1-65535, 默认值：1

        Community (str): 当Type为NO_EXPORT时，团体值为0xffffff01；当Type为NO_ADVERTISE时，团体值为0xffffff02；当Type为LOCAL_AS时，团体值为0xffffff03, 类型为：string, 默认值：""

        ExtendedCommunity (str): 扩展团体, 类型为：string, 默认值：""

        ComponentType (list): 过滤规则, 类型为：list, 默认值：Type1, 取值范围：

            Type1

            Type2

            Type3

            Type4

            Type5

            Type6

            Type7

            Type8

            Type9

            Type10

            Type11

            Type12

        VrfNum (int): VRF数量, 类型为：number, 默认值：1

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：1:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

    Returns:

        (:obj:`BgpIpv4FlowSpecConfig`): Bgp Ipv4 Flow Specs对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Ipv4 Flow Specs | Session=${Session} |
    """

    result = renix.create_bgp_ipv4_flow_specs(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_flow_specs_actions(FlowSpec, **kwargs):
    """
    创建Bgp Ipv4 Flow Specs Actions对象, 类型为：object / list

    Args:

        FlowSpec(:obj:`BgpIpv4FlowSpecConfig`): BGP Flow Spec对象, 类型为：object / list

    Keyword Args:

        EnableTrafficRate (bool): 启用流量限速动作。类型为：bool, 取值范围：True或False, 默认值：True

        TrafficRate (int): 类型为：number, 取值范围：1-4294967295, 默认值：0

        AsNum (int): 指定AS号。类型为：number, 取值范围：1-4294967295, 默认值：1

        EnableTrafficAction (bool): 启用Traffic action。类型为：bool, 取值范围：True或False, 默认值：True

        SampleBit (bool): 启用流量抽样记录。类型为：bool, 取值范围：True或False, 默认值：True

        TerminateBit (bool): 撤销已生效的匹配规则。类型为：bool, 取值范围：True或False, 默认值：True

        EnableRedirect: 启用流量重定向到指定的路由目标动作。类型为：bool, 取值范围：True或False, 默认值：False

        RouteTarget (str): 指定重定向的路由目标。类型为：string, 默认值："100:1"

        EnableTrafficMarking (bool): 启用重新标记报文DSCP值的动作。类型为：bool, 取值范围：True或False, 默认值：True

        DSCPValue (int): 以十六进制形式指定重新标记报文所使用的DSCP值。类型为：number, 取值范围：1-4294967295, 默认值：0

        EnableRedirectToIpNextHop (bool): 启用重定向到下一跳动作, 类型为：bool, 取值范围：True或False, 默认值：False

        NextHop (str): 指定下一跳IP, 类型为有效的ipv4地址, 默认值: "0.0.1.0"

        CopyBit (bool): 复制一份规则匹配的流量，并执行重定向到下一跳动作。类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`BgpIpv4FlowSpecAction`): Bgp Ipv4 Flow Specs Actions对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${FlowSpec} | Create Bgp Ipv4 Flow Specs | Session=${Session} |
            | Create Bgp Ipv4 Flow Specs Action | FlowSpec=${FlowSpec} |
    """

    result = renix.create_bgp_flow_specs_actions(FlowSpec=FlowSpec, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_flow_spec_conponent_type(FlowSpec, Types, **kwargs):
    """
    创建Bgp Flow Specs Conponent Type对象, 类型为：object / list

    Args:

        FlowSpec(:obj:`BgpIpv4FlowSpecConfig`): BGP Flow Spec对象, 类型为：object / list

        Types (int): BGP IPv4 FLowSpec Type序号, 类型为：number, 取值范围：1-12

    Keyword Args:

        IpValue (str): 指定起始地址, 类型为有效的ipv4地址, 默认值: "192.0.1.0"

        PrefixLength (int): 指定前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

        AddressList (str): 类型为列表时, 指定地址列表, 类型为有效的ipv4地址, 默认值: ""

        InputType (str): 指定类型, 类型为：string, 默认值：RANGE, 取值范围：

            RANGE

            LIST

            RFC_4814

        Count (int): 地址数量, 类型为：number, 取值范围：1-99, 默认值：1

        Step (int): 地址跳变步长, 类型为：number, 取值范围：1-4294967295, 默认值：1

        EqualBit (bool): 数据与指定值相等表示匹配, 类型为：bool, 取值范围：True或False, 默认值：False

        LessThanBit (bool): 数据小于指定值表示匹配, 类型为：bool, 取值范围：True或False, 默认值：False

        MoreThanBit (bool): 数据大于指定值表示匹配, 类型为：bool, 取值范围：True或False, 默认值：False

        AndBit (bool): 如果选中And Bit，则该{option/value}组与前一个{option/value}组之间的关系是逻辑与（AND）；如果未选中And Bit，则该{option/value}组与前一个{option/value}组之间的关系是逻辑或（OR）。类型为：bool, 取值范围：True或False, 默认值：False

        ValueField (int): 类型为：number, 取值范围：1-15, 默认值：1

        Count (int): 类型为：number, 取值范围：0-99, 默认值：1

        ValueIncrement (int): 类型为：number, 取值范围：0-65535, 默认值：1

        ValueList (int): 类型为：number, 取值范围：0-65535, 默认值：""

        ValueType (str): 指定值的类型, 类型为：string, 默认值：Increment, 取值范围：

            Increment

            List

        NotBit (bool): 选中Not Bit时，对计算结果按位取反。类型为：bool, 取值范围：True或False, 默认值：False

        MatchBit (bool): 选中Match Bit时，(data & value) == value表示按位匹配；未选中Match Bit时，如果数据中包含值掩码，则(data & value) == True表示匹配。其中，data是发送的数据，value是给定的值掩码。类型为：bool, 取值范围：True或False, 默认值：False

        DSCPValue (int): 类型为：number, 取值范围：0-63, 默认值：0

    Returns:

        (:obj:`BgpIpv4FlowSpecType1Component`): Bgp Flow Spec Conponent Type对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${FlowSpec} | Create Bgp Ipv4 Flow Specs | Session=${Session} |
            | Create Bgp Flow Spec Conponent Type | FlowSpec=${FlowSpec} | Type=1 |
    """

    result = renix.create_bgp_flow_spec_conponent_type(FlowSpec=FlowSpec, Types=Types, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_flow_spec_custom_path_attribute(FlowSpec, **kwargs):
    """
    创建BGP Flow Spec Custom Path Attribute对象, 类型为：object / list

    Args:

        FlowSpec(:obj:`BgpIpv4FlowSpecConfig`): 所属的Bgp Flow Spec对象, 类型为：object / list

    Keyword Args:

        PathAttributeType (int): 路径属性的类型, 类型为：number, 取值范围：1-255, 默认值：1

        OptionalFlag (str): 指定Optional Flag的值, 类型为：string, 默认值：OPTION, 取值范围：

            WELL_KNOWN

            OPTION

        TransitiveFlag (str): 指定Transitive Flag的值, 类型为：string, 默认值：NONTRANSITIVE, 取值范围：

            NONTRANSITIVE

            TRANSITIVE

        PartialFlag (str): 指定Partial Flag的值, 类型为：string, 默认值：PARTIAL, 取值范围：

            COMPLETE

            PARTIAL

        ExtendedLengthFlag (bool): 是否启用Extended Length Flag, 类型为：bool, 默认值：False

        AttributeValue (str): 指定路径属性的值, 类型为：string, 默认值：""

    Returns:

        (:obj:`BgpFlowSpecPathAttributeConfig`): Bgp Route Pool Custom Path Attribute对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${FlowSpecs} | Create Bgp Ipv4 Flow Specs | Session=${Session} |
            | Create Bgp Flow Spec Custom Path Attribute | FlowSpec=${FlowSpecs} |
    """

    result = renix.create_bgp_flow_spec_custom_path_attribute(FlowSpec=FlowSpec, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv6_flow_spec(Session, **kwargs):
    """
    创建BGP Ipv6 Flow Spec对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象, 类型为：object / list

    Keyword Args:

        RouteCount (int): 类型为：number, 取值范围：1-8000000, 默认值：1

        FlowSpecSubAfi (str): 指定SubAFI的值, 类型为：string, 默认值：FlowSpec, 取值范围：

            FlowSpec

            FlowSpecVpn

        FlowSpecActionType (str): 指定Optional Flag的值, 类型为：string, 默认值：RedirectRT, 取值范围：

            RedirectRT

        ComponentType (list): 指定Transitive Flag的值, 类型为：list, 默认值：Type1, 取值范围：

            Type1

            Type2

        DestinationPrefix (str): 指定Partial Flag的值, 类型为：有效的ipv6地址, 默认值：2000::1

        DestinationPrefixLength (bool): 是否启用Extended Length Flag, 类型为：bool, 默认值：False

        DestinationPrefixIncrement (int): 指定路径属性的长度, 类型为：number, 取值范围：1-128, 默认值：64

        DestinationPrefixCount (int): 指定路径属性的值, 类型为：number, 取值范围：1-65535, 默认值：1

        DestinationPrefixOffset (int): 目的IP前缀偏移, 类型为：number, 默认值：0

        SourcePrefix (str): 源IP前缀, 类型为：有效的ipv6地址, 默认值：2000::1

        SourcePrefixLength (int): 源IP前缀长度, 类型为：number, 取值范围：1-128, 默认值：64

        SourcePrefixIncrement (int): 源IP前缀偏移, 类型为：number, 取值范围：1-4294967295, 默认值：1

        SourcePrefixCount (int): 源IP前缀个数, 类型为：number, 取值范围：1-65535, 默认值：1

        SourcePrefixOffset (int): 源IP前缀偏移, 类型为：number, 取值范围：0-255, 默认值：0

        Origin (str): 指定ORIGIN的值, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        AsPathType (str): AS Path类型, 类型为：string, 默认值：SEQUENCE, 取值范围：

            SET

            SEQUENCE

        EnableLocalPref (bool): 是否启用Local_PREF属性。类型为：bool, 取值范围：True或False, 默认值：True

        LocalPref (int): 指定Local_PREF的值。类型为：number, 取值范围：1-4294967295, 默认值：10

        EnableMed (bool): 是否启用MULTI_EXIT_DISC属性。类型为：bool, 取值范围：True或False, 默认值：False

        MultExitDisc (int): 指定Multi Exit Discriminator的值。类型为：number, 取值范围：1-4294967295, 默认值：0

        EnableClusterIdList (bool): 是否启用Cluster ID List, 类型为：bool, 取值范围：True或False, 默认值：False

        ClusterIdList (str): 指定cluster ID list的值, 类型为：有效的ipv4地址, 默认值：""

        EnableCommunity (bool): 类型为：bool, 取值范围：True或False, 默认值：False

        CommunityType (str): 团体类型, 类型为：string, 默认值：AA_NN, 取值范围：

            AA_NN

            NO_EXPORT

            NO_ADVERTISE

            LOCAL_AS

        CommunityAsNumber (int): 当Type为AA:NN时，指定团体的AS号, 类型为：number, 取值范围：1-65535, 默认值：1

        CommunityId (int): 当Type为AA:NN时，指定团体的ID值, 类型为：number, 取值范围：1-65535, 默认值：1

        Community (str): 当Type为NO_EXPORT时，团体值为0xffffff01；当Type为NO_ADVERTISE时，团体值为0xffffff02；当Type为LOCAL_AS时，团体值为0xffffff03, 类型为：string, 默认值：""

        ExtendedCommunity (str): 扩展团体, 类型为：string, 默认值：""

        VrfNum (int): VRF数量, 类型为：number, 默认值：1

        VrfRouteTarget (str): 指定VRF路由目标起始值, 类型为：string, 默认值：100:1

        VrfRouteTargetStep (str): 指定VRF路由目标的跳变步长, 类型为：string, 默认值：0:1

        VrfRouteDistinguisher (str): 指定VRF路由标识起始值, 类型为：string, 默认值：1:1

        VrfRouteDistinguisherStep (str): 指定VRF路由标识的跳变步长, 类型为：string, 默认值：0:1

    Returns:

        (:obj:`BgpIpv6FlowSpecConfig`): Bgp Ipv6 Flow Spec对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${FlowSpecs} | Create Bgp Ipv6 Flow Specs | Session=${Session} |
    """

    result = renix.create_bgp_ipv6_flow_spec(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_ipv6_flow_spec_action(FlowSpec, **kwargs):
    """
    创建Bgp Ipv6 Flow Specs Actions对象, 类型为：object / list

    Args:

        FlowSpec(:obj:`BgpIpv6FlowSpecConfig`): BGP Flow Spec对象, 类型为：object / list

    Keyword Args:

        EnableTrafficRate (bool): 启用流量限速动作。类型为：bool, 取值范围：True或False, 默认值：True

        TrafficRate (int): 指定流量的最大传输速率, 类型为：number, 取值范围：1-4294967295, 默认值：0

        AsNum (int): 指定AS号。类型为：number, 取值范围：1-4294967295, 默认值：1

        EnableTrafficAction (bool): 启用Traffic action。类型为：bool, 取值范围：True或False, 默认值：True

        SampleBit (bool): 启用流量抽样记录。类型为：bool, 取值范围：True或False, 默认值：True

        TerminateBit (bool): 撤销已生效的匹配规则。类型为：bool, 取值范围：True或False, 默认值：True

        EnableRedirect (bool): 启用流量重定向到指定的路由目标动作。类型为：bool, 取值范围：True或False, 默认值：False

        RedirectIpv6RouteTarget (str): 指定重定向的路由目标。类型为：string, 默认值："100:1"

        EnableRedirectToIpv6NextHop (bool): 启用重定向到下一跳动作, 类型为：bool, 取值范围：True或False, 默认值：False

        Type (str): 类型为：string, 默认值："TYPE_0x000c", 取值范围：

            TYPE_0x0800

            TYPE_0x000c

        NextHop (str): 指定下一跳IP, 类型为有效的ipv6地址, 默认值: "2000::1"

        CopyBit (bool): 复制一份规则匹配的流量，并执行重定向到下一跳动作。类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`BgpIpv6FlowSpecAction`): Bgp Ipv6 Flow Specs Actions对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${FlowSpec} | Create Bgp Ipv6 Flow Specs | Session=${Session} |
            | Create Bgp Ipv6 Flow Specs Action | FlowSpec=${FlowSpec} |
    """

    result = renix.create_bgp_ipv6_flow_spec_action(FlowSpec=FlowSpec, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_sr_te_policy(Session, **kwargs):
    """
    创建Bgp Sr Te Policy对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：list

    Keyword Args:

        BindingSidCount (int): Binding SID数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        PolicyColor (int): 指定SR Policy的起始Color值, 类型为：number, 默认值：0

        PolicyColorStep (int): 指定Policy Color的跳变步长, 类型为：number, 默认值：1

        IpVersion (str): 指定IP前缀类型, 类型为：string, 默认值：IPV4, 取值范围：

            IPV4

            IPV6

        EndpointCount (int): 指定目的节点的数量。该参数值不能大于Binding SID数量。类型为：number, 取值范围：1-4294967295, 默认值：1

        Ipv4Endpoint (str): 指定Policy块中目的节点的起始IP地址, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        Ipv4EndpointStep (str): 指定Policy块中目的节点的IP地址的跳变步长, 类型为：有效的ipv4地址, 默认值：0.0.0.1

        Ipv6Endpoint (str): 指定Policy目的节点的IP地址, 类型为：有效的ipv6地址, 默认值：2000::1

        Ipv6EndpointStep (str): 指定Policy目的节点的IP地址, 类型为：有效的ipv6地址, 默认值：2000::1

        EndpointIncrementMode (str): 指定Policy块中目的节点IP地址的生成方式, 类型为：string, 默认值：RoundRobin, 取值范围：

            RoundRobin

            Sequential

        Origin (str): 指定ORIGIN的值, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 指定AS路径的值, 类型为：string, 默认值：""

        AsPathType (str): AS Path类型, 类型为：string, 默认值：SEQUENCE, 取值范围：

            SET

            SEQUENCE

            CONFED_SEQUENCE

            CONFED_SET

        LocalPref (int): 指定Local_PREF的值, 类型为：number, 默认值：10

        UseSessionAddressAsNextHop (bool): 使用会话地址作为下一跳地址, 类型为：bool, 默认值：True

        Ipv4NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        Ipv6NextHop (str): 下一跳地址，即UPDATE消息中NEXT_HOP的值, 类型为：有效的ipv6地址, 默认值：2001::1

        Distinguisher (int): 输入SR Policy标识, 类型为：number, 取值范围：1-4294967295, 默认值：0

        RouteTarget (str): 指定重定向的路由目标。类型为：string, 默认值：""

        Community (str): 当Type为NO_EXPORT时，团体值为0xffffff01；当Type为NO_ADVERTISE时，团体值为0xffffff02；当Type为LOCAL_AS时，团体值为0xffffff03, 类型为：string, 默认值：""

        ExtendedCommunity (str): 扩展团体, 类型为：string, 默认值："0x03:0x0b:0:0"

        SrTePolicySubTlv (list): 选择一个或多个TLV, 类型为：list, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            REMOTE_ENDPOINT

            COLOR

            PREFERENCE

            BINDING_SID

            ENLP

            PRIORITY

            EGRESS_ENDPOINT

            POLICY_CP_NAME

            SRV6_BSID

            POLICY_NAME

        RemoteEndpointAsn (int): 远端Endpoint自治域号, 类型为：number, 取值范围：1-4294967295, 默认值：0

        Ipv4RemoteEndpoint (str): IPv6远端Endpoint, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        Ipv6RemoteEndpoint (str): IPv6远端Endpoint, 类型为：有效的ipv6地址, 默认值：2000::1

        Color (int): 指定Color扩展团体中Color Value字段的值, 类型为：number, 取值范围：1-4294967295, 默认值：0

        ColorFlags (list): 指定Color扩展团体中Flags字段的值, 类型为：list, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            C_FLAG

            O_FLAG

        Preference (int): 指定SR Policy中候选路径的优先级, 类型为：number, 取值范围：1-4294967295, 默认值：0

        BsidFlags (str): Binding SID Flags, 类型为：string, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            S_FLAG

            I_FLAG

        BsidLength (str): Binding SID长度, 类型为：string, 默认值：NO_SHOW, 取值范围：

            OCTET_0

            OCTET_4

            OCTET_16

        BsidLabel (int): Binding SID标签, 类型为：number, 取值范围：1-4294967295, 默认值：0

        BsidLabelStep (int): Binding SID标签跳变, 类型为：number, 取值范围：1-4294967295, 默认值：1

        BsidTc (int): 指定BSID中的S字段值, 类型为：number, 取值范围：0-7, 默认值：0

        BsidS (int): 指定BSID中的S字段值, 类型为：number, 取值范围：0-1, 默认值：0

        BsidTtl (int): 指定BSID中的TTL字段值, 类型为：number, 默认值：0

        Ipv6Bsid (str): 指定IPv6 BSID, 类型为：有效的ipv6地址, 默认值：2000::1

        Ipv6BsidStep (str): 指定IPv6 BSID的跳变步长, 类型为：有效的ipv6地址, 默认值：::1

        Enlp (str): 指定显式空标签策略, 类型为：string, 默认值：IPV4, 取值范围：

            RESERVED0

            IPV4

            IPV6

        PolicyPriority (int): 指定拓扑改变后重新计算SR Policy时的Policy优先级, 类型为：number, 取值范围：1-255, 默认值：0

        Srv6BsidFlags (list): 指定SRv6 Binding SID sub-TLV中包含的Flag, 类型为：list, 默认值：NO_SHOW(0x0), 取值范围：

            NO_SHOW

            S_FLAG

            I_FLAG

            B_FLAG

        Srv6Bsid (str): 指定SRv6 BSID, 类型为：有效的ipv6地址, 默认值：2000::1

        Srv6BsidStep (str): 指定SRv6 BSID的跳变步长, 类型为：有效的ipv6地址, 默认值：::1

        Srv6BsidEndpointBehavior (int): 指定SRv6 SID Endpoint Behavior, 类型为：number, 取值范围：1-65535, 默认值：0

        Srv6BsidLbLength (int): 指定SRv6 SID Function长度。类型为：number, 取值范围：1-255, 默认值：0

        Srv6BsidLnLength (int): 指定SRv6 SID Locator Node长度。单位：比特, 类型为：number, 取值范围：1-255, 默认值：0

        Srv6BsidFunLength (int): 指定SRv6 SID Function长度。单位：比特, 类型为：number, 取值范围：1-255, 默认值：0

        Srv6BsidArgLength (int): 指定SRv6 SID参数长度。单位：比特, 类型为：number, 取值范围：1-255, 默认值：0

        CandidatePathName (str): Policy候选路径名称, 类型为：string, 默认值：""

        PolicyName (str): 指定Policy的名称, 类型为：string, 默认值：""

        TunnelEgressEndpointAfi (str): 隧道出口端点AFI, 类型为：string, 默认值：IPV4, 取值范围：

            RESERVED0

            IPV4

            IPV6

        Ipv4TunnelEgressEndpoint (str): IPv4远端Endpoint, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        Ipv6TunnelEgressEndpoint (str): IPv6远端Endpoint, 类型为：有效的ipv6地址, 默认值：2000::1

    Returns:

        (:obj:`BgpSrTePolicyConfig`): Bgp Sr Te Policy对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Sr Te Policy | Session=${Session} |
    """

    result = renix.create_bgp_sr_te_policy(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_sr_te_policy_Segement_list(Session, SrTePolicy, **kwargs):
    """
    创建Bgp Sr Te Policy Segement List对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

        SrTePolicy(:obj:`BgpSrTePolicyConfig`): BGP Sr Te Policy对象, 类型为：object / list

    Keyword Args:

        SubTlvs (list): 选择一个或多个子TLV, 类型为：list, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            WEIGHT

        Weight (int): 指定Segment List（SID列表）对应的权重, 类型为：number, 取值范围：1-4294967295, 默认值：1

    Returns:

        (:obj:`BgpSrTePolicySegmentList`): Bgp Sr Te Policy Segement List对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${SrTe} | Create Bgp Sr Te Policy | Session=${Session} |
            | Create Bgp Sr Te Policy Segement List | Session=${Session} | SrTePolicy=${SrTe} |
    """

    result = renix.create_bgp_sr_te_policy_Segement_list(Session=Session, SrTePolicy=SrTePolicy, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_segement_sub_tlv(Session, SegementList, Types, **kwargs):
    """
    创建Bgp Segement Sub Tlv对象, 类型为：object

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

        SegementList(:obj:`BgpSrTePolicySegmentList`): BGP Sr Te Policy Segement List对象, 类型为：object

        Types (str): BGP Sr Te Policy Segement Sub Tlv类型, 类型为string, 默认值: A, 取值范围：A-K

    Keyword Args:

        Flags (list): 选择一个或多个Flag, 类型为：list, 默认值：NO_SHOW, 取值范围：

            NO_SHOW

            V_FLAG

            A_FLAG

            S_FLAG

            B_FLAG

        Label (int): 指定标签, 类型为：number, 取值范围：1-1048575, 默认值：1600

        LabelStep (int): 指定标签跳变, 类型为：number, 取值范围：1-1048575, 默认值：1

        Tc (int): 指定TC（Traffic Class，通信量类）值, 类型为：number, 取值范围：0-7, 默认值：0

        Sbit (int): 指定栈底标志（S）的值, 类型为：number, 取值范围：0-1, 默认值：1

        Ttl (int): 指定TTL值, 类型为：number, 取值范围：1-1048575, 默认值：255

        Srv6Sid (str): 指定SRv6 SID, 类型为：有效的ipv6地址, 默认值：2000::1

        Srv6SidStep (str): 指定SRv6 SID的跳变步长, 类型为：有效的ipv6地址, 默认值：::1

        EndpointBehavior (int): 指定SRv6 Endpoint Behavior, 类型为：number, 取值范围：1-1048575, 默认值：0

        LbLength (int): SRv6 SID Locator Block长度, 类型为：number, 取值范围：1-1048575, 默认值：0

        LnLength (int): SRv6 SID Locator Node长度, 类型为：number, 取值范围：1-1048575, 默认值：0

        FunLength (int): SRv6 SID Function长度, 类型为：number, 取值范围：1-1048575, 默认值：0

        ArgLength (int): SRv6 SID参数长度, 类型为：number, 取值范围：1-1048575, 默认值：0

        SrAlgorithm (int): SR算法, 类型为：number, 取值范围：1-1048575, 默认值：0

        Ipv4NodeAddress (str): IPv4节点地址, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        Ipv4NodeAddressStep (str): IPv4节点地址跳变, 类型为：有效的ipv4地址, 默认值：0.0.0.1

        Ipv6NodeAddress (str): IPv6节点地址, 类型为：有效的ipv6地址, 默认值：2000::1

        Ipv6NodeAddressStep (str): IPv6节点地址跳变, 类型为：有效的ipv6地址, 默认值：::1

        LocalInterfaceId: 本地Interface ID, 类型为：number, 取值范围：1-1048575, 默认值：0

        LocalIpv4Address (str): IPv4节点地址, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        LocalIpv4AddressStep (str): IPv4节点地址跳变, 类型为：有效的ipv4地址, 默认值：0.0.0.1

        RemoteIpv4Address (str): 远端IPv4地址, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        RemoteIpv4AddressStep (str): 远端IPv4地址跳变, 类型为：有效的ipv4地址, 默认值：0.0.0.1

        LocalIpv6NodeAddress (str): IPv6本地节点地址, 类型为：有效的ipv6地址, 默认值：2000::1

        LocalIpv6NodeAddressStep (str): IPv6本地节点地址跳变, 类型为：有效的ipv6地址, 默认值：::1

        RemoteInterfaceId (int): 远端Interface ID, 类型为：number, 取值范围：1-1048575, 默认值：0

        RemoteIpv6NodeAddress (str): IPv6远端节点地址, 类型为：有效的ipv6地址, 默认值：2000::1

        RemoteIpv6NodeAddressStep (str): IPv6远端节点地址跳变, 类型为：有效的ipv6地址, 默认值：::1

    Returns:

        (:obj:`BgpSegmentSubTlvTypeA`): Bgp Segement Sub Tlv对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${SrTe} | Create Bgp Sr Te Policy | Session=${Session} |
            | ${SrTeSegmentList} | Create Bgp Sr Te Policy Segement List | Session=${Session} | SrTePolicys=${SrTe} |
            | Create Bgp Segement Sub Tlv | Session=${Session} | SrTePolicys=${SrTe} | Types=B |
    """

    result = renix.create_bgp_segement_sub_tlv(Session=Session, SegementList=SegementList, Types=Types, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_link_states(Session, **kwargs):
    """
    创建Bgp Link States对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

    Keyword Args:

        Origin (str): 路由产生源, 类型为：string, 默认值：IGP, 取值范围：

            IGP

            EGP

            INCOMPLETE

        AsPath (str): 自治域路径, 类型为：string, 默认值：""

        AsPathType (str): 自治域路径类型, 类型为：string, 默认值：SEQUENCE, 取值范围：

            SET

            SEQUENCE

            CONFED_SEQUENCE

            CONFED_SET

        NextHop (str): 下一跳, 类型为：有效的ipv4地址, 默认值：10.0.0.1

        IPv6NextHop (str): IPv6下一跳, 类型为：有效的ipv6地址, 默认值：2001::1

        EnableLinkLocalNextHop (bool): 使能下一跳本地链路地址, 类型为：bool, 取值范围：True或False, 默认值：True

        LinkLocalNextHop (str): 下一跳本地链路地址, 类型为：有效的ipv6地址, 默认值：fe80::1

        LocalPreference (int): 本地优先级, 类型为：number, 默认值：10

        Community (str): 团体, 当Type为NO_EXPORT时，团体值为0xffffff01；当Type为NO_ADVERTISE时，团体值为0xffffff02；当Type为LOCAL_AS时，团体值为0xffffff03, 类型为：string, 默认值：""

        ExtendedCommunity (str): 扩展团体, 类型为：string, 默认值：""

        ProtocolID (str): 协议ID, 类型为：string, 默认值：DIRECT, 取值范围：

            ISIS_LEVEL_1

            ISIS_LEVEL_2

            OSPFV2

            DIRECT

            STATIC

            OSPFV3

            BGP

        IdentifierType (str): 标识符类型, 类型为：string, 默认值：CUSTOMIZED, 取值范围：

            DEFAULT_LAYER3

            CUSTOMIZED

        Identifier (int): 标识符, 类型为：number, 取值范围：1-1048575, 默认值：0

        EnableNodeNLRI (bool): 使能节点NLRI, 类型为：bool, 取值范围：True或False, 默认值：True

        LocalNodeDescriptorFlag (list): 本地节点描述符标志, 类型为：list, 默认值：IGP_ROUTER_ID, 取值范围：

            AS_NUMBER

            BGPLS_IDENTIFIER

            OSPF_AREA_ID

            IGP_ROUTER_ID

            BGP_ROUTER_ID

            MEMBER_ASN

        AsNumber (int): 自治域, 类型为：number, 取值范围：1-4294967295, 默认值：1

        BgpLsIdentifier (str): BGP-LS标识符, 类型为：有效的ipv4地址, 默认值：1.0.0.1

        OspfAreaId (str): OSPF区域ID, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        IGPRouterIdType (str): IGP路由ID类型, 类型为：string, 默认值：OSPF_NONPSEUDONODE, 取值范围：

            ISIS_NONPSEUDONODE

            ISIS_PSEUDONODE

            OSPF_NONPSEUDONODE

            OSPF_PSEUDONODE

        IsisNonPseud (str): ISIS非伪节点路由ID, 类型为：string, 默认值："00:10:12:00:00:01"

        IsisPseud (str): ISIS伪节点路由ID, 类型为：string, 默认值："00:10:12:00:00:01.02"

        OspfNonPseud (str): OSPF非伪节点路由ID, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        OspfPseud (str): OSPF伪节点路由ID, 类型为：string, 默认值："192.0.0.1:192.0.0.1"

        BgpRouterId: BGP路由ID, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        MemberAsn (int): 自治域成员, 类型为：number, 取值范围：1-4294967295, 默认值：0

        LocalNodeAttributeFlag (str): 本地节点描述符标志 类型为：string, 默认值：NODE_FLAG_BITS, 取值范围：

            MULTI_TOPO_ID

            NODE_FLAG_BITS

            NODE_NAME

            ISIS_AREA_ID

            IPV4_LOCAL_NODE_ROUTERID

            IPV6_LOCAL_NODE_ROUTERID

            SR_CAPABILITIES

            SR_ALGORITHM

            SR_LOCAL_BLOCK

            SR_SRMA_PREF

            SRV6_CAPABILITIES

            SRV6_NODE_MSD

        MultiTopoId (str): 多拓扑ID, 类型为：string, 取值范围：1-4095, 默认值：""

        NodeFlagBitIsis (str): 节点标志（ISIS）, 类型为：string, 默认值：ATTACHED, 取值范围：

            OVERLOAD

            ATTACHED

        NodeFlagBitOspfv2 (list): 节点标志（OSPFv2）, 类型为：list, 默认值：ABR, 取值范围：

            EXTERNAL

            ABR

        NodeFlagBitOspfv3 (list): 节点标志（OSPFv3）, 类型为：list, 默认值：ABR, 取值范围：

            EXTERNAL
            ABR
            ROUTER
            V6

        NodeName (str): 节点名称, 类型为：string, 默认值：""

        IsisAreaId (int): IS-IS区域ID, 类型为：number, 取值范围：1-4294967295, 默认值：0

        LocalIpv4RouterIds (str): 本端IPv4路由IDs, 类型为：有效的ipv4地址, 默认值：""

        LocalIpv6RouterIds (str): 本端IPv6路由IDs, 类型为：有效的ipv6地址, 默认值：""

        SidLabelType (str): SID/Label类型, 类型为：string, 默认值：BIT20_LABEL, 取值范围：

            BIT20_LABEL

            BIT32_SID

        SrCapabilitiesFlags (list): SR能力标志, 类型为：list, 默认值：MPLS_IPv4, 取值范围：

            MPLS_IPv4

            MPLS_IPv6

        SrCapabilities (str): SR能力, 类型为：string, 默认值："16:100"

        SrAlgorithm (int): SR算法, 类型为：number, 取值范围：1-255, 默认值：0

        SrLocalBlock (str): SRLB范围, 类型为：string, 默认值："16:100"

        SrmsPref (int): SRMS优先级, 类型为：number, 取值范围：1-255, 默认值：0

        Srv6CapabilitiesFlags (list): SRv6能力标志, 类型为：list, 默认值：O_FLAG, 取值范围：

            UNUSED0

            O_FLAG

            UNUSED2

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

            UNUSED8

            UNUSED9

            UNUSED10

            UNUSED11

            UNUSED12

            UNUSED13

            UNUSED14

            UNUSED15

        Srv6MsdFlags (list): SRv6节点MSD类型, 类型为：list, 默认值：NONE, 取值范围：

            NONE

            MAX_SEGMENTS_LELT

            MAX_END_POP

            MAX_T_INSERT_SRH

            MAX_T_ENCAPS_SRH

            MAX_END_D_SRH

        Srv6MsdMaxSegmentLeft (int): 最大Segments Left, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxEndPop (int): 最大End Pop, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxInsert (int): 最大T.Insert SRH, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxEncap (int): 最大T.Encaps SRH, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxEndD (int): 最大End D SRH, 类型为：number, 取值范围：1-255, 默认值：8

    Returns:

        (:obj:`BgpLsNodeConfig`): Bgp Link States对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | Create Bgp Link States | Session=${Session} |
    """

    result = renix.create_bgp_link_states(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_link_states_link(Session, LinkState, **kwargs):
    """
    创建Bgp Link States Link对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

        LinkState(:obj:`BgpLsNodeConfig`): Bgp Link States对象列表, 类型为：object / list

    Keyword Args:

        LinkLocalRemoteIdFlag (str): 链路本端/远端ID位置, 类型为：string, 默认值：NONE, 取值范围：

            NONE

            LINK_DESCRIPTOR

            LINK_ATTRIBUTE

        LinkLocalId (int): 链路本端ID, 类型为：number, 取值范围：1-4294967295, 默认值：0

        LinkRemoteId (int): 链路远端ID, 类型为：number, 取值范围：1-4294967295, 默认值：0

        RemoteNodeDescriptorFlag (str): 远端节点描述符标志, 类型为：string, 默认值：IGP_ROUTER_ID, 取值范围：

            AS_NUMBER

            BGPLS_IDENTIFIER

            OSPF_AREA_ID

            IGP_ROUTER_ID

            BGP_ROUTER_ID

            MEMBER_ASN

        AsNumber (int): 自治域, 类型为：number, 取值范围：1-4294967295, 默认值：1

        BgpLsIdentifier (str): BGP-LS标识符, 类型为：有效的ipv4地址, 默认值：1.0.0.1

        OspfAreaId (str): OSPF区域ID, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        IGPRouterIdType (str): IGP路由ID类型, 类型为：string, 默认值：OSPF_NONPSEUDONODE, 取值范围：

            ISIS_NONPSEUDONODE

            ISIS_PSEUDONODE

            OSPF_NONPSEUDONODE

            OSPF_PSEUDONODE

        IsisNonPseud (str): ISIS非伪节点路由ID, 类型为：string, 默认值："00:10:12:00:00:01"

        IsisPseud (str): OSPF伪节点路由ID, 类型为：string, 默认值："00:10:12:00:00:01.02"

        OspfNonPseud (str): OSPF非伪节点路由ID, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        OspfPseud (str): OSPF伪节点路由ID, 类型为：string, 默认值："192.0.0.1:192.0.0.1"

        BgpRouterId (str): BGP路由ID, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        MemberAsn (int): 自治域成员, 类型为：number, 取值范围：1-1048575, 默认值：0

        LinkDescriptorFlag (list): 链路描述符标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            LINK_IDENTIFIES

            IPV4_INTERFACE

            IPV4_NEIGHBOR

            IPV6_INTERFACE

            IPV6_NEIGHBOR

            MULTI_TOPOLOGY

        Ipv4InterfaceAddr (str): IPv4接口地址, 类型为：有效的ipv4地址, 默认值：192.168.0.1

        Ipv4NeighborAddr (str): IPv4邻接地址, 类型为：有效的ipv4地址, 默认值：192.168.0.2

        Ipv6InterfaceAddr (str): IPv6接口地址, 类型为：有效的ipv6地址, 默认值：2001::1

        Ipv6NeighborAddr (str): IPv6邻接地址, 类型为：有效的ipv6地址, 默认值：2001::2

        MultiTopologyId (int): 多拓扑ID, 类型为：number, 取值范围：1-4095, 默认值：“”

        LinkAttributeFlag (list): 链路属性标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            IPV4_LOCAL_NODE

            IPV4_REMOTE_NODE

            IPV6_LOCAL_NODE

            IPV6_REMOTE_NODE

            LINK_IDENTIFIES

            LINK_PROTECTION_TYPE

            IGP_METRIC

            SHARED_RISE

            ADI_SID

            LAN_ADJ_SID

            PEERNODE_SID

            PEERADJ_SID

            PEERSET_SID

            SRV6_LINK_MSD

            SRV6_END_X_SID

            SRV6_LAN_END_X_SID

        LocalIpv4RouterIds (str): 本端IPv4路由IDs, 类型为：有效的ipv4地址, 默认值：""

        RemoteIpv4RouterIds (str): 远端IPv4路由IDs, 类型为：有效的ipv4地址, 默认值：""

        LocalIpv6RouterIds (str): 本端IPv6路由IDs, 类型为：有效的ipv6地址, 默认值：""

        RemoteIpv6RouterIds (str): 远端IPv6路由IDs, 类型为：有效的ipv6地址, 默认值：""

        IgpMetricType (str): IGP度量类型, 类型为：string, 默认值：UNKNOWN, 取值范围：

            ISIS_NARROW

            OSPFv2_LINK

            ISIS_WIDE

        IgpMetricValue (int): IGP度量值, 类型为：number, 取值范围：IS-IS Narrow Metrics：0-255, OSPFv2 Link Metrics：0-65535, IS-IS Wide Metrics：0-16777215, 默认值：0

        LinkProteType (list): 链路保护类型, 类型为：list, 默认值：UNKNOWN, 取值范围：

            EXTRA_TRAFFIC

            UNPROTECTED

            SHARED

            DEDICATED1

            DEDICATED2

            ENHANCED

            RESERVED4

            RESERVED8

        ShareRiskGroup (int): SRLG信息, 类型为：number, 取值范围：1-4294967295, 默认值：""

        OspfAdjSidFlag (list): OSPF SR邻接SID标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            BACKUP

            VALUE

            LOCAL

            GROUP

            PERSISTENT

        IsisAdjSidFlag (list): ISIS SR邻接SID标志, 类型为：list, 默认值：NOSHOW, 取值范围：

            NOSHOW

            ADDRESS

            BACKUP

            VALUE

            LOCAL

            SET

            PERSISTENT

        AdjSidWeight (int): 权重, 类型为：number, 取值范围：1-255, 默认值：1

        AdjSidLabel (int): SID/Label, 类型为：number, 取值范围：1-255, 默认值：16

        OspfNeighborId (str): OSPF邻居ID, 类型为：有效的ipv4地址, 默认值：192.0.1.0

        IsisSystemId (str): ISIS系统ID, 类型为：有效的mac地址, 默认值：00:00:00:00:00:00

        PeerNodeFlag (list): Peer Node标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            VALUE

            LOCAL

            BACKUP

            PERSISTENT

        PeerNodeWeight (int): Peer Node权重, 类型为：number, 取值范围：1-255, 默认值：1

        PeerNodeSidLabel (int): Peer Node SID/Index/Label, 类型为：number, 取值范围：1-255, 默认值：16

        PeerAdjFlag (list): Peer Adj标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            VALUE

            LOCAL

            BACKUP

            PERSISTENT

        PeerAdjWeight (int): Peer Adj权重, 类型为：number, 取值范围：1-255, 默认值：1

        PeerAdjSidLabel (int): Peer Adj权重, 类型为：number, 取值范围：1-255, 默认值：16

        PeerSetFlag (list): Peer Set标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            VALUE

            LOCAL

            BACKUP

            PERSISTENT

        PeerSetWeight (int): Peer Set权重, 类型为：number, 取值范围：1-255, 默认值：1

        PeerSetSidLabel (int): Peer Set SID/Index/Label, 类型为：number, 取值范围：1-255, 默认值：16

        Srv6MsdFlags (list): SRv6链路MSD类型, 类型为：list, 默认值：NONE, 取值范围：

            NONE

            MAX_SEGMENTS_LELT

            MAX_END_POP

            MAX_T_INSERT_SRH

            MAX_T_ENCAPS_SRH

            MAX_END_D_SRH

        Srv6MsdMaxSegmentLeft (int): 最大Segments Left, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxEndPop (int): 最大End Pop, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxInsert (int): 最大T.Insert SRH, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxEncap (int): 最大T.Encaps SRH, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6MsdMaxEndD (int): 最大End D SRH, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6EndXSidEndpointBehavior (str): SRv6 Endpoint功能指令类型, 类型为：string, 默认值：CUSTOM, 取值范围：

            END

            END_WITH_PSP

            END_WITH_USP

            END_WITH_PSP_USP

            END_X

            END_X_WITH_PSP

            END_X_WITH_USP

            END_X_WITH_PSP_USP

            END_T

            END_T_WITH_PSP

            END_T_WITH_USP

            END_T_WITH_PSP_USP

            END_B6_ENCAPS

            END_BM

            END_DX6

            END_DX4

            END_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DT2U

            END_DT2M

            END_B6_ENCAPS_RED

            END_WITH_USD

            END_WITH_PSP_USD

            END_WITH_USP_USD

            END_WITH_PSP_USP_USD

            END_X_WITH_USD

            END_X_WITH_PSP_USD

            END_X_WITH_USP_USD

            END_X_WITH_PSP_USP_USD

            END_T_WITH_USD

            END_T_WITH_PSP_USD

            END_T_WITH_USP_USD

            END_T_WITH_PSP_USP_USD

            CUSTOM

        Srv6EndXSidFlag (list): SRv6 End.X SID标志, 类型为：list, 默认值：NONE, 取值范围：

            NONE

            BACKUP_FLAG

            SET_FLAG

            PERSISTENT_FLAG

        Srv6EndXSidAlgorithm (int): SRv6 End.X SID算法, 类型为：number, 取值范围：1-255, 默认值：8

        Srv6EndXSidWeight (int): SRv6 End.X SID权重, 类型为：number, 取值范围：1-255, 默认值：1

        Srv6EndXSidSid (str): SRv6 End.X SID, 类型为：有效的ipv6地址, 默认值：::1

        Srv6LanEndXSidSystemId (str): ISIS邻居ID, 类型为：有效的mac地址, 默认值：00:00:00:00:00:00

        Srv6LanEndXSidRouterId (str): OSPFv3邻居ID, 类型为：有效的ipv4地址, 默认值：192.0.0.1

        EnableInterfaceIp (bool): 启用本端IPv4地址, 类型为：bool, 取值范围：True或False, 默认值：False

        InterfaceIp (str): 本端IPv4地址, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        EnableNeighborIp (bool): 启用远端IPv4地址, 类型为：bool, 取值范围：True或False, 默认值：False

        NeighborIp (str): 远端IPv4地址, 类型为：有效的ipv4地址, 默认值：0.0.0.0

        EnableInterfaceIpv6 (bool): 启用本端IPv6地址, 类型为：bool, 取值范围：True或False, 默认值：False

        InterfaceIpv6 (str): 本端IPv6地址, 类型为：有效的ipv4地址, 默认值：2000::1

        EnableNeighborIpv6 (bool): 启用远端IPv6地址, 类型为：bool, 取值范围：True或False, 默认值：False

        NeighborIpv6 (str): 启用远端IPv6地址, 类型为：有效的ipv6地址, 默认值：2000::1

        EnableGroup (bool): 启用组, 类型为：bool, 取值范围：True或False, 默认值：False

        Group (int): 组, 类型为：number, 取值范围：1-4294967295, 默认值：1

        EnableUniLinkLoss (bool): 启用单向链路损耗, 类型为：bool, 取值范围：True或False, 默认值：False

        LinkLoss (int): 链路损耗, 类型为：number, 取值范围：1-100, 默认值：3

        LinkLossAflag (bool): 链路损耗的A-flag, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableUniDelay (bool): 启用单向延迟, 类型为：bool, 取值范围：True或False, 默认值：False

        UniDelay (int): 单向延迟, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UniAflag (bool): 单向延迟的A-flag, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableUniMinMaxDelay (bool): 启用单向延迟最小/最大值, 类型为：bool, 取值范围：True或False, 默认值：False

        UniMinMaxAflag (bool): 启用单向延迟最小/最大值的A-flag类型为：bool, 取值范围：True或False, 默认值：False

        UniMinDelay (int): 单向最小延迟, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UniMaxDelay (int): 单向最大延迟, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniDelayVariation (bool): 启用单向延迟变化, 类型为：bool, 取值范围：True或False, 默认值：False

        UniVarDelay (int): 单向延迟变化, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniResidual (bool): 启用单向剩余带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        UniResBandwidth (int): 单向剩余带宽, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniAva (bool): 启用单向可用带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        UniAvaBandwidth (int): 单向可用带宽, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUniUtilized (bool): 启用单向已用带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        UniUtilized (int): 单向已用带宽, 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableMaximum (bool): 启用最大带宽(字节/秒), 类型为：bool, 取值范围：True或False, 默认值：False

        Maximum (int): 最大带宽(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableReservable (bool): 启用预留带宽(字节/秒), 类型为：bool, 取值范围：True或False, 默认值：False

        Reservable (int): 预留带宽(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableUnreserved (bool): 启用未预留带宽优先级(字节/秒), 类型为：bool, 取值范围：True或False, 默认值：False

        UnreservedBandwidth0 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth1 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth2 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth3 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth4 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth5 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth6 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        UnreservedBandwidth7 (int): 未预留带宽优先级(字节/秒), 类型为：number, 取值范围：1-4294967295, 默认值：100000

        EnableTeDefaultMetric (bool): 启用TE默认度量, 类型为：bool, 取值范围：True或False, 默认值：False

        TeDefaultValue (int): TE默认度量, 类型为：number, 取值范围：1-4294967295, 默认值：0

    Returns:

        (:obj:`BgpLsLinkConfig`): Bgp Link States Link对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${LinkState} | Create Bgp Link States | Sessions=${Session} |
            | Create Bgp Link States Link | Sessions=${Session} | LinkState=${LinkState} |
    """

    result = renix.create_bgp_link_states_link(Session=Session, LinkState=LinkState, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_link_states_prefix(Session, LinkState, **kwargs):
    """
    创建Bgp Link States Prefix对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

        LinkState(:obj:`BgpLsNodeConfig`): Bgp Link States对象列表, 类型为：object / list

    Keyword Args:

        PrefixDescriptorFlag (list): LS前缀描述符标志, 类型为：list, 默认值：IP_REACH_INFO, 取值范围：

            MULTI_TOPOLOGY

            OSPF_ROUTE_TYPE

            IP_REACH_INFO

        OspfRouteType (str): OSPF路由类型, 类型为：string, 默认值：INTRA_AREA, 取值范围：

            INTRA_AREA

            INTER_AREA

            EXTERNAL1

            EXTERNAL2

            NSSA1

            NSSA2

        PrefixCount (int): 地址前缀个数, 类型为：number, 取值范围：1-65535, 默认值：1

        PrefixType (str): 地址前缀类型, 类型为：string, 默认值：IPV4, 取值范围：

            IPV4

            IPV6

        Ipv4Prefix (str): IPv4地址前缀, 类型为：有效的ipv4地址, 默认值：1.0.0.0

        Ipv4PrefixLength (int): IPv4地址前缀步长, 类型为：number, 取值范围：1-32, 默认值：24

        Ipv4PrefixStep (int): IPv4地址前缀步长, 类型为：number, 取值范围：1-65535, 默认值：1

        Ipv6Prefix (str): IPv6地址前缀, 类型为：有效的ipv6地址, 默认值：2000::1

        Ipv6PrefixLength (int): IPv6地址前缀步长, 类型为：number, 取值范围：1-128, 默认值：64

        Ipv6PrefixStep (int): IPv6地址前缀长度, 类型为：number, 取值范围：1-65535, 默认值：1

        MultiTopologyId (int): 多拓扑ID, 类型为：number, 取值范围：1-4095, 默认值：“”

        OspfSrPrefixSidFlag (list): OSPF SR前缀SID标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            NO_PHP

            MAPPING_SERVER

            EXPLICIT_NULL

            VALUE

            LOCAL

        IsisSrPrefixSidFlag (list): ISIS SR前缀SID标志, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            RE_ADVER

            NODESID

            NO_PHP

            EXPLICIT_NULL

            VALUE

            LOCAL

        PrefixAttributeFlag (str): LS前缀描述符标志, 类型为：string, 默认值：UNKNOWN|IGP_FLAGS, 取值范围：

            UNKNOWN

            IGP_FLAGS

            PREFIX_METRIC

            OSPF_FORWARDING

            SR_PREFIX_SID

            SR_RANGE

            SR_ATTRIBUTE_FLAG

            SR_SOURCE

            SRV6_LOCATOR_TLV

        IgpFlag (str): IGP标志, 类型为：string, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            ISIS_UP_DOWN

            OSPF_NO_UNICAST

            OSPF_LOCAL_ADDRESS

            OSPF_PROPAGATE_NSSA

        PrefixMetric (int): 前缀度量, 类型为：number, 取值范围：1-4294967295, 默认值：0

        OspfForwardtype (str): OSPF转发地址类型, 类型为：string, 默认值：OSPFV2, 取值范围：

            OSPFV2

            OSPFV3

        Ospfv2ForwardAddr (str): OSPFv2转发地址, 类型为：有效的ipv4地址, 默认值：192.168.1.1

        Ospfv3ForwardAddr (str): OSPFv3转发地址, 类型为：有效的ipv6地址, 默认值：2000::1

        OspfSrPrefixFlag (str): OSPF SR前缀SID标志, 类型为：string, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            NO_PHP

            MAPPING_SERVER

            EXPLICIT_NULL

            VALUE

            LOCAL

        IsisSrPrefixFlag (str): ISIS SR前缀SID标志, 类型为：string, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            RE_ADVER

            NODESID

            NO_PHP

            EXPLICIT_NULL

            VALUE

            LOCAL

        Algorithm (int): 算法, 类型为：number, 取值范围：1-255, 默认值：0

        SidLabelIndex (int): SID/Label/Index, 类型为：number, 取值范围：0-1048575 (20比特值), 0-4294967295 (32比特值), 默认值：0

        Ospfv2SrPrefixAttributeFlag (list): OSPFv2 SR前缀属性标志, 类型为：list, 默认值：NODE, 取值范围：

            ATTACH

            NODE

        Ospfv3SrPrefixAttributeFlag (list): OSPFv3 SR前缀属性标志, 类型为：list, 默认值：NO_UNICAST, 取值范围：

            NO_UNICAST

            LOCAL_ADDRESS

            MULTICAST

            PROPAGATE

            RE_ADVER

            HOST

        IsisSrPrefixAttributeFlag (list): ISIS SR前缀属性标志, 类型为：list, 默认值：NODE, 取值范围：

            EXTERNAL_PREFIX

            RE_ADVER

            NODE

        SrSourceIpv4Id (str): SR IPv4源路由ID, 类型为：有效的ipv4地址, 默认值：192.168.1.0

        SrSourceIpv6Id (str): SR IPv6源路由ID, 类型为：有效的ipv6地址, 默认值：2000::1

        Ospfv2SrRangeFlag (list): OSPFv2 SR范围标志, 类型为：list, 默认值：INTER_AREA, 取值范围：

            INTER_AREA

        IsisSrRangeFlag (list): ISIS SR范围标志, ISIS SR前缀SID标志, 类型为：list, 默认值：ATTACHED, 取值范围：

            ADDRESS_FAMILY

            MIRROR_CONTEXT

            S_FLAG

            D_FLAG

            ATTACHED

        SrRangeSubTlv (str): SR范围Sub-TLVs, 类型为：string, 默认值："0 Range Sub-TLV"

        Srv6LocatorFlag (str): SRv6 Locator标志, 类型为：string, 默认值：NONE, 取值范围：

            NONE

            D_FLAG

        Srv6LocatorAlgorithm (int): SRv6 Locator算法, 类型为：number, 取值范围：1-255, 默认值：0

        Srv6LocatorMetric (int): SRv6 Locator度量值, 类型为：number, 取值范围：1-4294967295, 默认值：0

    Returns:

        (:obj:`BgpLsPrefixConfig`): Bgp Link States Prefix对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${LinkState} | Create Bgp Link States | Sessions=${Session} |
            | Create Bgp Link States Prefix | Sessions=${Session} | LinkState=${LinkState} |
    """

    result = renix.create_bgp_link_states_prefix(Session=Session, LinkState=LinkState, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_link_states_prefix_sr_range_sub_tlv(Session, LinkStatePrefix, **kwargs):
    """
    创建Bgp Link States Prefix Sr Range Sub Tlv对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

        LinkStatePrefix(:obj:`BgpLsPrefixConfig`): Bgp Link States prefix对象列表, 类型为：object / list

    Keyword Args:

        Algorithm (int): 算法, 类型为：number, 取值范围：1-255, 默认值：0

        OspfSrPrefixSidFlag (list): OSPF SR Prefix SID Flags, 类型为：list, 默认值：UNKNOWN, 取值范围:

            UNKNOWN

            NO_PHP

            MAPPING_SERVER

            EXPLICIT_NULL

            VALUE

            LOCAL

        IsisSrPrefixSidFlag (list): ISIS SR Prefix SID Flags, 类型为：list, 默认值：UNKNOWN, 取值范围:

            UNKNOWN

            RE_ADVER

            NODESID

            NO_PHP

            EXPLICIT_NULL

            VALUE

            LOCAL

        SidLabelIndex (int): SID/Label/Index, 类型为：number, 取值范围：1-255, 默认值：0

    Returns:

        (:obj:`BgpLsSrRangeSubTlvConfig`): Bgp Link States Prefix Sr Range Sub Tlv对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${LinkState} | Create Bgp Link States | Sessions=${Session} |
            | ${prefix} | Create Bgp Link States Prefix | LinkState=${LinkState} |
            | Create Bgp Link States Prefix Sr Range Sub Tlv | Sessions=${Session} | LinkStatePrefix=${prefix} |
    """

    result = renix.create_bgp_link_states_prefix_sr_range_sub_tlv(Session=Session,
                                                                  LinkStatePrefix=LinkStatePrefix, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bgp_link_states_srv6_sid(Session, LinkState, **kwargs):
    """
    创建Bgp Link States Srv6 Sid对象, 类型为：object / list

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象列表, 类型为：object / list

        LinkState(:obj:`BgpLsNodeConfig`): Bgp Link States对象列表, 类型为：object / list

    Keyword Args:

        Srv6AttributeFlag (list): SRv6 SID属性标志, 类型为：list, 默认值：SRV6_ENDPOINT_BEHAVIOR, 取值范围：

            SRV6_ENDPOINT_BEHAVIOR

            SRV6_BGP_PEER_NODE_SID

            SRV6_SID_STRUCTURE

        Srv6EndpointBehavior (str): SRv6 Endpoint功能指令类型, 类型为：string, 默认值：CUSTOM, 取值范围：

            END

            END_WITH_PSP

            END_WITH_USP

            END_WITH_PSP_USP

            END_X

            END_X_WITH_PSP

            END_X_WITH_USP

            END_X_WITH_PSP_USP

            END_T

            END_T_WITH_PSP

            END_T_WITH_USP

            END_T_WITH_PSP_USP

            END_B6_ENCAPS

            END_BM

            END_DX6

            END_DX4

            END_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DT2U

            END_DT2M

            END_B6_ENCAPS_RED

            END_WITH_USD

            END_WITH_PSP_USD

            END_WITH_USP_USD

            END_WITH_PSP_USP_USD

            END_X_WITH_USD

            END_X_WITH_PSP_USD

            END_X_WITH_USP_USD

            END_X_WITH_PSP_USP_USD

            END_T_WITH_USD

            END_T_WITH_PSP_USD

            END_T_WITH_USP_USD

            END_T_WITH_PSP_USP_USD

            CUSTOM

        Srv6EndpointBehaviorFlag (list): SRv6 Endpoint功能指令标志, 类型为：list, 默认值：NONE, 取值范围：

            NONE

            UNUSED0

            UNUSED1

            UNUSED2

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

        Srv6EndpointBehaviorAlgorithm (int): SRv6 Endpoint功能指令算法, 类型为：number, 取值范围：1-255, 默认值：0

        Srv6BgpPeerNodeSidFlag (list): EPE Peer Node SID标志, 类型为：list, 默认值：0, 取值范围：

            NONE

            BACKUP_FLAG

            SET_FLAG

            PERSISTENT_FLAG

        Srv6BgpPeerNodeSidWeight (int): EPE Peer Node SID权重, 类型为：number, 取值范围：1-255, 默认值：0

        Srv6BgpPeerNodeSidPeerAsNumber (int): Peer自治域, 类型为：number, 取值范围：1-4294967295, 默认值：1001

        Srv6BgpPeerNodeSidPeerBgpId (int): Peer BGP标识符, 类型为：number, 取值范围：1-4294967295, 默认值：0

        Srv6SidStructureLbLength (int): SRv6 Locator Block长度, 类型为：number, 取值范围：1-255, 默认值：32

        Srv6SidStructureLnLength (int): SRv6 Locator Node长度, 类型为：number, 取值范围：1-255, 默认值：32

        Srv6SidStructureFunLength (int): SRv6 Function长度, 类型为：number, 取值范围：1-255, 默认值：32

        Srv6SidStructureArgLength (int): SRv6 Argument长度, 类型为：number, 取值范围：1-255, 默认值：32

        Srv6Sid (str): 类型为：有效的ipv6地址, 默认值：::1

        MultiTopologyId (int): 多拓扑ID, 类型为：number, 取值范围：1-4095, 默认值：“”

    Returns:

        (:obj:`BgpLsSrv6SidConfig`): Bgp Link States Srv6 Sid对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bgp | Port=${Port} |
            | ${LinkState} | Create Bgp Link States | Sessions=${Session} |
            | Create Bgp Link States Srv6 Sid | Sessions=${Session} | LinkState=${LinkState} |
    """

    result = renix.create_bgp_link_states_srv6_sid(Session=Session, LinkState=LinkState, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bgp_evpn_routes_statistic(Session=None, StaItems: list = None):
    """
    获取Bgp Evpn Routes统计结果

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            TxAdRouteCount

            RxAdRouteCount

            TxMacIpRouteCount

            RxMacIpRouteCount

            TxInclusiveMcastRouteCount

            RxInclusiveMcastRouteCount

            TxEthernetSegmentRouteCount

            RxEthernetSegmentRouteCount

            TxIpPrefixRouteCount

            RxIpPrefixRouteCount

            TxWithdrawnAdRouteCount

            RxWithdrawnAdRouteCount

            TxWithdrawnMacIpRouteCount

            RxWithdrawnMacIpRouteCount

            TxWithdrawnInclusiveMcastRouteCount

            RxWithdrawnInclusiveMcastRouteCount

            TxWithdrawnEthernetSegmentRouteCount

            RxWithdrawnEthernetSegmentRouteCount

            TxWithdrawnIpPrefixRouteCount

            RxWithdrawnIpPrefixRouteCount

    Returns:

        dict: eg::

            {
                'TxAdRouteCount': 10,
                'RxAdRouteCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=EvpnRoutesStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bgp Evpn Routes Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bgp_evpn_routes_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bgp_link_state_statistic(Session=None, StaItems: list = None):
    """
    获取Bgp Evpn Routes统计结果

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            TxAdvertisedNodeCount

            RxAdvertisedNodeCount

            TxWithdrawnNodeCount

            RxWithdrawnNodeCount

            TxAdvertisedLinkCount

            RxAdvertisedLinkCount

            TxWithdrawnLinkCount

            RxWithdrawnLinkCount

            TxAdvertisedIpv4PrefixCount

            RxAdvertisedIpv4PrefixCount

            TxWithdrawnIpv4PrefixCount

            RxWithdrawnIpv4PrefixCount

            TxAdvertisedIpv6PrefixCount

            RxAdvertisedIpv6PrefixCount

            TxWithdrawnIpv6PrefixCount

            RxWithdrawnIpv6PrefixCount

            TxAdvertisedSrv6SidCount

            RxAdvertisedSrv6SidCount

            TxWithdrawnSrv6SidCount

            RxWithdrawnSrv6SidCount

    Returns:

        dict: eg::

            {
                'TxAdRouteCount': 10,
                'RxAdRouteCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=BgpLinkStateStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bgp Link State Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bgp_link_state_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bgp_session_statistic(Session=None, Id=1, StaItems=None):
    """
    获取Bgp Session统计结果

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象, 类型为：Object

        Id (int): Bgp Peer Id, 类型为：number

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            PeerState

            TxOpen

            RxOpen

            TxKeepalive

            RxKeepalive

            TxUpdate

            RxUpdate

            TxAdvertisedUpdate

            RxAdvertisedUpdate

            TxWithdrawnUpdate

            RxWithdrawnUpdate

            TxAdvertisedRoutes

            RxAdvertisedRoutes

            TxWithdrawnRoutes

            RxWithdrawnRoutes

            LastTxUpdateRoutes

            LastRxUpdateRoutes

            TxNotification

            RxNotification

            TxRefresh

            RxRefresh

    Returns:

        dict: eg::

            {
                'TxAdRouteCount': 10,
                'RxAdRouteCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=BgpSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bgp Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bgp_session_statistic(Session=Session, Id=Id, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bgp_session_block_statistic(Session=None, StaItems: list = None):
    """
    获取Bgp Session Block统计结果

    Args:

        Session (:obj:`BgpRouter`): BGP协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            PeerState

            TxOpen

            RxOpen

            TxKeepalive

            RxKeepalive

            TxUpdate

            RxUpdate

            TxAdvertisedUpdate

            RxAdvertisedUpdate

            TxWithdrawnUpdate

            RxWithdrawnUpdate

            TxAdvertisedRoutes

            RxAdvertisedRoutes

            TxWithdrawnRoutes

            RxWithdrawnRoutes

            LastTxUpdateRoutes

            LastRxUpdateRoutes

            TxNotification

            RxNotification

            TxRefresh

            RxRefresh

    Returns:

        dict: eg::

            {
                'TxAdRouteCount': 10,
                'RxAdRouteCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=BgpSessionBlockStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bgp Session Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bgp_session_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_bgp_port_config(Ports, **kwargs):
    """
    修改Bgp端口统计对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        BgpUpdateMessageRate (int): BGP Update Messages Tx Rate (messages/sec), 取值范围：1-1000, 默认值：10

        SessionConnectDelay (int): BGP Session Connect Delay (ms), 取值范围：1-10000, 默认值：100

        SessionDisconnectDelay (int): BGP Session Disconnect Delay (ms), 取值范围：1-10000, 默认值：100

        BgpSrVersion (str): BGP SR Version, 默认值：RFC8669, 取值范围：

            RFC8669

        SrgbBase (int): Global SRGB Base, 取值范围：0-16777215, 默认值：16000

        SrgbRange (int): Global SRGB Range, 取值范围：0-16777215, 默认值：1000

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Bgp Port Config | Ports=${Ports} | BgpUpdateMessageRate=100 |
    """

    result = renix.edit_bgp_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def sent_bgp_data(Session, Data):
    """
    发送自定义BGP协议报文数据

    Args:

        Session (:obj:`BgpRoute`): BGP协议会话对象

        Data (string): 十六进制数据

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Sent Bgp Data | Session=${Session} |
    """

    result = renix.sent_bgp_data(Session=Session, Data=Data)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------IGMP-------------------------------------
def create_igmp(Port, **kwargs):
    """
    创建IGMP协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): IGMP协会话名称, 类型为：string

        Enable (bool): 使能ICMP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：IGMPV2, 支持版本：

            IGMPV1

            IGMPV2

            IGMPV3

        PackReports (bool): 合并报告报文, 类型为：bool, 取值范围：True或False, 默认值：False

        InitialJoin (bool): 单个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustJoin (bool): 多个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustnessVariable (int): Robust值, 类型为：number, 取值范围：2-255, 默认值：2

        UnsolicitedReportInterval (int): 发送初始报文的时间间隔 (秒), 类型为：number, 取值范围：0-65535, 默认值：10

        ForceLeave (bool): 强制发送Leave报文, 类型为：bool, 取值范围：True或False, 默认值：True

        RouterPresentTimeout (int): IGMPv1路由器存在的超时时间 (秒), 类型为：number, 取值范围：0-65535, 默认值：400

        NotFragment (bool): 设置IP头报文分片标志位, 类型为：bool, 取值范围：True或False, 默认值：False

        TosValue (Hex or int): 设置IP头TOS值 (十进制或者十六进制), 类型为：hex or int, 取值范围：0x00-0xFF, 默认值：0xc0

    Returns:

        (:obj:`Igmp`): IGMP协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Igmp | Port=${Port} | Version=IGMPV3 |
    """

    result = renix.create_igmp(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_igmp(Session, **kwargs):
    """
    编辑IGMP协议会话对象

    Args:

        Session(:obj:`Igmp`): IGMP协会话对象, 类型为：object

    Keyword Args:

        Name (str): IGMP协会话名称, 类型为：string

        Enable (bool): 使能ICMP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：IGMPV2, 支持版本：

            IGMPV1

            IGMPV2

            IGMPV3

        PackReports (bool): 合并报告报文, 类型为：bool, 取值范围：True或False, 默认值：False

        InitialJoin (bool): 单个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustJoin (bool): 多个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustnessVariable (int): Robust值, 类型为：number, 取值范围：2-255, 默认值：2

        UnsolicitedReportInterval (int): 发送初始报文的时间间隔 (秒), 类型为：number, 取值范围：0-65535, 默认值：10

        ForceLeave (bool): 强制发送Leave报文, 类型为：bool, 取值范围：True或False, 默认值：True

        RouterPresentTimeout (int): IGMPv1路由器存在的超时时间 (秒), 类型为：number, 取值范围：0-65535, 默认值：400

        NotFragment (bool): 设置IP头报文分片标志位, 类型为：bool, 取值范围：True或False, 默认值：False

        TosValue (bool): 设置IP头TOS值 (Hex), 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Igmp | Port=${Port} | Version=IGMPV1 | RouterPresentTimeout=500 |
    """

    result = renix.edit_igmp(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def select_source_interface(Session, Memberships, Interface):
    """
    将协议会话组播组过滤源地址绑定到指定接口

    Args:

        Session (:obj:`Igmp`): IGMP/MLD协会话对象, 类型为：object

        Memberships (:obj:`MldMembershipsConfig`): 组播协议和组播组绑定关系对象, 类型为：object

        Interface (:obj:`Interface`): 测试仪表接口对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Interface} |  create_interface | Port=${Port} |
            | ${Group} | Create Multicast Group | Version=IPV4 | Start=225.0.1.1 | Number=20 |
            | ${Session} | Create Igmp | Port=${Port} | Version=IGMPV3 |
            | ${Memberships} | Create Memberships | Session=${Session} | Start=225.0.1.1 | DeviceGroupMapping=ONETOONE |
            | binding_multicast_group | Session=${Session} | Memberships=${Memberships} | MulticastGroup=${Group} |
            | Select Source Interface | Session=${Session} | Memberships=${Memberships} | Interface=${Interface} |
    """

    result = renix.select_source_interface(Session=Session, Memberships=Memberships, Interface=Interface)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_igmp_state(Sessions, State='MEMBER', Interval=1, TimeOut=60):
    """
    等待Igmp协议会话达到指定状态

    Args:

        Sessions (list (:obj:`Igmp`)): Igmp协议会话对象列表

        State (str): 等待Igmp协议会话达到的状态, 默认值：达到MEMBER, 支持下列状态：

            NONMEMBER
            JOINING
            MEMBER
            LEAVING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Igmp State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_igmp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def igmp_send_report(Sessions):
    """
    IGMP客户端加入组

    Args:

        Sessions (list (:obj:`Igmp`)): IGMP协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Igmp Send Report | Sessions=${Session} |
    """

    result = renix.igmp_send_report(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def igmp_send_leave(Sessions):
    """
    IGMP客户端离开组

    Args:

        Sessions (list (:obj:`Igmp`)): IGMP协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Igmp Send Leave | Sessions=${Session} |
    """

    result = renix.igmp_send_leave(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def igmp_resend_report(Sessions):
    """
    IGMP客户端重新加入组

    Args:

        Sessions (list (:obj:`Igmp`)): IGMP协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Igmp Resend Report | Sessions=${Session} |
    """

    result = renix.igmp_resend_report(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_igmp_host_statistic(Session=None, StaItems=None):
    """
    获取Igmp协议会话统计结果

    Args:

        Session (:obj:`Igmp`): Igmp协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            IgmpTxFrames

            IgmpRxFrames

            IgmpRxUnknownTypes

            IgmpRxChecksumErrors

            IgmpRxLengthErrors

    Returns:

        dict: eg::

            {
                'IgmpTxFrames': 8,
                'IgmpRxFrames': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | IgmpTxFrames | IgmpRxFrames |
            | Subscribe Result | Types=IgmpHostResults |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Igmp Host Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_igmp_host_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_igmp_port_statistic(Port=None, StaItems=None):
    """
    获取Igmp Port统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            IgmpTxFrames

            IgmpRxFrames

            IgmpTxV1Reports

            IgmpTxV2Reports

            IgmpTxLeaveGroups

            IgmpTxV3Reports

            IgmpTxV3ModeInclude

            IgmpTxV3ModeExclude

            IgmpTxV3ModeChangeToInclude

            IgmpTxV3ModeChangeToExclude

            IgmpTxV3ModeAllowNewSources

            IgmpTxV3ModeBlockOldSources

            IgmpRxV1Queries

            IgmpRxV2Queries

            IgmpRxV3Queries

            IgmpRxGeneralQueries

            IgmpRxGroupSpecificQueries

            IgmpRxGroupAndSourceSpecificQueries

            IgmpRxUnknownTypes

            IgmpRxChecksumErrors

            IgmpRxLengthErrors

    Returns:

        dict: eg::

            {
                'IgmpTxFrames': 8,
                'IgmpRxFrames': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | IgmpTxFrames | IgmpRxFrames |
            | Subscribe Result | Types=IgmpPortAggregatedResults |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Igmp Port Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_igmp_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------IGMP Querier-------------------------------------
def create_igmp_querier(Port, **kwargs):
    """
    创建IGMP Querier协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): IGMP Querier协会话名称, 类型为：string

        Enable (bool): 使能IGMP Querier协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：IGMPV2, 支持版本：

            IGMPV1

            IGMPV2

            IGMPV3

        RobustnessVariable (int): 健壮系数, 取值范围：2-255, 默认值: 2

        Interval (int): 查询时间间隔（秒）, 取值范围：0-4294967295, 默认值: 125

        QueryResponseInterval (int): 查询响应时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 10000

        StartupQueryCount (int): 初始查询报文个数, 取值范围：1-255, 默认值：2

        LastMemberQueryInterval (int): 最后成员查询时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 1000

        LastMemberQueryCount (bool): 最后成员查询次数, 取值范围：0-255, 默认值: 2

        IPv4DoNotFragment (bool): 设置IP头报文分片标志位, 取值范围：True或False, 默认值: False

        IPv4TosValue (hex): 设置IP头TOS值, 类型为：hex, 取值范围：0x0-0xff, 默认值: 0xc0

    Returns:

        (:obj:`IgmpQuerier`): IGMP协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Igmp Querier| Port=${Port} | Version=IGMPV3 |
    """

    result = renix.create_igmp_querier(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_igmp_querier(Session, **kwargs):
    """
    编辑IGMP Querier协议会话对象

    Args:

        Session(:obj:`IgmpQuerier`): IGMP协会话对象, 类型为：object

    Keyword Args:

        Name (str): IGMP Querier协会话名称, 类型为：string

        Enable (bool): 使能ICMP Querier协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：IGMPV2, 支持版本：

            IGMPV1

            IGMPV2

            IGMPV3

        RobustnessVariable (int): 健壮系数, 取值范围：2-255, 默认值: 2

        Interval (int): 查询时间间隔（秒）, 取值范围：0-4294967295, 默认值: 125

        ResponseInterval (int): 查询响应时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 10000

        StartupQueryCount (int): 初始查询报文个数, 取值范围：1-255, 默认值：2

        LastMemberQueryInterval (int): 最后成员查询时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 1000

        LastMemberQueryCount (bool): 最后成员查询次数, 取值范围：0-255, 默认值: 2

        IPv4DoNotFragment (bool): 设置IP头报文分片标志位, 取值范围：True或False, 默认值: False

        IPv4TosValue (hex): 设置IP头TOS值, 类型为：hex, 取值范围：0x0-0xff, 默认值: 0xc0

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Igmp Querier | Port=${Port} | Version=IGMPV3 | IPv4TosValue=0xff |
    """

    result = renix.edit_igmp_querier(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def apply_igmp_querier(Sessions):
    """
    IGMP Querier增量配置下发到后台

    Args:

        Sessions (list (:obj:`IgmpQuerier`)): IGMP Querier协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Apply Igmp Querier |
    """

    result = renix.apply_igmp_querier(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_igmp_querier_state(Sessions, State='UP', Interval=1, TimeOut=60):
    """
    等待Igmp Querier协议会话达到指定状态

    Args:

        Sessions (list (:obj:`IgmpQuerier`)): Igmp Querier协议会话对象列表

        State (list): 等待Igmp Querier协议会话达到的状态, 默认值：达到UP, 支持下列状态：

            NOTSTARTED

            UP

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Igmp Querier State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_igmp_querier_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_igmp_querier_statistic(Session=None, StaItems=None):
    """
    获取Igmp Querier协议会话统计结果

    Args:

        Session (:obj:`IgmpQuerier`): Igmp协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            QuerierTxFrames

            QuerierRxFrames

            QuerierRxUnknownTypes

            QuerierRxChecksumErrors

            QuerierRxLengthErrors

    Returns:

        dict: eg::

            {
                'QuerierTxFrames': 8,
                'QuerierRxFrames': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | QuerierTxFrames | QuerierRxFrames |
            | Subscribe Result | Types=IgmpQuerierResults |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Igmp Querier Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_igmp_querier_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_igmp_port_config(Ports, **kwargs):
    """
    修改Igmp端口统计对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object / list

    Keyword Args:

        IgmpMaximumOutputRate (int): 最大发包速率(包/秒) , 取值范围：1-1000000000, 默认值：100

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Igmp Port Config | Ports=${Ports} | IgmpMaximumOutputRate=100 |
    """

    result = renix.edit_igmp_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

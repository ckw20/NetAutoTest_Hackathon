import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------ISIS-------------------------------------
def create_isis(Port, **kwargs):
    """
    创建ISIS协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): ISIS协会话名称, 类型为：string

        Enable (bool): 使能ISIS协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        IpVersion (str): IP版本, 类型为：string, 默认值：IPV4, 支持版本：

            IPV4

            IPV6

            IPV4IPV6

        Level (str): 区域类型, 类型为：string, 默认值：L2, 支持版本：

            L1

            L2

            L1L2

        NetworkType (str): 网络类型, 类型为：string, 默认值：BROADCAST, 支持参数：

            BROADCAST

            P2P

        SystemId (str): 系统ID, 类型为：string, 取值范围：MAC地址, 默认值：00:00:00:00:00:01

        Priority (int): 路由器优先级, 类型为：number, 取值范围：0-127, 默认值：0

        AuthMethod (str): 认证方式, 类型为：string, 默认值：NONE, 支持参数：

            NONE

            SIMPLE

            MD5

        Password (str): 4字节自治域跳变, 类型为：string, 默认值：Xinertel

        AuthSendOnly (bool): 默认值为False，AuthSendOnly设置为True时，仅发送认证信息

        CircuitId (int): 电路ID, 类型为：number, 取值范围：0-255, 默认值：1

        Area1 (str): 区域ID 1, 类型为：hex number, 取值范围：0x0-0xff, 默认值：0x10

        Area2 (str): 区域ID 2, 类型为：hex number, 取值范围：0x0-0xff, 默认值：空

        Area3 (str): 区域ID 3, 类型为：hex number, 取值范围：0x0-0xff, 默认值：空

        MetricMode (str): 度量模式, 类型为：string, 默认值：NARROWWIDE, 支持参数：

            NARROW

            WIDE

            NARROWWIDE

        TeRouterId (str): TE路由器ID, 类型为：string, 取值范围：IPv4地址, 默认值：192.168.1.1

        TeRouterIdIpv6 (str): IPv6 TE路由器ID, 类型为：string, 取值范围：IPv6地址, 默认值：3000::1

        HelloInterval (int): Hello PDU发送间隔(秒), 类型为：number, 取值范围：1-300, 默认值：10

        HelloMultiplier (int): Hello时间间隔倍数, 类型为：number, 取值范围：1-100, 默认值：3

        PsnInterval (int): PSNP发送间隔(秒), 类型为：number, 取值范围：1-20, 默认值：2

        LspRefreshTime (int): LSP刷新时间(秒), 类型为：number, 取值范围：1-65535, 默认值：900

        RetransInterval (int): LSP重传间隔(秒), 类型为：number, 取值范围：1-100, 默认值：5

        HelloPadding (bool): 类型为：bool, 取值范围：True或False, 默认值：True

        LspSize (int): LSP大小, 类型为：number, 取值范围：100-1492, 默认值：1492

        ValidateIpAddr (bool): 使能接口校验, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableBFD (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        MtParams (int): 多拓扑参数数量, 类型为：number, 取值范围：0-2, 默认值：0

        PerPduAuthentication (int): Per PDU认证数量, 类型为：number, 取值范围：0-4, 默认值：0

        ReportLabel (bool): 使能ReportLabel, 类型为：bool, 默认值：True

        LearnRoute (bool): 使能LearnRoute, 类型为：bool, 默认值：True

        RecordLspNextSequenceNum (bool): 使能Record Lsp Next Sequence Number, 类型为：bool, 默认值：True

        L1NarrowMetric (int): L1 Narrow Metric, 类型为：number, 取值范围：0-63, 默认值：1

        L1WideMetric (int): L1 Wild Metric, 类型为：number, 取值范围：0-16777214, 默认值：1

        L2NarrowMetric (int): L2 Narrow Metric, 类型为：number, 取值范围：0-63, 默认值：1

        L2WideMetric (int): L2 Wide Metric, 类型为：number, 取值范围：0-16777214, 默认值：1

        FloodLsp (bool): 默认值为True，FloodLsp设置为True时，邻居建立起来后通告Lsp信息，设置为false时，邻居建立后不通告Lsp信息

        HostName (str): 主机名称

    Returns:

        (:obj:`IsisRouter`): ISIS协议会话对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${MtId} | Create List | IPV4 | IPV6 |
            | ${{MtFlags} | Create List |  ABIT | OBIT |
            | Edit Isis | Session=${Session} | EnableViewRoutes=True | MtParams=1 |
    """

    result = renix.create_isis(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_isis(Session, **kwargs):
    """
    编辑ISIS协议会话对象参数

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): ISIS协会话名称, 类型为：string

        Enable (bool): 使能ISIS协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        IpVersion (str): IP版本, 类型为：string, 默认值：IPV4, 支持版本：

            IPV4

            IPV6

            IPV4IPV6

        Level (str): 区域类型, 类型为：string, 默认值：L2, 支持版本：

            L1

            L2

            L1L2

        NetworkType (str): 网络类型, 类型为：string, 默认值：BROADCAST, 支持参数：

            BROADCAST

            P2P

        SystemId (str): 系统ID, 类型为：string, 取值范围：MAC地址, 默认值：00:00:00:00:00:01

        Priority (int): 路由器优先级, 类型为：number, 取值范围：0-127, 默认值：0

        AuthMethod (str): 认证方式, 类型为：string, 默认值：NONE, 支持参数：

            NONE

            SIMPLE

            MD5

        Password (str): 4字节自治域跳变, 类型为：string, 默认值：Xinertel

        CircuitId (int): 电路ID, 类型为：number, 取值范围：0-255, 默认值：1

        Area1 (str): 区域ID 1, 类型为：hex number, 取值范围：0x0-0xff, 默认值：0x10

        Area2 (str): 区域ID 2, 类型为：hex number, 取值范围：0x0-0xff, 默认值：空

        Area3 (str): 区域ID 3, 类型为：hex number, 取值范围：0x0-0xff, 默认值：空

        MetricMode (str): 度量模式, 类型为：string, 默认值：NARROWWIDE, 支持参数：

            NARROW

            WIDE

            NARROWWIDE

        TeRouterId (str): TE路由器ID, 类型为：string, 取值范围：IPv4地址, 默认值：192.168.1.1

        TeRouterIdIpv6 (str): IPv6 TE路由器ID, 类型为：string, 取值范围：IPv6地址, 默认值：3000::1

        HelloInterval (int): Hello PDU发送间隔(秒), 类型为：number, 取值范围：1-300, 默认值：10

        HelloMultiplier (int): Hello时间间隔倍数, 类型为：number, 取值范围：1-100, 默认值：3

        PsnInterval (int): PSNP发送间隔(秒), 类型为：number, 取值范围：1-20, 默认值：2

        LspRefreshTime (int): LSP刷新时间(秒), 类型为：number, 取值范围：1-65535, 默认值：900

        RetransInterval (int): LSP重传间隔(秒), 类型为：number, 取值范围：1-100, 默认值：5

        HelloPadding (bool): 类型为：bool, 取值范围：True或False, 默认值：True

        LspSize (int): LSP大小, 类型为：number, 取值范围：100-1492, 默认值：1492

        ValidateIpAddr (bool): 使能接口校验, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableBFD (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        MtParams (int): 多拓扑参数数量, 类型为：number, 取值范围：0-2, 默认值：0

        PerPduAuthentication (int): Per PDU认证数量, 类型为：number, 取值范围：0-4, 默认值：0

        ReportLabel (bool): 使能ReportLabel, 类型为：bool, 默认值：True

        LearnRoute (bool): 使能LearnRoute, 类型为：bool, 默认值：True

        RecordLspNextSequenceNum (bool): 使能Record Lsp Next Sequence Number, 类型为：bool, 默认值：True

        L1NarrowMetric (int): L1 Narrow Metric, 类型为：number, 取值范围：0-63, 默认值：1

        L1WideMetric (int): L1 Wild Metric, 类型为：number, 取值范围：0-16777214, 默认值：1

        L2NarrowMetric (int): L2 Narrow Metric, 类型为：number, 取值范围：0-63, 默认值：1

        L2WideMetric (int): L2 Wide Metric, 类型为：number, 取值范围：0-16777214, 默认值：

        FloodLsp (bool): 默认值为True，FloodLsp设置为True时，邻居建立起来后通告Lsp信息，设置为false时，邻居建立后不通告Lsp信息

        AuthSendOnly (bool): 默认值为False，AuthSendOnly设置为True时，仅发送认证信息

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${MtId} | Create List | IPV4 | IPV6 |
            | ${{MtFlags} | Create List |  ABIT | OBIT |
            | Edit Isis | Session=${Session} | EnableViewRoutes=True | MtParams=1 |
    """

    result = renix.edit_isis(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_isis_global_options(**kwargs):
    """
    编辑ISIS协议global options参数

    Keyword Args:

        SRMSPerfType (int): SRMS Pref sub-TLV Type

        SRv6CapabilityType (int): SRv6 Capabilities sub-TLV type
        
        SRv6LocatorType (int): SRv6 Locator TLV type
        
        SRv6EndType (int): SRv6 End SID sub-TLV type
        
        SRv6EndXType (int): SRv6 End.X SID sub-TLV type
        
        SRv6LanEndXType (int): SRv6 LAN End.X SID sub-TLV type
        
        SRNodeMSDType (int): SR Node MSD sub-TLV type
        
        SRLinkMSDType (int): SR Link MSD sub-TLV type

        SRFAPM (int): Flex-Algo Prefix Metric sub-TLV type

        ScalabilityMode (str): 支持：NORMAL和DISCARD

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | edit_isis_global_options | SRMSPerfType=3 |
    """

    result = renix.edit_isis_global_options(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_isis_per_pdu(Session, Index=0, **kwargs):
    """
    编辑ISIS协议会话Per Pdu Authentication参数

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Index (int): ISIS协议会话Per Pdu Authentication参数对象序号，类型为：number, 取值范围：0-1, 默认值：0

    Keyword Args:

        PdusType (str): PDU类型, 类型为：string, 默认值：L1_HELLO, 支持参数：

            L1_HELLO

            L2_HELLO

            L1_AREA_PDUS

            L2_DOMAIN_PDUS

        AuthMethod (str): 认证类型, 类型为：string, 默认值：NONE, 支持参数：

            NONEReportLabel

            SIMPLE

            MD5

        Password (str): 认证密码, 类型为：string, 默认值：Xinertel.

        AuthSendOnly (bool): 默认值为False，AuthSendOnly设置为True时，仅发送认证信息

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${{MtFlags} | Create List |  ABIT | OBIT |
            | Edit Isis | Session=${Session} | EnableViewRoutes=True | PerPduAuthentication=1 |
            | Edit Isis Per Pdu | Session=${Session} | PdusType=L2_HELLO | AuthMethod=SIMPLE | Password=Test |
    """

    result = renix.edit_isis_per_pdu(Session=Session, Index=Index, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_isis_per_pdu(Session, Index=0):
    """
    获取ISIS协议会话Per Pdu Authentication参数

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Index (int): ISIS协议会话Per Pdu Authentication参数对象序号，类型为：number, 取值范围：0-4, 默认值：0

    Returns:

        dict: eg::

            {
                'PdusType': 'L1_HELLO',
                'AuthMethod': 'SIMPLE',
                'Password': 'Xinertel',
            }

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${{MtFlags} | Create List |  ABIT | OBIT |
            | ${Session} | Create Isis | Port=${Port} |
            | ${{MtFlags} | Create List |  ABIT | OBIT |
            | Edit Isis | Session=${Session} | EnableViewRoutes=True | PerPduAuthentication=1 |
            | Edit Isis Per Pdu Authentication | Session=${Session} | PdusType=L2_HELLO | AuthMethod=SIMPLE | Password=Test |
            | Get Isis Per Pdu Authentication | Session=${Session} | Index=0 |
    """

    result = renix.get_isis_per_pdu(Session=Session, Index=Index)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_isis_mt_params(Session, Index=0, MtId=None, MtFlags=None):
    """
    编辑ISIS协议会话MT参数

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Index (int): ISIS协议会话MT参数对象序号，类型为：number, 取值范围：0-1, 默认值：0

        MtId (str): 多拓扑ID, 类型为：string, 默认值：IPV4, 支持参数：

            IPV4

            IPV6

        MtFlags (list): 多拓扑Flags, 类型为：list, 默认值：NOSHOW, 支持参数：

            NOSHOW

            ABIT

            OBIT

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${{MtFlags} | Create List |  ABIT | OBIT |
            | Edit Isis | Session=${Session} | EnableViewRoutes=True | MtParams=1 |
            | Edit Isis Mt Params | Session=${Session} | MtId=IPV6 | MtFlags=${{MtFlags} |
    """

    result = renix.edit_isis_mt_params(Session=Session, Index=Index, MtId=MtId, MtFlags=MtFlags)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_isis_mt_params(Session, Index=0):
    """
    获取ISIS协议会话MT参数

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Index (int): ISIS协议会话MT参数对象序号，类型为：number, 取值范围：0-1, 默认值：0

    Returns:

        dict: eg::

            {
                'MtId': 'IPV4',
                'MtFlags': '['ABIT', 'OBIT'],
            }

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${{MtFlags} | Create List |  ABIT | OBIT |
            | Edit Isis | Session=${Session} | EnableViewRoutes=True | MtParams=2 |
            | Edit Isis Mt Params | Session=${Session} | Index=0 | MtId=IPv4 | MtFlags=${{MtFlags} |
            | Edit Isis Mt Params | Session=${Session} | Index=1 | MtId=IPv6 | MtFlags=${{MtFlags} |
            | Get Isis Mt Params | Session=${Session} | Index=0 |
            | Get Isis Mt Params | Session=${Session} | Index=1 |
    """

    result = renix.get_isis_mt_params(Session=Session, Index=Index)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_lsp(Session, **kwargs):
    """
    创建ISIS LSP对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): ISIS LSP对象名称, 类型为：string

        Enable (bool): 使能ISIS LSP, 类型为：bool, 取值范围：True或False, 默认值：True

        SystemId (str): 系统ID, 类型为：string, 取值范围：MAC地址, 默认值：00:00:00:00:00:01

        Level (str): 区域类型, 类型为：string, 默认值：L2, 支持版本：

            L1

            L2

        PseudonodeId (int): 伪节点ID, 类型为：number, 取值范围：1-100, 默认值：0

        TeRouterId (str): TE路由器ID, 类型为：string, 取值范围：IPv4地址, 默认值：192.168.1.1

        TeRouterIdIpv6 (str): IPv6 TE路由器ID, 类型为：string, 取值范围：IPv6地址, 默认值：3000::1

        SequenceNumber (int): 序列号, 类型为：number, 取值范围：1-300, 默认值：10

        RemainingLifeTime (int): 剩余生存时间, 类型为：number, 取值范围：1-100, 默认值：3

        Checksum (int): 使能正确校验和, 类型为：number, 取值范围：1-20, 默认值：2

        AttachedBit (int): 区域关联位, 类型为：number, 取值范围：1-65535, 默认值：900

        OverloadBit (int): 过载位, 类型为：number, 取值范围：1-100, 默认值：5

        HostName (str): 主机名称

    Returns:

        (:obj:`IsisLspConfig`): ISIS LSP对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
    """

    result = renix.create_isis_lsp(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_ipv4_tlv(Lsp, **kwargs):
    """
    创建ISIS IPv4 TLV对象

    Args:

        Lsp (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：object

    Keyword Args:

        Name (str): ISIS IPv4 TLV对象名称, 类型为：string

        Enable (bool): 使能ISIS IPv4 TLV, 类型为：bool, 取值范围：True或False, 默认值：True

        RouteType (str): 路由类型, 类型为：string, 默认值：INTERNAL, 支持参数：

            INTERNAL

            EXTERNAL

        RouteCount (int): 路由数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        Increment (int): 步长, 类型为：number, 取值范围：1-4294967295, 默认值：1

        MetricType (str): 度量类型, 类型为：string, 默认值：INTERNAL, 支持参数：

            INTERNAL

            EXTERNAL

        WideMetric (int): 扩展度量, 类型为：number, 取值范围：0-16777214, 默认值：10

        UpDownBit (bool): Up/Down位, 类型为：bool, 取值范围：True或False, 默认值：False

        StartIpv4Prefix (str): 起始IPv4路由前缀, 类型为：string, 取值范围：IPv4地址, 默认值：192.168.1.1

        PrefixLength (int): 前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

        NarrowMetric (int): 默认度量, 类型为：number, 取值范围：0-63, 默认值：10

    Returns:

        (:obj:`IsisIpv4TlvConfig`): ISIS IPv4 TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | Create Isis Ipv4 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
    """

    result = renix.create_isis_ipv4_tlv(Lsp=Lsp, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_ipv6_tlv(Lsp, **kwargs):
    """
    创建ISIS IPv6 TLV对象

    Args:

        Lsp (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：object

    Keyword Args:

        Name (str): ISIS IPv6 TLV对象名称, 类型为：string

        Enable (bool): 使能ISIS IPv6 TLV, 类型为：bool, 取值范围：True或False, 默认值：True

        RouteType (str): 路由类型, 类型为：string, 默认值：INTERNAL, 支持参数：

            INTERNAL

            EXTERNAL

        RouteCount (int): 路由数量, 类型为：number, 取值范围：1-4294967295, 默认值：1

        Increment (int): 步长, 类型为：number, 取值范围：1-4294967295, 默认值：1

        MetricType (str): 度量类型, 类型为：string, 默认值：INTERNAL, 支持参数：

            INTERNAL

            EXTERNAL

        WideMetric (int): 扩展度量, 类型为：number, 取值范围：0-16777214, 默认值：10

        UpDownBit (bool): Up/Down位, 类型为：bool, 取值范围：True或False, 默认值：False

        StartIpv6Prefix (str): 起始IPv4路由前缀, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PrefixLength (int): 前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

    Returns:

        (:obj:`IsisIpv6TlvConfig`): ISIS IPv6 TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | Create Isis Ipv6 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
    """

    result = renix.create_isis_ipv6_tlv(Lsp=Lsp, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_isis_router_from_tlv(Configs):
    """
    获取ISIS TLV对应的绑定流源或目的端点对象

    Args:

        Configs (list(:obj:`IsisIpv4TlvConfig`, `IsisIpv6TlvConfig`)): 测试仪表ISIS TLV对象列表, 类型为：list

    Returns:

        (list(:obj:`IsisIpv4Router`): ISIS TLV对应的绑定流源或目的端点对象列表

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${TLV} | Create Isis Ipv4 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Get Isis Router From Tlv | Configs=${TLV} |
    """

    result = renix.get_isis_router_from_tlv(Configs=Configs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_isis_state(Sessions, State='UP', Interval=1, TimeOut=60):
    """
    等待ISIS协议会话达到指定状态

    Args:

        Sessions (list (:obj:`IsisRouter`)): ISIS协议会话对象列表, 类型为：list

        State (list): 等待ISIS协议会话达到的状态, 类型为：string, 默认值：达到UP, 支持下列状态：

            NOTSTART

            IDLE

            INIT

            UP

            GR

            GRHELPER

            DISABLE

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Isis State | Sessions=${Sessions} | State=GR | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_isis_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_isis_three_way_p2p_adj_state(Sessions, State='UP', Interval=1, TimeOut=60):
    """
    等待ISIS协议会话three_way_p2p_adj达到指定状态

    Args:

        Sessions (list (:obj:`IsisRouter`)): ISIS协议会话对象列表, 类型为：list

        State (list): 等待ISIS协议会话three_way_p2p_adj达到的状态, 类型为：string, 默认值：达到UP, 支持下列状态：

            UP

            INIT

            DOWN

            NOTSTART

            NA

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Isis Three Way P2p Adj State | Sessions=${Sessions} | State=INIT | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_isis_three_way_p2p_adj_state(Sessions=Sessions, State=State, Interval=Interval,
                                                        TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_isis_l1_broadcast_adj_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待ISIS协议会话l1_broadcast_adj_state达到指定状态

    Args:

        Sessions (list (:obj:`IsisRouter`)): ISIS协议会话对象列表, 类型为：list

        State (list): 等待ISIS协议会话l1_broadcast_adj_state达到的状态, 类型为：string, 默认值：达到DISOTHER或DIS, 支持下列状态：

            NOTSTART

            IDLE

            INIT

            DISOTHER

            DIS

            GR

            GRHELPER

            NA

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Isis L1 Broadcast Adj State | Sessions=${Sessions} | State=RUNNING | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_isis_l1_broadcast_adj_state(Sessions=Sessions, State=State, Interval=Interval,
                                                       TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_isis_l2_broadcast_adj_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待ISIS协议会话l2_broadcast_adj_state达到指定状态

    Args:

        Sessions (list (:obj:`IsisRouter`)): ISIS协议会话对象列表, 类型为：list

        State (list): 等待ISIS协议会话l2_broadcast_adj_state达到的状态, 类型为：string, 默认值：达到DISOTHER或DIS, 支持下列状态：

            NOTSTART

            IDLE

            INIT

            DISOTHER

            DIS

            GR

            GRHELPER

            NA

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Isis L2 Broadcast Adj State | Sessions=${Sessions} | State=RUNNING | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_isis_l1_broadcast_adj_state(Sessions=Sessions, State=State, Interval=Interval,
                                                       TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_tlv(Lsp, **kwargs):
    """
    创建ISIS邻居TLV对象

    Args:

        Lsp (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：object

    Keyword Args:

        SystemId (str): 邻居系统ID, 取值范围：有效的MAC地址, 默认值："00:00:00:00:00:01"

        PseudonodeSystemId (int): 伪节点ID, 取值范围：0-255, 默认值：0

        NarrowMetric (int): 默认度量, 取值范围：0-63, 默认值：1

        WideMetric (int): 扩展度量, 取值范围：0-16777214, 默认值：10

    Returns:

        (:obj:`IsisNeighborConfig`): ISIS Neighbor TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
    """

    result = renix.create_isis_neighbor_tlv(Lsp=Lsp, **kwargs)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_te_config(Neighbor, **kwargs):
    """
    创建ISIS邻居TLV的Te Config对象

    Args:

        Neighbor (:obj:`IsisNeighborConfig`): ISIS Neighbor TLV对象, 类型为：object

    Keyword Args:

        EnableInterfaceIp (bool): 是否包含本地IPv4地址, 默认值：False

        InterfaceIp (str): 本地IPv4地址, 取值范围：有效的ip地址, 默认值：'0.0.0.0'

        EnableNeighborIp (bool): 是否包含邻居IPv4地址, 默认值：False

        NeighborIp (int): 邻居IPv4地址, 取值范围：有效的ip地址, 默认值：10

        EnableInterfaceIpv6 (bool): 是否包含本地IPv6地址, 默认值：False

        InterfaceIpv6 (str): 本地IPv6地址, 取值范围：有效的ipv6地址, 默认值：'2000::1'

        EnableNeighborIpv6 (bool): 是否包含邻居IPv6地址, 默认值：False

        NeighborIpv6 (str): 邻居IPv6地址, 取值范围：有效的ipv6地址, 默认值：'2000::1'

        EnableTeGroup (bool): 是否包含TE组, 默认值：False

        TeGroup (int): TE组, 取值范围：0-4294967295, 默认值：1

        EnableMaxBandwidth (bool): 是否包含最大带宽值, 默认值：False

        MaximunLink (int): 最大带宽值(字节/秒), 取值范围：0-4294967295, 默认值：1000

        EnableResBandwidth (bool): 是否包含预留带宽值, 默认值：False

        MaximumReservableLink (int): 最大预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：1000

        EnableUnresBandwidth (bool): 是否包含未预留带宽优先级, 默认值：False

        UnreservedBandwidth0 (int): 优先级0的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth1 (int): 优先级1的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth2 (int): 优先级2的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth3 (int): 优先级3的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth4 (int): 优先级4的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth5 (int): 优先级5的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth6 (int): 优先级6的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth7 (int): 优先级7的未预留带宽值(字节/秒), 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`IsisTEConfig`): ISIS Neighbor TLV Te Config对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Neighbor} | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Neighbor Te Config | Neighbor=${Neighbor} |
    """

    result = renix.create_isis_neighbor_te_config(Neighbor=Neighbor, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_sr_adj_sid_sub_tlv(Session, Neighbor, **kwargs):
    """
    创建Isis Neighbor Sr Adj Sid Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Neighbor (:obj:`IsisNeighborConfig`): ISIS Neighbor TLV对象, 类型为：object

    Keyword Args:

        Flags (list) : 选择一个或多个包含在TLV中的标志位, 默认值：['NOSHOW', 'VALUE', 'LOCAL'], 取值范围：

            NOSHOW

            ADDRESS

            BACKUP

            VALUE

            LOCAL

            SET

            PERSISTENT

        Sid (int): Flags中包含L.Local和V.Value时，指定标签值; Flags中不包含Value/Index时，指定SID/Label范围内的标签偏移值, 默认值：0, 取值范围：0-4294967295

        Weight (int): 指定Adj-SID权重，用于负载分担, 默认值：0, 取值范围：0-255

    Returns:

        (:obj:`IsisSrAdjSidSubTlv`): Isis Neighbor Sr Adj Sid Sub Tlv对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Neighbor} | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Neighbor Sr Adj Sid Sub Tlv | Neighbor=${Neighbor} |
    """

    result = renix.create_isis_neighbor_sr_adj_sid_sub_tlv(Session=Session, Neighbor=Neighbor, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_sr_lan_adj_sid_sub_tlv(Session, Neighbor, **kwargs):
    """
    创建Isis Neighbor Sr Lan Sid Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Neighbor (:obj:`IsisNeighborConfig`): ISIS Neighbor TLV对象, 类型为：object

    Keyword Args:

        Flags (list) : 选择一个或多个包含在TLV中的标志位, 默认值：['NOSHOW', 'VALUE', 'LOCAL'], 取值范围：

            NOSHOW

            ADDRESS

            BACKUP

            VALUE

            LOCAL

            SET

            PERSISTENT

        Sid (int): Flags中包含L.Local和V.Value时，指定标签值; Flags中不包含Value/Index时，指定SID/Label范围内的标签偏移值, 默认值：0, 取值范围：0-4294967295

        Weight (int): 指定Adj-SID权重，用于负载分担, 默认值：0, 取值范围：0-255

        SystemId (str): 指定LAN上邻居的系统ID, 默认值："00:00:00:00:00:01"


    Returns:

        (:obj:`IsisSrAdjSidSubTlv`): Isis Neighbor Sr Adj Sid Sub Tlv对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Neighbor} | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Neighbor Sr Lan Adj Sid Sub Tlv | Neighbor=${Neighbor} |
    """

    result = renix.create_isis_neighbor_sr_lan_adj_sid_sub_tlv(Session=Session, Neighbor=Neighbor, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_srv6_endx_sid_sub_tlv(Session, Neighbor, **kwargs):
    """
    创建Isis Neighbor Srv6 EndX Sid Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Neighbor (:obj:`IsisNeighborConfig`): ISIS Neighbor TLV对象, 类型为：object

    Keyword Args:

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            BACKUP

            SET

            PERSISTENT

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

        Algorithm (int): 指定SID关联的算法, 默认值：0, 取值范围：0-255

        Weight (int): 指定End.X SID的权重，用于负载分担, 默认值：100, 取值范围：0-255

        EndpointFunc (str): 端点行为, 默认值：END_NO, 取值范围：

            END_NO

            END_PSP

            END_USP

            END_PSP_USP

            END_X_NO

            END_X_PSP

            END_X_USP

            END_X_PSP_USP

            END_T_NO

            END_T_PSP

            END_T_USP

            END_T_PSPS_USP

            END_B6

            END_B6_ENCAPS

            END_BM

            END_DX6

            END_DX4

            EDN_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DX2U

            END_DX2M

            END_S

            END_B6_RED

            END_B6_ENCAPS_RED

            END_WITH_USD

            END_PSP_USD

            END_USP_USD

            END_PSP_USP_USD

            END_X_USD

            END_X_PSP_USD

            END_X_USP_USD

            END_X_PSP_USP_USD

            END_T_USD

            END_T_PSP_USD

            END_T_USP_USD

            END_T_PSP_USP_USD

        EnableCustom (bool): 使能自定义端点行为, 默认值：False

        CustomFunc (int): 自定义端点行为, 默认值：0, 取值范围：0-65535

        SID (str): 指定通告的SRv6 SID, 默认值："::1", 取值范围：有效IPv6地址

    Returns:

        (:obj:`IsisSrv6EndXSidSubTlv`): Isis Neighbor Srv6 EndX Sid Sub Tlv对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Neighbor} | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Neighbor Srv6 EndX Sid Sub Tlv | Neighbor=${Neighbor} |
    """

    result = renix.create_isis_neighbor_srv6_endx_sid_sub_tlv(Session=Session, Neighbor=Neighbor, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_srv6_lan_endx_sid_sub_tlv(Session, Neighbor, **kwargs):
    """
    创建Isis Neighbor Srv6 Lan EndX Sid Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Neighbor (:obj:`IsisNeighborConfig`): ISIS Neighbor TLV对象, 类型为：object

    Keyword Args:

        SystemIdLan (str): LAN系统标识, 默认值："00:10:96:00:00:01"

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            BACKUP

            SET

            PERSISTENT

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

        Algorithm (int): 指定SID关联的算法, 默认值：0, 取值范围：0-255

        Weight (int): 指定End.X SID的权重，用于负载分担, 默认值：100, 取值范围：0-255

        EndpointFunc (list): 端点行为, 默认值：END_NO, 取值范围：

            END_NO

            END_PSP

            END_USP

            END_PSP_USP

            END_X_NO

            END_X_PSP

            END_X_USP

            END_X_PSP_USP

            END_T_N

            END_T_PSP

            END_T_USP

            END_T_PSPS_USP

            END_B6

            END_B6_ENCAPS

            END_BM

            END_DX6

            END_DX4

            EDN_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DX2U

            END_DX2M

            END_S

            END_B6_RED

            END_B6_ENCAPS_RED

            END_WITH_USD

            END_PSP_USD

            END_USP_USD

            END_PSP_USP_USD

            END_X_USD

            END_X_PSP_USD

            END_X_USP_USD

            END_X_PSP_USP_USD

            END_T_USD

            END_T_PSP_USD

            END_T_USP_USD

            END_T_PSP_USP_USD

        EnableCustom (bool): 使能自定义端点行为, 默认值：False

        CustomFunc (int): 自定义端点行为, 默认值：0

        SID (str): 指定通告的SRv6 SID, 默认值："::1", 取值范围：有效IPv6地址

    Returns:

        (:obj:`IsisSrv6LanEndXSidSubTlv`): Isis Neighbor Srv6 Lan EndX Sid Sub Tlv对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Neighbor} | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Neighbor Srv6 Lan EndX Sid Sub Tlv | Neighbor=${Neighbor} |
    """

    result = renix.create_isis_neighbor_srv6_lan_endx_sid_sub_tlv(Session=Session, Neighbor=Neighbor, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_sr_link_msd_sub_tlv(Session, Neighbor, **kwargs):
    """
    创建Isis Neighbor Sr Link Msd Sid Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Neighbor (:obj:`IsisNeighborConfig`): ISIS Neighbor TLV对象, 类型为：object

    Keyword Args:

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            MAX_SEG_LELT

            MAX_END_POP

            MAX_T_INSERT

            MAX_T_ENCAPS

            MAX_END_D

        MaxSegmentLeft (int): 在应用与SID关联的SRv6 Endpoint Function指令之前，指定接收报文的SRH中SL（Segment Left）字段的最大值, 默认值：8, 取值范围：0-255

        MaxEndPop (int): 指定SRH栈的顶端SRH中SID的最大数量, 默认值：8, 取值范围：0-255

        MaxInsert (int): 指定执行T.Insert行为时可包含SID的最大数量, 默认值：8, 取值范围：0-255

        MaxEncap (int): 指定执行T.Encap行为时可包含SID的最大数量, 默认值：8, 取值范围：0-255

        MaxEndD (int): 指定执行End.DX6和End.DT6功能时，SRH中SID的最大数量, 默认值：8, 取值范围：0-255

    Returns:

        (:obj:`IsisSrLinkMsdSubTlv`): Isis Neighbor Sr Link Msd Sid Sub Tlv对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Neighbor} | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Neighbor Sr Link Msd Sid Sub Tlv | Neighbor=${Neighbor} |
    """

    result = renix.create_isis_neighbor_sr_link_msd_sub_tlv(Session=Session, Neighbor=Neighbor, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_neighbor_custom_sub_tlv(SubTlv, **kwargs):
    """
    创建Isis Neighbor Custom Sub Tlv对象

    Args:

        SubTlv (:obj:`IsisSrLinkMsdSubTlv`): ISIS Neighbor Sr Link Msd Sid Sub TLV对象, 类型为：object

    Keyword Args:

        SubType (int): 该Sub-TLV的Type字段值, 默认值：0, 取值范围：0-255

        SubValue (int): 该Sub-TLV的Value字段值, 取值范围：十六进制值。默认值：08

    Returns:

        (:obj:`IsisSrLinkMsdSubTlv`): Isis Neighbor Sr Link Msd Sid Sub Tlv对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Neighbor} | Create Isis Neighbor Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | ${Msd} | Create Isis Neighbor Sr Link Msd Sid Sub Tlv | Neighbor=${Neighbor} |
            | Isis Neighbor Custom Sub Tlv | SubTlv=${Msd} |
    """

    result = renix.create_isis_neighbor_custom_sub_tlv(SubTlv=SubTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_tlv_prefix_sid_sub_tlv(Session, Tlv, **kwargs):
    """
    创建ISIS Tlv Prefix Sid Sub Tlv对象

    Args:

        Tlv (:obj:`IsisIpv4TlvConfig`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：['NOSHOW', 'NOPHP'], 取值范围：

            NOSHOW

            ADVERTISEMENT

            NODESID

            NOPHP

            EXPLICIT

            VALUE

            LOCAL

        Sid (int): SID/Label, 默认值：0, 取值范围：0-4294967295

        Algorithm (int): 指定计算到其他节点/前缀的可达信息的算法, 指定SID关联的算法, 默认值：0, 取值范围：0-255

        PrefixSidStep (int): 默认值：1

    Returns:

        (:obj:`IsisSrPrefixSidSubTlv`): ISIS Prefix Sid Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Ipv4} | Create Isis Ipv4 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Tlv Prefix Sid Sub Tlv | Tlv=${Ipv4} |
    """

    result = renix.create_isis_tlv_prefix_sid_sub_tlv(Session=Session, Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_tlv_flex_algorithm_prefix_metric_sub_tlv(Tlv, **kwargs):
    """
    创建ISIS Tlv Flex Algorithm Prefix Metric Sid Sub Tlv对象

    Args:

        Tlv (:obj:`IsisIpv4TlvConfig`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Algorithm (int): Locator关联算法, 类型为：number, 取值范围：128-255, 默认值：128

        Metric (int): 度量值, 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`IsisFlexAlgoPrefixMetricSubTlv`): ISIS Prefix Sid Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Ipv4} | Create Isis Ipv4 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Tlv Flex Algorithm Prefix Metric Sub Tlv | Tlv=${Ipv4} |
    """

    result = renix.create_isis_tlv_flex_algorithm_prefix_metric_sub_tlv(Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_tlv_bier_sub_tlv(Tlv, **kwargs):
    """
    创建ISIS Tlv Bier Sub Tlv对象

    Args:

        Tlv (:obj:`IsisIpv4TlvConfig`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        BFRId (int): 指定BFR（Bit Forwarding Router，比特转发路由器）ID, 取值范围：1-65535, 默认值：1

        SubDomainId (int): 指定BIER子域ID, 取值范围：0-255, 默认值：1

        IgpAlgorithm (int): IGP算法, 取值范围：0-255, 默认值：0

        BierAlgorithm (int): BIER算法, 取值范围：0-255, 默认值：0

    Returns:

        (:obj:`IsisBierSubTlv`): ISIS Prefix Sid Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Ipv4} | Create Isis Ipv4 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Tlv Bier Sub Tlv | Tlv=${Ipv4} |
    """

    result = renix.create_isis_tlv_bier_sub_tlv(Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_tlv_bier_Mpls_sub_sub_tlv(Bier, **kwargs):
    """
    创建ISIS Tlv Bier Mpls Sub Sub Tlv对象

    Args:

        Bier (:obj:`IsisBierSubTlv`): ISIS Bierv6 Sub Tlv对象, 类型为：object

    Keyword Args:

        MaxSI (int): 指定最大Set ID, 默认值：1, 取值范围：0-255

        LabelorBiftId (int): 指定标签范围中的起始标签值, 默认值：100, 取值范围：0-4294967295

        BSLength (int): 指定本地比特串的长度, 默认值：1, 取值范围：0-15

    Returns:

        (:obj:`IsisBierMplsSubTlv`): ISIS Prefix Sid Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Ipv6} | Create Isis Ipv6 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Tlv Bier Sub Tlv | Tlv=${Ipv6} |
            | Create Isis Tlv Bier Mpls Sub Sub Tlv | Bier=${Ipv6} |
    """

    result = renix.create_isis_tlv_bier_Mpls_sub_sub_tlv(Bier=Bier, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_tlv_bierv6_sub_sub_tlv(Bier, **kwargs):
    """
    创建ISIS Tlv Bierv6 Sub Sub Tlv对象

    Args:

        Bier (:obj:`IsisBierSubTlv`): ISIS Bierv6 Sub Tlv对象, 类型为：object

    Keyword Args:

        MaxSI (int): 指定最大Set ID, 默认值：1, 取值范围：0-255

        LabelorBiftId (int): 指定标签范围中的起始标签值, 默认值：100, 取值范围：0-4294967295

        BSLength (int): 指定本地比特串的长度, 默认值：1, 取值范围：0-15

    Returns:

        (:obj:`IsisBierMplsSubTlv`): ISIS Prefix Sid Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Ipv6} | Create Isis Ipv6 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Tlv Bier Sub Tlv | Tlv=${Ipv6} |
            | Create Isis Tlv Bierv6 Sub Sub Tlv | Bier=${Ipv6} |
    """

    result = renix.create_isis_tlv_bierv6_sub_sub_tlv(Bier=Bier, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_tlv_end_bier_sub_tlv(Bier, **kwargs):
    """
    创建ISIS Tlv End Bier Sub Tlv对象

    Args:

        Bier (:obj:`IsisIpv6TlvConfig`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Type (int): 指定Type字段值。取值范围：0-255, 默认值：3

        EndBierAddr (str): 指定End.BIER SID, 默认值："::1", 取值范围：有效IPv6地址

    Returns:

        (:obj:`IsisEndBierSubTlv`): ISIS Prefix Sid Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Ipv6} | Create Isis Ipv6 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Tlv End Bier Sub Tlv | Tlv=${Ipv6} |
    """

    result = renix.create_isis_tlv_end_bier_sub_tlv(Bier=Bier, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_tlv_bierv6_bift_id_sub_tlv(Bier, **kwargs):
    """
    创建ISIS Tlv Bierv6 Bift Id Sub Tlv对象

    Args:

        Bier (:obj:`IsisIpv6TlvConfig`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Type(int): 指定Type字段值, 默认值：7, 取值范围：0-255

        MPRA (str): 指定MPRA地址, 默认值：'::1', 取值范围：有效IPv6地址

    Returns:

        (:obj:`IsisBierBiftIdSubTlv`): ISIS Prefix Sid Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Ipv6} | Create Isis Ipv6 Tlv | Lsp=${LSP} | SystemId=00:00:00:00:00:02 |
            | Create Isis Tlv Bierv6 Bift Id Sub Tlv | Tlv=${Ipv6} |
    """

    result = renix.create_isis_tlv_bierv6_bift_id_sub_tlv(Bier=Bier, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_capability_tlv(Session, Lsp, **kwargs):
    """
    创建ISIS Capability TLV对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Lsp (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：object

    Keyword Args:

        Option (list): 选项, 默认值：['NOSHOW', 'SBIT'], 取值范围：

            NOSHOW

            SBIT

            DBIT

        RouterId (str): 路由器ID, 默认值："192.0.0.1", 取值范围：有效IPv4地址

    Returns:

        (:obj:`IsisCapabilityTlv`): ISIS Neighbor TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | Create Isis Capability Tlv | Session=${Session} | Lsp=${LSP} | RouterId=1.1.1.1 |
    """

    result = renix.create_isis_capability_tlv(Session=Session, Lsp=Lsp, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_capability_sr_capability_sub_tlv(Session, Capability, **kwargs):
    """
    创建ISIS Capability Sr Capability Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Capability (:obj:`IsisCapabilityTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：['NOSHOW', 'IPv4_CAPABLE'], 取值范围：

            NOSHOW

            IPv4_CAPABLE

            IPv6_CAPABLE

        ValueType (str): 选择标识符（SID或标签）, 默认值：BIT32, 取值范围：

            BIT20

            BIT32

    Returns:

        (:obj:`IsisSrCapabilitySubTlv`): ISIS Capability Sr Capability Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Capability} | Create Isis Capability Tlv | Lsp=${LSP} | SystemId=1.1.1.1 |
            | Create Isis Capability Sr Capability Sub Tlv | Session={Session} | Capability=${Capability} |
    """

    result = renix.create_isis_capability_sr_capability_sub_tlv(Session=Session, Capability=Capability, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_capability_sr_algorithm_sub_tlv(Capability, **kwargs):
    """
    创建ISIS Capability Sr Algorithm Sub Tlv对象

    Args:

        Capability (:obj:`IsisCapabilityTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Algorithm (list): 算法值, 默认值：0, 取值范围：int


    Returns:

        (:obj:`IsisSrAlgorithmSubTlv`): ISIS Capability Sr Algorithm Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Capability} | Create Isis Capability Tlv | Lsp=${LSP} | SystemId=1.1.1.1 |
            | Create Isis Capability Sr Algorithm Sub Tlv | Capability=${Capability} |
    """

    result = renix.create_isis_capability_sr_algorithm_sub_tlv(Capability=Capability, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_capability_srv6_capability_sub_tlv(Session, Capability, **kwargs):
    """
    创建ISIS Capability Srv6 Capability Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Capability (:obj:`IsisCapabilityTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            UNUSED0

            O_BIT

            UNUSED2

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

            UNUSED8

            UNUSED9

            UNUSED10

            UNUSED11

            UNUSED12

            UNUSED13

            UNUSED14

            UNUSED15

    Returns:

        (:obj:`IsisSrv6CapabilitySubTlv`): ISIS Capability Srv6 Capability Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Capability} | Create Isis Capability Tlv | Lsp=${LSP} | SystemId=1.1.1.1 |
            | Create Isis Capability Srv6 Capability Sub Tlv | Session=Session | Capability=${Capability} |
    """

    result = renix.create_isis_capability_srv6_capability_sub_tlv(Session=Session, Capability=Capability,
                                                                     **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_capability_sr_node_msd_sub_tlv(Session, Capability, **kwargs):
    """
    创建ISIS Capability Sr Node Msd Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Capability (:obj:`IsisCapabilityTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            MAX_SEG_LELT

            MAX_END_POP

            MAX_T_INSERT

            MAX_T_ENCAPS

            MAX_END_D

        MaxSegmentLeft (int): 在应用与SID关联的SRv6 Endpoint Function指令之前，指定接收报文的SRH中SL（Segment Left）字段的最大值, 默认值：8, 取值范围：0-255

        MaxEndPop (int): 指定SRH栈的顶端SRH中SID的最大数量, 默认值：8, 取值范围：0-255

        MaxInsert (int): 指定执行T.Insert行为时可包含SID的最大数量, 默认值：8, 取值范围：0-255

        MaxEncap (int): 指定执行T.Encap行为时可包含SID的最大数量, 默认值：8, 取值范围：0-255

        MaxEndD (int): 指定执行End.DX6和End.DT6功能时，SRH中SID的最大数量, 默认值：8, 取值范围：0-255

    Returns:

        (:obj:`IsisSrMsdSubTlv`): ISIS Capability Sr Node Msd Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Capability} | Create Isis Capability Tlv | Lsp=${LSP} | SystemId=1.1.1.1 |
            | Create Isis Capability Sr Node Msd Sub Tlv | Capability=${Capability} |
    """

    result = renix.create_isis_capability_sr_node_msd_sub_tlv(Session=Session, Capability=Capability, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_capability_sr_fad_sub_tlv(Session, Capability, **kwargs):
    """
    创建ISIS Capability Sr Fad Sub Tlv对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Capability (:obj:`IsisCapabilityTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        FlexAlgo (int): 灵活算法ID, 默认值：128, 取值范围：128-255

        MetricType (str): 指定算路使用的度量类型, 默认值：IGP_METRIC, 取值范围：

            IGP_METRIC

            MIN_LINK_DELAY

            TE_METRIC

        CalType (int): 指定特定IGP算法的计算类型, 默认值：0, 取值范围：0-255

        Priority (int): 指定该Sub TLV的优先级, 默认值：0

        FlexAlgoSubTlv (list): 选择灵活算法路径计算要遵循的约束条件, 默认值：['UNKNOWN'], 取值范围：

            UNKNOWN

            EXCLUDE_ADMIN

            INCLUDE__ANY_ADMIN

            INCLUDE_ALL_ADMIN

            DEFINITION_FLAGS

            EXCLUDE_SRLG

        ExcludeAdmin (int): 类型为：number, 默认值：0, 取值范围：0-4294967295

        IncludeAnyAdmin (int): 类型为：number, 默认值：0, 取值范围：0-4294967295

        IncludeAllAdmin (int): 类型为：number, 默认值：0, 取值范围：0-4294967295

        DefinitionFlags (list): 类型为：hex int, 默认值：0x80, 取值范围：0-FF

        ExcludeSRLG (list): 类型为：hex int, 默认值：0x10020000, 取值范围：0-4294967295

    Returns:

        (:obj:`IsisFelxAlgoDefinitionSubTlv`): ISIS Capability Sr Fad Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Capability} | Create Isis Capability Tlv | Lsp=${LSP} | SystemId=1.1.1.1 |
            | Create Isis Capability Sr Fad Sub Tlv | Session={Session} | Capability=${Capability} |
    """

    result = renix.create_isis_capability_sr_fad_sub_tlv(Session=Session, Capability=Capability, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_capability_srms_preference_sub_tlv(Capability, **kwargs):
    """
    创建ISIS Capability Srms Preference Sub Tlv对象

    Args:

        Capability (:obj:`IsisCapabilityTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Preference (int): 指定本节点作为SR Mapping Server的优先级, 取值范围：0-255, 默认值：0

    Returns:

        (:obj:`IsisSrSRMSPrefSubTlv`): ISIS Capability Srms Preference Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Capability} | Create Isis Capability Tlv | Lsp=${LSP} | SystemId=1.1.1.1 |
            | Create Isis Capability Srms Preference Sub Tlv | Capability=${Capability} |
    """

    result = renix.create_isis_capability_srms_preference_sub_tlv(Capability=Capability, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_sr_binding_tlv(Session, Lsp, **kwargs):
    """
    创建ISIS Binding TLV对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Lsp (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：object

    Keyword Args:

        EnableMt (bool): 使能多拓扑, 默认值：False

        MtId (str): 多拓扑ID, 默认值：STANDARD, 取值范围：

            STANDARD

            IPV6_ROUTING

        Flags (list): 标签, 默认值：['NOSHOW'], 取值范围：

            NOSHOW

            FBIT

            MBIT

            SBIT

            DBIT

            ABIT

        Weight (int): 权重, 默认值：0, 取值范围：0-255

        Range (int): 范围, 默认值：1, 取值范围：0-65535

        Ipv4Version (bool): 默认值：True

        Ipv4Prefix (str): IPv4前缀, 默认值："192.0.0.1"

        Ipv4PrefixLength (int): IPv4前缀长度, 默认值：1, 取值范围：1-32

        Ipv6Prefix (str): IPv6前缀, 默认值："2000::1

        Ipv6PrefixLength (int): IPv6前缀长度, 默认值：64, 取值范围：1-128

    Returns:

        (:obj:`IsisSrBindingTlv`): ISIS Neighbor TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | Create Isis Binding Tlv | Session={Session} | Lsp=${LSP} | Ipv4Version=False |
    """

    result = renix.create_isis_sr_binding_tlv(Session=Session, Lsp=Lsp, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_binding_sr_sid_sub_tlv(Binding, **kwargs):
    """
    创建ISIS Capability Srms Preference Sub Tlv对象

    Args:

        Binding (:obj:`IsisSrBindingTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        ValueType (str): 选择标识符（SID或标签）, 默认值：BIT32, 取值范围：

            BIT20

            BIT32

        Sid (int): 值类型为20bit时，指定起始标签; 值类型为32bit时，指定起始SID, 默认值：12000

    Returns:

        (:obj:`IsisSrSRMSPrefSubTlv`): ISIS Capability Srms Preference Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Binding} | Create Isis Binding Tlv | Lsp=${LSP} | Ipv4Version=False |
            | Create Isis Binding Sr sid Sub Tlv | Binding=${Binding}
    """

    result = renix.create_isis_binding_sr_sid_sub_tlv(Binding=Binding, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_srv6_location_tlv(Session, Lsp, **kwargs):
    """
    创建ISIS Binding TLV对象

    Args:

        Session (:obj:`IsisRouter`): ISIS协议会话对象列表, 类型为：object

        Lsp (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：object

    Keyword Args:

        MtId (str): 多拓扑ID, 默认值：STANDARD, 取值范围：

        Metric (int): 指定度量值, 默认值：0, 取值范围：0-4294967295

        Flags (list): 标签, 默认值：['UNKNOWN'], 取值范围：

            UNKNOWN

            D_BIT

            A_BIT

            UNUSED2

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

        Algorithm (int): Locator关联算法, 类型为：number, 取值范围：0-255, 默认值：0

        NumLocator (int): Locator数量, 取值范围：0-4294967295, 默认值：1

        LocatorSize (int): 定位器大小, 取值范围：1-128, 默认值：64

        Locator (str): 定位器, 默认值："aaaa:1:1:1::", 取值范围：IPv6地址

        LocatorStep (int): 定位器步长, 默认值：1, 取值范围：0-65535

    Returns:

        (:obj:`IsisSrv6LocatorTlv`): ISIS Srv6 Location TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | Create Isis Srv6 Location Tlv | Session={Session} | Lsp=${LSP} | Algorithm=1 |
    """

    result = renix.create_isis_srv6_location_tlv(Session=Session, Lsp=Lsp, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_isis_srv6_end_sid_sub_tlv(Session, Location, **kwargs):
    """
    创建ISIS Capability Srms Preference Sub Tlv对象

    Args:

        Location (:obj:`IsisSrv6LocatorTlv`): ISIS Tlv对象, 类型为：object

    Keyword Args:

        Flags (list): 选择一个或多个包含在TLV中的标志位, 默认值：['UNKNOWN'], 取值范围：

            UNKNOWN

            UNUSED0

            UNUSED1

            UNUSED2

            UNUSED3

            UNUSED4

            UNUSED5

            UNUSED6

            UNUSED7

        EndpointFunc (str): 端点行为, 默认值：END_NO, 取值范围：

            END_NO

            END_PSP

            END_USP

            END_PSP_USP

            END_X_NO

            END_X_PSP

            END_X_USP

            END_X_PSP_USP

            END_T_NO

            END_T_PSP

            END_T_USP

            END_T_PSPS_USP

            END_B6

            END_B6_ENCAPS

            END_BM

            END_DX6

            END_DX4

            EDN_DT6

            END_DT4

            END_DT46

            END_DX2

            END_DX2V

            END_DX2U

            END_DX2M

            END_S

            END_B6_RED

            END_B6_ENCAPS_RED

            END_WITH_USD

            END_PSP_USD

            END_USP_USD

            END_PSP_USP_USD

            END_X_USD

            END_X_PSP_USD

            END_X_USP_USD

            END_X_PSP_USP_USD

            END_T_USD

            END_T_PSP_USD

            END_T_USP_USD

            END_T_PSP_USP_USD

        EnableCustom (bool): 使能自定义端点行为, 默认值：False

        CustomFunc (int): 自定义端点行为, 默认值：0, 取值范围：0-65535

        SID (str): 指定通告的SRv6 SID, 默认值："::1", 取值范围：IPv6地址

    Returns:

        (:obj:`IsisSrv6EndSidSubTlv`): ISIS Capability Srms Preference Sub TLV对象

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Isis | Port=${Port} |
            | ${LSP} | Create Isis Lsp | Session=${Session} | SystemId=00:00:00:00:00:02 |
            | ${Location} | Create Isis Srv6 Location Tlv | Lsp=${LSP} | Algorithm=1 |
            | Create Isis Srv6 End Sid Sub Tlv | Session={Session} | Location=${Location} |
    """

    result = renix.create_isis_srv6_end_sid_sub_tlv(Session=Session, Location=Location, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def advertise_isis(Lsps):
    """
    通告Isis协议会话lsp

    Args:

        Lsps (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Advertise Isis | Lsp=${Lsp} |
    """

    result = renix.advertise_isis(Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def withdraw_isis(Lsps):
    """
    通告Isis协议会话lsp

    Args:

        Lsps (:obj:`IsisLspConfig`): ISIS LSP对象, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Withdraw Isis | Lsp=${Lsp} |
    """

    result = renix.withdraw_isis(Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def graceful_restart_isis(Sessions):
    """
    平滑重启Isis协议会话

    Args:

        Sessions (list (:obj:`IsisRouter`)): ISIS 会话对象列表

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Graceful Restart Isis | Session=${Session} |
    """

    result = renix.graceful_restart_isis(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_isis_session_stats(Session=None, StaItems=None):
    """
    获取Isis Session统计结果

    Args:

        Session (:obj:`IsisRouter`): Isis协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            TxP2pHello

            RxP2pHello

            TxLanL1Hello

            RxLanL1Hello

            TxLanL2Hello

            RxLanL2Hello

            TxL1Lsp

            RxL1Lsp

            TxL2Lsp

            RxL2Lsp

            TxL1Csnp

            RxL1Csnp

            TxL2Csnp

            RxL2Csnp

            TxL1Psnp

            RxL1Psnp

            TxL2Psnp

            RxL2Psnp

    Returns:

        dict: eg::

            {
                'TxL1Lsp': 10,
                'RxL1Lsp': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=IsisSessionStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Isis Session Stats | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_isis_session_stats(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_isis_tlv_stats(Session=None, StaItems=None):
    """
    获取Isis Session统计结果

    Args:

        Session (:obj:`IsisRouter`): Isis协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            TxPrefixSid

            RxPrefixSid

            TxAdjSid

            RxAdjSid

            TxLanAdjSid

            RxLanAdjSid

            TxSidBinding

            RxSidBinding

            TxSrv6Loc

            RxSrv6Loc

            TxSrv6EndX

            RxSrv6EndX

            TxSrv6LanEndX

            RxSrv6LanEndX

    Returns:

        dict: eg::

            {
                'TxPrefixSid': 10,
                'RxPrefixSid': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=IsisTlvStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Isis Tlv Stats | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_isis_tlv_stats(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_isis_port_config(Ports, **kwargs):
    """
    修改Isis端口统计对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        UpdateRoutesTransmitRate (int): IS-IS Tx Hello Rate(messages/second) , 取值范围：1-10000, 默认值：1000

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Isis Port Config | Ports=${Ports} | UpdateRoutesTransmitRate=100 |
    """

    result = renix.edit_isis_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Mld-------------------------------------
def create_mld(Port, **kwargs):
    """
    创建MLD协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): MLD协会话名称, 类型为：string

        Enable (bool): 使能MLD协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：MLDV1, 支持版本：

            MLDV1

            MLDV2

        PackReports (bool): 合并报告报文, 类型为：bool, 取值范围：True或False, 默认值：False

        InitialJoin (bool): 单个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustJoin (bool): 多个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustnessVariable (int): Robust值, 类型为：number, 取值范围：2-255, 默认值：2

        UnsolicitedReportInterval (int): 发送初始报文的时间间隔 (秒), 类型为：number, 取值范围：0-65535, 默认值：10

        ForceLeave (bool): 强制发送Leave报文, 类型为：bool, 取值范围：True或False, 默认值：True

        TrafficClass (hex int): IP头的Traffic Class值, 型为：string, 取值范围：0x0-0xff, 默认值：0xc0

    Returns:

        (:obj:`Mld`): MLD协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Mld | Port=${Port} | Version=MLDV2 |
    """

    result = renix.create_mld(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mld(Session, **kwargs):
    """
    创建MLD协议会话对象

    Args:

        Session (:obj:`Mld`): MLD协议会话对象, 类型为：object

    Keyword Args:

        Name (str): MLD协会话名称, 类型为：string

        Enable (bool): 使能MLD协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：MLDV1, 支持版本：

            MLDV1

            MLDV2

        PackReports (bool): 合并报告报文, 类型为：bool, 取值范围：True或False, 默认值：False

        InitialJoin (bool): 单个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustJoin (bool): 多个初始报文加入组, 类型为：bool, 取值范围：True或False, 默认值：False

        RobustnessVariable (int): Robust值, 类型为：number, 取值范围：2-255, 默认值：2

        UnsolicitedReportInterval (int): 发送初始报文的时间间隔 (秒), 类型为：number, 取值范围：0-65535, 默认值：10

        ForceLeave (bool): 强制发送Leave报文, 类型为：bool, 取值范围：True或False, 默认值：True

        TrafficClass (hex int): IP头的Traffic Class值, 型为：string, 取值范围：0x0-0xff, 默认值：0xc0

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mld | Port=${Port} | Version=MLDV2 |
    """

    result = renix.edit_mld(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_mld_state(Sessions, State='MEMBER', Interval=1, TimeOut=60):
    """
    等待Mld协议会话达到指定状态

    Args:

        Sessions (list (:obj:`Mld`)): Mld协议会话对象列表

        State (list): 等待Mld协议会话达到的状态, 默认值：达到MEMBER, 支持下列状态：

            NONMEMBER

            JOINING

            MEMBER

            LEAVING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Mld State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_mld_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def mld_send_report(Sessions):
    """
    MLD客户端加入组

    Args:

        Sessions (list (:obj:`Mld`)): MLD协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Mld Send Report | Sessions=${Session} |
    """

    result = renix.mld_send_report(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def mld_send_leave(Sessions):
    """
    MLD客户端离开组

    Args:

        Sessions (list (:obj:`Mld`)): MLD协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Mld Send Leave | Sessions=${Session} |
    """

    result = renix.mld_send_leave(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def mld_resend_report(Sessions):
    """
    MLD客户端重新加入组

    Args:

        Sessions (list (:obj:`Mld`)): MLD协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Mld Resend Report | Sessions=${Session} |
    """

    result = renix.mld_resend_report(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def get_mld_host_statistic(Session=None, StaItems=None):
    """
    获取Mld协议会话统计结果

    Args:

        Session (:obj:`Mld`): Mld协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            MldTxFrames

            MldRxFrames

            MldRxUnknownTypes

            MldRxChecksumErrors

            MldRxLengthErrors

    Returns:

        dict: eg::

            {
                'MldTxFrames': 8,
                'MldRxFrames': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | MldTxFrames | MldRxFrames |
            | Subscribe Result | Types=MldHostResults |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Mld Host Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_mld_host_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_mld_port_statistic(Port=None, StaItems=None):
    """
    获取Mld Port统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            MldTxFrames

            MldRxFrames

            MldTxV1Reports

            MldStopListenGroups

            MldTxV2Reports

            MldTxV2ModeInclude

            MldTxV2ModeExclude

            MldTxV2ModeChangeToInclude

            MldTxV2ModeChangeToExclude

            MldTxV2ModeAllowNewSources

            MldTxV2ModeBlockOldSources

            MldRxV1Queries

            MldRxV2Queries

            MldRxGeneralQueries

            MldRxGroupSpecificQueries

            MldRxGroupAndSourceSpecificQueries

            MldRxUnknownTypes

            MldRxChecksumErrors

            MldRxLengthErrors

    Returns:

        dict: eg::

            {
                'MldTxFrames': 8,
                'MldRxFrames': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | MldTxFrames | MldRxFrames |
            | Subscribe Result | Types=MldPortAggregatedResults |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Mld Port Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_mld_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------MLD Querier-------------------------------------
def create_mld_querier(Port, **kwargs):
    """
    创建MLD Querier协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): MLD Querier协会话名称, 类型为：string

        Enable (bool): 使能MLD Querier协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：MLDV1, 支持版本：

            MLDV1

            MLDV2

        RobustnessVariable (int): 健壮系数, 取值范围：2-255, 默认值: 2

        Interval (int): 查询时间间隔（秒）, 取值范围：0-4294967295, 默认值: 125

        ResponseInterval (int): 查询响应时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 10000

        StartupQueryCount (int): 初始查询报文个数, 取值范围：1-255, 默认值：2

        LastMemberQueryInterval (int): 最后成员查询时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 1000

        LastMemberQueryCount (bool): 最后成员查询次数, 取值范围：0-255, 默认值: 2

        IPv6TrafficClassValue (str): 设置IPv6头TrafficClass值, 取值范围：0x0-0xff, 默认值: 0x0

    Returns:

        (:obj:`MldQuerier`): MLD协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Mld Querier| Port=${Port} | Version=MLDV3 |
    """

    result = renix.create_mld_querier(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mld_querier(Session, **kwargs):
    """
    编辑MLD Querier协议会话对象

    Args:

        Session(:obj:`MldQuerier`): MLD协会话对象, 类型为：object

    Keyword Args:

        Name (str): MLD Querier协会话名称, 类型为：string

        Enable (bool): 使能ICMP Querier协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): 版本, 类型为：string, 默认值：MLDV1, 支持版本：

            MLDV1

            MLDV2

        RobustnessVariable (int): 健壮系数, 取值范围：2-255, 默认值: 2

        Interval (int): 查询时间间隔（秒）, 取值范围：0-4294967295, 默认值: 125

        ResponseInterval (int): 查询响应时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 10000

        StartupQueryCount (int): 初始查询报文个数, 取值范围：1-255, 默认值：2

        LastMemberQueryInterval (int): 最后成员查询时间间隔（毫秒）, 取值范围：0-4294967295, 默认值: 1000

        LastMemberQueryCount (bool): 最后成员查询次数, 取值范围：0-255, 默认值: 2

        IPv6TrafficClassValue (str): 设置IPv6头TrafficClass值, 取值范围：0x0-0xff, 默认值: 0x0

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mld Querier | Port=${Port} | Version=MLDV2 | IPv6TrafficClassValue=0xff |
    """

    result = renix.edit_mld(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def apply_mld_querier(Sessions):
    """
    MLD Querier增量配置下发到后台

    Args:

        Sessions (list (:obj:`MldQuerier`)): MLD Querier协会话对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Apply Mld Querier |
    """

    result = renix.apply_mld_querier(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_mld_querier_state(Sessions, State='UP', Interval=1, TimeOut=60):
    """
    等待Mld Querier协议会话达到指定状态

    Args:

        Sessions (list (:obj:`MldQuerier`)): Mld Querier协议会话对象列表

        State (list): 等待Mld Querier协议会话达到的状态, 默认值：达到UP, 支持下列状态：

            NOTSTARTED

            UP

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Mld Querier State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_mld_querier_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_mld_querier_statistic(Session=None, StaItems=None):
    """
    获取Mld Querier协议会话统计结果

    Args:

        Session (:obj:`MldQuerier`): Mld协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            QuerierTxFrames

            QuerierRxFrames

            QuerierRxUnknownTypes

            QuerierRxChecksumErrors

            QuerierRxLengthErrors

    Returns:

        dict: eg::

            {
                'QuerierTxFrames': 8,
                'QuerierRxFrames': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | QuerierTxFrames | QuerierRxFrames |
            | Subscribe Result | Types=MldQuerierResults |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Mld Querier Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_mld_querier_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_mld_port_config(Ports, **kwargs):
    """
    修改Mld端口统计对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        MldMaximumOutputRate (int): 最大发包速率(包/秒) , 取值范围：1-1000000000, 默认值：100

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Mld Port Config | Ports=${Ports} | MldMaximumOutputRate=100 |
    """

    result = renix.edit_mld_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------OSPFv3-------------------------------------
def create_ospfv3(Port, **kwargs):
    """
    创建OSPFv3协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): OSPFv3协会话名称, 类型为：string

        Enable (bool): 使能OSPFv3协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        InstanceId (int): 实例ID, 类型为：number, 取值范围：0-255, 默认值：0

        AreaId (str): 区域ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        EnableExtendedLsa (bool): 使能扩展LSA, 类型为：bool, 取值范围：True或False, 默认值：False

        ExtendedLsaMode (str): 扩展LSA模式, 类型为：string, 默认值：Full, 取值范围：

            NONE

            MixedModeOriginateOnly

            MixedModeOriginateSPF

            Full

        AreaExtendedLsaMode (str): 扩展区域LSA模式, 类型为：string, 默认值：InheritGlobal, 取值范围：

            InheritGlobal

            NONE

            MixedModeOriginateOnly

            MixedModeOriginateSPF

            Full

        EnableBfd (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        NetworkType (str): 网络类型, 类型为：string, 取值范围：Broadcast或P2P, 默认值：Broadcast

        Priority (int): 路由器优先级, 类型为：number, 取值范围：0-255, 默认值：0

        InterfaceId (int): 接口ID, 类型为：number, 取值范围：0-4294967295, 默认值：10

        Cost (int): 接口开销, 类型为：number, 取值范围：1-65535, 默认值：10

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'V6BIT', 'EBIT', 'RBIT'], 支持选项有：

            NONTBIT

            V6BIT

            EBIT

            MCBIT

            NBIT

            RBIT

            DCBIT

            Unused17

            Unused16

            Unused15

            Unused14

            Unused13

            Unused12

            Unused11

            Unused10

            Unused9

            Unused8

            Unused7

            Unused6

            Unused5

            Unused4

            Unused3

            Unused2

            Unused1

            Unused0

        EnableOspfv3Mtu (bool): 使能OSPFv3 MTU, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        GracefulRestartReason (str): 平滑重启原因, 类型为：string, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            SOFTWARE

            RELOADORUPGRADE

            SWITCH

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        HelloInterval (int): Hello包间隔(秒), 类型为：number, 取值范围：0-65535, 默认值：10

        RouterDeadInterval (int): 路由器失效间隔(秒), 类型为：number, 取值范围：0-65535, 默认值：40

        LsaRetransInterval (int): LSA重传间隔(秒), 类型为：number, 取值范围：0-4294967295, 默认值：5

        LsaRefreshTime (int): LSA刷新间隔(秒), 类型为：number, 取值范围：1-1800, 默认值：1800

    Returns:

        (:obj:`Ospfv3Router`): OSPFv3协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Ospfv3 | Port=${Port} |
    """

    result = renix.create_ospfv3(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ospfv3(Session, **kwargs):
    """
    编辑OSPFv3协议会话对象参数

    Args:

        Session (list(:obj:`Ospfv3Router`)): OSPFv3协议会话对象列表

    Keyword Args:

        Name (str): OSPFv3协会话名称, 类型为：string

        Enable (bool): 使能OSPFv3协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        InstanceId (int): 实例ID, 类型为：number, 取值范围：0-255, 默认值：0

        AreaId (str): 区域ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        EnableExtendedLsa (bool): 使能扩展LSA, 类型为：bool, 取值范围：True或False, 默认值：False

        ExtendedLsaMode (str): 扩展LSA模式, 类型为：string, 默认值：Full, 取值范围：

            NONE

            MixedModeOriginateOnly

            MixedModeOriginateSPF

            Full

        AreaExtendedLsaMode (str): 扩展区域LSA模式, 类型为：string, 默认值：InheritGlobal, 取值范围：

            InheritGlobal

            NONE

            MixedModeOriginateOnly

            MixedModeOriginateSPF

            Full

        EnableBfd (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        NetworkType (str): 网络类型, 类型为：string, 取值范围：Broadcast或P2P, 默认值：Broadcast

        Priority (int): 路由器优先级, 类型为：number, 取值范围：0-255, 默认值：0

        InterfaceId (int): 接口ID, 类型为：number, 取值范围：0-4294967295, 默认值：10

        Cost (int): 接口开销, 类型为：number, 取值范围：1-65535, 默认值：10

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'V6BIT', 'EBIT', 'RBIT'], 支持选项有：

            NONTBIT

            V6BIT

            EBIT

            MCBIT

            NBIT

            RBIT

            DCBIT

            Unused17

            Unused16

            Unused15

            Unused14

            Unused13

            Unused12

            Unused11

            Unused10

            Unused9

            Unused8

            Unused7

            Unused6

            Unused5

            Unused4

            Unused3

            Unused2

            Unused1

            Unused0

        EnableOspfv3Mtu (bool): 使能OSPFv3 MTU, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        GracefulRestartReason (str): 平滑重启原因, 类型为：string, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            SOFTWARE

            RELOADORUPGRADE

            SWITCH

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        HelloInterval (int): Hello包间隔(秒), 类型为：number, 取值范围：0-65535, 默认值：10

        RouterDeadInterval (int): 路由器失效间隔(秒), 类型为：number, 取值范围：0-65535, 默认值：40

        LsaRetransInterval (int): LSA重传间隔(秒), 类型为：number, 取值范围：0-4294967295, 默认值：5

        LsaRefreshTime (int): LSA刷新间隔(秒), 类型为：number, 取值范围：1-1800, 默认值：1800

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Ospfv3 | Session=${Session} |
    """

    result = renix.edit_ospfv3(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_router_lsa(Session, **kwargs):
    """
    创建OSPFv3 Router LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Router LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.0.0.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        RouterType (str): 路由器类型, 类型为：string, 默认值：NONTBIT, 支持选项有：

            NONEBIT

            RouterTypeABR

            RouterTypeASBR

            RouterTypeVirtype

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            V6BIT

            EBIT

            MCBIT

            NBIT

            RBIT

            DCBIT

            Unused17

            Unused16

            Unused15

            Unused14

            Unused13

            Unused12

            Unused11

            Unused10

            Unused9

            Unused8

            Unused7

            Unused6

            Unused5

            Unused4

            Unused3

            Unused2

            Unused1

            Unused0

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3RouterLsaConfig`): OSPFv3 Router LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Router Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_router_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_router_lsa_link(RouterLsa, **kwargs):
    """
    创建OSPFv3 Router LSA Link对象

    Args:

        RouterLsa (:obj:`Ospfv3RouterLsaConfig`): 测试仪表OSPFv3 Router LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Router LSA Link的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        LinkType (str): 链路类型, 类型为：string, 默认值：P2P, 支持选项有：

            P2P

            TRANSITNETWORK

            VIRTUALLINK

        InterfaceId (int): 接口ID,即该ID用于唯一标识simulated router的接口, 类型为：number, 取值范围：0-4294967295, 默认值：1

        NeighborInterfaceId (int): 邻居接口ID,即该ID用于唯一标识邻居路由器的接口, 类型为：number, 取值范围：0-4294967295, 默认值：1

        NeighborRouterId (str): 邻居路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.0.0.1

        Metric (int): 度量值, 类型为：number, 取值范围：1-65535, 默认值：1

    Returns:

        (:obj:`Ospfv3RouterLsaLinksConfig`): OSPFvv3 Router LSA Link对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${RouterLsa} | Create Ospfv3 Router Lsa | Session=${Session} | Age=20 |
            | Create Ospfv3 Router Lsa Link | RouterLsa=${RouterLsa} | Metric=65535 |
    """

    result = renix.create_ospfv3_router_lsa_link(RouterLsa=RouterLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def create_ospfv3_srv6_endx_sid_sub_tlv(Session, RouterLsaLink, **kwargs):
    """
    创建OSPFv3 Srv6 EndX Sid Sub Tlv对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

        RouterLsaLink (:obj:`Ospfv3RouterLsaLinksConfig`): OSPFv3 Router Lsa LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 EndX Sid Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        EndpointBehaviorId (int): SRv6 SID的端点行为ID, 类型为：number, 默认值：0

        Flags (list): 包含在TLV中的标志位, 类型为：list, 默认值：NONEBIT, 取值范围：

            NONEBIT

            Unused0

            Unused1

            Unused2

            Unused3

            Unused4

            PersistentFlag

            SetFlag

            BackupFlag

        Algorithm (int): SID关联的算法, 类型为：number, 取值范围：0-255, 默认值：0

        Weight (int): END.X SID / LAN END.X SID的权重，用于负载分担, 类型为：number, 取值范围：0-255, 默认值：1

        Sid (str): 通告的SRv6 SID, 邻居路由器ID, 类型为：string, 取值范围：有效的ipv6地址, 默认值：'aaaa:1:1:1::'

    Returns:

        (:obj:`Ospfv3Srv6EndXSidSubTlvConfig`): OSPFv3 Srv6 EndX Sid Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${RouterLsa} | Create Ospfv3 Router Lsa | Session=${Session} | Age=20 |
            | ${LsaLink} | Create Ospfv3 Router Lsa Link | RouterLsa=${RouterLsa} | Metric=65535 |
            | Create Ospfv3 Srv6 Endx Sid Sub Tlv | RouterLsaLink=${LsaLink} |
    """

    result = renix.create_ospfv3_srv6_endx_sid_sub_tlv(Session=Session, RouterLsaLink=RouterLsaLink, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_lan_endx_sid_sub_tlv(Session, RouterLsaLink, **kwargs):
    """
    创建OSPFv3 Srv6 Lan EndX Sid Sub Tlv对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

        RouterLsaLink (:obj:`Ospfv3RouterLsaLinksConfig`): OSPFv3 Router Lsa LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Lan EndX Sid Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        EndpointBehaviorId (int): SRv6 SID的端点行为ID, 类型为：number, 默认值：0

        Flags (list): 包含在TLV中的标志位, 类型为：list, 默认值：NONEBIT, 取值范围：

            NONEBIT

            Unused0

            Unused1

            Unused2

            Unused3

            Unused4

            PersistentFlag

            SetFlag

            BackupFlag

        Algorithm (int): SID关联的算法, 类型为：number, 取值范围：0-255, 默认值：0

        Weight (int): END.X SID / LAN END.X SID的权重，用于负载分担, 类型为：number, 取值范围：0-255, 默认值：1

        Sid (str): 通告的SRv6 SID, 邻居路由器ID, 类型为：string, 取值范围：有效的ipv6地址, 默认值：'aaaa:1:1:1::'

    Returns:

        (:obj:`Ospfv3Srv6LanEndXSidSubTlvConfig`): OSPFv3 Srv6 Lan EndX Sid Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${RouterLsa} | Create Ospfv3 Router Lsa | Session=${Session} | Age=20 |
            | ${LsaLink} | Create Ospfv3 Router Lsa Link | RouterLsa=${RouterLsa} | Metric=65535 |
            | Create Ospfv3 Srv6 Lan Endx Sid Sub Tlv | RouterLsaLink=${LsaLink} |
    """

    result = renix.create_ospfv3_srv6_lan_endx_sid_sub_tlv(Session=Session, RouterLsaLink=RouterLsaLink, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_link_msd_sub_tlv(Session, RouterLsaLink, **kwargs):
    """
    创建OSPFv3 Srv6 Link Msd Sub Tlv对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

        RouterLsaLink (:obj:`Ospfv3RouterLsaLinksConfig`): OSPFv3 Router Lsa LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Link Msd Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Msds (list): 包含在TLV中的标志位, 类型为：list, 默认值：NONEBIT, 取值范围：

            NONTBIT

            MaxiSegmentLeft

            MaxiEndPop

            MaxiTInsert

            MaxiTEncaps

            MaxiEndD

        MaximumEndDSrh (int): 接收报文的SRH中SL（Segment Left）字段的最大值, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumEndPop (int): SRH栈的顶端SRH中SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumSegmentsLeft (int): 执行T.Insert行为时可包含SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumTEncapSrh (int): 执行T.Encap行为时可包含SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumTInsertSrh (int): 执行End.DX6和End.DT6功能时，SRH中SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

    Returns:

        (:obj:`Ospfv3Srv6MsdSubTlvConfig`): OSPFv3 Srv6 Link Msd Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${RouterLsa} | Create Ospfv3 Router Lsa | Session=${Session} | Age=20 |
            | ${LsaLink} | Create Ospfv3 Router Lsa Link | RouterLsa=${RouterLsa} | Metric=65535 |
            | Create Ospfv3 Srv6 Msd Sid Sub Tlv | RouterLsaLink=${LsaLink} |
    """

    result = renix.create_ospfv3_srv6_link_msd_sub_tlv(Session=Session, RouterLsaLink=RouterLsaLink, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_endx_sid_structure_sub_tlv(SubTlv, **kwargs):
    """
    创建OSPFv3 Endx Sid Structure Sub Tlv对象

    Args:

        SubTlv (:obj:`Ospfv3Srv6EndXSidSubTlvConfig`): OSPFv3 Srv6 EndX Sid Sub Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Link Msd Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        LbLength (int): SRv6 SID Locator Block长度, 类型为：number, 取值范围：0-128, 默认值：32

        LnLength (int): SRv6 SID Locator Node长度, 类型为：number, 取值范围：0-128, 默认值：32

        FunctionLength (int): SRv6 SID Function长度, 类型为：number, 取值范围：0-128, 默认值：32

        ArgumentLength (int): SRv6 SID Argument长度, 类型为：number, 取值范围：0-128, 默认值：32

    Returns:

        (:obj:`Ospfv3Srv6SidStructureSubTlvConfig`): Ospfv3 Endx Sid Structure Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${RouterLsa} | Create Ospfv3 Router Lsa | Session=${Session} | Age=20 |
            | ${LsaLink} | Create Ospfv3 Router Lsa Link | RouterLsa=${RouterLsa} | Metric=65535 |
            | ${SubTlv} | Create Ospfv3 Srv6 Msd Sid Sub Tlv | RouterLsaLink=${LsaLink} |
            | Create Ospfv3 Endx Sid Structure Sub Tlv | SubTlv=${SubTlv} |
    """

    result = renix.create_ospfv3_endx_sid_structure_sub_tlv(SubTlv=SubTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def create_ospfv3_lan_endx_sid_structure_sub_tlv(SubTlv, **kwargs):
    """
    创建OSPFv3 Lan Endx Sid Structure Sub Tlv对象

    Args:

        SubTlv (:obj:`Ospfv3Srv6LanEndXSidSubTlvConfig`): OSPFv3 Srv6 Lan EndX Sid Sub Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Link Msd Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        LbLength (int): SRv6 SID Locator Block长度, 类型为：number, 取值范围：0-128, 默认值：32

        LnLength (int): SRv6 SID Locator Node长度, 类型为：number, 取值范围：0-128, 默认值：32

        FunctionLength (int): SRv6 SID Function长度, 类型为：number, 取值范围：0-128, 默认值：32

        ArgumentLength (int): SRv6 SID Argument长度, 类型为：number, 取值范围：0-128, 默认值：32

    Returns:

        (:obj:`Ospfv3Srv6LanEndXSidSubTlvConfig`): Ospfv3 Lan Endx Sid Structure Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${RouterLsa} | Create Ospfv3 Router Lsa | Session=${Session} | Age=20 |
            | ${LsaLink} | Create Ospfv3 Router Lsa Link | RouterLsa=${RouterLsa} | Metric=65535 |
            | ${SubTlv} | Create Ospfv3 Srv6 Msd Sid Sub Tlv | RouterLsaLink=${LsaLink} |
            | Create Ospfv3 Lan Endx Sid Structure Sub Tlv | SubTlv=${SubTlv} |
    """

    result = renix.create_ospfv3_lan_endx_sid_structure_sub_tlv(SubTlv=SubTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def create_ospfv3_network_lsa(Session, **kwargs):
    """
    创建OSPFv3 Network LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Network LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            V6BIT

            EBIT

            MCBIT

            NBIT

            RBIT

            DCBIT

            Unused17

            Unused16

            Unused15

            Unused14

            Unused13

            Unused12

            Unused11

            Unused10

            Unused9

            Unused8

            Unused7

            Unused6

            Unused5

            Unused4

            Unused3

            Unused2

            Unused1

            Unused0

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3NetworkLsaConfig`): OSPFv3 Network LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Network Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_network_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_network_atch_router(Lsa, **kwargs):
    """
    创建OSPFv3 Network LSA Atch Router对象

    Args:

        Lsa (:obj:`Ospfv3NetworkLsaConfig`): 测试仪表OSPFv3 Network LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Network LSA Atch Router的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AttachedRouter (str): 附加路由器的IP地址, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

    Returns:

        (:obj:`Ospfv3NetworkAtchRouterConfig`): OSPFv3 Network LSA Atch Router对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${RouterLsa} | Create Ospfv3 Network Lsa | Session=${Session} | Age=20 |
            | Create Ospfv3 Network Lsa Atch Router | Lsa=${RouterLsa} | Metric=65535 |
    """

    result = renix.create_ospfv3_network_atch_router(Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_intra_area_prefix_lsa(Session, **kwargs):
    """
    创建OSPFv3 Intra Area Prefix LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Intra Prefix LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        ReferencedLsType (str): 参考LS类型, 类型为：hex number, 取值范围：0x0-0xFFFF, 默认值：0x0

        ReferencedAdvertisingRouterId (str): 参考通告路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        ReferencedLinkStateId (int): 参考链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        ExtendedLsaTlvs (list): 扩展LSA TLVs, 类型为：list, 默认值： Ipv6IntraAreaPrefix, 支持选项有：

            NONE

            Ipv6IntraAreaPrefix

        PrefixCount (int): 前缀个数, 类型为：number, 取值范围：1-4294967295, 默认值：1

        StartPrefixAddress (str): 起始网络前缀, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-128, 默认值：64

        Increment (int): 步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        PrefixOptions (list): 前缀选项, 类型为：list, 默认值： NONTBIT, 支持选项有：

            NONTBIT

            NUBIT

            LABIT

            MCBIT

            PBIT

            DNBit

            NBit

            Unused1

            Unused0

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：1

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3IntraAreaPrefixLsaConfig`): Ospfv3 Intra Area Prefix LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Intra Area Prefix Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_intra_area_prefix_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_inter_area_prefix_lsa(Session, **kwargs):
    """
    创建OSPFv3 Inter Area Prefix LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Inter Prefix LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        ExtendedLsaTlvs (list): 扩展LSA TLVs, 类型为：list, 默认值： Ipv6InterAreaPrefix, 支持选项有：

            NONE

            Ipv6InterAreaPrefix

        PrefixCount (int): 前缀个数, 类型为：number, 取值范围：1-4294967295, 默认值：1

        StartPrefixAddress (str): 起始网络前缀, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-128, 默认值：64

        Increment (int): 步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        PrefixOptions (list): 前缀选项, 类型为：list, 默认值： NONTBIT, 支持选项有：

            NONTBIT

            NUBIT

            LABIT

            MCBIT

            PBIT

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：1

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3InterAreaPrefixLsaConfig`): Ospfv3 Inter Area Prefix LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Inter Area Prefix Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_inter_area_prefix_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_inter_area_router_lsa(Session, **kwargs):
    """
    创建OSPFv3 Inter Area Router LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Router LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        AsbrId (str): ASBR ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：1

        Options (list): 选项, 类型为：list, 默认值： NONTBIT | V6BIT | EBIT, 支持选项有：

            NONTBIT

            V6BIT

            EBIT

            MCBIT

            NBIT

            RBIT

            DCBIT

            Unused17

            Unused16

            Unused15

            Unused14

            Unused13

            Unused12

            Unused11

            Unused10

            Unused9

            Unused8

            Unused7

            Unused6

            Unused5

            Unused4

            Unused3

            Unused2

            Unused1

            Unused0

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3InterAreaRouterLsaConfig`): Ospfv3 Inter Area Router LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Inter Area Router Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_inter_area_router_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_sr_fapm_sub_tlv(Lsa, **kwargs):
    """
    创建OSPFv3 Sr Fapm Sub Tlv对象

    Args:

        Lsa (:obj:`Ospfv3InterAreaRouterLsaConfig`): Ospfv3 Inter Area Router LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Sr Fapm Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Algorithm (int): 灵活算法ID, 类型为：number, 取值范围：128-255, 默认值：128

        Metric (int): 度量值, 类型为：number, 取值范围：128-255, 默认值：0

    Returns:

        (:obj:`Ospfv3SrFapmSubTlvConfig`): Ospfv3 Sr Fapm Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Inter Area Prefix Lsa | Session=${Session} | Age=20 |
            | Create Ospfv3 Sr Fapm Sub Tlv | Lsa=${Lsa} |
    """

    result = renix.create_ospfv3_sr_fapm_sub_tlv(Lsa=Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_bier_sub_tlv(Lsa, **kwargs):
    """
    创建OSPFv3 Bier Sub Tlv对象

    Args:

        Lsa (:obj:`Ospfv3InterAreaRouterLsaConfig`): Ospfv3 Inter Area Router LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Bier Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        TlvType (int): Type字段值, 类型为：number, 取值范围：0-255, 默认值：9

        SubDomainId (int): BIER子域ID, 类型为：number, 取值范围：1-255, 默认值：1

        MtId (int): 多拓扑ID, 类型为：number, 取值范围：1-255, 默认值：1

        BfrId (int): BFR（Bit Forwarding Router，比特转发路由器）ID, 类型为：number, 取值范围：1-65535, 默认值：1

        Bar (int): BIER算法, 类型为：number, 取值范围：0-255, 默认值：0

        Ipa (int): IGP算法, 类型为：number, 取值范围：0-255, 默认值：0

    Returns:

        (:obj:`Ospfv3BierSubTlvConfig`): Ospfv3 Bier Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Inter Area Prefix Lsa | Session=${Session} | Age=20 |
            | Create Ospfv3 Bier Sub Tlv | Lsa=${Lsa} |
    """

    result = renix.create_ospfv3_bier_sub_tlv(Lsa=Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_bier_mpls_encap_sub_tlv(SubTlv, **kwargs):
    """
    创建OSPFv3 Bier Mpls Encap Sub Tlv对象

    Args:

        SubTlv (:obj:`Ospfv3BierSubTlvConfig`): Ospfv3 Bier Sub Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Bier Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        TlvType (int): Type字段值, 类型为：number, 取值范围：0-255, 默认值：10

        MaxSi (int): 最大Set ID, 类型为：number, 取值范围：1-255, 默认值：1

        Label (int): 标签范围中的起始标签值, 类型为：number, 取值范围：0-1048575, 默认值：100

        BsLen (int): 本地比特串的长度, 类型为：number, 取值范围：0-15, 默认值：4

    Returns:

        (:obj:`Ospfv3BierMplsEncapSubTlvConfig`): Ospfv3 Bier Mpls Encap Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Inter Area Prefix Lsa | Session=${Session} | Age=20 |
            | ${SubTlv} | Create Ospfv3 Bier Sub Tlv | Lsa=${Lsa} |
            | Create Ospfv3 Bier Mpls Encap Sub Tlv | SubTlv=${SubTlv} |
    """

    result = renix.create_ospfv3_bier_mpls_encap_sub_tlv(SubTlv=SubTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_as_external_lsa(Session, **kwargs):
    """
    创建OSPFv3 As External LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 As External LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        PrefixCount (int): 前缀个数, 类型为：number, 取值范围：1-4294967295, 默认值：1

        StartPrefixAddress (str): 起始网络前缀, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-128, 默认值：64

        Increment (int): 步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        PrefixOptions (list): 前缀选项, 类型为：list, 默认值： NONTBIT, 支持选项有：

            NONTBIT

            NUBIT

            LABIT

            MCBIT

            PBIT

            DNBit

            NBit

            Unused1

            Unused0

        IsExternalMetric (bool): 是否外部度量值, 类型为：bool, 取值范围：True或False, 默认值：False

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：1

        EnableForwardingAddress (bool): 使能转发地址, 类型为：bool, 取值范围：True或False, 默认值：False

        ForwardingAddress (str): 转发地址,即：LSA中携带的转发地址, 类型为：string, 取值范围：IPv6地址, 默认值：'::'

        AdminTag (int): 管理标签, 类型为：number, 取值范围：0-4294967295, 默认值：0

        ReferencedLsType (int): 参考链路状态类型, 类型为：hex number, 取值范围：0x0-0xFFFF, 默认值：0x0

        ReferencedLinkStateId (int): 参考链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        LsaAutomaticConversion (bool): LSA自动转换, 即：当配置的会话为NSSA会话时,Renix会自动将此处配置的外部LSA转换为NSSA-LSA进行发送;当配置的会话为非NSSA会话时,Renix会自动将此处配置的NSSA-LSA转换为外部LSA进行发送, 类型为：bool, 取值范围：True或False, 默认值：True

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3AsExternalLsaConfig`): OSPFv3 As External LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 As External Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_as_external_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_nssa_external_lsa(Session, **kwargs):
    """
    创建OSPFv3 Nssa External LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Nssa External LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        ExtendedLsaTlvs (list): 扩展LSA TLVs, 类型为：list, 默认值： Ipv6ExternalPrefix, 支持选项有：

            NONE

            Ipv6ExternalPrefix

        ExtendedLsaSubTlvs (list): 扩展LSA Sub-TLV, 类型为：list, 默认值： NONTBIT, 支持选项有：

            NONE

            Ipv6ForwardingAddr

            Ipv4ForwardingAddr

            RouteTag

        PrefixCount (int): 前缀个数, 类型为：number, 取值范围：1-4294967295, 默认值：1

        StartPrefixAddress (str): 起始网络前缀, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-128, 默认值：64

        Increment (int): 步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        PrefixOptions (list): 前缀选项, 类型为：list, 默认值： NONTBIT, 支持选项有：

            NONTBIT

            NUBIT

            LABIT

            MCBIT

            PBIT

            DNBit

            NBit

            Unused1

            Unused0

        IsExternalMetric (bool): 是否外部度量值, 类型为：bool, 取值范围：True或False, 默认值：False

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：1

        EnableForwardingAddress (bool): 使能转发地址, 类型为：bool, 取值范围：True或False, 默认值：False

        ForwardingAddress (str): Ipv6转发地址,即：LSA中携带的转发地址, 类型为：string, 取值范围：IPv6地址, 默认值：'::'

        Ipv4ForwardingAddress (str): IPv4转发地址, 取值范围：IPv4地址, 默认值：0.0.0.0

        AdminTag (int): 管理标签, 类型为：number, 取值范围：0-4294967295, 默认值：0

        ReferencedLsType (int): 参考链路状态类型, 类型为：hex number, 取值范围：0x0-0xFFFF, 默认值：0x0

        ReferencedLinkStateId (int): 参考链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

        LsaAutomaticConversion (bool): LSA自动转换, 即：当配置的会话为NSSA会话时,Renix会自动将此处配置的外部LSA转换为NSSA-LSA进行发送;当配置的会话为非NSSA会话时,Renix会自动将此处配置的NSSA-LSA转换为外部LSA进行发送, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3NssaExternalLsaConfig`): OSPFv3 Nssa External LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Nssa External Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_nssa_external_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_link_lsa(Session, **kwargs):
    """
    创建OSPFv3 Link LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Link LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LinkStateId (int): 链路状态ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        ExtendedLsaTlvs (list): 扩展LSA TLVs, 类型为：list, 默认值： Ipv6IntraAreaPrefix, 支持选项有：

            NONE

            Ipv6IntraAreaPrefix

            Ipv6LinkLocalAddr

            Ipv4LinkLocalAddr

        PrefixCount (int): 前缀个数, 类型为：number, 取值范围：1-4294967295, 默认值：1

        StartPrefixAddress (str): 起始网络前缀, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-128, 默认值：64

        Increment (int): 步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        PrefixOptions (list): 前缀选项, 类型为：list, 默认值： NONTBIT, 支持选项有：

            NONTBIT

            NUBIT

            LABIT

            MCBIT

            PBIT

            DNBit

            NBit

            Unused1

            Unused0

        LinkLocalInterfaceAddress (str): 本地链路接口地址, 类型为：string, 取值范围：IPv6地址, 默认值：fe80::1

        Ipv4LinkLocalInterfaceAddress (str): 本地链路接口地址, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.0.0

        RouterPriority (int): 路由优先级, 类型为：number, 取值范围：1-255, 默认值：1

        Options (list): 选项, 类型为：list, 默认值： NONTBIT | V6BIT | EBIT, 支持选项有：

            NONTBIT

            V6BIT

            EBIT

            MCBIT

            NBIT

            RBIT

            DCBIT

            Unused17

            Unused16

            Unused15

            Unused14

            Unused13

            Unused12

            Unused11

            Unused10

            Unused9

            Unused8

            Unused7

            Unused6

            Unused5

            Unused4

            Unused3

            Unused2

            Unused1

            Unused0

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3LinkLsaConfig`): OSPFv3 Link LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Link Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_link_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_opaque_router_info_lsa(Session, **kwargs):
    """
    创建OSPFv3 Opaque Router Info LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Opaque Router Info LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Scope (str): 起始网络前缀, 类型为：string, 默认值：AreaLocal, 取值范围：

            LinkLocal

            AreaLocal

            AreaSystemWide

        AdvertisingRouterId (str): 起始网络前缀, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.0.1

        LinkStateId (int): 路由优先级, 类型为：number, 取值范围：1-255, 默认值：0

        TlvsFlag (list): 前缀选项, 类型为：list, 默认值： ['NONTBIT', 'InfoCapabilities'], 支持选项有：

            NONEBIT

            InfoCapabilities

            FuncCapabilities

        InformationalCapabilities (list): 前缀选项, 类型为：list, 默认值： NONEBIT, 支持选项有：

            NONEBIT

            RcBit

            RhBit

            SrsBit

            TesBit

            PolBit

            Etbit

            MiBit

            SrhBit

            Unused8

            Unused9

            Unused10

            Unused11

            Unused12

            Unused13

            Unused14

            Unused15

            Unused16

            Unused17

            Unused18

            Unused19

            Unused20

            Unused22

            Unused21

            Unused23

            Unused24

            Unused25

            Unused26

            Unused27

            Unused28

            Unused29

            Unused30

        FunctionalCapabilities (list): 前缀选项, 类型为：list, 默认值： NONEBIT, 支持选项有：

            NONEBIT

            Unused0

            Unused1

            Unused2

            Unused3

            Unused4

            Unused5

            Unused6

            Unused7

            Unused8

            Unused9

            Unused10

            Unused11

            Unused12

            Unused13

            Unused14

            Unused15

            Unused16

            Unused17

            Unused18

            Unused19

            Unused20

            Unused22

            Unused21

            Unused23

            Unused24

            Unused25

            Unused26

            Unused27

            Unused28

            Unused29

            Unused30

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3OpaqueRouterInfoLsaConfig`): OSPFv3 Opaque Router Info LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_opaque_router_info_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_sr_algorithm_tlv(Lsa, **kwargs):
    """
    创建OSPFv3 Sr Algorithm Tlv对象

    Args:

        Lsa (:obj:`Ospfv3OpaqueRouterInfoLsaConfig`): Ospfv3 Opaque Router Info LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Sr Algorithm Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Algorithms (int): 算法, 类型为：number, 默认值：0

    Returns:

        (:obj:`Ospfv3SrAlgorithmTlvConfig`): Ospfv3 Sr Algorithm Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | Create Ospfv3 Sr Algorithm Tlv | Lsa=${Lsa} |
    """

    result = renix.create_ospfv3_sr_algorithm_tlv(Lsa=Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_sr_fad_tlv(Session, Lsa, **kwargs):
    """
    创建OSPFv3 Sr Fad Tlv对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

        Lsa (:obj:`Ospfv3OpaqueRouterInfoLsaConfig`): Ospfv3 Opaque Router Info LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Sr Fad Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        FlexAlgorithm (int): 灵活算法ID, 类型为：number, 取值范围：128-255, 默认值：128

        MetricType (str): 度量类型, 类型为：string, 默认值：IGPMetric, 取值范围：

            IGPMetric

            MinUnidirectionalLinkDelay

            TEDefaultMetric

        CalculationType (int): 特定IGP算法的计算类型, 类型为：number, 取值范围：0-127, 默认值：0

        Priority (int): 该TLV的优先级, 类型为：number, 取值范围：0-255, 默认值：0

        FlexAlgorithmSubTlvs (list): 灵活算法路径计算要遵循的约束条件, 类型为：list, 默认值： NONEBIT, 支持选项有：

            NONEBIT

            ExcludeAdminGroups

            IncludeAnyAdminGroups

            IncludeAllAdminGroups

            DefinitionFlags

            ExcludeSRLG

        ExcludeAdminGroups (int): 算法, 类型为：number, 取值范围：0-4294967295, 默认值：0

        IncludeAnyAdminGroups (int): 算法, 类型为：number, 取值范围：0-4294967295, 默认值：0

        IncludeAllAdminGroups (int): 算法, 类型为：number, 取值范围：0-4294967295, 默认值：0

        DefinitionFlags (int): 算法, 类型为：number, 取值范围：0-FF, 默认值：0x80

        ExcludeSRLG (int): 算法, 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`Ospfv3SrFadTlvConfig`): Ospfv3 Sr Fad Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | Create Ospfv3 Sr Fad Tlv | Lsa=${Lsa} |
    """

    result = renix.create_ospfv3_sr_fad_tlv(Session=Session, Lsa=Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_capabilities_tlv(Session, Lsa, **kwargs):
    """
    创建OSPFv3 Srv6 Capabilities Tlv对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

        Lsa (:obj:`Ospfv3OpaqueRouterInfoLsaConfig`): Ospfv3 Opaque Router Info LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Capabilities Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Flags (list): 类型为：list, 默认值： NONEBIT, 支持选项有：

            NONEBIT

            Unused0

            OFlag

            Unused2

            Unused3

            Unused4

            Unused5

            Unused6

            Unused7

            Unused8

            Unused9

            Unused10

            Unused11

            Unused12

            Unused13

            Unused14

            Unused15

    Returns:

        (:obj:`Ospfv3Srv6CapabilitiesTlvConfig`): Ospfv3 Srv6 Capabilities Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | Create Ospfv3 Srv6 Capabilities Tlv | Lsa=${Lsa} |
    """

    result = renix.create_ospfv3_srv6_capabilities_tlv(Session=Session, Lsa=Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_node_msd_tlv(Session, Lsa, **kwargs):
    """
    创建OSPFv3 Srv6 Node Msd Tlv对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

        Lsa (:obj:`Ospfv3OpaqueRouterInfoLsaConfig`): Ospfv3 Opaque Router Info LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Node Msd Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Msds (list): 包含在TLV中的标志位, 类型为：list, 默认值：NONEBIT, 取值范围：

            NONTBIT

            MaxiSegmentLeft

            MaxiEndPop

            MaxiTInsert

            MaxiTEncaps

            MaxiEndD

        MaximumEndDSrh (int): 接收报文的SRH中SL（Segment Left）字段的最大值, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumEndPop (int): SRH栈的顶端SRH中SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumSegmentsLeft (int): 执行T.Insert行为时可包含SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumTEncapSrh (int): 执行T.Encap行为时可包含SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaximumTInsertSrh (int): 执行End.DX6和End.DT6功能时，SRH中SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

    Returns:

        (:obj:`Ospfv3Srv6MsdSubTlvConfig`): OSPFv3 Srv6 Link Msd Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | Create Ospfv3 Srv6 Node Msd Tlv | Lsa=${Lsa} |
    """

    result = renix.create_ospfv3_srv6_node_msd_tlv(Session=Session, Lsa=Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_location_lsa(Session, **kwargs):
    """
    创建OSPFv3 Srv6 Location LSA对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Location LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Scope (str): 起始网络前缀, 类型为：string, 默认值：AreaLocal, 取值范围：

            LinkLocal

            AreaLocal

            AreaSystemWide

        AdvertisingRouterId (str): 起始网络前缀, 类型为：string, 取值范围：IPv4地址, 默认值：192.0.0.1

        LinkStateId (int): 路由优先级, 类型为：number, 取值范围：1-255, 默认值：0

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv3Srv6LocatorLsaConfig`): OSPFv3 Srv6 Location LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | Create Ospfv3 Srv6 Location LSA | Session=${Session} | Age=20 |
    """

    result = renix.create_ospfv3_srv6_location_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_location_tlv(Session, Lsa, **kwargs):
    """
    创建OSPFv3 Srv6 Location Tlv对象

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：object

        Lsa (:obj:`Ospfv3Srv6LocatorLsaConfig`): Ospfv3 Srv6 Location LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Location Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        RouterType (str): 路由器类型, 类型为：string, 默认值：IntraArea, 支持选项有：

            IntraArea

            InterArea

            ASExternal

            NSSAExternal

        Algorithm (int): Locator关联算法, 类型为：number, 取值范围：0-255, 默认值：0

        LocatorLength (int): Locator前缀长度, 类型为：number, 取值范围：0-128, 默认值：64

        Flags (list): 类型为：list, 默认值： NONEBIT, 支持选项有：

            NONEBIT

            Unused0

            Unused1

            Unused2

            Unused3

            Unused4

            Unused5

            ABit

            NFlag

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：1

        Locator (str): 通告的Locator, 类型为：string, 取值范围：有效的ipv6地址, 默认值：'aaaa:1:1:1::'

    Returns:

        (:obj:`Ospfv3Srv6LocatorTlvConfig`): Ospfv3 Srv6 Location Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | Create Ospfv3 Srv6 Location Tlv | Lsa=${Lsa} |
    """

    result = renix.create_ospfv3_srv6_location_tlv(Session=Session, Lsa=Lsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_end_sid_sub_tlv(Tlv, **kwargs):
    """
    创建OSPFv3 Srv6 End Sid Sub Tlv对象

    Args:

        Tlv (:obj:`Ospfv3Srv6LocatorTlvConfig`): Ospfv3 Srv6 Location Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Lan EndX Sid Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        EndpointBehaviorId (int): SRv6 SID的端点行为ID, 类型为：int, 默认值：0, 取值范围：0-65535

        Flags (int): 包含在TLV中的标志位, 类型为：int, 默认值：0, 取值范围：0-255

        Sid (str): 通告的SRv6 SID, 邻居路由器ID, 类型为：string, 取值范围：有效的ipv6地址, 默认值：'aaaa:1:1:1::'

    Returns:

        (:obj:`Ospfv3Srv6EndSidSubTlvConfig`): Ospfv3 Srv6 End Sid Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | ${Tlv} | Create Ospfv3 Srv6 Location Tlv | Lsa=${Lsa} |
            | Create OSPFv3 Srv6 End Sid Sub Tlv | Tlv=${Tlv} | Flags=255 |
    """

    result = renix.create_ospfv3_srv6_end_sid_sub_tlv(Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospfv3_srv6_sid_structure_sub_tlv(SubTlv, **kwargs):
    """
    创建OSPFv3 Srv6 Sid Structure Sub Tlv对象

    Args:

        SubTlv (:obj:`Ospfv3Srv6EndSidSubTlvConfig`): OSPFv3 Srv6 End Sid Sub Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv3 Srv6 Sid Structure Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        LbLength (int): SRv6 SID Locator Block长度, 类型为：number, 取值范围：0-128, 默认值：32

        LnLength (int): SRv6 SID Locator Node长度, 类型为：number, 取值范围：0-128, 默认值：32

        FunctionLength (int): SRv6 SID Function长度, 类型为：number, 取值范围：0-128, 默认值：32

        ArgumentLength (int): SRv6 SID Argument长度, 类型为：number, 取值范围：0-128, 默认值：32

    Returns:

        (:obj:`Ospfv3Srv6SidStructureSubTlvConfig`): Ospfv3 Endx Sid Structure Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | ${Tlv} | Create Ospfv3 Srv6 Location Tlv | Lsa=${Lsa} |
            | ${SubTlv} | Create OSPFv3 Srv6 End Sid Sub Tlv | Tlv=${Tlv} | Flags=255 |
            | Create OSPFv3 Srv6 Sid Structure Sub Tlv | SubTlv=${SubTlv} | LbLength=128 |
    """

    result = renix.create_ospfv3_srv6_sid_structure_sub_tlv(SubTlv=SubTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ospf_router_from_lsa(Lsa):
    """
    获取Ospfv2/Ospfv3 lsa对应的绑定流源或目的端点对象

    Args:

        Lsa (list(:obj:`Ospfv3RouterLsaConfig`)): 测试仪表Ospfv2/Ospfv3 Lsa对象列表

    Returns:

        (list(:obj:`Ospfv3InterAreaRoute`)): Ospfv2/Ospfv3 Lsa对应的绑定流源或目的端点对象列表

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospfv3 | Port=${Port} |
            | ${Lsa} | Create Ospfv3 Opaque Router Info LSA | Session=${Session} | Age=20 |
            | ${Point} | Get Router From Route Pool | Lsa=${Lsa} |
    """

    result = renix.get_ospf_router_from_lsa(Lsa=Lsa)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def establish_ospfv3(Sessions):
    """
    建立OSPFv3协议会话

    Args:

        Sessions (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Establish Ospfv3 | Sessions=${Sessions} |
    """

    result = renix.establish_ospf(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def grace_restart_ospfv3(Sessions):
    """
    平滑重启OSPFv3协议会话

    Args:

        Sessions (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Grace Restart Ospfv3 | Sessions=${Sessions} |
    """

    result = renix.grace_restart_ospfv3(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def advertise_ospfv3_lsa(Sessions=None, Type=None, Lsa=None):
    """
    通告OSPFv3协议会话lsa

    Args:

        Sessions (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：list

        Type (str): OSPFv3 lsa类型, 类型为：string, 支持的lsa类型：

            Router

            Network

            InterAreaPrefix

            InterAreaRouter

            AsExternal

            Link

        Lsa (int): OSPFv3 lsa列表, 类型为：list, 当Type=None时参数生效

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Advertise Ospfv3 Lsa | Sessions=${Sessions} | Type=router |
            | Advertise Ospfv3 Lsa | Sessions=${Sessions} | Lsa=${Lsas} |
    """

    result = renix.advertise_ospfv3_lsa(Sessions=Sessions, Type=Type, Lsa=Lsa)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def withdraw_ospfv3_lsa(Sessions=None, Type=None, Lsa=None):
    """
    撤销OSPFv3协议会话lsa

    Args:

        Sessions (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：list

        Type (str): OSPFv3 lsa类型, 类型为：string, 支持的lsa类型：

            router

            network

            InterAreaPrefix

            InterAreaRouter

            AsExternal

        Lsa (list): OSPFv3 lsa列表, 类型为：list, 当Type=None时参数生效

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Withdraw Ospfv3 Lsa | Sessions=${Sessions} | Type=router |
            | Withdraw Ospfv3 Lsa | Sessions=${Sessions} | Lsa=${Lsas} |
    """

    result = renix.withdraw_ospfv3_lsa(Sessions=Sessions, Type=Type, Lsa=Lsa)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ospfv3_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待OSPFv3协议会话达到指定状态

    Args:

        Sessions (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：list

        State (list): 等待OSPFv3协议会话达到的状态, 类型为：string, 默认值：达到DR或BACKUP或DROTHER, 支持下列状态：

            NOTSTART

            P2P

            WAITING

            DR

            BACKUP

            DROTHER

            DISABLE

            DOWN

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ospfv3 State | Sessions=${Sessions} | State=DR | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ospf_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ospfv3_adjacency_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待OSPFv3协议会话达到指定邻接状态

    Args:

        Sessions (:obj:`Ospfv3Router`): OSPFv3协议会话对象列表, 类型为：list

        State (list): 等待OSPFv3协议会话达到的邻接状态, 类型为：string, 默认值：FULL, 支持下列状态：

            DOWN

            INIT

            TWOWAY

            EXSTART

            EXCHANGE

            LOADING

            FULL

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话邻接状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ospfv3 Adjacency State | Sessions=${Sessions} | State=FULL | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ospf_adjacency_state(Sessions=Sessions, State=State, Interval=Interval,
                                             TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ospfv3_statistic(Session=None, StaItems=None):
    """
    获取OSPFv3协议会话统计结果

    Args:

        Session (:obj:`Ospfv3Router`): OSPFv3协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            RouterState

            AdjacencyState

            TxHello

            RxHello

            TxDd

            RxDd

            TxRouterLsa

            RxRouterLsa

            TxNetworkLsa

            RxNetworkLsa

            TxInterAreaPrefixLsa

            RxInterAreaPrefixLsa

            TxInterAreaRouterLsa

            RxInterAreaRouterLsa

            TxAsExternalLsa

            RxAsExternalLsa

            TxNssaLsa

            RxNssaLsa

            TxLinkLsa

            RxLinkLsa

            TxIntraAreaPrefixLsa

            RxIntraAreaPrefixLsa

            TxOpaqueRouterInfoLsa

            RxOpaqueRouterInfoLsa

            TxSrv6LocatorLsa

            RxSrv6LocatorLsa

            TxRequest

            RxRequest

            TxUpdate

            RxUpdate

            TxAck

            RxAck

    Returns:

        dict: eg::

            {
                'AdjacencyState': 'Full',
                'TxUpdate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ospfv3SessionResultPropertySet |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ospfv3 Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ospfv3_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_ospfv3_port_config(Ports, **kwargs):
    """
    修改Ospfv3端口统计对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        TransmitRate (int): OSPFv3 Message Tx Rate (messages/second), 取值范围：1-9000, 默认值：100

        SessionOutstanding (int): OSPFv3 Session Outstanding, 取值范围：1-1000, 默认值：20

        UpdateMsgTransmitRate (int): Deprecated. OSPFv3 Update Message Tx Rate (messages/second), 取值范围：1-9000, 默认值：10

        EnableLoop (bool): Enable Loop Back, 默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Ospfv3 Port Config | Ports=${Ports} | TransmitRate=100 |
    """

    result = renix.edit_ospfv3_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
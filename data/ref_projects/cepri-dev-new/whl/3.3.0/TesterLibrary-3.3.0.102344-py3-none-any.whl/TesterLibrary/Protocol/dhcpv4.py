import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------DHCPv4-------------------------------------
def create_dhcp_client(Port, **kwargs):
    """
    创建DHCPv4客户端协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象

    Keyword Args:

        Name (str): DHCP协议会话名称

        Mode (str): DHCPv4客户端模式，默认值：CLIENT, 支持的参数：

            CLIENT

            RELAY_AGENT

        HostName (str): 主机名字，默认值：XINERTEL

        ParameterRequests (list): 主机请求选项, 默认值：['NONEOPTION', 'SUBNET_MASK', 'DOMAIN_NAME_SERVERS', 'DOMAIN_NAME', 'STATIC_ROUTES'], 支持的参数:

            SUBNET_MASK

            ROUTERS

            DOMAIN_NAME_SERVERS

            DOMAIN_NAME

            STATIC_ROUTES

            IP_LEASE_TIME

            SERVER_IDENTIFIER

            T1

            T2

        EnableRouterOption (bool): 启用路由选项, 默认值：False

        VendorClassIdentifier (str): 供应商识别, 默认值：XINERTEL

        BroadcastFlag (str): 默认值：BROADCAST, 支持参数：

            UNICAST

            BROADCAST

        RelayAgentIp (str): 代理端IP, 取值范围：IPv4地址, 默认值：1.1.1.1

        ServerIp (str): DHCPv4服务端IP, 取值范围：IPv4地址, 默认值：2.1.1.3

        EnableRelayAgentCircuitID (bool): 使能代理电路标识, 默认值：False

        RelayAgentCircuitID (str): 代理电路标识, 默认值：""

        EnableRelayAgentRemoteID (str): 使能代理远程标识, 默认值：False

        RelayAgentRemoteID (str): 代理远程标识, 默认值：""

        EnableSyncAddressToInterface (bool): 使能同步地址到接口, 默认值：True

        HostInterface (:obj:`Interface`): 客户端接口对象, 类型：object

    Returns:

        (:obj:`DhcpClient`): DHCP协议会话对象Object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Dhcp Client | Port=${Port} | Name=DHCP_Client_1 |
    """

    result = renix.create_dhcp_client(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dhcp_client(Session, **kwargs):
    """
    编写DHCP协议会话对象参数

    Args:

        Session (:obj:`DhcpClient`): DHCPv4 Client协议对象

    Keyword Args:

        Name (str): DHCP协议会话名称

        Mode (str): DHCPv4客户端模式，默认值：CLIENT, 支持的参数：

            CLIENT

            RELAY_AGENT

        HostName (str): 主机名字，默认值：XINERTEL

        ParameterRequests (list): 主机请求选项, 默认值：['NONEOPTION', 'SUBNET_MASK', 'DOMAIN_NAME_SERVERS', 'DOMAIN_NAME', 'STATIC_ROUTES'], 支持的参数:

            SUBNET_MASK

            ROUTERS

            DOMAIN_NAME_SERVERS

            DOMAIN_NAME

            STATIC_ROUTES

            IP_LEASE_TIME

            SERVER_IDENTIFIER

            T1

            T2

        EnableRouterOption (bool): 启用路由选项, 默认值：False

        VendorClassIdentifier (str): 供应商识别, 默认值：XINERTEL

        BroadcastFlag (str): 默认值：BROADCAST, 支持参数：

            UNICAST

            BROADCAST

        RelayAgentIp (str): 代理端IP, 取值范围：IPv4地址, 默认值：1.1.1.1

        ServerIp (str): DHCPv4服务端IP, 取值范围：IPv4地址, 默认值：2.1.1.3

        EnableRelayAgentCircuitID (bool): 使能代理电路标识, 默认值：False

        RelayAgentCircuitID (str): 代理电路标识, 默认值：""

        EnableRelayAgentRemoteID (str): 使能代理远程标识, 默认值：False

        RelayAgentRemoteID (str): 代理远程标识, 默认值：""

        EnableSyncAddressToInterface (bool): 使能同步地址到接口, 默认值：True

        HostInterface (:obj:`Interface`): 客户端接口对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Dhcp Client | Session=${Session} | RelayAgentIp=2.2.2.2 |
    """

    result = renix.edit_dhcp_client(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcp_bind(Sessions):
    """
    DHCP客户端请求地址

    Args:

        Sessions (:obj:`DhcpClient`): DHCPv4 Client协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Bind | Sessions=${Sessions} |
    """

    result = renix.dhcp_bind(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcp_abort(Sessions):
    """
    DHCP客户端中断

    Args:

        Sessions (:obj:`DhcpClient`): DHCPv4 Client协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Abort | Sessions=${Sessions} |
    """

    result = renix.dhcp_abort(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcp_rebind(Sessions):
    """
    DHCP客户端广播续租

    Args:

        Sessions (:obj:`DhcpClient`): DHCPv4 Client协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Rebind | Sessions=${Sessions} |
    """

    result = renix.dhcp_rebind(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcp_reboot(Sessions):
    """
    DHCP客户端重新启动

    Args:

        Sessions (:obj:`DhcpClient`): DHCPv4 Client协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Reboot | Sessions=${Sessions} |
    """

    result = renix.dhcp_reboot(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcp_release(Sessions):
    """
    DHCP客户端释放地址

    Args:

        Sessions (:obj:`DhcpClient`): DHCPv4 Client协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Release | Sessions=${Sessions} |
    """

    result = renix.dhcp_release(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcp_renew(Sessions):
    """
    DHCP客户端单播续租

    Args:

        Sessions (:obj:`DhcpClient`): DHCPv4 Client协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Renew | Sessions=${Sessions} |
    """

    result = renix.dhcp_renew(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcp_client_custom_option(Session, **kwargs):
    """
    创建测试仪表DHCP协议会话option对象

    Args:

        Session (:obj:`DhcpClient`): DHCPv4 Client协议对象, 类型为：object / list

    Keyword Args:

        OptionTag (number): 可选项类型标识, 默认值：0, 取值范围：0-255

        OptionType (str): 可选项数据类型, 默认值：HEX, 支持以下参数：

            HEX

            STRING

            BOOLEAN

            INT8

            INT16

            INT32

            IP

        EnableOptionValueList (bool): 可选项值列表, 默认值：False

        OptionValue (str): 可选项值, 默认值：""

        MessageType (list): 携带Option消息类型, 默认值：['DISCOVER'], 支持以下参数：

            DISCOVER

            REQUEST

    Returns:

        (:obj:`Dhcpv4ClientOption`): 测试仪表DHCP协议会话option对象Object

    Examples:
        .. code:: RobotFramework

            | Create Dhcp Client Custom Option | Session=${Sessions} |
    """

    result = renix.create_dhcp_client_custom_option(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dhcp_client_port_config(Ports, **kwargs):
    """
    修改DHCP客户端端口配置对象

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object / list

    Keyword Args:

        SetupRate (int): 建立速率, 默认值: 100, 范围: 1-65535

        TeardownRate: 拆除速率, 默认值: 100, 范围: 1-65535

        MaxOutstanding: 最大同时请求个数速率, 默认值: 100, 范围: 1-65535

        LeaseTime: 期望租约时间（秒）, 默认值: 600, 范围: 1-4294967295

        SessionRetryCount: 创建会话尝试次数, 默认值: 0, 范围: 0-65535

        MessageRetryCount: 消息发送超时尝试次数, 默认值: 5, 范围: 0-65535

        MessageTimeout: 消息超时时间（秒）, 默认值: 10, 范围: 1-99999

        MaxMessageSize: 允许最大有效负荷（字节）, 默认值: 576, 范围: 291-1500

    Returns:

        (:obj:`Dhcpv4PortConfig`): Dhcpv4 Port Config对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dhcp Client Port Config | Port=${Port} | SetupRate=65535 |
    """

    result = renix.edit_dhcp_client_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcp_port_statistic(Port=None, StaItems=None):
    """
    获取Dhcp Port Statistic统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            CurrentAttempt

            CurrentBound

            TotalAttempt

            TotalBound

            TotalFailed

            TotalReboot

            TotalRenew

            TotalRebind

            TotalRetry

            TxDiscover

            RxOffer

            TxRequest

            RxAck

            RxNak

            TxRenew

            TxRebind

            TxReboot

            TxRelease

            RxForceRenew

    Returns:

        dict: eg::

            {
                'CurrentAttempt': 10,
                'CurrentBound': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | CurrentAttempt | CurrentBound |
            | Subscribe Result | Types=Dhcpv4PortStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcp Port Statistic | Port=${Port} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcp_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcp_client_statistic(Session=None, Id=1, StaItems=None):
    """
    获取Dhcp Client Statistic统计结果

    Args:

        Session (:obj:`DhcpClient`): Dhcp客户端会话对象, 类型为：Object

        Id (int): Dhcp客户端会话Index, 默认值: 1

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            ClientState

            IpAddress

            LeaseTime

            LeaseLeft

            ErrorStatus

            DiscoverResponseTime

            RequestResponseTime

    Returns:

        dict: eg::

            {
                'LeaseTime': 10,
                'DiscoverResponseTime': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | LeaseTime | DiscoverResponseTime |
            | Subscribe Result | Types=Dhcpv4ClientStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcp Client Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcp_client_statistic(Session=Session, Id=Id, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcp_client_block_statistic(Session=None, StaItems=None):
    """
    获取Dhcp Client Block Statistic统计结果

    Args:

        Session (:obj:`DhcpClient`): Dhcp客户端会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            BlockState

            AttemptRate

            SetupRate

            CurrentAttempt

            CurrentBound

            TotalAttempt

            TotalBound

            TotalFailed

            TotalReboot

            TotalRenew

            TotalRebind

            TotalRetry

            TxDiscover

            RxOffer

            TxRequest

            RxAck

            RxNak

            TxRenew

            TxRebind

            TxReboot

            TxRelease

            TxDecline

            RxForceRenew

    Returns:

        dict: eg::

            {
                'CurrentAttempt': 10,
                'CurrentBound': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | CurrentAttempt | CurrentBound |
            | Subscribe Result | Types=Dhcpv4ClientBlockStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcp Client Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcp_client_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dhcp_client_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待DHCP协议会话达到指定状态

    Args:

        Sessions (list): DHCP协议会话对象列表

        State (list): 等待DHCP协议会话达到的状态，默认值：BOUND，支持下列状态：

            NOT_READY

            IDLE

            BINDING

            BOUND

            RELEASING

            RENEWING

            REBINDING

            REBOOTING

        Interval (number): 查询DHCP协议会话的间隔，默认值：1 sec

        TimeOut (number): 等待DHCP协议会话状态的超时时间，默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dhcp Client State | Sessions=${Sessions} | State=${State} | Interval=${Interval} | TimeOut=${TimeOut} |
    """

    result = renix.wait_dhcp_client_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcp_server(Port, **kwargs):
    """
    创建DHCP Server会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象

    Keyword Args:

        Name (str): DHCP Server协议会话名称

        LeaseTime (number): 租约时间（秒）, 默认值：600, 范围：1-4294967295

        RenewTime (number): T1租约更新时间(%), 默认值：50, 范围：0-200

        RebindTime (number): T2租约更新时间(%), 默认值：87.5, 范围：0-200

        MinLeaseTime (number): 最小允许租约时间(秒), 默认值：10, 范围：1-4294967295

        DeclineReserveTime (number): 资源释放等待时间(秒), 默认值：10, 范围：1-600

        OfferReserveTime (number): 租约申请超时(秒), 默认值：10, 范围：1-600

        ServerHostName (str): 服务端名字, 默认值：""

        DuplicateAddressDetection (bool): 重复地址检测（DAD）, 默认值：False

        DuplicateAddressDetectionTimeout (number): DAD超时时间, 默认值：0.5, 范围：0-60

    Returns:

        (:obj:`DhcpServer`): DHCP Server会话对象Object

    Examples:
        .. code:: RobotFramework

            | Create Dhcp Server | Port=${Port} | RenewTime=100 |
    """

    result = renix.create_dhcp_server(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dhcp_server(Session, **kwargs):
    """
    编写DHCP Server会话对象参数

    Args:

        Session (:obj:`DhcpServer`): DHCPv4 Client协议对象

    Keyword Args:

        Name (str): DHCP Server协议会话名称

        LeaseTime (number): 租约时间（秒）, 默认值：600, 范围：1-4294967295

        RenewTime (number): T1租约更新时间(%), 默认值：50, 范围：0-200

        RebindTime (number): T2租约更新时间(%), 默认值：87.5, 范围：0-200

        MinLeaseTime (number): 最小允许租约时间(秒), 默认值：10, 范围：1-4294967295

        DeclineReserveTime (number): 资源释放等待时间(秒), 默认值：10, 范围：1-600

        OfferReserveTime (number): 租约申请超时(秒), 默认值：10, 范围：1-600

        ServerHostName (str): 服务端名字

        DuplicateAddressDetection (bool): 重复地址检测（DAD）, 默认值：False

        DuplicateAddressDetectionTimeout (number): DAD超时时间, 默认值：0.5, 范围：0-60

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Dhcp Server | Session=${Session} | LeaseTime=1000 |
    """

    result = renix.edit_dhcp_server(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcp_server_custom_option(Session, Upper, **kwargs):
    """
    创建测试仪表DHCP协议会话option对象

    Args:

        Session (:obj:`DhcpClient`): DHCPv4 Client协议对象/DHCP地址池对象, 类型为：object / list

        Upper (:obj:`DhcpClient` or `Dhcpv4AddressPool`): DHCPv4 Client协议对象/DHCP地址池对象, 类型为：object / list

    Keyword Args:

        OptionTag (number): 可选项类型标识, 默认值：0, 取值范围：0-255

        OptionType (str): 可选项数据类型, 默认值：HEX, 支持以下参数：

            HEX

            STRING

            BOOLEAN

            INT8

            INT16

            INT32

            IP

        EnableOptionValueList (bool): 可选项值列表, 默认值：False

        OptionValue (str): 可选项值, 默认值：""

        MessageType (list): 携带Option消息类型, 默认值：['OFFER', 'ACK'], 支持以下参数：

            OFFER

            ACK

            NAK

    Returns:

        (:obj:`Dhcpv4ClientOption`): 测试仪表DHCP协议会话option对象Object

    Examples:
        .. code:: RobotFramework

            | Create Dhcp Server Custom Option | Session=${Sessions} |
    """

    result = renix.create_dhcp_server_custom_option(Session=Session, Upper=Upper, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcp_server_address_pool(Sessions, **kwargs):
    """
    创建DHCP Server会话对象地址池

    Args:

        Sessions (:obj:`DhcpServer`): DHCPv4 Client协议对象, 类型为：object / list

    Keyword Args:

        Name (str): DHCP Server协议会话名称

        PoolAddressStart (str): 开始地址, 取值范围：IPv4地址, 默认值：1.1.1.2

        PoolAddressStep (str): 地址步长, 取值范围：IPv4地址, 默认值：0.0.0.1

        PrefixLength (number): 前缀长度, 默认值：24, 范围：0-32

        RouterList (list): 网关列表, 默认值："", 范围：列表元素为有效的ipv4地址

        LimitPoolCount (bool): 限制地址池个数, 默认值：True

        PoolAddressCount (number): 地址池地址个数, 默认值：255, 范围：0-4294967295

        DomainName (str): 域名, 默认值：""

        DnsList (list): DNS地址列表, 默认值："", 范围：列表元素为有效的ipv4地址

    Returns:

        (:obj:`Dhcpv4AddressPool`): DHCP地址池对象列表list

    Examples:
        .. code:: RobotFramework

            | Create Dhcp Server Address Pool | Sessions=${Sessions} | PoolAddressStart=2.2.2.2 |
    """

    result = renix.create_dhcp_server_address_pool(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dhcp_server_port_config(Ports, **kwargs):
    """
    修改DHCP服务器端口配置

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object / list

    Keyword Args:

        RenewRate (int): 强制单播续租速度, 默认值: 100, 范围: 1-65535

        MaxOutstanding: 最大请求个数, 默认值: 1000, 范围: 1-65535

    Returns:

        (:obj:`Dhcpv4ServerPortConfig`): Dhcpv4 Server Port Config对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dhcp Server Port Config | Port=${Port} | RenewRate=1000 |
    """

    result = renix.edit_dhcp_server_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcp_server_statistic(Session=None, StaItems=None):
    """
    获取Dhcp Server Statistic统计结果

    Args:

        Session (:obj:`DhcpServer`): DHCP服务端会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            CurrentBound

            TotalBound

            TotalExpire

            TotalReboot

            TotalRenew

            TotalRebind

            TotalRelease

            RxDiscover

            TxOffer

            RxRequest

            TxAck

            TxNak

            RxDecline

            RxRelease

            TxForceRenew

    Returns:

        dict: eg::

            {
                'CurrentBound': 10,
                'TotalBound': 20,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | CurrentBound | TotalBound |
            | Subscribe Result | Types=Dhcpv4ServerStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcp Server Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcp_server_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcp_server_lease_statistic(Session=None, ClientId=None, StaItems=None):
    """
    获取Dhcp Server Lease Statistic统计结果

    Args:

        Session (:obj:`DhcpServer`): DHCP服务端会话对象, 类型为：object

        ClientId (str): DHCP Client Mac Address

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            ClientIp

            LeaseTime

            LeaseLeft

    Returns:

        dict: eg::

            {
                'LeaseTime': 100,
                'LeaseLeft': 50,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | LeaseTime | LeaseLeft |
            | Subscribe Result | Types=Dhcpv4LeaseStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcp Server Lease Statistic | Session=${Session} | ClientId=00:00:12:01:01:03 | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcp_server_lease_statistic(Session=Session, ClientId=ClientId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dhcp_server_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待DHCP服务器协议会话达到指定状态

    Args:

        Sessions (list): DHCP Server协议会话对象列表

        State (list): 等待DHCP Server协议会话达到的状态，默认值：UP，支持下列状态：

            NOT_READY

            DOWN

            UP

        Interval (number): 查询DHCP协议会话的间隔，默认值：1 sec

        TimeOut (number): 等待DHCP协议会话状态的超时时间，默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dhcp Server State | Sessions=${Sessions} | State=${State} | Interval=${Interval} | TimeOut=${TimeOut} |
    """

    result = renix.wait_dhcp_server_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def dhcp_force_renew(Sessions):
    """
    DHCP服务端强制单播续租

    Args:

        Sessions (:obj:`DhcpServer`): DHCPv4 Server协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Force Renew | Sessions=${Sessions} |
    """

    result = renix.dhcp_force_renew(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def dhcp_abort_server(Sessions):
    """
    DHCP服务端中断

    Args:

        Sessions (:obj:`DhcpServer`): DHCPv4 Server协议对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcp Abort Server | Sessions=${Sessions} |
    """

    result = renix.dhcp_abort_server(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

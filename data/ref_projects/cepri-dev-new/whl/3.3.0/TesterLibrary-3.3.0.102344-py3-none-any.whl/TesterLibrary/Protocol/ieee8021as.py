import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_ieee8021as(Port, **kwargs):
    """
    创建Ieee802.1as会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): Ieee802.1as会话名称, 类型为：string

        Enable (bool): 使能Ieee802.1as会话, 类型为：bool, 取值范围：True或False, 默认值：True

        MaxPduSize (int): 最大PDU范围，默认值：1500, 取值范围：uint32 in [60,2047]

        TransmitType (str): 发送方式，默认值：SINGLE, 取值范围：

            SINGLE

            BATCH

        LoopBackRespTime (int): Loopback响应时间，默认值：1, 取值范围：uint32 in [1,10]

        EnableLinkFault (bool): 使能Link Fault, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableDyingGasp (bool): 使能Dying Gasp, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableCriticalEvent (bool): 使能Critical Event, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableLoopBackResp (bool): 使能Loopback Response, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableVarResp (bool): 使能Variable Response, 类型为：bool, 取值范围：True或False, 默认值：True

        VarReqPeriod (int): Variable Request周期，默认值：1, 取值范围：uint8 in [0,10]

    Returns:

        (:obj:`Ieee801as`): Ieee802.1as会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Ieee801as | Port=${Port} | MaxPduSize=1300 |

    """

    result = renix.create_ieee8021as(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ieee8021as(Session, **kwargs):
    """
    修改Ieee802.1as会话对象

    Args:

        Session (:obj:`Ieee802.1as`): 802.1as会话对象, 类型为：object / list

    Keyword Args:

        Name (str): Ieee802.1as会话名称, 类型为：string

        Enable (bool): 使能Ieee802.1as会话, 类型为：bool, 取值范围：True或False, 默认值：True

        MaxPduSize (int): 最大PDU范围，默认值：1500, 取值范围：uint32 in [60,2047]

        TransmitType (str): 发送方式，默认值：SINGLE, 取值范围：

            SINGLE

            BATCH

        LoopBackRespTime (int): Loopback响应时间，默认值：1, 取值范围：uint32 in [1,10]

        EnableLinkFault (bool): 使能Link Fault, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableDyingGasp (bool): 使能Dying Gasp, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableCriticalEvent (bool): 使能Critical Event, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableLoopBackResp (bool): 使能Loopback Response, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableVarResp (bool): 使能Variable Response, 类型为：bool, 取值范围：True或False, 默认值：True

        VarReqPeriod (int): Variable Request周期，默认值：1, 取值范围：uint8 in [0,10]

    Returns:

        (:obj:`Ieee801as`): Ieee802.1as会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Ieee801as | Port=${Port} | MaxPduSize=1300 |

    """

    result = renix.edit_ieee8021as(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ieee8021as_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待802.1as会话达到指定状态

    Args:

        Session (:obj:`Ieee802.1as`): 802.1as会话对象, 类型为：object / list

        State (list): 等待802.1as会话组达到的状态, 类型为：string, 默认值：达到COMPLETED, 支持下列状态：

            RUNNING

            DISABLED

            IDLE

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ieee8021as State | Sessions=${Sessions} | State=RUNNING | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ieee8021as_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ieee8021as_clock_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待802.1as会话达到指定状态

    Args:

        Session (:obj:`Ieee802.1as`): 802.1as会话对象, 类型为：object / list

        State (list): 等待802.1as会话组达到的状态, 类型为：string, 默认值：达到COMPLETED, 支持下列状态：

            MASTER

            SLAVE

            DISABLED

            IDLE

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ieee8021as Clock State | Sessions=${Sessions} | State=MASTER | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ieee8021as_clock_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ieee8021as_clock_statistic(Session=None, StaItems: list = None):
    """
    获取Ieee802.1as session 统计结果

    Args:

        Session (:obj:`Ieee802.1as`): Ieee802.1as会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            LocalMultiplexerAction

    Returns:

        dict: eg::

            {
                'TxOrgSpecPduCounter': 10,
                'RxOrgSpecPduCounter': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ieee802.1asSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ieee802.1as Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ieee8021as_clock_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ieee8021as_clock_sync_statistic(Session=None, StaItems: list = None):
    """
    获取Ieee802.1as session 统计结果

    Args:

        Session (:obj:`Ieee802.1as`): Ieee802.1as会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            LocalMultiplexerAction

    Returns:

        dict: eg::

            {
                'TxOrgSpecPduCounter': 10,
                'RxOrgSpecPduCounter': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ieee802.1asSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ieee802.1as Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ieee8021as_clock_sync_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ieee8021as_message_rate_statistic(Session=None, StaItems: list = None):
    """
    获取Ieee802.1as session 统计结果

    Args:

        Session (:obj:`Ieee802.1as`): Ieee802.1as会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            LocalMultiplexerAction

    Returns:

        dict: eg::

            {
                'TxOrgSpecPduCounter': 10,
                'RxOrgSpecPduCounter': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ieee802.1asSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ieee802.1as Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ieee8021as_message_rate_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ieee8021as_parent_clock_info_statistic(Session=None, StaItems: list = None):
    """
    获取Ieee802.1as session 统计结果

    Args:

        Session (:obj:`Ieee802.1as`): Ieee802.1as会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            LocalMultiplexerAction

    Returns:

        dict: eg::

            {
                'TxOrgSpecPduCounter': 10,
                'RxOrgSpecPduCounter': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ieee802.1asSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ieee802.1as Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ieee8021as_parent_clock_info_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ieee8021as_state_summary_statistic(Port=None, StaItems: list = None):
    """
    获取Ieee802.1as session 统计结果

    Args:

        Port (:obj:`Port`): 仪表端口对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            LocalMultiplexerAction

    Returns:

        dict: eg::

            {
                'TxOrgSpecPduCounter': 10,
                'RxOrgSpecPduCounter': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ieee802.1asSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ieee802.1as Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ieee8021as_state_summary_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ieee8021as_time_properties_statistic(Session=None, StaItems: list = None):
    """
    获取Ieee802.1as session 统计结果

    Args:

        Session (:obj:`Ieee802.1as`): Ieee802.1as会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            LocalMultiplexerAction

    Returns:

        dict: eg::

            {
                'TxOrgSpecPduCounter': 10,
                'RxOrgSpecPduCounter': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ieee802.1asSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ieee802.1as Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ieee8021as_time_properties_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

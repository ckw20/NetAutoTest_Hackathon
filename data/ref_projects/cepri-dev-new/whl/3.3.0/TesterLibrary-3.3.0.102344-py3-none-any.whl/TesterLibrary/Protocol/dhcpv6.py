import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------client-------------------------------------
def create_dhcpv6_client(Port, **kwargs):
    """
    创建DHCPv6客户端会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): DHCPv6客户端会话名称, 类型为：string

        Enable (bool): 使能DHCPv6客户端会话, 类型为：bool, 取值范围：True或False, 默认值：True

        EmulationMode (str): 会话模式, 默认值：DHCPV6, 取值范围：

            DHCPV6

            DHCPV6PD

            DHCPV6ANDPD

        EnableRenewMsg (bool): 使能Renew消息, 默认值：True, 取值范围：True或False

        EnableRebindMsg (bool): 使能Rebind消息, 默认值：True, 取值范围：True或False

        EnableReconfigAccept (bool): 使能Reconfigure消息, 默认值：True, 取值范围：True或False

        EnableSyncAddressInterface (bool): 默认值：True, 取值范围：True或False

        T1Timer (int): T1时刻（秒）, 取值范围：0-2147483647, 默认值：302400

        T2Timer (int): T2时刻（秒）, 取值范围：0-2147483647, 默认值：483840

        PreferredLifetime (int): 首选生命周期（秒）, 取值范围：0-2147483647, 默认值：604800

        ValidLifetime (int): 有效生命周期（秒）, 取值范围：0-2147483647, 默认值：2592000

        RapidCommitOptMode (str): 快速交互模式, 默认值：DISABLE, 取值范围：

            DISABLE

            ENABLE

            SERVERSET

        DuidType (str): DUID类型, 默认值：LL, 取值范围：

            LLT

            EN

            LL

            CUSTOM

        DuidCustomValue (int): 自定义DUID编号, 取值范围：0-65535, 默认值：1

        DuidEnterpriseNumber (int): DUID企业编号, 取值范围：0-4294967295, 默认值：3456

        DuidStartValue (str): DUID企业编号, 默认值：3456, 取值范围：匹配正则表达式"^([0-9a-fA-F]{1,256})$"

        DuidStepValue (int): DUID标识符跳变, 取值范围：0-4294967295, 默认值：0x1

        DestinationAddress (str): 目的地址, 默认值：ALL, 取值范围：

            ALL

            SERVER

        EnableRelayAgent (bool): 使能中继代理, 默认值：False, 取值范围：True或False

        RelayAgentIp (str): 中继代理IP, 默认值：2000::1, 取值范围：有效的ipv6地址

        ServerIp (str): 服务IP, 默认值：2001::2, 取值范围：有效的ipv6地址

        EnableUseRelayAgentMacForTraffic (bool): 默认值：True

        RequestPrefixLength (int): 请求前缀长度, 取值范围：0-128, 默认值：64

        RequestPrefixStartAddress (str): 请求前缀地址, 默认值：'::', 取值范围：有效的ipv6地址

        ControlPlaneSrcIPv6Addr (str): 默认值：LINKLOCAL, 取值范围：

            LINKLOCAL

            ROUTEADVERTISEMENT

        RequestStartAddress (str): 请求前缀地址, 默认值：'::', 取值范围：有效的ipv6地址

        EnableAuthentication (bool): 使能认证, 默认值：False, 取值范围：True或False

        AuthenticationProtocol (str): 认证协议, 默认值：DELAYED, 取值范围：

            DELAYED

            RECONFIGURATION

        DhcpRealm (str): 认证域名称, 默认值：'xinertel.com'

        AuthenticationKeyId (int): 取值范围：0-4294967295, 默认值：0

        AuthenticationKey (str): 认证秘钥ID, 默认值：''

        AuthenticationKeyType (str): 认证秘钥类型, 默认值：ASCII, 取值范围：

            ASCII

            HEX

        EnableDad (bool): 使能重复地址检测（DAD）, 默认值：False, 取值范围：True或False

        DadTimeout (int): DAD超时时间（秒）, 取值范围：1-4294967295, 默认值：2

        DadTransmits (int): DAD传输次数, 取值范围：1-4294967295, 默认值：1

        HostInterface (:obj:`Interface`): 接口对象, 类型：object
        
    Returns:

        (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Dhcpv6 Client | Port=${Port} | DadTransmits=10 |
    """

    result = renix.create_dhcpv6_client(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcpv6_client_custom_options(Sessions, **kwargs):
    """
    创建DHCPv6 Client Custom Options对象

    Args：

        Session (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Keyword Args:

        OptionVal (int): 选项标识, 取值范围：0-255, 默认值：0

        IncludeMsg (list): 包含选项的消息类型, 默认值：['SOLICIT', 'REQUEST'], 取值范围：

            SOLICIT

            REQUEST

            CONFIRM

            RENEW

            REBIND

            RELEASE

            INFOREQUEST

            RELAYFORWARD

        Wildcards (bool): 使能通配符, 默认值：False, 取值范围：True或False

        StringIsHexadecimal (bool): 使能十六进制字符, 默认值：False, 取值范围：True或False

        OptionPayload (str): 选项载荷, 默认值：'', 取值范围：string length in [0,512]

        OptionHexPayload (int): 十六进制选项载荷, 默认值：""

        RemoveOption (bool): 默认值：False, 取值范围：True或False

    Returns:

        (:obj:`Dhcpv6ClientCustomOptionsConfig`): DHCPv6 Client Custom Options对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Dhcpv6} | Create Dhcpv6 Client | Port=${Port} |
            | Create Dhcpv6 Client Custom Options | Sessions=${Dhcpv6} | Wildcards=True |
    """

    result = renix.dhcpv6_client_custom_options(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_bind(Sessions):
    """
    DHCPv6客户端绑定地址

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Bind | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_bind(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_release(Sessions):
    """
    DHCPv6客户端释放地址

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Release | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_release(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_renew(Sessions):
    """
    DHCPv6客户端单播续租地址

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Renew | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_renew(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_rebind(Sessions):
    """
    DHCPv6客户端广播续租地址

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Rebind | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_rebind(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_confirm(Sessions):
    """
    DHCPv6客户端确认参数

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Confirm | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_confirm(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_abort(Sessions):
    """
    中断DHCPv6/PD客户端

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Abort | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_abort(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_info_request(Sessions):
    """
    DHCPv6客户端请求信息

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Info Request | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_info_request(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_lease_query(Sessions, **kwargs):
    """
    DHCPv6客户端租借查询

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Keyword Args:

        QueryType (str): Leasequery消息中query-type类型, 默认值：QUERY_BY_ADDRESS, 取值范围：

            QUERY_BY_ADDRESS

            QUERY_BY_CLIENTID

        ClientAddress (str): 客户端IPv6地址, 默认值：'2000::1', 取值范围：有效的ipv6地址

        ClientId (str): 客户端ID, 默认值：'', 取值范围：匹配正则表达式"^([0-9a-fA-F]{0,512})$"

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Lease Query | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_lease_query(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_bulk_lease_query(Sessions, **kwargs):
    """
    DHCPv6客户端批量租借查询

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Keyword Args:

        QueryType (str): Bulk Leasequery消息中query-type类型, 默认值：QUERY_BY_ADDRESS, 取值范围：

            QUERY_BY_ADDRESS

            QUERY_BY_CLIENTID

            QUERY_BY_RELAY_ID

            QUERY_BY_LINK_ADDRESS

            QUERY_BY_REMOTE_ID

        ClientAddress (str): 指定客户端IPv6地址, 默认值：'2000::1', 取值范围：有效的ipv6地址

        ClientId (str): 客户端ID, 默认值：'', 取值范围：匹配正则表达式"^([0-9a-fA-F]{0,512})$"

        RelayIdentifier (str): 中继器ID, 默认值：'', 取值范围：匹配正则表达式"^([0-9a-fA-F]{0,512})$"

        LinkAddress (str): 链路地址, 默认值：'2000::1', 取值范围：有效的ipv6地址

        RemoteId (str): 中继代理Remote-ID值, 默认值：''

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Bulk Lease Query | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_bulk_lease_query(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_active_lease_query(Sessions):
    """
    DHCPv6客户端活动租借查询

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Active Lease Query | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_active_lease_query(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_client_start_tls(Sessions):
    """
    DHCPv6客户端启动TLS

    Args:

        Sessions (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Client Start Tls | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_client_start_tls(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dhcpv6_client_port_config(Ports, **kwargs):
    """
    修改DHCPv6端口配置对象

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        RequestRate (int): Request速率（会话/秒）, 取值范围：1-10000, 默认值：100

        ReleaseRate (int): Release速率（会话/秒）, 取值范围：1-10000, 默认值：100

        RenewRate (int): Renew速率（会话/秒）, 取值范围：1-10000, 默认值：100

        MaxOutstanding (int): 最大会话数量, 取值范围：1-2048, 默认值：1000

        SolicitInitialTimeout (int): Solicit消息初始超时时间（秒）, 取值范围：1-99999, 默认值：5

        SolicitMaxTimeout (int): Solicit消息最大超时时间（秒）, 取值范围：1-99999, 默认值：120

        SolicitRetryCount (int): Solicit消息重发次数, 取值范围：0-32, 默认值：10

        SolicitIndefiniteRetry (bool): Solicit消息无限次重发, 默认值：False, 取值范围：True或False

        SolicitDisableRetries (bool): Solicit消息无限次重发, 默认值：False, 取值范围：True或False

        RequestInitialTimeout (int): Request消息初始超时时间（秒）, 取值范围：1-99999, 默认值：2

        RequestMaxTimeout (int): Request消息最大超时时间（秒）, 取值范围：1-99999, 默认值：30

        RequestRetryCount (int): Request消息重发次数, 取值范围：0-32, 默认值：10

        RequestIndefiniteRetry (bool): Request消息无限次重发, 默认值：False, 取值范围：True或False

        RequestDisableRetries (bool): Request消息禁止重发, 默认值：False, 取值范围：True或False

        ConfirmInitialTimeout (int): Confirm消息初始超时时间（秒）, 取值范围：1-99999, 默认值：2

        ConfirmMaxTimeout (int): Confirm消息最大超时时间（秒）, 取值范围：1-99999, 默认值：4

        ConfirmMaxDuration (int): Confirm消息最大重发次数, 取值范围：0-32, 默认值：5

        RenewInitialTimeout (int): Renew消息初始超时时间（秒）, 取值范围：0-32, 默认值：10

        RenewMaxTimeout (int): Renew消息最大超时时间（秒）, 取值范围：1-99999, 默认值：600

        RenewRetryCount (int): Renew消息重发次数, 取值范围：0-32, 默认值：5

        RenewIndefiniteRetry (bool): Renew消息无限次重发, 默认值：False, 取值范围：True或False

        RenewDisableRetries (bool): Renew消息禁止重发, 默认值：False, 取值范围：True或False

        RebindInitialTimeout (int): Rebind消息初始超时时间（秒）, 取值范围：1-99999, 默认值：10

        RebindMaxTimeout (int): Rebind消息最大超时时间（秒）, 取值范围：1-99999, 默认值：600

        RebindRetryCount (int): Rebind消息重发次数, 取值范围：0-32, 默认值：5

        RebindIndefiniteRetry (bool): Rebind消息无限次重发, 默认值：False, 取值范围：True或False

        RebindDisableRetries (bool): Rebind消息禁止重发, 默认值：False, 取值范围：True或False

        ReleaseInitialTimeout (int): Release消息初始超时时间（秒）, 取值范围：1-99999, 默认值：1

        ReleaseRetryCount (int): Release消息重发次数, 取值范围：0-32, 默认值：3

        ReleaseIndefiniteRetry (bool): Release消息无限次重发, 默认值：False, 取值范围：True或False

        ReleaseDisableRetries (bool): Release消息禁止重发, 默认值：False, 取值范围：True或False

        DeclineInitialTimeout (int): Decline消息初始超时时间（秒）, 取值范围：1-99999, 默认值：1

        DeclineRetryCount (int): Decline消息重发次数, 取值范围：0-32, 默认值：5

        DeclineIndefiniteRetry (bool): Decline消息无限次重发, 默认值：False, 取值范围：True或False

        DeclineDisableRetries (bool): Decline消息禁止重发, 默认值：False, 取值范围：True或False

        InfoRequestInitialTimeout (int): Information-Request消息初始超时时间（秒）, 取值范围：1-99999, 默认值：1

        InfoRequestMaxTimeout (int): Information-Request消息最大超时时间（秒）, 取值范围：1-99999, 默认值：120

        InfoRequestRetryCount (int): Information-Request消息重发次数, 取值范围：0-32, 默认值：5

        InfoRequestIndefiniteRetry (bool): Information-Request消息无限次重发, 默认值：False, 取值范围：True或False

        InfoRequestDisableRetries (bool): Information-Request消息禁止重发, 默认值：False, 取值范围：True或False

        TcpServerPort (int): TCP服务端口号, 取值范围：1-65535, 默认值：547

    Returns:

        (:obj:`Dhcpv6PortRateConfig`): DHCPv6 Client Custom Options对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dhcpv6 Client Port Config | Ports=${Port} | TcpServerPort=10 |
    """

    result = renix.edit_dhcpv6_client_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dhcpv6_client_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待Dhcpv6客户端会话达到指定状态

    Args:

        Session (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

        State (list): 等待DHCPv6客户端会话组达到的状态, 类型为：string, 默认值：达到BOUND, 支持下列状态：

            DISABLED

            IDLE

            BOUND

            SOLICITING

            REQUESTING

            RELEASING

            RENEWING

            REBINDING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dhcpv6 Client State | Sessions=${Sessions} | State=BOUND | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_dhcpv6_client_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dhcpv6_pd_client_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待Dhcpv6 PD客户端会话达到指定状态

    Args:

        Session (:obj:`Dhcpv6Client`): DHCPv6客户端会话对象, 类型为：object / list

        State (list): 等待DHCPv6客户端会话组达到的状态, 类型为：string, 默认值：达到BOUND, 支持下列状态：

            DISABLED

            IDLE

            BOUND

            SOLICITING

            REQUESTING

            RELEASING

            RENEWING

            REBINDING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dhcpv6 Pd Client State | Sessions=${Sessions} | State=BOUND | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_dhcpv6_pd_client_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcpv6_port_statistic(Port=None, StaItems: list = None):
    """
    获取Dhcpv6 Port Statistic统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            CurrentlyAttempting

            CurrentlyIdl

            CurrentlyBound

            AverageSetupTime

            MaxSetupTime

            MinSetupTime

            SolicitTxCount

            RequestTxCount

            ReleaseTxCount

            RenewTxCount

            RebindTxCount

            ConfirmTxCount

            InfoRequestTxCount

            AdvertiseRxCount

            ReconfigureRxCount

            ReplyRxCount

            SuccessPercentage

            TotalAttempted

            TotalBound

            TotalBoundFailed

            TotalRebound

            TotalReleased

            TotalReleaseRetried

            TotalRenewed

            TotalRenewedRetried

            TotalRetired

    Returns:

        dict: eg::

            {
                'TotalRenewedRetried': 10,
                'TotalRetired': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dhcpv6PortStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcpv6 Port Statistic | Port=${Port} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcpv6_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcpv6_client_statistic(Session=None, Id=None, StaItems: list = None):
    """
    获取Dhcpv6 Client Statistic统计结果

    Args:

        Session (:obj:`Dhcpv6Client`): Dhcpv6客户端会话对象, 类型为：Object

        Id (int): Dhcpv6客户端会话Index

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            IaidValue

            MacAddr

            LeaseRx

            AddressType

            SessionState

            StateCode

            IpAddress

            LeaseRemaining

            PrefixLength

            RequestResponseTime

            SolicitResponseTime

    Returns:

        dict: eg::

            {
                'RequestResponseTime': 10,
                'SolicitResponseTime': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dhcpv6ClientStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcpv6 Client Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcpv6_client_statistic(Session=Session, Id=Id, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcpv6_client_block_statistic(Session=None, StaItems: list = None):
    """
    获取Dhcpv6 Client Block Statistic统计结果

    Args:

        Session (:obj:`Dhcpv6Client`): Dhcpv6客户端会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            BlockSessionState

            CurrentlyAttempting

            CurrentlyIdl

            CurrentlyBound

            AttemptRate

            BindRate

            RebindRate

            ReleaseRate

            RenewRate

            AverageRebindToReplyTime

            AverageReleaseToReplyTime

            AverageRenewToReplyTime

            AverageRequestToReplyTime

            AverageSolicitToAdvertiseTime

            AverageSolicitToReplyTime

            MaxRebindToReplyTime

            MaxReleaseToReplyTime

            MaxRenewToReplyTime

            MaxRequestToReplyTime

            MaxSolicitToAdvertiseTime

            MaxSolicitToReplyTime

            MinRebindToReplyTime

            MinReleaseToReplyTime

            MinRenewToReplyTime

            MinRequestToReplyTime

            MinSolicitToAdvertiseTime

            MinSolicitToReplyTime

            AdvertiseRxCount

            ReplyRxCount

            ReconfigureRxCount

            SolicitTxCount

            RequestTxCount

            ReleaseTxCount

            RenewTxCount

            RebindTxCount

            ConfirmTxCount

            InfoRequestTxCount

            TotalAttempted

            TotalBound

            TotalFailed

            TotalRebound

            TotalReleased

            TotalReleaseRetried

            TotalRenewed

            TotalRenewedRetried

            TotalRetired

    Returns:

        dict: eg::

            {
                'TotalRenewedRetried': 10,
                'TotalRetired': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dhcpv6ClientBlockStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcpv6 Client Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcpv6_client_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcpv6_pd_client_statistic(Session=None, Id=None, StaItems: list = None):
    """
    获取Dhcpv6 pd Client Statistic统计结果

    Args:

        Session (:obj:`Dhcpv6Client`): Dhcpv6客户端会话对象, 类型为：Object

        Id (int): Dhcpv6客户端会话Index

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            Dhcpv6PdClientId

            IaidValue

            SessionIndex

            MacAddr

            VlanId

            LeaseRx

            AddressType

            SessionState

            StateCode

            IpAddress

            LeaseRemaining

            PrefixLength

            RequestResponseTime

            SolicitResponseTime


    Returns:

        dict: eg::

            {
                'RequestResponseTime': 10,
                'SolicitResponseTime': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dhcpv6ClientStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcpv6 Client Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcpv6_pd_client_statistic(Session=Session, Id=Id, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


# -------------------------server-------------------------------------


def create_dhcpv6_server(Port, **kwargs):
    """
    创建DHCPv6服务端会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): DHCPv6服务端会话名称, 类型为：string

        Enable (bool): 使能DHCPv6服务端会话, 类型为：bool, 取值范围：True或False, 默认值：True

        EmulationMode (str): 默认值：DHCPV6, 取值范围：

            DHCPV6

            DHCPV6PD

        RenewalTimer (int): T1租约更新时间（%）, 取值范围：1-200, 默认值：50

        RebindingTimer (int): T2租约更新时间（%）, 取值范围：1-200, 默认值：80

        DnsList (str): DNS地址列表, 取值范围：IPv6地址, 默认值："::"

        EnableDelayedAuth (bool): 使能延时认证, 取值范围：True或False, 默认值：False

        DhcpRealm (str): DHCP认证域名, 默认值："xinertel.com"

        AuthenticationKeyId (int): 认证秘钥ID, 取值范围：0-4294967295, 默认值：0

        AuthenticationKey (str): 认证秘钥, 默认值：""

        AuthenticationKeyType (str): 认证秘钥类型, 默认值：ASCII, 取值范围：

            ASCII

            HEX

        EnabledReconfigureKey (bool): 使能重新配置认证, 取值范围：True或False, 默认值：False

        ReconfigureKey (str): 重新配置秘钥类型, 默认值：""

        ReconfigureKeyType (str): 重新配置秘钥类型, 默认值：ASCII, 取值范围：

            ASCII

            HEX

        EnabledDhcpv6Only (bool): 使能单独DHCPv6, 取值范围：True或False, 默认值：False

        EnabledTcp (bool): 使能TCP, 取值范围：True或False, 默认值：False

        TcpPort (int): TCP端口号, 取值范围：1-65535, 默认值：547

        LeaseQueryStatusCode (str): 租借查询应答码, 默认值：SUCCESS, 取值范围：

            SUCCESS

            UNKNOWN_QUERY_TYPE

            MALFORMED_QUERY

            NOT_CONFIGURED

            NOT_ALLOWED

        BulkLeaseQueryStatusCode (str): 批量租借查询应答码, 默认值：SUCCESS, 取值范围：

            SUCCESS

            UNKNOWN_QUERY_TYPE

            MALFORMED_QUERY

            NOT_CONFIGURED

            NOT_ALLOWED

            QUERY_TERMINATED

        ActiveLeaseQueryStatusCode (str): 活动租借查询应答码, 默认值：SUCCESS, 取值范围：

            SUCCESS

            UNKNOWN_QUERY_TYPE

            MALFORMED_QUERY

            NOT_CONFIGURED

            NOT_ALLOWED

            QUERY_TERMINATED

            DATA_MISSING

            CATCH_UP_COMPLETE

            NOT_SUPPORTED

        StartTlsStatusCode (str): 启动TLS应答码, 默认值：SUCCESS, 取值范围：

            SUCCESS

            TLS_CONNECTION_REFUSED

    Returns:

        (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Dhcpv6 Server | Port=${Port} | DadTransmits=10 |
    """

    result = renix.create_dhcpv6_server(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcpv6_server_custom_options(Sessions, **kwargs):
    """
    创建DHCPv6 Server Custom Options对象

    Args：

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Keyword Args:

        OptionVal (int): 选项标识, 取值范围：0-255, 默认值：0

        IncludeMsg (list): 包含选项的消息类型, 默认值：['ADVERTISE', 'REPLY'], 取值范围：

            ADVERTISE

            REPLY

            RECONFIGURE

            RELAYREPLY

        Wildcards (bool): 使能通配符, 取值范围：True或False, 默认值：False

        StringIsHexadecimal (bool): 使能十六进制字符串, 取值范围：True或False, 默认值：False

        OptionPayload (str): 选项负载, 默认值：""

        OptionHexPayload (str): 选项负载, 默认值：""

    Returns:

        (:obj:`Dhcpv6ServerCustomOptionsConfig`): DHCPv6 Server Custom Options对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Dhcpv6} | Create Dhcpv6 Server | Port=${Port} |
            | Create Dhcpv6 Server Custom Options | Sessions=${Dhcpv6} | Wildcards=True |
    """

    result = renix.dhcpv6_server_custom_options(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcpv6_server_address_pool(Sessions, **kwargs):
    """
    创建DHCPv6 Server Address Pool对象

    Args：

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Keyword Args:

        PrefixLength (int): 地址池前缀长度, 取值范围：0-128, 默认值：64

        AssignMode (str): 默认值：SUCCESS, 取值范围：

            CUSTOM

            EUI64

        StartAddress (str): 地址池起始地址, 取值范围：IPv6地址, 默认值："2001::1"

        HostStep (str): 地址池地址跳变, 取值范围：IPv6地址, 默认值："::1"

        AddressCount (int): 地址池地址总数, 取值范围：1-4294967295, 默认值：65535

        PreferredLifetime (int): 首选生命周期（秒）, 取值范围：0-4294967295, 默认值：604800

        ValidLifetime (int): 有效生命周期（秒）, 取值范围：0-4294967295, 默认值：2592000

        MinIaidValue (int): 最小IAID值, 取值范围：0-4294967295, 默认值：0

        MaxIaidValue (int): 最大IAID值, 取值范围：0-4294967295, 默认值：4294967295

    Returns:

        (:obj:`Dhcpv6AddressPoolsConfig`): DHCPv6 Server Address Pool对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Dhcpv6} | Create Dhcpv6 Server | Port=${Port} |
            | Create Dhcpv6 Server Address Pool | Sessions=${Dhcpv6} | MinIaidValue=10 |
    """

    result = renix.dhcpv6_server_address_pool(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dhcpv6_server_prefix_pool(Sessions, **kwargs):
    """
    创建DHCPv6 Server Prefix Pool对象

    Args：

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Keyword Args:

        PrefixLength (int): 前缀池前缀长度, 取值范围：0-128, 默认值：64

        PrefixPoolStart (str): 前缀池起始地址, 取值范围：IPv6地址, 默认值："2001::1"

        PrefixPoolStep (str): 前缀池地址跳变, 取值范围：IPv6地址, 默认值："0:0:0:1::"

        PrefixAddressCount (int): 前缀池地址总数, 取值范围：1-65535, 默认值：16

        PreferredLifetime (int): 最优租期（秒）, 取值范围：0-4294967295, 默认值：604800

        ValidLifetime (int): 有效租期（秒）, 取值范围：0-4294967295, 默认值：2592000

        MinIaidValue (int): 最小IAID值, 取值范围：0-4294967295, 默认值：0

        MaxIaidValue (int): 最大IAID值, 取值范围：0-4294967295, 默认值：4294967295

    Returns:

        (:obj:`Dhcpv6PrefixPoolsConfig`): DHCPv6 Server Prefix Pool对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | ${Dhcpv6} | Create Dhcpv6 Server | Port=${Port} |
            | Create Dhcpv6 Server Prefix Pool | Sessions=${Dhcpv6} | MinIaidValue=10 |
    """

    result = renix.dhcpv6_server_prefix_pool(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_server_start(Sessions):
    """
    启动DHCPv6服务端

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Server Start | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_server_start(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_server_stop(Sessions):
    """
    停止DHCPv6服务端

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Server Stop | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_server_stop(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_server_reconfigure_renew(Sessions):
    """
    DHCPv6服务端重新配置Renew

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Server Reconfigure Renew | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_server_reconfigure_renew(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_server_reconfigure_rebind(Sessions):
    """
    DHCPv6服务端重新配置Rebind

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Server Reconfigure Rebind | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_server_reconfigure_rebind(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dhcpv6_server_abort(Sessions):
    """
    中断DHCPv6/PD服务器

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dhcpv6 Server Abort | Sessions=${Sessions} |
    """

    result = renix.dhcpv6_server_abort(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dhcpv6_server_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待Dhcpv6服务端会话达到指定状态

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

        State (list): 等待DHCPv6客户端会话组达到的状态, 类型为：string, 默认值：达到UP, 支持下列状态：

            NOTSTART

            UP

            DISABLED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dhcpv6 Server State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_dhcpv6_server_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcpv6_server_statistic(Session=None, StaItems: list = None):
    """
    获取Dhcpv6 Server Statistic统计结果

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            ServerState

            CurrentlyBound

            ReconfigureRebindTxCount

            ReconfigureRenewTxCount

            ReconfigureTxCount

            AdvertiseTxCount

            ReplyTxCount

            SolicitRxCount

            RequestRxCount

            ReleaseRxCount

            RenewRxCount

            RebindRxCount

            TotalBound

            TotalExpired

            TotalReleased

            TotalRenewed

    Returns:

        dict: eg::

            {
                'TotalReleased': 10,
                'TotalRenewed': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dhcpv6ServerStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcpv6 Server Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcpv6_server_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dhcpv6_server_lease_statistic(Session=None, Pool=None, StaItems: list = None):
    """
    获取Dhcpv6 Server Lease Statistic统计结果

    Args:

        Session (:obj:`Dhcpv6Server`): DHCPv6服务端会话对象, 类型为：object / list

        Pool (:obj:`Dhcpv6AddressPoolsConfig`): DHCPv6 Server Address Pool对象

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            ServerState

            CurrentlyBound

            ReconfigureRebindTxCount

            ReconfigureRenewTxCount

            ReconfigureTxCount

            AdvertiseTxCount

            ReplyTxCount

            SolicitRxCount

            RequestRxCount

            ReleaseRxCount

            RenewRxCount

            RebindRxCount

            TotalBound

            TotalExpired

            TotalReleased

            TotalRenewed

    Returns:

        dict: eg::

            {
                'TotalReleased': 10,
                'TotalRenewed': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dhcpv6ServerStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dhcpv6 Server Lease Statistic | Session=${Session} | Pool=${Pool} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dhcpv6_server_lease_statistic(Session=Session, Pool=Pool, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

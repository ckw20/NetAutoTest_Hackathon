import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------y1731-------------------------------------
def create_y1731(Port, **kwargs):
    """
    创建y1731协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        NextHop (str): 默认值：DUT, 取值范围：

            DUT

            Interface_X: handle of interface object

    Returns:

        (:obj:`Y1731`): y1731协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 | Port=${Port} | DADTransmitCount=255 |
    """

    result = renix.create_y1731(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_y1731_state(Sessions, State='RUNNING', Interval=1, TimeOut=60):
    """
    等待y1731协议会话达到指定状态

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

        State (list): 等待协议会话达到的状态, 默认值：达到RUNNING, 支持下列状态：

            DISABLED

            IDLE

            RUNNING

        Interval (int): 查询协议会话的间隔, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Y1731 State | Sessions=${Sessions} | State=IDLE | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_y1731_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_y1731_port_config(Ports, **kwargs):
    """
    修改y1731端口配置

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        MulticastClass1DaMac (str): 第一类组播mac地址, 默认值：01:80:c2:00:00:30, 取值范围：有效的mac地址

        MulticastClass2DaMac (str): 第一类组播mac地址, 默认值：01:80:c2:00:00:38, 取值范围：有效的mac地址

        EncodeMdOrMeLevel (bool): 是否在组播mac地址中包含MD/ME等级, 默认值：True, 取值范围：

            True

            False

        DisableCCRcv (bool): 是否在该端口上忽略接收CCM消息, 默认值：False, 取值范围：

            True

            False

        TlvsInDmr (bool): 是否在DMR应答消息中包含TLV选项, 默认值：True, 取值范围：

            True

            False

        TlvsInLmr (bool): 是否在LMR应答消息中包含TLV选项, 默认值：True, 取值范围：

            True

            False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Y1731 Port Config | Ports=${Ports} | RequestRate=1000 |
    """

    result = renix.edit_y1731_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_y1731_global_option(**kwargs):
    """
    修改y1731全局配置

    Keyword Args:

        TestModeType (str): Test Mode Options, 默认值：TYPE_NORMAL, 取值范围：

            TYPE_NORMAL

            TYPE_CC_SCALE_MODE

            TYPE_CC_SCALE_MODE_WITHOUT_RX

        LmrRxFCfStart (int): Initial value of the loss Measurement Response received frame count forwarding, 默认值：1, 取值范围：0-4294967295

        LmrRxFCfStep (int): Increment value for the number of frames in subsequent steps in Step mode, 默认值：1, 取值范围：0-4294967295

        LmrTxFCbStart (int): Initial value of the loss Measurement Response sent frame count forwarding, 默认值：1, 取值范围：0-4294967295

        LmrTxFCbStep (int): Increment value for the number of frames in subsequent steps in Step mode, 默认值：1, 取值范围：0-65535

        LmmTxFCfOffset (int): TLV offset for the LMM sent frame count, 默认值：0, 取值范围：0-32767

        LmrRxFCfOffset (int): TLV offset for the LMR received frame count, 默认值：0, 取值范围：0-32767

        LmrTxFCbOffset (int): TLV offset for the LMR sent frame count, 默认值：0, 取值范围：0-32767

        DmTimeUnit (str): Set the unit of measure for delay measurement, 默认值：TIME_MS, 取值范围：

            TIME_MS

            TIME_NS

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Y1731 Global Option | DmTimeUnit=TIME_NS |
    """

    result = renix.edit_y1731_global_option(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_y1731_meg(**kwargs):
    """
    创建Y1731 MEG对象

    Keyword Args:

        OperationMode (str): 模式，默认值：ITU_T, 取值范围：

            ITU_T

            IEEE

        MdOrMeLevel (str): ME级别，默认值：LEVEL1, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        CcPeriod (str): CC周期，默认值：CCM_1S, 取值范围：

            CCM_3MS

            CCM_10MS

            CCM_100MS

            CCM_1S

            CCM_10S

            CCM_1MIN

            CCM_10MIN

        LckPeriod (str): LCK周期，默认值：PERIOD_1S, 取值范围：

            PERIOD_1S

            PERIOD_1MIN

        AisPeriod (str): AIS周期，默认值：PERIOD_1S, 取值范围：

            PERIOD_1S

            PERIOD_1MIN

        CcPriority (str): CC优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        LbPriority (str): LB优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        LtPriority (str): LT优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        AisPriority (str): AIS优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        LckPriority (str): LCK优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        DmPriority (str): DM优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        DmmPriority (str): DMM优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        LmPriority (str): LM优先级，默认值：LEVEL0, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        DomainIdType (str): （IEEE模式下）DomainIDType，默认值：NO_DOMAIN, 取值范围：

            NO_DOMAIN

            DNS_LIKE_NAME

            MAC_ADDRESS_2OCTETS

            CHARACTER_STRING

        DnsLikeName (str): （IEEE模式下且Domain ID类型为DNS_LIKE_NAME）DnsLikeName，默认值："xinertel.com", 取值范围：长度1-43的字符串

        MacAnd2Octets (str): （IEEE模式下且Domain ID类型为MAC_ADDRESS_2OCTETS）MAC Address + 2 Octec，默认值："00-00-00-00-00-00:0000", 取值范围：string match pattern "^[A-Fa-f0-9]{2}([-]?[A-Fa-f0-9]{2}){5}[:][A-Fa-f0-9]{4}$"

        CharacterStringDmId (str): （IEEE模式下且Domain ID类型为CHARACTER_STRING）Character String，默认值："Domain", 取值范围：长度1-43的字符串

        MaIdType (str): （IEEE模式下）MA ID Type，默认值：CHARACTER_STRING, 取值范围：

            PRIMARY_VID

            CHARACTER_STRING

            TWO_OCTET_INTEGER

            RFC_2685_VPN_ID

        PrimaryVid (int): （IEEE模式下且MEG ID类型为PRIMARY_VID）Primary Vid, 默认值：100, 取值范围：0-4095

        CharacterStringMaId (str): （IEEE模式下且MEG ID类型为CHARACTER_STRING）Character String，默认值："MA_1", 取值范围：长度1-43的字符串

        TwoOctet (str): （IEEE模式下且MEG ID类型为TWO_OCTET_INTEGER）2 Octecs，默认值："0000", 取值范围：string match pattern "^[A-Fa-f0-9]{4}$"

        Rfc2685VpnId (str): （IEEE模式下且MEG ID类型为RFC_2685_VPN_ID）RFC 2685 VPN ID，默认值："00-00-00:00-00-00-00", 取值范围：string match pattern "^[A-Fa-f0-9]{2}([-][A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})[:]([A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})$"

        MegIdType (str): （ITU-T模式下）MEG ID类型，默认值：CHARACTER_STRING, 取值范围：

            PRIMARY_VID

            CHARACTER_STRING

            TWO_OCTET_INTEGER

            RFC_2685_VPN_ID

            ICC_BASED

            CC_AND_ICC_BASED

        IccFormatedString (str): （ITU-T模式下且MEG ID类型为ICC_BASED/CC_AND_ICC_BASED）ICC格式化字符串，默认值："MEG_1", 取值范围：长度1-13的字符串

        CountryCode (str): （ITU-T模式下且MEG ID类型为CC_AND_ICC_BASED）国家代码，默认值："ZZ", 取值范围：string match pattern "^[A-Z]{2}$"

        PrimaryVidMegId (int): （ITU-T模式下且MEG ID类型为PRIMARY_VID）Primary VID, 默认值：100, 取值范围：0-4095

        CharacterStringMegId (str): （ITU-T模式下且MEG ID类型为CHARACTER_STRING）字符串，默认值："MEG_1", 取值范围：长度1-43的字符串

        TwoOctetMegId (str): （ITU-T模式下且MEG ID类型为TWO_OCTET_INTEGER）2 Octects，默认值："0000", 取值范围：string match pattern "^[A-Fa-f0-9]{4}$"

        Rfc2685VpnIdMegId (str): （ITU-T模式下且MEG ID类型为RFC_2685_VPN_ID）RFC 2685 VPN ID，默认值："00-00-00:00-00-00-00", 取值范围：string match pattern "^[A-Fa-f0-9]{2}([-][A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})[:]([A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})([-][A-Fa-f0-9]{2})$"

    Returns:

        (:obj:`Y1731MegConfig`): y1731 MEG对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Meg | OperationMode=IEEE |
    """

    result = renix.create_y1731_meg(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_y1731_mp(Sessions, **kwargs):
    """
    创建y1731 MP对象

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        Meg (:obj:`Y1731MegConfig`): y1731 MEG对象, 类型：object

        Vid1 (int): VLAN ID #1，默认值：100, 取值范围：0-4095

        Vid2 (int): VLAN ID #2，默认值：100, 取值范围：0-4095

        MpType (str): MP类型，默认值：MEP, 取值范围：

            MEP

            MIP

        MepId (int): MEP ID，默认值：1, 取值范围：1-8191

        Rdi (str): RDI，默认值：AUTO, 取值范围：

            AUTO

            OFF

            ON

        EnableAisRx (bool): 使能AIS Rx, 默认值：True, 取值范围：

            True

            False

        EnableLckRx (bool): 使能LCK Rx, 默认值：True, 取值范围：

            True

            False

        EnableLbResponse (bool): 使能LB响应, 默认值：True, 取值范围：

            True

            False

        EnableLtResponse (bool): 使能LT响应, 默认值：True, 取值范围：

            True

            False

        EnableDmResponse (bool): 使能DM响应, 默认值：True, 取值范围：

            True

            False

        EnableLmResponse (bool): 使能LM响应, 默认值：True, 取值范围：

            True

            False

        EnableOverrideCcPeriod (bool): 使能覆盖CC周期, 默认值：False, 取值范围：

            True

            False

        OverrideCcPeriod (str): 覆盖CC周期，默认值：CCM_1S, 取值范围：

            CCM_3MS

            CCM_10MS

            CCM_100MS

            CCM_1S

            CCM_10S

            CCM_1MIN

            CCM_10MIN

        EnableOverrideAisPeriod (bool): 使能覆盖AIS周期, 默认值：False, 取值范围：

            True

            False

        OverrideAisPeriod (str): 覆盖AIS周期，默认值：PERIOD_1S, 取值范围：

            PERIOD_1S

            PERIOD_1MIN

        EnableOverrideLckPeriod (bool): 使能覆盖LCK周期, 默认值：False, 取值范围：

            True

            False

        OverrideLckPeriod (str): 覆盖LCK周期，默认值：PERIOD_1S, 取值范围：

            PERIOD_1S

            PERIOD_1MIN

        EnableOverrideMeLevel (bool): 使能覆盖ME级别, 默认值：False, 取值范围：

            True

            False

        OverrideMeLevel (str): 覆盖ME级别，默认值：LEVEL1, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        DmmDelay (int): DMM延迟，默认值：0, 取值范围：0-100

        DmrDelay (int): DMR延迟，默认值：0, 取值范围：0-100

        LmrRxFCfStart (int): Initial value of the loss Measurement Response received frame count forwarding，默认值：1, 取值范围：0-4294967295

        LmrRxFCfStep (int): Increment value for the number of frames in subsequent steps in Step mode，默认值：1, 取值范围：0-65535

        LmrTxFCbStart (int): Initial value of the loss Measurement Response sent frame count forwarding，默认值：1, 取值范围：0-4294967295

        LmrTxFCbStep (int): Increment value for the number of frames in subsequent steps in Step mode，默认值：1, 取值范围：0-65535

        LmmTxFCfOffset (int): TLV offset for the LMM sent frame count，默认值：0, 取值范围：0-32767

        LmrRxFCfOffset (int): TLV offset for the LMR received frame count，默认值：0, 取值范围：0-32767

        LmrTxFCbOffset (int): TLV offset for the LMR sent frame count，默认值：0, 取值范围：0-32767

    Returns:

        (:obj:`Y1731MpConfig`): y1731 Mp对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Mp | Sessions=${session} | MpType=MEP |
    """

    result = renix.create_y1731_mp(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_y1731_mp(Mps, **kwargs):
    """
    创建y1731 MP对象

    Args:

        (:obj:`Y1731MpConfig`): y1731 Mp对象, 类型：object

    Keyword Args:

        Meg (:obj:`Y1731MegConfig`): y1731 MEG对象, 类型：object

        Vid1 (int): VLAN ID #1，默认值：100, 取值范围：0-4095

        Vid2 (int): VLAN ID #2，默认值：100, 取值范围：0-4095

        MpType (str): MP类型，默认值：MEP, 取值范围：

            MEP

            MIP

        MepId (int): MEP ID，默认值：1, 取值范围：1-8191

        Rdi (str): RDI，默认值：AUTO, 取值范围：

            AUTO

            OFF

            ON

        EnableAisRx (bool): 使能AIS Rx, 默认值：True, 取值范围：

            True

            False

        EnableLckRx (bool): 使能LCK Rx, 默认值：True, 取值范围：

            True

            False

        EnableLbResponse (bool): 使能LB响应, 默认值：True, 取值范围：

            True

            False

        EnableLtResponse (bool): 使能LT响应, 默认值：True, 取值范围：

            True

            False

        EnableDmResponse (bool): 使能DM响应, 默认值：True, 取值范围：

            True

            False

        EnableLmResponse (bool): 使能LM响应, 默认值：True, 取值范围：

            True

            False

        EnableOverrideCcPeriod (bool): 使能覆盖CC周期, 默认值：False, 取值范围：

            True

            False

        OverrideCcPeriod (str): 覆盖CC周期，默认值：CCM_1S, 取值范围：

            CCM_3MS

            CCM_10MS

            CCM_100MS

            CCM_1S

            CCM_10S

            CCM_1MIN

            CCM_10MIN

        EnableOverrideAisPeriod (bool): 使能覆盖AIS周期, 默认值：False, 取值范围：

            True

            False

        OverrideAisPeriod (str): 覆盖AIS周期，默认值：PERIOD_1S, 取值范围：

            PERIOD_1S

            PERIOD_1MIN

        EnableOverrideLckPeriod (bool): 使能覆盖LCK周期, 默认值：False, 取值范围：

            True

            False

        OverrideLckPeriod (str): 覆盖LCK周期，默认值：PERIOD_1S, 取值范围：

            PERIOD_1S

            PERIOD_1MIN

        EnableOverrideMeLevel (bool): 使能覆盖ME级别, 默认值：False, 取值范围：

            True

            False

        OverrideMeLevel (str): 覆盖ME级别，默认值：LEVEL1, 取值范围：

            LEVEL0

            LEVEL1

            LEVEL2

            LEVEL3

            LEVEL4

            LEVEL5

            LEVEL6

            LEVEL7

        DmmDelay (int): DMM延迟，默认值：0, 取值范围：0-100

        DmrDelay (int): DMR延迟，默认值：0, 取值范围：0-100

        LmrRxFCfStart (int): Initial value of the loss Measurement Response received frame count forwarding，默认值：1, 取值范围：0-4294967295

        LmrRxFCfStep (int): Increment value for the number of frames in subsequent steps in Step mode，默认值：1, 取值范围：0-65535

        LmrTxFCbStart (int): Initial value of the loss Measurement Response sent frame count forwarding，默认值：1, 取值范围：0-4294967295

        LmrTxFCbStep (int): Increment value for the number of frames in subsequent steps in Step mode，默认值：1, 取值范围：0-65535

        LmmTxFCfOffset (int): TLV offset for the LMM sent frame count，默认值：0, 取值范围：0-32767

        LmrRxFCfOffset (int): TLV offset for the LMR received frame count，默认值：0, 取值范围：0-32767

        LmrTxFCbOffset (int): TLV offset for the LMR sent frame count，默认值：0, 取值范围：0-32767

    Returns:

        (:obj:`Y1731MpConfig`): y1731 Mp对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Mp | Mps=${mp} | MpType=MEP |
    """

    result = renix.edit_y1731_mp(Mps=Mps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def create_y1731_expected_mep(Megs, **kwargs):
    """
    创建y1731 Expected Mep对象

    Args:

        Megs(:obj:`Y1731MegConfig`): y1731 Meg对象列表, 类型为：list

    Keyword Args:

        MepId (int): MEP ID，默认值：1, 取值范围：0-65535

        MacAddr (str): 目的mac地址，默认值：00:00:00:00:00:01, 取值范围：有效的mac地址

        EnableRx (bool): 使能Rx, 默认值：False, 取值范围：

            True

            False

    Returns:

        (:obj:`Y1731ExpectedMep`): y1731 Expected MEG对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Expected Mep | Megs=${meg} | EnableRx=True |
    """

    result = renix.create_y1731_expected_mep(Megs=Megs, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_y1731_data_tlv(Mps, **kwargs):
    """
    创建y1731 Data Tlv对象

    Args:

        Mps(:obj:`Y1731MpConfig`): y1731 Mp对象列表, 类型为：list

    Keyword Args:

        Length (int): Length，默认值：0, 取值范围：0-65535

        Data (list): Data，默认值：[], 取值范围：列表长度0-255，元素0-255十进制数

    Returns:

        (:obj:`Y1731DataTlv`): y1731 Data Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Data Tlv | Mps=${mp} | Length=10 |
    """

    result = renix.create_y1731_data_tlv(Mps=Mps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_y1731_ltm_egress_identifier_tlv(Mps, **kwargs):
    """
    创建y1731 Ltm Egress Identifier Tlv对象

    Args:

        Mps(:obj:`Y1731MpConfig`): y1731 Mp对象列表, 类型为：list

    Keyword Args:

        Length (int): Length of TLV value field，默认值：0, 取值范围：0-65535

        Index (int): Egress Identifier - Index，默认值：0, 取值范围：0-65535

        MacAddress (str): Egress Identifier - Mac address，默认值："00:00:00:00:00:00", 取值范围：有效的mac地址

    Returns:

        (:obj:`Y1731LtmEgressIdentifierTlv`): y1731 Ltm Egress Identifier Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Ltm Egress Identifier Tlv | Mps=${mp} | Length=10 |
    """

    result = renix.create_y1731_ltm_egress_identifier_tlv(Mps=Mps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_y1731_ltr_egress_identifier_tlv(Mps, **kwargs):
    """
    创建y1731 Ltr Egress Identifier Tlv对象

    Args:

        Mps(:obj:`Y1731MpConfig`): y1731 Mp对象列表, 类型为：list

    Keyword Args:

        Length (int): Length of TLV value field，默认值：0, 取值范围：0-65535

        LastIndex (hex): Last Egress Identifier - Unique Identifier，默认值：0, 取值范围：0-65535

        LastMacAddress (str): Last Egress Identifier - MAC address，默认值："00:00:00:00:00:00", 取值范围：有效的mac地址

        NextIndex (hex): Next Egress Identifier - Unique Identifier，默认值：0, 取值范围：0-65535

        NextMacAddress (str): Next Egress Identifier - MAC address，默认值："00:00:00:00:00:00", 取值范围：有效的mac地址

    Returns:

        (:obj:`Y1731LtrEgressIdentifierTlv`): y1731 Ltr Egress Identifier Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Ltm Egress Identifier Tlv | Mps=${mp} | Length=10 |
    """

    result = renix.create_y1731_ltr_egress_identifier_tlv(Mps=Mps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_y1731_organization_specific_tlv(Mps, **kwargs):
    """
    创建y1731 Organization Specific Tlv对象

    Args:

        Mps(:obj:`Y1731MpConfig`): y1731 Mp对象列表, 类型为：list

    Keyword Args:

        Length (int): Length of TLV value field，默认值：0, 取值范围：0-65535

        OrgUniqueId (list): Unique organization ID，默认值：[0,0,0], 取值范围：列表元素为0-255的十进制数

        SubType (int): Sub-type of this TLV，默认值：0, 取值范围：0-255

        Data (list): TLV Data，默认值：[], 取值范围：列表长度0-255，元素0-255十进制数

    Returns:

        (:obj:`Y1731OrgSpecificTlv`): y1731 Organization Specific Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Organization Specific Tlv | Mps=${mp} | Length=10 |
    """

    result = renix.create_y1731_organization_specific_tlv(Mps=Mps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_y1731_reply_ingress_tlv(Mps, **kwargs):
    """
    创建y1731 Reply Ingress Tlv对象

    Args:

        Mps(:obj:`Y1731MpConfig`): y1731 Mp对象列表, 类型为：list

    Keyword Args:

        Length (int): Length of TLV value field，默认值：0, 取值范围：0-65535

        IngressAction (str): Ingress Action，默认值：ACTION_ING_OK, 取值范围：

            ACTION_ING_OK

            ACTION_ING_DOWN

            ACTION_ING_BLOCKED

            ACTION_ING_VID

        IngressMacAddress (str): Ingress MAC address，默认值："00:00:00:00:00:00", 取值范围：有效的mac地址

        ChassisIdLength (int): Chassis ID Length，默认值：0, 取值范围：0-255

        ChassisIdSubtype (int): Chassis ID Sub-type，默认值：0, 取值范围：0-255

        ChassisId (list): Data，默认值：[], 取值范围：列表长度0-255，元素0-255十进制数

    Returns:

        (:obj:`Y1731ReplyIngressTlv`): y1731 Reply Ingress Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Y1731 Reply Ingress Tlv | Mps=${mp} | Length=10 |
    """

    result = renix.create_y1731_reply_ingress_tlv(Mps=Mps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_1dm(Sessions, **kwargs):
    """
    启动1DM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

        TxType (str): Message type，默认值：SINGLE, 取值范围：

            SINGLE

            CONTINUOUS

            MULTIPLE

        TxRate (str): Message type，默认值：TXRATE_1_PER_SEC, 取值范围：

            TXRATE_10_PER_SEC

            TXRATE_1_PER_SEC

            TXRATE_1_PER_MIN

            TXRATE_1_PER_10MIN

        TxCount (int): Number of packets to send，默认值：1, 取值范围：0-65535

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 1dm | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_1dm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_ais(Sessions, **kwargs):
    """
    启动AIS

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 AIS | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_ais(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_ccm(Sessions, **kwargs):
    """
    启动CCM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

        CcosList (list): List of class of service values for customer VLAN, 默认值：[], 列表元素取值范围：0-7

        ScosList (list): List of class of service values for service-provider VLAN, 默认值：[], 列表元素取值范围：0-7

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 Ccm | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_ccm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_dmm(Sessions, **kwargs):
    """
    启动CCM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

        TxType (str): Message type，默认值：SINGLE, 取值范围：

            SINGLE

            CONTINUOUS

            MULTIPLE

        TxRate (str): Message type，默认值：TXRATE_1_PER_SEC, 取值范围：

            TXRATE_10_PER_SEC

            TXRATE_1_PER_SEC

            TXRATE_1_PER_MIN

            TXRATE_1_PER_10MIN

        CcosList (int): List of class of service values for customer VLAN, 默认值："", 取值范围：0-7

        ScosList (int): List of class of service values for service-provider VLAN, 默认值："", 取值范围：0-7

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 Dmm | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_dmm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_lbm(Sessions, **kwargs):
    """
    启动CCM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

        InitTransactionId (int): Initial transaction ID，默认值：1, 取值范围：0-4294967295

        TxType (str): Message type，默认值：SINGLE, 取值范围：

            SINGLE

            CONTINUOUS

            MULTIPLE

        TxRate (str): Message type，默认值：TXRATE_1_PER_SEC, 取值范围：

            TXRATE_10_PER_SEC

            TXRATE_1_PER_SEC

            TXRATE_1_PER_MIN

            TXRATE_1_PER_10MIN

        TxCount (int): Number of packets to send，默认值：1, 取值范围：0-65535

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 Lbm | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_lbm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_lck(Sessions, **kwargs):
    """
    启动LCK

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 Lck | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_lck(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_lmm(Sessions, **kwargs):
    """
    启动LMM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

        TxType (str): Message type，默认值：SINGLE, 取值范围：

            SINGLE

            CONTINUOUS

        TxRate (str): Message type，默认值：TXRATE_1_PER_SEC, 取值范围：

            TXRATE_10_PER_SEC

            TXRATE_1_PER_SEC

            TXRATE_1_PER_MIN

            TXRATE_1_PER_10MIN

        TxFCfMode (str): Method of transmitting frames, a constant rate or stepping the number of frames，默认值：STEP, 取值范围：

            STATIC

            STEP

        TxFCfValue (int): TxFCf counter value to be included in the LM message (TxFCf mode = static) or initial value of the counter (TxFCf mode = step)，默认值：1, 取值范围：0-4294967295

        TxFCfStep (int): Step value for the TcFCf counter in each subsequent LM message，默认值：1, 取值范围：0-65535

        CcosList (int): List of class of service values for customer VLAN, 默认值："", 取值范围：0-7

        ScosList (int): List of class of service values for service-provider VLAN, 默认值："", 取值范围：0-7

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 Lmm | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_lmm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_y1731_ltm(Sessions, **kwargs):
    """
    启动LTM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MsgType (str): Message type，默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

        DestMacList (str): Destination MAC Address，默认值："", 取值范围：有效的mac地址

        InitTransactionId (int): Initial transaction ID，默认值：1, 取值范围：0-4294967295

        InitTtl (int): Initial time to live value，默认值：255, 取值范围：0-255

        TxType (str): Message type，默认值：SINGLE, 取值范围：

            SINGLE

            CONTINUOUS

            MULTIPLE

        TxRate (str): Message type，默认值：TXRATE_1_PER_SEC, 取值范围：

            TXRATE_10_PER_SEC

            TXRATE_1_PER_SEC

            TXRATE_1_PER_MIN

            TXRATE_1_PER_10MIN

        TxCount (int): Number of packets to send，默认值：1, 取值范围：0-65535

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Y1731 Ltm | Sessions=${Sessions} | MsgType=UNICAST |
    """

    result = renix.start_y1731_ltm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_1dm(Sessions, **kwargs):
    """
    停止1DM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 1dm | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_1dm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_ais(Sessions, **kwargs):
    """
    停止AIS

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 Ais | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_ais(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_ccm(Sessions, **kwargs):
    """
    停止CCM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 Ccm | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_ccm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_dmm(Sessions, **kwargs):
    """
    停止DMM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 Dmm | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_dmm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_lbm(Sessions, **kwargs):
    """
    停止LBM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 Lbm | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_lbm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_lck(Sessions, **kwargs):
    """
    停止LCK

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 LCK | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_lck(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_lmm(Sessions, **kwargs):
    """
    停止LMM

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 Lmm | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_lmm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_y1731_ltm(Sessions, **kwargs):
    """
    停止Ltm

    Args:

        Sessions(:obj:`Y1731`): y1731协议会话对象列表, 类型为：list

    Keyword Args:

        MepHandles (:obj:`Y1731MpConfig`): Y.1731 meps对象，默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Y1731 Ltm | Sessions=${Sessions} |
    """

    result = renix.stop_y1731_ltm(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_y1731_port_statistic(Port=None, StaItems: list = None):
    """
    获取y1731 port统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            MaOrMegCount

            DropPacketCount

            TxAis

            RxAis

            TxCcm

            RxCcm

            TxDmm

            RxDmm

            TxLbm

            RxLbm

            TxLck

            RxLck

            TxLmm

            RxLmm

            TxLtm

            RxLtm

            Tx1Dm

            Rx1Dm

    Returns:

        dict: eg::

            {
                'Tx1Dm': 10,
                'Rx1Dm': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Y1731 Port Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_y1731_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_y1731_meg_statistic(Meg=None, Port=None, StaItems: list = None):
    """
    获取y1731 Meg统计结果

    Args:

        Meg(:obj:`Y1731MegConfig`): y1731 Meg对象, 类型为：Object

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            MdOrMeLevel

            DropPacketCount

            TimeOuts

            UnexpectedId

            UnexpectedLevel

            Meps

            UnexpectedMeps

            UnexpectedPeriod

            BadCcReceiveCount

            CcRxState

            CcTxState

    Returns:

        dict: eg::

            {
                'CcRxState': 10,
                'CcTxState': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Y1731 Meg Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_y1731_meg_statistic(Meg=Meg, Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_y1731_mp_statistic(Mp=None, StaItems: list = None):
    """
    获取y1731 Mp统计结果

    Args:

        Mp(:obj:`Y1731MpConfig`): y1731 Mp对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionHandle

            MpType

            MepId

            RemoteMeps

            CcmTimeout

            CcmUnexpectMeg

            CcmUnexpectMep

            CcmUnexpectMeLevel

            UnexpectedPeriod

            TxCcm300Hz

            TxCcm10ms

            TxCcm100ms

            TxCcm1s

            TxCcm10s

            TxCcm1min

            TxCcm10min

            RxCcm

            LastTxCcmSeqNum

            LbmTimeout

            LbTransIdMismatch

            TxLbm

            RxLbm

            TxLbr

            RxLbr

            TxLtm

            RxLtm

            TxLtr

            RxLtr

            LtmTimeout

            TxAis

            RxAis

            AisTimeout

            TxLck

            RxLck

            LckTimeout

            Tx1Dm

            Rx1Dm

            TxDmm

            RxDmm

            TxDmr

            RxDmr

            DmmTimeout

            TxLmm

            RxLmm

            TxLmr

            RxLmr

            LmmTimeout

    Returns:

        dict: eg::

            {
                'TxLmr': 10,
                'RxLmr': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Y1731 Mp Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_y1731_mp_statistic(Mp=Mp, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result




import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------PCEP-------------------------------------
def create_pcep(Port, **kwargs):
    """
    创建PCEP协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): PCEP协会话名称, 类型为：string

        Enable (bool): 使能PCEP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Role (str): PCEP角色, 类型为：string, 默认值：PCE, 取值范围:

            PCE

            PCC

        IpVersion (str): IP版本, 类型为：string, 默认值：IPv4, 取值范围:

            IPv4

            IPv6

        UseGatewayAsDutIp (bool): 使用网关地址作为DUT地址, 选中则使用接口上配置的网关IP地址作为DUT地址；未选中则自定义DUT IP地址, 类型为：bool, 取值范围：True或False, 默认值：True

        SessionIpAddress (str): 会话IP地址, 用于PCEP连接的IP类型, 类型为：string, 默认值：Interface_IP, 取值范围:

            Interface_IP

            Router_ID

        PeerIpv4Address (str): DUT IPv4地址, 使用网关地址作为DUT地址未选中且IP版本为IPv4时可见, 指定DUT的IPv4地址, 类型为：string, 默认值：192.85.1.1, 取值范围：有效的Ipv4地址

        PeerIpv4AddressStep (str): DUT IPv4地址跳变, 使用网关地址作为DUT地址未选中且IP版本为IPv4时可见, 指定DUT IPv4地址的增量步长, 类型为：string, 默认值：0.0.0.1, 取值范围：有效的Ipv4地址

        PeerIpv6Address (str): DUT IPv6地址, 使用网关地址作为DUT地址未选中且IP版本为IPv6时可见, 指定DUT的IPv6地址, 类型为：string, 默认值：2000::1, 取值范围：有效的Ipv6地址

        PeerIpv6AddressStep (str): DUT IPv6地址跳变, 使用网关地址作为DUT地址未选中且IP版本为IPv6时可见, 指定DUT的IPv6地址的增量步长, 类型为：string, 默认值：::1, 取值范围：有效的Ipv6地址

        SessionInitiator (bool): 会话发起者, 选中则主动发起会话建立请求；未选中则监听对端的发起会话建立请求。双方均主动发起会话建立请求时，IP地址大的一方优先级更高, 类型为：bool, 取值范围：True或False, 默认值：True

        Negotiation (bool): 使能Negotiation, 选中则对Keepalive Timer和Dead Timer的值进行协商, 类型为：bool, 取值范围：True或False, 默认值：True

        KeepAlive (str): Keep Alive间隔 (sec), KEEPALIVE消息的发送间隔，以秒为单位, 类型为：string, 默认值：30, 0-65535

        MinKeepAlive (int): KEEPALIVE消息发送间隔的最小值。以秒为单位, 类型为：number, 取值范围：0-255, 默认值： 0

        MaxKeepAlive (int): KEEPALIVE消息发送间隔的最大值，以秒为单位, 类型为：number, 取值范围：0-255, 默认值： 255

        Dead (str): Dead间隔 (sec), 从未收到对端消息到PCEP会话断开连接之间的时间间隔。类型为：string, 取值范围：0-65535, 默认值： 120

        MinDeadAlive (int): 最小可接受Dead间隔(sec), 类型为：number, 取值范围：0-255, 默认值： 0

        MaxDeadAlive (int): 最大可接受Dead间隔(sec), 类型为：number, 取值范围：0-255, 默认值： 255

        EnableStatefulCapability (bool): 选中则OPEN消息中包含Stateful PCE Capability TLV, 类型为：bool, 取值范围：True或False, 默认值： True

        StatefulCapability (list): 使能PCE Stateful Capability选中时可见, 单击单元格并从下拉菜单中选择一个或多个能力, 类型为：list, 默认值：['LSP_UPDATE','LSP_INSTANTIATION'], 取值范围:

            LSP_UPDATE

            INCLUDE_DB_VERSION

            LSP_INSTANTIATION

            TRIGGERED_RESYNC

            DELTA_LSP_SYN

            TRIGGERED_INITIAL_SYNC

        EnableSegmentRoutingCapability (list): 选择段路由扩展，OPEN消息中将包括该Capability TLV, 类型为：list, 默认值：['SR'], 取值范围：

            SR

            SRv6

        PathSetupTypeList (list): 添加路径建立类型, 类型为：list, 默认值：[0,1]

        SrCapabilityFlags (list): 选择一个或多个SR能力标志, PCEP角色为PCC，且使能Segment Routing Capability中选中SR时可见, 类型为：list, 默认值：['NONTBIT','NFlag','XFlag'],

            NONTBIT

            NFlag

            XFlag

        Srv6CapabilityFlags (list): 选择一个或多个SRv6能力标志, PCEP角色为PCC，且使能Segment Routing Capability中选中SRv6时可见, 类型为：list, 默认值：['NONTBIT','NFlag','XFlag'],

            NONTBIT

            NFlag

            XFlag

        MSDs (list): 选择一个或多个MSD类型, PCEP角色为PCC，且使能Segment Routing Capability中选中SRv6时可见, 类型为：list, 默认值：['NONTBIT']

            NONTBIT

            MaxiSegmentLeft

            MaxiEndPop

            MaxiHEncaps

            MaxiEndD

        MaximumSidDepth (int): 指定SID的最大数量, PCEP角色为PCC，且使能Segment Routing Capability中选中SR时可见, 类型为：number, 默认值：0, 取值范围：0-255

        MaxSegmentsLeft (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum Segments Left时可见, 类型为：number, 默认值：8, 取值范围：0-255

        MaxEndPop (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum End Pop时可见, 类型为：number, 默认值：8, 取值范围：0-255

        MaxHencaps (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum H.Encaps时可见, 类型为：number, 默认值：8, 取值范围：0-255

        MaxEndD (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum End D时可见, 类型为：number, 默认值：8, 取值范围：0-255

        EnableDbVersionTlv (bool): 选中则配置DB version TLV, 类型为：bool, 取值范围：True或False, 默认值： False

        LspStateDbVersion (int): 指定LSP状态数据库的初始版本号, 选中使能DB Version TLV时可见, 类型为：number, 默认值： 1, 取值范围：1-18446744073709551614

    Returns:

        (:obj:`Pcep`): PCEP协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Pcep | Port=${Port} |
    """

    result = renix.create_pcep(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_pcep(Sessions, **kwargs):
    """
    编辑PCEP协议会话对象参数

    Args:

        Sessions (:obj:`Pcep`): : PCEP协议会话对象, 类型为：object

    Keyword Args:

        Name (str): PCEP协会话名称, 类型为：string

        Enable (bool): 使能PCEP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Role (str): PCEP角色, 类型为：string, 默认值：PCE, 取值范围:

            PCE

            PCC

        IpVersion (str): IP版本, 类型为：string, 默认值：IPv4, 取值范围:

            IPv4

            IPv6

        UseGatewayAsDutIp (bool): 使用网关地址作为DUT地址, 选中则使用接口上配置的网关IP地址作为DUT地址；未选中则自定义DUT IP地址, 类型为：bool, 取值范围：True或False, 默认值：True

        SessionIpAddress (str): 会话IP地址, 用于PCEP连接的IP类型, 类型为：string, 默认值：Interface_IP, 取值范围:

            Interface_IP

            Router_ID

        PeerIpv4Address (str): DUT IPv4地址, 使用网关地址作为DUT地址未选中且IP版本为IPv4时可见, 指定DUT的IPv4地址, 类型为：string, 默认值：192.85.1.1, 取值范围：有效的Ipv4地址

        PeerIpv4AddressStep (str): DUT IPv4地址跳变, 使用网关地址作为DUT地址未选中且IP版本为IPv4时可见, 指定DUT IPv4地址的增量步长, 类型为：string, 默认值：0.0.0.1, 取值范围：有效的Ipv4地址

        PeerIpv6Address (str): DUT IPv6地址, 使用网关地址作为DUT地址未选中且IP版本为IPv6时可见, 指定DUT的IPv6地址, 类型为：string, 默认值：2000::1, 取值范围：有效的Ipv6地址

        PeerIpv6AddressStep (str): DUT IPv6地址跳变, 使用网关地址作为DUT地址未选中且IP版本为IPv6时可见, 指定DUT的IPv6地址的增量步长, 类型为：string, 默认值：::1, 取值范围：有效的Ipv6地址

        SessionInitiator (bool): 会话发起者, 选中则主动发起会话建立请求；未选中则监听对端的发起会话建立请求。双方均主动发起会话建立请求时，IP地址大的一方优先级更高, 类型为：bool, 取值范围：True或False, 默认值：True

        Negotiation (bool): 使能Negotiation, 选中则对Keepalive Timer和Dead Timer的值进行协商, 类型为：bool, 取值范围：True或False, 默认值：True

        KeepAlive (str): Keep Alive间隔 (sec), KEEPALIVE消息的发送间隔，以秒为单位, 类型为：string, 默认值：30, 0-65535

        MinKeepAlive (int): KEEPALIVE消息发送间隔的最小值。以秒为单位, 类型为：number, 取值范围：0-255, 默认值： 0

        MaxKeepAlive (int): KEEPALIVE消息发送间隔的最大值，以秒为单位, 类型为：number, 取值范围：0-255, 默认值： 255

        Dead (str): Dead间隔 (sec), 从未收到对端消息到PCEP会话断开连接之间的时间间隔。类型为：string, 取值范围：0-65535, 默认值： 120

        MinDeadAlive (int): 最小可接受Dead间隔(sec), 类型为：number, 取值范围：0-255, 默认值： 0

        MaxDeadAlive (int): 最大可接受Dead间隔(sec), 类型为：number, 取值范围：0-255, 默认值： 255

        EnableStatefulCapability (bool): 选中则OPEN消息中包含Stateful PCE Capability TLV, 类型为：bool, 取值范围：True或False, 默认值： True

        StatefulCapability (list): 使能PCE Stateful Capability选中时可见, 单击单元格并从下拉菜单中选择一个或多个能力, 类型为：list, 默认值：['LSP_UPDATE','LSP_INSTANTIATION'], 取值范围:

            LSP_UPDATE

            INCLUDE_DB_VERSION

            LSP_INSTANTIATION

            TRIGGERED_RESYNC

            DELTA_LSP_SYN

            TRIGGERED_INITIAL_SYNC

        EnableSegmentRoutingCapability (list): 选择段路由扩展，OPEN消息中将包括该Capability TLV, 类型为：list, 默认值：['SR'], 取值范围：

            SR

            SRv6

        PathSetupTypeList (list): 添加路径建立类型, 类型为：list, 默认值：[0,1]

        SrCapabilityFlags (list): 选择一个或多个SR能力标志, PCEP角色为PCC，且使能Segment Routing Capability中选中SR时可见, 类型为：list, 默认值：['NONTBIT','NFlag','XFlag'],

            NONTBIT

            NFlag

            XFlag

        Srv6CapabilityFlags (list): 选择一个或多个SRv6能力标志, PCEP角色为PCC，且使能Segment Routing Capability中选中SRv6时可见, 类型为：list, 默认值：['NONTBIT','NFlag','XFlag'],

            NONTBIT

            NFlag

            XFlag

        MSDs (list): 选择一个或多个MSD类型, PCEP角色为PCC，且使能Segment Routing Capability中选中SRv6时可见, 类型为：list, 默认值：['NONTBIT']

            NONTBIT

            MaxiSegmentLeft

            MaxiEndPop

            MaxiHEncaps

            MaxiEndD

        MaximumSidDepth (int): 指定SID的最大数量, PCEP角色为PCC，且使能Segment Routing Capability中选中SR时可见, 类型为：number, 默认值：0, 取值范围：0-255

        MaxSegmentsLeft (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum Segments Left时可见, 类型为：number, 默认值：8, 取值范围：0-255

        MaxEndPop (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum End Pop时可见, 类型为：number, 默认值：8, 取值范围：0-255

        MaxHencaps (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum H.Encaps时可见, 类型为：number, 默认值：8, 取值范围：0-255

        MaxEndD (int): 指定MSD取值, PCEP角色为PCC，使能Segment Routing Capability中选中SRv6，且MSDs中选中Maximum End D时可见, 类型为：number, 默认值：8, 取值范围：0-255

        EnableDbVersionTlv (bool): 选中则配置DB version TLV, 类型为：bool, 取值范围：True或False, 默认值： False

        LspStateDbVersion (int): 指定LSP状态数据库的初始版本号, 选中使能DB Version TLV时可见, 类型为：number, 默认值： 1, 取值范围：1-18446744073709551614

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | Role=PCC |
    """

    result = renix.edit_pcep(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pcc_lsp(Sessions, **kwargs):
    """
    创建PCEP PCC LSP对象

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP PCC LSP对象名称, 类型为：string

        Enable (bool): 使能PCEP PCC LSP, 类型为：bool, 取值范围：True或False, 默认值：True

        LspCount (int): Lsp数量, 类型为：number, 默认值：1, 取值范围：1-65535

        AutoGenSymbolicName (bool): 系统自动生成Symbolic Name, 类型为：bool, 取值范围：True或False, 默认值：False

        SymbolicName (str): 设置Symbolic Name, 类型为：string, 默认值：PLSP_@s

        PathSetupType (str): 建立LSP的方法, 类型为：string, 默认值：SEGMENT_ROUTING, 取值范围：

            SEGMENT_ROUTING

            SRv6

        SourceIpv4Address (str): 起始源IP地址, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        SourceIpv4AddressStep (str): 源IP地址的跳变步长, 类型为：string, 默认值：0.0.0.1, 取值范围: IPv4地址

        SourceIpv4AddressSessionOffset: 源IPv4地址接口跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：0.0.1.0, 取值范围: IPv4地址

        DestinationIpv4Address (str): 起始目的IP地址, 类型为：string, 默认值：193.85.1.1, 取值范围: IPv4地址

        DestinationIpv4AddressStep (str): 目的IP地址的跳变步长, 类型为：string, 默认值：0.0.0.1, 取值范围: IPv4地址

        DestinationIpv4AddressSessionOffset (str): 目的IPv4地址跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：0.0.1.0, 取值范围: IPv4地址

        SourceIpv6Address (str): 源IPv6地址的跳变步长, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        SourceIpv6AddressStep (str): 源IPv6地址的跳变步长, 类型为：string, 默认值：::1, 取值范围: IPv6地址

        SourceIpv6AddressSessionOffset (str): 源IPv6地址接口跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：::1:0, 取值范围: IPv6地址

        DestinationIpv6Address (str): 起始目的IPv6地址, 类型为：string, 默认值：2001::1, 取值范围: IPv6地址

        DestinationIpv6AddressStep (str): 目的IPv6地址的跳变步长, 类型为：string, 默认值：::1, 取值范围: IPv6地址

        DestinationIpv6AddressSessionOffset (str): 目的IPv6地址跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：::1:0, 取值范围: IPv6地址

        LspInitiateMethod (str): LSP初始方式, 类型为：string, 默认值：REPORT, 取值范围:

            REPORT

            PCE_INITIATE

            SYNCHRONIZATION

            REQUEST

        ImmediateDelegation (bool): 直接托管, 会话建立后自动将LSP托管给PCE, LSP初始方式为Report Method、Synchronization Method或Request Method时可见, 类型为：bool, 取值范围：True或False, 默认值：True

        DelegationInSynchronization (bool): 同步中托管, LSP初始方式为Synchronization Method时可见, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PccLspConfig`): Pcep Pcc Lsp对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
    """

    result = renix.create_pcc_lsp(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pce_lsp(Sessions, **kwargs):
    """
    创建PCEP PCE LSP对象

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP PCE LSP对象名称, 类型为：string

        Enable (bool): 使能PCEP PCE LSP, 类型为：bool, 取值范围：True或False, 默认值：True

        LspCount (int): Lsp数量, 类型为：number, 默认值：1, 取值范围：1-65535

        AutoGenSymbolicName (bool): 系统自动生成Symbolic Name, 类型为：bool, 取值范围：True或False, 默认值：False

        SymbolicName (str): 设置Symbolic Name, 类型为：string, 默认值：PLSP_@s

        PathSetupType (str): 建立LSP的方法, 类型为：string, 默认值：SEGMENT_ROUTING, 取值范围：

            SEGMENT_ROUTING

            SRv6

        SourceIpv4Address (str): 起始源IP地址, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        SourceIpv4AddressStep (str): 源IP地址的跳变步长, 类型为：string, 默认值：0.0.0.1, 取值范围: IPv4地址

        SourceIpv4AddressSessionOffset: 源IPv4地址接口跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：0.0.1.0, 取值范围: IPv4地址

        DestinationIpv4Address (str): 起始目的IP地址, 类型为：string, 默认值：193.85.1.1, 取值范围: IPv4地址

        DestinationIpv4AddressStep (str): 目的IP地址的跳变步长, 类型为：string, 默认值：0.0.0.1, 取值范围: IPv4地址

        DestinationIpv4AddressSessionOffset: 目的IPv4地址跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：0.0.1.0, 取值范围: IPv4地址

        SourceIpv6Address (str): 源IPv6地址的跳变步长, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        SourceIpv6AddressStep (str): 源IPv6地址的跳变步长, 类型为：string, 默认值：::1, 取值范围: IPv6地址

        SourceIpv6AddressSessionOffset: 源IPv6地址接口跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：::1:0, 取值范围: IPv6地址

        DestinationIpv6Address (str): 起始目的IPv6地址, 类型为：string, 默认值：2001::1, 取值范围: IPv6地址

        DestinationIpv6AddressStep (str): 目的IPv6地址的跳变步长, 类型为：string, 默认值：::1, 取值范围: IPv6地址

        DestinationIpv6AddressSessionOffset: 目的IPv6地址跳变, 指定PCEP会话块中源IP地址在会话之间的跳变步长, 类型为：string, 默认值：::1:0, 取值范围: IPv6地址

        LspInitiateMethod (str): LSP初始方式, 类型为：string, 默认值：UPDATE, 取值范围:

            UPDATE

            PCE_INITIATE

            REPLY

        ImmediateUpdate (bool): 直接更新, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`PceLspConfig`): Pcep Pce Lsp对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
    """

    result = renix.create_pce_lsp(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pcc_lsp_info(PcepLsps, **kwargs):
    """
    创建PCEP PCC LSP INFO对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCC LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP PCC LSP INFO对象名称, 类型为：string

        Enable (bool): PCEP PCC LSP INFO对象, 类型为：bool, 取值范围：True或False, 默认值：True

        Administrator (bool): 使能Administrative, 类型为：bool, 取值范围：True或False, 默认值：True

        State (str): 设置Initial LSP State, 类型为：string, 默认值：GOING_UP, 取值范围：

            DOWN

            UP

            ACTIVE

            GOING_DOWN

            GOING_UP

            RESERVED_5

            RESERVED_6

            RESERVED_7

        AutoGeneratedPlspId (bool): 自动生成PLSP-ID, 类型为：bool, 取值范围：True或False, 默认值：True

        PlspId (int): 指定起始PLSP-ID, 类型为：number, 默认值：1, 取值范围：1-1048575

        Step (int): 指定PLSP-ID的跳变步长, 类型为：number, 默认值：1, 取值范围：1-1048575

        LspId (int): 指定起始LSP ID, 类型为：number, 默认值：1, 取值范围：1-65535

        LspIdStep (int): 指定同一个会话中LSP-ID的跳变步长, 类型为：number, 默认值：1, 取值范围：1-65535

        LspIdSessionOffset (int): 指定PCEP会话块中LSP-ID在会话之间的跳变步长, 类型为：number, 默认值：1, 取值范围：1-65535

        TunnelId (int): 指定起始隧道ID, 类型为：number, 默认值：1, 取值范围：1-65535

        TunnelStep (int): 指定同一个会话中隧道ID的跳变步长, 类型为：number, 默认值：1, 取值范围：1-65535

        TunnelSessionOffset (int): 指定PCEP会话块中隧道ID在会话之间的跳变步长, 类型为：number, 默认值：1, 取值范围：1-65535

        ExtendedTunnelIPv4Id (str): 指定扩展隧道ID, 类型为：string, 默认值：10.0.0.1, 取值范围: IPv4地址

        ExtendedTunnelIPv4IdStep (str): 指定同一个会话中扩展隧道ID的跳变步长, 类型为：string, 默认值：0.0.0.1, 取值范围: IPv4地址

        ExtendedTunnelIPv4IdSessionOffset (str): 指定PCEP会话块中扩展隧道ID在会话之间的跳变步长, 类型为：string, 默认值：0.0.1.0, 取值范围: IPv4地址

        ExtendedTunnelIPv6Id (str): 指定扩展隧道ID, 类型为：string, 默认值：2000:1::1, 取值范围: IPv6地址

        ExtendedTunnelIPv6IdStep (str): 指定同一个会话中扩展隧道ID的跳变步长, 类型为：string, 默认值：::1, 取值范围: IPv6地址

        ExtendedTunnelIPv6IdSessionOffset: 指定PCEP会话块中扩展隧道ID在会话之间的跳变步长, 类型为：string, 默认值：::1:0, 取值范围: IPv6地址

    Returns:

        (:obj:`PccLspInfoObjectConfig`): Pcep Pcc Lsp Info对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${LspInfo} | Create Pcep Pcc Lsp Info | PcepLsp=${Egress} |
    """

    result = renix.create_pcc_lsp_info_object(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pce_lsp_info(PcepLsps, **kwargs):
    """
    创建PCEP PCE LSP INFO对象

    Args:

        PcepLsps(:obj:`PceLspConfig`): : PCEP PCE LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP PCE LSP INFO对象名称, 类型为：string

        Enable (bool): PCEP PCE LSP INFO对象, 类型为：bool, 取值范围：True或False, 默认值：True

        Administrator (bool): 使能Administrative, 类型为：bool, 取值范围：True或False, 默认值：True

        State (str): 设置Initial LSP State, 类型为：string, 默认值：GOING_UP, 取值范围：

            DOWN

            UP

            ACTIVE

            GOING_DOWN

            GOING_UP

            RESERVED_5

            RESERVED_6

            RESERVED_7

    Returns:

        (:obj:`PceLspInfoObjectConfig`): Pcep Pce Lsp Info对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Info} | Create Pcep Pce Lsp Info | PcepLsp=${Egress} |
    """

    result = renix.create_pce_lsp_info_object(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pcc_auto_delegation_parameters(PcepLsps, **kwargs):
    """
    创建PCEP Auto Delegation Parameters对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCC LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Auto Delegation Parameters对象名称, 类型为：string

        Enable (bool): PCEP Auto Delegation Parameters对象, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`PcepAutoDelegationParametersConfig`): Pcep Pcc Lsp Auto Delegation Parameters对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Pcc Auto Delegation Parameters | PcepLsp=${Egress} |
    """

    result = renix.pcep_auto_delegation_parameters_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pce_auto_initiate_parameters(PcepLsps, **kwargs):
    """
    创建PCEP PCE Lsp Auto Initiate Parameters对象

    Args:

        PcepLsps(:obj:`PceLspConfig`): : PCEP PCE LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Auto Initiate Parameters对象名称, 类型为：string

        Enable (bool): PCEP Auto Initiate Parameters对象, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`PcepAutoInitiateParametersConfig`): Pcep Pce Lsp Auto Initiate Parameters对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Pce Auto Initiate Parameters | PcepLsp=${Egress} |
    """

    result = renix.pcep_auto_initiate_parameters_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pce_auto_reply_parameters(PcepLsps, **kwargs):
    """
    创建PCEP PCE Lsp Auto Reply Parameters对象

    Args:

        PcepLsps(:obj:`PceLspConfig`): : PCEP PCE LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Auto Reply Parameters对象名称, 类型为：string

        Enable (bool): PCEP Auto Reply Parameters对象, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`PcepAutoReplyParametersConfig`): Pcep Pce Lsp Auto Reply Parameters对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Pce Auto Reply Parameters | PcepLsp=${Egress} |
    """

    result = renix.pcep_auto_reply_parameters_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pcc_auto_request_parameters(PcepLsps, **kwargs):
    """
    创建PCEP PCC Lsp Auto Request Parameters对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCC LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Auto Request Parameters对象名称, 类型为：string

        Enable (bool): PCEP Auto Request Parameters对象, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`PcepAutoRequestParametersConfig`): Pcep Pce Lsp Auto Request Parameters对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Pcc Auto Request Parameters | PcepLsp=${Egress} |
    """

    result = renix.pcep_auto_request_parameters_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pcc_auto_sync_parameters(PcepLsps, **kwargs):
    """
    创建PCEP PCC Lsp Auto Sync Parameters对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCC LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Auto Sync Parameters对象名称, 类型为：string

        Enable (bool): PCEP Auto Sync Parameters对象, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`PcepAutoSyncParametersConfig`): Pcep Pce Lsp Auto Sync Parameters对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Pcc Auto Sync Parameters | PcepLsp=${Egress} |
    """

    result = renix.pcep_auto_sync_parameters_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_pce_auto_update_parameters(PcepLsps, **kwargs):
    """
    创建PCEP PCE Lsp Auto Update Parameters对象

    Args:

        PcepLsps(:obj:`PceLspConfig`): : PCEP PCE LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Auto Update Parameters对象名称, 类型为：string

        Enable (bool): PCEP Auto Update Parameters对象, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`PcepAutoUpdateParametersConfig`): Pcep Pce Lsp Auto Update Parameters对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Pce Auto Update Parameters | PcepLsp=${Egress} |
    """

    result = renix.pcep_auto_update_parameters_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_lsp_auto_tx_parameters(PcepAutoParameters, **kwargs):
    """
    创建PCEP PCE Lsp Auto Tx Parameters对象

    Args:

        PcepAutoParameters(:obj:`BgpRouter`): : PCEP LSP Auto Parameters对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Auto Tx Parameters对象名称, 类型为：string

        Enable (bool): PCEP Auto Tx Parameters对象, 类型为：bool, 取值范围：True或False, 默认值：True

        ObjectCategory (str): 选择对象类别, 类型为：string, 默认值：LSP, 取值范围：

            BANDWIDTH

            RP

            NO_PATH

            ENDPOINT

            METRIC

            ERO

            RRO

            LSPA

            SRP

            LSP

            XRO

        SelectObjectHandle (str): 选择对象, 类型为：string, 默认值：""

    Returns:

        (:obj:`PcepAutoTxParametersConfig`): Pcep Lsp Auto Tx Parameters对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Pce Auto Update Parameters | PcepLsp=${Egress} |
            | ${LspAutoTx} | Create Pcep Lsp Auto Tx Parameters | PcepAutoParameters=${Parameter} |
    """

    result = renix.pcep_auto_tx_parameters_config(PcepAutoParametersConfigs=PcepAutoParameters, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_bw_object(PcepLsps, **kwargs):
    """
    创建PCEP Bw Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Bw Object对象名称, 类型为：string

        Enable (bool): PCEP Bw Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

        Bandwidth (str): 类型为：string, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`PcepBwObjectConfig`): Pcep Bw Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Bw Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_bw_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_endpoint_object(PcepLsps, **kwargs):
    """
    创建PCEP Endpoint Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Endpoint Object对象名称, 类型为：string

        Enable (bool): PCEP Endpoint Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepEndPointObjectConfig`): Pcep Endpoint Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Endpoint Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_end_point_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_lspa_object(PcepLsps, **kwargs):
    """
    创建PCEP Lspa Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Lspa Object对象名称, 类型为：string

        Enable (bool): PCEP Lspa Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

        SetupPriority (int): 指定TE LSA抢占资源的优先级。类型为：number, 取值范围：0-7, 默认值：0

        HoldingPriority (int): 指定TE LSA持有资源的优先级。类型为：number, 取值范围：0-7, 默认值：0

        LFlag (bool): LSPA L Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

        Affinities (bool): 选中则对32位掩码和链接属性进行比较，设置包含链接条件和排除链接条件, 类型为：bool, 取值范围：True或False, 默认值：False

        ExcludeAny (int): Affinities选中时启用, 排除与32位掩码中任何属性匹配的链接, 类型为：number, 取值范围：0-4294967295, 默认值：0

        IncludeAny (int): Affinities选中时启用, 包含与32位掩码中任何属性匹配的链接, 类型为：number, 取值范围：0-4294967295, 默认值：0

        IncludeAll (int): Affinities选中时启用, 包含与32位掩码中全部属性匹配的链接, 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`PcepLspaObjectConfig`): Pcep Lspa Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Lspa Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_lspa_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_metric_list(PcepLsps, **kwargs):
    """
    创建PCEP Metric List对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Metric List对象名称, 类型为：string

        Enable (bool): PCEP Metric List对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepMetricListConfig`): Pcep Metric List对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Metric List | PcepLsp=${Egress} |
    """

    result = renix.pcep_metric_list_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_metric_object(PcepMetricLists, **kwargs):
    """
    创建PCEP Metric Object对象

    Args:

        PcepMetricLists(:obj:`BgpRouter`): : PCEP Metric List对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Metric Object对象, 类型为：string

        Enable (bool): PCEP Metric Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        BoundFlag (bool): PCReq消息中METRIC Object的B(Bound)位是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

        ComputedFlag (bool): PCReq消息中METRIC Object的C(Computed Metric)位是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

        MetricType (str): 指定度量值类型, 类型为：string, 默认值：MAX_SID_DEPTH, 取值范围:

            IGP_METRIC

            TE_METRIC

            HOP_COUNTS

            MAX_SID_DEPTH

        MetricValue (int): 指定最大度量值, 类型为：number, 取值范围：0-4294967295, 默认值：10

    Returns:

        (:obj:`PcepMetricObjectConfig`): Pcep Metric Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Metric List | PcepLsp=${Egress} |
            | ${Subobject} | Create Pcep Metric Object | PcepMetricLists=${Object} |
    """

    result = renix.pcep_metric_object_config(PcepMetricLists=PcepMetricLists, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_no_path_reason(PcepLsps, **kwargs):
    """
    创建PCEP No Path Reason对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCE LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP No Path Object对象名称, 类型为：string

        Enable (bool): PCEP No Path Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        NoPathType (str): No-Path类型, 类型为：string, 默认值：NOT_SATISFYING_CONSTRAINTS, 取值范围:

            NOT_SATISFYING_CONSTRAINTS

            PCE_CHAIN_BROKEN

        CFlag (bool): C Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

        NoPathReason (str): No-Path原因, 类型为：string, 默认值：NONTBIT, 取值范围:

            NONTBIT

            PCE_UNAVAILABLE

            UNKNOWN_DESTINATION

            UNKNOWN_SOURCE

    Returns:

        (:obj:`PcepNoPathObjectConfig`): Pcep No Path Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep No Path Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_no_path_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_rp_object(PcepLsps, **kwargs):
    """
    创建PCEP PCC Rp Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCC LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP PCC Rp Object对象名称, 类型为：string

        Enable (bool): PCEP PCC Rp Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        AutoGeneratedId (bool): 自动生成RP-ID 类型为：bool, 取值范围：True或False, 默认值：True

        RpId (int): 指定起始RP-ID, Auto-Generated RP-ID未选中时启用, 类型为：number, 取值范围：0-4294967295, 默认值：1

        RpIdStep (int): 指定PLSP-ID的跳变步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        Priority (int): 指定请求的优先级。数字越大，优先级越高, 类型为：number, 取值范围：0-7, 默认值：0

        PFlag (bool): PCReq消息中P Flag置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCRep消息中I Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        BFlag (bool): RP Object的B(Bi-directional)位置位, 类型为：bool, 取值范围：True或False, 默认值：False

        OFlag (bool): RP Object的O(strict/loose)位置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepRpObjectConfig`): Pcep Pcc Rp Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${Parameter} | Create Pcep Rp Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_rp_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_sr_ero_object(PcepLsps, **kwargs):
    """
    创建PCEP Sr Ero Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Sr Ero Object对象名称, 类型为：string

        Enable (bool): PCEP Sr Ero Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepSrEroObjectConfig`): Pcep Metric List对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Sr Ero Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_sr_ero_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_sr_ero_sub_object(PcepSrEroObjects, **kwargs):
    """
    创建PCEP Sr Ero Sub Object对象

    Args:

        PcepSrEroObjects(:obj:`PcepSrEroObjectConfig`): : PCEP PCE LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Sr Ero Sub Object对象名称, 类型为：string

        Enable (bool): PCEP Sr Ero Sub Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        RouteType (str): PCReq消息中P Flag是否置位, 类型为：string, 默认值：STRICT, 取值范围:

            STRICT

            LOOSE

        NaiType (str): PCReq消息中I Flag是否置位, 类型为：string, 默认值：IPV4_NODE_ID, 取值范围:

            ABSENT

            IPV4_NODE_ID

            IPV6_NODE_ID

            IPV4_ADJACENCY

            IPV6_ADJACENCY_GLOBAL

            UNNUMBERED_ADJACENCY

            IPV6_ADJACENCY_LINK_LOCAL

        MFlag (bool): M Flag, 类型为：bool, 取值范围：True或False, 默认值：True

        CFlag (bool): C Flag, 类型为：bool, 取值范围：True或False, 默认值：False

        SFlag (bool): 类型为：bool, 取值范围：True或False, 默认值：False

        FFlag (bool): F Flag, 类型为：bool, 取值范围：True或False, 默认值：False

        SidLabel (int): SID Label, 类型为：number, 取值范围：0-1048575, 默认值：16

        SidLabelStep (int): SID Label跳变, 类型为：number, 取值范围：0-1048575, 默认值：0

        SidLabelSessionOffset (int): SID Label接口间跳变, 类型为：number, 取值范围：0-1048575, 默认值：0

        SidIndex (int): SID Index（32 Bits）, 类型为：number, 取值范围：0-4294967295, 默认值：1

        SidIndexStep (int): SID Index跳变（32 Bits）, 类型为：number, 取值范围：0-4294967295, 默认值：0

        SidIndexSessionOffset (int): SID Index接口间跳变（32 Bits）, 类型为：number, 取值范围：0-1048575, 默认值：0

        SidTrafficClass (int): SID Traffic Class（3 bits）, 类型为：number, 取值范围：0-7, 默认值：0

        SidTimeToLive (int): SID Time To Liv, 类型为：number, 取值范围：0-255, 默认值：255

        SidBottomOfStack (bool): SID Bottom Of Stack Flag（1 Bit）, 类型为：bool, 取值范围：True或False, 默认值：False

        NaiIpv4NodeId (str): NAI IPv4 Node ID, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        NaiIpv6NodeId (str): NAI IPv6 Node ID, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiLocalIpv4Address (str): NAI Local IPv4 Address, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        NaiLocalIpv6Address (str): NAI Local IPv6 Address, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiRemoteIpv4Address (str): NAI Remote IPv4 Address, 类型为：string, 默认值：193.85.1.1, 取值范围: IPv4地址

        NaiRemoteIpv6Address (str): NAI Remote IPv6 Address, 类型为：string, 默认值：2001::1, 取值范围: IPv6地址

        NaiLocalNodeId (str): NAI Local Node-ID, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        NaiLocalInterfaceId (int): NAI Local Interface ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        NaiRemoteNodeId (str): NAI Remote Node-ID, 类型为：string, 默认值：193.85.1.1, 取值范围: IPv4地址

        NaiRemoteInterfaceId (int): NAI Remote Interface ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`PcepSrEroSubObjectConfig`): Pcep Sr Ero Sub Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Sr Ero Object | PcepLsp=${Egress} |
            | ${Subobject} | Create Pcep Sr Ero Sub Object | PcepSrEroObjects=${Object} |
    """

    result = renix.pcep_sr_ero_sub_object_config(PcepSrEroObjects=PcepSrEroObjects, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_srp_info(PcepLsps, **kwargs):
    """
    创建PCEP Srp Info对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCE LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Srp Info对象名称, 类型为：string

        Enable (bool): PCEP Srp Info对象, 类型为：bool, 取值范围：True或False, 默认值：True

        AutoGeneratedId (bool): 自动生成SRP-ID, 类型为：bool, 取值范围：True或False, 默认值：True

        SrpId (int): 指定起始SRP-ID, 类型为：number, 取值范围：0-4294967295, 默认值：1

        SrpIdStep (int): 指定SRP-ID的跳变步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

    Returns:

        (:obj:`PcepSrpObjectConfig`): Pcep Srp Info对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Srp Info | PcepLsp=${Egress} |
    """

    result = renix.pcep_srp_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_sr_rro_object(PcepLsps, **kwargs):
    """
    创建PCEP Sr Rro Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCC LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Sr Ero Object对象名称, 类型为：string

        Enable (bool): PCEP Sr Ero Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepSrRroObjectConfig`): Pcep Metric List对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Sr Rro Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_sr_rro_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_sr_rro_sub_object(PcepSrRroObjects, **kwargs):
    """
    创建PCEP Sr Rro Sub Object对象

    Args:

        PcepLsps(:obj:`PcepSrRroObjectConfig`): : PCEP PCE Sr Rro对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Sr Rro Sub Object对象名称, 类型为：string

        Enable (bool): PCEP Sr Rro Sub Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        NaiType (str): 子对象中NT字段的值, 类型为：string, 默认值：IPV4_NODE_ID, 取值范围:

            ABSENT

            IPV4_NODE_ID

            IPV6_NODE_ID

            IPV4_ADJACENCY

            IPV6_ADJACENCY_GLOBAL

            UNNUMBERED_ADJACENCY

            IPV6_ADJACENCY_LINK_LOCAL

        MFlag (bool): 子对象中的M Flag置位, 类型为：bool, 取值范围：True或False, 默认值：True

        CFlag (bool): 子对象中的C Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        SFlag (bool): 子对象中的S Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        FFlag (bool): 子对象中的F Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        SidIndex (int): 指定起始SID Index, 类型为：number, 取值范围：0-1048575, 默认值：1

        SidLabel (int): 指定起始SID Label, 类型为：number, 取值范围：0-1048575, 默认值：16

        SidTrafficClass (int): 指定流量类型字段的值, 类型为：number, 取值范围：0-7, 默认值：0

        SidTimeToLive (int): 指定TTL字段值, 类型为：number, 取值范围：0-255, 默认值：255

        SidBottomOfStack (bool): 是否指定的SID Label为标签栈的栈底标签, 类型为：bool, 取值范围：True或False, 默认值：False

        NaiIpv4NodeId (str): 指定NAI IPv4节点ID, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        NaiIpv6NodeId (str): 指定NAI IPv6节点ID, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiLocalIpv4Address (str): 指定NAI本地IPv4地址, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        NaiLocalIpv6Address (str): 指定NAI本地IPv6地址, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiRemoteIpv4Address (str): 指定NAI远端IPv4地址, 类型为：string, 默认值：193.85.1.1, 取值范围: IPv4地址

        NaiRemoteIpv6Address (str): 指定NAI远端IPv6地址, 类型为：string, 默认值：2001::1, 取值范围: IPv6地址

        NaiLocalNodeId (str): 指定NAI远端节点ID, 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        NaiLocalInterfaceId (int): 指定NAI本地接口ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        NaiRemoteNodeId (str): 指定NAI远端节点ID, 类型为：string, 默认值：193.85.1.1, 取值范围: IPv4地址

        NaiRemoteInterfaceId (int): 指定NAI远端接口ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`PcepSrRroSubObjectConfig`): Pcep Sr Ero Sub Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Sr Rro Object | PcepLsp=${Egress} |
            | ${Subobject} | Create Pcep Sr Rro Sub Object | PcepSrRroObjects=${Object} |
    """

    result = renix.pcep_sr_rro_sub_object_config(PcepSrRroObjects=PcepSrRroObjects, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_srv6_ero_object(PcepLsps, **kwargs):
    """
    创建PCEP Srv6 Ero Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Srv6 Ero Object对象名称, 类型为：string

        Enable (bool): PCEP Srv6 Ero Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepSrv6EroObjectConfig`): Pcep Srv6 Ero Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Srv6 Ero Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_srv6_ero_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_srv6_ero_sub_object(PcepSrv6EroObjects, **kwargs):
    """
    创建PCEP Srv6 Ero Sub Object对象

    Args:

        PcepSrv6EroObjects(:obj:`PcepSrv6EroObjectConfig`): : PCEP Srv6 Ero对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Srv6 Ero Sub Object对象名称, 类型为：string

        Enable (bool): PCEP Srv6 Ero Sub Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        RouteType (str): 建立LSP使用的路由类型, 类型为：string, 默认值：STRICT, 取值范围:

            STRICT

            LOOSE

        NaiType (str): 指定端点行为, 类型为：string, 默认值：IPV6_NODE_ID, 取值范围:

            ABSENT

            IPV4_NODE_ID

            IPV6_NODE_ID

            IPV4_ADJACENCY

            IPV6_ADJACENCY_GLOBAL

            UNNUMBERED_ADJACENCY

            IPV6_ADJACENCY_LINK_LOCAL

        SFlag (bool): 子对象中的S Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        FFlag (bool): 子对象中的F Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        EndpointBehavior (str): 指定端点行为, 类型为：string, 默认值：Invalid, 取值范围:

            Invalid

            EndNoPspUsp

            EndPsp

            EndUsp

            EndPspUsp

            EndXNoPspUsp

            EndXPsp

            EndXUsp

            EndXPspUsp

            EndTNoPspUsp

            EndTPsp

            EndTUsp

            EndTPspUsp

            EndB6Encaps

            EndBM

            EndDX6

            EndDX4

            EndDT6

            EndDT4

            EndDT46

            EndDX2

            EndDX2V

            EndDT2U

            EndDT2M

            ENDB6EncapsRed

            EndUSD

            EndPSPUSD

            EndUSPUSD

            EndPSPUSPUSD

            EndXUSD

            EndXPSPUSD

            EndXUSPUSD

            EndXPSPUSPUSD

            EndTUSD

            EndTPSPUSD

            EndTUSPUSD

            EndTPSPUSPUSD

        SRv6Sid (str): 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiIpv6NodeId (str): 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiLocalIpv6Address (str): 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiRemoteIpv6Address (str): 类型为：string, 默认值：2001::1, 取值范围: IPv6地址

        NaiLocalInterfaceId (int): 类型为：number, 取值范围：0-4294967295, 默认值：0

        NaiRemoteInterfaceId (int): 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`PcepSrv6EroSubObjectConfig`): Pcep Srv6 Ero Sub Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Srv6 Ero Object | PcepLsp=${Egress} |
            | ${Subobject} | Create Pcep Srv6 Ero Sub Object | PcepSrEroObjects=${Object} |
    """

    result = renix.pcep_srv6_ero_sub_object_config(PcepSrv6EroObjects=PcepSrv6EroObjects, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_srv6_rro_object(PcepLsps, **kwargs):
    """
    创建PCEP Srv6 Rro Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP PCC LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Srv6 Rro Object对象名称, 类型为：string

        Enable (bool): PCEP Srv6 Rro Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepSrv6RroObjectConfig`): Pcep Srv6 Rro Onject对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Srv6 Rro Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_srv6_rro_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_srv6_rro_sub_object(PcepSrv6RroObjects, **kwargs):
    """
    创建PCEP Srv6 Rro Sub Object对象

    Args:

        PcepSrv6RroObjects(:obj:`PcepSrv6RroObjectConfig`): : PCEP Srv6 Rro对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Srv6 Rro Sub Object对象名称, 类型为：string

        Enable (bool): PCEP Srv6 Rro Sub Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        NaiType (str): 子对象中NT字段的值, 类型为：string, 默认值：IPV6_NODE_ID, 取值范围:

            ABSENT

            IPV4_NODE_ID

            IPV6_NODE_ID

            IPV4_ADJACENCY

            IPV6_ADJACENCY_GLOBAL

            UNNUMBERED_ADJACENCY

            IPV6_ADJACENCY_LINK_LOCAL

        SFlag (bool): 子对象中的S Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        FFlag (bool): 子对象中的F Flag置位, 类型为：bool, 取值范围：True或False, 默认值：False

        EndpointBehavior (str): 指定端点行为, 类型为：string, 默认值：Invalid, 取值范围:

            Invalid

            EndNoPspUsp

            EndPsp

            EndUsp

            EndPspUsp

            EndXNoPspUsp

            EndXPsp

            EndXUsp

            EndXPspUsp

            EndTNoPspUsp

            EndTPsp

            EndTUsp

            EndTPspUsp

            EndB6Encaps

            EndBM

            EndDX6

            EndDX4

            EndDT6

            EndDT4

            EndDT46

            EndDX2

            EndDX2V

            EndDT2U

            EndDT2M

            ENDB6EncapsRed

            EndUSD

            EndPSPUSD

            EndUSPUSD

            EndPSPUSPUSD

            EndXUSD

            EndXPSPUSD

            EndXUSPUSD

            EndXPSPUSPUSD

            EndTUSD

            EndTPSPUSD

            EndTUSPUSD

            EndTPSPUSPUSD

        SRv6Sid (str): 指定SRv6 SID, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiIpv6NodeId (str): 指定NAI IPv6节点ID, 指定NAI IPv6节点ID, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiLocalIpv6Address (str): 指定NAI本地IPv6地址, 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        NaiRemoteIpv6Address (str): 指定NAI远端IPv6地址, 类型为：string, 默认值：2001::1, 取值范围: IPv6地址

        NaiLocalInterfaceId (int): 指定NAI本地接口ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

        NaiRemoteInterfaceId (int): 指定NAI远端接口ID, 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`PcepSrv6RroSubObjectConfig`): Pcep Srv6 Rro Sub Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pcc Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Srv6 Rro Object | PcepLsp=${Egress} |
            | ${Subobject} | Create Pcep Srv6 Rro Sub Object | PcepSrv6RroObjects=${Object} |
    """

    result = renix.pcep_srv6_rro_sub_object_config(PcepSrv6RroObjects=PcepSrv6RroObjects, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_xro_object(PcepLsps, **kwargs):
    """
    创建PCEP XRO Object对象

    Args:

        PcepLsps(:obj:`PccLspConfig`): : PCEP LSP对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP XRO Object对象名称, 类型为：string

        Enable (bool): PCEP XRO Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        PFlag (bool): PCReq消息中P Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：True

        IFlag (bool): PCReq消息中I Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

        FFlag (bool): PCReq消息中F Flag是否置位, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`PcepXroObjectConfig`): Pcep XRO Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep XRO Object | PcepLsp=${Egress} |
    """

    result = renix.pcep_xro_object_config(PcepLsps=PcepLsps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pcep_xro_sub_object(PcepXroObjects, **kwargs):
    """
    创建PCEP XRO Object对象

    Args:

        PcepXroObjects(:obj:`PcepXroObjectConfig`): : PCEP XRO Object对象列表, 类型为：object / list

    Keyword Args:

        Name (str): PCEP Xro Sub Object对象名称, 类型为：string

        Enable (bool): PCEP Xro Sub Object对象, 类型为：bool, 取值范围：True或False, 默认值：True

        XFlag (bool): 类型为：bool, 取值范围：True或False, 默认值：False

        Type (str): 类型为：string, 默认值：IPv4_PREFIX, 取值范围:

            IPv4_PREFIX

            IPv6_PREFIX

            UNNUMBERED_INTERFACE_ID

            AUTONOMOUS_SYS_NUM

            SRLG

        PrefixLength (int): 类型为：number, 取值范围：0-32, 默认值：24

        Attribute (str): 类型为：string, 默认值：INTERFACE, 取值范围:

            INTERFACE

            NODE

            SRLG

        Ipv4Address (str): 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        Ipv6Address (str): 类型为：string, 默认值：2000::1, 取值范围: IPv6地址

        TeRouterId (str): 类型为：string, 默认值：192.85.1.1, 取值范围: IPv4地址

        InterfaceId (int): 类型为：number, 默认值：0

        AsNumber (int): 类型为：number, 默认值：0

        SrlgId (int): 类型为：number, 默认值：0

    Returns:

        (:obj:`PcepXroSubObjectConfig`): Pcep Xro Sub Object对象列表, 类型: object / list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pcep | Port=${Port} |
            | Edit Pcep | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Pcep Pce Lsp | Sessions=${Session} |
            | ${Object} | Create Pcep Xro Object | PcepLsp=${Egress} |
            | ${Subobject} | Create Pcep Xro Sub Object | PcepXroObjects=${Object} |
    """

    result = renix.pcep_xro_sub_object_config(PcepXroObjects=PcepXroObjects, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_pcep_state(Sessions, State='UP', Interval=1, TimeOut=60):
    """
    等待PCEP协议会话达到指定状态

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        State (list): 等待PCEP协议会话达到的状态, 类型为：string, 默认值：达到UP, 支持下列状态：

            DISABLED

            IDLE

            PENDING

            UP

            CLOSING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Pcep State | Sessions=${Sessions} | State=UP | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_pcep_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_establish(Sessions):
    """
    建立PCEP会话

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Establish | Sessions=${Sessions} |
    """

    result = renix.pcep_establish(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_stop_keep_alive(Sessions):
    """
    指定PCEP会话暂停发送Keepalive报文

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Stop Keep Alive | Sessions=${Sessions} |
    """

    result = renix.pcep_stop_keep_alive(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_resume_keep_alive(Sessions):
    """
    指定PCEP会话恢复发送Keepalive报文

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Resume Keep Alive | Sessions=${Sessions} |
    """

    result = renix.pcep_resume_keep_alive(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_initial_sync(Sessions, Lsps=None):
    """
    PCC向PCE发送初始状态同步报文

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`BgpRouter`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc Initial Sync | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_initial_sync(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_end_sync(Sessions, Lsps=None):
    """
    停止PCC向PCE发送初始状态同步报文

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`BgpRouter`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc End Sync | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_end_sync(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_delegate_lsp(Sessions, Lsps=None):
    """
    PCC向PCE发送托管LSP请求

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`BgpRouter`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc Delegate Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_delegate_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_revoke_lsp(Sessions, Lsps=None):
    """
    PCC向PCE发送取消托管LSP请求

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`BgpRouter`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc Revoke Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_revoke_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_remove_delegate_lsp(Sessions, Lsps=None):
    """
    PCC向PCE发送删除托管LSP请求

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`BgpRouter`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc Remove Delegate Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_remove_delegated_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_request_lsp(Sessions, Lsps=None):
    """
    PCC向PCE发送路径计算请求

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`PccLspConfig`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc Request Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_request_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_report_lsp(Sessions, Lsps=None):
    """
    PCC向PCE报告LSP状态

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`PccLspConfig`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc Report Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_report_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pcc_synchronize_lsp(Sessions, Lsps=None):
    """
    PCC向PCE报告LSP状态

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`PccLspConfig`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pcc Synchronize Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pcc_synchronize_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pce_return_lsp(Sessions, Lsps=None):
    """
    使Stateful PCE向PCC归还LSP托管权限

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`PccLspConfig`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pce Return Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pce_return_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pce_update_lsp(Sessions, Lsps=None):
    """
    使Stateful PCE向PCC发送更新LSP请求

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`PccLspConfig`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pce Update Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pce_update_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pce_initiate_lsp(Sessions, Lsps=None):
    """
    PCE向PCC发送初始化LSP请求

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`PccLspConfig`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pce Initiate Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pce_initiate_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pcep_pce_remove_initiated_lsp(Sessions, Lsps=None):
    """
    PCE向PCC发送删除指定LSP请求

    Args:

        Sessions(:obj:`Pcep`): : PCEP协议会话对象列表, 类型为：list

        Lsps(:obj:`PccLspConfig`): : PCEP Lsp对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pcep Pce Remove Initiate Lsp | Sessions=${Sessions} | Lsps=&{Lsps} |
    """

    result = renix.pce_remove_initiated_lsp(Sessions=Sessions, Lsps=Lsps)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pcep_lsp_statistic(Session=None, SessionId=1, Lsp=None, LspId=1, StaItems: list = None):
    """
    获取PCEP LSP统计结果

    Args:

        Session(:obj:`Pcep`): : PCEP协议会话对象, 类型为：Object

        SessionId (int): PCEP协议会话ID, 类型为：Number

        Lsp(:obj:`PccLspConfig`): : LSP对象, 类型为：Object

        LspId (int): LSP对象ID, 类型为：Number

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionBlockId

            LspIdentify

            SessionIndex

            LspIndex

            SessionLocalIP

            SessionPeerIP

            Role

            SymbolicName

            LspSourceIP

            LspDestinationIP

            LspState

            PLSPId

            LSPId

            SRPId

            RPId

    Returns:

        dict: eg::

            {
                'PLSPId': 1,
                'LSPId': 1,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=PcepLspStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pcep Lsp Statistic | Session=@{Session} | SessionId=1 | Lsp=@{Lsp} | LspId=1 | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pcep_lsp_statistic(Session=Session, SessionId=SessionId, Lsp=Lsp, LspId=LspId,
                                             StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pcep_lsp_block_statistic(Session=None, SessionId=1, Lsp=None, StaItems: list = None):
    """
    获取PCEP LSP BLOCK统计结果

    Args:

        Session(:obj:`Pcep`): : PCEP协议会话对象, 类型为：Object

        SessionId (int): PCEP协议会话ID, 类型为：Number

        Lsp(:obj:`PccLspConfig`): : LSP对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionBlockId

            LspIdentify

            SessionIndex

            SessionLocalIP

            SessionPeerIP

            Role

            LspCount

            RequestedLsps

            RepliedLsps

            DelegatedLsps

            UpdatedLsps

            RevokedLsps

            ReturnedLsps

            InitiatedLsps

            StateDownLsps

            StateUpLsps

            StateActiveLsps

            StateGoingDownLsps

            StateGoingUpLsps

            StateOtherLsps

    Returns:

        dict: eg::

            {
                'LspCount': 1,
                'RequestedLsps': 0,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=PcepLspBlockStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pcep Lsp Block Statistic | Session=@{Session} | SessionId=1 | Lsp=@{Lsp} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pcep_lsp_block_statistic(Session=Session, SessionId=SessionId, Lsp=Lsp, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pcep_port_statistic(Port=None, StaItems: list = None):
    """
    获取PCEP Port统计结果

    Args:

        Port (:obj:`Port`): PCEP协议会话所在的端口对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionBlockCount

            SessionBlockIdleCount

            SessionBlockPendingCount

            SessionBlockUpCount

    Returns:

        dict: eg::

            {
                'SessionBlockCount': 1,
                'SessionBlockIdleCount': 0,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=PcepPortStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pcep Port Statistic | Port=@{Port} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pcep_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pcep_session_statistic(Session=None, SessionId=1, StaItems: list = None):
    """
    获取PCEP session统计结果

    Args:

        Session(:obj:`Pcep`): : PCEP协议会话对象, 类型为：Object

        SessionId (int): PCEP协议会话ID, 类型为：Number

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            Role

            LocalIP

            PeerIP

            State

            LspCount

            StateDownLsps

            StateUpLsps

            StateActiveLsps

            StateGoingDownLsps

            StateGoingUpLsps

            StateOtherLsps

            TxOpenCount

            RxOpenCount

            TxKeepaliveCount

            RxKeepaliveCount

            TxReportCount

            RxReportCount

            TxUpdateCount

            RxUpdateCount

            TxRequestCount

            RxRequestCount

            TxReplyCount

            RxReplyCount

            TxInitiateCount

            RxInitiateCount

            TxCloseCount

            RxCloseCount

            TxErrorCount

            RxErrorCount

    Returns:

        dict: eg::

            {
                'TxErrorCount': 1,
                'RxErrorCount': 0,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=PcepSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pcep Session Statistic | Session=@{Session} | SessionId=@{SessionId} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pcep_session_statistic(Session=Session, SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pcep_session_block_statistic(Session=None, StaItems: list = None):
    """
    获取PCEP session block统计结果

    Args:

        Session(:obj:`Pcep`): : PCEP协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionBlockId

            SessionCount

            IdleCount

            PendingCount

            UpCount

            LspCount

            StateDownLsps

            StateUpLsps

            StateActiveLsps

            StateGoingDownLsps

            StateGoingUpLsps

            StateOtherLsps

            TxOpenCount

            RxOpenCount

            TxKeepaliveCount

            RxKeepaliveCount

            TxReportCount

            RxReportCount

            TxUpdateCount

            RxUpdateCount

            TxRequestCount

            RxRequestCount

            TxReplyCount

            RxReplyCount

            TxInitiateCount

            RxInitiateCount

            TxCloseCount

            RxCloseCount

            TxErrorCount

            RxErrorCount

    Returns:

        dict: eg::

            {
                'TxErrorCount': 1,
                'RxErrorCount': 0,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=PcepSessionBlockStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pcep Session Block Statistic | Session=@{Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pcep_session_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_pcep_port_config(Ports, **kwargs):
    """
    修改PCEP端口配置对象

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        MaxOutstanding (int): 最大会话负载数量, 取值范围：1-65535, 默认值：100

        RetryCount (int): 会话尝试建立次数, 取值范围：0-65535, 默认值：5

        RetryInterval (int): 会话尝试建立间隔（sec）, 取值范围：0-65535, 默认值：30

        MaxLspPerMessage (int): 消息中LSP的最大个数, 取值范围：1-2000, 默认值：100

    Returns:

        (:obj:`PCEPPortRateConfig`): PCEP Client Custom Options对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit PCEP Client Port Config | Ports=${Port} | TcpServerPort=10 |
    """

    result = renix.edit_pcep_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
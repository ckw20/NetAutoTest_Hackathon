import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------saa-------------------------------------
def create_saa(Port, **kwargs):
    """
    创建Saa协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Mode (str): 模式, 默认值：RouterHost, 取值范围：

            RouterRA

            RouterHost

        Flags (list): 标志位, 默认值：NONEBIT, 取值范围：

            NONEBIT

            MBIT

            OBIT

        RouterLifetime (int): 路由器生命周期, 默认值：1800, 取值范围：0-65535

        EnableDAD (bool): 使能重复地址检测, 默认值：False, 取值范围：

            True

            False

        DADTransmitCount (int): 重复地址检测发送次数, 默认值：1, 取值范围：1-255

        DADRetransmitDelay (int): 重复地址检测重传时延, 默认值：1000, 取值范围：1000-4294967295

        RouterSolicitationRetries (int): 路由Solicitation重传次数, 默认值：2, 取值范围：0-4294967295

        RouterSolicitationRetransmitDelay (int): 路由Solicitation重传时延, 默认值：3000, 取值范围：1000-4294967295

        EnableEui64LinkLocal (bool): 使能EUI-64 Link Local, 默认值：True, 取值范围：

            True

            False

        EnableSendRA (bool): 使能发布RA报文, 默认值：False, 取值范围：

            True

            False

        MaxInterval (int): 最大发布时间间隔（秒）, 默认值：600, 取值范围：2-1350

        MinInterval (int): 最小发布时间间隔（秒）, 默认值：200, 取值范围：1-1800

        Ipv6EnableGatewayLearn (bool): Ipv6使能网关地址学习, 默认值：False, 取值范围：

            True

            False

        DefaultNoAdvertise (bool): 不携带前缀信息, 默认值：False, 取值范围：

            True

            False

    Returns:

        (:obj:`Saa`): Saa协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Saa | Port=${Port} | DADTransmitCount=255 |
    """

    result = renix.create_saa(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_saa_state(Sessions, State='IDLE', Interval=1, TimeOut=60):
    """
    等待Saa协议会话达到指定状态

    Args:

        Sessions(:obj:`Saa`): Saa协议会话对象列表, 类型为：list

        State (list): 等待RIP协议会话达到的状态, 默认值：达到IDLE, 支持下列状态：

            DISABLED

            IDLE

            ESTABLISHING

            BOUND

            RUNNING

        Interval (int): 查询协议会话的间隔, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Saa State | Sessions=${Sessions} | State=BOUND | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_saa_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_saa_port_config(Ports, **kwargs):
    """
    修改Saa端口配置

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        RequestRate (int): Request Rate (sessions/sec), 默认值：100, 取值范围：0-10000

        MaxOutstanding (int): Max Outstanding Session, 默认值：1000, 取值范围：0-65535

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Saa Port Config | Ports=${Ports} | RequestRate=1000 |
    """

    result = renix.edit_saa_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_saa_port_statistic(Port=None, StaItems: list = None):
    """
    获取Saa port统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            CurrentlyAttempting

            CurrentlyIdle

            CurrentlyBound

            TxNeighborSolicitation

            RxNeighborSolicitation

            TxNeighborAdvertisement

            RxNeighborAdvertisement

            TxRouterSolicitation

            RxRouterSolicitation

            TxRouterAdvertisement

            RxRouterAdvertisement

            SuccessPercentage

            TotalAttempted

            TotalBound

            TotalDADFailed

            TotalRATimeoutFailed

            TotalFailed

    Returns:

        dict: eg::

            {
                'TotalAttempted': 10,
                'TotalBound': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Saa Port Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_saa_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_saa_session_block_statistic(Session=None, StaItems: list = None):
    """
    获取Saa协议会话统计结果

    Args:

        Session(:obj:`Saa`): Saa协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            BindingState

            BlockSessionState

            CurrentlyAttempting

            CurrentlyIdle

            CurrentlyBound

            AttemptRate

            BindRate

            TxNeighborSolicitation

            RxNeighborSolicitation

            TxNeighborAdvertisement

            RxNeighborAdvertisement

            TxRouterSolicitation

            RxRouterSolicitation

            TxRouterAdvertisement

            RxRouterAdvertisement

            TotalAttempted

            TotalBound

            TotalDADFailed

            TotalRATimeoutFailed

            TotalFailed

    Returns:

        dict: eg::

            {
                'TotalAttempted': 10,
                'TotalBound': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Saa Session Block Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_saa_session_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_saa_session_statistic(Session=None, SessionId=1, StaItems=None):
    """
    获取Saa协议会话统计结果

    Args:

        Session (:obj:`Saa`): Saa协议会话对象, 类型为：Object

        SessionId (int): Session ID, 类型为：int

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionState

            MacAddress

            VlanId

            InnerVlanId

            GlobalIpv6Address

            LinkLocalIpv6Address

            PrefixIpv6Address

            PrefixLength

            ValidLifeTime

            PreferredLifeTime

    Returns:

        dict: eg::

            {
                'ValidLifeTime': 10,
                'PreferredLifeTime': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Saa Session Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_saa_session_statistic(Session=Session, Index=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

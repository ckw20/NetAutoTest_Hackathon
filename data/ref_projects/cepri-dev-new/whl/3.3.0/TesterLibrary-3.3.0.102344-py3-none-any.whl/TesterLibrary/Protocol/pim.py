import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------PIM-------------------------------------
def create_pim(Port, **kwargs):
    """
    创建PIM协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): PIM协会话名称, 类型为：string

        Enable (bool): 使能PIM协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        SessionMode (str): 协议模式, 类型为：string, 默认值：SM, 支持版本：

            SM

            SSM

        IpVersion (str): IP版本, 类型为：string, 默认值：IPV4, 支持版本：

            IPV4

            IPV6

        DrPriority (int): DR优先级, 类型为：number, 取值范围：1-65535, 默认值：1

        DrAddr (str): DR地址, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.0.0

        DrIpv6Addr (str): DR IPv6地址, 类型为：string, 取值范围：IPv6地址, 默认值：'::'

        GenIdMode (str): GenID模式, 类型为：string, 默认值：FIXED, 支持参数：

            FIXED

            INCR

            RAND

        RegisterEnable (bool): Register使能, 类型为：bool, 取值范围：True或False, 默认值：False

        BsrEnable (bool): BSR使能, 类型为：bool, 取值范围：True或False, 默认值：False

        BsrPriority (int): BSR优先级, 类型为：number, 取值范围：0-255, 默认值：1

        BsrInterval (int): BSR消息发送时间间隔（秒）, 类型为：number, 取值范围：1-3600, 默认值：60

        HelloInterval (int): Hello消息发送时间间隔（秒）, 类型为：number, 取值范围：1-3600, 默认值：30

        HelloHoldTime (int): Hello消息超时时间（秒）, 类型为：number, 取值范围：1-65535, 默认值：105

        JoinPruneInterval (int): Join/Prune消息发送时间间隔（秒）, 类型为：number, 取值范围：1-65535, 默认值：60

        JoinPruneHoldTime (int): Join/Prune消息超时时间（秒）, 类型为：number, 取值范围：1-65535, 默认值：210

    Returns:

        (:obj:`PimRouter`): PIM协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | ${DrAddr} | Set Variable | ${Session.DrAddr} |
    """

    result = renix.create_pim(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_pim(Session, **kwargs):
    """
    编辑PIM协议会话对象参数

    Args:

        Session (:obj:`PimRouter`): PIM协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): PIM协会话名称, 类型为：string

        Enable (bool): 使能PIM协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        SessionMode (str): 协议模式, 类型为：string, 默认值：SM, 支持版本：

            SM

            SSM

        IpVersion (str): IP版本, 类型为：string, 默认值：IPV4, 支持版本：

            IPV4

            IPV6

        DrPriority (int): DR优先级, 类型为：number, 取值范围：1-65535, 默认值：1

        DrAddr (str): DR地址, 类型为：string, 取值范围：IPv4地址, 默认值：0.0.0.0

        DrIpv6Addr (str): DR IPv6地址, 类型为：string, 取值范围：IPv6地址, 默认值：'::'

        GenIdMode (str): GenID模式, 类型为：string, 默认值：FIXED, 支持参数：

            FIXED

            INCR

            RAND

        RegisterEnable (bool): Register使能, 类型为：bool, 取值范围：True或False, 默认值：False

        BsrEnable (bool): BSR使能, 类型为：bool, 取值范围：True或False, 默认值：False

        BsrPriority (int): BSR优先级, 类型为：number, 取值范围：0-255, 默认值：1

        BsrInterval (int): BSR消息发送时间间隔（秒）, 类型为：number, 取值范围：1-3600, 默认值：60

        HelloInterval (int): Hello消息发送时间间隔（秒）, 类型为：number, 取值范围：1-3600, 默认值：30

        HelloHoldTime (int): Hello消息超时时间（秒）, 类型为：number, 取值范围：1-65535, 默认值：105

        JoinPruneInterval (int): Join/Prune消息发送时间间隔（秒）, 类型为：number, 取值范围：1-65535, 默认值：60

        JoinPruneHoldTime (int): Join/Prune消息超时时间（秒）, 类型为：number, 取值范围：1-65535, 默认值：210

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | Edit Pim | Session=${Session} | HelloInterval=60 |
    """

    result = renix.edit_pim(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pim_group(Session, **kwargs):
    """
    创建PIM Group对象

    Args:

        Session (:obj:`PimRouter`): PIM协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): PIM Group对象名称, 类型为：string

        Enable (bool): 使能PIM Group对象, 类型为：bool, 取值范围：True或False, 默认值：True

        GroupCheck (bool): 协议模式, 类型为：bool, 取值范围：True或False, 默认值：False

        GroupType (str): 组类别, 类型为：string, 默认值：ANY_G, 支持版本：

            ANY_G

            S_G

            S_G_RPT

            ANY_RP

        GroupAddr (str): 组地址, 类型为：string, 取值范围：IPv4地址, 默认值：225.0.0.1

        GroupCount (int): 组数目, 类型为：number, 取值范围：1-65535（BigTao） 1-500000（DarYu）, 默认值：1

        GroupModifierStep (int): 组地址增量步进, 类型为：number, 取值范围：0-65535, 默认值：1

        GroupModifierBit (int): 组地址增量位, 类型为：number, 取值范围：1-32, 默认值：32

        RpAddr (str): RP地址, 类型为：string, 取值范围：IPv4地址, 默认值：10.10.10.10

        JoinSrc (str): Join源地址, 类型为：string, 取值范围：IPv4地址, 默认值：1.1.1.1

        JoinMaskLen (int): Join掩码长度, 类型为：number, 取值范围：1-32, 默认值：32

        PruneSrcAddr: Prune源地址, 类型为：string, 取值范围：IPv4地址, 默认值：1.1.1.1

        PruneMaskLen (int): Prune掩码长度, 类型为：number, 取值范围：1-32, 默认值：32

    Returns:

        (:obj:`PimGroupConfig`): PIM Group对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | Create Pim Group | Session=${Session} | GroupAddr=255.0.0.2 |
    """

    result = renix.create_pim_group(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pim_ipv6_group(Session, **kwargs):
    """
    创建PIM IPv6 Group对象

    Args:

        Session (:obj:`PimRouter`): PIM协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): PIM IPv6 Group对象名称, 类型为：string

        Enable (bool): 使能PIM IPv6 Group对象, 类型为：bool, 取值范围：True或False, 默认值：True

        GroupCheck (bool): 协议模式, 类型为：bool, 取值范围：True或False, 默认值：False

        GroupType (str): 组类别, 类型为：string, 默认值：ANY_G, 支持版本：

            ANY_G

            S_G

            S_G_RPT

            ANY_RP

        GroupAddr (str): 组地址, 类型为：string, 取值范围：IPv6地址, 默认值：ff1e::1

        GroupCount (int): 组数目, 类型为：number, 取值范围：1-65535（BigTao） 1-500000（DarYu）, 默认值：1

        GroupModifierStep (int): 组地址增量步进, 类型为：number, 取值范围：0-65535, 默认值：1

        GroupModifierBit (int): 组地址增量位, 类型为：number, 取值范围：1-128, 默认值：128

        RpAddr (str): RP地址, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        JoinSrc (str): Join源地址, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        JoinMaskLen (int): Join掩码长度, 类型为：number, 取值范围：1-128, 默认值：64

        PruneSrcAddr (str): Prune源地址, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PruneMaskLen (int): Prune掩码长度, 类型为：number, 取值范围：1-128, 默认值：64

    Returns:

        (:obj:`PimIpv6GroupConfig`): PIM IPv6 Group对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | Create Pim IPv6 Group | Session=${Session} | GroupAddr=ff1e::2 |
    """

    result = renix.create_pim_ipv6_group(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pim_register_group(Session, **kwargs):
    """
    创建PIM IPv4 Register Group对象

    Args:

        Session (:obj:`PimRouter`): PIM协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): PIM IPv4 Register Group对象名称, 类型为：string

        Enable (bool): 使能PIM IPv4 Register Group对象, 类型为：bool, 取值范围：True或False, 默认值：True

        MulticastGroupToSourceDistribution (str): 组播地址和源地址映射方式, 类型为：string, 默认值：PAIR, 支持参数：

            PAIR

            BACKBONE

        RegisterTransmitMode (str): 注册发送模式, 类型为：string, 默认值：CONTINUOUS, 支持参数：

            FIXED

            CONTINUOUS

        FixedModeCount (int): 固定模式数量, 类型为：number, 取值范围：1-1000, 默认值：5

        MulticastGroupCount (int): 多播组数量, 类型为：number, 取值范围：1-65535, 默认值：1

        StartMulticastGroupAddr (str): 多播组起始地址, 类型为：string, 取值范围：IPv4地址, 默认值：225.0.1.1

        MulticastGroupStep (int): 多播组步长, 类型为：number, 取值范围：1-255, 默认值：1

        MulticastGroupPrefixLength (int): 多播组前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

        MulticastSourceCount (int): 组播源数量, 类型为：number, 取值范围：1-65535, 默认值：1

        StartMulticastSourceAddr (str): 多播组起始地址, 类型为：string, 取值范围：IPv4地址, 默认值：192.168.1.1

        MulticastSourceStep (int): 多播组步长, 类型为：number, 取值范围：1-255, 默认值：1

        MulticastSourcePrefixLength (int): 多播组前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

        RpAddr (str): RP地址, 类型为：string, 取值范围：IPv4地址, 默认值：10.10.10.20

        RegisterTransmitInterval (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：10-180, 默认值：60

    Returns:

        (:obj:`PimRegisterGroupConfig`): PIM IPv4 Register Group对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | Create Pim Register Group | Session=${Session} | RpAddr=20.10.10.20 |
    """

    result = renix.create_pim_register_group(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pim_ipv6_register_group(Session, **kwargs):
    """
    创建PIM IPv6 Register Group对象

    Args:

        Session (:obj:`PimRouter`): PIM协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): PIM IPv6 Register Group对象名称, 类型为：string

        Enable (bool): 使能PIM IPv6 Register Group对象, 类型为：bool, 取值范围：True或False, 默认值：True

        MulticastGroupToSourceDistribution (str): 组播地址和源地址映射方式, 类型为：string, 默认值：PAIR, 支持参数：

            PAIR

            BACKBONE

        RegisterTransmitMode (str): 注册发送模式, 类型为：string, 默认值：CONTINUOUS, 支持参数：

            FIXED

            CONTINUOUS

        FixedModeCount (int): 固定模式数量, 类型为：number, 取值范围：1-1000, 默认值：5

        MulticastGroupCount (int): 多播组数量, 类型为：number, 取值范围：1-65535, 默认值：1

        StartMulticastGroupAddr (str): 多播组起始地址, 类型为：string, 取值范围：IPv6地址, 默认值：ff1e::2

        MulticastGroupStep (int): 多播组步长, 类型为：number, 取值范围：1-255, 默认值：1

        MulticastGroupPrefixLength (int): 多播组前缀长度, 类型为：number, 取值范围：1-128, 默认值：64

        MulticastSourceCount (int): 组播源数量, 类型为：number, 取值范围：1-65535, 默认值：1

        StartMulticastSourceAddr (str): 多播组起始地址, 类型为：string, 取值范围：IPv6地址, 默认值：2001::1

        MulticastSourceStep (int): 多播组步长, 类型为：number, 取值范围：1-255, 默认值：1

        MulticastSourcePrefixLength (int): 多播组前缀长度, 类型为：number, 取值范围：1-128, 默认值：64

        RpAddr (str): RP地址, 类型为：string, 取值范围：IPv6地址, 默认值：2000::2

        RegisterTransmitInterval (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：10-180, 默认值：60

    Returns:

        (:obj:`PimIpv6RegisterGroupConfig`): Create Pim Ipv6 Register Group对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | Create Pim Ipv6 Register Group | Session=${Session} | RpAddr=3000::2 |
    """

    result = renix.create_pim_ipv6_register_group(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pim_rp_map(Session, **kwargs):
    """
    创建PIM IPv4 Rp Map对象

    Args:

        Session (:obj:`PimRouter`): PIM协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): PIM IPv4 Rp Map对象名称, 类型为：string

        Enable (bool): 使能PIM IPv4 Rp Map对象, 类型为：bool, 取值范围：True或False, 默认值：True

        MulticastGroupAddr (str): 组播地址和源地址映射方式, 类型为：string, 取值范围：IPv4地址, 默认值：255.0.0.1

        RpAddr (str): RP地址, 类型为：string, 取值范围：IPv4地址, 默认值：10.10.10.10

        PrefixLength (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：0-32, 默认值：32

        RpPriority (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：0-255, 默认值：0

        RpHoldTime (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：1-65535, 默认值：150

    Returns:

        (:obj:`PimIpv6RpMapConfig`): PIM IPv6 Rp Map对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | Create Pim IPv4 Rp Map | Session=${Session} | RpAddr=20.10.10.10 |
    """

    result = renix.create_pim_rp_map(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pim_ipv6_rp_map(Session, **kwargs):
    """
    创建PIM IPv6 Rp Map对象

    Args:

        Session (:obj:`PimRouter`): PIM协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): PIM IPv6 Rp Map对象名称, 类型为：string

        Enable (bool): 使能PIM IPv6 Rp Map对象, 类型为：bool, 取值范围：True或False, 默认值：True

        MulticastGroupAddr (str): 组播地址和源地址映射方式, 类型为：string, 取值范围：IPv6地址, 默认值：ff1e::1

        RpAddr (str): RP地址, 类型为：string, 取值范围：IPv6地址, 默认值：2000::1

        PrefixLength (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：0-128, 默认值：128

        RpPriority (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：0-255, 默认值：0

        RpHoldTime (int): Register发送时间间隔（秒）, 类型为：number, 取值范围：1-65535, 默认值：150

    Returns:

        (:obj:`PimIpv6RpMapConfig`): PIM IPv6 Rp Map对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Pim | Port=${Port} |
            | Create Pim Ipv6 Rp Map | Session=${Session} | RpAddr=3000::1 |
    """

    result = renix.create_pim_ipv6_rp_map(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_pim_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待PIM协议会话达到指定状态

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

        State (list): 等待PIM协议会话达到的状态, 类型为：string, 默认值：达到NEIGHBOR, 支持下列状态：

            DISABLED

            HELLO

            NEIGHBOR

            IDLE

            NOTSTARTED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Pim State | Sessions=${Sessions} | State=NEIGHBOR | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_pim_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def pim_start_boot_strap(Sessions):
    """
    启动PIM协议会话BootStrap

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Start Boot Strap | Sessions=${Sessions} |
    """

    result = renix.pim_start_boot_strap(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pim_stop_boot_strap(Sessions):
    """
    停止PIM协议会话BootStrap

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Stop Boot Strap | Sessions=${Sessions} |
    """

    result = renix.pim_stop_boot_strap(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def pim_change_gen_id(Sessions):
    """
    修改PIM协议会话的GenId

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Join Group | Sessions=${Sessions} |
    """

    result = renix.pim_change_gen_id(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result



def pim_join_group(Sessions):
    """
    PIM协议会话发送加入组数据包

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Join Group | Sessions=${Sessions} |
    """

    result = renix.pim_join_group(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pim_leave_group(Sessions):
    """
    PIM协议会话发送离开组数据包

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Leave Group | Sessions=${Sessions} |
    """

    result = renix.pim_leave_group(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pim_start_register(Sessions):
    """
    PIM协议会话开始发送Register消息

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Start Register | Sessions=${Sessions} |
    """

    result = renix.pim_start_register(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pim_stop_register(Sessions):
    """
    PIM协议会话停止发送Register消息

    Args:

        Sessions (list (:obj:`PimRouter`)): PIM协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Stop Register | Sessions=${Sessions} |
    """

    result = renix.pim_stop_register(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_pim_port_config(Ports, **kwargs):
    """
    修改PIM协议会话的端口配置

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        MsgTransRate (int): PIM Message Transmit Rate (messages/sec), 类型为：number, 取值范围：1-10000, 默认值：500

        TriggerHelloDelay (int): Trigger Hello Delay (sec), 类型为：number, 取值范围：0-60, 默认值：5

        DisableHelloExpireTimer (bool): 使能PIM协议会话, 类型为：bool, 取值范围：True或False, 默认值：False

        DisableRecvHelloInNeighborState (bool): 使能PIM协议会话, 类型为：bool, 取值范围：True或False, 默认值：False

        DisableNonHelloRecv (bool): 使能PIM协议会话, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pim Port Config | Ports=${Ports} | DisableNonHelloRecv=True |
    """

    result = renix.edit_pim_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pim_session_stats(Session=None, StaItems: list = None):
    """
    获取Pim Session Stats统计结果

    Args:

        Session (:obj:`PimRouter`): BGP协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            NeighborNum

            TxHello

            RxHello

            TxJoin

            RxJoin

            TxAnyG

            RxAnyG

            TxSG

            RxSG

            TxRP

            RxRP

            TxRpt

            RxRpt

            TxBsr

            TxRegister

            RxRegisterStop

    Returns:

        dict: eg::

            {
                'TxRpt': 10,
                'RxRpt': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | TxHello | RxHello |
            | Subscribe Result | Types=PimSessionStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pim Session Stats | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pim_session_stats(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pim_group_stats(Session=None, Group=None, StaItems: list = None):
    """
    获取Pim Group Stats统计结果

    Args:

        Session (:obj:`PimRouter`): BGP协议会话对象, 类型为：Object

        Group (:obj:`PimGroupConfig`): Pim协议组对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            TxAnyG

            TxSG

            TxRP

            TxRpt

    Returns:

        dict: eg::

            {
                'TxRpt': 10,
                'RxRpt': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | TxHello | RxHello |
            | Subscribe Result | Types=PimGroupStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pim Group Stats | Session=${Session} | Group=${Group} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pim_group_stats(Session=Session, Group=Group, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_dot3ah(Port, **kwargs):
    """
    创建802.3ah会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): 802.3ah会话名称, 类型为：string

        Enable (bool): 使能802.3ah会话, 类型为：bool, 取值范围：True或False, 默认值：True

        MaxPduSize (int): 最大PDU范围，默认值：1500, 取值范围：uint32 in [60,2047]

        TransmitType (str): 发送方式，默认值：SINGLE, 取值范围：

            SINGLE

            BATCH

        LoopBackRespTime (int): Loopback响应时间，默认值：1, 取值范围：uint32 in [1,10]

        EnableLinkFault (bool): 使能Link Fault, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableDyingGasp (bool): 使能Dying Gasp, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableCriticalEvent (bool): 使能Critical Event, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableLoopBackResp (bool): 使能Loopback Response, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableVarResp (bool): 使能Variable Response, 类型为：bool, 取值范围：True或False, 默认值：True

        VarReqPeriod (int): Variable Request周期，默认值：1, 取值范围：uint8 in [0,10]

    Returns:

        (:obj:`Dot3ah`): 802.3ah会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Dot3ah | Port=${Port} | MaxPduSize=1300 |

    """

    result = renix.create_dot3ah(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dot3ah_event_notification(Session, **kwargs):
    """
    修改802.3ah Event Notification对象

    Args：

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Keyword Args:

        InitialTime (int): 初始时间，默认值：0, 取值范围：uint32 in [0,65535]

        EventRepeatPeriod (int): 重复周期，默认值：2, 取值范围：uint32 in [0,10]

        EnableErroredFrameEvent (bool): 使能Errored Frame Event, 类型为：bool, 取值范围：True或False, 默认值：False

        EfeWindow (int): EFE窗口，默认值：10, 取值范围：uint16 in [10,600]

        EfeThreshold (int): EFE阈值，默认值：1, 取值范围：uint16 in [0,65535]

        EfeErrorCount (int): EFE错误计数，默认值：1, 取值范围：uint16 in [0,65535]

        EnableErroredFramePeriodEvent (bool): 使能Errored Frame Period Event, 类型为：bool, 取值范围：True或False, 默认值：False

        EfpeWindow (int): EFPE窗口，默认值：10, 取值范围：uint16 in [1,65535]

        EfpeThreshold (int): EFPE阈值，默认值：10, 取值范围：uint16 in [0,65535]

        EfpeErrorCount (int): EFPE错误计数，默认值：10, 取值范围：uint32 in [0,65535]

        EnableErroredSymbolPeriodEvent (bool): 使能Errored Symbol Period Event, 类型为：bool, 取值范围：True或False, 默认值：False

        EspeWindow (int): ESPE窗口，默认值：10, 取值范围：uint16 in [1,65535]

        EspeThreshold (int): ESPE阈值，默认值：600, 取值范围：uint16 in [100,900]

        EspeErrorCount (int): ESPE错误计数，默认值：10, 取值范围：uint32 in [0,65535]

        EnableErroredFrameSecondsSummaryEvent (bool): 使能Errored Frame Seconds Summary Event, 类型为：bool, 取值范围：True或False, 默认值：False

        EfsseWindow (int): EFSSE窗口，默认值：600, 取值范围：uint16 in [1,65535]

        EfsseThreshold (int): EFSSE阈值，默认值：600, 取值范围：uint16 in [100,900]

        EfsseCount (int): EFSSE计数，默认值：1, 取值范围：uint32 in [0,65535]

        EnableOrgSpecEvent (bool): 使能Org Spec Event, 类型为：bool, 取值范围：True或False, 默认值：False

        OrgSpecEventOUI (list): Organization Specific Event OUI，默认值：[0,0,0], 取值范围：列表元素0-255的十进制数

        OrgSpecEventData (list): Organization Specific Event数据，默认值：[], 取值范围：列表元素0-255的十进制数

    Returns:

        (:obj:`Dot3ahEventNotificationConfig`): 802.3ah Event Notification对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dot3ah Event Notification | Session=${Session} | InitialTime=20 |
    """

    result = renix.edit_dot3ah_event_notification(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dot3ah_info_pdu(Session, **kwargs):
    """
    修改802.3ah Info Pdu对象

    Args：

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Keyword Args:

        PduTime (int): PDU时间，默认值：1, 取值范围：uint32 in [1,10]

        LostLinkTime (int): Lost Link时间，默认值：5, 取值范围：uint32 in [2,90]

        OamModeType (str): OAM模式，默认值：ACTIVE, 取值范围：

            PASSIVE

            ACTIVE

        OrgUniqueId (lst): 组织唯一ID，默认值：[0,0,0], 取值范围：列表元素0-255的十进制数

        OamVersion (int): OAM版本，默认值：1, 取值范围：uint8 in [0,255]

        VendorSpecInfo (int): 供应商信息，默认值：0, 取值范围：uint32

        EnableOverrideRevision (bool): 使能Override Revision, 类型为：bool, 取值范围：True或False, 默认值：False

        OverrideRevision (int): Override Revision, 默认值：0, 取值范围：uint16

        EnableVarRetrieval (bool): 使能Var Retrieval, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableInterpLinkEvent (bool): 使能Interp Link Event, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableLoopBack (bool): 使能LoopBack, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableUnidirMode (bool): 使能Unidir Mode, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Dot3ahInfoPduConfig`): 802.3ah Info Pdu对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dot3ah Info Pdu | Session=${Session} | PduTime=10 |
    """

    result = renix.edit_dot3ah_info_pdu(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dot3ah_org_spec(Session, **kwargs):
    """
    修改802.3ah Org Spec对象

    Args：

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Keyword Args:

        EnableOrgSpec (bool): 使能Org Spec, 类型为：bool, 取值范围：True或False, 默认值：False

        Period (int): 周期，默认值：1, 取值范围：uint8 in [0,10]

        OrgSpecOUI (list): Organization Specific Event OUI，默认值：[0,0,0], 取值范围：列表元素0-255的十进制数

        OrgSpecEventData (list): Organization Specific Event数据，默认值：[], 取值范围：列表元素0-255的十进制数

    Returns:

        (:obj:`Dot3ahOrgSpecConfig`): 802.3ah Org Spec对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dot3ah Org Spec | Session=${Session} | Period=20 |
    """

    result = renix.edit_dot3ah_org_spec(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot3ah_org_spec_tlv(Session, **kwargs):
    """
    创建802.3ah Org Spec TLV对象

    Args：

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Keyword Args:

        OrgUniqueId (list): 组织唯一标识，默认值：[0,0,0], 取值范围：列表元素0-255的十进制数

        Data (list): TLV数据，默认值：[], 取值范围：列表元素0-255的十进制数

    Returns:

        (:obj:`Dot3ahOrgSpecTlvConfig`): 802.3ah Org Spec TLV对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot3ah Org Spec Tlv | Session=${Session} | Data=2 |
    """

    result = renix.create_dot3ah_org_spec_tlv(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot3ah_var_req(Session, **kwargs):
    """
    创建802.3ah Var Req对象

    Args：

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Keyword Args:

        Branch (int): 分支，默认值：0, 取值范围：uint8 in [0,255]

        Leaf (int): 叶子，默认值：0, 取值范围：uint16 in [0,65535]

    Returns:

        (:obj:`Dot3ahVarReqConfig`): 802.3ah Var Req对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot3ah Var Req | Session=${Session} | Branch=10 |
    """

    result = renix.create_dot3ah_var_req(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot3ah_var_resp(Session, **kwargs):
    """
    创建802.3ah Var Resp对象

    Args：

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Keyword Args:

        Branch (int): 分支，默认值：0, 取值范围：uint8 in [0,255]

        Leaf (int): 叶子，默认值：0, 取值范围：uint16 in [0,65535]

        Indication (bool): 表示, 类型为：bool, 取值范围：True或False, 默认值：False

        Width (int): 宽度，默认值：1, 取值范围：uint8

        Data (list): 数据，默认值：[], 取值范围：列表元素0-255的十进制数

    Returns:

        (:obj:`Dot3ahVarRespConfig`): 802.3ah Var Resp对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot3ah Var Resq | Session=${Session} | Branch=10 |
    """

    result = renix.create_dot3ah_var_resp(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_event_notification_dot3ah(Sessions):
    """
    启动Event Notification

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Event Notification Dot3ah | Sessions=${Sessions} |
    """

    result = renix.start_event_notification_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_link_trace_dot3ah(Sessions):
    """
    启动Link Trace

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Link Trace | Sessions=${Sessions} |
    """

    result = renix.start_link_trace_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_loopback_dot3ah(Sessions):
    """
    启动Loopback

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Loopback Dot3ah | Sessions=${Sessions} |
    """

    result = renix.start_loopback_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_org_spec_dot3ah(Sessions):
    """
    启动Organization Specific

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Org Spec | Sessions=${Sessions} |
    """

    result = renix.start_org_spec_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_var_req_dot3ah(Sessions):
    """
    启动Variable Request

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Var Req | Sessions=${Sessions} |
    """

    result = renix.start_var_req_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_event_notification_dot3ah(Sessions):
    """
    停止Event Notification

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Event Notification Dot3ah | Sessions=${Sessions} |
    """

    result = renix.stop_event_notification_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_link_trace_dot3ah(Sessions):
    """
    停止Link Trace

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Link Trace Dot3ah | Sessions=${Sessions} |
    """

    result = renix.stop_link_trace_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_loopback_dot3ah(Sessions):
    """
    停止Loopback

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Loopback Dot3ah | Sessions=${Sessions} |
    """

    result = renix.stop_loopback_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_org_spec_dot3ah(Sessions):
    """
    停止Organization Specific

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Org Spec | Sessions=${Sessions} |
    """

    result = renix.stop_org_spec_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_var_req_dot3ah(Sessions):
    """
    停止Variable Request

    Args:

        Sessions (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Var Req | Sessions=${Sessions} |
    """

    result = renix.stop_var_req_dot3ah(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dot3ah_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待802.3ah会话达到指定状态

    Args:

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

        State (list): 等待802.3ah会话组达到的状态, 类型为：string, 默认值：达到COMPLETED, 支持下列状态：

            NONE

            UNSATISFIED

            NOTCOMPLETED

            COMPLETED

            RESERVED

            DISABLED

            IDLE

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dot3ah State | Sessions=${Sessions} | State=COMPLETED | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_dot3ah_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dot3ah_error_event_stats(Session=None, StaItems: list = None):
    """
    获取802.3ah error event 统计结果

    Args:

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            EventType

            TimeStamp

            WindowsSize

            Threshold

            ErrorCount

            ErrorRunningTotal

            EventRunningTotal

            OrgUniqueId

            OrgSpecificData

    Returns:

        dict: eg::

            {
                'OrgUniqueId': [1, 1, 1],
                'OrgSpecificData': 1,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dot3ahErrorEventStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dot3ah Error Event Stats | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dot3ah_error_event_stats(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dot3ah_session_statistic(Session=None, StaItems: list = None):
    """
    获取802.3ah session 统计结果

    Args:

        Session (:obj:`Dot3ah`): 802.3ah会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            LocalMultiplexerAction

            LocalParserAction

            RemoteMultiplexerAction

            RemoteParserAction

            RemoteMode

            RemoteOamVersion

            RemoteRevision

            RemoteOui

            RemoteEnableVarRetrieval

            RemoteEnableInterpretLinkEvent

            RemoteEnableLoopBack

            RemoteEnableUnidirMode

            RemoteMaxPduSize

            RemoteVendorSpecificInfo

            TxDyingGaspCounter

            RxDyingGaspCounter

            TxLinkFaultCounter

            RxLinkFaultCounter

            TxCriticalCounter

            RxCriticalCounter

            TxEfeCounter

            RxEfeCounter

            TxEspeCounter

            RxEspeCounter

            TxEfpeCounter

            RxEfpeCounter

            TxEfsseCounter

            RxEfsseCounter

            TxOrgSpecEventCounter

            RxOrgSpecEventCounter

            TxInfoPduCounter

            RxInfoPduCounter

            TxEventNotificationPduCounter

            RxEventNotificationPduCounter

            TxLoopBackCounter

            RxLoopBackCounter

            TxVarReqCounter

            RxLoopBackCounter

            TxVarReqCounter

            RxVarReqCounter

            TxVarRespCounter

            RxVarRespCounter

            TxOrgSpecPduCounter

            RxOrgSpecPduCounter

    Returns:

        dict: eg::

            {
                'TxOrgSpecPduCounter': 10,
                'RxOrgSpecPduCounter': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dot3ahSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dot3ah Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dot3ah_session_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

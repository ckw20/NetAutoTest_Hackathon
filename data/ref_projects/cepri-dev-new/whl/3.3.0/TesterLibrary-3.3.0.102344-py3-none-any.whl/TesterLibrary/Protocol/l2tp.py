import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------L2TP-------------------------------------
def create_l2tp(Port, **kwargs):
    """
    创建L2tp协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): L2tp协会话名称, 类型为：string

        Enable (bool): 使能L2tp协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        EmulationMode (str): L2TP角色, 默认值：LAC, 取值范围：

            LAC

            LNS

        TunnelCountPerNode (int): 每LAC/LNS隧道数, 取值范围：1-32768, 默认值：1

        SessionCountPerTunnel (int): 每隧道会话数, 取值范围：0-65535, 默认值：0

        TunnelStartingId (int): 隧道起始ID, 取值范围：1-65535, 默认值：1

        SessionStartingId (int): 会话起始ID, 取值范围：1-65535, 默认值：1

        UdpSourcePort (int): UDP源端口, 取值范围：1-65535, 默认值：1701

        UdpChecksumEnabled (bool): 使能UDP校验和, 默认值：True

        RetryTunnelCreationEnabled (bool): 使能隧道重试, 默认值：False

        TunnelCreationTimeout (int): 隧道建立超时(secs), 取值范围：1-65535, 默认值：5

        MaxTunnelCreationTimes (int): 隧道建立最大尝试次数, 取值范围：1-65535, 默认值：5

        HostName (str): 主机名, 取值范围：string length in [1,255], 默认值：xinertel

        EnableAuthentication (bool): 使能认证, 默认值：True

        IncomingTunnelPassword (str): Incoming隧道密码, 取值范围：string length in [1,255], 默认值：xinertel

        OutgoingTunnelPassword (str): Outgoing隧道密码, 取值范围：string length in [1,255], 默认值：xinertel

        HelloEnabled (bool): 使能Hello, 默认值：False

        HelloInterval (int): Hello间隔(secs), 取值范围：1-255, 默认值：60

        TxBitRate (int): 发送bps速率(bits/sec), 取值范围：1-65535, 默认值：56000

        BearerCapabilities (str): 负载能力, 默认值：ANALOG, 取值范围：

            DIGITAL

            ANALOG

            BOTH

        BearerType (str): 负载类型, 默认值：ANALOG, 取值范围：

            DIGITAL

            ANALOG

        FrameCapabilities (str): 帧能力, 默认值：SYNC, 取值范围：

            SYNC

            ASYNC

            BOTH

        FrameType (str): 帧类型, 默认值：SYNC, 取值范围：

            SYNC

            ASYNC

        CallingNumberEnabled (bool): 使能Calling Number, 默认值：False

        CallingNumber (str): 隧道的Calling Number, 默认值：xinertel

        RxWindowSize (int): 接收窗口大小, 取值范围：1-65535, 默认值：4

        UseGatewayAsRemoteIp (bool): 使用网关作为远端地址, 默认值：True

        RemoteIpv4Address (str): 远端IPv4地址, 取值范围：IPv4地址, 默认值：2.1.1.1

        RemoteIpv4AddressStep (str): 远端IPv4地址跳变, 取值范围：IPv4地址, 默认值：0.0.0.1

        RemoteIpv6Address (str): 远端IPv6地址, 取值范围：IPv6地址, 默认值：2000::1

        RemoteIpv6AddressStep (str): 远端IPv6地址跳变, 取值范围：IPv6地址, 默认值：::1

        LcpProxyMode (str): LCP代理模式, 默认值：NONE, 取值范围：

            NONE

            LCP

            LCP_AUTH

        ForceLcpRenegotiation (bool): 强制LCP重协商, 默认值：False

        Ipv4TosValue (hex int): IPv4 TOS值, 取值范围：1-65535, 默认值：0xc0

        Ipv6TrafficClassValue (hex int): IPv6 Traffic Class Value, 取值范围：1-65535, 默认值：0x0

        HideFramingCapabilities (bool): 默认值：False

        HideBearerCapabilities (bool): 默认值：False

        HideAssignedTunnelId (bool): 默认值：False

        HideChallenge (bool): 默认值：False

        HideChallengeResponse (bool): 默认值：False

        HideAssignedSessionId (bool): 默认值：False

        HideCallSerialNumber (bool): 默认值：False

        HideFramingType (bool): 默认值：False

        HideCallingNumber (bool): 默认值：False

        HideTxConnectSpeed (bool): 默认值：False

        HideLastSentLcpConfReq (bool): 默认值：False

        HideLastReceivedLcpConfReq (bool): 默认值：False

        HideProxyAuthenType (bool): 默认值：False

        HideProxyAuthenName (bool): 默认值：False

        HideProxyAuthenChallenge (bool): 默认值：False

        HideProxyAuthenId (bool): 默认值：False

        HideProxyAuthenResponse (bool): 默认值：False

    Returns:

        (:obj:`L2tp`): L2tp协议会话对, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create L2tp | Port=${Port} |
    """

    result = renix.create_l2tp(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_l2tp(Session, **kwargs):
    """
    修改L2tp协议会话对象

    Args:

        Session (:obj:`L2tpProtocolConfig`): L2tp协议会话对, 类型为：object

    Keyword Args:

        Name (str): L2tp协会话名称, 类型为：string

        Enable (bool): 使能L2tp协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        EmulationMode (str): L2TP角色, 默认值：LAC, 取值范围：

            LAC

            LNS

        TunnelCountPerNode (int): 每LAC/LNS隧道数, 取值范围：1-32768, 默认值：1

        SessionCountPerTunnel (int): 每隧道会话数, 取值范围：0-65535, 默认值：0

        TunnelStartingId (int): 隧道起始ID, 取值范围：1-65535, 默认值：1

        SessionStartingId (int): 会话起始ID, 取值范围：1-65535, 默认值：1

        UdpSourcePort (int): UDP源端口, 取值范围：1-65535, 默认值：1701

        UdpChecksumEnabled (bool): 使能UDP校验和, 默认值：True

        RetryTunnelCreationEnabled (bool): 使能隧道重试, 默认值：False

        TunnelCreationTimeout (int): 隧道建立超时(secs), 取值范围：1-65535, 默认值：5

        MaxTunnelCreationTimes (int): 隧道建立最大尝试次数, 取值范围：1-65535, 默认值：5

        HostName (str): 主机名, 取值范围：string length in [1,255], 默认值：xinertel

        EnableAuthentication (bool): 使能认证, 默认值：True

        IncomingTunnelPassword (str): Incoming隧道密码, 取值范围：string length in [1,255], 默认值：xinertel

        OutgoingTunnelPassword (str): Outgoing隧道密码, 取值范围：string length in [1,255], 默认值：xinertel

        HelloEnabled (bool): 使能Hello, 默认值：False

        HelloInterval (int): Hello间隔(secs), 取值范围：1-255, 默认值：60

        TxBitRate (int): 发送bps速率(bits/sec), 取值范围：1-65535, 默认值：56000

        BearerCapabilities (str): 负载能力, 默认值：ANALOG, 取值范围：

            DIGITAL

            ANALOG

            BOTH

        BearerType (str): 负载类型, 默认值：ANALOG, 取值范围：

            DIGITAL

            ANALOG

        FrameCapabilities (str): 帧能力, 默认值：SYNC, 取值范围：

            SYNC

            ASYNC

            BOTH

        FrameType (str): 帧类型, 默认值：SYNC, 取值范围：

            SYNC

            ASYNC

        CallingNumberEnabled (bool): 使能Calling Number, 默认值：False

        CallingNumber (str): 隧道的Calling Number, 默认值：xinertel

        RxWindowSize (int): 接收窗口大小, 取值范围：1-65535, 默认值：4

        UseGatewayAsRemoteIp (bool): 使用网关作为远端地址, 默认值：True

        RemoteIpv4Address (str): 远端IPv4地址, 取值范围：IPv4地址, 默认值：2.1.1.1

        RemoteIpv4AddressStep (str): 远端IPv4地址跳变, 取值范围：IPv4地址, 默认值：0.0.0.1

        RemoteIpv6Address (str): 远端IPv6地址, 取值范围：IPv6地址, 默认值：2000::1

        RemoteIpv6AddressStep (str): 远端IPv6地址跳变, 取值范围：IPv6地址, 默认值：::1

        LcpProxyMode (str): LCP代理模式, 默认值：NONE, 取值范围：

            NONE

            LCP

            LCP_AUTH

        ForceLcpRenegotiation (bool): 强制LCP重协商, 默认值：False

        Ipv4TosValue (hex int): IPv4 TOS值, 取值范围：1-65535, 默认值：0xc0

        Ipv6TrafficClassValue (hex int): IPv6 Traffic Class Value, 取值范围：1-65535, 默认值：0x0

        HideFramingCapabilities (bool): 默认值：False

        HideBearerCapabilities (bool): 默认值：False

        HideAssignedTunnelId (bool): 默认值：False

        HideChallenge (bool): 默认值：False

        HideChallengeResponse (bool): 默认值：False

        HideAssignedSessionId (bool): 默认值：False

        HideCallSerialNumber (bool): 默认值：False

        HideFramingType (bool): 默认值：False

        HideCallingNumber (bool): 默认值：False

        HideTxConnectSpeed (bool): 默认值：False

        HideLastSentLcpConfReq (bool): 默认值：False

        HideLastReceivedLcpConfReq (bool): 默认值：False

        HideProxyAuthenType (bool): 默认值：False

        HideProxyAuthenName (bool): 默认值：False

        HideProxyAuthenChallenge (bool): 默认值：False

        HideProxyAuthenId (bool): 默认值：False

        HideProxyAuthenResponse (bool): 默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit L2tp | Session=${Session} |
    """

    result = renix.edit_l2tp(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_l2tp_port_config(Ports, **kwargs):
    """
    修改DHCPv6端口配置对象

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object / list

    Keyword Args:

        TunnelConnectRate (int): Request速率（会话/秒）, 取值范围：1-1000, 默认值：100

    Returns:

        (:obj:`L2tpPortConfig`): L2tp端口对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit L2tp Port Config | Ports=${Port} | TcpServerPort=10 |
    """

    result = renix.edit_l2tp_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def connect_l2tp(Sessions):
    """
    建立L2tp协议会话

    Args:

        Sessions (:obj:`L2tp`): L2tp协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Connect L2tp | Sessions=${Sessions} |
    """
    result = renix.connect_l2tp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def disconnect_l2tp(Sessions):
    """
    断开L2tp协议会话

    Args:

        Sessions (:obj:`L2tp`): L2tp协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Disconnect L2tp | Sessions=${Sessions} |
    """
    result = renix.disconnect_l2tp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def abort_l2tp(Sessions):
    """
    中断L2tp协议会话

    Args:

        Sessions (:obj:`L2tp`): L2tp协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Abort L2tp | Sessions=${Sessions} |
    """
    result = renix.abort_l2tp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_l2tp_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待L2tp协议会话达到指定状态

    Args:

        Sessions (:obj:`L2tp`): L2tp协议会话对象列表, 类型为：list

        State (list): 等待L2tp协议会话达到的状态, 类型为：string, 默认值：达到CONNECTED, 支持下列状态：

            NONE

            IDLE

            CONNECTING

            CONNECTED

            DISCONNECTING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait L2tp State | Sessions=${Sessions} | State=DR | Interval=2 | TimeOut=120 |
    """
    result = renix.wait_l2tp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_l2tp_port_statistic(Port=None, StaItems=None):
    """
    获取L2tp Session Statistic统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            LacCount

            LnsCount

            TunnelCount

            SessionCount

            TunnelUp

            TunnelDown

            SessionUp

            SessionDown

    Returns:

        dict: eg::

            {
                'TunnelUp': 10,
                'SessionUp': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=L2tpPortStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get L2tp Port Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """
    result = renix.get_l2tp_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_l2tp_session_statistic(Session=None, NodeIndexInBlock=1, StaItems=None):
    """
    获取L2tp Session Statistic统计结果

    Args:

        Session (:obj:`L2tp`): L2tp协议会话对象, 类型为：Object

        NodeIndexInBlock (int): Session Index, 类型为：int

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            LocalTunnelId

            RemoteTunnelId

            LocalSessionId

            RemoteSessionId

            SessionState

            LocalTunnelIpAddress

            RemoteTunnelIpAddress

            LocalTunnelIpv6Address

            RemoteTunnelIpv6Address

            TxIcrq

            RxIcrq

            TxIcrp

            RxIcrp

            TxIccn

            RxIccn

            TxCdn

            RxCdn

            ResultCode

            ErrorCode

            ErrorMessage

    Returns:

        dict: eg::

            {
                'TxIcrq': 10,
                'RxIcrq': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=L2tpSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get L2tp Session Statistic | Session=${Session} | NodeIndexInBlock=1 | StaItems=@{StaItems} |
            | Clear Result |
    """
    result = renix.get_l2tp_session_statistic(Session=Session, NodeIndexInBlock=NodeIndexInBlock,
                                              StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_l2tp_block_statistic(Session=None, StaItems=None):
    """
    获取L2tp Block Statistic统计结果

    Args:

        Session (:obj:`L2tp`): L2tp协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            TunnelCount

            SessionCount

            TunnelUp

            TunnelDown

            SessionUp

            SessionDown

            TunnelSetupRate

            SessionSetupRate

            AverageTunnelSetupTime

            MaxTunnelSetupTime

            MinTunnelSetupTime

            AverageSessionSetupTime

            MaxSessionSetupTime

            MinSessionSetupTime

            TxPackets

            RxPackets

            TxSccrq

            RxSccrq

            TxSccrp

            RxSccrp

            TxScccn

            RxScccn

            TxIcrq

            RxIcrq

            TxIcrp

            RxIcrp

            TxIccn

            RxIccn

            TxSli

            RxSli

            TxStopCcn

            RxStopCcn

            TxWen

            RxWen

            TxHello

            RxHello

            TxCdn

            RxCdn

            TxZlb

            RxZlb

    Returns:

        dict: eg::

            {
                'TxZlb': 10,
                'RxZlb': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=L2tpBlockStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get L2tp Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """
    result = renix.get_l2tp_session_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_l2tp_tunnel_statistic(Session=None, NodeIndexInBlock=1, StaItems=None):
    """
    获取L2tp Tunnel Statistic统计结果

    Args:

        Session (:obj:`L2tp`): L2tp协议会话对象, 类型为：Object

        NodeIndexInBlock (int): Session Index, 类型为：int

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            LocalTunnelId

            RemoteTunnelId

            TunnelState

            UdpSourcePort

            UdpDestinationPort

            LocalIpAddress

            RemoteIpAddress

            LocalIpv6Address

            RemoteIpv6Address

            SessionCount

            SessionUp

            SessionDown

            TxPackets

            RxPackets

            TxSccrq

            RxSccrq

            TxSccrp

            RxSccrp

            TxScccn

            RxScccn

            TxSli

            RxSli

            TxStopCcn

            RxStopCcn

            TxWen

            RxWen

            TxHello

            RxHello

    Returns:

        dict: eg::

            {
                'TxHello': 10,
                'RxHello': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=L2tpTunnelStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get L2tp Tunnel Statistic | Session=${Session} | NodeIndexInBlock=1 | StaItems=@{StaItems} |
            | Clear Result |
    """
    result = renix.get_l2tp_tunnel_statistic(Session=Session, NodeIndexInBlock=NodeIndexInBlock,
                                             StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

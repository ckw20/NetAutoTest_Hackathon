import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_dot1x(Port, **kwargs):
    """
    创建802.1x会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): 802.1x会话名称, 类型为：string

        Enable (bool): 使能801.1x会话, 类型为：bool, 取值范围：True或False, 默认值：True

        AuthMode (str): 默认值：MD5, 取值范围：

            MD5

            TLS

            TTLS

        Identity (str): 默认值：xinertel, 取值范围：string length in [1,255]

        Password (str): 默认值：xinertel, 取值范围：string length in [1,255]

        UseAuthenticatorMac (bool): 使能801.1x会话, 类型为：bool, 取值范围：True或False, 默认值：False

        AuthenticatorMac(str): 默认值：01:80:c2:00:00:03, 取值范围：有效的mac地址

        RetryCount (int): 默认值：5, 取值范围：uint32

        RetryTimeout (int): 默认值：5, 取值范围：1-4294967295

        RetransmitCount (int): 默认值：5, 取值范围：uint32

        RetransmitTimeout (int): 默认值：5, 取值范围：1-4294967295

        SupplicantCertificateName (str): 默认值：‘’, 取值范围：string length in [1,255]

        CertificatePassword (str): 默认值：‘’, 取值范围：string length in [1,255]

        DuplicateUserInfoToInner (bool): 使能801.1x会话, 类型为：bool, 取值范围：True或False, 默认值：True

        InnerIdentity (str): 默认值：xinertel, 取值范围：string length in [1,255]

        InnerPassword (str): 默认值：xinertel, 取值范围：string length in [1,255]

        InnerTunnelAuthMode (str): 默认值：AUTO, 取值范围：

            AUTO

            GTC

            MS_CHAPV2

            MD5

        EnableClientCertificate (bool): 使能801.1x会话, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`Dot1x`): 802.1x会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Dot1x | Port=${Port} | DadTransmits=10 |
    """

    result = renix.create_dot1x(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dot1x_port_config(Ports, **kwargs):
    """
    修改802.1x端口配置对象

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        AuthenticationRate (int): 默认值：100, 取值范围：1-16384

        LogoutRate (int): 默认值：100, 取值范围：1-16384

        OutstandingSessions (int): 默认值：100, 取值范围：1-10000

    Returns:

        (:obj:`Dot1xPortConfig`): 802.1x端口配置对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit dot1x Port Config | Ports=${Port} | OutstandingSessions=10 |
    """

    result = renix.edit_dot1x_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dot1x_upload_certificate(Sessions, Folder):
    """
    上传802.1x证书

    Args:

        Sessions (:obj:`Dot1x`): 802.1x会话对象, 类型为：object / list

        Folder (str): 证书所在路径，e.g.'c:/CertificateFolder'

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dot1x Upload Certificate | Sessions=${Sessions} | Folder=${Folder} |
    """

    result = renix.dot1x_upload_certificate(Sessions=Sessions, Folder=Folder)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def dot1x_delete_certificate(Sessions):
    """
    删除802.1x证书

    Args:

        Sessions (:obj:`Dot1x`): 802.1x会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Dot1x Upload Certificate | Sessions=${Sessions} |
    """

    result = renix.dot1x_delete_certificate(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def abort_dot1x(Sessions):
    """
    中断802.1x会话

    Args:

        Sessions (:obj:`Dot1x`): 802.1x会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Abort Dot1x | Sessions=${Sessions} |
    """

    result = renix.abort_dot1x(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dot1x_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待802.1x会话达到指定状态

    Args:

        Session (:obj:`Dot1x`): 802.1x会话对象, 类型为：object / list

        State (list): 等待802.1x会话组达到的状态, 类型为：string, 默认值：达到AUTHENTICATED, 支持下列状态：

            DISABLED

            DOWN

            UNAUTHORIZED

            AUTHENTICATING

            AUTHENTICATED

            FAILED

            LOGGING_OFF

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dot1x State | Sessions=${Sessions} | State=AUTHENTICATED | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_dot1x_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dot1x_block_statistic(Session=None, StaItems: list = None):
    """
    获取802.1x session block统计结果

    Args:

        Session (:obj:`Dot1x`): 802.1x会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            BlockState

            CurrentAuthenticatedAttempt

            CurrentAuthenticated

            CurrentFailed

            CurrentLogoff

            AuthenticatedAttemptRate

            AuthenticatedRate

            LogoffRate

            TotalAttempt

            TotalAuthenticated

            TotalFailed

            TotalLogoff

            TotalRetry

            TotalRetransmit

            RxEapFailure

            RxEapRequest

            RxEapSucess

            TxEapResponse

            MaxAuthenticatedTime

            MaxLogoffTime

    Returns:

        dict: eg::

            {
                'MaxAuthenticatedTime': 10,
                'MaxLogoffTime': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dot3ahErrorEventStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dot3ah Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dot1x_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dot1x_port_statistic(Port=None, StaItems: list = None):
    """
    获取802.1x port block统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            CurrentAuthenticatedAttempt

            CurrentAuthenticated

            CurrentFailed

            CurrentLogoff

            TotalAttempt

            TotalAuthenticated

            TotalFailed

            TotalLogoff

            TotalRetry

            TotalRetransmit

    Returns:

        dict: eg::

            {
                'TotalRetry': 10,
                'TotalRetransmit': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dot1xPortStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dot1x Port Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dot1x_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dot1x_statistic(Session=None, Index=1, StaItems: list = None):
    """
    获取802.1x统计结果

    Args:

        Session (:obj:`Dot1x`): 802.1x会话对象, 类型为：object / list

        Index (int): Session Index

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            ReqIdentity

            RespIdentity

            ReqChallenge

            RespChallenge

            TLSEstablish

            ReceiveOK

            ReceiveFail


    Returns:

        dict: eg::

            {
                'ReceiveOK': 10,
                'ReceiveFail': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dot1xStatistics |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dot1x Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dot1x_statistic(Session=Session, Index=Index, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


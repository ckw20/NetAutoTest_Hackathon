import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Common-------------------------------------
def start_protocol(Ports=None, Protocols=None, Objects=None):
    """
    测试仪表启动协议

    Args:

        Ports (list): 端口对象的列表

        Protocols (list): 指定需要启动的协议类型列表, 目前支持的协议类型：

            ospfv2

            ospfv3

            dhcpv4

            dhcpv6

            vxlan

        Objects (list): 当Ports和Protocols都为None时，可以指定协议会话对象列表

    Returns:

        布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Protocol |
    """

    result = renix.start_protocol(Ports=Ports, Protocols=Protocols, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_protocol(Ports=None, Protocols=None, Objects=None):
    """
    测试仪表停止协议

    Args:

        Ports (list): 端口对象的列表

        Protocols (list): 指定需要停止的协议类型列表，目前支持的协议类型：

            ospfv2

            ospfv3

            dhcpv4

            dhcpv6

            vxlan

        Objects (list): 当Ports和Protocols都为None时，可以指定协议会话对象列表

    Returns:

        布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Protocol |
    """

    result = renix.stop_protocol(Ports=Ports, Protocols=Protocols, Objects=Objects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_sessions(Ports=None, Protocols=None):
    """
    获取当前测试仪表配置中所有的协议对象

    Args:

        Ports (list): 端口对象的列表

        Protocols (list): 指定需要启动的协议类型列表，目前支持的协议类型：

            bgp

            bfd

            isis

            ospfv2

            ospfv3

            pim

            rip

            dot1x

            dhcpv4server

            dhcpv4

            dhcpv6server

            dhcpv6

            vxlan

            saa

            IGMP

            igmpquery

            mld

            mldquery

            l2tp

            pppoe

            ldp

            lspping

            pcep

    Returns:

        协议会话对象列表

    Examples:
        .. code:: RobotFramework

            | ${result} | Get Sessions |
    """

    result = renix.get_sessions(Ports=Ports, Protocols=Protocols)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_sessions_from_type(Type):
    """
    获取当前测试仪表配置中指定类型协议对象

    Args:

        Type (str): 指定需要启动的协议类型，目前支持的协议类型：

            bgp

            bfd

            isis

            ospfv2

            ospfv3

            pim

            rip

            dot1x

            dhcpv4server

            dhcpv4

            dhcpv6server

            dhcpv6

            vxlan

            saa

            IGMP

            igmpquery

            mld

            mldquery

            l2tp

            pppoe

            ldp

            lspping

            pcep

    Returns:

        协议会话对象列表

    Examples:
        .. code:: RobotFramework

            | ${result} | Get Sessions |
    """

    result = renix.get_sessions_from_type(Type=Type)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def select_interface(Session, Interface):
    """
    协议绑定测试仪表接口

    Args:

        Session (object): 测试仪表协议对象

        Interface (object): 测试仪表接口对象

    Returns:

        布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Select Interface | Session=${Session} | Interface=${Interface} |
    """

    result = renix.select_interface(Session=Session, Interface=Interface)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
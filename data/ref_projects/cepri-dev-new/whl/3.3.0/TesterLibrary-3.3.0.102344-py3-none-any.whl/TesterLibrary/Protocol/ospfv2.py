import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------OSPFv2-------------------------------------
def create_ospf(Port, **kwargs):
    """
    创建OSPFv2协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): OSPFv2协会话名称, 类型为：string

        Enable (bool): 使能OSPFv2协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        AreaId (str): 区域ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        EnableBfd (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        NetworkType (str): 网络类型, 类型为：string, 取值范围：Broadcast或P2P, 默认值：Broadcast

        Priority (int): 路由器优先级, 类型为：number, 取值范围：0-255, 默认值：0

        Cost (int): 接口开销, 类型为：number, 取值范围：1-65535, 默认值：10

        AuthenticationType (str): 类型为：string, 取值范围：None Simple或MD5, 默认值：None

        Password (str): 密码, 类型为：string, 默认值：Xinertel

        Md5KeyId (int): MD5密钥, 类型为：number, 取值范围：0-255, 默认值：1

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        EnableOspfv2Mtu (bool): 使能OSPF MTU, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        GracefulRestartReason (str): 平滑重启原因, 类型为：string, 默认值：UNKNOWN,支持的原因：

            UNKNOWN

            SOFTWARE

            RELOADORUPGRADE

            SWITCH

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        HelloInterval (int): Hello包间隔(秒), 类型为：number, 取值范围：0-65535, 默认值：10

        RouterDeadInterval (int): 路由器失效间隔(秒), 类型为：number, 取值范围：0-4294967295, 默认值：40

        LsaRetransInterval (int): LSA重传间隔(秒), 类型为：number, 取值范围：0-4294967295, 默认值：5

        LsaRefreshTime (int): LSA刷新间隔(秒), 类型为：number, 取值范围：1-1800, 默认值：1800

        EnableSrManagement (bool): 启用SR, 类型为：bool, 取值范围：True或False, 默认值： False

    Returns:

        (:obj:`OspfRouter`): OSPFv2协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Ospf | Port=${Port} |
    """

    result = renix.create_ospf(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ospf(Session, **kwargs):
    """
    编辑OSPFv2协议会话对象参数

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): OSPFv2协会话名称, 类型为：string

        Enable (bool): 使能OSPFv2协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        AreaId (str): 区域ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        EnableBfd (bool): 使能BFD, 类型为：bool, 取值范围：True或False, 默认值：False

        NetworkType (str): 网络类型, 类型为：string, 取值范围：Broadcast或P2P, 默认值：Broadcast

        Priority (int): 路由器优先级, 类型为：number, 取值范围：0-255, 默认值：0

        Cost (int): 接口开销, 类型为：number, 取值范围：1-65535, 默认值：10

        AuthenticationType (str): 类型为：string, 取值范围：None Simple或MD5, 默认值：None

        Password (str): 密码, 类型为：string, 默认值：Xinertel

        Md5KeyId (int): MD5密钥, 类型为：number, 取值范围：0-255, 默认值：1

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        EnableOspfv2Mtu (bool): 使能OSPF MTU, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableGracefulRestart (bool): 使能平滑重启, 类型为：bool, 取值范围：True或False, 默认值：False

        GracefulRestartReason (str): 平滑重启原因, 类型为：string, 默认值：UNKNOWN,支持的原因：

            UNKNOWN

            SOFTWARE

            RELOADORUPGRADE

            SWITCH

        EnableViewRoutes (bool): 使能查看路由, 类型为：bool, 取值范围：True或False, 默认值：False

        HelloInterval (int): Hello包间隔(秒), 类型为：number, 取值范围：0-65535, 默认值：10

        RouterDeadInterval (int): 路由器失效间隔(秒), 类型为：number, 取值范围：0-4294967295, 默认值：40

        LsaRetransInterval (int): LSA重传间隔(秒), 类型为：number, 取值范围：0-4294967295, 默认值：5

        LsaRefreshTime (int): LSA刷新间隔(秒), 类型为：number, 取值范围：1-1800, 默认值：1800

        EnableSrManagement (bool): 启用SR, 类型为：bool, 取值范围：True或False, 默认值： False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Ospf | Session=${Session} |
    """

    result = renix.edit_ospf(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_router_lsa(Session, **kwargs):
    """
    创建OSPFv2 Router LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Router LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：192.0.0.1

        RouterType (list): 路由器类型, 类型为：list, 默认值：NONTBIT, 支持选项有：

            NONTBIT

            ABR

            ASBR

            VLE

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2RouterLsaConfig`): OSPFv2 Router LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Router Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_router_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_router_lsa_link(RouterLsa, **kwargs):
    """
    创建OSPFv2 Router LSA Link对象

    Args:

        RouterLsa (:obj:`Ospfv2RouterLsaConfig`): 测试仪表OSPFv2 Router LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Router LSA Link的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        LinkType (str): 链路类型, 类型为：string, 默认值：P2P, 支持选项有：

            P2P

            TRANSITNETWORK

            STUBNETWORK

            VIRTUALLINK

        LinkId (str): 链路状态ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：192.0.0.1

        LinkData (str): 链路数据, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：255.255.255.0

        Metric (int): 度量值, 类型为：number, 取值范围：0-65535, 默认值：1

    Returns:

        (:obj:`Ospfv2RouterLsaLinksConfig`): OSPFv2 Router LSA Link对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${RouterLsa} | Create Ospf Router Lsa | Session=${Session} | Age=20 |
            | Create Ospf Router Lsa Link | RouterLsa=${RouterLsa} | Metric=65535 |
    """

    result = renix.create_ospf_router_lsa_link(RouterLsa=RouterLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_network_lsa(Session, **kwargs):
    """
    创建OSPFv2 Network LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Network LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        DrIpAddress (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-32, 默认值：24

        Options (list): 选项, 类型为：list, 默认值： NONTBIT | EBIT, 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2NetworkLsaConfig`): OSPFv2 Network LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Network Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_network_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_network_atch_router(NetworkLsa, **kwargs):
    """
    创建OSPFv2 Network LSA Atch Router对象

    Args:

        NetworkLsa (:obj:`Ospfv2NetworkLsaConfig`): 测试仪表OSPFv2 Network LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Network LSA  Atch Router的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AttachedRouter (str): 附加路由器的IP地址, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

    Returns:

        (:obj:`Ospfv2NetworkAtchRouterConfig`): OSPFv2 Network LSA Atch Router对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${NetworkLsa} | Create Ospf Network Lsa | Session=${Session} | Age=20 |
            | Create Ospf Network Lsa Atch Router | NetworkLsa=${NetworkLsa} | Metric=65535 |
    """

    result = renix.create_ospf_network_atch_router(NetworkLsa=NetworkLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_summary_lsa(Session, **kwargs):
    """
    创建OSPFv2 Summary LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Summary LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        RouteCount (int): 路由个数, 类型为：number, 取值范围：1-1000000, 默认值：1

        StartNetworkPrefix (str): 起始网络前缀, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：192.0.1.0

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-32, 默认值：24

        Increment (int): 步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：10

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2SummaryLsaConfig`): OSPFv2 Summary LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Summary Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_summary_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_asbr_summary_lsa(Session, **kwargs):
    """
    创建OSPFv2 Asbr Summary LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Summary LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        AsbrRouterId (str): asbr路由器id, 类型为：ip address, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：10

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2AsbrSummaryLsaConfig`): OSPFv2 Asbr Summary LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Asbr Summary Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_asbr_summary_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_external_lsa(Session, **kwargs):
    """
    创建OSPFv2 External LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 External LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        LsType (str): LSA类型, 类型为：string, 默认值： ExtLsaLsType1, 支持选项有：

            ExtLsaLsType1: AS-External(5)

            ExtLsaLsType2: NSSA(7)

        RouteCount (int): 路由个数, 类型为：number, 取值范围：1-1000000, 默认值：1

        StartNetworkPrefix (str): 起始网络前缀, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：192.0.1.0

        PrefixLength (int): 路由器优先级, 类型为：number, 取值范围：1-32, 默认值：24

        Increment (int): 步长, 类型为：number, 取值范围：0-4294967295, 默认值：1

        MetricType (str): 选项, 类型为：string, 默认值： ExtLsaLsMetricType1, 支持选项有：

            ExtLsaLsMetricType1

            ExtLsaLsMetricType2

        Metric (int): 度量值, 类型为：number, 取值范围：1-16777215, 默认值：10

        ForwardingAddress (str): 转发地址,即：LSA中携带的转发地址, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：192.0.1.0

        RouterTag (int): 路由标签, 类型为：number, 取值范围：0-2147483647, 默认值：0

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        LsaAutomaticConversion (bool): LSA自动转换, 即：当配置的会话为NSSA会话时,Renix会自动将此处配置的外部LSA转换为NSSA-LSA进行发送;当配置的会话为非NSSA会话时,Renix会自动将此处配置的NSSA-LSA转换为外部LSA进行发送, 类型为：bool, 取值范围：True或False, 默认值：True

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2ExternalLsaConfig`): OSPFv2 External LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf External Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_external_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_te_lsa(Session, **kwargs):
    """
    创建OSPFv2 Te LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Te LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        TlvType (str): Tlv类型, 类型为：string, 默认值： LsaLink, 支持选项有：

            LsaRouter

            LsaLink

        RouterId (str): 路由器ID, 类类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        LinkId (str): Link ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        LinkType (str): Link类型, 类型为：string, 默认值： LsaLink, 支持选项有：

            LinkP2P

            LinkMultiaccess

        Instance (int): 实例, 类型为：number, 取值范围：0-16777215, 默认值：1

        Metric (int): 度量值, 类型为：number, 取值范围：0-16777215, 默认值：10

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2TeLsaConfig`): OSPFv2 Te LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Te Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_te_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ospf_te_lsa_link(TeLsa, **kwargs):
    """
    编辑OSPFv2 Te LSA Link参数

    Args:

        TeLsa (:obj:`Ospfv2TeLsaConfig`): OSPFv2 Te LSA对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Te LSA Link对象的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableLocalIp (bool): 使能本端IPv4地址, 类型为：bool, 取值范围：True或False, 默认值：False

        LocalIp (str): 本端IPv4地址, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        EnableRemoteIp (bool): 使能远端IPv4地址, 类型为：bool, 取值范围：True或False, 默认值：False

        RemoteIp (str): 远端IPv4地址, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：0.0.0.0

        EnableGroup (bool): 启动组, 类型为：bool, 取值范围：True或False, 默认值：False

        Group (int): 组ID,类型为：number, 取值范围：0-4294967295, 默认值：1

        EnableMaxBandwidth (bool): 启动最大带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        MaximumBandwidth (int): 最大带宽,类型为：number, 取值范围：0-16777215, 默认值：1000

        EnableReservedBandwidth (bool): 启动预留带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        ReservableBandwidth (int): 预留带宽,类型为：number, 取值范围：0-4294967295, 默认值：1000

        EnableUnreservedBandwidth (bool): 启动未预留带宽, 类型为：bool, 取值范围：True或False, 默认值：False

        UnreservedBandwidth0 (int): 未预留带宽优先级0,类型为：number, 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth1 (int): 未预留带宽优先级1,类型为：number, 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth2 (int): 未预留带宽优先级2,类型为：number, 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth3 (int): 未预留带宽优先级3,类型为：number, 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth4 (int): 未预留带宽优先级4,类型为：number, 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth5 (int): 未预留带宽优先级5,类型为：number, 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth6 (int): 未预留带宽优先级6,类型为：number, 取值范围：0-4294967295, 默认值：0

        UnreservedBandwidth7 (int): 未预留带宽优先级7,类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${TeLsa} | Create Ospf Te Lsa | Session=${Session} | Age=20 |
            | Edit Ospf Te Lsa Link| TeLsa=${TeLsa} | LocalIp=2.2.2.2 |
    """

    result = renix.edit_ospf_te_lsa_link(TeLsa=TeLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_opaque_router_info_lsa(Session, **kwargs):
    """
    创建OSPFv2 Opaque Router Info LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Opaque Router Info LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        AdvertisingRouterId (str): 通告路由器ID即：指定最初发布LSA的路由器ID, 类型为：string, 取值范围：0.0.0.0-255.255.255.255, 默认值：1.1.1.1

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Router Info LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_opaque_router_info_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sr_algorithm_tlv(OpaqueRouterInfoLsa, **kwargs):
    """
    创建OSPFv2 Sr Algorithm Tlv对象

    Args:

        OpaqueRouterInfoLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Router Info LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sr Algorithm Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Algorithms (int): 类型为：number, 默认值：0

    Returns:

        (:obj:`Ospfv2SrAlgorithmTlvConfig`): OSPFv2 Sr Algorithm Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | Create Ospf Sr Algorithm Tlv | OpaqueRouterInfoLsa=${Lsa} |
    """

    result = renix.create_ospf_sr_algorithm_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sr_sid_label_range_tlv(OpaqueRouterInfoLsa, **kwargs):
    """
    创建OSPFv2 Sr Sid Label Range Tlv对象

    Args:

        OpaqueRouterInfoLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Router Info LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sr Sid Label Range Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        SidLabelType (str): 类型为：str, 默认值：Bit20, 取值范围：

            Bit20

            Bit32

        SidLabelBase (int): SID/Label Type为20-Bit Label时，指定起始标签; SID/Label Type为32-Bit SID时，指定起始SID, 类型为：number, 默认值：0, 取值范围：1-4294967295

        SidLabelRange (int): 指定要创建的SID/标签的数量, 类型为：number, 默认值：0, 取值范围：1-16777215

    Returns:

        (:obj:`Ospfv2SidLabelRangeTlvConfig`): OSPFv2 Sr Sid Label Range Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | Create Ospf Sr Sid Label Range Tlv | OpaqueRouterInfoLsa=${Lsa} |
    """

    result = renix.create_ospf_sr_sid_label_range_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sr_srms_preference_tlv(OpaqueRouterInfoLsa, **kwargs):
    """
    创建OSPFv2 Sr Srms Preference Tlv对象

    Args:

        OpaqueRouterInfoLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Router Info LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sr Srms Preference Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Preference (int): 指定路由器作为SR Mapping Server的优先级, 类型为：number, 默认值：1, 取值范围：0-255

    Returns:

        (:obj:`Ospfv2SrmsPreferenceTlvConfig`): OSPFv2 Sr Srms Preference Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | Create Ospf Sr Srms Preference Tlv | OpaqueRouterInfoLsa=${Lsa} |
    """

    result = renix.create_ospf_sr_srms_preference_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_router_info_capability_tlv(OpaqueRouterInfoLsa, **kwargs):
    """
    创建OSPFv2 Router Info Capability Tlv对象

    Args:

        OpaqueRouterInfoLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Router Info LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Router Info Capability Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        InfoCapability (int): 指定TLV值, 类型为：number, 默认值：1, 取值范围：0-255

    Returns:

        (:obj:`Ospfv2RouterInfoCapabilityTlvConfig`): OSPFv2 Router Info Capability Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | Create Ospf Router Info Capability Tlv | OpaqueRouterInfoLsa=${Lsa} |
    """

    result = renix.create_ospf_router_info_capability_tlv(OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sr_fad_tlv(Session, OpaqueRouterInfoLsa, **kwargs):
    """
    创建OSPFv2 Sr Fad Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        OpaqueRouterInfoLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Router Info LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sr Fad Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        FlexAlgo (int): 灵活算法ID, 类型为：number, 默认值：128, 取值范围：128-255

        MetricType (str): 指定算路使用的度量类型, 类型为：str, 默认值：IGP_METRIC, 取值范围：

            IGP_METRIC

            MIN_LINK_DELAY

            TE_METRIC

        CalcType (int): 指定特定IGP算法的计算类型, 类型为：number, 默认值：0, 取值范围：0-127

        Priority (int): 指定该Sub-TLV的优先级, 类型为：number, 默认值：0, 取值范围：0-255

        FlexAlgoSubTlv (list): 选择灵活算法路径计算要遵循的约束条件, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            EXCLUDE_ADMIN

            INCLUDE_ANY_ADMIN

            INCLUDE_ALL_ADMIN

            DEFINITION_FLAGS

            EXCLUDE_SRLG

        ExcludeAdmin (int): 类型为：number, 默认值：0, 取值范围：0-4294967295

        IncludeAnyAdmin (int): 类型为：number, 默认值：0, 取值范围：0-4294967295

        IncludeAllAdmin (int): 类型为：number, 默认值：0, 取值范围：0-4294967295

        DefinitionFlags (list): 类型为：hex int, 默认值：0x80, 取值范围：0-FF

        ExcludeSRLG (list): 类型为：hex int, 默认值：0x10020000, 取值范围：0-4294967295

    Returns:

        (:obj:`Ospfv2FlexAlgoDefinitionTlvConfig`): OSPFv2 Sr Fad Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | Create Ospf Sr Fad Tlv | Session=${Session} | OpaqueRouterInfoLsa=${Lsa} |
    """

    result = renix.create_ospf_sr_fad_tlv(Session=Session, OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sr_node_msd_tlv(Session, OpaqueRouterInfoLsa, **kwargs):
    """
    创建OSPFv2 Sr Node Msd Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        OpaqueRouterInfoLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Router Info LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sr Node Msd Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Flags (list): TLV中的标志位, 类型为：list, 默认值：UNKNOWN, 取值范围：

            UNKNOWN

            MAX_SEG_LEFT

            MAX_END_POP

            MAX_T_INSERT

            MAX_T_ENCAPS

            MAX_END_D

        MaxSegmentLeft (int): 在应用与SID关联的SRv6 Endpoint Function指令之前，指定接收报文的SRH中SL（Segment Left）字段的最大值, 类型为：number, 默认值：0, 取值范围：0-255

        MaxEndPop (int): 指定SRH栈的顶端SRH中SID的最大数量, 类型为：number, 默认值：8, 取值范围：0-255

        MaxInsert (int): 指定执行T.Insert行为时可包含SID的最大数量, 类型为：number, 默认值：8, 取值范围：0-255

        MaxEncap (int): 指定执行T.Encap行为时可包含SID的最大数量, 类型为：number, 默认值：8, 取值范围：0-255

        MaxEndD (int): 指定执行End.DX6和End.DT6功能时，SRH中SID的最大数量, 类型为：number, 默认值：8, 取值范围：0-255

    Returns:

        (:obj:`Ospfv2SrNodeMsdTlvConfig`): OSPFv2 Sr Node Msd Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | Create Ospf Sr Node Msd Tlv | Session=${Session} | OpaqueRouterInfoLsa=${Lsa} |
    """

    result = renix.create_ospf_sr_node_msd_tlv(Session=Session, OpaqueRouterInfoLsa=OpaqueRouterInfoLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_opaque_extended_prefix_lsa(Session, **kwargs):
    """
    创建OSPFv2 Opaque Extended Prefix LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Opaque Extended Prefix LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Scope (str): LSA的泛洪区域, 类型为：string, 默认值：AreaLocal, 取值范围：

            LinkLocal

            AreaLocal

            AreaSystemWide

        AdvertisingRouterId (str): 通告路由器ID, 类型为：string, 默认值：192.0.0.1, 取值范围：有效的ipv4地址

        Instance (int): 指定LSA中Instance字段的值, 类型为：number, 默认值：1, 取值范围：0-16777215

        Options (list): 类型为：list, 默认值：['NONTBIT', 'EBIT'], 取值范围：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): LSA的老化时间。单位为秒, 类型为：number, 默认值：1, 取值范围：0-3600

        SequenceNumber (int): LSA的序列号, 类型为：number, 默认值：0x80000001, 取值范围：0-4294967295

        Checksum (bool): LSA的校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2OpaqueSrExtPrefixLsaConfig`): OSPFv2 Opaque Extended Prefix LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Opaque Extended Prefix Lsa | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_opaque_extended_prefix_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_ext_prefix_range_tlv(Session, OpaqueExtendedPrefixLsa, **kwargs):
    """
    创建OSPFv2 Ext Prefix Range Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        OpaqueExtendedPrefixLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Extended Prefix LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Ext Prefix Range Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        PrefixLength (int): 前缀长度, 类型为：number, 取值范围：0-32, 默认值：24

        AF (str): 前缀的地址族, 类型为：string, 默认值：IPv4Unicast, 取值范围：

            IPv4Unicast

        ExtendedPrefixRange (int): 要生成的前缀的数量, 类型为：number, 取值范围：1-65535, 默认值：1

        ExtendedPrefixFlags (list): 包含在TLV中的标志位, 类型为：list, 默认值： NoneFlag, 支持选项有：

            NoneFlag

            IAInterArea

        AddressPrefix (str): 起始地址前缀, 类型为：string, 默认值：192.0.1.0, 取值范围：有效的ipv4地址

    Returns:

        (:obj:`Ospfv2ExtPrefixRangeTlvConfig`): OSPFv2 Ext Prefix Range Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Extended Prefix Lsa | Session=${Session} | Age=20 |
            | Create Ospf Ext Prefix Range Tlv | Session=${Session} | OpaqueExtendedPrefixLsa=${Lsa} |
    """

    result = renix.create_ospf_ext_prefix_range_tlv(Session=Session, OpaqueExtendedPrefixLsa=OpaqueExtendedPrefixLsa,
                                                    **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_ext_prefix_tlv(Session, OpaqueExtendedPrefixLsa, **kwargs):
    """
    创建OSPFv2 Ext Prefix Range Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        OpaqueExtendedPrefixLsa (:obj:`Ospfv2OpaqueRouterInfoLsaConfig`): OSPFv2 Opaque Extended Prefix LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Ext Prefix Range Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        RouteType (str): 起始地址前缀, 类型为：string, 默认值：Unspecified, 取值范围：

            Unspecified

            IntraArea

            InterArea

            AsExternal

            NssaExternal

        AddressPrefix (str): 起始地址前缀, 类型为：string, 默认值：192.0.1.0, 取值范围：有效的ipv4地址

        PrefixLength (int): 要生成的前缀的数量, 类型为：number, 取值范围：0-32, 默认值：24

        PrefixTlvBlockCount (int): 要生成的前缀的数量, 类型为：number, 取值范围：0-32, 默认值：1

        AF (str): 起始地址前缀, 类型为：string, 默认值：IPv4Unicast, 取值范围：

            IPv4Unicast

        ExtendedPrefixFlags (list): 包含在TLV中的标志位, 类型为：list, 默认值： NoneFlag, 支持选项有：

            NoneFlag

            AttachFlag

            NodeFlag

    Returns:

        (:obj:`Ospfv2ExtPrefixTlvConfig`): OSPFv2 Ext Prefix Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Extended Prefix Lsa | Session=${Session} | Age=20 |
            | Create Ospf Ext Prefix Range Tlv | Session=${Session} | OpaqueExtendedPrefixLsa=${Lsa} |
    """

    result = renix.create_ospf_ext_prefix_tlv(Session=Session, OpaqueExtendedPrefixLsa=OpaqueExtendedPrefixLsa,
                                              **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sid_label_binding_sub_tlv(Session, Tlv, **kwargs):
    """
    创建OSPFv2 Sid Label Binding Sub Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        Tlv (:obj:`Ospfv2ExtPrefixTlvConfig`): OSPFv2 Ext Prefix Range Tlv / Ospfv2 Ext Prefix Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sid Label Binding Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        SidLabelBindingTlvFlags (list): 包含在TLV中的标志位, 类型为：list, 默认值： NoneFlag, 取值范围：

            NoneFlag

            MirroringContext

        Weight (int): 进行负载均衡时的权重, 类型为：number, 取值范围：0-255, 默认值：0

        MultiTopologyId (int): 指定MT-ID的值, 类型为：number, 取值范围：0-255, 默认值：0

        SidLabelType (str): 标识符（SID或者标签）, 类型为：string, 默认值：Bit20, 取值范围：

            Bit20

            Bit32

        SidLabel (int): SID/Label Type为20-Bit Label时，指定标签值; SID/Label Type为32-Bit SID时，指定SID, 类型为：number, 取值范围：0-255, 默认值：16

    Returns:

        (:obj:`Ospfv2SidLabelBindingSubTlvConfig`): OSPFv2 Sid Label Binding Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | Create Ospf Ext Prefix Range Tlv | OpaqueRouterInfoLsa=${Lsa} |
            | Create Ospf Sid Label Binding Sub Tlv | Session=${Session} | Tlv=${Tlv} |
    """

    result = renix.create_ospf_sid_label_binding_sub_tlv(Session=Session, Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_prefix_sid_sub_tlv(Session, Tlv, **kwargs):
    """
    创建OSPFv2 Prefix Sid Sub Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        Tlv (:obj:`Ospfv2ExtPrefixTlvConfig`): OSPFv2 Ext Prefix Range Tlv / Ospfv2 Ext Prefix Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Prefix Sid Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        PrefixSidTlvFlags (list): 包含在TLV中的标志位, 类型为：list, 默认值： NoPhp, 取值范围：

            NoPhp

            MappingServer

            ExplicitNull

            ValueIndex

            LacalGlobal

        MultiTopologyId (int): 指定MT-ID的值, 类型为：number, 取值范围：0-255, 默认值：0

        Algorithm (int): 计算到其他节点/前缀的可达信息的算法, 类型为：number, 默认值：0

        SidIndexLabel (int): Flags中包含Value/Index时，指定标签值; Flags中不包含Value/Index时，指定SID/Label范围内的标签偏移值, 类型为：number, 取值范围：0-4294967295, 默认值：0

        SidIndexLabelStep (int): SidIndexLabel跳变, 类型为：number, 取值范围：0-4294967295, 默认值：1

    Returns:

        (:obj:`Ospfv2PrefixSidSubTlvConfig`): OSPFv2 Prefix Sid Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | Create Ospf Ext Prefix Range Tlv | OpaqueRouterInfoLsa=${Lsa} |
            | Create Ospf Prefix Sid Sub Tlv | Session=${Session} | Tlv=${Tlv} |
    """

    result = renix.create_ospf_prefix_sid_sub_tlv(Session=Session, Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sr_fapm_sub_tlv(Tlv, **kwargs):
    """
    创建OSPFv2 Sr Fapm Sub Tlv对象

    Args:

        Tlv (:obj:`Port`): OSPFv2 Ext Prefix Range Tlv / Ospfv2 Ext Prefix Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sr Fapm Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Algorithm (int): 灵活算法ID, 类型为：number, 取值范围：128-255, 默认值：128

        Flags (int): 单字节值, 类型为：number, 取值范围：0-255, 默认值：0

        Metric (int): 度量值, 类型为：number, 取值范围：0-4294967295, 默认值：0

    Returns:

        (:obj:`Ospfv2SrFapmSubTlvConfig`): OSPFv2 Sr Fapm Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | Create Ospf Ext Prefix Range Tlv | OpaqueRouterInfoLsa=${Lsa} |
            | Create Ospf Sr Fapm Sub Tlv | Tlv=${Tlv} |
    """

    result = renix.create_ospf_sr_fapm_sub_tlv(Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_bier_sub_tlv(Tlv, **kwargs):
    """
    创建OSPFv2 Bier Sub Tlv对象

    Args:

        Tlv (:obj:`Port`): OSPFv2 Ext Prefix Range Tlv / Ospfv2 Ext Prefix Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Bier Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        TlvType (int): Type字段值, 类型为：number, 取值范围：0-255, 默认值：9

        SubDomainId (int): BIER子域ID, 类型为：number, 取值范围：1-255, 默认值：1

        MtId (int): 多拓扑ID, 类型为：number, 取值范围：1-255, 默认值：1

        BfrId (int): BFR（Bit Forwarding Router，比特转发路由器）ID, 类型为：number, 取值范围：1-65535, 默认值：1

        Bar (int): BIER算法, 类型为：number, 取值范围：0-255, 默认值：0

        Ipa (int): IGP算法, 类型为：number, 取值范围：0-255, 默认值：0

    Returns:

        (:obj:`Ospfv2BierSubTlvConfig`): OSPFv2 Bier Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | Create Ospf Ext Prefix Range Tlv | OpaqueRouterInfoLsa=${Lsa} |
            | Create Ospf Bier Sub Tlv | Tlv=${Tlv} |
    """

    result = renix.create_ospf_bier_sub_tlv(Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_bier_mpls_encap_sub_tlv(Tlv, **kwargs):
    """
    创建OSPFv2 Bier Mpls Encap Sub Tlv对象

    Args:

        Tlv (:obj:`Port`): OSPFv2 Bier Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Bier Mpls Encap Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        TlvType (int): Type字段值, 类型为：number, 取值范围：0-255, 默认值：10

        MaxSi (int): 最大Set ID, 类型为：number, 取值范围：1-255, 默认值：1

        Label (int): 标签范围中的起始标签值, 类型为：number, 取值范围：0-1048575, 默认值：100

    Returns:

        (:obj:`Ospfv2BierMplsEncapSubTlvConfig`): OSPFv2 Bier Mpls Encap Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Router Info Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | Create Ospf Ext Prefix Range Tlv | OpaqueRouterInfoLsa=${Lsa} |
            | ${SubTlv}| Create Ospf Bier Sub Tlv | Tlv=${Tlv} |
            | Create Ospf Bier Mpls Encap Sub Tlv | Tlv=${SubTlv} |
    """

    result = renix.create_ospf_bier_mpls_encap_sub_tlv(Tlv=Tlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_opaque_extended_link_lsa(Session, **kwargs):
    """
    创建OSPFv2 Opaque Extended Link LSA对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): 创建的Opaque Extended Link LSA的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Scope (str): Tlv类型, 类型为：string, 默认值： AreaLocal, 支持选项有：

            LinkLocal

            AreaLocal

            AreaSystemWide

        AdvertisingRouterId (str): 通告路由器ID, 类型为：string, 取值范围：有效的ipv4地址, 默认值：192.0.0.1

        Instance (int): 实例, 类型为：number, 取值范围：0-16777215, 默认值：1

        Options (list): 选项, 类型为：list, 默认值： ['NONTBIT', 'EBIT'], 支持选项有：

            NONTBIT

            TOSBIT

            EBIT

            MCBIT

            NPBIT

            EABIT

            DCBIT

            OBIT

            DNBIT

        Age (int): 路由器优先级, 类型为：number, 取值范围：0-3600, 默认值：0

        SequenceNumber (int): 序列号, 类型为：hex number, 取值范围：0x1-0xFFFFFFFF, 默认值：0x80000001

        Checksum (bool): 校验和, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Ospfv2OpaqueSrExtLinkLsaConfig`): OSPFv2 Opaque Extended Link LSA对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | Create Ospf Opaque Extended Link LSA | Session=${Session} | Age=20 |
    """

    result = renix.create_ospf_opaque_extended_link_lsa(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_extended_link_tlv(OpaqueExtendedLinkLsa, **kwargs):
    """
    创建OSPFv2 Extended link Tlv对象

    Args:

        OpaqueExtendedLinkLsa (:obj:`Ospfv2OpaqueSrExtLinkLsaConfig`): OSPFv2 Opaque Router Info LSA列表, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Extended link Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        LinkType (str): 前缀的地址族, 类型为：string, 默认值：P2P, 取值范围：

            P2P

            TRANSITNETWORK

            STUBNETWORK

            VIRTUALLINK

        LinkId (str): 起始地址前缀, 类型为：string, 默认值：0.0.0.0, 取值范围：有效的ipv4地址

        LinkData (str): 起始地址前缀, 类型为：string, 默认值：0.0.0.0, 取值范围：有效的ipv4地址

    Returns:

        (:obj:`Ospfv2ExtendedLinkTlvConfig`): OSPFv2 Extended link Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Extended Link Lsa | Session=${Session} | Age=20 |
            | Create Ospf Extended link Tlv | OpaqueExtendedLinkLsa=${Lsa} |
    """

    result = renix.create_ospf_extended_link_tlv(OpaqueExtendedLinkLsa=OpaqueExtendedLinkLsa, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_adj_sid_sub_tlv(Session, ExtendedLinkTlv, **kwargs):
    """
    创建OSPFv2 Adj Sid Sub Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        ExtendedLinkTlv (:obj:`Ospfv2ExtendedLinkTlvConfig`): OSPFv2 Extended Link Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Adj Sid Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Flags (list): 选项, 类型为：list, 默认值： ['ValueIndexFlag', 'LocalGlobalFlag', 'NONE'], 支持选项有：

            BackupFlag

            ValueIndexFlag

            LocalGlobalFlag

            GroupFlag

            PersistentFlag

            NONE

        MultiTopologyId (int): 最大Set ID, 类型为：number, 取值范围：0-255, 默认值：0

        Weight (int): 最大Set ID, 类型为：number, 取值范围：0-255, 默认值：0

        SidLabel (int): 最大Set ID, 类型为：number, 取值范围：1-255, 默认值：1

    Returns:

        (:obj:`Ospfv2AdjSidSubTlvConfig`): OSPFv2 Adj Sid Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Extended Link Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | | Create Ospf Extended link Tlv | OpaqueExtendedLinkLsa=${Lsa} |
            | Create Ospf Adj Sid Sub Tlv | Session=${Session} | ExtendedLinkTlv=${Tlv} |
    """

    result = renix.create_ospf_adj_sid_sub_tlv(Session=Session, ExtendedLinkTlv=ExtendedLinkTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_lan_adj_sid_sub_tlv(Session, ExtendedLinkTlv, **kwargs):
    """
    创建OSPFv2 Lan Adj Sid Sub Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        ExtendedLinkTlv (:obj:`Ospfv2ExtendedLinkTlvConfig`): OSPFv2 Extended Link Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Lan Adj Sid Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Flags (list): 选项, 类型为：list, 默认值： ['ValueIndexFlag', 'LocalGlobalFlag', 'NONE'], 支持选项有：

            BackupFlag

            ValueIndexFlag

            LocalGlobalFlag

            GroupFlag

            PersistentFlag

            NONE

        MultiTopologyId (int): 最大Set ID, 类型为：number, 取值范围：0-255, 默认值：0

        Weight (int): 最大Set ID, 类型为：number, 取值范围：0-255, 默认值：0

        NeighborId (str): 起始地址前缀, 类型为：string, 默认值：0.0.0.0, 取值范围：有效的ipv4地址

        SidLabel (int): 最大Set ID, 类型为：number, 取值范围：1-255, 默认值：1

    Returns:

        (:obj:`Ospfv2LanSidSubTlvConfig`): OSPFv2 Lan Adj Sid Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Extended Link Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | | Create Ospf Extended link Tlv | OpaqueExtendedLinkLsa=${Lsa} |
            | Create Ospf Lan Adj Sid Sub Tlv | Session=${Session} | Tlv=${Tlv} |
    """

    result = renix.create_ospf_lan_adj_sid_sub_tlv(Session=Session, ExtendedLinkTlv=ExtendedLinkTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_sr_link_msd_sub_tlv(Session, ExtendedLinkTlv, **kwargs):
    """
    创建OSPFv2 Sr Link Msd Sub Tlv对象

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象列表, 类型为：object

        ExtendedLinkTlv (:obj:`Ospfv2ExtendedLinkTlvConfig`): OSPFv2 Extended Link Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Sr Link Msd Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        Flags (list): 包含在TLV中的标志位, 类型为：list, 默认值： UNKNOWN, 支持选项有：

            UNKNOWN

            MAX_SEG_LEFT

            MAX_END_POP

            MAX_T_INSERT

            MAX_T_ENCAPS

            MAX_END_D

        MaxSegmentLeft (int): 指定接收报文的SRH中SL（Segment Left）字段的最大值, 类型为：number, 取值范围：0-255, 默认值：8

        MaxEndPop (int): 指定SRH栈的顶端SRH中SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaxInsert (int): 指定执行T.Insert行为时可包含SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaxEncap (int): 指定执行T.Encap行为时可包含SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

        MaxEndD (int): 指定执行End.DX6和End.DT6功能时，SRH中SID的最大数量, 类型为：number, 取值范围：0-255, 默认值：8

    Returns:

        (:obj:`Ospfv2SrLinkMsdSubTlvConfig`): OSPFv2 Sr Link Msd Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Extended Link Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | | Create Ospf Extended link Tlv | OpaqueExtendedLinkLsa=${Lsa} |
            | Create Ospf Sr Link Msd Sub Tlv | Session=${Session} | Tlv=${Tlv} |
    """

    result = renix.create_ospf_sr_link_msd_sub_tlv(Session=Session, ExtendedLinkTlv=ExtendedLinkTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ospf_custom_sub_tlv(SrLinkMsdSubTlv, **kwargs):
    """
    创建OSPFv2 Custom Sub Tlv对象

    Args:

        SrLinkMsdSubTlv (:obj:`Ospfv2SrLinkMsdSubTlvConfig`): OSPFv2 Sr Link Msd Sub Tlv对象, 类型为：object

    Keyword Args:

        Name (str): 创建的OSPFv2 Custom Sub Tlv的名称, 类型为：string

        Enable (bool): 使能, 类型为：bool, 取值范围：True或False, 默认值：True

        SubType (int): 类型为：number, 取值范围：0-255, 默认值：0

        SubValue (int): 类型为：number, 取值范围：0-255, 默认值：8

    Returns:

        (:obj:`Ospfv2CustomMsdSubTlvConfig`): OSPFv2 Custom Sub Tlv对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${Lsa} | Create Ospf Opaque Extended Link Lsa | Session=${Session} | Age=20 |
            | ${Tlv} | | Create Ospf Extended link Tlv | OpaqueExtendedLinkLsa=${Lsa} |
            | ${SubTlv} | Create Ospf Sr Link Msd Sub Tlv | SrLinkMsdSubTlv=${Tlv} |
            | Create Ospf Custom Sub Tlv | SrLinkMsdSubTlv = ${SubTlv} |
    """

    result = renix.create_ospf_custom_sub_tlv(SrLinkMsdSubTlv=SrLinkMsdSubTlv, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ospf_router_from_lsa(Lsa):
    """
    获取OSPF LSA对应的绑定流源或目的端点对象

    Args:

        Lsa (:obj:`Port`): 测试仪表OSPFv2或OSPFv3 LSA对象, 类型为：object


    Returns:

        OSPFv2或OSPFv3 LSA对应的绑定流源或目的端点对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ospf | Port=${Port} |
            | ${RouterLsa} | Create Ospf Router Lsa | Session=${Session} | Age=20 |
            | ${Point} | Get Ospf Router From Lsa | Lsa=${RouterLsa} |
    """

    result = renix.get_ospf_router_from_lsa(Lsa=Lsa)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def establish_ospf(Sessions):
    """
    建立OSPFv2协议会话

    Args:

        Sessions (list(:obj:`OspfRouter`)): OSPFv2协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Establish Ospf | Sessions=${Sessions} |
    """

    result = renix.establish_ospf(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def grace_restart_ospf(Sessions):
    """
    平滑重启OSPFv2协议会话

    Args:

        Sessions (list(:obj:`OspfRouter`)): OSPFv2协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Grace Restart Ospf | Sessions=${Sessions} |
    """

    result = renix.grace_restart_ospf(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def advertise_ospf_lsa(Sessions=None, Type=None, Lsa=None):
    """
    通告OSPFv2协议会话lsa

    Args:

        Sessions (list(:obj:`OspfRouter`)): OSPFv2协议会话对象列表, 类型为：list

        Type (str): OSPFv2 lsa类型, 类型为：string, 支持的lsa类型：

            Router

            Network

            Summary

            AsbrSummary

            External

        Lsa (list): OSPFv2 lsa列表, 类型为：list, 当Type=None时参数生效


    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Advertise Ospf Lsa | Sessions=${Sessions} | Type=router |
            | Advertise Ospf Lsa | Sessions=${Sessions} | Lsa=${Lsas} |
    """

    result = renix.advertise_ospf_lsa(Sessions=Sessions, Type=Type, Lsa=Lsa)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def withdraw_ospf_lsa(Sessions=None, Type=None, Lsa=None):
    """
    撤销OSPFv2协议会话lsa

    Args:

        Sessions (list(:obj:`OspfRouter`)): OSPFv2协议会话对象列表, 类型为：list

        Type (str): OSPFv2 lsa类型, 类型为：string, 支持的lsa类型：

            Router

            Network

            Summary

            AsbrSummary

            External

        Lsa (list): OSPFv2 lsa列表, 类型为：list, 当Type=None时参数生效

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Withdraw Ospf Lsa | Sessions=${Sessions} | Type=router |
            | Withdraw Ospf Lsa | Sessions=${Sessions} | Lsa=${Lsas} |
    """

    result = renix.withdraw_ospf_lsa(Sessions=Sessions, Type=Type, Lsa=Lsa)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ospf_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待OSPFv2或OSPFv3协议会话达到指定状态

    Args:

        Sessions (list(:obj:`OspfRouter`)) or (list(:obj:`Ospfv3Router`)): OSPFv2或OSPFv3协议会话对象列表, 类型为：list

        State (list): 等待OSPFv2协议会话达到的状态, 类型为：string, 默认值：达到DR或BACKUP或DROTHER, 支持下列状态：

            NOTSTART

            P2P

            WAITING

            DR

            BACKUP

            DROTHER

            DISABLE

            DOWN

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ospf State | Sessions=${Sessions} | State=DR | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ospf_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ospf_adjacency_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待OSPFv2或OSPFv3协议会话达到指定邻接状态

    Args:

        Sessions (list(:obj:`OspfRouter`)) or (list(:obj:`Ospfv3Router`)): OSPFv2或OSPFv3协议会话对象列表, 类型为：list

        State (list): 等待OSPFv2协议会话达到的邻接状态, 类型为：string, 默认值：FULL, 支持下列状态：

            DOWN

            INIT

            TWOWAY

            EXSTART

            EXCHANGE

            LOADING

            FULL

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话邻接状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ospf Adjacency State | Sessions=${Sessions} | State=FULL | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ospf_adjacency_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ospf_statistic(Session=None, StaItems=None):
    """
    获取OSPFv2协议会话统计结果

    Args:

        Session (:obj:`OspfRouter`): OSPFv2协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，默认为:None 表示获取所有统计项, 类型为：list，目前支持的统计项

            RouterState

            AdjacencyState

            TxHello

            RxHello

            TxDd

            RxDd

            TxRouterLsa

            RxRouterLsa

            TxNetworkLsa

            RxNetworkLsa

            TxSummaryLsa

            RxSummaryLsa

            TxAsbrSummaryLsa

            RxAsbrSummaryLsa

            TxAsExternalLsa

            RxAsExternalLsa

            TxNssaLsa

            RxNssaLsa

            TxTeLsa

            RxTeLsa

            TxOpaqueRouterInfoLsa

            RxOpaqueRouterInfoLsa

            TxOpaqueExtendedPrefixLsa

            RxOpaqueExtendedPrefixLsa

            TxOpaqueExtendedLinkLsa

            RxOpaqueExtendedLinkLsa

            TxRequest

            RxRequest

            TxUpdate

            RxRequest

            TxAck

            RxAck

    Returns:

        dict: eg::

            {
                'AdjacencyState': 'Full',
                'TxUpdate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ospfv2SessionResultPropertySet |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ospf Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ospf_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ospf_port_config(Ports, **kwargs):
    """
    修改Ospf端口统计对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        TransmitRate (int): OSPFv2 Message Tx Rate (messages/second), 取值范围：1-9000, 默认值：100

        SessionOutstanding (int): OSPFv2 Session Outstanding, 取值范围：1-1000, 默认值：20

        UpdateMsgTransmitRate (int): Deprecated. OSPFv2 Update Message Tx Rate (messages/second), 取值范围：1-9000, 默认值：10

        EnableLoop (bool): Enable Loop Back, 默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Ospf Port Config | Ports=${Ports} | TransmitRate=100 |
    """

    result = renix.edit_ospf_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result





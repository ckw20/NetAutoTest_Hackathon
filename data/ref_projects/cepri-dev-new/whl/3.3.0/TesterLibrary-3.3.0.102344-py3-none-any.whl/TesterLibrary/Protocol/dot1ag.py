import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


def create_dot1ag(Port, **kwargs):
    """
    创建802.1ag会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): 802.1ag会话名称, 类型为：string

        Enable (bool): 使能802.1ag会话, 类型为：bool, 取值范围：True或False, 默认值：True

    Returns:

        (:obj:`Dot1ag`): 802.1ag会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Dot1ag | Port=${Port} |

    """

    result = renix.create_dot1ag(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dot1ag_link_trace(Session, **kwargs):
    """
    修改802.1ag Link Trace对象

    Args：

        Session (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

    Keyword Args:

        TxType (str): 发送方式，默认值：SINGLE, 取值范围：

            SINGLE

            MULTIPLE

        TxRate (str): 发送速率，默认值：TXRATE_10_PER_SEC, 取值范围：

            TXRATE_10_PER_SEC

            TXRATE_1_PER_SEC

            TXRATE_1_PER_MIN

            TXRATE_1_PER_10MIN

        InitTransactionId (int): 初始Transaction ID，默认值：1, 取值范围：uint32 in [0,4294967295]

        InitTtl (int): 初始TTL，默认值：64, 取值范围：uint8 in [1,255]

    Returns:

        (:obj:`Dot1agLinkTraceConfig`): 802.1ag Link Trace对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dot1ag Link Trace | Session=${Session} | InitTtl=255 |
    """

    result = renix.edit_dot1ag_link_trace(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_dot1ag_loopback(Session, **kwargs):
    """
    修改802.1ag Loopback对象

    Args：

        Session (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

    Keyword Args:

        TxType (str): 发送方式，默认值：SINGLE, 取值范围：

            SINGLE

            MULTIPLE

        TxRate (str): 发送速率，默认值：TXRATE_10_PER_SEC, 取值范围：

            TXRATE_10_PER_SEC

            TXRATE_1_PER_SEC

            TXRATE_1_PER_MIN

            TXRATE_1_PER_10MIN

        InitTransactionId (int): 初始Transaction ID，默认值：1, 取值范围：uint32 in [0,4294967295]

    Returns:

        (:obj:`Dot1agLoopBackConfig`): 802.1ag Loopback对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit Dot1ag Loopback | Session=${Session} | InitTransactionId=50 |
    """

    result = renix.edit_dot1ag_loopback(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot1ag_ma(**kwargs):
    """
    创建802.1ag Ma对象

    Keyword Args:

        OperationMode (str): 模式，默认值：IEEE, 取值范围：

            IEEE

        MaidType (str): MA ID类型，默认值：STRING, 取值范围：

            PRI_VID

            STRING

        MdName (str): MD名称，默认值："", 取值范围：string

        MdLevel (str): MD级别，默认值：Level1, 取值范围：

            Level0

            Level1

            Level2

            Level3

            Level4

            Level5

            Level6

            Level7

        PrimaryVid (int): 首选VID，默认值：100, 取值范围：uint16 in [0,4095]

        CcPeriod (str): CC周期，默认值：CC_1S, 取值范围：

            CC_3MS

            CC_10MS

            CC_100MS

            CC_1S

            CC_10S

            CC_1MIN

            CC_10MIN

        LckPeriod (str): LCK周期，默认值：LCK_1S, 取值范围：

            LCK_1S

            LCK_1MIN

        CcPriority (str): CC优先级，默认值：Level0, 取值范围：

            Level0

            Level1

            Level2

            Level3

            Level4

            Level5

            Level6

            Level7

        LbPriority (str): LB优先级，默认值：Level0, 取值范围：

            Level0

            Level1

            Level2

            Level3

            Level4

            Level5

            Level6

            Level7

        LtPriority (str): LT优先级，默认值：Level0, 取值范围：

            Level0

            Level1

            Level2

            Level3

            Level4

            Level5

            Level6

            Level7

    Returns:

        (:obj:`Dot1agMaConfig`): 802.1ag Ma对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot1ag Ma | PrimaryVid=200 |
    """

    result = renix.create_dot1ag_ma(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot1ag_mp(Session, **kwargs):
    """
    创建802.1ag Mp对象

    Keyword Args:

        SelectMa (obj): 关联MA，e.g: SelectMa=config_ma (config_ma = create_dot1ag_ma())

        MpType (str): MP类型，默认值：MEP, 取值范围：

            MEP

        Rdi (str): RDI，默认值：AUTO, 取值范围：

            AUTO

            OFF

            ON

        EnableLbResponse (bool): 使能Lb Response, 类型为：bool, 取值范围：True或False, 默认值：True

        EnableLtResponse (bool): 使能Lt Response, 类型为：bool, 取值范围：True或False, 默认值：True

        MpId (int): MP ID，默认值：1, 取值范围：uint32 in [1,8191]

        EnableOverrideMdLevel (bool): 使能Override Md Level, 类型为：bool, 取值范围：True或False, 默认值：False

        OverrideMdLevel (str): 重写MD级别，默认值：Level1, 取值范围：

            Level0

            Level1

            Level2

            Level3

            Level4

            Level5

            Level6

            Level7

        EnableOverrideCcPeriod (bool): 使能Override Cc Period, 类型为：bool, 取值范围：True或False, 默认值：False

        OverrideCcPeriod (str): 重写CC周期，默认值：CC_1S, 取值范围：

            CC_3MS

            CC_10MS

            CC_100MS

            CC_1S

            CC_10S

            CC_1MIN

            CC_10MIN

        IsCcmRunning (bool): Whether CCM is running, 取值范围：True或False, 默认值：False

        IsLtmRunning (bool): Whether LTM is running, 取值范围：True或False, 默认值：False

        IsLbmRunning (bool): Whether LBM is running, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`Dot1agMpConfig`): 802.1ag Mp对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot1ag Mp | Session=${Session} | Rdi=ON |
    """

    result = renix.create_dot1ag_mp(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot1ag_org_specific_tlv(Session, **kwargs):
    """
    创建802.1ag Org Specific Tlv对象

    Keyword Args:

        OrgUniqueId (list): 组织唯一ID，默认值：[0,0,0], 取值范围：列表元素为0-255的十进制数

        SubType (int): 子类型，默认值：0, 取值范围：uint8

        Data (list): TLV数据，默认值：[], 取值范围：列表长度为0-250，元素取值0-255的十进制数

    Returns:

        (:obj:`Dot1agOrgSpecificTlv`): 802.1ag Org Specific Tlv, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot1ag Org Specific Tlv | Session=${Session} | SubType=1 |
    """

    result = renix.create_dot1ag_org_specific_tlv(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot1ag_custom_mp(**kwargs):
    """
    创建802.1ag Custom Mp对象

    Keyword Args:

        CustomTargetMacAddr (str): 默认值："", 取值范围：string

    Returns:

        (:obj:`Dot1agCustomMpConfig`): 802.1ag Custom Mp, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot1ag Custom Mp | CustomTargetMacAddr=00:00:00:01:01:01 |
    """

    result = renix.create_dot1ag_custom_mp(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_dot1ag_expected_mp(Ma, **kwargs):
    """
    创建802.1ag Expected Mp对象

    Keyword Args:

        MpId (int): MEP ID，默认值：1, 取值范围：uint32 in [1,8191]

        MacAddress (str): 默认值："00:00:00:00:00:01", 取值范围：Mac Address

    Returns:

        (:obj:`Dot1agExpectedMpConfig`): 802.1ag Expected Mp, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Create Dot1ag Expected Mp | Ma=${Ma} | MacAddress=00:00:00:01:01:01 |
    """

    result = renix.create_dot1ag_expected_mp(Ma=Ma, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_cc_dot1ag(Sessions):
    """
    启动Cc

    Args:

        Sessions (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Cc Dot1ag | Sessions=${Sessions} |
    """

    result = renix.start_cc_dot1ag(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_link_trace_dot1ag(Sessions, **kwargs):
    """
    启动Link Trace

    Args:

        Sessions (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

    Keyword Args:

        MsgType (str): Message type, 默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MpMaps (str): MP source and target map list, 默认值："", 取值范围：string

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Link Trace Dot1ag | Sessions=${Sessions} | MpMaps=['Dot1agMpConfig_1,00:00:00:00:00:01', 'Dot1agMpConfig_2,00:00:00:00:00:02'] |
    """

    result = renix.start_link_trace_dot1ag(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_loopback_dot1ag(Sessions, **kwargs):
    """
    启动LoopBack

    Args:

        Sessions (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

    Keyword Args:

        MsgType (str): Message type, 默认值：MULTICAST, 取值范围：

            MULTICAST

            UNICAST

        MpMaps (str): MP source and target map list, 默认值："", 取值范围：string

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start LoopBack Dot1ag | Sessions=${Sessions} |
    """

    result = renix.start_loopback_dot1ag(Sessions=Sessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_cc_dot1ag(Sessions):
    """
    停止Cc

    Args:

        Sessions (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Cc Dot1ag | Sessions=${Sessions} |
    """

    result = renix.stop_cc_dot1ag(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_link_trace_dot1ag(Sessions, MpObjects):
    """
    停止Link Trace

    Args:

        Sessions (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

        MpObjects (list): MP object list, 默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Link Trace Dot1ag | Sessions=${Sessions} |
    """

    result = renix.stop_link_trace_dot1ag(Sessions=Sessions, MpObjects=MpObjects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_loopback_dot1ag(Sessions, MpObjects):
    """
    停止LoopBack

    Args:

        Sessions (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

        MpObjects (list): MP object list, 默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop LoopBack | Sessions=${Sessions} |
    """

    result = renix.stop_loopback_dot1ag(Sessions=Sessions, MpObjects=MpObjects)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_dot1ag_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待802.1ag会话达到指定状态

    Args:

        Session (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

        State (list): 等待802.1ag会话组达到的状态, 类型为：string, 默认值：RUNNING, 支持下列状态：

            DISABLED

            IDLE

            RUNNING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Dot1ag State | Sessions=${Sessions} | State=RUNNING | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_dot1ag_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_dot1ag_mp_stats(Session=None, StaItems: list = None):
    """
    获取802.1ag session 统计结果

    Args:

        Session (:obj:`Dot1ag`): 802.1ag会话对象, 类型为：object / list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            MepId

            RemoteMeps

            CcmTimeout

            CcmUnexpectMaid

            CcmUnexpectMdLevel

            TxCcm300Hz

            TxCcm10ms

            TxCcm100ms

            TxCcm1s

            TxCcm10s

            TxCcm1min

            TxCcm10min

            RxCcm

            LastTxCcmSeqNum

            LbTimeout

            LbTransIdMismatch

            TxLbm

            RxLbm

            TxLbr

            RxLbr

            TxLtm

            RxLtm

            TxLtr

            RxLtr

            LtTimeout

    Returns:

        dict: eg::

            {
                'TxLtr': 10,
                'RxLtr': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Dot1agMpStats |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Dot1ag Mp stats | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_dot1ag_mp_stats(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------openflow-------------------------------------
def create_openflow_switch(Port, **kwargs):
    """
    创建openflow switch协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    keyword Args:

        TcpPort (int): TCP Port, 默认值：6633，取值范围：1-65535

        ConnectionType (str): Connection Type, 默认值：TCP，取值范围：

            TCP

            TCP_TLS

        EnableEchoRequest (bool): Enable Echo Request, 默认值：False，取值范围：

            True

            False

        EchoRequestInterval (int): Echo Request Interval (sec), 默认值：5，取值范围：0-4294967295

        OpenFlowVersion (str): OpenFlow Version, 默认值：v1_3，取值范围：

            v1_3

        DPID (int): DPID, 默认值：0，取值范围：0-(2^64-1)

        MaxBufferedPackets (int): Max Buffered Packets, 默认值：65535，取值范围：0-4294967295

        MaxTableCount (int): Max Table Count, 默认值：128，取值范围：0-255

        Capabilities (int): Capabilities, 默认值：1，取值范围：0-4294967295

    Returns:

        (:obj:`OpenFlowSwitch`): openflow switch协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Switch | Port=${Port} |
    """

    result = renix.create_openflow_switch(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_controller(Port, **kwargs):
    """
    创建openflow controller协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    keyword Args:

        TcpPort (int): TCP Port, 默认值：6633，取值范围：1-65535

        ConnectionType (str): Connection Type, 默认值：TCP，取值范围：

            TCP

            TCP_TLS

        EnableEchoRequest (bool): Enable Echo Request, 默认值：False，取值范围：

            True

            False

        EchoRequestInterval (int): Echo Request Interval (sec), 默认值：5，取值范围：0-4294967295

        OpenFlowVersion (str): OpenFlow Version, 默认值：v1_3，取值范围：

            v1_3

        BarrierRequestTimeout (int): Barrier Request Timeout (ms), 默认值：10000，取值范围：0-4294967295

        MaxFlowRate (int): Max Flow Rate, 默认值：4294967295，取值范围：0-4294967295

    Returns:

        (:obj:`OpenFlowController`): openflow controller协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Controller | Port=${Port} |
    """

    result = renix.create_openflow_controller(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_openflow_switch_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待openflow switch协议会话达到指定状态

    Args:

        Sessions (list(:obj:`OpenFlowSwitch`)): openflow switch协议会话对象列表, 类型为：list

        State (list): 等待openflow switch协议会话达到的状态, 类型为：string, 默认值：达到RUNING, 支持下列状态：

            IDLE

            RUNING

            STOPPED

            DISABLED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Openflow Switch State | Sessions=${Sessions} | State=IDLE | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_openflow_switch_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_openflow_controller_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待openflow controller协议会话达到指定状态

    Args:

        Sessions (list(:obj:`OpenFlowController`)): openflow controller协议会话对象列表, 类型为：list

        State (list): 等待openflow controller协议会话达到的状态, 类型为：string, 默认值：达到RUNING, 支持下列状态：

            IDLE

            RUNING

            STOPPED

            DISABLED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Openflow Controller State | Sessions=${Sessions} | State=IDLE | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_openflow_controller_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_controller_desc(Sessions, **kwargs):
    """
    修改openflow switch / controller对象的控制器配置

    Args:

        Sessions (list(:obj:`OpenFlowSwitch` or `OpenFlowController`)): openflow switch/controller协议会话对象列表, 类型为：list

    keyword Args:

        IpAddress (str): IP Address, 默认值：127.0.0.1，取值范围：有效的ipv4地址

    Returns:

        (:obj:`OfpControllerDescConfig`): openflow switch/controller的控制器对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Edit Controller Desc | Sessions=${Sessions} | IpAddress=1.1.1.1 |
    """

    result = renix.edit_controller_desc(Sessions=Sessions, **kwargs)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_switch_desc(Sessions, **kwargs):
    """
    修改openflow switch / controller对象的交换机配置

    Args:

        Sessions (list(:obj:`OpenFlowSwitch` or `OpenFlowController`)): openflow switch/controller协议会话对象列表, 类型为：list

    keyword Args:

        IpAddress (str): IP Address, 默认值：127.0.0.1，取值范围：有效的ipv4地址

        DPID (int): DPID, 默认值：0，取值范围：0-(2^64-1)

    Returns:

        (:obj:`OfpSwitchDescConfig`): openflow switch/controller的交换机对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Edit Switch Desc | Sessions=${Sessions} | IpAddress=1.1.1.1 |
    """

    result = renix.edit_switch_desc(Sessions=Sessions, **kwargs)
    if result is False:
        raise Failure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def openflow_start_vswitch(Sessions):
    """
    启动vswitch

    Args:

        Sessions (list(:obj:`OpenFlowSwitch`)): openflow switch协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Openflow Start Vswitch | Sessions=${Sessions) |
    """

    result = renix.openflow_start_vswitch(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def openflow_stop_vswitch(Sessions):
    """
    停止vswitch

    Args:

        Sessions (list(:obj:`OpenFlowSwitch`)): openflow switch协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Openflow Stop Vswitch | Sessions=${Sessions) |
    """

    result = renix.openflow_stop_vswitch(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_action_list(**kwargs):
    """
    创建openflow行动列表

    keyword Args:

        Builtin (bool): Builtin, 默认值：False，取值范围：

            True

            False

        IsDefault (bool): Default, 默认值：False，取值范围：

            True

            False

    Returns:

        (:obj:`OfpActionListConfig`): openflow行动列表对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Action List |
    """
    result = renix.create_openflow_action_list(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_action(ActionList, **kwargs):
    """
    创建openflow行动对象

    Args:

        ActionList (:obj:`OfpActionListConfig`): openflow行动列表对象, 类型：object

    keyword Args:

        Type (str): Type, 默认值：Output，取值范围：

            Output

            CopyTtlOut

            CopyTtlIn

            SetMplsTtl

            DecMplsTtl

            PushVlan

            PopVlan

            PushMpls

            PopMpls

            SetQueue

            Group

            SetIPv4Ttl

            DecIPv4Ttl

            SetField

            PushPBB

            PopPBB

            Experimenter

        PortNumber (int): Port Number, 默认值：1，取值范围：1-4294967295

        ControllerMaxLength (int): Controller Max Length, 默认值：128，取值范围：1-65535

        GroupID (int): Group ID, 默认值：1，取值范围：1-4294967295

        QueueID (int): Queue ID, 默认值：1，取值范围：1-4294967295

        TTL (int): TTL, 默认值：1，取值范围：1-255

        Ethertype (int): EtherType, 默认值：33024，取值范围：1-65535

        FieldType (str): Field Type, 默认值：InPort，取值范围：

            InPort

            InPhyPort

            Metadata

            EthDstAddr

            EthSrcAddr

            EthType

            VlanID

            VlanPCP

            IpDscp

            IpEcn

            IpProtocol

            IPv4SrcAddr

            IPv4DstAddr

            TcpSrcPort

            TcpDstPort

            UdpSrcPort

            UdpDstPort

            SctpSrcPort

            SctpDstPort

            ICMPv4Type

            ICMPv4Code

            ArpOpcode

            ArpSpa

            ArpTpa

            ArpSha

            ArpTha

            IPv6SrcAddr

            IPv6DstAddr

            IPv6FlowLabel

            ICMPv6Type

            ICMPv6Code

            IPv6NdTarget

            IPv6NdSll

            IPv6NdTll

            MplsLabel

            MplsTc

            MplsBos

            PbbIsid

            TunnelID

            IPv6ExtHdr

        FieldValue (list): Field Value, 默认值：[]，取值范围：列表元素为0-255的十进制数

        ExperimenterID (int): Experimenter ID, 默认值：0，取值范围：1-4294967295

    Returns:

        (:obj:`OfpActionConfig`): openflow行动对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Action | ActionList=${actions} |
    """
    result = renix.create_openflow_action(ActionList=ActionList, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_command_list(**kwargs):
    """
    创建openflow命令列表

    keyword Args:

        Builtin (bool): Builtin, 默认值：False，取值范围：

            True

            False

        IsDefault (bool): Default, 默认值：False，取值范围：

            True

            False

    Returns:

        (:obj:`OfpCommandListConfig`): openflow命令列表对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Command List |
    """
    result = renix.create_openflow_command_list(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_command(CommandList, **kwargs):
    """
    创建openflow行动对象

    Args:

        CommandList (:obj:`OfpCommandListConfig`): openflow命令列表对象, 类型：object

    keyword Args:

        CmdType (str): Command Type, 默认值：AddFlow，取值范围：

            ConfigSwitch

            ConfigTable

            AddFlow

            ModifyFlow

            DeleteFlow

            AddGroup

            ModifyGroup

            DeleteGroup

            AddMeter

            ModifyMeter

            DeleteMeter

            RoleRequest

            PacketOut

            Think

            LoopBegin

            LoopEnd

        EnableBarrier (bool): Enable Barrier, 默认值：False，取值范围：

            True

            False

        StrictMatch (bool): Match Strictly, 默认值：False，取值范围：

            True

            False

        Flags (int): Flags, 默认值：0，取值范围：0-4294967295

        ControllerMaxLength (int): Controller Max Length, 默认值：0，取值范围：0-4294967295

        TableID (int): Table ID, 默认值：0，取值范围：0-255

        OutGroup (int): Out Group, 默认值：0，取值范围：0-4294967295

        OutPort (int): Out Port, 默认值：0，取值范围：0-4294967295

        DesiredRole (str): Desired Role, 默认值：Equal，取值范围：

            Equal

            Master

            Slave

        GenerationID (int): Generation ID, 默认值：0，取值范围：0-(2^64-1)

        PacketData (hex): Packet Data (hex), 默认值：""，取值范围：十六进制数

        LoopCount (int): Loop Count, 默认值：5，取值范围：0-4294967295

        ThinkDuration (int): Duration (ms), 默认值：1000，取值范围：0-4294967295

        FlowEntry (:obj:`OfpFlowEntryConfig`): openflow流表项, 类型：object

        GroupTable (:obj:`OfpGroupTableConfig`): openflow组表, 类型：object

        MeterTable (:obj:`OfpMeterTableConfig`): openflow计量表, 类型：object

        ActionList (:obj:`OfpActionListConfig`): openflow行动列表对象, 类型：object

    Returns:

        (:obj:`OfpControllerCommandConfig`): openflow命令对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Command | CommandList=${commands} |
    """
    result = renix.create_openflow_command(CommandList=CommandList, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_flow_table(**kwargs):
    """
    创建openflow流表

    keyword Args:

        Builtin (bool): Builtin, 默认值：False，取值范围：

            True

            False

        IsDefault (bool): Default, 默认值：False，取值范围：

            True

            False

        ConfigId (int): ID, 默认值：1，取值范围：0-4294967295

        TableMissAction (str): Table-miss Action, 默认值：Drop，取值范围：

            Drop

            Continue

            Controller

    Returns:

        (:obj:`OfpFlowTableConfig`): openflow流表, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Flow Table |
    """
    result = renix.create_openflow_flow_table(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_flow_entry(FlowTable, **kwargs):
    """
    创建openflow流表项

    Args:

        FlowTable (:obj:`OfpCommandListConfig`): openflow流表, 类型：object

    keyword Args:

        Priority (int): Priority, 默认值：0，取值范围：0-65535

        IdleTimeout (int): Idle Timeout (sec), 默认值：100，取值范围：0-4294967295

        HardTimeout (int): Hard Timeout (sec), 默认值：100，取值范围：0-4294967295

        Cookie (int): Cookie, 默认值：0，取值范围：0-(2^64-1)

        Flags (list): Flags, 默认值：['SEND_FLOW_REM']，取值范围：

            SEND_FLOW_REM

            CHECK_OVERLAP

            RESET_COUNTS

            NO_PKT_COUNTS

            NO_BYT_COUNTS

        PacketInAction (str): PacketIn Action, 默认值：ApplyActions，取值范围：

            ApplyActions

            AddFlow

            ModifyFlow

        FlowStreamMatch (str): Flow Match Field, 默认值：""

        InPort (int): Switch input Port, 默认值：1，取值范围：0-4294967295

        OutPort (int): Switch output Port, 默认值：1，取值范围：0-4294967295

        ActionList (:obj:`OfpActionListConfig`): openflow行动列表对象, 类型：object

        StreamTemplate (:obj:`StreamTemplate`): 创建的流量对象object列表

        StreamChannel

    Returns:

        (:obj:`OfpFlowEntryConfig`): openflow流表项, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Flow Entry | FlowTable=${flowtable} |
    """
    result = renix.create_openflow_flow_entry(FlowTable=FlowTable, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_instruction(FlowEntry, **kwargs):
    """
    创建openflow instruction

    Args:

        FlowEntry (:obj:`OfpFlowEntryConfig`): openflow流表项, 类型：object

    keyword Args:

        Type (str): Type, 默认值：ApplyActions，取值范围：

            GotoTable

            WriteMetadata

            WriteActions

            ApplyActions

            ClearActions

            ApplyMeter

            Experimenter

        FlowTableID (int): Flow Table ID, 默认值：0，取值范围：0-255

        Metadata (int): Metadata, 默认值：0，取值范围：0-(2^64-1)

        MetadataMask (int): Metadata Mask, 默认值：0，取值范围：0-(2^64-1)

        MeterID (int): Meter Table ID, 默认值：0，取值范围：0-255

        ExperimenterID (int): Experimenter ID, 默认值：0，取值范围：0-4294967295

        ActionList (:obj:`OfpActionListConfig`): openflow行动列表对象, 类型：object

    Returns:

        (:obj:`OfpInstructionConfig`): openflow instruction, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Instruction | FlowEntry=${flowentry} |
    """
    result = renix.create_openflow_instruction(FlowEntry=FlowEntry, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_match_field(FlowEntry, **kwargs):
    """
    创建openflow流表匹配域对象

    Args:

        FlowEntry (:obj:`OfpFlowEntryConfig`): openflow流表项, 类型：object

    keyword Args:

        Type (str): Type, 默认值：InPort，取值范围：

            InPort

            InPhyPort

            Metadata

            EthDstAddr

            EthSrcAddr

            EthType

            VlanID

            VlanPCP

            IpDscp

            IpEcn

            IpProtocol

            IPv4SrcAddr

            IPv4DstAddr

            TcpSrcPort

            TcpDstPort

            UdpSrcPort

            UdpDstPort

            SctpSrcPort

            SctpDstPort

            ICMPv4Type

            ICMPv4Code

            ArpOpcode

            ArpSpa

            ArpTpa

            ArpSha

            ArpTha

            IPv6SrcAddr

            IPv6DstAddr

            IPv6FlowLabel

            ICMPv6Type

            ICMPv6Code

            IPv6NdTarget

            IPv6NdSll

            IPv6NdTll

            MplsLabel

            MplsTc

            MplsBos

            PbbIsid

            TunnelID

            IPv6ExtHdr

        Value (list): Value, 默认值：[]，取值范围：列表元素为0-255的十进制数

        Mask (list): Mask, 默认值：[]，取值范围：列表元素为0-255的十进制数

        ModifierType (str): Modifier Type, 默认值：NONE，取值范围：

            NONE

            Intra

            Inter

        ModifierStep (list): Modifier Step, 默认值：[]，取值范围：列表元素为0-255的十进制数

        ModifierCount (int): Modifier Count, 默认值：1，取值范围：0-4294967295

    Returns:

        (:obj:`OfpMatchFieldConfig`): openflow流表匹配域对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Match Field | FlowEntry=${flowentry} |
    """
    result = renix.create_openflow_match_field(FlowEntry=FlowEntry, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_group_table(**kwargs):
    """
    创建openflow组表

    keyword Args:

        Builtin (bool): Builtin, 默认值：False，取值范围：

            True

            False

        IsDefault (bool): Default, 默认值：False，取值范围：

            True

            False

        ConfigId (int): ID, 默认值：1，取值范围：0-4294967295

        Type (str): Type, 默认值：All，取值范围：

            All

            Select

            Indirect

            FastFailover

    Returns:

        (:obj:`OfpGroupTableConfig`): openflow组表, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Group Table |
    """
    result = renix.create_openflow_group_table(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_action_bucket(GroupTable, **kwargs):
    """
    创建openflow组表行动桶对象

    Args:

        GroupTable (:obj:`OfpGroupTableConfig`): openflow组表, 类型：object

    keyword Args:

        Weight (int): Weight, 默认值：0，取值范围：0-65535

        WatchGroup (int): Watch Group, 默认值：4294967295，取值范围：0-4294967295

        WatchPort (int): Watch Port, 默认值：4294967295，取值范围：0-4294967295

        ActionList (:obj:`OfpActionListConfig`): openflow行动列表对象, 类型：object

    Returns:

        (:obj:`OfpActionBucketConfig`): openflow组表行动桶对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Match Field | GroupTable=${grouptable} |
    """
    result = renix.create_openflow_action_bucket(GroupTable=GroupTable, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_meter_table(**kwargs):
    """
    创建openflow计量表

    keyword Args:

        Builtin (bool): Builtin, 默认值：False，取值范围：

            True

            False

        IsDefault (bool): Default, 默认值：False，取值范围：

            True

            False

        ConfigId (int): ID, 默认值：1，取值范围：0-4294967295

        BandUnit (str): Band Unit, 默认值：kb，取值范围：

            kb

            pkt

        EnableBurstSize (bool): Enable Burst Size, 默认值：False，取值范围：

            True

            False

        EnableStatistics (bool): Enable Statistics, 默认值：False，取值范围：

            True

            False

    Returns:

        (:obj:`OfpMeterTableConfig`): openflow计量表, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Meter Table |
    """
    result = renix.create_openflow_meter_table(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_meter_band(MeterTable, **kwargs):
    """
    创建openflow计量带宽对象

    Args:

        MeterTable (:obj:`OfpMeterTableConfig`): openflow计量表, 类型：object

    keyword Args:

        Type (str): Type, 默认值：Drop，取值范围：

            Drop

            DscpRemark

            Experimenter

        Rate (int): Rate (per sec), 默认值：100，取值范围：0-4294967295

        BurstSize (int): Burst Size, 默认值：10，取值范围：0-4294967295

        PrecLevel (int): Drop Precedence Level, 默认值：1，取值范围：0-255

        ExperimenterID (int): Experimenter ID, 默认值：0，取值范围：0-4294967295

    Returns:

        (:obj:`OfpMeterBandConfig`): openflow组表行动桶对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Meter Band | MeterTable=${MeterTable} |
    """
    result = renix.create_openflow_meter_band(MeterTable=MeterTable, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_queue(**kwargs):
    """
    创建openflow queue

    keyword Args:

        Builtin (bool): Builtin, 默认值：False，取值范围：

            True

            False

        IsDefault (bool): Default, 默认值：False，取值范围：

            True

            False

        ConfigId (int): ID, 默认值：1，取值范围：0-4294967295

    Returns:

        (:obj:`OfpQueueConfig`): openflow queue, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Queue |
    """
    result = renix.create_openflow_queue(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_openflow_queue_property(Queue, **kwargs):
    """
    创建openflow queue property

    Args:

        Queue (:obj:`OfpQueueConfig`): openflow queue, 类型：object

    keyword Args:

        Type (str): Type, 默认值：MinRate，取值范围：

            MinRate

            MaxRate

            Experimenter

        Rate (int): Rate(1/1000), 默认值：100，取值范围：0-4294967295

        ExperimenterID (int): Experimenter ID, 默认值：0，取值范围：0-4294967295

        ExperimenterData (list): Experimenter Data, 默认值：[]，取值范围：列表元素为0-255的十进制数

    Returns:

        (:obj:`OfpQueuePropertyConfig`): openflow组表行动桶对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Openflow Queue Property | Queue=${Queue} |
    """
    result = renix.create_openflow_queue_property(Queue=Queue, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_openflow_controller_statistic(Controller=None, StaItems: list = None):
    """
    获取openflow控制器统计结果

    Args:

        Controller (:obj:`OpenFlowController`): openflow controller协议会话对象, 类型：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            Duration

            ConnectedSwitchCount

            BarrierRequestCount

            BarrierReplyCount

            BarrierRequestTimeoutCount

            BarrierRemainingCount

            LastBarrierResponseTime

            MissPacketInCount

            MatchPacketInCount

            TotalPacketOutCount

            AddFlowCount

            ModifyFlowCount

            DeleteFlowCount

            FlowModErrorCount

            FlowRemovedCount

            AddGroupCount

            ModifyGroupCount

            DeleteGroupCount

            GroupModErrorCount

            AddMeterCount

            ModifyMeterCount

            DeleteMeterCount

            MeterModErrorCount

            RoleRequestCount

            RoleReplyCount

    Returns:

        dict: eg::

            {
                'RoleRequestCount': 10,
                'RoleReplyCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Openflow Controller Statistic | Controller=${Controller} | StaItems=@{StaItems} |
    """

    result = renix.get_openflow_controller_statistic(Controller=Controller, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_openflow_switch_statistic(Switch=None, StaItems: list = None):
    """
    获取openflow交换机desc统计结果

    Args:

        Switch (:obj:`OfpSwitchDescConfig`): openflow switch desc对象, 类型：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            Duration

            DPID

            ControllerRole

            CurrentGenerationID

            BarrierRequestCount

            BarrierReplyCount

            BarrierRequestTimeoutCount

            BarrierRemainingCount

            LastBarrierResponseTime

            MissPacketInCount

            MatchPacketInCount

            TotalPacketOutCount

            AddFlowCount

            AddFlowRate

            ModifyFlowCount

            ModifyFlowRate

            DeleteFlowCount

            DeleteFlowRate

            FlowModErrorCount

            FlowRemovedCount

            AddFlowSetupTime

            AddGroupCount

            AddGroupRate

            ModifyGroupCount

            ModifyGroupRate

            DeleteGroupCount

            DeleteGroupRate

            GroupModErrorCount

            AddMeterCount

            AddMeterRate

            ModifyMeterCount

            ModifyMeterRate

            DeleteMeterCount

            DeleteMeterRate

            MeterModErrorCount

            RoleRequestCount

            RoleReplyCount

    Returns:

        dict: eg::

            {
                'RoleRequestCount': 10,
                'RoleReplyCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Openflow Switch Statistic | Switch=${Switch} | StaItems=@{StaItems} |
    """

    result = renix.get_openflow_switch_statistic(Switch=Switch, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

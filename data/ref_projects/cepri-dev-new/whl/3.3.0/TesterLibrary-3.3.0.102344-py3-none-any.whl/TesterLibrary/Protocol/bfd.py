import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------bfd-------------------------------------
def create_bfd(Port, **kwargs):
    """
    创建BFD协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): BFD协议会话名称, 类型为：string

        Enable (bool): 使能BFD协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        RouterRole (str): BFD会话的角色, 类型为：string, 默认值：Active, 支持角色：

            Active

            Passive

        TimeIntervalUnit (str): 时间间隔的单位。 类型为：string, 默认值：milliseconds, 支持单位：

            milliseconds

            microseconds

        DesiredMinTXInterval (int): 期望的最小发送时间间隔。 类型为：number, 取值范围：1-10000 (milliseconds); 1-10000000 (microseconds), 默认值：50

        RequiredMinRXInterval (int): 需要的最小接收时间间隔。 类型为：number, 取值范围：1-10000 (milliseconds); 1-10000000 (microseconds), 默认值：50

        RequiredMinEchoRXInterval (int): 需要的最小Echo报文接收时间间隔。 类型为：number, 取值范围：1-10000 (milliseconds); 1-10000000 (microseconds), 默认值：0

        DetectMultiple (int): 用于检测超时的时间因子, 类型为：number, 取值范围：2-100, 默认值：3

        AuthenticationType (str): 认证方式, 类型为：string, 默认值：None, 支持的方式：

            NONE

            SIMPLE_PASSWORD

            KEYED_MD5

            METICULOUS_KEYED_MD5

            KEYED_SHA1

            METICULOUS_KEYED_SHA1

        Password (str): 当认证方式不为NONE时，在该单元格输入认证密码。密码可以是数字、字母或者数字和字母的组合，最长为16位。 类型为：string, 默认值：Xinertel

        KeyID (int): 当认证方式不为NONE时，在该单元格输入Key ID, 类型为：number, 取值范围：0-255, 默认值：1

    Returns:

        (:obj:`BfdRouter`): BFD协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create bfd | Port=${Port} | TimeIntervalUnit=microseconds |
    """

    result = renix.create_bfd(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_bfd(Session, **kwargs):
    """
    编辑BFD协议会话对象参数

    Args:

        Session(:obj:`BfdRouter`): BFD协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BFD协议会话名称, 类型为：string

        Enable (bool): 使能BFD协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        RouterRole (str): BFD会话的角色, 类型为：string, 默认值：Active, 支持角色：

            Active

            Passive

        TimeIntervalUnit (str): 时间间隔的单位。 类型为：string, 默认值：milliseconds, 支持单位：

            milliseconds

            microseconds

        DesiredMinTXInterval (int): 期望的最小发送时间间隔。 类型为：number, 取值范围：1-10000 (milliseconds); 1-10000000 (microseconds), 默认值：50

        RequiredMinRXInterval (int): 需要的最小接收时间间隔。 类型为：number, 取值范围：1-10000 (milliseconds); 1-10000000 (microseconds), 默认值：50

        DetectMultiple (int): 用于检测超时的时间因子, 类型为：number, 取值范围：2-100, 默认值：3

        AuthenticationType (str): 认证方式, 类型为：string, 默认值：None, 支持的方式：

            NONE

            SIMPLE_PASSWORD

            KEYED_MD5

            METICULOUS_KEYED_MD5

            KEYED_SHA1

            METICULOUS_KEYED_SHA1

        Password (str): 当认证方式不为NONE时，在该单元格输入认证密码。密码可以是数字、字母或者数字和字母的组合，最长为16位。 类型为：string, 默认值：Xinertel

        KeyID (int): 当认证方式不为NONE时，在该单元格输入Key ID, 类型为：number, 取值范围：0-255, 默认值：1

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Bfd | Session=${Session} | EnableViewRoutes=True |
    """

    result = renix.edit_bfd(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bfd_ipv4_session(Session, **kwargs):
    """
    创建BFD IPv4会话对象

    Args:

        Session(:obj:`BfdRouter`): BFD协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BFD IPv4会话名称, 类型为：string

        Enable (bool): 使能BFD IPv4会话, 类型为：bool, 取值范围：True或False, 默认值：True

        NumberOfSessions (str): BFD IPv4会话的数目, 类型为：string, 取值范围：1-4294967295, 默认值：1

        StartDestinationAddress (str): 指定第一个目的IPv4地址, 类型为：string, 取值范围：有效的ipv4地址, 默认值：192.0.1.0

        DestinationAddressIncrement (str): 指定下一个目的IPv4地址的增量, 类型为：string, 取值范围：有效的ipv4地址, 默认值：0.0.0.1

        EnableMyDiscriminator (bool): 是否指定本地标识符, 类型为：bool, 取值范围：True或False, 默认值：False

        MyDiscriminator (int): 指定本地标识符的初始值。只有使能本地标识符被选中才可编辑, 类型为：number, 取值范围：1-4294967295, 默认值：1

        MyDiscriminatorIncrement (int): 指定下一个本地标识符的增量。只有使能本地标识符被选中才可编辑。 类型为：number, 取值范围：1-4294967295, 默认值：1

        EnableYourDiscriminator (bool): 是否指定对端标识符, 类型为：bool, 取值范围：True或False, 默认值：False

        YourDiscriminator (int): 指定对端标识符的初始值。只有使能本地标识符被选中才可编辑, 类型为：number, 取值范围：1-4294967295, 默认值：1

        YourDiscriminatorIncrement (int): 指定下一个对端标识符的增量。只有使能本地标识符被选中才可编辑。 类型为：number, 取值范围：1-4294967295, 默认值：1

    Returns:

        (:obj:`BfdIpv4SessionConfig`): BFD IPv4会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bfd | Port=${Port} |
            | Create Bfd Ipv4 Session | Session=${Session} | NumberOfSessions=10 |
    """

    result = renix.create_bfd_ipv4_session(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_bfd_ipv6_session(Session, **kwargs):
    """
    创建BFD IPv6路由对象

    Args:

        Session(:obj:`BfdRouter`): BFD协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): BFD IPv6路由名称, 类型为：string

        Enable (bool): 使能BFD IPv6路由, 类型为：bool, 取值范围：True或False, 默认值：True

        NumberOfSessions (str): BFD IPv6会话的数目, 类型为：string, 取值范围：1-4294967295, 默认值：1

        StartDestinationAddress (str): 指定第一个目的IPv6地址, 类型为：string, 取值范围：有效的ipv6地址, 默认值：2000::1

        DestinationAddressIncrement (str): 指定下一个目的IPv4地址的增量, 类型为：string, 取值范围：有效的ipv4地址, 默认值：::1

        EnableMyDiscriminator (bool): 是否指定本地标识符, 类型为：bool, 取值范围：True或False, 默认值：False

        MyDiscriminator (int): 指定本地标识符的初始值。只有使能本地标识符被选中才可编辑, 类型为：number, 取值范围：1-4294967295, 默认值：1

        MyDiscriminatorIncrement (int): 指定下一个本地标识符的增量。只有使能本地标识符被选中才可编辑。 类型为：number, 取值范围：1-4294967295, 默认值：1

        EnableYourDiscriminator (bool): 是否指定对端标识符, 类型为：bool, 取值范围：True或False, 默认值：False

        YourDiscriminator (int): 指定对端标识符的初始值。只有使能本地标识符被选中才可编辑, 类型为：number, 取值范围：1-4294967295, 默认值：1

        YourDiscriminatorIncrement (int): 指定下一个对端标识符的增量。只有使能本地标识符被选中才可编辑。 类型为：number, 取值范围：1-4294967295, 默认值：1

    Returns:

        (:obj:`BfdIpv6SessionConfig`): BFD IPv6会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Bfd | Port=${Port} |
            | Create Bfd Ipv6 Session | Session=${Session} |
    """

    result = renix.create_bfd_ipv6_session(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_admin_down(Sessions):
    """
    设置BFD会话状态AdminDown

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Admin Down | Sessions=${Sessions} |
    """

    result = renix.bfd_admin_down(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_admin_up(Sessions):
    """
    设置BFD会话状态AdminUp

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Admin Up | Sessions=${Sessions} |
    """

    result = renix.bfd_admin_up(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_enable_demand_mode(Sessions):
    """
    开启BFD Demand模式

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Enable Demand Mode | Sessions=${Sessions} |
    """

    result = renix.bfd_enable_demand_mode(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_disable_demand_mode(Sessions):
    """
    关闭BFD demand模式

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Disable Demand Mode | Sessions=${Sessions} |
    """

    result = renix.bfd_disable_Demand_mode(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_initiate_poll(Sessions):
    """
    发送BFD poll Sequence

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Initiate Poll | Sessions=${Sessions} |
    """

    result = renix.bfd_initiate_poll(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_resume_pdus(Sessions):
    """
    恢复发送BFD PDU

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Resume Pdus | Sessions=${Sessions} |
    """

    result = renix.bfd_resume_pdus(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_stop_pdus(Sessions):
    """
    停止发送BFD PDU

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Stop Pdus | Sessions=${Sessions} |
    """

    result = renix.bfd_stop_pdus(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def bfd_set_diagnostic_state(Sessions, State):
    """
    设置BFD状态诊断码

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

        State (str):设置状态诊断码, 类型为：string, 默认值：NO_DIAGNOSTIC, 支持的状态诊断码：

            NO_DIAGNOSTIC

            CONTROL_DETECTION_TIME_EXPIRED

            ECHO_FUNCTION_FAILED

            NEIGHBOR_SIGNAL_SESSION_DOWN

            FORWARDING_PLANE_RESET

            PATH_DOWN

            CONCATENATED_PATH_DOWN

            ADMINISTRATIVELY_DOWN

            REVERSE_CONCATENATED_PATH_DOWN


    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Bfd Set Diagnostic State | Sessions=${Sessions} |
    """

    result = renix.bfd_set_diagnostic_state(Sessions=Sessions, State=State)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_bfd_state(Sessions, State='RUNNING', Interval=1, TimeOut=60):
    """
    等待BFD协议会话达到指定状态

    Args:

        Sessions (list (:obj:`BfdRouter`)): BFD协议会话对象列表, 类型为：list

        State (list): 等待BFD协议会话达到的状态, 类型为：string, 默认值：达到RUNNING, 支持下列状态：

            DISABLED

            NOT_STARTED

            IDLE

            RUNNING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Bfd State | Sessions=${Sessions} | State=RUNNING | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_bfd_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bfd_session_result(Session=None, StaItems: list = None):
    """
    获取BFD协议会话统计结果

    Args:

        Session (:obj:`BfdRouter`): BFD协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项：

            SessionID

            SessionState

            BfdSessionUpCount

            BfdSessionDownCount

            TXBfdPackets

            RXBfdPackets

            TimeoutsDetected

            FlapsDetected

    Returns:

        dict: eg::

            {
                'TXBfdPackets': 10,
                'RXBfdPackets': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=BfdSessionResult |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bfd Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bfd_session_result(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bfd_ipv4_session_result(Session=None, SessionId=1, StaItems: list = None):
    """
    获取BFD IPV4会话统计结果

    Args:

        Session (:obj:`BfdIpv4SessionConfig`): BFD IPV4会话对象, 类型为：Object

        SessionId (str): BFD会话的索引号, 类型为：string

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项：

            Ipv4SessionKeyID

            Ipv4SessionID

            SessionID

            SessionIndex

            Ipv4SourceAddress

            Ipv4DestinationAddress

            BfdSessionState

            MyDiscriminator

            YourDiscriminator

            BfdDiagnostic

            LastBfdDiagnosticErrorRx

            BfdControlBits_PFCADM

            ReceiveCount

            TransmitCount

            TransmitInterval

            ReceivedRequiredMinRXInterval

            ReceivedRequiredMinEchoRXInterval

            FlapsDetected

            TimeoutsDetected

            RXAvgRate

            RXMaxRate

            RXMinRate

            TXAvgRate

            TXMaxRate

            TXMinRate

    Returns:

        dict: eg::

            {
                'TXAvgRate': 10,
                'RXAvgRate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=BfdIpv4SessionResult |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bfd Ipv4 Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bfd_ipv4_session_result(Session=Session, SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bfd_ipv6_session_result(Session=None, SessionId=1, StaItems: list = None):
    """
    获取BFD IPV6会话统计结果

    Args:

        Session (:obj:`BfdIpv6SessionConfig`): BFD IPV6会话对象, 类型为：Object

        SessionId (str): BFD会话的索引号, 类型为：string

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项：

            Ipv6SessionKeyID

            Ipv6SessionID

            SessionID

            SessionIndex

            Ipv6SourceAddress

            Ipv6DestinationAddress

            BfdSessionState

            MyDiscriminator

            YourDiscriminator

            BfdDiagnostic

            LastBfdDiagnosticErrorRx

            BfdControlBits_PFCADM

            ReceiveCount

            TransmitCount

            TransmitInterval

            ReceivedRequiredMinRXInterval

            ReceivedRequiredMinEchoRXInterval

            FlapsDetected

            TimeoutsDetected

            RXAvgRate

            RXMaxRate

            RXMinRate

            TXAvgRate

            TXMaxRate

            TXMinRate

    Returns:

        dict: eg::

            {
                'TXAvgRate': 10,
                'RXAvgRate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=BfdIpv6SessionResult |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bfd Ipv6 Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bfd_ipv6_session_result(Session=Session, SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bfd_isis_session_result(BfdSession=None, IsisSession=None, SessionId=1, StaItems: list = None):
    """
    获取ISIS BFD会话统计结果

    Args:

        BfdSession (:obj:`BfdRouter`): BFD会话对象, 类型为：Object

        IsisSession (:obj:`IsisRouter`): ISIS会话对象, 类型为：Object

        SessionId (str): BFD会话的索引号, 类型为：string

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项：

            IpSessionKeyID

            IpSessionID

            SessionID

            SessionIndex

            Ipv4SourceAddress

            Ipv4DestinationAddress

            BfdSessionState

            MyDiscriminator

            YourDiscriminator

            BfdDiagnostic

            LastBfdDiagnosticErrorRx

            BfdControlBits_PFCADM

            ReceiveCount

            TransmitCount

            TransmitInterval

            ReceivedRequiredMinRXInterval

            ReceivedRequiredMinEchoRXInterval

            FlapsDetected

            TimeoutsDetected

            RXAvgRate

            RXMaxRate

            RXMinRate

            TXAvgRate

            TXMaxRate

            TXMinRate

    Returns:

        dict: eg::

            {
                'TXAvgRate': 10,
                'RXAvgRate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=IsisBfdSessionResult |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bfd Isis Session Statistic | BfdSession=${BfdSession} | IsisSession=${IsisSession} | SessionId=${SessionId} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bfd_isis_session_result(BfdSession=BfdSession, IsisSession=IsisSession,
                                                  SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bfd_isis_ipv6_session_result(BfdSession=None, IsisSession=None, SessionId=1, StaItems: list = None):
    """
    获取ISIS BFD IPV6会话统计结果

    Args:

        BfdSession (:obj:`BfdRouter`): BFD会话对象, 类型为：Object

        IsisSession (:obj:`IsisRouter`): ISIS会话对象, 类型为：Object

        SessionId (str): BFD会话的索引号, 类型为：string

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项：

            IpSessionKeyID

            IpSessionID

            SessionID

            SessionIndex

            Ipv6SourceAddress

            Ipv6DestinationAddress

            BfdSessionState

            MyDiscriminator

            YourDiscriminator

            BfdDiagnostic

            LastBfdDiagnosticErrorRx

            BfdControlBits_PFCADM

            ReceiveCount

            TransmitCount

            TransmitInterval

            ReceivedRequiredMinRXInterval

            ReceivedRequiredMinEchoRXInterval

            FlapsDetected

            TimeoutsDetected

            RXAvgRate

            RXMaxRate

            RXMinRate

            TXAvgRate

            TXMaxRate

            TXMinRate

    Returns:

        dict: eg::

            {
                'TXAvgRate': 10,
                'RXAvgRate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=IsisBfdIpv6SessionResult |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bfd Isis Ipv6 Session Statistic | BfdSession=${BfdSession} | IsisSession=${IsisSession} | SessionId=${SessionId} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bfd_isis_ipv6_session_result(BfdSession=BfdSession, IsisSession=IsisSession,
                                                       SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bfd_ospfv2_session_result(BfdSession=None, Ospfv2Session=None, SessionId=1, StaItems: list = None):
    """
    获取OSPFV2 BFD 会话统计结果

    Args:

        Ospfv2Session (:obj:`BfdRouter`): OSPFv2会话对象, 类型为：Object

        BfdSession (:obj:`OspfRouter`): BFD会话对象, 类型为：Object

        SessionId (str): BFD会话的索引号, 类型为：string

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项：

            Ipv4SessionKeyID

            Ipv4SessionID

            SessionID

            SessionIndex

            Ipv4SourceAddress

            Ipv4DestinationAddress

            BfdSessionState

            MyDiscriminator

            YourDiscriminator

            BfdDiagnostic

            LastBfdDiagnosticErrorRx

            BfdControlBits_PFCADM

            ReceiveCount

            TransmitCount

            TransmitInterval

            ReceivedRequiredMinRXInterval

            ReceivedRequiredMinEchoRXInterval

            FlapsDetected

            TimeoutsDetected

            RXAvgRate

            RXMaxRate

            RXMinRate

            TXAvgRate

            TXMaxRate

            TXMinRate

    Returns:

        dict: eg::

            {
                'TXAvgRate': 10,
                'RXAvgRate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ospfv2BfdSessionResult |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bfd Ospfv2 Session Statistic | BfdSession=${BfdSession} | Ospfv2Session=${Ospfv2Session} | SessionId=${SessionId} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bfd_ospfv2_session_result(BfdSession=BfdSession, Ospfv2Session=Ospfv2Session,
                                                    SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_bfd_ospfv3_session_result(BfdSession=None, Ospfv3Session=None, SessionId=1, StaItems: list = None):
    """
    获取OSPFV3 BFD 会话统计结果

    Args:

        BfdSession (:obj:`BfdRouter`): BFD会话对象, 类型为：Object

        Ospfv3Session (:obj:`Ospfv3Router`): OSPFv3会话对象, 类型为：Object

        SessionId (str): BFD会话的索引号, 类型为：string

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项：

            Ipv6SessionKeyID

            Ipv6SessionID

            SessionID

            SessionIndex

            Ipv6SourceAddress

            Ipv6DestinationAddress

            BfdSessionState

            MyDiscriminator

            YourDiscriminator

            BfdDiagnostic

            LastBfdDiagnosticErrorRx

            BfdControlBits_PFCADM

            ReceiveCount

            TransmitCount

            TransmitInterval

            ReceivedRequiredMinRXInterval

            ReceivedRequiredMinEchoRXInterval

            FlapsDetected

            TimeoutsDetected

            RXAvgRate

            RXMaxRate

            RXMinRate

            TXAvgRate

            TXMaxRate

            TXMinRate

    Returns:

        dict: eg::

            {
                'TXAvgRate': 10,
                'RXAvgRate': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ospfv3BfdSessionResult |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Bfd Ospfv3 Session Statistic | BfdSession=${BfdSession} | Ospfv3Session=${Ospfv3Session} | SessionId=${SessionId} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_bfd_ospfv3_session_result(BfdSession=BfdSession, Ospfv3Session=Ospfv3Session,
                                                    SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Multicast-------------------------------------
def create_multicast_group(Version="IPv4", **kwargs):
    """
    创建全局组播组对象

    Args:

        Version (str): 组播组IP版本，类型string, 支持ipv4和ipv6

    Keyword Args:

        Count (int): 组播组数量, 类型为：number, 取值范围：0-65535, 默认值：1

        Mode (str): 组播组地址模式, 类型为：string, 默认值：RANGE, 取值范围：

            RANGE

            LIST

            RFC_4814

        Start (str): 组播组地址起始值, 类型为：ipv4/ipv6 string, 默认值：225.0.0.1或ff1e::1

        Number (int): 组播组地址数量, 类型为：number, 取值范围：1-268435456, 默认值：1

        Increment (int): 组播组地址步长, 类型为：number, 取值范围：1-268435456, 默认值：1

        Prefix (int): 组播组地址掩码, 类型为：number, 取值范围：ipv4: 1-32 默认值：32, ipv6: 1-128 默认值：128

    Returns:

        (:obj:`MldSelectMulticastGroupCommand`): 全局组播组对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Multicast Group | Version=IPV4 | Start=225.0.1.1 | Number=20 |
    """

    result = renix.create_multicast_group(Version=Version, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_memberships(Session, **kwargs):
    """
    创建组播协议和组播组绑定关系对象

    Args:

        Session (:obj:`Mld`, `Igmp`): IGMP/MLD协会话对象, 类型为：object

    Keyword Args:

        DeviceGroupMapping (str): 主机和组播组映射关系, 类型为：str, 默认值：MANYTOMANY, 取值范围：

            MANYTOMANY

            ONETOONE

            ROUNDROBIN

        SourceFilterMode (str): 源地址过滤模式, 类型为：str, 默认值：EXCLUDE, 取值范围：

            INCLUDE

            EXCLUDE

        UserDefinedSources (bool): 自定义源地址, 类型为：bool, 取值范围：True或False, 默认值：False

        SpecifySourcesAsList (bool): 配置离散源地址, 类型为：bool, 取值范围：True或False, 默认值：False

        SourceAddressList (list): 离散源地址列表, 类型为：list, 取值范围：ipv4 or ipv6 string list

        NumberOfSources (int): 源地址个数, 类型为：number, 取值范围：0-16777215 默认值：1

        StartingSourceIp (str): 组播组起始源地址, 类型为：string, 取值范围：ipv4 or ipv6 string list，, 默认值ipv4: 192.0.1.0 , ipv6: 2000::1

        PrefixLength (int): 组跳变位, 类型为：number, 取值范围：ipv4: 1-32 默认值：32, ipv6: 1-128 默认值：128

        Increment (int): 跳变步长, 类型为：number, 取值范围：0-16777215 默认值：1

    Returns:

        (:obj:`MldMembershipsConfig`): 组播协议和组播组绑定关系对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Mld | Port=${Port} |
            | Create Memberships | Session=${Session} | Start=225.0.1.1 | DeviceGroupMapping=ONETOONE |
    """

    result = renix.create_memberships(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def binding_multicast_group(Session, Memberships, MulticastGroup):
    """
    将全局组播组绑定到组播协议会话上

    Args:

        Session (:obj:`Mld`, `Igmp`): IGMP/MLD协会话对象, 类型为：object

        Memberships (:obj:`MldMembershipsConfig`): 组播协议和组播组绑定关系对象, 类型为：object

        MulticastGroup (:obj:`MldSelectMulticastGroupCommand`): 全局组播组对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Group} | Create Multicast Group | Version=IPV4 | Start=225.0.1.1 | Number=20 |
            | ${Session} | Create Igmp | Port=${Port} | Version=IGMPV3 |
            | ${Memberships} | Create Memberships | Session=${Session} | Start=225.0.1.1 | DeviceGroupMapping=ONETOONE |
            | binding_multicast_group | Session=${Session} | Memberships=${Memberships} | MulticastGroup=${Group} |
    """

    result = renix.binding_multicast_group(Session=Session, Memberships=Memberships,
                                           MulticastGroup=MulticastGroup)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

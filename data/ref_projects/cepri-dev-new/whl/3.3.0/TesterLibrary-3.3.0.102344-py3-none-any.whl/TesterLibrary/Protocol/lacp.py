import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------lacp-------------------------------------
def create_lacp(Ports):
    """
    创建lacp协议会话对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        (:obj:`Lacp`): lacp协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Lacp | Ports=${Ports} |
    """

    result = renix.create_lacp(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def lacp_add_members(Lacp, Ports):
    """
    为lacp协议会话对象添加端口成员对象

    Args:

        Lacp (:obj:`Lacp`): lacp协议会话对象, 类型：object

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Lacp Add Members | Lacp=${Lacp} | Ports=${Ports} |
    """

    result = renix.lacp_add_members(Lacp_=Lacp, Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_lacp_aggregation_group(Lacp, **kwargs):
    """
    修改lacp协议会话对象的Aggregation Group对象

    Args:

        Lacp (:obj:`Lacp`): lacp协议会话对象, 类型：object

    Keyword Args:

        L2HashOption (list): L2 Hash Option, 默认值：['ETHERNET_SOURCE_MAC', 'ETHERNET_DESTINATION_MAC', 'VLAN', 'MPLS']，取值范围：

            ETHERNET_SOURCE_MAC

            ETHERNET_DESTINATION_MAC

            VLAN

            MPLS

        L3HashOption (list): L3 Hash Option, 默认值：['IPV4_SOURCE', 'IPV4_DESTINATION', 'UDP']，取值范围：

            ETHERNET_SOURCE_MAC

            ETHERNET_DESTINATION_MAC

            VLAN

            MPLS

            IPV4_SOURCE

            IPV4_DESTINATION

            IPV6_SOURCE

            IPV6_DESTINATION

            TCP

            UDP

        ActorSystemId (str): Actor System ID, 默认值：00:00:00:00:00:01，取值范围：有效的mac地址

        ActorSystemPriority (int): Actor System Priority, 默认值：32768，取值范围：0-65535

        MaxActiveNumber (int): Max Active Number, 默认值：8，取值范围：0-65535

        MinActiveNumber (int): Min Active Number, 默认值：0，取值范围：0-65535

        TransmitAlgorithm (str): Transmit algorithm, 默认值：HASHING，取值范围：

            HASHING

        Preempt (bool): Preempt Enable, 默认值：False，取值范围：

            True

            False

        PreemtDelay (int): Preemt Delay Time(sec), 默认值：30，取值范围：0-65535

        AggregationMode (str): Aggregation Mode, 默认值：LACP，取值范围：

            LACP

            STATIC

        LocalPreference (bool): Tx Local Preference, 默认值：True，取值范围：

            True

            False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Lacp Aggregation Group | Lacp=${Lacp} |
    """

    result = renix.edit_lacp_aggregation_group(Lacp_=Lacp, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def lacp_delete_members(Lacp, Ports):
    """
    为lacp协议会话对象删除端口成员对象

    Args:

        Lacp (:obj:`Lacp`): lacp协议会话对象, 类型：object

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Lacp Delete Members | Lacp=${Lacp} | Ports=${Ports} |
    """

    result = renix.lacp_delete_members(Lacp_=Lacp, Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_lacp_members_port_config(Ports, **kwargs):
    """
    修改lacp端口成员的Port Config对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Keyword Args:

        ActorKey (int): Actor Key, 默认值：1，取值范围：0-65535

        ActorPortId (int): Actor Port ID, 默认值：1，取值范围：0-65535

        ActorPortPriority (int): Actor Port Priority, 默认值：32768，取值范围：0-65535

        LacpTimeout (str): LACP Timeout, 默认值：LONG，取值范围：

            LONG

            SHORT

        LacpActivity (str): LACP Activity, 默认值：ACTIVE，取值范围：

            PASSIVE

            ACTIVE

        ActorSystemId (str): Actor System ID, 默认值：00:00:00:00:00:01，取值范围：有效的mac地址

        ActorSystemPriority (int): Actor System Priority, 默认值：32768，取值范围：0-65535

        PortMacAddress (str): Port MAC Address, 默认值：00:00:20:20:20:01，取值范围：有效的mac地址

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Lacp Member Port Config | Ports=${Ports} |
    """

    result = renix.edit_lacp_members_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def pause_send_lacp_pdus(Ports):
    """
    暂停发送lacp pdu

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Pause Send Lacp Pdus | Ports=${Ports) |
    """

    result = renix.pause_send_lacp_pdus(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def resume_send_lacp_pdus(Ports):
    """
    继续发送lacp pdu

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Resume Send Lacp Pdus | Ports=${Ports) |
    """

    result = renix.resume_send_lacp_pdus(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def send_in_sync_pdus(Ports):
    """
    发送lacp同步

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Send In Sync Pdus | Ports=${Ports) |
    """

    result = renix.send_in_sync_pdus(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def send_out_of_sync_pdus(Ports):
    """
    发送lacp异步

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Send Out of Sync Pdus | Ports=${Ports) |
    """

    result = renix.send_out_of_sync_pdus(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_lacp_port(Ports):
    """
    启动lacp

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Lacp Port | Ports=${Ports) |
    """

    result = renix.start_lacp_port(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_lacp_port(Ports):
    """
    停止lacp

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Lacp Port | Ports=${Ports) |
    """

    result = renix.stop_lacp_port(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_lacp_port_statistic(Port=None, StaItems: list = None):
    """
    获取lacp port统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            ActorState

            PartnerState

            LacpState

            ActorOperationalKey

            ActorSystemId

            ActorSystemPriority

            ActorPortId

            ActorPortPriority

            PartnerOperationalKey

            PartnerSystemId

            PartnerSystemPriority

            PartnerPortId

            PartnerPortPriority

            PartnerCollectorMaxDelay

            LacpPdusSent

            LacpPdusReceived

            MarkerPdusSent

            MarkerPdusReceived

            MarkerResponsePdusSent

            MarkerResponsePdusReceived

    Returns:

        dict: eg::

            {
                'MarkerResponsePdusSent': 10,
                'MarkerResponsePdusReceived': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Lacp Port Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_lacp_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_lag_port_statistic(Lacp=None, StaItems: list = None):
    """
    获取lag port统计结果

    Args:

        Lacp (:obj:`Lacp`): lacp协议会话对象, 类型：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            LacpUpCount

            LacpDownCount

    Returns:

        dict: eg::

            {
                'LacpUpCount': 10,
                'LacpDownCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Lag Port Statistic | Lacp=${Lacp} | StaItems=@{StaItems} |
    """

    result = renix.get_lag_port_statistic(Lacp_=Lacp, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


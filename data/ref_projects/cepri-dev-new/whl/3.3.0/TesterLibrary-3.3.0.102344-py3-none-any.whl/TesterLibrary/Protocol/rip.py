import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------rip-------------------------------------
def create_rip(Port, **kwargs):
    """
    创建RIP协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): RIP协议会话名称, 类型为：string

        Enable (bool): 使能RIP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): RIP版本, 类型为：string, 默认值：RIPV2, 支持版本：

            RIPV1

            RIPV2

            RIPNG

        UpdateType (str): 仿真路由器指定发送RIP消息的通信方式, 类型为：string, 默认值：MULTICAST, 支持方式：

            BROADCAST

            MULTICAST

            UNICAST

        DutIpv4Address (str): 指定接收RIP消息的路由器的IP地址, 当RIP版本为RIPv1或者RIPv2时，该选项可配。 类型为：string, 默认值：224.0.0.9

        DutIpv6Address (str): 指定接收RIP消息的路由器的IP地址, 当RIP版本为RIPng并且更新类型指定为Unicast时，该选项可配。 类型为：string, 默认值：ff02::9

        AuthMethod (str): 认证方式, 当RIP版本为RIPv2时配置该选项。 类型为：string, 默认值：NONE, 支持方式：

            NONE

            SIMPLE

            MD5

        Password (str): 当认证方式为Simple/MD5时，输入的认证密码, 类型为：string, 默认值：Xinetel

        Md5KeyId (int): 当认证方式为MD5时，输入的MD5密钥, 类型为：number, 取值范围：0-255, 默认值：1

        UpdateInterval (int): 发送RIP更新消息的时间间隔，单位为秒, 类型为：number, 取值范围：1-65535, 默认值：30

        UpdateJitter (int): 发送RIP更新消息的时间抖动, 类型为：number, 取值范围：0-5, 默认值：0

        MaxRoutePerUpdate (int): 更新消息中可携带的最大路由数, 类型为：number, 取值范围：1-70, 默认值：25

        SplitHorizon (bool): 是否开启水平分割功能, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableViewRoutes (bool): 是否需要查看学到的路由信息, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableIpAddrValidation (bool): 验证收到的IP地址是否和本地地址在同一网段, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        (:obj:`RipRouter`): RIP协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Rip | Port=${Port} | EnableIpAddrValidation=True |
    """

    result = renix.create_rip(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_rip(Session, **kwargs):
    """
    编辑Rip协议会话对象参数

    Args:

        Session(:obj:`RipRouter`): Rip协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): RIP协会话名称, 类型为：string

        Enable (bool): 使能RIP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        Version (str): RIP版本, 类型为：string, 默认值：RIPV2, 支持版本：

            RIPV1

            RIPV2

            RIPNG

        UpdateType (str): 仿真路由器指定发送RIP消息的通信方式, 类型为：string, 默认值：MULTICAST, 支持方式：

            BROADCAST

            MULTICAST

            UNICAST

        DutIpv4Address (str): 指定接收RIP消息的路由器的IP地址, 当RIP版本为RIPv1或者RIPv2时，该选项可配。 类型为：string, 默认值：224.0.0.9

        DutIpv6Address (str): 指定接收RIP消息的路由器的IP地址, 当RIP版本为RIPng并且更新类型指定为Unicast时，该选项可配。 类型为：string, 默认值：ff02::9

        AuthMethod (str): 认证方式, 当RIP版本为RIPv2时配置该选项。 类型为：string, 默认值：NONE, 支持方式：

            NONE

            SIMPLE

            MD5

        Password (str): 当认证方式为Simple/MD5时，输入的认证密码, 类型为：string, 默认值：Xinetel

        Md5KeyId (int): 当认证方式为MD5时，输入的MD5密钥, 类型为：number, 取值范围：0-255, 默认值：1

        UpdateInterval (int): 发送RIP更新消息的时间间隔，单位为秒, 类型为：number, 取值范围：1-65535, 默认值：30

        UpdateJitter (int): 发送RIP更新消息的时间抖动, 类型为：number, 取值范围：0-5, 默认值：0

        MaxRoutePerUpdate (int): 更新消息中可携带的最大路由数, 类型为：number, 取值范围：1-70, 默认值：25

        SplitHorizon (bool): 是否开启水平分割功能, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableViewRoutes (bool): 是否需要查看学到的路由信息, 类型为：bool, 取值范围：True或False, 默认值：False

        EnableIpAddrValidation (bool): 验证收到的IP地址是否和本地地址在同一网段, 类型为：bool, 取值范围：True或False, 默认值：False

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Rip | Session=${Session} | EnableViewRoutes=True |
    """

    result = renix.edit_rip(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_rip_ipv4_route(Session, **kwargs):
    """
    创建RIP IPv4路由对象

    Args:

        Session(:obj:`RipRouter`): Rip协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): RIP IPv4路由名称, 类型为：string

        Enable (bool): 使能RIP IPv4路由, 类型为：bool, 取值范围：True或False, 默认值：True

        RouteCount (str): 路由池中包含的路由的个数, 类型为：string, 取值范围：1-16777215, 默认值：1

        StartIpv4Prefix (str): 指定起始IPv4地址, 类型为：string, 取值范围：有效的ipv4地址, 默认值：192.168.1.0

        PrefixLength (int): 地址前缀长度, 类型为：number, 取值范围：1-32, 默认值：24

        Increment (str): 增量步长, 类型为：string, 取值范围：1-255, 默认值：1

        NextHop (str): 指定路由下一跳, 类型为：string, 取值范围：有效的ipv4地址, 默认值：0.0.0.0

        Metric (int): 路由度量, 16表示不可达。 类型为：number, 取值范围：1-16, 默认值：1

        RouteTag (int): 路由标签域的值, 0表示没有tag. 类型为：number, 取值范围：0-65535, 默认值：0

    Returns:

        (:obj:`RipIpv4RouteConfig`): RIP IPv4路由对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Rip | Port=${Port} |
            | Create Rip Ipv4 Route | Session=${Session} | Metric=10 |
    """

    result = renix.create_rip_ipv4_route(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_rip_ipv6_route(Session, **kwargs):
    """
    创建RIP IPv6路由对象

    Args:

        Session(:obj:`RipRouter`): Rip协议会话对象列表, 类型为：object

    Keyword Args:

        Name (str): RIP IPv6路由名称, 类型为：string

        Enable (bool): 使能RIP IPv6路由, 类型为：bool, 取值范围：True或False, 默认值：True

        RouteCount (int): 路由池中包含的路由的个数, 类型为：number, 取值范围：1-2147483647, 默认值：1

        StartIpv6Prefix (str): 起始IPv6地址, 类型为：string, 取值范围：有效的IPv6地址, 默认值：'2000::'

        RouteStep (str): IP地址的增加步长, 类型为：string, 取值范围：有效的IPv6地址, 默认值：'0:0:0:1::'

        PrefixLength (int): 地址的前缀长度, 类型为：number, 取值范围：1-128, 默认值：64

        NextHop (str): 路由下一跳, 类型为：string, 取值范围：有效的IPv6地址, 默认值：'::'

        Metric (int): 路由度量, 类型为：number, 取值范围：1-16, 默认值：1

        RouteTag (int): 路由标签域的值, 0表示没有tag, 类型为：number, 取值范围：0-65535, 默认值：0

    Returns:

        (:obj:`RipIpv6RouteConfig`): RIP IPv6路由对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Rip | Port=${Port} |
            | Create Rip Ipv6 Route | Session=${Session} |
    """

    result = renix.create_rip_ipv6_route(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def advertise_rip(Sessions):
    """
    通告RIP协议路由

    Args:

        Sessions(:obj:`RipRouter`): RIP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Advertise Rip | Sessions=${Sessions} |
    """

    result = renix.advertise_rip(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def withdraw_rip(Sessions):
    """
    撤销RIP协议通告路由

    Args:

        Sessions(:obj:`RipRouter`): RIP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Withdraw Rip | Sessions=${Sessions} |
    """

    result = renix.withdraw_rip(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def suspend_rip(Sessions):
    """
    暂停RIP协议

    Args:

        Sessions(:obj:`RipRouter`): RIP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Suspend Rip | Sessions=${Sessions} |
    """

    result = renix.suspend_rip(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def resume_rip(Sessions):
    """
    恢复RIP协议

    Args:

        Sessions(:obj:`RipRouter`): RIP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Resume Rip | Sessions=${Sessions} |
    """

    result = renix.resume_rip(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_rip_state(Sessions, State='OPEN', Interval=1, TimeOut=60):
    """
    等待RIP协议会话达到指定状态

    Args:

        Sessions(:obj:`RipRouter`): RIP协议会话对象列表, 类型为：list

        State (list): 等待RIP协议会话达到的状态, 类型为：string, 默认值：达到OPEN, 支持下列状态：

            DISABLED

            NOTSTART

            CLOSED

            OPEN

            SUSPENDED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Rip State | Sessions=${Sessions} | State=OPEN | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_rip_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_rip_session_block_statistic(Session=None, StaItems: list = None):
    """
    获取RIP协议会话统计结果

    Args:

        Session(:obj:`RipRouter`): RIP协议会话对象, 类型为：Object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionBlockId

            SessionCount

            TxAdvertised

            RxAdvertised

            TxWithdrawn

            RxWithdrawn

    Returns:

        dict: eg::

            {
                'TxAdvertised': 10,
                'RxAdvertised': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ospfv2SessionResultPropertySet |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Rip Session Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_rip_session_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_rip_session_statistic(Session=None, SessionId=1, StaItems=None):
    """
    获取RIP协议会话统计结果

    Args:

        Session (:obj:`RipRouter`): RIP协议会话对象, 类型为：Object

        SessionId (int): Session ID, 类型为：int

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            SessionBlockId

            SessionId

            SessionState

            TxAdvertised

            RxAdvertised

            TxWithdrawn

            RxWithdrawn

    Returns:

        dict: eg::

            {
                'TxAdvertised': 10,
                'RxAdvertised': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=Ospfv2SessionResultPropertySet |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Rip Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_rip_session_statistic(Session=Session, SessionId=SessionId, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_rip_router_from_route(Route):
    """
    获取OSPF LSA对应的绑定流源或目的端点对象

    Args:

        Route (:obj:`RipIpv4RouteConfig`): Rip Ipv4 / Ipv6 Route对象, 类型为：object


    Returns:

        Rip Route对应的绑定流源或目的端点对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Rip | Port=${Port} |
            | ${RouterLsa} | Create Rip Ipv4 Router | Session=${Session} | Age=20 |
            | ${Point} | Get Rip Router From Route | Route=${RouterLsa} |
    """

    result = renix.get_rip_router_from_route(Route=Route)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def edit_rip_port_config(Ports, **kwargs):
    """
    修改RIP端口统计对象

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        UpdateRoutesTransmitRate (int): RIP Tx Rate (messages/sec) , 取值范围：1-1000000000, 默认值：1000

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Rip Port Config | Ports=${Ports} | UpdateRoutesTransmitRate=100 |
    """

    result = renix.edit_rip_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
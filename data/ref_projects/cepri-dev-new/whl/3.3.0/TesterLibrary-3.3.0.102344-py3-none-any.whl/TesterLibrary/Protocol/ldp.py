import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------LDP-------------------------------------
def create_ldp(Port, **kwargs):
    """
    创建LDP协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): LDP协会话名称, 类型为：string

        Enable (bool): 使能LDP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        HelloType (str): Hello类型, 类型为：string, 默认值：DIRECT, 取值范围:

            DIRECT

            TARGETED

            DIRECT_TARGETED

        LabelAdvertType (str): 标签分配方式, 类型为：string, 默认值：DIRECT, 取值范围:

            DU

            DOD

        TransportMode (str): Transport Address TLV模式, 类型为：string, 默认值：TESTER_IP, 取值范围:

            TESTER_IP

            ROUTER_ID

            NONE

        DutIpv4Address (int): DUT IPv4地址, 类型为：number, 型为：string, 默认值：2.1.1.1, 取值范围: IPv4地址

        DirectHelloInterval (int): 直连Hello发送间隔(sec), 类型为：number, 默认值：5, 取值范围：1-21845

        TargetedHelloInterval (int): 远端Hello发送间隔(sec), 类型为：number, 默认值：15, 取值范围：1-21845

        KeepAliveInterval (int): 保活间隔(sec), 类型为：number, 默认值：60, 取值范围：1-21845

        LabelReqRetryCount (int): 标签请求间隔(sec), 类型为：number, 默认值：10, 取值范围：1-65535

        LabelReqRetryInterval (int): 标签请求重试次数, 类型为：number, 默认值：60, 取值范围：1-65535

        Authentication (str): 鉴权类型, 类型为：string, 默认值：DIRECT, 取值范围:

            NONE

            MD5

        Password (str): 密码, 类型为：string, 默认值：xinertel

        EgressLabel (str): 出标签方式, 类型为：string, 默认值：DIRECT, 取值范围:

            NEXT_AVAILABLE

            IMPLICIT

            EXPLICIT

        MinLabel (int): 最小标签值, 类型为：number, 默认值：16, 取值范围：0-1048575

        EnableLspResult (bool): LSP统计使能, 类型为：bool, 取值范围：True或False, 默认值： False

        EnablePseudowireLspResult (bool): 伪线LSP统计使能, 类型为：bool, 取值范围：True或False, 默认值： False

        LspBindMode (str): LSP绑定模式, 类型为：string, 默认值：TX_RX, 取值范围:

            TX_RX

            TX

            RX

            NONE

        VcLspBindMode (str): 虚拟电路LSP绑定模式, 类型为：string, 默认值：TX_RX, 取值范围:

            TX_RX

            TX

            RX

            NONE

        GeneralizedLspBindMode (str): 通用伪线LSP绑定模式, 类型为：string, 默认值：TX_RX, 取值范围:

            TX_RX

            TX

            RX

            NONE

    Returns:

        (:obj:`Ldp`): LDP协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Ldp | Port=${Port} |
    """

    result = renix.create_ldp(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ldp(Session, **kwargs):
    """
    编辑LDP协议会话对象参数

    Args:

        Session (:obj:`Ldp`): LDP协议会话对象, 类型为：object

    Keyword Args:

        Name (str): LDP协会话名称, 类型为：string

        Enable (bool): 使能LDP协议会话, 类型为：bool, 取值范围：True或False, 默认值：True

        HelloType (str): Hello类型, 类型为：string, 默认值：DIRECT, 取值范围:

            DIRECT

            TARGETED

            DIRECT_TARGETED

        LabelAdvertType (str): 标签分配方式, 类型为：string, 默认值：DIRECT, 取值范围:

            DU

            DOD

        TransportMode (str): Transport Address TLV模式, 类型为：string, 默认值：TESTER_IP, 取值范围:

            TESTER_IP

            ROUTER_ID

            NONE

        DutIpv4Address (int): DUT IPv4地址, 类型为：number, 型为：string, 默认值：2.1.1.1, 取值范围: IPv4地址

        DirectHelloInterval (int): 直连Hello发送间隔(sec), 类型为：number, 默认值：5, 取值范围：1-21845

        TargetedHelloInterval (int): 远端Hello发送间隔(sec), 类型为：number, 默认值：15, 取值范围：1-21845

        KeepAliveInterval (int): 保活间隔(sec), 类型为：number, 默认值：60, 取值范围：1-21845

        LabelReqRetryCount (int): 标签请求间隔(sec), 类型为：number, 默认值：10, 取值范围：1-65535

        LabelReqRetryInterval (int): 标签请求重试次数, 类型为：number, 默认值：60, 取值范围：1-65535

        Authentication (str): 鉴权类型, 类型为：string, 默认值：DIRECT, 取值范围:

            NONE

            MD5

        Password (str): 密码, 类型为：string, 默认值：xinertel

        EgressLabel (str): 出标签方式, 类型为：string, 默认值：DIRECT, 取值范围:

            NEXT_AVAILABLE

            IMPLICIT

            EXPLICIT

        MinLabel (int): 最小标签值, 类型为：number, 默认值：16, 取值范围：0-1048575

        EnableLspResult (bool): LSP统计使能, 类型为：bool, 取值范围：True或False, 默认值： False

        EnablePseudowireLspResult (bool): 伪线LSP统计使能, 类型为：bool, 取值范围：True或False, 默认值： False

        LspBindMode (str): LSP绑定模式, 类型为：string, 默认值：TX_RX, 取值范围:

            TX_RX

            TX

            RX

            NONE

        VcLspBindMode (str): 虚拟电路LSP绑定模式, 类型为：string, 默认值：TX_RX, 取值范围:

            TX_RX

            TX

            RX

            NONE

        GeneralizedLspBindMode (str): 通用伪线LSP绑定模式, 类型为：string, 默认值：TX_RX, 取值范围:

            TX_RX

            TX

            RX

            NONE

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ldp | Port=${Port} |
            | Edit Ldp | Session=${Session} | HelloType=DIRECT_TARGETED |
    """

    result = renix.edit_ldp(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ldp_ipv4_egress(Session, **kwargs):
    """
    创建LDP IPv4 Egress对象

    Args:

        Session (:obj:`Ldp`): LDP协议会话对象, 类型为：object

    Keyword Args:

        Name (str): LDP IPv4 Egress对象名称, 类型为：string

        Enable (bool): 使能LDP IPv4 Egress, 类型为：bool, 取值范围：True或False, 默认值：True

        FecType (str): Fec类型, 类型为：string, 默认值：PREFIX_FEC, 取值范围:

            PREFIX_FEC

            HOST_FEC

        LspCount (int): Lsp数量, 类型为：number, 默认值：1, 取值范围：1-65535

        StartIpv4Prefix: Lsp IPv4前缀地址, 型为：string, 默认值：192.0.1.0, 取值范围: IPv4地址

        PrefixLength (int): Lsp IPv4前缀长度, 类型为：number, 默认值：24, 取值范围: 1-32

        PrefixStep (int): Lsp IPv4前缀跳变步长, 类型为：number, 默认值：1, 取值范围: 1-65535

        Ipv4PrefixStep: Lsp IPv4前缀地址跳变步长, 型为：string, 默认值：0.0.1.0, 取值范围: IPv4地址

    Returns:

        (:obj:`LdpIpv4EgressLspConfig`): LDP IPv4 Egress对象列表, 类型: list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ldp | Port=${Port} |
            | Edit Ldp | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Egress} | Create Ldp Ipv4 Egress | Session=${Session} |
    """

    result = renix.create_ldp_ipv4_egress(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ldp_ipv4_ingress(Session, **kwargs):
    """
    创建LDP IPv4 Ingress对象

    Args:

        Session (:obj:`Ldp`): LDP协议会话对象, 类型为：object

    Keyword Args:

        Name (str): LDP IPv4 Ingress对象名称, 类型为：string

        Enable (bool): 使能LDP IPv4 Ingress, 类型为：bool, 取值范围：True或False, 默认值：True

        FecType (str): Fec类型, 类型为：string, 默认值：PREFIX_FEC, 取值范围:

            PREFIX_FEC

            HOST_FEC

        LspCount (int): Lsp数量, 类型为：number, 默认值：1, 取值范围：1-65535

        StartIpv4Prefix: Lsp IPv4前缀地址, 型为：string, 默认值：192.0.1.0, 取值范围: IPv4地址

        PrefixLength (int): Lsp IPv4前缀长度, 类型为：number, 默认值：24, 取值范围: 1-32

        PrefixStep (int): Lsp IPv4前缀跳变步长, 类型为：number, 默认值：1, 取值范围: 1-65535

        Ipv4PrefixStep: Lsp IPv4前缀地址跳变步长, 型为：string, 默认值：0.0.1.0, 取值范围: IPv4地址

    Returns:

        (:obj:`LdpIpv4IngressLspConfig`): LDP IPv4 Ingress对象列表, 类型: list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ldp | Port=${Port} |
            | Edit Ldp | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Ingress} | Create Ldp Ipv4 Ingress | Session=${Session} |
    """

    result = renix.create_ldp_ipv4_ingress(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ldp_fec_128(Session, **kwargs):
    """
    创建LDP FEC 128对象

    Args:

        Session (:obj:`Ldp`): LDP协议会话对象, 类型为：object

    Keyword Args:

        Name (str): LDP FEC 128对象名称, 类型为：string

        Enable (bool): 使能LDP FEC 128, 类型为：bool, 取值范围：True或False, 默认值：True

        ControlWordEnable (bool): 控制字使能, 类型为：bool, 取值范围：True或False, 默认值：False

        Encapsulation (str): 封装类型(hex), 类型为：string, 默认值：PREFIX_FEC, 取值范围:

            ETHERNET_TAGGED_MODE

            ETHERNET

            CEM

        GroupId (int): 组ID, 类型为：number, 默认值：1, 取值范围：1-65535

        InterfaceMtu (int): 接口MTU,类型为：number, 默认值：1500, 取值范围: 1-65535

        IncludePwStatusTlv (bool): 伪线状态码使能, 类型为：bool, 取值范围：True或False, 默认值：False

        PwStatusCode (list): 伪线状态码, 类型为：list, 默认值：PW_NOT_FORWARDING, 取值范围:

            PW_NOT_FORWARDING

            LOCAL_AC_RX_FAULT

            LOCAL_AC_TX_FAULT

            LOCAL_PSN_PW_RX_FAULT

            LOCAL_PSN_PW_TX_FAULT

        UseCustomPwStatusTlv (bool): 自定义伪线状态码使能, 类型为：bool, 取值范围：True或False, 默认值：False

        CustomPwStatusCode (int): 自定义伪线状态码, 类型为：number, 默认值：0, 取值范围: 0-4294967295

        VcCount (int): VC数量, 类型为：number, 默认值：1, 取值范围: 0-4294967295

        StartVcId (int): 起始VC, 类型为：number, 默认值：1, 取值范围: 0-4294967295

        VcIdStep (int): VC跳变步长, 类型为：number, 默认值：1, 取值范围: 0-4294967295

    Returns:

        (:obj:`LdpFec128LspConfig`): LDP FEC 128对象列表, 类型: list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ldp | Port=${Port} |
            | Edit Ldp | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Ingress} | Create Ldp Fec 128 | Session=${Session} |
    """

    result = renix.create_ldp_fec_128(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_ldp_fec_129(Session, **kwargs):
    """
    创建LDP FEC 129对象

    Args:

        Session (:obj:`Ldp`): LDP协议会话对象, 类型为：object

    Keyword Args:

        Name (str): LDP FEC 129对象名称, 类型为：string

        Enable (bool): 使能LDP FEC 129, 类型为：bool, 取值范围：True或False, 默认值：True

        ControlWordEnable (bool): 控制字使能, 类型为：bool, 取值范围：True或False, 默认值：False

        Encapsulation (str): 封装类型(hex), 类型为：string, 默认值：PREFIX_FEC, 取值范围:

            ETHERNET_TAGGED_MODE

            ETHERNET

            CEM

        GroupId (int): 组ID, 类型为：number, 默认值：1, 取值范围：1-65535

        InterfaceMtu (int): 接口MTU,类型为：number, 默认值：1500, 取值范围: 1-65535

        IncludePwStatusTlv (bool): 伪线状态码使能, 类型为：bool, 取值范围：True或False, 默认值：False

        PwStatusCode (list): 伪线状态码, 类型为：list, 默认值：PW_NOT_FORWARDING, 取值范围:

            PW_NOT_FORWARDING

            LOCAL_AC_RX_FAULT

            LOCAL_AC_TX_FAULT

            LOCAL_PSN_PW_RX_FAULT

            LOCAL_PSN_PW_TX_FAULT

        UseCustomPwStatusTlv (bool): 自定义伪线状态码使能, 类型为：bool, 取值范围：True或False, 默认值：False

        CustomPwStatusCode (int): 自定义伪线状态码, 类型为：number, 默认值：0, 取值范围: 0-4294967295

        PwCount (int): PW数量, 类型为：number, 默认值：1, 取值范围: 0-65535

        Agi (str): 起始Agi, 型为：string, 默认值：100:1, 取值范围: IPv6地址

        AgiStep (str): Agi跳变步长, 型为：string, 默认值：0:1, 取值范围: IPv6地址

        Saii (str): 起始Saii, 型为：string, 默认值：10.0.0.1, 取值范围: IPv4地址

        SaiiStep (str): Saii跳变步长, 型为：string, 默认值：0.0.0.1, 取值范围: IPv4地址

        Taii (str): 起始Taii, 型为：string, 默认值：192.0.0.1, 取值范围: IPv4地址

        TaiiStep (str): Taii跳变步长, 型为：string, 默认值：0.0.0.1, 取值范围: IPv4地址

    Returns:

        (:obj:`LdpFec129LspConfig`): LDP FEC 129对象列表, 类型: list

    Examples:
        .. code:: RobotFramework

            | ${Session} | Create Ldp | Port=${Port} |
            | Edit Ldp | Session=${Session} | HelloType=DIRECT_TARGETED |
            | ${Ingress} | Create Ldp Fec 129 | Session=${Session} |
    """

    result = renix.create_ldp_fec_129(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ldp_point_from_lsp(Configs):
    """
    获取LDP LSP对应的绑定流源或目的端点对象

    Args:

        Configs (list): 测试仪表LDP LSP对象列表, 类型为：list

    Returns:

        (:obj:`LdpIpv4EgressLspConfig`, `LdpIpv4IngressLspConfig`, `LdpFec128LspConfig`, `LdpFec129LspConfig`): LDP LSP对应的绑定流源或目的端点对象列表, 类型：list

    Examples:
        .. code:: RobotFramework

            | Get Ldp Point From Lsp | Configs=${IPv4EgressLsp} |
    """

    result = renix.get_ldp_point_from_lsp(Configs=Configs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ldp_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待LDP协议会话达到指定状态

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

        State (list): 等待LDP协议会话达到的状态, 类型为：string, 默认值：达到OPERATIONAL, 支持下列状态：

            DISABLED

            NOT_STARTED

            NON_EXISTENT

            INITIAL

            OPEN_SENT

            OPEN_REC

            OPERATIONAL

            RESTARTING

            HELPING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ldp State | Sessions=${Sessions} | State=RESTARTING | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ldp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def establish_ldp(Sessions):
    """
    建立LDP协议会话

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Establish Ldp | Sessions=${Sessions} |
    """

    result = renix.establish_ldp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_ldp_hello(Sessions):
    """
    停止LDP协议会话Hello发送

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Ldp Hello | Sessions=${Sessions} |
    """

    result = renix.stop_ldp_hello(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_ldp_keepalive(Sessions):
    """
    停止LDP协议会话Keepalive发送

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Ldp Keepalive | Sessions=${Sessions} |
    """

    result = renix.stop_ldp_keepalive(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def resume_ldp_hello(Sessions):
    """
    恢复LDP协议会话Hello发送

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Resume Ldp Hello | Sessions=${Sessions} |
    """

    result = renix.resume_ldp_hello(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def resume_ldp_keepalive(Sessions):
    """
    恢复LDP协议会话Keepalive发送

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Resume Ldp Keepalive | Sessions=${Sessions} |
    """

    result = renix.resume_ldp_keepalive(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def restart_ldp(Sessions):
    """
    重启LDP协议会话

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Restart Ldp | Sessions=${Sessions} |
    """

    result = renix.restart_ldp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def request_ldp_label(Configs):
    """
    LDP协议会话LSP请求标签

    Args:

        Configs (list): LDP LSP对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Request Ldp Label | Configs=${Configs} |
    """

    result = renix.request_ldp_label(Configs=Configs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def abort_request_ldp_label(Configs):
    """
    中止LDP协议会话LSP请求标签

    Args:

        Configs (list): LDP LSP对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Abort Request Ldp Label | Configs=${Configs} |
    """

    result = renix.abort_request_ldp_label(Configs=Configs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def withdraw_ldb_label(Configs):
    """
    撤销LDP协议会话LSP标签

    Args:

        Configs (list): LDP LSP对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Withdraw Ldp Label | Configs=${Configs} |
    """

    result = renix.withdraw_ldb_label(Configs=Configs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def advertise_ldp_label(Configs):
    """
    通告LDP协议会话LSP标签

    Args:

        Configs (list): LDP LSP对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Advertise Ldp Label | Configs=${Configs} |
    """

    result = renix.advertise_ldp_label(Configs=Configs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_ldp(Sessions):
    """
    启动LDP协议会话

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Ldp | Sessions=${Sessions} |
    """

    result = renix.start_ldp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_ldp(Sessions):
    """
    停止LDP协议会话

    Args:

        Sessions (list): LDP协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Ldp | Sessions=${Sessions} |
    """

    result = renix.stop_ldp(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ldp_session_statistic(Session=None, StaItems: list = None):
    """
    获取Ldp Session统计结果

    Args:

        Session (:obj:`Ldp`): LDP会话对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            TxAddressWithdraw

            RxAddressWithdraw

            TxAddress

            RxAddress

            TxDirectHello

            RxDirectHello

            TxInitialization

            RxInitialization

            TxKeepAlive

            RxKeepAlive

            TxLabelAbort

            RxLabelAbort

            TxLabelMapping

            RxLabelMapping

            TxLabelRelease

            RxLabelRelease

            TxLabelRequest

            RxLabelRequest

            TxLabelWithdraw

            RxLabelWithdraw

            TxNotification

            RxNotification

            TxTargetHello

            RxTargetHello

            TxIPv6DirectHello

            RxIPv6DirectHello

            TxIPv6TargetHello

            RxIPv6TargetHello

    Returns:

        dict: eg::

            {
                'TxIPv6TargetHello': 10,
                'RxIPv6TargetHello': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=LdpSessionStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ldp Session Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ldp_session_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ldp_lsp_statistic(Session=None, StaItems: list = None):
    """
    获取Ldp Lsp统计结果

    Args:

        Session (:obj:`Ldp`): LDP会话对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            FECInfo

            FECType

            LabelValue

            LspMode

            LspState

            LspType

    Returns:

        dict: eg::

            {
                'LabelValue': 16,
                'LspMode': DU,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | AdjacencyState | TxUpdate |
            | Subscribe Result | Types=LdpLspStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Ldp Lsp Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_ldp_lsp_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ldp_port_config(Ports, **kwargs):
    """
    修改LDP端口配置对象

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        EstablishRate (int): LDP发送速率(messages/sec), 取值范围：1-10000, 默认值：100

        AdvertiseRate (int): 会话建立速率(sessions/sec), 取值范围：1-10000, 默认值：100

        ReleaseRate (int): 会话释放速率(sessions/sec), 取值范围：1-10000, 默认值：100

        FecPerLdpMsg (int): 取值范围：1-65535, 默认值：65535

    Returns:

        (:obj:`LdpPortConfig`): LDP Port Config对象, 类型：object / list

    Examples:
        .. code:: RobotFramework

            | Edit LDP Port Config | Ports=${Port} | TcpServerPort=10 |
    """

    result = renix.edit_ldp_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------ovsdb-------------------------------------
def create_ovsdb(Port, **kwargs):
    """
    创建ovsdb协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        OvsdbControllerIpList (list): OVSDB Controller IP List, 默认值："", 取值范围：有效的ip地址

    Returns:

        (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Ovsdb | Port=${Port} | OvsdbControllerIpList=1.1.1.1 |
    """

    result = renix.create_ovsdb(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_ovsdb_state(Sessions, State='STARTED', Interval=1, TimeOut=60):
    """
    等待ovsdb协议会话达到指定状态

    Args:

        Sessions(:obj:`Ovsdb`): ovsdb协议会话对象列表, 类型为：list

        State (list): 等待协议会话达到的状态, 默认值：达到STARTED, 支持下列状态：

            STARTED

            STOPPED

        Interval (int): 查询协议会话的间隔, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Ovsdb State | Sessions=${Sessions} | State=IDLE | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_ovsdb_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ovsdb_port_config(Ports, **kwargs):
    """
    修改ovsdb端口配置

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象列表, 类型为：list

    Keyword Args:

        OvsdbConnectionType (str): OVSDB Connection Type, 默认值：TCP，取值范围：

            TCP

            TLS

            PASSIVE_TCP

            PASSIVE_TLS

        PrivateKey (str): Private Key, 默认值：""

        Certificate (str): Certificate, 默认值：""

        CaCertificate (str): CA Certificate, 默认值：""

        ConnectRate (int): Connection Rate, 默认值：1000，取值范围：0-65535

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Ovsdb Port Config | Ports=${Ports} | RequestRate=1000 |
    """

    result = renix.edit_ovsdb_port_config(Ports=Ports, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ovsdb_table(**kwargs):
    """
    修改ovsdb table

    Keyword Args:

        OvsdbRefreshWay (str): 默认值：MANUAL，取值范围：

            MANUAL

            PERIODIC

        OvsdbTimer (int): 默认值：30，取值范围：1-65535

        OvsdbContents (str): 默认值：""

        OvsdbDatabaseType (str): Data Base Type, 默认值：HARDWAREVTEP，取值范围：

            HARDWAREVTEP

        OvsdbTableType (str): Table Type, 默认值：LOCAL，取值范围：

            LOCAL

            REMOTE

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Ovsdb Table | RequestRate=1000 |
    """

    result = renix.edit_ovsdb_table(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_ovsdb_export(**kwargs):
    """
    修改ovsdb export

    Keyword Args:

        OvsdbDatabaseType (str): Data Base Type, 默认值：HARDWAREVTEP，取值范围：

            HARDWAREVTEP

        OvsdbTableType (str): Table Type, 默认值：LOCAL，取值范围：

            LOCAL

            REMOTE

        OvsdbExportFilePrefix (str): Export File Prefix, 默认值：OVSDB_Contents_

        OvsdbSaveAsArchive (bool): Save As Archive, 默认值：FALSE，取值范围：

            TRUE

            FALSE

        OvsdbExportPath (str): Export Path, 默认值：""

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Edit Ovsdb Export | OvsdbSaveAsArchive=True |
    """

    result = renix.edit_ovsdb_export(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_upload_ca_certificate(Ports, LocalPath, Files):
    """
    上传CA证书

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        LocalPath (str): Local Path, 默认值：""

        Files (list): File Name list, 默认值：[]

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Upload Ca Certificate | Ports=${Ports} | LocalPath='D:\\files\\tls' | Files=${files} |
    """

    result = renix.ovsdb_upload_ca_certificate(Ports=Ports, LocalPath=LocalPath, Files=Files)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_upload_certificate(Ports, LocalPath, Files):
    """
    上传证书

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        LocalPath (str): Local Path, 默认值：""

        Files (list): File Name list, 默认值：[]

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Upload Certificate | Ports=${Ports} | LocalPath='D:\\files\\tls' | Files=${files} |
    """

    result = renix.ovsdb_upload_certificate(Ports=Ports, LocalPath=LocalPath, Files=Files)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_upload_private_key(Ports, LocalPath, Files):
    """
    上传私钥

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        LocalPath (str): Local Path, 默认值：""

        Files (list): File Name list, 默认值：[]

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Upload Private Key | Ports=${Ports} | LocalPath='D:\\files\\tls' | Files=${files} |
    """

    result = renix.ovsdb_upload_private_key(Ports=Ports, LocalPath=LocalPath, Files=Files)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_refresh_files(Ports):
    """
    刷新文件

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Refrsh Files | Ports=${Ports} |
    """

    result = renix.ovsdb_refresh_files(Ports=Ports)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_delete_certificate(Ports, Files):
    """
    删除证书

    Args：

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        Files (list): File Name list, 默认值：[]

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Delete Certificate | Ports=${Ports} | Files=${files} |
    """

    result = renix.ovsdb_delete_certificate(Ports=Ports, Files=Files)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_start_refresh_table(Sessions):
    """
    Start Refresh Table

    Args：

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Start Refresh Table | Sessions=${Sessions} |
    """

    result = renix.ovsdb_start_refresh_table(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_stop_refresh_table(Sessions):
    """
    Stop Refresh Table

    Args：

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Stop Refresh Table | Sessions=${Sessions} |
    """

    result = renix.ovsdb_stop_refresh_table(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_query_db(Sessions):
    """
    Query DB

    Args：

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Query Db | Sessions=${Sessions} |
    """

    result = renix.ovsdb_query_db(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_query_db_oneshot(Sessions):
    """
    Query DB Oneshot

    Args：

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Query Db Oneshot | Sessions=${Sessions} |
    """

    result = renix.ovsdb_query_db_oneshot(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_query_db_period(Sessions):
    """
    Query DB Period

    Args：

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Query Db Period | Sessions=${Sessions} |
    """

    result = renix.ovsdb_query_db_period(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_stop_query_db_period(Sessions):
    """
    Stop Query DB Period

    Args：

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Stop Query Db Period | Sessions=${Sessions} |
    """

    result = renix.ovsdb_stop_query_db_period(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def ovsdb_export_contents(Sessions):
    """
    Stop Query DB Period

    Args：

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Ovsdb Stop Query Db Period | Sessions=${Sessions} |
    """

    result = renix.ovsdb_export_contents(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_ovsdb_statistic(Sessions=None, StaItems: list = None):
    """
    获取ovsdb统计结果

    Args:

        Sessions (:obj:`Ovsdb`): ovsdb协议会话对象列表, 类型：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            ReadCount

            WriteCount

    Returns:

        dict: eg::

            {
                'ReadCount': 10,
                'WriteCount': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Ovsdb Statistic | Sessions=${Sessions} | StaItems=@{StaItems} |
    """

    result = renix.get_ovsdb_statistic(Sessions=Sessions, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

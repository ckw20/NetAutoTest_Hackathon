import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------twamp-------------------------------------
def create_twamp(Port, **kwargs):
    """
    创建twamp协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        ActiveClient (bool): Select to enable TWAMP client or controller emulation, 默认值：False，取值范围：

            True

            False

        ActiveServer (bool): Select to enable TWAMP server emulation, 默认值：False，取值范围：

            True

            False

        IpLayerVersion (str): Version of IP for this interface, 默认值：IPv4，取值范围：

            IPv4

            IPv6

        EnableLight (bool): Select to enable the TWAMP Light protocol, 默认值：False，取值范围：

            True

            False

        Ipv6AddressType (str): Type of address, 默认值：GLOBAL，取值范围：

            GLOBAL

            LINKLOCAL

        ScalabilityMode (str): Select Discard Test Statistics to reduce the demand on the processor for large-scale testing, 默认值：NORMAL，取值范围：

            NORMAL

            DISCARDSTATISTICS

        PeerIpv4Address (str): IPv4 address of the peer (DUT port), 默认值：192.85.1.1，取值范围：有效的ipv4地址

        PeerIpv6Address (str): IPv6 address of the peer (DUT port), 默认值：2001::1，取值范围：有效的ipv6地址

        ConnectionRetryInterval (int): Number of seconds to wait between connection attempts, 默认值：30，取值范围：10-255

        ConnectionRetryCount (int): Number of times to attempt a connection before timing out, 默认值：100，取值范围：0-65535

        WillingToParticipate (bool): Sets the value of the bit in the modes field, 默认值：True，取值范围：

            True

            False

        Mode (list): Sets the security mode, 默认值：['NONE', 'UNAUTNENTICATED']，取值范围：

            NONE

            UNAUTNENTICATED

        LocalUdpPorts (int): Port number of the local UDP ports, 默认值：862，取值范围：0-65535

        ServWaitTime (int): Number of seconds that the Server discontinue any established control connection when no packet associated with that connection has been received, 默认值：900，取值范围：0-65535

        RefWaitTime (int): Number of seconds that the Session-Reflector discontinue any session that has been started when no packet associated with that session has been received, 默认值：900，取值范围：0-65535

    Returns:

        (:obj:`Twamp`): twamp协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Twamp | Port=${Port} | RefWaitTime=255 |
    """

    result = renix.create_twamp(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_twamp_state(Sessions, State='ESTABLISHED', Interval=1, TimeOut=60):
    """
    等待twamp协议会话达到指定状态

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        State (list): 等待协议会话达到的状态, 默认值：达到ESTABLISHED, 支持下列状态：

            DISABLED

            IDLE

            CONNECT

            ESTABLISHED

            SESSIONREQUESTED

            STARTED

        Interval (int): 查询协议会话的间隔, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Twamp State | Sessions=${Sessions} | State=IDLE | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_twamp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_twamp_test_session(Twamps, **kwargs):
    """
    修改twamp test session对象

    Args:

        Twamps(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

    Keyword Args:

        SourceUdpPort (int): UDP port from which TWAMP-Test packets are sent by the Session-Sender, 默认值：5450，取值范围：0-65535

        DestinationUdpPort (int): UDP port to which TWAMP-Test packets are sent by the Session-Reflector, 默认值：5450，取值范围：0-65535

        Timeout (int): Number of seconds that the Session-Reflector waits after receiving a Stop-Sessions message, 默认值：30，取值范围：0-65535

        DurationMode (str): Type of maintenance point, 默认值：SECONDS，取值范围：

            SECONDS

            PACKETS

            CONTINUOUS

        Duration (int): Number of seconds to run the test session, 默认值：60，取值范围：0-65535

        PacketCount (int): Number of packets to run the test session, 默认值：100，取值范围：0-65535

        PaddingLength (int): Number of octets to be appended to the normal TWAMP-Test packet, 默认值：128，取值范围：27-9000

        FrameRate (int): Rate at which to send TWAMP-Test packets in frames per second, 默认值：10，取值范围：1-1000

        Dscp (int): DiffServ code point value, 默认值：100，取值范围：1-255

        Ttl (int): Time To Live value, 默认值：255，取值范围：1-255

        PaddingPattern (str): Type of data to be used for padding, 默认值：RANDOM，取值范围：

            RANDOM

            USERDEFINED_STRING

            USERDEFINED_HEX

        UserDefinedString (str): User defined Padding Pattern (String), 默认值：xinertel.com

        UserDefinedHex (list): User defined Padding Pattern (Hex), 默认值：[]，取值范围：列表元素为0-255的十进制数

    Returns:

        (:obj:`TwampTestSessionConfig`): Twamp Test Session对象, 类型：object

    Examples:
        .. code:: RobotFramework

            |  Edit Twamp Test Session | Twamps=${Twamps} | PaddingPattern=USERDEFINED_STRING |
    """

    result = renix.edit_twamp_test_session(Twamps=Twamps, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_twamp_session_state(TestSessions, State='ACCEPTED', Interval=1, TimeOut=60):
    """
    等待twamp session达到指定状态

    Args:

        TestSessions(:obj:`TwampTestSessionConfig`): twamp test session对象列表, 类型为：list

        State (list): 等待协议会话达到的状态, 默认值：达到ACCEPTED, 支持下列状态：

            IDLE

            ACCEPTED

            REJECTED

            INPROCESS

            PAUSED

        Interval (int): 查询协议会话的间隔, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Twamp Session State | Sessions=${Sessions} | State=IDLE | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_twamp_session_state(TestSessions=TestSessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def twamp_start(Sessions):
    """
    启动twamp

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Twamp Start | Sessions=${Sessions} |
    """

    result = renix.twamp_start(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def twamp_stop(Sessions):
    """
    停止twamp

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Twamp Stop | Sessions=${Sessions} |
    """

    result = renix.twamp_stop(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def twamp_start_session(Sessions, TestSessions, **kwargs):
    """
    启动Twamp Test Session

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        TestSessions(:obj:`TwampTestSessionConfig`): Twamp Test Session对象, 类型：object

    Keyword Args:

        ControlType (str): Operate type, 默认值：REQUEST，取值范围：

            REQUEST

            START

            STOP

            PAUSE

            RESUME

            STARTTWAMP

            STOPTWAMP

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Twamp Start Session | Sessions=${Sessions} | TestSessions=${TestSessions} | ControlType=STOPTWAMP |
    """

    result = renix.twamp_start_session(Sessions=Sessions, TestSessions=TestSessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def twamp_stop_session(Sessions, TestSessions, **kwargs):
    """
    停止Twamp Test Session

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        TestSessions(:obj:`TwampTestSessionConfig`): Twamp Test Session对象, 类型：object

    Keyword Args:

        ControlType (str): Operate type, 默认值：REQUEST，取值范围：

            REQUEST

            START

            STOP

            PAUSE

            RESUME

            STARTTWAMP

            STOPTWAMP

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Twamp Stop Session | Sessions=${Sessions} | TestSessions=${TestSessions} | ControlType=STOPTWAMP |
    """

    result = renix.twamp_stop_session(Sessions=Sessions, TestSessions=TestSessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def twamp_request_session(Sessions, TestSessions, **kwargs):
    """
    Twamp Request Test Session

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        TestSessions(:obj:`TwampTestSessionConfig`): Twamp Test Session对象, 类型：object

    Keyword Args:

        ControlType (str): Operate type, 默认值：REQUEST，取值范围：

            REQUEST

            START

            STOP

            PAUSE

            RESUME

            STARTTWAMP

            STOPTWAMP

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Twamp Request Session | Sessions=${Sessions} | TestSessions=${TestSessions} | ControlType=STOPTWAMP |
    """

    result = renix.twamp_request_session(Sessions=Sessions, TestSessions=TestSessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def twamp_pause_session(Sessions, TestSessions, **kwargs):
    """
    Twamp Pause Test Session

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        TestSessions(:obj:`TwampTestSessionConfig`): Twamp Test Session对象, 类型：object

    Keyword Args:

        ControlType (str): Operate type, 默认值：REQUEST，取值范围：

            REQUEST

            START

            STOP

            PAUSE

            RESUME

            STARTTWAMP

            STOPTWAMP

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Twamp Pause Session | Sessions=${Sessions} | TestSessions=${TestSessions} | ControlType=STOPTWAMP |
    """

    result = renix.twamp_pause_session(Sessions=Sessions, TestSessions=TestSessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def twamp_resume_session(Sessions, TestSessions, **kwargs):
    """
    Twamp Pause Test Session

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        TestSessions(:obj:`TwampTestSessionConfig`): Twamp Test Session对象, 类型：object

    Keyword Args:

        ControlType (str): Operate type, 默认值：REQUEST，取值范围：

            REQUEST

            START

            STOP

            PAUSE

            RESUME

            STARTTWAMP

            STOPTWAMP

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Twamp Resume Session | Sessions=${Sessions} | TestSessions=${TestSessions} | ControlType=STOPTWAMP |
    """

    result = renix.twamp_resume_session(Sessions=Sessions, TestSessions=TestSessions, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_twamp_client_statistic(Sessions=None, StaItems: list = None):
    """
    获取Twamp Client统计结果

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            RxAcceptSession

            RxFailedSession

            RxStartAck

            TxRequestSession

            TxStartSession

            TxStopSession

    Returns:

        dict: eg::

            {
                'TxStartSession': 10,
                'TxStopSession': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Twamp Client Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_twamp_client_statistic(Sessions=Sessions, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_twamp_server_statistic(Sessions=None, StaItems: list = None):
    """
    获取Twamp Client统计结果

    Args:

        Sessions(:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            State

            RxRequestSession

            RxStartSession

            RxStopSession

            TxAcceptSession

            TxFailedSession

            TxStartAck

    Returns:

        dict: eg::

            {
                'TxAcceptSession': 10,
                'TxFailedSession': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Twamp Server Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_twamp_server_statistic(Sessions=Sessions, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_twamp_port_client_statistic(Ports=None, StaItems: list = None):
    """
    获取twamp port client统计结果

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            RxAcceptSession

            RxFailedSession

            RxStartAck

            TxRequestSession

            TxStartSession

            TxStopSession

    Returns:

        dict: eg::

            {
                'TxStartSession': 10,
                'TxStopSession': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Twamp Port Client Statistic | Ports=${Ports} | StaItems=@{StaItems} |
    """

    result = renix.get_twamp_port_client_statistic(Ports=Ports, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_twamp_port_server_statistic(Ports=None, StaItems: list = None):
    """
    获取twamp port server统计结果

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            RxRequestSession

            RxStartSession

            RxStopSession

            TxAcceptSession

            TxFailedSession

            TxStartAck

    Returns:

        dict: eg::

            {
                'RxRequestSession': 10,
                'RxStartSession': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Twamp Port Server Statistic | Ports=${Ports} | StaItems=@{StaItems} |
    """

    result = renix.get_twamp_port_server_statistic(Ports=Ports, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_twamp_test_session_statistic(Twamps=None, StaItems: list = None):
    """
    获取twamp Test Session统计结果

    Args:

        Twamps (:obj:`Twamp`): twamp协议会话对象列表, 类型为：list

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            AverageJitter

            AverageLatency

            AverageServerProcessingTime

            MaximumJitter

            MaximumLatency

            MaximumServerProcessingTime

            MinimumJitter

            MinimumLatency

            MinimumServerProcessingTime

    Returns:

        dict: eg::

            {
                'MinimumJitter': 10,
                'MinimumLatency': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Twamp Test Session Statistic | Twamps=${Twamps} | StaItems=@{StaItems} |
    """

    result = renix.get_twamp_test_session_statistic(Twamps=Twamps, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_twamp_port_test_session_statistic(Ports=None, StaItems: list = None):
    """
    获取twamp Port Test Session统计结果

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            AverageJitter

            AverageLatency

            AverageServerProcessingTime

            MaximumJitter

            MaximumLatency

            MaximumServerProcessingTime

            MinimumJitter

            MinimumLatency

            MinimumServerProcessingTime

    Returns:

        dict: eg::

            {
                'MinimumJitter': 10,
                'MinimumLatency': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Twamp Port Test Session Statistic | Ports=${Ports} | StaItems=@{StaItems} |
    """

    result = renix.get_twamp_port_test_session_statistic(Ports=Ports, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def get_twamp_state_statistic(Ports=None, StaItems: list = None):
    """
    获取twamp State统计结果

    Args:

        Ports (:obj:`Port`): 测试仪表端口对象, 类型为：object

        StaItems (list): 需要获取流模板统计项目，类型为：list，目前支持的统计项

            Connect

            Established

            Idle

            SessionRequested

            ConnectionsDown

            ConnectionsUp

    Returns:

        dict: eg::

            {
                'ConnectionsDown': 10,
                'ConnectionsUp': 10,
            }

    Examples:
        .. code:: RobotFramework

            | Get Twamp State Statistic | Ports=${Ports} | StaItems=@{StaItems} |
    """

    result = renix.get_twamp_state_statistic(Ports=Ports, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result






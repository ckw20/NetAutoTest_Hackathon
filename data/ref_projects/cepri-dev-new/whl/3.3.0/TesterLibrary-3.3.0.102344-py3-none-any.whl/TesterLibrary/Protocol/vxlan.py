import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------Vxlan-------------------------------------
def create_vxlan(Port, **kwargs):
    
    """
    创建Vxlan协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): Vxlan协会话名称, 类型为：string

        Enable (bool): 使能Vxlan协议会话, 默认值：True
    
        AutoUdpSourcePort (bool): 自动计算UDP源端口, 默认值：True

        UdpSourcePort (int): 配置UDP源端口, 取值范围：3-4095, 默认值：1025

        EnableUdpChecksum (bool): 使能计算UDP校验和, 默认值：False

        EvpnLearning (bool): 使能EVPN学习, 默认值：False

        OvsdbLearning (bool): 使能OVSDB学习, 默认值：False

        MulticastType (str): 组播类型, 默认值：IGMP, 取值范围：

            IGMP

            PIM

            MLD

        VtepTunnelIp (str): VTEP 隧道IP地址, 默认值：INTERFACEIP, 取值范围：

            INTERFACEIP

            ROUTERID

        EnableIrb (bool): 默认值：False

        RPAddress (str): 选择PIM的RP地址, 取值范围：IPv4地址, 默认值：192.0.0.1

        RPIpv6Address (str): 选择PIM的RP地址, 取值范围：IPv6地址, 默认值：2000::1

        IrbMode (str): 默认值：Symmetric, 取值范围：

            Symmetric

    Returns:

        (:obj:`Vxlan`): Vxlan协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Vxlan | Port=${Port} |
    """

    result = renix.create_vxlan(Port=Port, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_vxlan(Session, **kwargs):
    """
    创建Vxlan协议会话对象

    Args:

        Session (:obj:`Vxlan`): Vxlan协议会话对象, 类型为：object

    Keyword Args:

        Name (str): Vxlan协会话名称, 类型为：string

        Enable (bool): 使能Vxlan协议会话, 默认值：True

        AutoUdpSourcePort (bool): 自动计算UDP源端口, 默认值：True

        UdpSourcePort (int): 配置UDP源端口, 取值范围：3-4095, 默认值：1025

        EnableUdpChecksum (bool): 使能计算UDP校验和, 默认值：False

        EvpnLearning (bool): 使能EVPN学习, 默认值：False

        OvsdbLearning (bool): 使能OVSDB学习, 默认值：False

        MulticastType (str): 组播类型, 默认值：IGMP, 取值范围：

            IGMP

            PIM

            MLD

        VtepTunnelIp (str): VTEP 隧道IP地址, 默认值：INTERFACEIP, 取值范围：

            INTERFACEIP

            ROUTERID

        EnableIrb (bool): 默认值：False

        RPAddress (str): 选择PIM的RP地址, 取值范围：IPv4地址, 默认值：192.0.0.1

        RPIpv6Address (str): 选择PIM的RP地址, 取值范围：IPv6地址, 默认值：2000::1

        IrbMode (str): 默认值：Symmetric, 取值范围：

            Symmetric

    Returns:

        (:obj:`Vxlan`): Vxlan协议会话对, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Vxlan | Port=${Port} |
    """

    result = renix.edit_vxlan(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_vxlan_segment(**kwargs):
    """
    创建Vxlan Segment对象

    Keyword Args:

        Name (str): Vxlan协会话名称, 类型为：string

        Enable (bool): 使能Vxlan协议会话, 默认值：True

        StartVni (int): 起始 VNI, 取值范围：0-16777215, 默认值：0

        VniCount (int): VNI个数, 取值范围：1-65535, 默认值：1

        VniStep (int): VNI 跳变步长, 取值范围：1-65535, 默认值：1

        CommunicationType (str): 学习方式, 默认值：UNICAST, 取值范围：

            UNICAST

            MULTICAST

            VxlanEVPN

        VniDistributionType (str): VNI在VPN之间的分配方式, 默认值：ROUNDROBIN, 取值范围：

            ROUNDROBIN

            LINEAR

        EnableL3Vni (bool): 使能L3VNI, 默认值：False

        StartL3Vni (int): 起始L3VNI, 取值范围：1-16777215, 默认值：1

        L3VniStep (int): L3VNI跳变步长, 取值范围：1-16777215, 默认值：1

        L3VniCount (int): L3 VNI数量, 取值范围：1-65535, 默认值：1

        VniTrafficType (str): 流端点模式, 默认值：L2VNI, 取值范围：

            L2VNI

            L3VNI

            L2AndL3VNI

        EnableVmArp (bool): 使能VM ARP, 默认值：False

    Returns:

        (:obj:`VxlanSegmentConfig`): Vxlan Segment对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Vxlan Segment | Port=${Port} |
    """

    result = renix.create_vxlan_segment(**kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def binding_vxlan_multicast_group(Segments, MulticastGroups):
    """
    创建Vxlan Multicast Group对象

    Args:
        
        Segments (:obj:`VxlanSegmentConfig`): Vxlan Segment对象, 类型：object
        
        MulticastGroups (:obj:`Ipv4MulticastGroup`): Vxlan Multicast Group对象, 类型：object

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Binding Vxlan Multicast Group | Segments=${Segments} | MulticastGroups=${MulticastGroups} |
    """
    result = renix.binding_vxlan_multicast_group(Segments=Segments, MulticastGroups=MulticastGroups)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def binding_vxlan_vm(Segments, Interfaces):
    """
    绑定Vxlan Vm对象

    Args:

        Segments (:obj:`VxlanSegmentConfig`): Vxlan Segment对象

        Interfaces (list (:obj:`Interface`)): Vm Interface对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Binding Vxlan Vm | Segments=${Segments} | Vms=${Vms} |
    """
    
    result = renix.binding_vxlan_vm(Segments=Segments, Interfaces=Interfaces)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def binding_vxlan_vtep(Vteps, Interfaces):
    """
    绑定Vxlan Vtep对象

    Args:

        Vteps (list (:obj:`Vxlan`)): Vxlan协议会话对象

        Interfaces (list (:obj:`Interface`)): Vm Interface对象

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Binding Vxlan Vtep | Vteps=${Vxlan} | Interfaces=${Interfaces} |
    """
    result = renix.binding_vxlan_vtep(Vteps=Vteps, Interfaces=Interfaces)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def start_vxlan_ping(Interfaces, **kwargs):
    """
    启动Vxlan Ping

    Args:

        Interfaces (:obj:`Interface`): Interface对象列表, 类型为：list

    Keyword Args:

        FrameCount (int): 默认值：1，取值范围：1-1000

        TimeInterval (int): 默认值：1，取值范围：1-10

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Start Vxlan Ping | Interfaces=${Interface} |
    """
    result = renix.start_vxlan_ping(Interfaces=Interfaces, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def stop_vxlan_ping(Interfaces, **kwargs):
    """
    停止Vxlan Ping

    Args:

        Interfaces (:obj:`Interface`): Interface对象列表, 类型为：list

    Keyword Args:

        FrameCount (int): 默认值：1，取值范围：1-1000

        TimeInterval (int): 默认值：1，取值范围：1-10

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Stop Vxlan Ping | Interfaces=${Interface} |
    """
    result = renix.stop_vxlan_ping(Interfaces=Interfaces, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_vxlan_vm_property(Interface):
    """
    获取Vxlan Vm Property对象

    Args:

        Interface (:obj:`Interface`): Interface对象, 类型为：object

    Returns:

        (:obj:`VxlanVmProperty`): Vxlan Vm Property对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | ${Vm} | Get Vxlan Vm Property | Interface=${Interface} |
            | Edit Configs | ${Vm} | OverrideAttachedVtepIp=True | AttachedVtepAddr=3.3.3.3 | AttachedIp6VtepAddr=2022::2 |
    """
    result = renix.get_vxlan_vm_property(Interface=Interface)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_vxlan_vm_point(Vxlan):
    """
    获取Vxlan Vm对应的绑定流源或目的端点对象

    Args:

        Vxlan (:obj:`Vxlan`): Rip Ipv4 / Ipv6 Route对象, 类型为：object


    Returns:

        Vxlan Vm对应的绑定流源或目的端点对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Get Vxlan Vm Point | Vxlan=${Vxlan} |
    """

    result = renix.get_vxlan_vm_point(Vxlan=Vxlan)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_vxlan_statistic(Session=None, StaItems=None):
    """
    获取测试仪表vxlan统计

    Args:

        Session (:obj:`Vxlan`): Vxlan协议会话对象, 类型为：object

        StaItems (list): 需要获取Vxlan统计项目, 类型为：list，目前支持的统计项

            VtepId: VXLAN会话的名称

            VtepState: VXLAN会话的状态

            TotalVmCount：VM总数

            ResolvedVmCount: 已解析VM

            UnresolvedVmCount: 未解析VM

    Returns:

        dict:
            .. code:: RobotFramework

                {"TotalVmCount": 100, "ResolvedVmCount": 100}

    Examples:
        .. code:: RobotFramework

            | Subscribe Result |
            | Start Protocol |
            | Sleep | 10 |
            | Stop Protocol |
            | Sleep | 3 |
            | ${Port} | Get Ports |
            | ${Session} | Get Session | Ports=@{Port} | Protocols=vxlan |
            | ${StaItems} | Create List | TotalVmCount | ResolvedVmCount |
            | &{Result} | Get Vxlan Statistic | Session=${Session} | StaItems=@{StaItems} |
    """

    result = renix.get_vxlan_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

def wait_vxlan_state(Sessions, State='STARTED', Interval=1, TimeOut=60):
    """
    等待VXLAN协议会话达到指定状态

    Args:

        Sessions(:obj:`Vxlan`): VXLAN协议会话对象列表, 类型为：list

        State (list): 等待RIP协议会话达到的状态, 类型为：string, 默认值：达到STARTED, 支持下列状态：

            STARTED

            STOPPED

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Vxlan State | Sessions=${Sessions} | State=STARTED | Interval=2 | TimeOut=120 |
    """

    result = renix.wait_vxlan_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result
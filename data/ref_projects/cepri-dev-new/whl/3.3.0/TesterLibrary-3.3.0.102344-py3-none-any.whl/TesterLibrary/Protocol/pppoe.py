import sys
from TesterLibrary.Encryption.data import renix
from robot.api import ContinuableFailure, Failure


# -------------------------PPPoEClent-------------------------------------
def create_pppoe(Port, EmulationMode='CLIENT', **kwargs):
    """
    创建PPPoE协议会话对象

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：object

        EmulationMode (str): PPPoE角色, 默认值：CLIENT, 取值范围：

            CLIENT

            SERVER

    Keyword Args:

        Name (str): PPPoE协议会话名称, 类型为：string

        Enable (bool): 使能PPPoE协议会话, 默认值：True

        AuthenticationType (str): 认证方式, 默认值：NO_AUTHENTICATION, 取值范围：

            NO_AUTHENTICATION

            NEGOTIATION

            CHAP_MD5

            PAP

        Username (str): 用户名, 默认值：xinertel, 取值范围：string length in [1,126]

        Password (str): 密码, 默认值：xinertel, 取值范围：string length in [1,126]

        ServiceName (str): 服务名, 默认值："", 取值范围：string length in [0,255]

        EnableMaxPayloadTag (bool): 使能最大净荷标签, 默认值：False

        MaxPayloadBytes (int): 最大净荷(字节), 取值范围：1-65535, 默认值：1500

        LcpConfigReqTimeout (int): LCP Configure-Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        LcpConfigReqMaxAttempts (int): LCP Configure-Request最大尝试次数, 取值范围：1-65535, 默认值：10

        LcpTermReqTimeout (int): LCP Terminate-Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        LcpTermReqMaxAttempts (int): LCP Terminate-Request最大尝试次数, 取值范围：1-65535, 默认值：10

        NcpConfigReqTimeout (int): NCP Configure-Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        NcpConfigReqMaxAttempts (int): NCP Configure-Request最大尝试次数, 取值范围：1-65535, 默认值：10

        LcpNcpMaxNak (int): LCP/NCP最大Nak数量, 取值范围：1-65535, 默认值：5

        EnableMruNegotiation (bool): 使能MRU协商, 默认值：True

        MruSize (int): MRU(字节), 取值范围：128-65535, 默认值：1492

        EnableEchoRequest (bool): 使能Echo-Request报文, 默认值：False

        EchoRequestInterval (int): Echo-Request间隔 (sec), 取值范围：1-65535, 默认值：10

        EchoRequestMaxAttempts (int): Echo-Request最大尝试次数, 取值范围：1-65535, 默认值：3

        EnableMagicNumber (bool): 使能Magic Number, 默认值：True

        PadiTimeout (int): Client参数, PADI超时时间 (sec), 取值范围：1-65535, 默认值：3

        PadiMaxAttempts (int): Client参数, PADI最大尝试次数, 取值范围：1-65535, 默认值：10

        PadrTimeout (int): Client参数, PADR超时时间 (sec), 取值范围：1-65535, 默认值：3

        PadrMaxAttempts (int): Client参数, PADR最大尝试次数, 取值范围：1-65535, 默认值：10

        EnableRelayAgent (bool): Client参数, 启用中继代理, 默认值：False

        RelayAgentDestMac (str): Client参数, 中继代理MAC地址, 取值范围：有效的mac地址, 默认值：00:00:00:00:00:00

        RelayAgentDestMacStep (str): Client参数, 中继代理MAC地址跳变, 取值范围：有效的mac地址, 默认值：00:00:00:00:00:01

        UseRelayAgentPadi (bool): Client参数, PADI中包含中继代理信息, 默认值：True

        UseRelayAgentPadr (bool): Client参数, PADR中包含中继代理信息, 默认值：True

        RelayAgentType (str): Client参数, 中继代理类型, 默认值：RFC2516, 取值范围：

            RFC2516

            DSL_FORUM

        RelaySessionId (str): Client参数, 中继会话ID, 取值范围：string length in [0,12], 默认值：""

        CircuitId (str): Client参数, 环路ID, 取值范围：string length in [0,63], 默认值：@s

        RemoteId (str): Client参数, 远程ID, 取值范围：string length in [0,63], 默认值：@m-@p

        ChapChalReqTimeout (int): Client参数, CHAP Challenge Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        ChapAckTimeout (int): Client参数, CHAP Ack超时时间 (sec), 取值范围：1-65535, 默认值：3

        ChapMaxReplyAttempts (int): Client参数, CHAP Reply最大尝试次数, 取值范围：1-65535, 默认值：10

        PapReqTimeout (int): Client参数, PAP Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        PapReqMaxAttempts (int): Client参数, PAP Request最大尝试次数, 取值范围：1-65535, 默认值：10

        EnableAutoRetry (bool): Client参数, 使能PPPoE协议会话, 默认值：False

        AutoRetryCount (int): Client参数, 重连次数, 取值范围：1-65535, 默认值：65535

        LcpDelay (int): Client参数, LCP 推迟时间(ms), 取值范围：1-65535, 默认值：0

        EnableAutoFillIpv6 (bool): Client参数, 启用获取Global IPv6地址, 默认值：True

        AcName (str): Server参数, 访问集中器名称, 默认值：Xinertel

        ChapReplyTimeout (int): Server参数, CHAP Reply超时时间(sec), 取值范围：1-65535, 默认值：3

        ChapMaxChalAttempts (int): Server参数, CHAP Challenge最大尝试次数, 取值范围：1-65535, 默认值：10

        PapPeerReqTimeout (int): Server参数, 等待PAP Request超时时间(sec), 取值范围：1-65535, 默认值：3

        Ipv4Start (str): Server参数, IPv4起始地址, 默认值：192.0.1.0

        Ipv4Step (str): Server参数, IPv4地址步长, 默认值：0.0.0.1

        Ipv4Count (int): Server参数, IPv4地址数量, 取值范围：1-65535, 默认值：3

        Ipv6InterfaceId (str): Server参数, 起始Interface ID, 默认值："::2"

        Ipv6InterfaceIdStep (str): Server参数, Interface ID跳变步长, 默认值："::1"

        Ipv6PrefixStart (str): Server参数, IPv6起始前缀, 默认值："2002::"

        Ipv6PrefixStep (str): Server参数, IPv6前缀跳变步长, 默认值："0:0:0:1::"

        Ipv6Count (int): Server参数, IPv6前缀数量, 取值范围：1-65535, 默认值：1

        EnableForceConnectMode (bool): Server参数, 强制重连模式, 默认值：False

        UnconnectedSessionThreshold (int): Server参数, 未连接会话门限值, 取值范围：1-65535, 默认值：1

        MAndOFlag (str): Server参数, M 与 O 标志位, 默认值：M0_O0, 支持

            M0_O0
            M0_O1
            M1

    Returns:
    
        (:obj:`PppoeClent`): PPPoE协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Create Pppoe | Port=${Port} |
            | Create Pppoe | Port=${Port} | EmulationMode=Server |
    """

    result = renix.create_pppoe(Port=Port, EmulationMode=EmulationMode, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def edit_pppoe(Session, **kwargs):
    """
    编辑PPPoE协议会话对象

    Args:

        Session (:obj:`Ppp`): 测试仪表端口对象, 类型为：object

    Keyword Args:

        Name (str): PPPoE协会话名称

        Enable (bool): 使能PPPoE协议会话, 默认值：True

        EmulationMode (str): PPPoE角色, 默认值：CLIENT, 取值范围：

            CLIENT

            SERVER

            PPPoL2TP

        AuthenticationType (str): 认证方式, 默认值：NO_AUTHENTICATION, 取值范围：

            NO_AUTHENTICATION

            NEGOTIATION

            CHAP_MD5

            PAP

        Username (str): 用户名, 默认值：xinertel, 取值范围：string length in [1,126]

        Password (str): 密码, 默认值：xinertel, 取值范围：string length in [1,126]

        ServiceName (str): 服务名, 默认值："", 取值范围：string length in [0,255]

        EnableMaxPayloadTag (bool): 使能最大净荷标签, 默认值：False

        MaxPayloadBytes (int): 最大净荷(字节), 取值范围：1-65535, 默认值：1500

        LcpConfigReqTimeout (int): LCP Configure-Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        LcpConfigReqMaxAttempts (int): LCP Configure-Request最大尝试次数, 取值范围：1-65535, 默认值：10

        LcpTermReqTimeout (int): LCP Terminate-Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        LcpTermReqMaxAttempts (int): LCP Terminate-Request最大尝试次数, 取值范围：1-65535, 默认值：10

        NcpConfigReqTimeout (int): NCP Configure-Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        NcpConfigReqMaxAttempts (int): NCP Configure-Request最大尝试次数, 取值范围：1-65535, 默认值：10

        LcpNcpMaxNak (int): LCP/NCP最大Nak数量, 取值范围：1-65535, 默认值：5

        EnableMruNegotiation (bool): 使能MRU协商, 默认值：True

        MruSize (int): MRU(字节), 取值范围：128-65535, 默认值：1492

        EnableEchoRequest (bool): 使能Echo-Request报文, 默认值：False

        EchoRequestInterval (int): Echo-Request间隔 (sec), 取值范围：1-65535, 默认值：10

        EchoRequestMaxAttempts (int): Echo-Request最大尝试次数, 取值范围：1-65535, 默认值：3

        EnableMagicNumber (bool): 使能Magic Number, 默认值：True

        PadiTimeout (int): Client参数, PADI超时时间 (sec), 取值范围：1-65535, 默认值：3

        PadiMaxAttempts (int): Client参数, PADI最大尝试次数, 取值范围：1-65535, 默认值：10

        PadrTimeout (int): Client参数, PADR超时时间 (sec), 取值范围：1-65535, 默认值：3

        PadrMaxAttempts (int): Client参数, PADR最大尝试次数, 取值范围：1-65535, 默认值：10

        EnableRelayAgent (bool): Client参数, 启用中继代理, 默认值：False

        RelayAgentDestMac (str): Client参数, 中继代理MAC地址, 取值范围：有效的mac地址, 默认值：00:00:00:00:00:00

        RelayAgentDestMacStep (str): Client参数, 中继代理MAC地址跳变, 取值范围：有效的mac地址, 默认值：00:00:00:00:00:01

        UseRelayAgentPadi (bool): Client参数, PADI中包含中继代理信息, 默认值：True

        UseRelayAgentPadr (bool): Client参数, PADR中包含中继代理信息, 默认值：True

        RelayAgentType (str): Client参数, 中继代理类型, 默认值：RFC2516, 取值范围：

            RFC2516

            DSL_FORUM

        RelaySessionId (str): Client参数, 中继会话ID, 取值范围：string length in [0,12], 默认值：""

        CircuitId (str): Client参数, 环路ID, 取值范围：string length in [0,63], 默认值：@s

        RemoteId (str): Client参数, 远程ID, 取值范围：string length in [0,63], 默认值：@m-@p

        ChapChalReqTimeout (int): Client参数, CHAP Challenge Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        ChapAckTimeout (int): Client参数, CHAP Ack超时时间 (sec), 取值范围：1-65535, 默认值：3

        ChapMaxReplyAttempts (int): Client参数, CHAP Reply最大尝试次数, 取值范围：1-65535, 默认值：10

        PapReqTimeout (int): Client参数, PAP Request超时时间 (sec), 取值范围：1-65535, 默认值：3

        PapReqMaxAttempts (int): Client参数, PAP Request最大尝试次数, 取值范围：1-65535, 默认值：10

        EnableAutoRetry (bool): Client参数, 使能PPPoE协议会话, 默认值：False

        AutoRetryCount (int): Client参数, 重连次数, 取值范围：1-65535, 默认值：65535

        LcpDelay (int): Client参数, LCP 推迟时间(ms), 取值范围：1-65535, 默认值：0

        EnableAutoFillIpv6 (bool): Client参数, 启用获取Global IPv6地址, 默认值：True

        AcName (str): Server参数, 访问集中器名称, 默认值：Xinertel

        ChapReplyTimeout (int): Server参数, CHAP Reply超时时间(sec), 取值范围：1-65535, 默认值：3

        ChapMaxChalAttempts (int): Server参数, CHAP Challenge最大尝试次数, 取值范围：1-65535, 默认值：10

        PapPeerReqTimeout (int): Server参数, 等待PAP Request超时时间(sec), 取值范围：1-65535, 默认值：3

        Ipv4Start (str): Server参数, IPv4起始地址, 默认值：192.0.1.0

        Ipv4Step (str): Server参数, IPv4地址步长, 默认值：0.0.0。1

        Ipv4Count (int): Server参数, IPv4地址数量, 取值范围：1-65535, 默认值：3

        Ipv6InterfaceId (str): Server参数, 起始Interface ID, 默认值："::2"

        Ipv6InterfaceIdStep (str): Server参数, Interface ID跳变步长, 默认值："::1"

        Ipv6PrefixStart (str): Server参数, IPv6起始前缀, 默认值："2002::"

        Ipv6PrefixStep (str): Server参数, IPv6前缀跳变步长, 默认值："0:0:0:1::"

        Ipv6Count (int): Server参数, IPv6前缀数量, 取值范围：1-65535, 默认值：1

        EnableForceConnectMode (bool): 强制重连模式, 默认值：False

        UnconnectedSessionThreshold (int): 未连接会话门限值, 取值范围：1-65535, 默认值：1

        MAndOFlag (str): Server参数, M 与 O 标志位, 默认值：M0_O0, 支持

            M0_O0

            M0_O1

            M1

    Returns:
    
        (:obj:`PppoeClent` or `PppoeServer`): PPPoE协议会话对象, 类型：object

    Examples:
        .. code:: RobotFramework

            | Edit Pppoe | Port=${Port} |
    """

    result = renix.edit_pppoe(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def connect_pppoe(Sessions):
    """
    连接PPPoE协议会话

    Args:

        Sessions (list (:obj:`PppoeClent`)): PPPoE协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Connect Pppoe | Sessions=${Sessions} |
    """

    result = renix.connect_pppoe(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def disconnect_pppoe(Sessions):
    """
    断开PPPoE协议会话

    Args:

        Sessions (list (:obj:`PppoeClent`)): PPPoE协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Disconnect Pppoe | Sessions=${Sessions} |
    """

    result = renix.disconnect_pppoe(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def abort_pppoe(Sessions):
    """
    中断PPPoE协议会话

    Args:

        Sessions (list (:obj:`PppoeClent`)): PPPoE协议会话对象列表, 类型为：list

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Abort Pppoe | Sessions=${Sessions} |
    """

    result = renix.abort_pppoe(Sessions=Sessions)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def create_pppoe_custom_option(Session, **kwargs):
    """
    编辑PPPoE自定义选项

    Args:

        Session (:obj:`PppoeClent`) or (:obj:`PppoeServer`): PPPoE协议会话对象

    Keyword Args:

        OptionValue (int): 选项标识符, 默认值: 0, 取值范围: 0-65535

        SubPortocolType (str): 包含选项的消息类型, 默认值：LINK_CONTROL_PROTOCOL, 支持类型:

            LINK_CONTROL_PROTOCOL

            IP_CONTROL_PROTOCOL

            IPV6_CONTROL_PROTOCOL

            PPPOE_PADI_PADR

        UseWildcards (bool): 使用通配符, 默认值：False

        StringIsHexadecimal (int): 使能十六进制字符, 默认值：False

        OptionData (str): 十进制选项载荷

        OptionHexData (list): 十六进制选项载荷, 列表元素为十六进制数，默认值：[]

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Create Pppoe Custom Option | Sessions=${Sessions} | OptionValue=1 | SubPortocolType=LinkControlProtocol | OptionData=55 |
    """

    result = renix.create_pppoe_custom_option(Session=Session, **kwargs)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_pppoe_ipcp_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待PPPoE IPCP达到指定状态

    Args:

        Sessions (list (:obj:`PppoeClent`)): PPPoE协议会话对象列表, 类型为：list

        State (list): 等待PPPoE IPCP达到的状态, 类型为：string, 默认值：达到CONNECTED, 支持下列状态：

            NONE

            IDLE

            CONNECTED

            CONNECTING

            DISCONNECTING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Pppoe State | Sessions=${Sessions} | State=DR | Interval=2 | TimeOut=120 |
    """
    result = renix.wait_pppoe_ipcp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def wait_pppoe_ipv6cp_state(Sessions, State=None, Interval=1, TimeOut=60):
    """
    等待PPPoE IPv6CP达到指定状态

    Args:

        Sessions (list (:obj:`PppoeClent`)) or (list (:obj:`Pppoev3Router`)): PPPoE或Pppoev3协议会话对象列表, 类型为：list

        State (list): 等待PPPoE IPv6CP达到的状态, 类型为：string, 默认值：达到CONNECTED, 支持下列状态：

            NONE

            IDLE

            CONNECTED

            CONNECTING

            DISCONNECTING

        Interval (int): 查询协议会话的间隔, 类型为：number, 默认值：1 sec

        TimeOut (int): 等待协议会话状态的超时时间, 类型为：number, 默认值：60 sec

    Returns:

        bool: 布尔值Bool (范围：True / False)

    Examples:
        .. code:: RobotFramework

            | Wait Pppoe State | Sessions=${Sessions} | State=DR | Interval=2 | TimeOut=120 |
    """
    result = renix.wait_pppoe_ipv6cp_state(Sessions=Sessions, State=State, Interval=Interval, TimeOut=TimeOut)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pppoe_port_statistic(Port=None, StaItems=None):
    """
    获取PPPoE Port Statistic统计结果

    Args:

        Port (:obj:`Port`): 测试仪表端口对象, 类型为：Object

        StaItems (list): 需要获取PPPoE Port Statistic统计项目，类型为：list，目前支持的统计项

            SessionBlockCount

            SessionCount

            SessionsUp

            SuccessfulConnects

            FailedConnects

            SucessfulDisconnects

            FailedDisconnects

    Returns:

        dict: eg::

            {
                'SessionBlockCount': 10,
                'SessionCount': 100,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | SessionBlockCount | SessionCount |
            | Subscribe Result | Types=PppoePortStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pppoe Port Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pppoe_port_statistic(Port=Port, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pppoe_server_block_statistic(Session=None, StaItems=None):
    """
    获取PPPoE Server Block Statistic统计结果

    Args:

        Session (:obj:`PppoeServer`): 测试仪表端口对象, 类型为：Object

        StaItems (list): 需要获取PPPoE Server Block Statistic统计项目，类型为：list，目前支持的统计项

            IpcpState

            Ipv6cpState

            SessionCount

            SessionsUp

            SuccessfulConnects

            FailedConnects

            SucessfulDisconnects

            FailedDisconnects

            MaxSetupTime

            MinSetupTime

            AverageSetupTime

            SuccessfulSetupRate

            RxPadi

            TxPado

            RxPadr

            TxPads

            TxPadt

            RxPadt

            TxLcpConfigRequest

            RxLcpConfigRequest

            TxLcpConfigAck

            RxLcpConfigAck

            TxLcpConfigNak

            RxLcpConfigNak

            TxLcpConfigReject

            RxLcpConfigReject

            TxLcpEchoRequest

            RxLcpEchoRequest

            TxLcpEchoReply

            RxLcpEchoReply

            TxLcpTerminateRequest

            RxLcpTerminateRequest

            TxLcpTerminateAck

            RxLcpTerminateAck

            TxChap

            RxChap

            TxPap

            RxPap

            TxIpcp

            RxIpcp

            TxIpv6cp

            RxIpv6cp

            TxIpv4

            RxIpv4

            TxIpv6

            RxIpv6

    Returns:

        dict: eg::

            {
                'SessionCount': 10,
                'SessionsUp': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | SessionCount | SessionsUp |
            | Subscribe Result | Types=PppoeServerBlockStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pppoe Server Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pppoe_server_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pppoe_server_statistic(Session=None, Index=1, StaItems=None):
    """
    获取PPPoE Server Statistic统计结果

    Args:

        Session (:obj:`PppoeServer`): 测试仪表端口对象, 类型为：Object

        Index (int): PppoeServer Block里会话的index, 默认值为: 1

        StaItems (list): 需要获取PPPoE Server Statistic统计项目，类型为：list，目前支持的统计项

            IpcpState

            Ipv6cpState

            MacAddress

            PeerMacAddress

            PppoeSessionId

            VlanId

            InnerVlanId

            Ipv4Address

            PeerIpv4Address

            Ipv6LinklocalAddress

            PeerIpv6LinklocalAddress

            SuccessfulConnects

            FailedConnects

            SucessfulDisconnects

            FailedDisconnects

            SetupTime

            RxPadi

            TxPado

            RxPadr

            TxPads

            TxPadt

            RxPadt

            TxLcpConfigRequest

            RxLcpConfigRequest

            TxLcpConfigAck

            RxLcpConfigAck

            TxLcpConfigNak

            RxLcpConfigNak

            TxLcpConfigReject

            RxLcpConfigReject

            TxLcpEchoRequest

            RxLcpEchoRequest

            TxLcpEchoReply

            RxLcpEchoReply

            TxLcpTerminateRequest

            RxLcpTerminateRequest

            TxLcpTerminateAck

            RxLcpTerminateAck

            TxChap

            RxChap

            TxPap

            RxPap

            TxIpcp

            RxIpcp

            TxIpv6cp

            RxIpv6cp

            TxIpv4

            RxIpv4

            TxIpv6

            RxIpv6

    Returns:

        dict: eg::

            {
                'SessionCount': 10,
                'SessionsUp': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | SessionCount | SessionsUp |
            | Subscribe Result | Types=PppoeServerStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pppoe Server Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pppoe_server_statistic(Session=Session, Index=Index, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pppoe_client_block_statistic(Session=None, StaItems=None):
    """
    获取PPPoE Server Block Statistic统计结果

    Args:

        Session (:obj:`PppoeClient`): 测试仪表端口对象, 类型为：Object

        StaItems (list): 需要获取PPPoE Client Block Statistic统计项目，类型为：list，目前支持的统计项

            IpcpState

            Ipv6cpState

            SessionCount

            SessionsUp

            SessionsRetried

            AttemptedConnects

            SuccessfulConnects

            FailedConnects

            SucessfulDisconnects

            FailedDisconnects

            MaxSetupTime

            MinSetupTime

            AverageSetupTime

            SuccessfulSetupRate

            TxPadi

            RxPado

            TxPadr

            RxPads

            TxPadt

            RxPadt

            TxLcpConfigRequest

            RxLcpConfigRequest

            TxLcpConfigAck

            RxLcpConfigAck

            TxLcpConfigNak

            RxLcpConfigNak

            TxLcpConfigReject

            RxLcpConfigReject

            TxLcpEchoRequest

            RxLcpEchoRequest

            TxLcpEchoReply

            RxLcpEchoReply

            TxLcpTerminateRequest

            RxLcpTerminateRequest

            TxLcpTerminateAck

            RxLcpTerminateAck

            TxChap

            RxChap

            TxPap

            RxPap

            TxIpcp

            RxIpcp

            TxIpv6cp

            RxIpv6cp

            TxIpv4

            RxIpv4

            TxIpv6

            RxIpv6

    Returns:

        dict: eg::

            {
                'SessionCount': 10,
                'SessionsUp': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | SessionCount | SessionsUp |
            | Subscribe Result | Types=PppoeClientBlockStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pppoe Client Block Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pppoe_client_block_statistic(Session=Session, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result


def get_pppoe_client_statistic(Session=None, Index=1, StaItems=None):
    """
    获取PPPoE Client Statistic统计结果

    Args:

        Session (:obj:`PppoeClient`): 测试仪表端口对象, 类型为：Object

        Index (int): PppoeClient Block里会话的index, 默认值为: 1

        StaItems (list): 需要获取PPPoE Client Block Statistic统计项目，类型为：list，目前支持的统计项

            IpcpState

            Ipv6cpState

            MacAddress

            PeerMacAddress

            PppoeSessionId

            VlanId

            InnerVlanId

            Ipv4Address

            PeerIpv4Address

            Ipv6LinklocalAddress

            PeerIpv6LinklocalAddress

            Ipv6GlobalAddress

            SessionsRetried

            AttemptedConnects

            SuccessfulConnects

            FailedConnects

            SucessfulDisconnects

            FailedDisconnects

            SetupTime

            TxPadi

            RxPado

            TxPadr

            RxPads

            TxPadt

            RxPadt

            TxLcpConfigRequest

            RxLcpConfigRequest

            TxLcpConfigAck

            RxLcpConfigAck

            TxLcpConfigNak

            RxLcpConfigNak

            TxLcpConfigReject

            RxLcpConfigReject

            TxLcpEchoRequest

            RxLcpEchoRequest

            TxLcpEchoReply

            RxLcpEchoReply

            TxLcpTerminateRequest

            RxLcpTerminateRequest

            TxLcpTerminateAck

            RxLcpTerminateAck

            TxChap

            RxChap

            TxPap

            RxPap

            TxIpcp

            RxIpcp

            TxIpv6cp

            RxIpv6cp

            TxIpv4

            RxIpv4

            TxIpv6

            RxIpv6

    Returns:

        dict: eg::

            {
                'SessionCount': 10,
                'SessionsUp': 10,
            }

    Examples:
        .. code:: RobotFramework

            | @{StaItems} | Create List | SessionCount | SessionsUp |
            | Subscribe Result | Types=PppoeClientStatistic |
            | Start Protocol |
            | Sleep | 60 |
            | &{Result} | Get Pppoe Client Statistic | Session=${Session} | StaItems=@{StaItems} |
            | Clear Result |
    """

    result = renix.get_pppoe_client_statistic(Session=Session, Index=Index, StaItems=StaItems)
    if result is False:
        raise ContinuableFailure(message=f'{sys._getframe().f_code.co_name} Failure')
    else:
        return result

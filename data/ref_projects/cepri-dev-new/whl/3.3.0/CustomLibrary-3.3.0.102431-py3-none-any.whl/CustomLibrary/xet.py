import os
import sqlite3
import time
import signal
import requests
import warnings
import re
from zipfile import ZipFile
from pathlib import Path
from urllib3.exceptions import InsecureRequestWarning
import pandas as pd
import IPy

from renix_py_api.api_gen import (
    StartupClCommand,
    ShutdownClCommand,
    SyncPasswordToRtsmCommand,
    GetConnectedClCommand,
    CheckPlCountCommand,
    SetChiefUserCommand,
)
from renix_py_api.renix import start_renix, initialize
from renix_py_api.renix_common_api import RenixApiManager, get_sys_entry, get_cl, set_cl

warnings.filterwarnings("ignore", category=InsecureRequestWarning)


class ALPSClient:
    """
    This class `ALPSClient` is an API client for interacting with a specific server.

    Methods:
        - `login`: Logs in the user with provided or stored credentials.
        - `logout`: Logs out the user.
        - `get_port_info`: Retrieves port information.
        - `http_get`: Performs an HTTP GET request.
        - `http_post`: Performs an HTTP POST request.
        - `search_testcase`: Searches for a testcase by testcase name.
        - `import_testcase`: Imports a testcase from the local file.
        - `export_testcase`: Exports a testcase to the local file.
        - `download_report`: Downloads a report in PDF, HTML, or CSV format.
        - `get_testcase_latest_result`: Retrieves the latest result of a specific testcase.
    """

    def __init__(self, base_url, username, password, observer="1"):

        self.base_url = base_url
        self.username = username
        self.password = password
        self.observer = observer

        self.session_id = None
        self.user_id = None
        self.default_request_header = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en,zh-CN;q=0.9,zh;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "Connection": "keep-alive",
        }

    @property
    def timestamp(self):
        return int(time.time())

    def login(self, username="", password="", observer="1"):
        login_url = f"{self.base_url}/v1/cl/user/login"
        query = {
            "timestamp": self.timestamp,
        }
        body = {
            "name": username or self.username,
            "password": password or self.password,
            "observer": observer or self.observer,
        }
        res = requests.post(
            url=login_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {login_url}, {res.text}")
        data = res.json()
        if data["code"] != 0:
            raise Exception(f"Failed to login, {data['message']}")
        self.session_id = data["result"]["session_id"]
        self.user_id = data["result"]["user_id"]
        return data

    def logout(self, username):
        logout_url = f"{self.base_url}/v1/cl/user/logout"
        query = {
            "timestamp": self.timestamp,
        }
        body = {
            "name": username,
        }
        res = requests.post(
            url=logout_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {logout_url}, {res.text}")
        data = res.json()
        return data

    def get_port_info(self):
        port_info_url = f"{self.base_url}/v1/cl/port/list"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        res = requests.get(
            url=port_info_url,
            params=query,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {port_info_url}, {res.text}")
        data = res.json()
        if data["code"] != 0:
            raise Exception(f"Failed to get port info, {data['message']}")
        ret_data = {
            "code": data["code"],
            "message": data["message"],
            "port_list": data["result"][0]["card_list"][0]["port_list"],
        }
        return ret_data

    def reserve_port(self, port_id):
        reserve_port_url = f"{self.base_url}/v1/cl/port/reserve"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {
            "port_id": port_id,
        }
        res = requests.post(
            url=reserve_port_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {reserve_port_url}, {res.text}")
        data = res.json()
        return data

    def get_reserved_port_status(self):
        port_status_url = f"{self.base_url}/v1/cl/port/status"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {"port_ids": []}
        res = requests.post(
            url=port_status_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {port_status_url}, {res.text}")
        data = res.json()
        return data

    def http_get(self, url, params={}, body={}, header={}):
        get_url = f"{self.base_url}{url}"
        query = {
            "timestamp": self.timestamp,
            **params,
        }
        header = {
            **self.default_request_header,
            **header,
        }
        if body:
            res = requests.post(
                url=get_url, params=query, json=body, headers=header, verify=False
            )
        else:
            res = requests.get(url=get_url, params=query, verify=False)
        if res.status_code != 200:
            raise Exception(f"Failed to get {get_url}, {res.text}")
        data = res.json()
        return data

    def http_post(self, url, params={}, body={}, header={}):
        post_url = f"{self.base_url}{url}"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
            **params,
        }
        header = {
            **self.default_request_header,
            **header,
        }
        res = requests.post(
            url=post_url, params=query, json=body, headers=header, verify=False
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {post_url}, {res.text}")
        data = res.json()
        return data

    def search_testcase(self, testcase_name, page_no=1, page_size=18):
        search_testcase_url = f"{self.base_url}/v1/cl/testcase/search"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {
            "page_no": page_no,
            "page_size": page_size,
            "test_type": [],
            "test_name": testcase_name,
            "test_sort": "",
        }
        res = requests.post(
            url=search_testcase_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {search_testcase_url}, {res.text}")
        data = res.json()
        return data

    def import_testcase(self, testcase_path):
        testcase_path = Path(testcase_path)
        import_testcase_url = f"{self.base_url}/v1/cl/testcase/import"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
            "category": "testcase",
            "object": testcase_path.name,
            "shared": 1,
            "overwrite_testcase": True,
            "overwrite_config": True,
        }
        header = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Content-Type": "application/octet-stream",
        }
        res = requests.post(
            url=import_testcase_url,
            params=query,
            headers=header,
            data=open(testcase_path, "rb").read(),
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {import_testcase_url}, {res.text}")
        with ZipFile(testcase_path, "r") as zip_file:
            testcase_file_name = [
                name
                for name in zip_file.namelist()
                if (lambda string, pattern: re.search(pattern, string) is not None)(
                    name, r"(?<=#)testcase(?=@)"
                )
            ]
        testcase_name = testcase_file_name[0].split(".")[0].split("@")[-1]
        data = self.search_testcase(testcase_name=testcase_name)
        return data

    def export_testcase(self, testcase_id, testcase_path):
        testcase_path = Path(testcase_path)
        export_testcase_url = f"{self.base_url}/v1/cl/testcase/export"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {"testcase_id": testcase_id}
        res = requests.post(
            url=export_testcase_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {export_testcase_url}, {res.text}")
        data = res.json()
        if data["code"] != 0:
            raise Exception(f"Failed to export testcase, {data['message']}")
        testcase_file_url = data["result"]["testcase_config_file_url"]
        testcase_name = testcase_file_url.split("/")[-1]
        # if path is a dir
        if testcase_path.is_dir():
            testcase_path = testcase_path / testcase_name
        res = requests.get(url=testcase_file_url, verify=False)
        if res.status_code != 200:
            raise Exception(f"Failed to get {testcase_file_url}, {res.text}")
        with open(testcase_path, "wb") as f:
            f.write(res.content)
        return data

    def run_testcase(self, testcase_id):
        run_testcase_url = f"{self.base_url}/v1/cl/testcase/run"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {"testcase_id": testcase_id}
        res = requests.post(
            url=run_testcase_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {run_testcase_url}, {res.text}")
        data = res.json()
        if data["code"] != 0:
            raise Exception(f"Failed to run testcase, {data['message']}")
        return data
    
    def get_testcase_status(self, testcase_id):
        testcase_status_url = f"{self.base_url}/v1/cl/testcase/status"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {"testcase_id": testcase_id}
        res = requests.post(
            url=testcase_status_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {testcase_status_url}, {res.text}")
        data = res.json()
        if data["code"] != 0:
            raise Exception(f"Failed to get testcase status, {data['message']}")
        return data

    def download_report(self, instance_id, report_path, report_format="pdf"):
        report_path = Path(report_path)
        if report_format not in ("pdf", "html", "csv"):
            raise Exception(f"Invalid report format {report_format}")
        download_report_url = (
            f"{self.base_url}/v1/cl/test_report/download_{report_format}"
        )
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {
            "instance_id": instance_id,
            "checked_nodes": "",
            "is_all": True,
            "report_language": "zh-CN",
        }
        res = requests.post(
            url=download_report_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {download_report_url}, {res.text}")
        data = res.json()
        if data["code"] != 0:
            raise Exception(f"Failed to download report, {data['message']}")
        report_file_url = data["result"]["report_url"]
        report_file_name = (
            report_file_url.split("/")[-1].replace(" ", "-").replace(":", "-")
        )

        # if path is a dir
        if path.is_dir():
            path = path / report_file_name
        res = requests.get(url=report_file_url, verify=False)
        if res.status_code != 200:
            raise Exception(f"Failed to get {report_file_url}, {res.text}")
        with open(path, "wb") as f:
            f.write(res.content)
        return data

    def get_testcase_latest_result(self, testcase_name):
        testcase_result_url = f"{self.base_url}/v1/cl/testcase/instance/search"
        query = {
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }
        body = {
            "page_no": 1,
            "page_size": 18,
            "test_name": testcase_name,
            "instance_sort": "",
            "test_result": [],
            "user_id": self.user_id,
        }
        res = requests.post(
            url=testcase_result_url,
            params=query,
            json=body,
            headers=self.default_request_header,
            verify=False,
        )
        if res.status_code != 200:
            raise Exception(f"Failed to post {testcase_result_url}, {res.text}")
        data = res.json()
        if data["code"] != 0:
            raise Exception(f"Failed to get testcase latest result, {data['message']}")
        ret_data = {
            "code": data["code"],
            "message": data["message"],
            "latest_result": data["result"]["instance_list"][0],
        }
        return ret_data

    def __enter__(self):
        try:
            self.login(self.username, self.password, self.observer)
        except Exception as e:
            print(f"Failed to login: {e}")
            raise
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.logout(self.username)
        except Exception as e:
            print(f"Failed to logout: {e}")
            raise
        if exc_type:
            return False
        return True


def resource_map(sys_entry):
    ports = sys_entry.get_children("Port")
    interfaces = []
    streams = []
    ospfv2s = []
    ospfv3s = []
    isis = []
    bgps = []
    igmps = []
    stream_profiles = []
    for i in ports:
        interfaces.extend(i.get_children("Interface"))
        streams.extend(i.get_children("StreamTemplate"))
        ospfv2s.extend(i.get_children("Ospfv2ProtocolConfig"))
        ospfv3s.extend(i.get_children("Ospfv3ProtocolConfig"))
        isis.extend(i.get_children("IsisProtocolConfig"))
        bgps.extend(i.get_children("BgpProtocolConfig"))
        igmps.extend(i.get_children("IgmpProtocolConfig"))
    for i in streams:
        stream_profiles.extend(i.get_children("StreamTemplateLoadProfile"))
    stream_port_configs = [i.get_children("StreamPortConfig")[0] for i in ports]
    inter_frame_gap_profiles = [
        i.get_children("InterFrameGapProfile")[0]
        for i in stream_port_configs
        if i.get_children("InterFrameGapProfile")
    ]
    burst_profiles = [
        i.get_children("BurstTransmitConfig")[0]
        for i in stream_port_configs
        if i.get_children("BurstTransmitConfig")
    ]
    resource_map = {
        "port": {i.Name: i for i in ports},
        "interface": {i.Name: i for i in interfaces},
        "stream": {i.Name: i for i in streams},
        "result_view": {
            i.DataClassName: i for i in sys_entry.get_children("ResultView")
        },
        "ospfv2": {i.Name: i for i in ospfv2s},
        "ospfv3": {i.Name: i for i in ospfv3s},
        "isis": {i.Name: i for i in isis},
        "bgp": {i.Name: i for i in bgps},
        "igmp": {i.Name: i for i in igmps},
        "load_profile_continue": {i.Name: i for i in inter_frame_gap_profiles},
        "load_profile_burst": {i.Name: i for i in burst_profiles},
        "load_profile_stream": {i.upper.Name: i for i in stream_profiles},
        "multicase_ipv4_group": {
            i.Name: i for i in sys_entry.get_children("Ipv4MulticastGroup")
        },
    }
    return resource_map


def get_stats_by_name(
    result_view, port_name=None, stream_block_name=None, stream_name=None, bgp_name=None
):
    result_query = result_view.get_children()[0]
    for i in result_query.get_children():
        if port_name:
            if i.PortID == port_name:
                return i
        elif stream_block_name:
            if i.StreamBlockID == stream_block_name:
                return i
        elif stream_name:
            if i.StreamID == stream_name:
                return i
        elif bgp_name:
            if i.BgpSessionBlockId == bgp_name:
                return i
        else:
            return


def wait_state(objects, state_name=None, state=None, interval=1, timeout=60):
    start_time = time.time()
    if not hasattr(objects, '__iter__'):
        objects = [objects]
    for obj in objects:
        tmp_state = getattr(obj, state_name).name
        while tmp_state != state:
            time.sleep(interval)
            tmp_state = getattr(obj, state_name).name
            if time.time() - start_time > timeout:
                print(f"等待超时：{timeout}s.")
                return False
    print("等待用时：", time.time() - start_time, "s.")
    return True


def ipv4_addr_increment(start, count, increment=1, prefix=24):
    start_int = IPy.IP(f"{start}/{prefix}").int()
    end_int = (start_int + 2 ** (32 - prefix) * count) * increment
    return IPy.IP(end_int)


def get_streamblockstats(db):
    with sqlite3.connect(db) as conn:
        # 使用 SQL 查询语句来获取数据
        query = "SELECT * FROM StreamBlockStats"
        # 使用 read_sql 函数将查询结果转换为 DataFrame
        df = pd.read_sql(query, conn)
        return df


class RTSM:

    def __init__(self, Host="127.0.0.1", Port=10001, TimeOut=30000):
        self.host = Host
        self.port = Port
        self.pl = None
        self.timeout = TimeOut
        self.cl = []
        self.connection = False
        self.connection_cl = False
        self.cl_port = None
        self.cl_instance = RenixApiManager()
        set_cl(self.cl_instance)

    def Login(self):
        # 连接RTSM
        if not self.connection:
            self.cl_instance.connection_init(
                host=self.host, port=self.port, timeout=self.timeout
            )
            self.connection = True
            print(f"RTSM {self.host}:{self.port} login succeeded")
        else:
            raise Exception("RTSM has logined")

    def Logout(self):
        # 断开RTSM连接
        if self.connection:
            self.cl_instance.close_connection()
            self.connection = False
            print(f"RTSM {self.host}:{self.port} logout succeeded")
        else:
            raise Exception("RTSM do not login")

    def Start(self):
        # 启动cl
        if not self.connection:
            self.Login()
        startClCommand = StartupClCommand(cl_instance=self.cl_instance)
        startClCommand.execute()
        self.cl.append(startClCommand.ClListenPort)
        # 将密码同步给rtsm服务
        SyncPasswordToRtsmCommand(
            Password="xinertel",
            ClListenPort=startClCommand.ClListenPort,
            cl_instance=self.cl_instance,
        ).execute()
        clCount = GetConnectedClCommand(cl_instance=self.cl_instance)
        clCount.execute()
        self.cl_port = startClCommand.ClListenPort
        print(f"listen cl port: {str(self.cl_port)}")
        if not self.connection:
            self.Logout()
        return startClCommand.ClListenPort

    def ShutDown(self, Port=None):
        if self.pl is not None:
            os.kill(self.pl.pid, signal.SIGTERM)
        # 关闭cl
        if not self.connection:
            self.Login()
        if Port is None:
            for i in self.cl:
                ShutdownClCommand(i, cl_instance=self.cl_instance).execute()
                print(f"Shutdown cl port: {i}")
        else:
            ShutdownClCommand(Port, cl_instance=self.cl_instance).execute()
            print(f"Shutdown cl port: {Port}")
        if not self.connection:
            self.Logout()

    def StartAPP(self, Port=None):
        self.pl = start_renix(self.host, self.cl_port, "xinertel")
        return self.pl
        # CheckPlCountCommand(ClListenPort=self.cl_port, cl_instance=self.cl_instance).execute()

    def ConnectionCl(self):
        # 连接CL
        if self.connection:
            self.Logout()
        self.cl_instance.connection_init(
            host=self.host, port=self.cl[-1], timeout=self.timeout
        )
        self.cl_instance.rom_init()
        # 获取管理员权限
        SetChiefUserCommand(Password="xinertel", cl_instance=self.cl_instance).execute()
        self.cl_port = self.cl[-1]
        self.connection_cl = True
        print(f"Connection cl port: {self.cl_port} succeeded")
        return self.cl_instance.get_sys_entry()

    def DisconnectionCl(self):
        # 连接CL
        if self.connection_cl:
            self.cl_instance.close_connection()
            self.connection_cl = False
            print(f"disconnection cl port: {self.cl_port} succeeded")
        else:
            raise Exception("CL do not connected")


def init_tester(rtsm=False, app=False, timeout=30):
    if rtsm:
        tester = RTSM(Host=rtsm)
        cl_port = tester.Start()
        entry = tester.ConnectionCl()
        print(entry.__dict__)
        cl_instance = tester.cl_instance
        if app:
            tester.StartAPP()
            time.sleep(timeout)
    else:
        cl_instance = initialize()
        cl_port = 0
        tester = False
    return cl_instance, cl_port, tester


def shotdown_tester(rtsm=False, cl_port=None):
    if rtsm:
        tester = RTSM(Host=rtsm)
        tester.ShutDown(cl_port)
    return True

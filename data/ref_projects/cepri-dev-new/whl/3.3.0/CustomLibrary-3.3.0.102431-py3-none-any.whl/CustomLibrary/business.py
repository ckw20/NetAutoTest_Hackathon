"""
业务层二次封装函数
"""

import os
import sys
import time
import json
from renix_py_api.renix import LoadTestCaseCommand, get_sys_entry, BringPortsOnlineCommand
from CustomLibrary.common import testbed, get_port_params, xcfg_path, cfg
from CustomLibrary.xet import resource_map, init_tester


def script_setup(*args, **kwargs):
    # 初始化仪表
    cl_instance, cl_port, tester = init_tester(rtsm=testbed['tester']['rtsm']['ip'])
    # 加载配置文件
    LoadTestCaseCommand(TestCase=xcfg_path).execute()
    # 是否启动界面监控
    if testbed['tester']['rtsm']['ip'] and testbed['tester']['rtsm']['app']:
        tester.StartAPP()
        time.sleep(30)
    # 修改产品类型
    sys_entry = get_sys_entry()
    if testbed['tester']['product_type']['default'].lower() == 'daryu':
        sys_entry.edit(ProductType=testbed['tester']['product_type']['default'])
    # 获取配置文件中资源对象映射
    res_map = resource_map(sys_entry)

    return cfg, testbed, cl_port, tester, res_map, sys_entry


def reserve_renix_ports(res_map):
    """

    :param res_map:
    :return:
    """
    ports = res_map['port'].values()
    dict_ = get_port_params(testbed)
    for port in ports:
        port.edit(Location=dict_[port.Name]['location'])
    BringPortsOnlineCommand(PortList=[i.handle for i in ports]).execute()
    # 检查端口状态
    for port in ports:
        if not port.Online:
            raise Exception('有端口未上线：', port.Name)

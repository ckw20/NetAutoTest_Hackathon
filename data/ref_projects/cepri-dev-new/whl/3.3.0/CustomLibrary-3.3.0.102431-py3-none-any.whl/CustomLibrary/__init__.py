import sys
import os


# 设置环境变量RENIX_SERVER_PATH，指向Renix服务器的安装路径
if 'RENIX_SERVER_PATH' not in os.environ:
    os.environ['RENIX_SERVER_PATH'] = '/root/server'
# os.environ['RENIX_SERVER_PATH'] = r'C:\Program Files\Xinertel\Renix3.2.8\server'
# 将Renix服务器的python_api目录添加到Python路径的最前面，确保优先加载该目录下的模块
sys.path.insert(0, os.path.join(os.environ['RENIX_SERVER_PATH'], 'python_api'))
sys.path.append(os.path.abspath(os.path.join(os.path.pardir, os.path.pardir)))
print('RENIX_SERVER_PATH: {}'.format(os.environ['RENIX_SERVER_PATH']))

from renix_py_api.renix import *

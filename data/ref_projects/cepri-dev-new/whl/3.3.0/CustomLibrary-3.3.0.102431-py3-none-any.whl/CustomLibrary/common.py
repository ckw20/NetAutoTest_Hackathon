# -*- coding: utf-8 -*-
import glob
import importlib
import json
import os
import re
import sqlite3
import sys
import telnetlib
import time
import tkinter
import chardet
import pandas as pd
import paramiko

from typing import List, Tuple, Dict
from ruamel.yaml import YAML

from CustomLibrary.topu import tupo_to_testbed, topu_json

print(os.getcwd())
print(sys.argv[0])
script_dir, script_name = os.path.split(os.path.abspath(sys.argv[0]))

edit_port_params = [
    'EnableLink',
    'AutoNegotiation',
    'Mtu',
    'FecType',
    'LineSpeed',
    'Duplex',
    'FlowControl',
    'Media',
    'PhyMode',
    'PpmAdjust',
    'DataPathMode',
    'RemoteFault',
    'Master',
    'NoParam',
    'ArpTimeout',
    'ArpRate',
    'ArpRetryCount',
    'ArpSuppressDuplicateGateway',
    'ArpDelayTime',
    'ArpUseLinkLocalForNd'
]
def get_file_encoding(file_path):
    with open(file_path, 'rb') as f:
        result = chardet.detect(f.read(1024))
        return result['encoding']

# 默认脚本json配置文件路径为脚本同级目录cfg.json
cfg_path = os.path.join(script_dir, 'cfg.json')
# 根据xcfg文件名称查找cfg文件
pattern = os.path.join(script_dir, '**/*xcfg')
xcfg_file = glob.glob(pattern, recursive=True)
if xcfg_file:
    xcfg_file = xcfg_file[0]
    directory, cfg_name = os.path.split(xcfg_file)
    cfg_name, extension = os.path.splitext(cfg_name)
    if not os.path.exists(cfg_path):
        # 如果脚本默认cfg.json配置文件不存在，使用脚本统计目录下边，脚本名称.json文件
        cfg_path = os.path.join(script_dir, '{}.json'.format(cfg_name))
# 读取脚本json配置内容
with open(cfg_path, 'r', encoding=get_file_encoding(cfg_path)) as file:
    cfg = json.load(file)

# 脚本默认xcfg配置文件路径为脚本同级目录下：脚本编号.xcfg
xcfg_path_1 = os.path.join(script_dir, '{}.xcfg'.format(cfg['tc_no']))
xcfg_path_2 = os.path.join(os.environ['RENIX_SERVER_PATH'], 'python_api', 'xcfg', '{}.xcfg'.format(cfg['tc_no']))
xcfg_path_3 = os.path.join(script_dir, '{}.xcfg'.format(cfg['name']))
xcfg_path_4 = os.path.join(os.environ['RENIX_SERVER_PATH'], 'python_api', 'xcfg', '{}.xcfg'.format(cfg['name']))
if os.path.exists(xcfg_path_1):
    xcfg_path = xcfg_path_1
elif os.path.exists(xcfg_path_2):
    # 如果脚本同级目录下：用例编号.xcfg文件存在，查找RENIX_SERVER_PATH环境变量下python_api/xcfg/脚本名称.xcfg文件
    xcfg_path = xcfg_path_2
elif os.path.exists(xcfg_path_3):
    xcfg_path = xcfg_path_3
elif os.path.exists(xcfg_path_4):
    xcfg_path = xcfg_path_4
else:
    xcfg_path = None
# 获取当前脚本文件的绝对路径和文件名
dirname, tempfilename = os.path.split(os.path.abspath(__file__))

# 从文件名中分离出文件基础名和扩展名
filename, extension = os.path.splitext(tempfilename)

# 配置文件所在文件夹
xcfg_dir = os.path.abspath(os.path.join(script_dir, os.path.pardir, os.path.pardir, 'xcfg'))
temp_dir = os.path.abspath(os.path.join(script_dir, os.path.pardir, os.path.pardir, 'temp'))
if not os.path.exists(temp_dir):
    os.makedirs(temp_dir)

# 被测设备配置命令excel所在文件夹
excel_path = os.path.abspath(os.path.join(script_dir, os.path.pardir, os.path.pardir, 'excel'))
# 被测设备配置命令默认所在文件夹为脚本两级父级文件夹下的command文件件
command_path = os.path.abspath(os.path.join(script_dir, os.path.pardir, os.path.pardir, 'command'))
if not os.path.exists(command_path):
    # 如果默认command文件件不存在，查找RENIX_SERVER_PATH环境变量下python_api/command 文件夹
    command_path = os.path.abspath(os.path.join(os.environ['RENIX_SERVER_PATH'], 'python_api', 'command'))

# 测试套件保存结果路径
result_path = os.path.abspath(os.path.join(script_dir, os.path.pardir, os.path.pardir, 'result'))
if not os.path.exists(result_path):
    os.makedirs(result_path)

# 构建topu.xlsx文件的完整路径，该文件位于与当前脚本相同的目录中
topu_path = os.path.join(excel_path, 'topu.xlsx')

xat_flag = False
# 适配XAT测试工具
if os.path.exists(os.path.join(script_dir, 'dev_info.csv')):
    print('使用XAT测试工具')
    xat_flag = True
    dev_info_csv = pd.read_csv(os.path.join(script_dir, 'dev_info.csv'))
    dpm_csv = pd.read_csv(os.path.join(script_dir, 'dpm.csv'))
    xat_locations = sys.argv[1].split(' ') if len(sys.argv) >= 1 else None
    if xat_locations is not None:
        xat_host = set()
        filtered_df = dpm_csv[dpm_csv['chassis_slot_port'].isin(xat_locations)]
        xat_host = xat_host.union(set(filtered_df['host']))
    else:
        xat_host = set(dpm_csv['host'].unique())

    dut = {
        "description": "被测设备信息",
        "auto": {
            "description": "是否自动化下发设备配置",
            "default": True
        },
        "command_source": {
            "description": "从哪种方式获取配置，支持：excel、txt",
            "default": "txt"
        }
    }
    num = 65
    for host in xat_host:
        row = dev_info_csv.loc[dpm_csv['host'] == host].iloc[0]
        char = chr(num)
        dpm_csv_rows = dpm_csv.loc[dpm_csv['host'] == host]
        count = 1
        interface = {}
        for index, row_dpm in dpm_csv_rows.iterrows():
            if row_dpm.chassis_slot_port not in xat_locations:
                continue
            interface.update({
                f"PortDevice{char}_{count}": {
                    "port_type": "tester",
                    "interface": row_dpm.interface,
                    "location": "//{}".format(row_dpm.chassis_slot_port)
                }
            })
            count += 1
        dut.update({
            f'Device{char}': {
                "dut_type": row.vendor,
                "dut_ip": row.host,
                "dut_user": row.username,
                "dut_password": row.passwd,
                "interface": interface
            }
        })
        num += 1

    dict_ = {
        "version": {
            "description": "版本号",
            "default": "1.0.0"
        },
        "tester": {
            "description": "测试仪表信息",
            "product_type": {
                "description": "renix产品类型 BIGTAO or DARYU",
                "default": "BIGTAO"
            },
            "rtsm": {
                "description": "是否使用rtsm",
                "ip": False,
                "app": True
            },
            "force": {
                "description": "是否强制占用端口",
                "default": True
            },
            "debug": {
                "description": "是否使用离线模式调试",
                "default": False
            },
            "wait_for_status_up": {
                "description": "是否等待端口UP",
                "default": True
            }
        },
        "nto": {
            "description": "nto设备信息",
            "enable": {
                "description": "是否自动化切换拓扑",
                "default": False
            },
            "ip": {
                "description": "设备IP地址",
                "default": "192.168.41.99"
            },
            "port": {
                "description": "设备port端口号",
                "default": 8000
            },
            "username": {
                "description": "设备登录用户名",
                "default": "admin"
            },
            "password": {
                "description": "设备登录密码",
                "default": "admin"
            }
        },
        "dut": dut
    }
    testbed = lambda type='switch': dict_
    testbed = testbed(cfg['type'])

if not xat_flag:
    #  检查param模块是否存在
    try:
        import importlib

        importlib.import_module('param')
        import param

        testbed_dict = tupo_to_testbed(topu_json)
        testbed = lambda type='switch': testbed_dict

    except ImportError:
        testbed = lambda type='switch': json.load(
            open(os.path.abspath(os.path.join(script_dir, os.path.pardir, os.path.pardir, type, 'testbed.json')), 'r',
                 encoding=get_file_encoding(
                     os.path.abspath(os.path.join(script_dir, os.path.pardir, os.path.pardir, type, 'testbed.json')))))
    testbed = testbed(cfg['type'])


def get_locations(ports):
    global testbed
    ret = {}
    for k, v in testbed['dut'].items():
        if 'Device' in k:
            for k1, v1 in v['interface'].items():
                ret.update({k1: v1['location']})

    get_values = lambda d, keys: [d[key] for key in keys if key in d]
    return get_values(ret, ports)


# 初始化判定变量为'pass'，用于后续的测试或验证过程
verdict = 'pass'

# 初始化错误信息变量为空字符串，用于收集和记录过程中可能出现的错误信息
errInfo = ''
step_generator = (i for i in range(1, 1024))


def get_suite_path(case_path):
    a1, a2 = os.path.split(case_path)
    case_name, b1 = os.path.splitext(a2)
    case_path = os.path.abspath(a1)
    project_path = os.path.abspath(os.path.join(dirname, os.path.pardir))
    suite_path = case_path.replace(project_path, '')
    return suite_path, case_name


class Device:
    """
    设备操作类，用于与远程设备建立SSH连接并执行命令。

    参数:
    - case: 测试用例名称，用于确定要执行的命令集。
    - port: 远程设备的SSH端口号，默认为22。
    - timeout: 连接超时时间，默认为10秒。
    """

    def __init__(self, case, testbed: dict, name='DeviceA', port=None, timeout=10):
        # 初始化设备属性，包括IP地址、用户名、密码、端口、超时时间、用例名称和命令路径。
        self.name = name
        self.testbed = testbed
        self.ipaddr = self.testbed['dut'][name]['dut_ip']
        self.username = self.testbed['dut'][name]['dut_user']
        self.pwd = self.testbed['dut'][name]['dut_password']
        self.timeout = timeout
        self.case = case
        self.product = self.testbed['dut'][name]['dut_type']
        self.login_type = self.testbed['dut'][name]['login_type'] if 'login_type' in self.testbed['dut'][name] else 'ssh'
        self.login_match = self.testbed['dut'][name]['login_match'] if 'login_match' in self.testbed['dut'][name] else None
        self.command_path = os.path.join(command_path, self.product)
        self.command_excel_path = os.path.join(command_path, '{}.xlsx'.format(self.product))
        self.topu_path = topu_path
        self.interval = self.testbed['dut'][name]['command_interval'] if 'command_interval' in self.testbed['dut'][name] else 0.01
        self.wait = self.testbed['dut'][name]['command_wait'] if 'command_wait' in self.testbed['dut'][name] else 0.05
        self.connect_timeout = self.testbed['dut'][name]['connect_timeout'] if 'connect_timeout' in self.testbed['dut'][ name] else 10
        self.connect_retry = self.testbed['dut'][name]['connect_retry'] if 'connect_retry' in self.testbed['dut'][name] else 3
        if port is None:
            if 'login_port' in self.testbed['dut'][name]:
                self.port = int(self.testbed['dut'][name]['login_port'])
            else:
                if str(self.login_type) == 'ssh':
                    self.port = 22
                else:
                    self.port = 23
        else:
            self.port = int(port)

    def get_commands_from_excel(self, row: str) -> List[str]:
        """
        从Excel中获取指定行的命令列表。

        参数:
        - row: Excel中的行号，表示要获取命令的行。

        返回:
        - 命令列表。
        """
        # 读取Excel中指定用例的命令表，并返回指定行的命令列表。
        df = pd.read_excel(self.command_excel_path, sheet_name=self.case)
        return df[row].tolist()

    def get_commands_from_file(self, name: str) -> List[str]:
        """
        从文件中获取指定行的命令列表。

        参数:
        - name: 文件名称，表示要获取命令的行。

        返回:
        - 命令列表。
        """
        # 读取Excel中指定用例的命令表，并返回指定行的命令列表。
        ret = []
        path = os.path.join(self.command_path, self.case, f'{name}.txt')
        with open(path, 'r') as fid:
            ret = fid.readlines()
        return ret

    def get_topu_from_excel(self) -> Dict[str, Dict]:
        """
        从Excel中获取端口与设备接口的映射关系。

        返回:
        - 映射关系的字典。
        """
        # 读取Excel中IP地址对应的端口与设备接口映射表，并设置索引为接口名。
        df = pd.read_excel(self.topu_path, sheet_name=self.ipaddr)
        df.set_index('name', drop=True, inplace=True)
        return df.to_dict('index')

    def get_topu_from_json(self) -> Dict[str, Dict]:
        return self.testbed['dut'][self.name]['interface']

    def execute(self, row: str = None, commands: List = None):
        """
        执行远程设备的命令。

        参数:
        - row: Excel中的行号，可选，用于指定要执行的命令行。
        - commands: 命令列表，可选，如果提供，则直接执行这些命令。
        - interval: 发送命令之间的间隔时间，默认为0.1秒。
        - wait: 等待命令执行结果的时间，默认为0.1秒。

        返回:
        - 命令执行结果的列表。
        """
        try:
            if not self.testbed['dut']['auto']['default']:
                print("未使能自动下方DUT配置！")
                return True
            # 从Excel中获取端口与设备接口的映射关系。
            # port_dict = self.get_topu_from_excel()
            port_dict = self.get_topu_from_json()
            # 如果没有提供命令列表，则从Excel中获取。
            if self.name not in row:
                row = '{}_{}'.format(self.name, row)
            if commands is None:
                if self.testbed['dut']['command_source']['default'] == 'excel':
                    commands = self.get_commands_from_excel(row)
                else:
                    commands = self.get_commands_from_file(row)

            if str(self.login_type).lower() == 'ssh':
                ret = self.execute_commands_ssh(self.ipaddr, self.port, self.username, self.pwd, commands, port_dict, self.wait, self.interval, self.connect_timeout, self.connect_retry)
            else:
                ret = self.execute_commands_telnet(self.ipaddr, self.port, self.username, self.pwd, commands, port_dict, self.wait, self.interval, self.login_match, self.connect_timeout, self.connect_retry)

            return True if not ret else ret
        except Exception as e:
            # 打印执行过程中捕获的异常。
            print(f"设备命令下发失败，失败信息：{str(e)}")
            return False

    @staticmethod
    def execute_commands_ssh(ipaddr, port, username, pwd, commands, port_dict, wait=1, interval=1, connect_timeout=10, connect_retry=3):
        for i in range(1, connect_retry):
            try:
                # 建立与远程设备的SSH连接。
                transport = paramiko.Transport((ipaddr, port))
                # 建立连接
                transport.connect(username=username, password=pwd)
                # 开启一个信道
                channel = transport.open_session()
                # 设置信道获取信息的超时时间。因为在调用 channel.recv(65535) 方法时 会阻塞执行，不设置就会卡死。
                channel.timeout = connect_timeout
                # 开启终端，进入交互模式
                channel.get_pty()
                channel.invoke_shell()

                # 等待一段时间，确保终端准备就绪。
                time.sleep(2)  # 是为了一次能显示完所有回显，如果不等待2秒，获取的回显可能不完整。
                # 检查通道是否有数据。若没有，则返回False，注意：不能用来判断已回显完。当下发命令后，执行出现卡顿，在卡顿期间信道是没有数据的。
                channelStatus = channel.recv_ready()
                # 获取返回的数据。此时返回的是登陆信息。注意：当信道没有数据是，若直接获取，则会处于阻塞状态
                backMsg = channel.recv(65535).decode('utf-8')  # 使用recv读取in-buffer内容，65535表示预读取内容大小，若该值小于in-buffer值，则会读取不完全
                print(backMsg)
            except Exception as e:
                print(f"第{i}次SSH连接失败，失败信息：{str(e)}")
                if i == int(connect_retry):
                    return False
        ret = []
        flag = False
        # 遍历命令列表，发送命令并接收执行结果。
        for command in commands:
            # 跳过接收缓冲区命令。
            if command == 'recBuffer':
                flag = True
                continue

            # 忽略NaN命令。
            if str(command) == 'nan':
                continue

            # 替换命令中的接口名占位符为实际接口名。
            if 'ReplaceInterface' in str(command):
                for k, v in port_dict.items():
                    pattern = f"ReplaceInterface_{k}"
                    command = re.sub(pattern, v['interface'], str(command))

            # 发送命令。
            channel.send(command + "\r")
            # 等待一段时间，让命令执行。
            time.sleep(wait)
            # 接收并打印命令执行结果。
            backMsg = channel.recv(65535).decode('utf-8')
            print(backMsg)
            # 如果命令是接收缓冲区命令，则将结果添加到返回列表中。
            if flag:
                ret.append(backMsg)
            flag = False
            # 等待一段时间，再发送下一个命令。
            time.sleep(interval)

        # 关闭信道
        channel.close()
        # 关闭连接
        transport.close()
        return ret

    @staticmethod
    def execute_commands_telnet(ipaddr, port, username, pwd, commands, port_dict, wait=1, interval=1, login_match=None, connect_timeout=10, connect_retry=3):
        for i in range(1, int(connect_retry)):
            try:
                # 建立与远程设备的Telnet连接
                tn = telnetlib.Telnet(ipaddr, port, timeout=connect_timeout)

                # 登录设备
                if login_match is None:
                    login_match = {
                        'Username:': username,
                        'Password:': pwd
                    }
                for k, v in login_match.items():
                    backMsg = tn.read_until(k.encode('utf-8'), timeout=connect_timeout).decode('utf-8')
                    print(backMsg)
                    if str(v) == 'dut_user':
                        v = username
                    elif str(v) == 'dut_password':
                        v = pwd
                    tn.write(v.encode('ascii') + b"\n")
                    # 等待一段时间，让命令执行
                    time.sleep(wait)
                    # 接收并打印命令执行结果
                    backMsg = tn.read_very_eager().decode('utf-8')
                    print(backMsg)
            except Exception as e:
                print(f"第{i}次telnet连接登录失败: {str(e)}")
                if i == int(connect_retry):
                    return False
        # 等待一段时间，确保终端准备就绪
        time.sleep(int(wait) + 2)

        # 初始化返回结果列表
        ret = []
        flag = False
        # 遍历命令列表，发送命令并接收执行结果
        for command in commands:
            # 跳过接收缓冲区命令
            if command == 'recBuffer':
                flag = True
                continue

            # 忽略NaN命令
            if str(command) == 'nan':
                continue

            # 替换命令中的接口名占位符为实际接口名
            if 'ReplaceInterface' in str(command):
                for k, v in port_dict.items():
                    pattern = f"ReplaceInterface_{k}"
                    command = re.sub(pattern, v['interface'], str(command))

            # 发送命令
            tn.write(command.encode('ascii') + b"\r\n")

            # 等待一段时间，让命令执行
            time.sleep(wait)

            # 接收并打印命令执行结果
            backMsg = tn.read_very_eager().decode('utf-8')
            print(backMsg)

            # 如果命令是接收缓冲区命令，则将结果添加到返回列表中
            if flag:
                ret.append(backMsg)
            flag = False

            # 等待一段时间，再发送下一个命令
            time.sleep(interval)

        # 关闭连接
        tn.close()
        return ret


def get_port_params(testbed) -> dict:
    """
    从测试台配置中获取所有端口的参数。

    此函数遍历测试台配置中的'dut'部分，提取与设备相关的条目，并收集每个设备的接口信息。
    这些信息然后被整合到一个字典中，该字典将被返回。

    参数:
    testbed (dict): 测试床的配置字典，预期包含'dut'键，其中包含设备相关信息。

    返回:
    dict: 包含所有端口参数的字典。
    """
    # 初始化一个空字典来存储端口参数
    ret = {}

    for k, v in testbed['dut'].items():
        if 'Device' not in k:
            continue
        else:
            ret.update(v['interface'])

    # 返回包含所有端口参数的字典
    return ret


def printf(message, step: int = False, result: bool = True) -> Tuple[str, str]:
    """
    打印测试结果并更新全局判断信息。

    此函数用于在测试过程中根据测试结果打印信息，并更新全局的判断状态和错误信息。
    如果测试未通过，它会记录失败的详细信息。

    参数:
    message: str - 要打印的消息，通常描述了正在测试的功能或特性。
    step: int - 测试的当前步骤，用于标识测试的进度。
    result: bool - 测试结果，True表示测试通过，False表示测试失败。

    返回值:
    Tuple[str, str] - 包含当前的判断状态（'pass'或'fail'）和累积的错误信息。
    """
    global step_generator
    if not step:
        step = next(step_generator)
    if not result:
        print(f"\n[Step {step}: Fail] {message}\n", flush=True)
        CustomData.verdict = 'fail'
        CustomData.errInfo += f"Step {step}: Fail - {message}\n"
    else:
        print(f"\n[Step {step}: Pass] {message}\n", flush=True)
    return CustomData.verdict, CustomData.errInfo


def setup(cfg: dict, testbed: dict) -> dict:
    """
    根据提供的配置初始化设备测试环境。

    参数:
    cfg (dict): 包含测试环境配置的字典，必须包含 'dut', 'name', 'dut_cfg' 键。

    testbed (dict): 测试床的配置字典，预期包含'dut'键，其中包含设备相关信息。

    返回:
    dict: 包含初始化后的设备对象的字典，键为设备名称。

    异常:
    ValueError: 如果配置字典缺少 'dut', 'name', 'dut_cfg' 其中之一，则抛出此异常。
    """
    # 检查配置字典是否包含必需的键
    if not all(key in cfg for key in ['dut', 'name', 'dut_cfg']):
        raise ValueError("Configuration missing required keys")

    # 初始化一个空字典来存储设备对象
    ret = {}
    flag = False
    # 遍历配置字典中的每个设备
    for i in cfg['dut']:
        # 创建设备对象并添加到返回字典中
        device = Device(case=cfg['tc_no'], testbed=testbed, name=i)
        ret.update({i: device})

        # 遍历设备配置，寻找特定配置项并执行
        for j in cfg['dut_cfg']:
            # 如果当前设备适用该配置项并且包含 'Setup'
            if i in j and 'Setup' in j:
                # 解析配置项的具体命令并执行
                cmd_cfg = '_'.join(j.split('_')[1:])
                for _ in range(3):
                    flag = device.execute(row=cmd_cfg)
                    if flag:
                        break
    if not flag:
        raise Exception(f'设备{i}下发配置失败！')
    # 返回包含所有初始化设备的字典
    return ret


def teardown(cfg: dict, testbed: dict) -> dict:
    """
    根据提供的配置执行环境清理操作。

    该函数遍历配置文件中的设备配置，并根据特定的配置执行清理命令。

    参数:
    cfg (dict): 包含测试环境配置的字典，必须包含 'dut', 'name', 'dut_cfg' 键。

    返回:
    dict: 包含初始化后的设备对象的字典，键为设备名称。

    异常:
    ValueError: 如果配置字典缺少 'dut', 'name', 'dut_cfg' 其中之一，则抛出此异常。
    """
    # 检查配置是否包含必要的键
    if not all(key in cfg for key in ['dut', 'name', 'dut_cfg']):
        raise ValueError("Configuration missing required keys")

    # 初始化返回的字典
    ret = {}
    flag = False
    # 遍历配置中的设备列表
    for i in cfg['dut']:
        # 创建设备对象
        device = Device(case=cfg['tc_no'], testbed=testbed, name=i)
        # 将设备对象添加到返回的字典中
        ret.update({i: device})

        # 遍历设备配置，寻找对应的清理命令
        for j in cfg['dut_cfg']:
            # 检查当前配置是否适用于该设备，并包含清理操作
            if i in j and 'Teardown' in j:
                # 从配置中提取具体的命令配置
                cmd_cfg = '_'.join(j.split('_')[1:])
                # 执行清理命令
                for _ in range(3):
                    flag = device.execute(row=cmd_cfg)
                    if flag:
                        break
    if not flag:
        raise Exception(f'设备{i}清除配置失败！')
    # 返回包含所有设备对象的字典
    return ret


class CustomData:
    verdict = 'pass'
    errInfo = ''

    def __init__(self):
        self.case_name = cfg['tc_no']
        self.temp = os.path.abspath(os.path.join(script_dir, os.path.pardir, os.pardir, 'temp'))
        self.report = os.path.abspath(os.path.join(script_dir, os.path.pardir, os.pardir, 'report'))
        if not os.path.exists(self.report):
            os.makedirs(self.report)
        self.db_file = os.path.join(self.report, 'report.db')
        yaml = YAML(typ='safe')
        self._case_yaml = os.path.join(script_dir, 'cfg.yaml')
        if os.path.exists(self._case_yaml):
            with open(self._case_yaml, 'r', encoding='utf-8') as fid:
                self.case = yaml.load(fid)

    def write_report(self, dateframe):
        if not os.path.isfile(self.db_file):
            with open(self.db_file, 'w') as fid:
                pass
        with sqlite3.connect(self.db_file) as conn:
            dateframe.to_sql(self.case_name, conn, if_exists='replace')

    def read_sql(self, table=None):
        if table is None:
            table = self.case_name
        with sqlite3.connect(self.db_file) as conn:
            return pd.read_sql_table(table, conn)

    def Dialog(self):

        def __init__(self):
            pass

        def button_box():
            root = tkinter.Tk()
            button = tkinter.Button(root, text="显示对话框")
            button.pack()
            root.mainloop()

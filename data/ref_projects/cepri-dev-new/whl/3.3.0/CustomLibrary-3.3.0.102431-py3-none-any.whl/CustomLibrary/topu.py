Tester_ip = '192.168.0.180'
Tester_port_1 = "1/1"
Tester_port_2 = "1/2"
Tester_port_3 = "1/3"
Tester_port_4 = "1/4"
Tester_port_5 = "1/5"

DeviceA_product_type = "BDCOM_s3900"
DeviceA_ip = "192.168.0.181"
DeviceA_username = "admin"
DeviceA_password = "admin"
DeviceA_port_1 = "g0/0/1"
DeviceA_port_2 = "g0/0/2"
DeviceA_port_3 = "g0/0/3"
DeviceA_port_4 = "g0/0/4"
DeviceA_port_5 = "g0/0/6"
DeviceA_port_6 = "10GE 1/0/50"

DeviceB_product_type = "BDCOM_s3900"
DeviceB_ip = "192.168.0.182"
DeviceB_username = "admin"
DeviceB_password = "admin"
DeviceB_port_1 = "g0/0/5"
DeviceB_port_2 = "10GE 1/0/46"
DeviceB_port_3 = "g0/0/6"

DeviceC_product_type = "Huawei_CE6881"
DeviceC_ip = "10.0.11.207"
DeviceC_username = "admin123"
DeviceC_password = "ADmin@123"
DeviceC_port_1 = "10GE 1/0/45"
DeviceC_port_2 = "10GE 1/0/46"

DeviceD_product_type = "Huawei_CE6881"
DeviceD_ip = "10.0.11.208"
DeviceD_username = "admin123"
DeviceD_password = "ADmin@123"
DeviceD_port_1 = "10GE 1/0/45"
DeviceD_port_2 = "10GE 1/0/46"


try:
    import importlib
    importlib.import_module('param')
    import param

    Tester_ip = param.tester_ip
    Tester_port_1 = param.tester_port_1
    Tester_port_2 = param.tester_port_2
    Tester_port_3 = param.tester_port_3
    Tester_port_4 = param.tester_port_4
    Tester_port_5 = param.tester_port_5

    DeviceA_product_type = param.DeviceA_product_type
    DeviceA_ip = param.DeviceA_ip
    DeviceA_username = param.DeviceA_username
    DeviceA_password = param.DeviceA_password
    DeviceA_port_1 = param.DeviceA_port_1
    DeviceA_port_2 = param.DeviceA_port_2
    DeviceA_port_3 = param.DeviceA_port_3
    DeviceA_port_4 = param.DeviceA_port_4
    DeviceA_port_5 = param.DeviceA_port_5
    DeviceA_port_6 = param.DeviceA_port_6

    DeviceB_product_type = param.DeviceB_product_type
    DeviceB_ip = param.DeviceB_ip
    DeviceB_username =  param.DeviceB_username
    DeviceB_password =  param.DeviceB_password
    DeviceB_port_1 = param.DeviceB_port_1
    DeviceB_port_2 =  param.DeviceB_port_2
    DeviceB_port_3 =  param.DeviceB_port_3

    DeviceC_product_type =  param.DeviceC_product_type
    DeviceC_ip =  param.DeviceC_ip
    DeviceC_username = param.DeviceC_username
    DeviceC_password = param.DeviceC_password
    DeviceC_port_1 = param.DeviceC_port_1
    DeviceC_port_2 = param.DeviceC_port_2

    DeviceD_product_type =  param.DeviceD_product_type
    DeviceD_ip = param.DeviceD_ip
    DeviceD_username = param.DeviceD_username
    DeviceD_password = param.DeviceD_password
    DeviceD_port_1 = param.DeviceD_port_1
    DeviceD_port_2 = param.DeviceD_port_2

except Exception as e:
    pass


topu_json = {
    "nodes": [
        {
            "label": "Tester",
            "id": "Tester",
            "params": [
                {
                    "name": "product",
                    "value": "tester",
                    "description": "设备类型"
                },
                {
                    "name": "product_type",
                    "value": "BigTao220",
                    "description": "产品型号"
                },
                {
                    "name": "sn",
                    "value": "123451546",
                    "description": "机箱序列号"
                },
                {
                    "name": "ip",
                    "value": Tester_ip,
                    "description": "机箱IP地址"
                }
            ],
            "points": [
                {
                    "location": Tester_port_1,
                    "description": "仪表端口"
                },
                {
                    "location": Tester_port_2,
                    "description": "仪表端口"
                },
                {
                    "location": Tester_port_3,
                    "description": "仪表端口"
                },
                {
                    "location": Tester_port_4,
                    "description": "仪表端口"
                },
                {
                    "location": Tester_port_5,
                    "description": "仪表端口"
                }
            ]
        },
        {
            "label": "DeviceA",
            "id": "DeviceA",
            "params": [
                {
                    "name": "product",
                    "value": "switch",
                    "description": "设备类型"
                },
                {
                    "name": "product_type",
                    "value": DeviceA_product_type,
                    "description": "产品型号"
                },
                {
                    "name": "sn",
                    "value": "1234515461",
                    "description": "设备序列号"
                },
                {
                    "name": "ip",
                    "value": DeviceA_ip,
                    "description": "设备IP地址"
                },
                {
                    "name": "login_type",
                    "value": "ssh",
                    "description": "cli登录方式"
                },
                {
                    "name": "username",
                    "value": DeviceA_username,
                    "description": "设备登录用户名"
                },
                {
                    "name": "password",
                    "value": DeviceA_password,
                    "description": "设备登录密码"
                }
            ],
            "points": [
                {
                    "location": DeviceA_port_1,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceA_port_2,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceA_port_3,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceA_port_4,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceA_port_5,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceA_port_6,
                    "description": "设备物理端口"
                }
            ]
        },
        {
            "label": "DeviceB",
            "id": "DeviceB",
            "params": [
                {
                    "name": "product",
                    "value": "switch",
                    "description": "设备类型"
                },
                {
                    "name": "product_type",
                    "value": DeviceB_product_type,
                    "description": "产品型号"
                },
                {
                    "name": "sn",
                    "value": "1234515462",
                    "description": "设备序列号"
                },
                {
                    "name": "ip",
                    "value": DeviceB_ip,
                    "description": "设备IP地址"
                },
                {
                    "name": "login_type",
                    "value": "ssh",
                    "description": "cli登录方式"
                },
                {
                    "name": "username",
                    "value": DeviceB_username,
                    "description": "设备登录用户名"
                },
                {
                    "name": "password",
                    "value": DeviceB_password,
                    "description": "设备登录密码"
                }
            ],
            "points": [
                {
                    "location": DeviceB_port_1,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceB_port_2,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceB_port_3,
                    "description": "设备物理端口"
                }
            ]
        },
        {
            "label": "DeviceC",
            "id": "DeviceC",
            "params": [
                {
                    "name": "product",
                    "value": "switch",
                    "description": "设备类型"
                },
                {
                    "name": "product_type",
                    "value": DeviceC_product_type,
                    "description": "产品型号"
                },
                {
                    "name": "sn",
                    "value": "1234515463",
                    "description": "设备序列号"
                },
                {
                    "name": "ip",
                    "value": DeviceC_ip,
                    "description": "设备IP地址"
                },
                {
                    "name": "login_type",
                    "value": "ssh",
                    "description": "cli登录方式"
                },
                {
                    "name": "username",
                    "value": DeviceC_username,
                    "description": "设备登录用户名"
                },
                {
                    "name": "password",
                    "value": DeviceC_password,
                    "description": "设备登录密码"
                }
            ],
            "points": [
                {
                    "location": DeviceC_port_1,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceC_port_2,
                    "description": "设备物理端口"
                }
            ]
        },
        {
            "label": "DeviceD",
            "id": "DeviceD",
            "params": [
                {
                    "name": "product",
                    "value": "switch",
                    "description": "设备类型"
                },
                {
                    "name": "product_type",
                    "value": DeviceD_product_type,
                    "description": "产品型号"
                },
                {
                    "name": "sn",
                    "value": "1234515463",
                    "description": "设备序列号"
                },
                {
                    "name": "ip",
                    "value": DeviceD_ip,
                    "description": "设备IP地址"
                },
                {
                    "name": "login_type",
                    "value": "ssh",
                    "description": "cli登录方式"
                },
                {
                    "name": "username",
                    "value": DeviceD_username,
                    "description": "设备登录用户名"
                },
                {
                    "name": "password",
                    "value": DeviceD_password,
                    "description": "设备登录密码"
                }
            ],
            "points": [
                {
                    "location": DeviceD_port_1,
                    "description": "设备物理端口"
                },
                {
                    "location": DeviceD_port_2,
                    "description": "设备物理端口"
                }
            ]
        }
    ],
    "edges": [
        {
            "label": "PortDeviceA_1",
            "source": "DeviceA",
            "target": "Tester",
            "sourceAnchor": 0,
            "targetAnchor": 0
        },
        {
            "label": "PortDeviceA_2",
            "source": "DeviceA",
            "target": "Tester",
            "sourceAnchor": 1,
            "targetAnchor": 1
        },
        {
            "label": "PortDeviceA_3",
            "source": "DeviceA",
            "target": "Tester",
            "sourceAnchor": 2,
            "targetAnchor": 2
        },
        {
            "label": "PortDeviceA_4",
            "source": "DeviceA",
            "target": "Tester",
            "sourceAnchor": 3,
            "targetAnchor": 3
        },
        {
            "label": "PortDeviceB_1",
            "source": "DeviceB",
            "target": "Tester",
            "sourceAnchor": 0,
            "targetAnchor": 4
        },
        {
            "label": "Line_1",
            "source": "DeviceA",
            "target": "DeviceB",
            "sourceAnchor": 4,
            "targetAnchor": 1
        },
        {
            "label": "Line_2",
            "source": "DeviceA",
            "target": "DeviceC",
            "sourceAnchor": 5,
            "targetAnchor": 0
        },
        {
            "label": "Line_3",
            "source": "DeviceB",
            "target": "DeviceD",
            "sourceAnchor": 2,
            "targetAnchor": 0
        },
        {
            "label": "Line_4",
            "source": "DeviceC",
            "target": "DeviceD",
            "sourceAnchor": 1,
            "targetAnchor": 1
        }
    ]
}

def tupo_to_testbed(topu):
    nodes_data = topu['nodes']
    nodes = {}
    for i in nodes_data:
        temp_dict = {'label': i['label']}
        for param in i.get('params', []):
            temp_dict.update({
                param.get('name'): {
                    'description': param.get('description'),
                    'default': param.get('value')
                },
                'points': i.get('points', []),
                'params': i.get('params', [])
            })
        nodes.update({
            i['id']: temp_dict
        })

    dut = {
        "description": "被测设备信息",
        "auto": {
            "description": "是否自动化下发设备配置",
            "default": True
        },
        "command_source": {
            "description": "从哪种方式获取配置，支持：excel、txt",
            "default": "txt"
        }
    }

    for k, v in nodes.items():
        if v['product']['default'].lower() != '网络测试仪表':
            dut.update({
                v['label']: {
                    "dut_type": v['product_type']['default'],
                    "dut_ip": v['ip']['default'],
                    "dut_user": v['username']['default'],
                    "dut_password": v['password']['default']
                }
            })

    edges_data = topu['edges']
    for i in edges_data:
        source_node = nodes.get(i['source'])
        target_node = nodes.get(i['target'])
        source_points = source_node.get('points', [])
        target_points = target_node.get('points', [])

        if target_node['label'] in dut:

            if source_node['product']['default'].lower() == '网络测试仪表':
                port_type = "tester"
                location = '//{}/{}'.format(source_node['ip']['default'], source_points[i['sourceAnchor']]['value'])
            else:
                port_type = "dut"
                location = source_points[i['sourceAnchor']]['value']

            interface = {
                i['label']: {
                    "port_type": port_type,
                    "interface": target_points[i['targetAnchor']]['value'],
                    "location": location
                }
            }
            dut_info = dut[target_node['label']]
            if 'interface' in dut_info:
                dut_interface = dut_info['interface']
            else:
                dut_interface = {}
            dut_interface.update(interface)
            dut_info.update({'interface': dut_interface})
            dut.update({target_node['label']: dut_info})

        if source_node['label'] in dut:

            if target_node['product']['default'].lower() == '网络测试仪表':
                port_type = "tester"
                location = '//{}/{}'.format(target_node['ip']['default'], target_points[i['targetAnchor']]['value'])
            else:
                port_type = "dut"
                location = target_points[i['targetAnchor']]['value']

            interface = {
                i['label']: {
                    "port_type": port_type,
                    "interface": source_points[i['sourceAnchor']]['value'],
                    "location": location
                }
            }
            dut_info = dut[source_node['label']]
            if 'interface' in dut_info:
                dut_interface = dut_info['interface']
            else:
                dut_interface = {}
            dut_interface.update(interface)
            dut_info.update({'interface': dut_interface})
            dut.update({source_node['label']: dut_info})

    tester_params = False
    for k, v in nodes.items():
        if v['product']['default'].lower() == '网络测试仪表':
            tester_params = {"description": "测试仪表信息"}
            for p in v['params']:
                tester_params.update({p['name']: {
                    'description': p['description'],
                    'default': p['value']
                }})
            if "product_type" not in tester_params:
                tester_params.update({
                    "product_type": {
                        "description": "renix产品类型 BIGTAO or DARYU",
                        "default": "BIGTAO"
                    },
                })
            if "rtsm" not in tester_params:
                tester_params.update({
                    "rtsm": {
                        "description": "是否使用rtsm",
                        "ip": False,
                        "app": True
                    },
                })
            if "force" not in tester_params:
                tester_params.update({
                    "force": {
                        "description": "是否强制占用端口",
                        "default": True
                    },
                })
            if "debug" not in tester_params:
                tester_params.update({
                    "debug": {
                        "description": "是否使用离线模式调试",
                        "default": False
                    },
                })
            if "wait_for_status_up" not in tester_params:
                tester_params.update({
                    "wait_for_status_up": {
                        "description": "是否等待端口UP",
                        "default": True
                    }
                })
        elif v['product']['default'].lower() == '物理层交换机':
            tester_params = {"description": "物理层交换机信息"}
            for p in v['params']:
                tester_params.update({p['name']: {
                    'description': p['description'],
                    'default': p['value']
                }})
            if "enable" not in tester_params:
                tester_params.update({
                    "enable": {
                        "description": "是否自动化切换拓扑",
                        "default": False
                    },
                })

    if not tester_params:
        test_bed = {
            "version": {
                "description": "版本号",
                "default": "v1.0.0"
            },
            "tester": {
                "description": "测试仪表信息",
                "product_type": {
                    "description": "renix产品类型 BIGTAO or DARYU",
                    "default": "BIGTAO"
                },
                "rtsm": {
                    "description": "是否使用rtsm",
                    "ip": False,
                    "app": True
                },
                "force": {
                    "description": "是否强制占用端口",
                    "default": True
                },
                "debug": {
                    "description": "是否使用离线模式调试",
                    "default": False
                },
                "wait_for_status_up": {
                    "description": "是否等待端口UP",
                    "default": True
                }
            }
        }
    else:
        test_bed = {
            "version": {
                "description": "版本号",
                "default": "v1.0.0"
            },
            "tester": tester_params
        }

    test_bed.update({'dut': dut})
    return test_bed

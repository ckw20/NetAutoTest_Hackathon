# =================================================================================
# Objective   	:   测试目的 : 检查测试仪表发流StreamBlockStats统计正确
#
# Step			:	测试步骤1: 预约两个自环端口Port_1、Port_2;
#                   测试步骤2: 端口Port_1, Port_2分别创建两条流量StreamTemplate_1、2、3、4;
#                   测试步骤3: 订阅StreamBlockStats统计;
#                   测试步骤4: 发送所有流量，查看StreamBlockStats统计信息，等待一段时间;
#                   测试步骤5: 停止所有流量，查看StreamBlockStats统计信息;
#
# Criteria    	:   预期结果1: 步骤4,5中StreamBlockStats统计信息获取正确;
#
# Created by   	:  	Tester-001
#
# Bugs   	    :  	None
# =================================================================================

from TesterLibrary.base import *

locations = ['//10.0.11.191/1/15', '//10.0.11.191/1/16'] if len(sys.argv) < 2 else sys.argv[1].split(' ')
Product = 'DarYu' if len(sys.argv) < 3 else sys.argv[2].split(' ')

verdict = 'pass'
errInfo = ''
try:

    # 初始化仪表，执行仪表平台为DarYu
    init_tester(Product=Product)

    # 创建端口，并预约端口
    Port_UP, Port_Down = reserve_port(Locations=locations, Force=True)

    # 创建流量
    streams = add_stream(Ports=[Port_UP, Port_UP, Port_Down, Port_Down])

    # 订阅StreamBlockStats统计视图
    subscribe_result(Types=['StreamBlockStats'])

    # 保存配置文件
    dirname, tempfilename = os.path.split(os.path.abspath(__file__))
    filename, extension = os.path.splitext(tempfilename)
    save_case(Path=f'{dirname}/xcfg/{filename}.xcfg')

    # 发送流量
    start_stream()
    # 发送流获取统计建议等待10sec获取到稳定统计数据
    time.sleep(10)

    # NOTE: 统计获取数据返回基本原则，当获取到单行数据时返回dict类型数据，
    # 当获取到多行数据时返回Pandas的DataFrame数据，Pandas详细请参考: https://www.pypandas.cn/
    # 统计获取方式1 -- 获取StreamBlockStats所有统计结果:
    # get_streamblock_statistic不传参数，返回值为DataFrame数据
    result = get_streamblock_statistic()
    # 使用tabulate库表格化输出DataFrame二维数据
    print('\n' + tabulate(result, headers='keys', tablefmt='psql') + '\n')
    # 将DataFrame数据转成list[dict]形式
    data = result.to_dict('records')
    print(data)

    # 将数据存入数据库，供自动化测试平台读取数据展示
    # 规则：
    # 1. 在脚本同级目录下，创建一个以脚本名称命名的db文件，如脚本名称GetStreamBlockStatistic_Save创建的db文件为：GetStreamBlockStatistic_Save.db
    # 2. db创建好之后将要展示的数据存储的db文件以脚本名称名称的table表格中，自动化测试平台会读取这个表格做数据展示
    # 具体实现参考如下示例
    # 创建GetStreamBlockStatistic_Save.db文件
    with open(f'{dirname}/{filename}.db', 'w') as fid:
        pass
    # 创建将脚本中获取到的pandas dataframe类型数据存入GetStreamBlockStatistic_Save.db文件GetStreamBlockStatistic_Save表格中
    with sqlite3.connect(f'{dirname}/{filename}.db') as conn:
        result.to_sql(filename, conn, if_exists='replace')

    # 根据DataFrame数据筛选出StreamTemplate_1的TxFrameRate和RxStreamFrames
    df = result[(result['StreamBlockID'] == streams[0].Name)][['TxFrameRate', 'RxFrameRate']]
    data = df.to_dict('records')[0]
    # 判断StreamTemplate_1收发包速率不为0
    if data['TxFrameRate'] == 0 or data['RxFrameRate'] == 0:
        verdict = 'fail'
        errInfo += f'{streams[0].Name} TxFrameRate or RxFrameRate is equal to 0\n'

    stop_stream()
    # 停流获取统计必须等待3sec才能获取到稳定统计数据
    time.sleep(3)


except Exception as e:
    verdict = 'fail'
    errInfo = repr(e)
finally:
    print(f'errInfo:\n{errInfo}')
    print(f'verdict:{verdict}')
